<?php
session_start();
require_once __DIR__ . '/config.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $panelist_id = trim($_POST['panelist_id'] ?? '');
    $email = trim($_POST['email'] ?? '');

    $conn = exaconnect_db();
    $stmt = $conn->prepare("SELECT * FROM exaconnect_panelists WHERE panelist_id = ? AND email = ? LIMIT 1");
    $stmt->execute([$panelist_id, $email]);
    $panelist = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($panelist) {
        $_SESSION['exaconnect_panelist_id'] = $panelist['id'];
        header('Location: panelist_portal.php');
        exit;
    } else {
        $error = 'We could not find an account matching that Panelist ID and email.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<title>Panelist Login | ExaConnect</title>
<style>
  body{font-family:'DM Sans',sans-serif;background:#0a1628;color:#e8edf5;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;}
  form{background:#111e38;border:1px solid rgba(255,255,255,.07);border-radius:14px;padding:32px;width:320px;}
  h1{font-size:18px;margin-bottom:20px;color:#e8c96a;}
  label{display:block;font-size:13px;color:#8a9bb8;margin:12px 0 6px;}
  input{width:100%;padding:10px;background:#0f2040;border:1px solid rgba(255,255,255,.07);border-radius:8px;color:#e8edf5;box-sizing:border-box;}
  button{width:100%;margin-top:18px;padding:11px;background:linear-gradient(135deg,#c9a84c,#e8c96a);border:none;border-radius:8px;color:#0a1628;font-weight:500;cursor:pointer;}
  .error{color:#e74c3c;font-size:13px;margin-top:10px;}
</style>
</head>
<body>
<form method="post">
  <h1>Panelist Login</h1>
  <label>Panelist ID</label><input type="text" name="panelist_id" placeholder="EXZ-2026-UN0123" required>
  <label>Registered email</label><input type="email" name="email" required>
  <button type="submit">Log in</button>
  <?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
</form>
</body>
</html>
