<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) { header('Location: admin_login.php'); exit; }
$conn = exaconnect_db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn->prepare("INSERT INTO exaconnect_profile_questions (question_key, question_label, field_type, options, sort_order) VALUES (?,?,?,?,?)")
         ->execute([
            trim($_POST['question_key']), trim($_POST['question_label']),
            $_POST['field_type'], trim($_POST['options']), (int)$_POST['sort_order']
         ]);
    header('Location: admin_profile_questions.php'); exit;
}

$rows = $conn->query("SELECT * FROM exaconnect_profile_questions ORDER BY sort_order ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"/><title>Profile Questions | ExaConnect</title><link rel="stylesheet" href="admin.css"></head>
<body>
<header><h1>ExaConnect Admin</h1><a class="signout" href="admin_logout.php">Sign out</a></header>
<?php include 'nav_include.php'; ?>
<main>
  <div class="card">
    <h2 style="font-size:14px;margin-bottom:10px;">Add a registration profile question</h2>
    <form method="post">
      <label>Key (no spaces)</label><input name="question_key" required>
      <label>Label shown to panelist</label><input name="question_label" required>
      <label>Type</label>
      <select name="field_type"><option value="text">Text</option><option value="select">Dropdown</option></select>
      <label>Options (comma separated, only for dropdown)</label><input name="options">
      <label>Sort order</label><input type="number" name="sort_order" value="0">
      <button type="submit" style="margin-top:10px;">Add question</button>
    </form>
  </div>
  <table>
    <tr><th>Key</th><th>Label</th><th>Type</th><th>Options</th><th>Active</th><th>Action</th></tr>
    <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= htmlspecialchars($r['question_key']) ?></td>
      <td><?= htmlspecialchars($r['question_label']) ?></td>
      <td><?= htmlspecialchars($r['field_type']) ?></td>
      <td><?= htmlspecialchars($r['options']) ?></td>
      <td><?= $r['is_active'] ? 'Yes' : 'No' ?></td>
      <td><button class="ghost" onclick="toggleQ(<?= $r['id'] ?>)">Toggle</button></td>
    </tr>
    <?php endforeach; ?>
  </table>
</main>
<script>
function toggleQ(id) {
  fetch('profile_question_actions.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({action:'toggle', id}) })
    .then(() => location.reload());
}
</script>
</body></html>
