<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/config.php';

if (empty($_SESSION['exaconnect_panelist_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Not logged in.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$points = (int)($input['points'] ?? 0);
$method = $input['method'] ?? '';
$details = trim($input['details'] ?? '');

if ($points <= 0 || !in_array($method, ['bank_transfer', 'gift_card'], true) || !$details) {
    echo json_encode(['success' => false, 'message' => 'Please fill in all fields.']);
    exit;
}

$conn = exaconnect_db();
$conn->beginTransaction();

$stmt = $conn->prepare("SELECT points_balance FROM exaconnect_panelists WHERE id = ? FOR UPDATE");
$stmt->execute([$_SESSION['exaconnect_panelist_id']]);
$balance = (int)$stmt->fetchColumn();

if ($balance < $points) {
    $conn->rollBack();
    echo json_encode(['success' => false, 'message' => 'You do not have enough points for this request.']);
    exit;
}

// Generate a redemption reference like RED-000042
$countStmt = $conn->query("SELECT COUNT(*) FROM exaconnect_redemptions");
$next = $countStmt->fetchColumn() + 1;
$ref = 'RED-' . str_pad((string)$next, 6, '0', STR_PAD_LEFT);

$conn->prepare("INSERT INTO exaconnect_redemptions
    (redemption_ref, panelist_id, points_requested, method, payout_details, status)
    VALUES (?, ?, ?, ?, ?, 'pending')")
    ->execute([$ref, $_SESSION['exaconnect_panelist_id'], $points, $method, $details]);

// Deduct points immediately (held pending); if rejected later, points are refunded.
$conn->prepare("UPDATE exaconnect_panelists SET points_balance = points_balance - ? WHERE id = ?")
     ->execute([$points, $_SESSION['exaconnect_panelist_id']]);
$conn->prepare("INSERT INTO exaconnect_point_ledger (panelist_id, points_change, reason, source) VALUES (?, ?, ?, 'manual')")
     ->execute([$_SESSION['exaconnect_panelist_id'], -$points, "Redemption requested: {$ref}"]);

$conn->commit();
echo json_encode(['success' => true, 'redemption_ref' => $ref]);
