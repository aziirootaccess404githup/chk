-- ExaConnect — Phase 2 schema additions
-- Run this after schema.sql (Phase 1) is already in place.

ALTER TABLE exaconnect_panelists
  ADD COLUMN points_balance INT UNSIGNED NOT NULL DEFAULT 0 AFTER status;

CREATE TABLE IF NOT EXISTS exaconnect_point_ledger (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  panelist_id INT UNSIGNED NOT NULL,
  points_change INT NOT NULL,              -- positive = earned, negative = redeemed
  reason VARCHAR(255) NOT NULL,            -- e.g. "Survey complete: PRJ-1e92" or "Redemption: RED-000042"
  source VARCHAR(30) NOT NULL DEFAULT 'manual', -- 'manual' (admin credit) or 'webhook' (ExaVerify signal)
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (panelist_id) REFERENCES exaconnect_panelists(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exaconnect_redemptions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  redemption_ref VARCHAR(20) NOT NULL UNIQUE,   -- e.g. RED-000042
  panelist_id INT UNSIGNED NOT NULL,
  points_requested INT UNSIGNED NOT NULL,
  method ENUM('bank_transfer','gift_card') NOT NULL,
  payout_details TEXT DEFAULT NULL,             -- bank details or gift card email, entered by panelist
  status ENUM('pending','approved','paid','rejected') NOT NULL DEFAULT 'pending',
  admin_note VARCHAR(255) DEFAULT NULL,
  requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reviewed_at DATETIME DEFAULT NULL,
  reviewed_by VARCHAR(100) DEFAULT NULL,
  FOREIGN KEY (panelist_id) REFERENCES exaconnect_panelists(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Simple shared-secret table for the ExaVerify -> ExaConnect completion webhook.
-- This is the interim connection mechanism: ExaVerify's track.php (or a small
-- script alongside it) can POST to webhook_credit_points.php with this key
-- once the connection method is finalised. Replace the placeholder value.
CREATE TABLE IF NOT EXISTS exaconnect_webhook_keys (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  key_name VARCHAR(50) NOT NULL,
  key_value VARCHAR(100) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO exaconnect_webhook_keys (key_name, key_value)
VALUES ('exaverify_completion', 'REPLACE_WITH_A_LONG_RANDOM_SECRET');
