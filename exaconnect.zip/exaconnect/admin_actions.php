<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/config.php';

if (empty($_SESSION['exaconnect_admin_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Not authenticated.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';

if ($action === 'review') {
    $id = (int)($input['id'] ?? 0);
    $status = $input['status'] ?? '';
    if (!$id || !in_array($status, ['approved', 'rejected'], true)) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $conn = exaconnect_db();
    $stmt = $conn->prepare("UPDATE exaconnect_panelists
        SET status = ?, reviewed_at = NOW(), reviewed_by = ?
        WHERE id = ?");
    $stmt->execute([$status, $_SESSION['exaconnect_admin_name'], $id]);

    echo json_encode(['success' => true]);
    exit;
}

if ($action === 'review_redemption') {
    $id = (int)($input['id'] ?? 0);
    $status = $input['status'] ?? '';
    if (!$id || !in_array($status, ['paid', 'rejected'], true)) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $conn = exaconnect_db();
    $conn->beginTransaction();

    // FOR UPDATE genuinely locks this specific row for the duration of
    // the transaction — without it, two admins (or one admin
    // double-clicking) approving the same redemption at nearly the same
    // moment could both read status='pending' before either commits,
    // and both send a real Tremendous payout for it. This makes the
    // second request genuinely wait for the first to finish, so it sees
    // the updated status and correctly stops instead of double-paying.
    $stmt = $conn->prepare("
        SELECT r.*, p.first_name, p.last_name, p.email
        FROM exaconnect_redemptions r
        JOIN exaconnect_panelists p ON p.id = r.panelist_id
        WHERE r.id = ? LIMIT 1 FOR UPDATE
    ");
    $stmt->execute([$id]);
    $redemption = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$redemption || $redemption['status'] !== 'pending') {
        $conn->rollBack();
        echo json_encode(['success' => false, 'message' => 'Redemption not found or already handled.']);
        exit;
    }

    if ($status === 'paid') {
        require_once __DIR__ . '/tremendous_send.php';
        $amount_usd = round($redemption['points_requested'] / POINTS_PER_USD, 2);
        $name = trim($redemption['first_name'] . ' ' . $redemption['last_name']);
        $result = send_tremendous_reward($name, $redemption['email'], $amount_usd, "Redemption {$redemption['redemption_ref']}");

        if (!$result['success']) {
            $conn->rollBack();
            echo json_encode(['success' => false, 'message' => 'Reward send failed: ' . $result['message']]);
            exit;
        }
    }

    $conn->prepare("UPDATE exaconnect_redemptions SET status = ?, reviewed_at = NOW(), reviewed_by = ? WHERE id = ?")
         ->execute([$status, $_SESSION['exaconnect_admin_name'], $id]);

    if ($status === 'rejected') {
        // Refund the held points back to the panelist.
        $conn->prepare("UPDATE exaconnect_panelists SET points_balance = points_balance + ? WHERE id = ?")
             ->execute([$redemption['points_requested'], $redemption['panelist_id']]);
        $conn->prepare("INSERT INTO exaconnect_point_ledger (panelist_id, points_change, reason, source) VALUES (?, ?, ?, 'manual')")
             ->execute([$redemption['panelist_id'], $redemption['points_requested'], "Redemption rejected, refunded: {$redemption['redemption_ref']}"]);
    }

    $conn->commit();
    echo json_encode(['success' => true]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Unknown action.']);
