<?php
// webhook_credit_points.php
// Called by ExaVerify (via a small addition to track.php — see
// track_php_patch_instructions.md) when a survey completes for a known
// panelist. Matches primarily by panelist_id (since that's what's passed
// as the uid on the survey link), with email as a fallback.
//
// Expected POST JSON:
//   { "key": "the shared secret", "panelist_id": "EXZ-2026-UN0123",
//     "project_ref": "PRJ-1e92", "reason": "Survey complete: PRJ-1e92" }

header('Content-Type: application/json');
require_once __DIR__ . '/config.php';

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid payload.']);
    exit;
}

$conn = exaconnect_db();

// Validate shared secret — hash_equals() is used instead of a plain !==
// comparison specifically because this key gates real money moving
// through the system (points that convert to Tremendous payouts). A
// plain string comparison is vulnerable to a timing attack in theory;
// hash_equals() takes the same time regardless of where a mismatch
// occurs, which closes that off.
$keyRow = $conn->prepare("SELECT key_value FROM exaconnect_webhook_keys WHERE key_name = 'exaverify_completion' LIMIT 1");
$keyRow->execute();
$expectedKey = $keyRow->fetchColumn();

if (!$expectedKey || !hash_equals($expectedKey, (string)($input['key'] ?? ''))) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Invalid key.']);
    exit;
}

$panelist_id = trim($input['panelist_id'] ?? '');
$email = trim($input['email'] ?? '');
$project_ref = trim($input['project_ref'] ?? '');
$reason = trim($input['reason'] ?? 'Survey complete');

if (!$panelist_id && !$email) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing panelist_id/email.']);
    exit;
}

if ($panelist_id) {
    $stmt = $conn->prepare("SELECT id FROM exaconnect_panelists WHERE panelist_id = ? AND status = 'approved' LIMIT 1");
    $stmt->execute([$panelist_id]);
} else {
    $stmt = $conn->prepare("SELECT id FROM exaconnect_panelists WHERE email = ? AND status = 'approved' LIMIT 1");
    $stmt->execute([$email]);
}
$panelist = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$panelist) {
    // No matching approved panelist — this is expected for third-party/vendor
    // respondents who aren't panelists at all. Not an error.
    echo json_encode(['success' => true, 'matched' => false]);
    exit;
}

// Points value comes from THIS project's own setting in ExaConnect, not
// from whatever the caller sends — so changing a project's reward amount
// only ever needs updating it here, never a track.php edit. Falls back to
// the platform default if this project_ref isn't registered in
// exaconnect_open_projects (e.g. genuinely not yet set up there).
$points = DEFAULT_POINTS_PER_SURVEY;
if ($project_ref) {
    $projRow = $conn->prepare("SELECT points_value FROM exaconnect_open_projects WHERE project_ref = ? LIMIT 1");
    $projRow->execute([$project_ref]);
    $projPoints = $projRow->fetchColumn();
    if ($projPoints !== false) {
        $points = (int)$projPoints;
    }
}
if ($points <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid points value.']);
    exit;
}

// Idempotency check — genuinely prevents crediting the same completion
// twice if this webhook is ever called more than once for it (a network
// retry on ExaVerify's side, a manual re-trigger, etc). Matches on the
// exact same panelist + reason string, which already encodes the project
// ref — a genuinely different completion (different project, or the
// same project completed again after being re-taken) gets a different
// reason and is correctly NOT blocked by this.
$dupeCheck = $conn->prepare("SELECT id FROM exaconnect_point_ledger WHERE panelist_id = ? AND reason = ? AND source = 'webhook' LIMIT 1");
$dupeCheck->execute([$panelist['id'], $reason]);
if ($dupeCheck->fetch()) {
    echo json_encode(['success' => true, 'matched' => true, 'duplicate' => true]);
    exit;
}

$conn->beginTransaction();
$conn->prepare("UPDATE exaconnect_panelists SET points_balance = points_balance + ? WHERE id = ?")
     ->execute([$points, $panelist['id']]);
$conn->prepare("INSERT INTO exaconnect_point_ledger (panelist_id, points_change, reason, source) VALUES (?, ?, ?, 'webhook')")
     ->execute([$panelist['id'], $points, $reason]);
$conn->commit();

echo json_encode(['success' => true, 'matched' => true, 'points_credited' => $points]);
