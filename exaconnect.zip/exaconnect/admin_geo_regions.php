<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) { header('Location: admin_login.php'); exit; }
$conn = exaconnect_db();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn->prepare("INSERT INTO exaconnect_geo_regions (country, state_region, city) VALUES (?,?,?)")
         ->execute([trim($_POST['country']), trim($_POST['state_region']), trim($_POST['city'])]);
    header('Location: admin_geo_regions.php'); exit;
}
$rows = $conn->query("SELECT * FROM exaconnect_geo_regions ORDER BY country, state_region, city")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"/><title>Geo Regions | ExaConnect</title><link rel="stylesheet" href="admin.css"></head>
<body>
<header><h1>ExaConnect Admin</h1><a class="signout" href="admin_logout.php">Sign out</a></header>
<?php include 'nav_include.php'; ?>
<main>
  <div class="card">
    <h2 style="font-size:14px;margin-bottom:10px;">Add region</h2>
    <form method="post">
      <label>Country</label><input name="country" required>
      <label>State/Region</label><input name="state_region">
      <label>City</label><input name="city">
      <button type="submit" style="margin-top:10px;">Add</button>
    </form>
  </div>
  <table>
    <tr><th>Country</th><th>State/Region</th><th>City</th><th>Active</th><th>Action</th></tr>
    <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= htmlspecialchars($r['country']) ?></td>
      <td><?= htmlspecialchars($r['state_region']) ?></td>
      <td><?= htmlspecialchars($r['city']) ?></td>
      <td><?= $r['is_active'] ? 'Yes' : 'No' ?></td>
      <td><button class="ghost" onclick="toggleGeo(<?= $r['id'] ?>)">Toggle</button></td>
    </tr>
    <?php endforeach; ?>
  </table>
</main>
<script>
function toggleGeo(id){fetch('geo_region_actions.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'toggle',id})}).then(()=>location.reload());}
</script>
</body></html>
