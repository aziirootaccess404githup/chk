<?php
// tremendous_send.php
// Sends a reward via the Tremendous API when a redemption is marked paid.
// Sandbox mode (TREMENDOUS_TEST_MODE = true in config.php) uses fake money
// so you can test the whole flow safely before going live.
//
// NOTE: Tremendous's API can evolve — verify the request shape against
// their current docs (developers.tremendous.com) before relying on this
// in production, and always test a real send in sandbox mode first.

function send_tremendous_reward($recipient_name, $recipient_email, $amount_usd, $note = 'Panelist reward') {
    $base_url = TREMENDOUS_TEST_MODE
        ? 'https://testflight.tremendous.com/api/v2/orders'
        : 'https://api.tremendous.com/api/v2/orders';

    $payload = [
        'payment' => [
            'funding_source_id' => TREMENDOUS_TEST_MODE ? 'balance' : TREMENDOUS_FUNDING_SOURCE_ID,
        ],
        'reward' => [
            'value' => [
                'denomination' => (float)$amount_usd,
                'currency_code' => 'USD',
            ],
            'delivery' => [
                'method' => 'EMAIL',
            ],
            'recipient' => [
                'name' => $recipient_name,
                'email' => $recipient_email,
            ],
        ],
    ];

    if (!empty(TREMENDOUS_CAMPAIGN_ID)) {
        $payload['reward']['campaign_id'] = TREMENDOUS_CAMPAIGN_ID;
    }

    $ch = curl_init($base_url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . TREMENDOUS_API_KEY,
        ],
        CURLOPT_POSTFIELDS => json_encode($payload),
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($curlError) {
        return ['success' => false, 'message' => 'Network error contacting Tremendous: ' . $curlError];
    }

    $data = json_decode($response, true);

    if ($httpCode >= 200 && $httpCode < 300) {
        return ['success' => true, 'order_id' => $data['order']['id'] ?? null, 'raw' => $data];
    }

    return [
        'success' => false,
        'message' => $data['message'] ?? "Tremendous API error (HTTP {$httpCode})",
        'raw' => $data,
    ];
}
