<?php
// config.php — real credentials filled in for exaconnect.exazonresearch.com

define('DB_HOST', 'localhost');
define('DB_NAME', 'u994909610_exaconnect');
define('DB_USER', 'u994909610_exaconnect');
define('DB_PASS', 'Insights@8181');

// ExaVerify connection settings — fill these in once you've set up a
// vendor entry in ExaVerify representing "ExaConnect Panel" (Client > Assign
// Vendor on each project you want panelists to be able to take).
define('EXAVERIFY_BASE_URL', 'https://exaverify.exazonresearch.com');
define('EXAVERIFY_VENDOR_ID', 6); // ExaConnect Panel vendor in ExaVerify

// --- EmailJS (server-side sending, for OTP) -------------------------
// The Private Key is required for send_otp.php to call EmailJS's REST
// API directly from the server — this is genuinely what makes OTP
// verification real: the raw code only ever exists here and in the
// email itself, never in a browser-visible response.
define('EMAILJS_PUBLIC_KEY', 'ULmltpXraYu5ik48H');
define('EMAILJS_PRIVATE_KEY', '0rpgGsGJXviCtP_e3v8XG');
define('EMAILJS_SERVICE_ID', 'service_6tb3hwf');
define('EMAILJS_OTP_TEMPLATE_ID', 'template_dqdgjjs');
define('EMAILJS_CONTACT_TEMPLATE_ID', 'template_b1ee9uh');

// Genuinely used to sign the OTP-verification token (see verify_otp.php)
// — this must stay secret, it's what makes the token unforgeable.
define('OTP_TOKEN_SECRET', 'a7f3e91c4b8d2f60e5a1c9b7d3f8e2a6c4b9d7f1e3a5c8b2d6f9e1a4c7b3d5f8');

// Default points awarded per completed survey if a project doesn't set its
// own value in exaconnect_open_projects.points_value.
define('DEFAULT_POINTS_PER_SURVEY', 50);

// --- Tremendous (reward payouts: gift cards, PayPal, bank transfer) ------
// Get these from your Tremendous dashboard (Developer > API Keys, and
// Funding Sources once you've linked a bank account/card for real payouts).
define('TREMENDOUS_TEST_MODE', true); // true = sandbox, no real money moves
define('TREMENDOUS_API_KEY', 'TEST_9hMJJKGS5--jQaWdaCSmgDp71btD0g2Mhl5xRU8cCrc');
define('TREMENDOUS_FUNDING_SOURCE_ID', 'YOUR_FUNDING_SOURCE_ID'); // not needed while TEST_MODE is true
define('TREMENDOUS_CAMPAIGN_ID', ''); // optional — leave blank to use your account default

// How many points equal 1 US dollar of reward. Adjust to match your
// business economics.
define('POINTS_PER_USD', 100);

function exaconnect_db() {
    static $conn = null;
    if ($conn === null) {
        $conn = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
    }
    return $conn;
}

// Builds a panelist's unique survey link for a given project, using
// ExaVerify's existing vendor.php entry format: ?sid=..&vid=..&uid=..
// The panelist_id itself is passed as the uid — it's already a unique,
// non-guessable-enough string, so no extra encryption layer is needed.
function build_survey_link($project_ref, $panelist_id) {
    return EXAVERIFY_BASE_URL . '/vendor.php?sid=' . urlencode($project_ref)
        . '&vid=' . EXAVERIFY_VENDOR_ID . '&uid=' . urlencode($panelist_id);
}

// Generates a panelist ID in the same style as the existing system,
// e.g. EXZ-2026-UN0123 (UN = "unassigned region" placeholder; swap the
// middle segment for a country code if you want geo-tagged IDs).
function generate_panelist_id(PDO $conn) {
    $year = date('Y');
    do {
        $rand = str_pad((string) random_int(0, 9999), 4, '0', STR_PAD_LEFT);
        $candidate = "EXZ-{$year}-UN{$rand}";
        $stmt = $conn->prepare("SELECT id FROM exaconnect_panelists WHERE panelist_id = ? LIMIT 1");
        $stmt->execute([$candidate]);
    } while ($stmt->fetch());
    return $candidate;
}
