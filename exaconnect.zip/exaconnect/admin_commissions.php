<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) { header('Location: admin_login.php'); exit; }
$conn = exaconnect_db();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn->prepare("INSERT INTO exaconnect_commissions (project_ref, team_member, amount) VALUES (?,?,?)")
         ->execute([trim($_POST['project_ref']), trim($_POST['team_member']), (float)$_POST['amount']]);
    header('Location: admin_commissions.php'); exit;
}
$rows = $conn->query("SELECT * FROM exaconnect_commissions ORDER BY (status='pending') DESC, created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"/><title>Commissions | ExaConnect</title><link rel="stylesheet" href="admin.css"></head>
<body>
<header><h1>ExaConnect Admin</h1><a class="signout" href="admin_logout.php">Sign out</a></header>
<?php include 'nav_include.php'; ?>
<main>
  <div class="card">
    <h2 style="font-size:14px;margin-bottom:10px;">Add commission</h2>
    <form method="post">
      <label>Project reference</label><input name="project_ref" required>
      <label>Team member</label><input name="team_member" required>
      <label>Amount</label><input name="amount" type="number" step="0.01" required>
      <button type="submit" style="margin-top:10px;">Add</button>
    </form>
  </div>
  <table>
    <tr><th>Project</th><th>Team member</th><th>Amount</th><th>Status</th><th>Action</th></tr>
    <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= htmlspecialchars($r['project_ref']) ?></td>
      <td><?= htmlspecialchars($r['team_member']) ?></td>
      <td><?= htmlspecialchars($r['amount']) ?></td>
      <td><span class="badge <?= htmlspecialchars($r['status']) ?>"><?= htmlspecialchars($r['status']) ?></span></td>
      <td><?php if ($r['status']==='pending'): ?><button onclick="markPaid(<?= $r['id'] ?>)">Mark paid</button><?php endif; ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
</main>
<script>
function markPaid(id){fetch('commission_actions.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})}).then(()=>location.reload());}
</script>
</body></html>
