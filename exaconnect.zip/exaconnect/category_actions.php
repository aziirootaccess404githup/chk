<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) { http_response_code(403); echo json_encode(['success'=>false]); exit; }
$input = json_decode(file_get_contents('php://input'), true);
$conn = exaconnect_db();
if (($input['action'] ?? '') === 'toggle') {
    $conn->prepare("UPDATE exaconnect_categories SET is_active = 1 - is_active WHERE id=?")->execute([(int)$input['id']]);
    echo json_encode(['success'=>true]); exit;
}
echo json_encode(['success'=>false]);
