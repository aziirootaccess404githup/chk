-- ============================================================
-- Server-side OTP verification (fixes the client-side-bypassable
-- registration flow — see register.html/register_submit.php).
--
-- OTP is genuinely generated AND checked entirely server-side now.
-- The raw code is NEVER returned to the browser — only sent via
-- EmailJS's REST API, called from PHP using the Private Key, which
-- means it's genuinely impossible to read the code without receiving
-- the actual email.
-- ============================================================

CREATE TABLE IF NOT EXISTS exaconnect_otp_requests (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) NOT NULL,
  otp_hash VARCHAR(255) NOT NULL,
  attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
  verified TINYINT(1) NOT NULL DEFAULT 0,
  expires_at DATETIME NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
