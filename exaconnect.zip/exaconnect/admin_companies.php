<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) { header('Location: admin_login.php'); exit; }
$conn = exaconnect_db();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn->prepare("INSERT INTO exaconnect_companies (name, type, contact_email, contact_phone, notes) VALUES (?,?,?,?,?)")
         ->execute([trim($_POST['name']), $_POST['type'], trim($_POST['contact_email']), trim($_POST['contact_phone']), trim($_POST['notes'])]);
    header('Location: admin_companies.php'); exit;
}
$rows = $conn->query("SELECT * FROM exaconnect_companies ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"/><title>Companies | ExaConnect</title><link rel="stylesheet" href="admin.css"></head>
<body>
<header><h1>ExaConnect Admin</h1><a class="signout" href="admin_logout.php">Sign out</a></header>
<?php include 'nav_include.php'; ?>
<main>
  <div class="card">
    <h2 style="font-size:14px;margin-bottom:10px;">Add company</h2>
    <form method="post">
      <label>Name</label><input name="name" required>
      <label>Type</label><select name="type"><option value="client">Client</option><option value="vendor">Vendor</option></select>
      <label>Contact email</label><input name="contact_email" type="email">
      <label>Contact phone</label><input name="contact_phone">
      <label>Notes</label><input name="notes">
      <button type="submit" style="margin-top:10px;">Add</button>
    </form>
  </div>
  <table>
    <tr><th>Name</th><th>Type</th><th>Email</th><th>Phone</th><th>Notes</th></tr>
    <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= htmlspecialchars($r['name']) ?></td>
      <td><?= htmlspecialchars($r['type']) ?></td>
      <td><?= htmlspecialchars($r['contact_email']) ?></td>
      <td><?= htmlspecialchars($r['contact_phone']) ?></td>
      <td><?= htmlspecialchars($r['notes']) ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
</main>
</body></html>
