<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) { header('Location: admin_login.php'); exit; }
$conn = exaconnect_db();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn->prepare("INSERT INTO exaconnect_cms_pages (page_key, title, content) VALUES (?,?,?)
                    ON DUPLICATE KEY UPDATE title=VALUES(title), content=VALUES(content)")
         ->execute([trim($_POST['page_key']), trim($_POST['title']), $_POST['content']]);
    header('Location: admin_cms.php'); exit;
}
$rows = $conn->query("SELECT * FROM exaconnect_cms_pages ORDER BY page_key")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"/><title>CMS | ExaConnect</title><link rel="stylesheet" href="admin.css"></head>
<body>
<header><h1>ExaConnect Admin</h1><a class="signout" href="admin_logout.php">Sign out</a></header>
<?php include 'nav_include.php'; ?>
<main>
  <div class="card">
    <h2 style="font-size:14px;margin-bottom:10px;">Add / update a static page</h2>
    <form method="post">
      <label>Page key (e.g. faq, help)</label><input name="page_key" required>
      <label>Title</label><input name="title" required>
      <label>Content</label><textarea name="content" rows="6" required></textarea>
      <button type="submit" style="margin-top:10px;">Save page</button>
    </form>
  </div>
  <table>
    <tr><th>Key</th><th>Title</th><th>Updated</th></tr>
    <?php foreach ($rows as $r): ?>
    <tr><td><?= htmlspecialchars($r['page_key']) ?></td><td><?= htmlspecialchars($r['title']) ?></td><td><?= htmlspecialchars($r['updated_at']) ?></td></tr>
    <?php endforeach; ?>
  </table>
</main>
</body></html>
