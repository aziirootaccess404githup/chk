<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) {
    header('Location: admin_login.php');
    exit;
}
$conn = exaconnect_db();

$total    = $conn->query("SELECT COUNT(*) FROM exaconnect_panelists")->fetchColumn();
$pending  = $conn->query("SELECT COUNT(*) FROM exaconnect_panelists WHERE status='pending'")->fetchColumn();
$approved = $conn->query("SELECT COUNT(*) FROM exaconnect_panelists WHERE status='approved'")->fetchColumn();
$rejected = $conn->query("SELECT COUNT(*) FROM exaconnect_panelists WHERE status='rejected'")->fetchColumn();

$pendingRows = $conn->query("SELECT * FROM exaconnect_panelists WHERE status='pending' ORDER BY registered_at ASC LIMIT 50")->fetchAll(PDO::FETCH_ASSOC);

$redemptionRows = $conn->query("
    SELECT r.*, p.panelist_id AS pid, p.first_name, p.last_name
    FROM exaconnect_redemptions r
    JOIN exaconnect_panelists p ON p.id = r.panelist_id
    WHERE r.status = 'pending'
    ORDER BY r.requested_at ASC LIMIT 50
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<title>ExaConnect — Admin Dashboard</title>
<style>
  body{font-family:'DM Sans',sans-serif;background:#0a1628;color:#e8edf5;margin:0;}
  header{display:flex;justify-content:space-between;align-items:center;padding:18px 28px;border-bottom:1px solid rgba(255,255,255,.07);}
  header h1{font-size:18px;color:#e8c96a;font-weight:500;}
  main{padding:24px 28px;}
  .cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;margin-bottom:28px;}
  .card{background:#111e38;border:1px solid rgba(255,255,255,.07);border-radius:12px;padding:16px;}
  .card .num{font-size:26px;font-weight:600;}
  .card .lbl{font-size:12px;color:#8a9bb8;text-transform:uppercase;letter-spacing:.06em;margin-top:4px;}
  table{width:100%;border-collapse:collapse;background:#111e38;border:1px solid rgba(255,255,255,.07);border-radius:12px;overflow:hidden;}
  th,td{padding:10px 14px;text-align:left;font-size:13px;border-bottom:1px solid rgba(255,255,255,.05);}
  th{color:#8a9bb8;text-transform:uppercase;font-size:11px;letter-spacing:.06em;}
  button{padding:6px 14px;border-radius:6px;border:none;font-size:12px;cursor:pointer;margin-right:6px;}
  .approve{background:#2ecc71;color:#0a1628;}
  .reject{background:#e74c3c;color:#fff;}
  a.signout{color:#8a9bb8;font-size:13px;}
</style>
</head>
<body>
<header>
  <h1>ExaConnect — Panelist Admin</h1>
  <div>
    <span style="margin-right:16px;color:#8a9bb8;font-size:13px;">Signed in as <?= htmlspecialchars($_SESSION['exaconnect_admin_name']) ?></span>
    <a class="signout" href="admin_logout.php">Sign out</a>
  </div>
</header>
<main>
  <div class="cards">
    <div class="card"><div class="num"><?= (int)$total ?></div><div class="lbl">Total panelists</div></div>
    <div class="card"><div class="num"><?= (int)$pending ?></div><div class="lbl">Pending approval</div></div>
    <div class="card"><div class="num"><?= (int)$approved ?></div><div class="lbl">Approved</div></div>
    <div class="card"><div class="num"><?= (int)$rejected ?></div><div class="lbl">Rejected</div></div>
  </div>

  <h2 style="font-size:15px;margin-bottom:12px;">Pending approval</h2>
  <table>
    <tr><th>Panelist ID</th><th>Name</th><th>Email</th><th>Country</th><th>Registered</th><th>Action</th></tr>
    <?php if (!$pendingRows): ?>
      <tr><td colspan="6" style="color:#8a9bb8;">No pending applications.</td></tr>
    <?php endif; ?>
    <?php foreach ($pendingRows as $row): ?>
      <tr>
        <td><?= htmlspecialchars($row['panelist_id']) ?></td>
        <td><?= htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) ?></td>
        <td><?= htmlspecialchars($row['email']) ?></td>
        <td><?= htmlspecialchars($row['country']) ?></td>
        <td><?= htmlspecialchars($row['registered_at']) ?></td>
        <td>
          <button class="approve" onclick="review(<?= (int)$row['id'] ?>, 'approved')">Approve</button>
          <button class="reject" onclick="review(<?= (int)$row['id'] ?>, 'rejected')">Reject</button>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>

  <h2 style="font-size:15px;margin:28px 0 12px;">Reward redemption requests</h2>
  <table>
    <tr><th>Ref</th><th>Panelist</th><th>Points</th><th>Method</th><th>Details</th><th>Requested</th><th>Action</th></tr>
    <?php if (!$redemptionRows): ?>
      <tr><td colspan="7" style="color:#8a9bb8;">No pending redemption requests.</td></tr>
    <?php endif; ?>
    <?php foreach ($redemptionRows as $row): ?>
      <tr>
        <td><?= htmlspecialchars($row['redemption_ref']) ?></td>
        <td><?= htmlspecialchars($row['pid'] . ' — ' . $row['first_name'] . ' ' . $row['last_name']) ?></td>
        <td><?= (int)$row['points_requested'] ?></td>
        <td><?= htmlspecialchars($row['method']) ?></td>
        <td><?= htmlspecialchars($row['payout_details']) ?></td>
        <td><?= htmlspecialchars($row['requested_at']) ?></td>
        <td>
          <button class="approve" onclick="reviewRedemption(<?= (int)$row['id'] ?>, 'paid')">Send reward &amp; mark paid</button>
          <button class="reject" onclick="reviewRedemption(<?= (int)$row['id'] ?>, 'rejected')">Reject &amp; refund</button>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>

  <p style="margin-top:20px;"><a href="admin_credit_points.php" style="color:#8a9bb8;font-size:13px;">Manual points credit (testing tool) &rarr;</a></p>
</main>
<script>
function review(id, status) {
  fetch('admin_actions.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'review', id, status })
  }).then(() => location.reload());
}
function reviewRedemption(id, status) {
  fetch('admin_actions.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'review_redemption', id, status })
  })
  .then(r => r.json())
  .then(d => {
    if (d.success) { location.reload(); }
    else { alert(d.message || 'Something went wrong.'); }
  });
}
</script>
</body>
</html>
