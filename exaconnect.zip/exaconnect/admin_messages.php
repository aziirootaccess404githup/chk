<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) { header('Location: admin_login.php'); exit; }
$conn = exaconnect_db();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn->prepare("INSERT INTO exaconnect_messages (from_admin, to_admin, message) VALUES (?,?,?)")
         ->execute([$_SESSION['exaconnect_admin_name'], trim($_POST['to_admin']) ?: null, trim($_POST['message'])]);
    header('Location: admin_messages.php'); exit;
}
$rows = $conn->query("SELECT * FROM exaconnect_messages ORDER BY created_at DESC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"/><title>Messages | ExaConnect</title><link rel="stylesheet" href="admin.css"></head>
<body>
<header><h1>ExaConnect Admin</h1><a class="signout" href="admin_logout.php">Sign out</a></header>
<?php include 'nav_include.php'; ?>
<main>
  <div class="card">
    <h2 style="font-size:14px;margin-bottom:10px;">Send a message</h2>
    <form method="post">
      <label>To (leave blank to broadcast to all admins)</label><input name="to_admin">
      <label>Message</label><textarea name="message" rows="3" required></textarea>
      <button type="submit" style="margin-top:10px;">Send</button>
    </form>
  </div>
  <?php foreach ($rows as $r): ?>
    <div class="card">
      <p style="font-size:12px;color:#8a9bb8;"><?= htmlspecialchars($r['from_admin']) ?> &rarr; <?= htmlspecialchars($r['to_admin'] ?: 'Everyone') ?> · <?= htmlspecialchars($r['created_at']) ?></p>
      <p style="font-size:13px;margin-top:6px;"><?= nl2br(htmlspecialchars($r['message'])) ?></p>
    </div>
  <?php endforeach; ?>
</main>
</body></html>
