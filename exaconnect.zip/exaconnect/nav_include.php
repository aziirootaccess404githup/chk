<nav class="subnav">
  <a href="admin_dashboard.php">Dashboard</a>
  <a href="admin_queries.php">Queries</a>
  <a href="admin_profile_questions.php">Profile Questions</a>
  <a href="admin_categories.php">Categories</a>
  <a href="admin_tasks.php">Tasks</a>
  <a href="admin_bids.php">Bidding</a>
  <a href="admin_open_projects.php">Open Projects</a>
  <a href="admin_geo_regions.php">Geo Regions</a>
  <a href="admin_companies.php">Companies</a>
  <a href="admin_email_templates.php">Email Templates</a>
  <a href="admin_user_groups.php">User Groups</a>
  <a href="admin_messages.php">Messages</a>
  <a href="admin_cms.php">CMS</a>
  <a href="admin_accounts.php">Accounts</a>
  <a href="admin_commissions.php">Commissions</a>
</nav>
