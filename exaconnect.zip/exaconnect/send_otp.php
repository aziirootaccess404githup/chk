<?php
// send_otp.php
// Genuinely generates the OTP server-side, stores only its hash (never
// the raw code), and sends it via EmailJS's REST API called FROM THE
// SERVER using the Private Key — not the browser SDK. This is the key
// difference from the old flow: the raw OTP is never present anywhere
// in the browser or in any network response the client can see, so
// there's genuinely no way to "verify" without actually receiving and
// reading the real email.

header('Content-Type: application/json');
// Genuinely only exazonresearch.com (and its subdomains) can call this —
// not a wide-open '*', which would let any random website trigger OTP
// emails through this endpoint.
$allowedOrigin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (preg_match('/^https:\/\/([a-z0-9-]+\.)?exazonresearch\.com$/', $allowedOrigin)) {
    header("Access-Control-Allow-Origin: $allowedOrigin");
}
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once __DIR__ . '/config.php';

$input = json_decode(file_get_contents('php://input'), true);
$email = trim($input['email'] ?? '');
$name  = trim($input['name'] ?? '');

if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'A valid email is required.']);
    exit;
}

$conn = exaconnect_db();

// Basic rate-limit — genuinely at most 5 OTP requests per email per
// 15 minutes, so this endpoint can't be used to spam someone's inbox
// or brute-force-farm codes by requesting many in a row.
$rateCheck = $conn->prepare("SELECT COUNT(*) FROM exaconnect_otp_requests WHERE email = ? AND created_at > (NOW() - INTERVAL 15 MINUTE)");
$rateCheck->execute([$email]);
if ((int)$rateCheck->fetchColumn() >= 5) {
    http_response_code(429);
    echo json_encode(['success' => false, 'message' => 'Too many requests. Please wait a few minutes and try again.']);
    exit;
}

$otp = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
$otp_hash = password_hash($otp, PASSWORD_DEFAULT);
$expires_at = date('Y-m-d H:i:s', strtotime('+10 minutes'));

$conn->prepare("INSERT INTO exaconnect_otp_requests (email, otp_hash, expires_at) VALUES (?, ?, ?)")
     ->execute([$email, $otp_hash, $expires_at]);

// Send via EmailJS's REST API, server-side, using the Private Key (this
// is what makes it a genuinely authenticated server-to-server call
// rather than a browser-origin-checked one — the raw $otp only ever
// exists here and in the email itself).
$ch = curl_init('https://api.emailjs.com/api/v1.0/email/send');
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 10,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => json_encode([
        'service_id'  => EMAILJS_SERVICE_ID,
        'template_id' => EMAILJS_OTP_TEMPLATE_ID,
        'user_id'     => EMAILJS_PUBLIC_KEY,
        'accessToken' => EMAILJS_PRIVATE_KEY,
        'template_params' => [
            'to_email' => $email,
            'to_name'  => $name ?: 'there',
            'otp_code' => $otp,
        ],
    ]),
]);
$result = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200) {
    error_log("send_otp.php: EmailJS send failed for $email — HTTP $httpCode, response: " . substr((string)$result, 0, 300));
    http_response_code(502);
    echo json_encode(['success' => false, 'message' => 'Could not send verification email. Please try again.']);
    exit;
}

echo json_encode(['success' => true]);
