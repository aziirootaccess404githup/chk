<?php
session_start();
session_destroy();
header('Location: panelist_login.php');
exit;
