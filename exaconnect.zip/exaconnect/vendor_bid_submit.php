<?php
header('Content-Type: application/json');
require_once __DIR__ . '/config.php';
$input = json_decode(file_get_contents('php://input'), true);

$project_ref = trim($input['project_ref'] ?? '');
$vendor_name = trim($input['vendor_name'] ?? '');
$bid_rate = (float)($input['bid_rate'] ?? 0);
$quota_offered = (int)($input['quota_offered'] ?? 0);
$notes = trim($input['notes'] ?? '');

if (!$project_ref || !$vendor_name || $bid_rate <= 0 || $quota_offered <= 0) {
    echo json_encode(['success' => false, 'message' => 'Please fill in all required fields.']);
    exit;
}

$conn = exaconnect_db();
$conn->prepare("INSERT INTO exaconnect_vendor_bids (project_ref, vendor_name, bid_rate, quota_offered, notes) VALUES (?,?,?,?,?)")
     ->execute([$project_ref, $vendor_name, $bid_rate, $quota_offered, $notes]);

echo json_encode(['success' => true]);
