<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_panelist_id'])) {
    header('Location: panelist_login.php');
    exit;
}
$conn = exaconnect_db();
$stmt = $conn->prepare("SELECT * FROM exaconnect_panelists WHERE id = ? LIMIT 1");
$stmt->execute([$_SESSION['exaconnect_panelist_id']]);
$panelist = $stmt->fetch(PDO::FETCH_ASSOC);

$openProjects = [];
if ($panelist['status'] === 'approved') {
    $openProjects = $conn->query("SELECT * FROM exaconnect_open_projects WHERE is_open = 1 ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
}

$statusLabel = ucfirst($panelist['status']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<title>My Dashboard | ExaConnect</title>
<style>
  body{font-family:'DM Sans',sans-serif;background:#0a1628;color:#e8edf5;margin:0;}
  header{padding:18px 28px;border-bottom:1px solid rgba(255,255,255,.07);display:flex;justify-content:space-between;align-items:center;}
  header h1{font-size:17px;color:#e8c96a;font-weight:500;}
  main{padding:28px;max-width:640px;margin:0 auto;}
  .card{background:#111e38;border:1px solid rgba(255,255,255,.07);border-radius:12px;padding:20px;margin-bottom:16px;}
  .status{display:inline-block;padding:4px 12px;border-radius:999px;font-size:12px;text-transform:uppercase;letter-spacing:.06em;}
  .status.pending{background:rgba(201,168,76,.15);color:#e8c96a;}
  .status.approved{background:rgba(46,204,113,.15);color:#2ecc71;}
  .status.rejected{background:rgba(231,76,60,.15);color:#e74c3c;}
  .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;}
  .stat .num{font-size:22px;font-weight:600;}
  .stat .lbl{font-size:11px;color:#8a9bb8;text-transform:uppercase;margin-top:4px;}
  a.signout{color:#8a9bb8;font-size:13px;}
</style>
</head>
<body>
<header>
  <h1>Welcome, <?= htmlspecialchars($panelist['first_name']) ?></h1>
  <a class="signout" href="panelist_logout.php">Sign out</a>
</header>
<nav style="padding:10px 28px;border-bottom:1px solid rgba(255,255,255,.07);">
  <a href="panelist_queries.php" style="color:#8a9bb8;font-size:13px;text-decoration:none;">My Queries &rarr;</a>
</nav>
<main>
  <div class="card">
    <p style="font-size:12px;color:#8a9bb8;margin-bottom:6px;">Panelist ID</p>
    <p style="font-size:18px;font-family:monospace;"><?= htmlspecialchars($panelist['panelist_id']) ?></p>
    <p style="margin-top:12px;">
      Status: <span class="status <?= htmlspecialchars($panelist['status']) ?>"><?= htmlspecialchars($statusLabel) ?></span>
    </p>
  </div>

  <div class="card grid">
    <div class="stat"><div class="num"><?= count($openProjects) ?></div><div class="lbl">Surveys available</div></div>
    <div class="stat"><div class="num">0</div><div class="lbl">Completed</div></div>
    <div class="stat"><div class="num"><?= (int)$panelist['points_balance'] ?></div><div class="lbl">Points balance</div></div>
  </div>

  <?php if ($panelist['status'] === 'approved' && $openProjects): ?>
  <div class="card">
    <p style="font-size:13px;color:#8a9bb8;margin-bottom:10px;">Available surveys</p>
    <?php foreach ($openProjects as $proj): ?>
      <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-top:1px solid rgba(255,255,255,.06);">
        <div>
          <div style="font-size:14px;"><?= htmlspecialchars($proj['title']) ?></div>
          <div style="font-size:11px;color:#8a9bb8;"><?= (int)$proj['points_value'] ?> points on completion</div>
        </div>
        <a href="<?= htmlspecialchars(build_survey_link($proj['project_ref'], $panelist['panelist_id'])) ?>" target="_blank"
           style="padding:8px 16px;background:linear-gradient(135deg,#c9a84c,#e8c96a);border-radius:6px;color:#0a1628;font-weight:500;font-size:12px;text-decoration:none;">
           Take survey
        </a>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <?php if ($panelist['status'] === 'approved'): ?>
  <div class="card">
    <p style="font-size:13px;color:#8a9bb8;margin-bottom:10px;">Redeem points</p>
    <div id="redeemForm">
      <select id="redeem_method" style="width:100%;padding:9px;background:#0f2040;border:1px solid rgba(255,255,255,.07);border-radius:8px;color:#e8edf5;margin-bottom:8px;">
        <option value="bank_transfer">Bank transfer</option>
        <option value="gift_card">Gift card</option>
      </select>
      <input type="number" id="redeem_points" placeholder="Points to redeem" style="width:100%;padding:9px;background:#0f2040;border:1px solid rgba(255,255,255,.07);border-radius:8px;color:#e8edf5;margin-bottom:8px;box-sizing:border-box;">
      <input type="text" id="redeem_details" placeholder="Bank details or gift card email" style="width:100%;padding:9px;background:#0f2040;border:1px solid rgba(255,255,255,.07);border-radius:8px;color:#e8edf5;margin-bottom:8px;box-sizing:border-box;">
      <button onclick="submitRedemption()" style="padding:10px 18px;background:linear-gradient(135deg,#c9a84c,#e8c96a);border:none;border-radius:8px;color:#0a1628;font-weight:500;cursor:pointer;">Request redemption</button>
      <div id="redeemMsg" style="font-size:13px;margin-top:8px;"></div>
    </div>
  </div>
  <?php endif; ?>

  <?php if ($panelist['status'] === 'pending'): ?>
    <div class="card" style="font-size:13px;color:#8a9bb8;">
      Your application is under review. You'll receive an email once it's approved, and survey invitations will start appearing here.
    </div>
  <?php endif; ?>

  <?php if ($panelist['status'] === 'approved' && !$openProjects): ?>
    <div class="card" style="font-size:13px;color:#8a9bb8;">
      No survey invitations right now. Check back soon, or ask the team if you're expecting one.
    </div>
  <?php endif; ?>
</main>
<script>
function submitRedemption() {
  const points = parseInt(document.getElementById('redeem_points').value, 10);
  const method = document.getElementById('redeem_method').value;
  const details = document.getElementById('redeem_details').value.trim();
  const msgEl = document.getElementById('redeemMsg');

  if (!points || points <= 0 || !details) {
    msgEl.textContent = 'Please enter points and payout details.';
    msgEl.style.color = '#e74c3c';
    return;
  }

  fetch('redemption_submit.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ points, method, details })
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      msgEl.textContent = 'Request submitted: ' + data.redemption_ref;
      msgEl.style.color = '#2ecc71';
      setTimeout(() => location.reload(), 1200);
    } else {
      msgEl.textContent = data.message || 'Something went wrong.';
      msgEl.style.color = '#e74c3c';
    }
  });
}
</script>
</body>
</html>
