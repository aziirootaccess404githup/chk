<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) { header('Location: admin_login.php'); exit; }
$conn = exaconnect_db();
$rows = $conn->query("
    SELECT q.*, p.panelist_id AS pid, p.first_name, p.last_name
    FROM exaconnect_queries q JOIN exaconnect_panelists p ON p.id = q.panelist_id
    ORDER BY (q.status='open') DESC, q.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"/><title>Queries | ExaConnect</title><link rel="stylesheet" href="admin.css"></head>
<body>
<header><h1>ExaConnect Admin</h1><a class="signout" href="admin_logout.php">Sign out</a></header>
<?php include 'nav_include.php'; ?>
<main>
  <h2 style="font-size:15px;margin-bottom:12px;">Panelist queries</h2>
  <?php foreach ($rows as $r): ?>
    <div class="card">
      <div style="display:flex;justify-content:space-between;">
        <strong><?= htmlspecialchars($r['subject']) ?></strong>
        <span class="badge <?= htmlspecialchars($r['status']) ?>"><?= htmlspecialchars($r['status']) ?></span>
      </div>
      <p style="font-size:12px;color:#8a9bb8;margin:6px 0;"><?= htmlspecialchars($r['pid'] . ' — ' . $r['first_name'] . ' ' . $r['last_name']) ?> · <?= htmlspecialchars($r['created_at']) ?></p>
      <p style="font-size:13px;margin-bottom:10px;"><?= nl2br(htmlspecialchars($r['message'])) ?></p>
      <?php if ($r['admin_reply']): ?>
        <p style="font-size:13px;color:#e8c96a;background:#0f2040;padding:10px;border-radius:8px;"><?= nl2br(htmlspecialchars($r['admin_reply'])) ?></p>
      <?php else: ?>
        <textarea rows="2" id="reply<?= $r['id'] ?>" placeholder="Type a reply..."></textarea>
        <button onclick="reply(<?= $r['id'] ?>)" style="margin-top:8px;">Send reply</button>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
  <?php if (!$rows): ?><p style="color:#8a9bb8;">No queries yet.</p><?php endif; ?>
</main>
<script>
function reply(id) {
  const text = document.getElementById('reply' + id).value.trim();
  if (!text) return;
  fetch('query_reply.php', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ id, reply: text })
  }).then(() => location.reload());
}
</script>
</body></html>
