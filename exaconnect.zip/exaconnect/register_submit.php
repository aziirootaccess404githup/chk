<?php
header('Content-Type: application/json');
$allowedOrigin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (preg_match('/^https:\/\/([a-z0-9-]+\.)?exazonresearch\.com$/', $allowedOrigin)) {
    header("Access-Control-Allow-Origin: $allowedOrigin");
}
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once __DIR__ . '/config.php';

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
    exit;
}

$first_name = trim($input['first_name'] ?? '');
$last_name  = trim($input['last_name'] ?? '');
$email      = trim($input['email'] ?? '');
$phone      = trim($input['phone'] ?? '');
$dob        = trim($input['dob'] ?? '') ?: null;
$gender     = trim($input['gender'] ?? '');
$country    = trim($input['country'] ?? '');
$state      = trim($input['state'] ?? '');
$city       = trim($input['city'] ?? '');
$employment_status = trim($input['employment'] ?? '');
$income_range       = trim($input['income'] ?? '');
$education_level    = trim($input['education'] ?? '');
$industry           = trim($input['industry'] ?? '');
$interests          = trim($input['interests'] ?? '');
$referral_source    = trim($input['source'] ?? '');
$token              = trim($input['otp_token'] ?? '');
$ip                 = $_SERVER['REMOTE_ADDR'] ?? '';

// Genuinely verifies the signed token from verify_otp.php — replaces
// the old, client-trusted "otp_verified: true" flag. Checks: the HMAC
// signature genuinely matches (so it was issued by this server, not
// forged), the email inside it matches what's being submitted (so a
// token issued for one email can't register a different one), and it's
// genuinely recent (issued within the last 30 minutes).
function verify_otp_token($token, $expectedEmail) {
    $decoded = base64_decode($token, true);
    if (!$decoded) return false;
    $parts = explode('|', $decoded);
    if (count($parts) !== 3) return false;
    [$tokenEmail, $issuedAt, $signature] = $parts;
    if ($tokenEmail !== $expectedEmail) return false;
    if ((time() - (int)$issuedAt) > 1800) return false; // 30 min expiry
    $expectedSig = hash_hmac('sha256', $tokenEmail . '|' . $issuedAt, OTP_TOKEN_SECRET);
    return hash_equals($expectedSig, $signature);
}

$otp_verified = $token && verify_otp_token($token, $email);

if (!$first_name || !$last_name || !filter_var($email, FILTER_VALIDATE_EMAIL) || !$otp_verified) {
    echo json_encode(['success' => false, 'message' => 'Please complete all required fields and verify your email.']);
    exit;
}

try {
    $conn = exaconnect_db();

    // Prevent duplicate registrations by email
    $chk = $conn->prepare("SELECT id FROM exaconnect_panelists WHERE email = ? LIMIT 1");
    $chk->execute([$email]);
    if ($chk->fetch()) {
        echo json_encode(['success' => false, 'message' => 'An account with this email already exists.']);
        exit;
    }

    $panelist_id = generate_panelist_id($conn);

    $stmt = $conn->prepare("INSERT INTO exaconnect_panelists
        (panelist_id, first_name, last_name, email, phone, dob, gender, country, state_region, city,
         employment_status, income_range, education_level, industry,
         interests, referral_source, otp_verified, status, ip_address)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'pending', ?)");

    $stmt->execute([
        $panelist_id, $first_name, $last_name, $email, $phone, $dob, $gender, $country, $state, $city,
        $employment_status, $income_range, $education_level, $industry,
        $interests, $referral_source, $ip
    ]);

    // Genuinely notifies the admin of a new registration — moved
    // server-side (from the website page's own client-side EmailJS
    // call) so it reliably fires regardless of the visitor's own
    // browser/network conditions, and doesn't depend on a client-side
    // script that a visitor's ad-blocker or privacy-extension might
    // silently block.
    $ch = curl_init('https://api.emailjs.com/api/v1.0/email/send');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 8,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode([
            'service_id'  => EMAILJS_SERVICE_ID,
            'template_id' => EMAILJS_CONTACT_TEMPLATE_ID,
            'user_id'     => EMAILJS_PUBLIC_KEY,
            'accessToken' => EMAILJS_PRIVATE_KEY,
            'template_params' => [
                'to_email' => 'shavaz@exazonresearch.com',
                'panelist_id' => $panelist_id,
                'first_name' => $first_name, 'last_name' => $last_name,
                'email' => $email, 'phone' => $phone, 'country' => $country, 'city' => $city,
                'dob' => $dob, 'gender' => $gender,
                'employment' => $employment_status, 'income' => $income_range,
                'education' => $education_level, 'industry' => $industry,
                'interests' => $interests, 'source' => $referral_source,
                'registered_at' => date('Y-m-d H:i:s'),
            ],
        ]),
    ]);
    curl_exec($ch); // genuinely fire-and-forget — a failed notification-email should never block a successful registration
    curl_close($ch);

    echo json_encode(['success' => true, 'panelist_id' => $panelist_id]);

} catch (Exception $e) {
    // Do not leak internal error details to the client.
    error_log("register_submit.php error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Registration failed. Please try again later.']);
}
