<?php
// api_open_projects.php — Insights Exchange stub.
// Vendors can poll this endpoint to see currently open projects instead of
// checking manually. A future version can push notifications instead of
// requiring polling, and can sync from ExaVerify automatically once the
// read-only API connection (see blueprint, open decisions) is built.
header('Content-Type: application/json');
require_once __DIR__ . '/config.php';

$conn = exaconnect_db();
$rows = $conn->query("SELECT project_ref, title, target_criteria, quota_needed FROM exaconnect_open_projects WHERE is_open = 1 ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['success' => true, 'open_projects' => $rows]);
