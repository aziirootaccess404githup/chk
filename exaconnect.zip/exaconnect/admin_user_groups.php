<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) { header('Location: admin_login.php'); exit; }
$conn = exaconnect_db();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn->prepare("INSERT INTO exaconnect_user_groups (name, permissions) VALUES (?,?)")
         ->execute([trim($_POST['name']), trim($_POST['permissions'])]);
    header('Location: admin_user_groups.php'); exit;
}
$groups = $conn->query("SELECT * FROM exaconnect_user_groups ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$admins = $conn->query("SELECT id, username, display_name FROM exaconnect_admins ORDER BY username")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"/><title>User Groups | ExaConnect</title><link rel="stylesheet" href="admin.css"></head>
<body>
<header><h1>ExaConnect Admin</h1><a class="signout" href="admin_logout.php">Sign out</a></header>
<?php include 'nav_include.php'; ?>
<main>
  <div class="card">
    <h2 style="font-size:14px;margin-bottom:10px;">Add a group (e.g. Admin, Manager, Viewer)</h2>
    <form method="post">
      <label>Name</label><input name="name" required>
      <label>Permissions (comma-separated keys)</label><input name="permissions" placeholder="approve_panelists, view_reports">
      <button type="submit" style="margin-top:10px;">Add group</button>
    </form>
  </div>
  <table>
    <tr><th>Group</th><th>Permissions</th></tr>
    <?php foreach ($groups as $g): ?>
    <tr><td><?= htmlspecialchars($g['name']) ?></td><td><?= htmlspecialchars($g['permissions']) ?></td></tr>
    <?php endforeach; ?>
  </table>
  <p style="font-size:12px;color:#8a9bb8;margin:16px 0 6px;">Team members (assign a group manually in the database for now — a dropdown assignment UI is a good next increment):</p>
  <table>
    <tr><th>Username</th><th>Display name</th></tr>
    <?php foreach ($admins as $a): ?>
    <tr><td><?= htmlspecialchars($a['username']) ?></td><td><?= htmlspecialchars($a['display_name']) ?></td></tr>
    <?php endforeach; ?>
  </table>
</main>
</body></html>
