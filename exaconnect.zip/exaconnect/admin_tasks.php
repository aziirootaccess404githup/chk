<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) { header('Location: admin_login.php'); exit; }
$conn = exaconnect_db();

function ageHours($ts) { return round((time() - strtotime($ts)) / 3600, 1); }

$pendingApprovals = $conn->query("SELECT panelist_id, first_name, last_name, registered_at FROM exaconnect_panelists WHERE status='pending' ORDER BY registered_at ASC")->fetchAll(PDO::FETCH_ASSOC);
$pendingRedemptions = $conn->query("SELECT redemption_ref, requested_at FROM exaconnect_redemptions WHERE status='pending' ORDER BY requested_at ASC")->fetchAll(PDO::FETCH_ASSOC);
$openQueries = $conn->query("SELECT id, subject, created_at FROM exaconnect_queries WHERE status='open' ORDER BY created_at ASC")->fetchAll(PDO::FETCH_ASSOC);
$pendingBids = $conn->query("SELECT project_ref, vendor_name, submitted_at FROM exaconnect_vendor_bids WHERE status='submitted' ORDER BY submitted_at ASC")->fetchAll(PDO::FETCH_ASSOC);

$OVERDUE_HOURS = 48;
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"/><title>Task Status | ExaConnect</title><link rel="stylesheet" href="admin.css"></head>
<body>
<header><h1>ExaConnect Admin</h1><a class="signout" href="admin_logout.php">Sign out</a></header>
<?php include 'nav_include.php'; ?>
<main>
  <p style="color:#8a9bb8;font-size:13px;margin-bottom:16px;">Anything older than <?= $OVERDUE_HOURS ?> hours is flagged overdue.</p>

  <?php
  function taskTable($title, $rows, $labelFn, $tsField, $overdueHours) {
      echo "<h2 style='font-size:14px;margin:18px 0 8px;'>{$title} (" . count($rows) . ")</h2>";
      if (!$rows) { echo "<p style='color:#8a9bb8;font-size:13px;'>Nothing pending.</p>"; return; }
      echo "<table><tr><th>Item</th><th>Age</th><th>Status</th></tr>";
      foreach ($rows as $r) {
          $hrs = round((time() - strtotime($r[$tsField])) / 3600, 1);
          $flag = $hrs > $overdueHours ? "<span class='badge rejected'>Overdue</span>" : "<span class='badge open'>On time</span>";
          echo "<tr><td>" . htmlspecialchars($labelFn($r)) . "</td><td>{$hrs}h</td><td>{$flag}</td></tr>";
      }
      echo "</table>";
  }
  taskTable('Pending panelist approvals', $pendingApprovals, fn($r) => $r['panelist_id'] . ' — ' . $r['first_name'] . ' ' . $r['last_name'], 'registered_at', $OVERDUE_HOURS);
  taskTable('Pending redemption requests', $pendingRedemptions, fn($r) => $r['redemption_ref'], 'requested_at', $OVERDUE_HOURS);
  taskTable('Open panelist queries', $openQueries, fn($r) => $r['subject'], 'created_at', 24);
  taskTable('Pending vendor bids', $pendingBids, fn($r) => $r['project_ref'] . ' — ' . $r['vendor_name'], 'submitted_at', $OVERDUE_HOURS);
  ?>
</main>
</body></html>
