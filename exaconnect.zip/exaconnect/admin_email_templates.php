<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) { header('Location: admin_login.php'); exit; }
$conn = exaconnect_db();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn->prepare("INSERT INTO exaconnect_email_templates (template_key, subject, body) VALUES (?,?,?)
                    ON DUPLICATE KEY UPDATE subject=VALUES(subject), body=VALUES(body)")
         ->execute([trim($_POST['template_key']), trim($_POST['subject']), $_POST['body']]);
    header('Location: admin_email_templates.php'); exit;
}
$rows = $conn->query("SELECT * FROM exaconnect_email_templates ORDER BY template_key")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"/><title>Email Templates | ExaConnect</title><link rel="stylesheet" href="admin.css"></head>
<body>
<header><h1>ExaConnect Admin</h1><a class="signout" href="admin_logout.php">Sign out</a></header>
<?php include 'nav_include.php'; ?>
<main>
  <div class="card">
    <h2 style="font-size:14px;margin-bottom:10px;">Add / update template</h2>
    <p style="font-size:12px;color:#8a9bb8;margin-bottom:8px;">Use <code>{{first_name}}</code> and <code>{{panelist_id}}</code> as placeholders in the body.</p>
    <form method="post">
      <label>Key (e.g. otp, approval, invitation)</label><input name="template_key" required>
      <label>Subject</label><input name="subject" required>
      <label>Body</label><textarea name="body" rows="5" required></textarea>
      <button type="submit" style="margin-top:10px;">Save template</button>
    </form>
  </div>
  <table>
    <tr><th>Key</th><th>Subject</th><th>Updated</th></tr>
    <?php foreach ($rows as $r): ?>
    <tr><td><?= htmlspecialchars($r['template_key']) ?></td><td><?= htmlspecialchars($r['subject']) ?></td><td><?= htmlspecialchars($r['updated_at']) ?></td></tr>
    <?php endforeach; ?>
  </table>
</main>
</body></html>
