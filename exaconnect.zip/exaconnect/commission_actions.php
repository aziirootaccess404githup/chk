<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) { http_response_code(403); echo json_encode(['success'=>false]); exit; }
$input = json_decode(file_get_contents('php://input'), true);
$id = (int)($input['id'] ?? 0);
if (!$id) { echo json_encode(['success'=>false]); exit; }
$conn = exaconnect_db();
$conn->prepare("UPDATE exaconnect_commissions SET status='paid', paid_at=NOW() WHERE id=?")->execute([$id]);
echo json_encode(['success'=>true]);
