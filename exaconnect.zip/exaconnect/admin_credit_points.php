<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) {
    header('Location: admin_login.php');
    exit;
}
$conn = exaconnect_db();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $panelist_id = trim($_POST['panelist_id'] ?? '');
    $points = (int)($_POST['points'] ?? 0);
    $reason = trim($_POST['reason'] ?? 'Manual credit');

    $stmt = $conn->prepare("SELECT id FROM exaconnect_panelists WHERE panelist_id = ? LIMIT 1");
    $stmt->execute([$panelist_id]);
    $panelist = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($panelist && $points !== 0) {
        $conn->beginTransaction();
        $conn->prepare("UPDATE exaconnect_panelists SET points_balance = points_balance + ? WHERE id = ?")
             ->execute([$points, $panelist['id']]);
        $conn->prepare("INSERT INTO exaconnect_point_ledger (panelist_id, points_change, reason, source) VALUES (?, ?, ?, 'manual')")
             ->execute([$panelist['id'], $points, $reason]);
        $conn->commit();
        $message = "Credited {$points} points to {$panelist_id}.";
    } else {
        $message = "Panelist not found or points value invalid.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"/><title>Manual points credit | ExaConnect Admin</title>
<style>
  body{font-family:'DM Sans',sans-serif;background:#0a1628;color:#e8edf5;padding:32px;}
  form{background:#111e38;border:1px solid rgba(255,255,255,.07);border-radius:12px;padding:24px;max-width:400px;}
  label{display:block;font-size:13px;color:#8a9bb8;margin:12px 0 6px;}
  input{width:100%;padding:9px;background:#0f2040;border:1px solid rgba(255,255,255,.07);border-radius:8px;color:#e8edf5;box-sizing:border-box;}
  button{margin-top:16px;padding:10px 20px;background:linear-gradient(135deg,#c9a84c,#e8c96a);border:none;border-radius:8px;color:#0a1628;font-weight:500;cursor:pointer;}
  .msg{margin-top:12px;font-size:13px;color:#e8c96a;}
  a{color:#8a9bb8;font-size:13px;}
</style>
</head>
<body>
<p><a href="admin_dashboard.php">&larr; Back to dashboard</a></p>
<h2 style="color:#e8c96a;font-size:16px;margin:16px 0;">Manual points credit (for testing — the real path is the ExaVerify webhook)</h2>
<form method="post">
  <label>Panelist ID</label><input type="text" name="panelist_id" placeholder="EXZ-2026-UN0123" required>
  <label>Points (use negative to deduct)</label><input type="number" name="points" required>
  <label>Reason</label><input type="text" name="reason" placeholder="e.g. Test credit">
  <button type="submit">Credit points</button>
  <?php if ($message): ?><div class="msg"><?= htmlspecialchars($message) ?></div><?php endif; ?>
</form>
</body>
</html>
