<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) { header('Location: admin_login.php'); exit; }
$conn = exaconnect_db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn->prepare("INSERT INTO exaconnect_categories (name, description) VALUES (?,?)")
         ->execute([trim($_POST['name']), trim($_POST['description'])]);
    header('Location: admin_categories.php'); exit;
}
$rows = $conn->query("SELECT * FROM exaconnect_categories ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"/><title>Categories | ExaConnect</title><link rel="stylesheet" href="admin.css"></head>
<body>
<header><h1>ExaConnect Admin</h1><a class="signout" href="admin_logout.php">Sign out</a></header>
<?php include 'nav_include.php'; ?>
<main>
  <div class="card">
    <h2 style="font-size:14px;margin-bottom:10px;">Add interest category</h2>
    <form method="post">
      <label>Name</label><input name="name" required>
      <label>Description</label><input name="description">
      <button type="submit" style="margin-top:10px;">Add category</button>
    </form>
  </div>
  <table>
    <tr><th>Name</th><th>Description</th><th>Active</th><th>Action</th></tr>
    <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= htmlspecialchars($r['name']) ?></td>
      <td><?= htmlspecialchars($r['description']) ?></td>
      <td><?= $r['is_active'] ? 'Yes' : 'No' ?></td>
      <td><button class="ghost" onclick="toggleCat(<?= $r['id'] ?>)">Toggle</button></td>
    </tr>
    <?php endforeach; ?>
  </table>
</main>
<script>
function toggleCat(id){fetch('category_actions.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'toggle',id})}).then(()=>location.reload());}
</script>
</body></html>
