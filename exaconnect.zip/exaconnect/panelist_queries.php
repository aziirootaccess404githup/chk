<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_panelist_id'])) { header('Location: panelist_login.php'); exit; }
$conn = exaconnect_db();
$myQueries = $conn->prepare("SELECT * FROM exaconnect_queries WHERE panelist_id=? ORDER BY created_at DESC");
$myQueries->execute([$_SESSION['exaconnect_panelist_id']]);
$rows = $myQueries->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"/><title>My Queries | ExaConnect</title><link rel="stylesheet" href="admin.css"></head>
<body>
<header><h1>My Queries</h1><a class="signout" href="panelist_portal.php">&larr; Back to dashboard</a></header>
<main>
  <div class="card">
    <label>Subject</label><input type="text" id="q_subject">
    <label>Message</label><textarea rows="3" id="q_message"></textarea>
    <button onclick="submitQuery()" style="margin-top:10px;">Submit query</button>
    <div class="msg" id="q_msg"></div>
  </div>
  <?php foreach ($rows as $r): ?>
    <div class="card">
      <div style="display:flex;justify-content:space-between;">
        <strong><?= htmlspecialchars($r['subject']) ?></strong>
        <span class="badge <?= htmlspecialchars($r['status']) ?>"><?= htmlspecialchars($r['status']) ?></span>
      </div>
      <p style="font-size:13px;margin:8px 0;color:#8a9bb8;"><?= nl2br(htmlspecialchars($r['message'])) ?></p>
      <?php if ($r['admin_reply']): ?>
        <p style="font-size:13px;background:#0f2040;padding:10px;border-radius:8px;color:#e8c96a;"><?= nl2br(htmlspecialchars($r['admin_reply'])) ?></p>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</main>
<script>
function submitQuery() {
  const subject = document.getElementById('q_subject').value.trim();
  const message = document.getElementById('q_message').value.trim();
  const msgEl = document.getElementById('q_msg');
  if (!subject || !message) { msgEl.textContent='Please fill in both fields.'; msgEl.className='msg err'; return; }
  fetch('query_submit.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({subject, message}) })
    .then(r => r.json()).then(d => {
      if (d.success) { msgEl.textContent='Query submitted.'; msgEl.className='msg ok'; setTimeout(()=>location.reload(), 800); }
      else { msgEl.textContent=d.message||'Error'; msgEl.className='msg err'; }
    });
}
</script>
</body></html>
