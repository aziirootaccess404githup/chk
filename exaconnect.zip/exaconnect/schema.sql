-- ExaConnect — Phase 1 schema
-- Standalone database, separate from ExaVerify's own tables.
-- Column names on exaconnect_panelists intentionally mirror the existing
-- exazon_panelists table (panelist_id, email, first_name, last_name, country,
-- status, registered_at) so the real approved/pending records already
-- collected on exazonresearch.com can be migrated in with a straight
-- INSERT ... SELECT once this schema is live.

CREATE TABLE IF NOT EXISTS exaconnect_panelists (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  panelist_id VARCHAR(20) NOT NULL UNIQUE,      -- e.g. EXZ-2026-UN0123
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  phone VARCHAR(30) DEFAULT NULL,
  country VARCHAR(100) DEFAULT NULL,
  state_region VARCHAR(100) DEFAULT NULL,
  city VARCHAR(100) DEFAULT NULL,
  employment_status VARCHAR(100) DEFAULT NULL,
  income_range VARCHAR(100) DEFAULT NULL,
  education_level VARCHAR(100) DEFAULT NULL,
  industry VARCHAR(100) DEFAULT NULL,
  interests TEXT DEFAULT NULL,                  -- comma-separated for phase 1; normalised in Phase 3 (panelist_categories)
  referral_source VARCHAR(100) DEFAULT NULL,
  otp_verified TINYINT(1) NOT NULL DEFAULT 0,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  admin_note VARCHAR(255) DEFAULT NULL,
  registered_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reviewed_at DATETIME DEFAULT NULL,
  reviewed_by VARCHAR(100) DEFAULT NULL,
  INDEX idx_status (status),
  INDEX idx_registered_at (registered_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exaconnect_admins (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  display_name VARCHAR(100) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed one admin account. Replace the hash below by generating your own with:
--   php -r "echo password_hash('yourpassword', PASSWORD_DEFAULT);"
-- The placeholder hash corresponds to the password "changeme" — change it
-- immediately after first login.
INSERT INTO exaconnect_admins (username, password_hash, display_name)
VALUES ('admin', '$2y$10$examplehashreplacewithrealone000000000000000000000000', 'Azii')
ON DUPLICATE KEY UPDATE username = username;
