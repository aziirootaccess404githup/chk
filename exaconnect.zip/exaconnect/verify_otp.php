<?php
// verify_otp.php
// Checks the user-entered code against the hash stored server-side by
// send_otp.php. On success, sets a session flag that register_submit.php
// checks — this is what genuinely replaces the old, client-side-only
// "otp_verified: true" flag that anyone could fake by calling
// register_submit.php directly.

// verify_otp.php
// Checks the user-entered code against the hash stored server-side by
// send_otp.php. On success, returns a signed, time-limited token that
// register_submit.php verifies — this is genuinely used instead of a
// PHP session specifically because this page is meant to be called
// cross-domain (from exazonresearch.com, while this backend lives on
// exaconnect.exazonresearch.com), and cross-domain session-cookies are
// genuinely unreliable — modern browsers frequently block third-party
// cookies outright, which would silently break email-verification for
// some visitors. A signed token sidesteps that entirely.

header('Content-Type: application/json');
$allowedOrigin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (preg_match('/^https:\/\/([a-z0-9-]+\.)?exazonresearch\.com$/', $allowedOrigin)) {
    header("Access-Control-Allow-Origin: $allowedOrigin");
}
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once __DIR__ . '/config.php';

$input = json_decode(file_get_contents('php://input'), true);
$email = trim($input['email'] ?? '');
$code  = trim($input['otp'] ?? '');

if (!$email || !$code) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Email and code are required.']);
    exit;
}

$conn = exaconnect_db();

$row = $conn->prepare("SELECT id, otp_hash, attempts, expires_at FROM exaconnect_otp_requests WHERE email = ? AND verified = 0 ORDER BY id DESC LIMIT 1");
$row->execute([$email]);
$otpRow = $row->fetch(PDO::FETCH_ASSOC);

if (!$otpRow) {
    echo json_encode(['success' => false, 'message' => 'No pending code for this email — please request a new one.']);
    exit;
}

// Genuinely at most 5 guesses against any one sent code, so a 6-digit
// code can't just be brute-forced by trying values one after another.
if ($otpRow['attempts'] >= 5) {
    echo json_encode(['success' => false, 'message' => 'Too many incorrect attempts. Please request a new code.']);
    exit;
}

if (strtotime($otpRow['expires_at']) < time()) {
    echo json_encode(['success' => false, 'message' => 'This code has expired. Please request a new one.']);
    exit;
}

if (!password_verify($code, $otpRow['otp_hash'])) {
    $conn->prepare("UPDATE exaconnect_otp_requests SET attempts = attempts + 1 WHERE id = ?")->execute([$otpRow['id']]);
    echo json_encode(['success' => false, 'message' => 'Incorrect code. Please try again.']);
    exit;
}

$conn->prepare("UPDATE exaconnect_otp_requests SET verified = 1 WHERE id = ?")->execute([$otpRow['id']]);

// A signed token: email|timestamp|hmac — register_submit.php checks the
// hmac genuinely matches (proving it was issued by this server, not
// forged) and that the timestamp is recent enough. This is what
// genuinely replaces the client-trusted "otp_verified: true" flag from
// before — it cannot be produced without a real code-match just above.
$issuedAt = time();
$payload = $email . '|' . $issuedAt;
$signature = hash_hmac('sha256', $payload, OTP_TOKEN_SECRET);
$token = base64_encode($payload . '|' . $signature);

echo json_encode(['success' => true, 'token' => $token]);
