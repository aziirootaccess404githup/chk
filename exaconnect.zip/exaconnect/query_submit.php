<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_panelist_id'])) { http_response_code(403); echo json_encode(['success'=>false]); exit; }

$input = json_decode(file_get_contents('php://input'), true);
$subject = trim($input['subject'] ?? '');
$message = trim($input['message'] ?? '');
if (!$subject || !$message) { echo json_encode(['success'=>false,'message'=>'Please fill in both fields.']); exit; }

$conn = exaconnect_db();
$conn->prepare("INSERT INTO exaconnect_queries (panelist_id, subject, message) VALUES (?, ?, ?)")
     ->execute([$_SESSION['exaconnect_panelist_id'], $subject, $message]);
echo json_encode(['success'=>true]);
