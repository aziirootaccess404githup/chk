<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) { header('Location: admin_login.php'); exit; }
$conn = exaconnect_db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn->prepare("INSERT INTO exaconnect_open_projects (project_ref, title, target_criteria, quota_needed, points_value) VALUES (?,?,?,?,?)")
         ->execute([trim($_POST['project_ref']), trim($_POST['title']), trim($_POST['target_criteria']), (int)$_POST['quota_needed'], (int)$_POST['points_value']]);
    header('Location: admin_open_projects.php'); exit;
}
$rows = $conn->query("SELECT * FROM exaconnect_open_projects ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"/><title>Open Projects | ExaConnect</title><link rel="stylesheet" href="admin.css"></head>
<body>
<header><h1>ExaConnect Admin</h1><a class="signout" href="admin_logout.php">Sign out</a></header>
<?php include 'nav_include.php'; ?>
<main>
  <p style="font-size:13px;color:#8a9bb8;margin-bottom:14px;">These feed <code>api_open_projects.php</code>, which vendors can poll. Once the ExaVerify read-only API is wired up, this list can sync automatically instead of being entered by hand.</p>
  <div class="card">
    <h2 style="font-size:14px;margin-bottom:10px;">Add open project</h2>
    <form method="post">
      <label>Project reference</label><input name="project_ref" required>
      <label>Title</label><input name="title" required>
      <label>Target criteria</label><input name="target_criteria" placeholder="e.g. US, 18-34, employed">
      <label>Quota needed</label><input type="number" name="quota_needed">
      <label>Points awarded on completion</label><input type="number" name="points_value" value="50">
      <button type="submit" style="margin-top:10px;">Add</button>
    </form>
  </div>
  <table>
    <tr><th>Ref</th><th>Title</th><th>Criteria</th><th>Quota</th><th>Points</th><th>Open</th><th>Action</th></tr>
    <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= htmlspecialchars($r['project_ref']) ?></td>
      <td><?= htmlspecialchars($r['title']) ?></td>
      <td><?= htmlspecialchars($r['target_criteria']) ?></td>
      <td><?= (int)$r['quota_needed'] ?></td>
      <td><?= (int)$r['points_value'] ?></td>
      <td><?= $r['is_open'] ? 'Yes' : 'No' ?></td>
      <td><button class="ghost" onclick="toggleProj(<?= $r['id'] ?>)">Toggle open</button></td>
    </tr>
    <?php endforeach; ?>
  </table>
</main>
<script>
function toggleProj(id){fetch('open_project_actions.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'toggle',id})}).then(()=>location.reload());}
</script>
</body></html>
