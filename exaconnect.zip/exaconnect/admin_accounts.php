<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) { header('Location: admin_login.php'); exit; }
$conn = exaconnect_db();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn->prepare("INSERT INTO exaconnect_chart_of_accounts (account_name, account_type) VALUES (?,?)")
         ->execute([trim($_POST['account_name']), $_POST['account_type']]);
    header('Location: admin_accounts.php'); exit;
}
$rows = $conn->query("SELECT * FROM exaconnect_chart_of_accounts ORDER BY account_type, account_name")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"/><title>Chart of Accounts | ExaConnect</title><link rel="stylesheet" href="admin.css"></head>
<body>
<header><h1>ExaConnect Admin</h1><a class="signout" href="admin_logout.php">Sign out</a></header>
<?php include 'nav_include.php'; ?>
<main>
  <div class="card">
    <h2 style="font-size:14px;margin-bottom:10px;">Add account</h2>
    <form method="post">
      <label>Account name</label><input name="account_name" required>
      <label>Type</label>
      <select name="account_type">
        <option value="income">Income</option><option value="expense">Expense</option>
        <option value="asset">Asset</option><option value="liability">Liability</option>
      </select>
      <button type="submit" style="margin-top:10px;">Add</button>
    </form>
  </div>
  <table>
    <tr><th>Account</th><th>Type</th><th>Active</th></tr>
    <?php foreach ($rows as $r): ?>
    <tr><td><?= htmlspecialchars($r['account_name']) ?></td><td><?= htmlspecialchars($r['account_type']) ?></td><td><?= $r['is_active']?'Yes':'No' ?></td></tr>
    <?php endforeach; ?>
  </table>
</main>
</body></html>
