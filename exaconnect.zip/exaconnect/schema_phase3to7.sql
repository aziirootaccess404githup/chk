-- ExaConnect — Phases 3 to 7 schema
-- Run after schema.sql and schema_phase2.sql are already in place.

-- ===== Phase 3: Panel-list support tools =====

CREATE TABLE IF NOT EXISTS exaconnect_queries (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  panelist_id INT UNSIGNED NOT NULL,
  subject VARCHAR(150) NOT NULL,
  message TEXT NOT NULL,
  admin_reply TEXT DEFAULT NULL,
  status ENUM('open','answered','closed') NOT NULL DEFAULT 'open',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  replied_at DATETIME DEFAULT NULL,
  FOREIGN KEY (panelist_id) REFERENCES exaconnect_panelists(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exaconnect_profile_questions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  question_key VARCHAR(60) NOT NULL UNIQUE,   -- e.g. "employment_status"
  question_label VARCHAR(200) NOT NULL,       -- shown to panelist
  field_type ENUM('text','select') NOT NULL DEFAULT 'text',
  options TEXT DEFAULT NULL,                  -- comma-separated, used when field_type='select'
  sort_order INT NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exaconnect_categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  description VARCHAR(255) DEFAULT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ===== Phase 4: Marketplace =====

CREATE TABLE IF NOT EXISTS exaconnect_vendor_bids (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  project_ref VARCHAR(50) NOT NULL,          -- matches an ExaVerify project code, e.g. PRJ-1e92
  vendor_name VARCHAR(150) NOT NULL,
  bid_rate DECIMAL(10,2) NOT NULL,           -- CPI/CPC offered
  quota_offered INT UNSIGNED NOT NULL,
  notes VARCHAR(255) DEFAULT NULL,
  status ENUM('submitted','accepted','declined') NOT NULL DEFAULT 'submitted',
  submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  decided_at DATETIME DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exaconnect_open_projects (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  project_ref VARCHAR(50) NOT NULL UNIQUE,
  title VARCHAR(200) NOT NULL,
  target_criteria VARCHAR(255) DEFAULT NULL,
  quota_needed INT UNSIGNED DEFAULT NULL,
  points_value INT UNSIGNED NOT NULL DEFAULT 50,
  is_open TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
  -- Populated manually for now; once the ExaVerify read-only API is wired
  -- up (per the blueprint's open connection decision), this table can be
  -- synced automatically instead.
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ===== Phase 5: Master data & configuration =====

CREATE TABLE IF NOT EXISTS exaconnect_geo_regions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  country VARCHAR(100) NOT NULL,
  state_region VARCHAR(100) DEFAULT NULL,
  city VARCHAR(100) DEFAULT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exaconnect_companies (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  type ENUM('client','vendor') NOT NULL,
  contact_email VARCHAR(190) DEFAULT NULL,
  contact_phone VARCHAR(30) DEFAULT NULL,
  notes VARCHAR(255) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exaconnect_email_templates (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  template_key VARCHAR(60) NOT NULL UNIQUE,   -- e.g. "otp", "approval", "invitation"
  subject VARCHAR(200) NOT NULL,
  body TEXT NOT NULL,                          -- supports {{first_name}}, {{panelist_id}} placeholders
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE exaconnect_admins
  ADD COLUMN role VARCHAR(30) NOT NULL DEFAULT 'admin' AFTER display_name;

CREATE TABLE IF NOT EXISTS exaconnect_user_groups (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(60) NOT NULL UNIQUE,           -- e.g. Admin, Manager, Viewer
  permissions TEXT DEFAULT NULL                -- comma-separated permission keys
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exaconnect_user_group_members (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  admin_id INT UNSIGNED NOT NULL,
  group_id INT UNSIGNED NOT NULL,
  FOREIGN KEY (admin_id) REFERENCES exaconnect_admins(id) ON DELETE CASCADE,
  FOREIGN KEY (group_id) REFERENCES exaconnect_user_groups(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ===== Phase 6: Communication & content =====

CREATE TABLE IF NOT EXISTS exaconnect_messages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  from_admin VARCHAR(100) NOT NULL,
  to_admin VARCHAR(100) DEFAULT NULL,          -- NULL = broadcast to all admins
  message TEXT NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exaconnect_cms_pages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  page_key VARCHAR(60) NOT NULL UNIQUE,        -- e.g. "faq", "help"
  title VARCHAR(200) NOT NULL,
  content TEXT NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ===== Phase 7: Accounting expansion =====

CREATE TABLE IF NOT EXISTS exaconnect_chart_of_accounts (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  account_name VARCHAR(150) NOT NULL,
  account_type ENUM('income','expense','asset','liability') NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exaconnect_commissions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  project_ref VARCHAR(50) NOT NULL,
  team_member VARCHAR(100) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  status ENUM('pending','paid') NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  paid_at DATETIME DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
