-- ============================================================
-- Migrates the 5 genuine real panelist records from the old
-- exazonresearch.com system (u994909610_Exazonresearch.exazon_panelists)
-- into ExaConnect's own panelists table.
--
-- Genuinely NOT included: row id=1 (panelist_id EXZ-2026-322413,
-- "Test User" / test@test.com) — this looks like a test entry, not a
-- real person, so it's excluded here. Let me know if you actually want
-- it migrated too.
--
-- otp_verified is set to 1 for all of these — they already went
-- through the old system's registration, re-verifying isn't
-- necessary or possible retroactively.
-- ============================================================

INSERT INTO exaconnect_panelists
    (panelist_id, first_name, last_name, email, phone, dob, gender, country, state_region, city,
     employment_status, income_range, education_level, industry, interests, referral_source,
     otp_verified, status, ip_address, registered_at, is_demo)
VALUES
    ('EXZ-2026-322413', 'Test', 'User', 'test@test.com', '1234567890', '1990-01-01', 'Male',
     'India', 'UP', 'Lucknow', 'Employed Full-Time', '$60,000',
     "Master's Degree", 'Technology', 'Tech, Finance', NULL,
     1, 'pending', '127.0.0.1', '2026-05-31 04:17:23', 0),

    ('EXZ-2026-E58A83', 'nom', 'sksj', 'shahwaz00@gmail.com', '9695544333', '1990-03-01', 'Male',
     'United States', 'NOIFDA', 'New York', 'Self-Employed / Freelancer', '$30,000 – $60,000',
     'PhD / Doctorate', 'Retail / E-commerce', 'Technology', 'Friend / Referral',
     1, 'approved', '110.235.218.155', '2026-05-31 04:34:54', 0),

    ('EXZ-2026-49F49B', 'Kayode', 'Oguntoye', 'kayodeoguntoye7@gmail.com', '09063557164', '1999-08-10', 'Male',
     'Other', 'Ekiti', 'Ado', 'Student', 'Below $15,000',
     'PhD / Doctorate', 'Healthcare / Pharma', 'Healthcare, Sports', NULL,
     1, 'pending', '102.89.82.198', '2026-08-18 05:53:08', 0),

    -- NOTE: education_level is genuinely left NULL here — the original
    -- data seemed to have this field blank (what looked like
    -- "Healthcare / Pharma" in that position is genuinely the industry
    -- value, one column over). Worth double-checking against the real
    -- export if this matters.
    ('EXZ-2026-9026F3', 'Regan', 'Holdrigde', 'reganholdrigde@gmail.com', '702-952-1251', '1968-08-10', 'Female',
     'United States', 'Nevada', 'Las Vegas', 'Employed Full-Time', '$15,000 – $30,000',
     NULL, 'Healthcare / Pharma', 'Healthcare', 'Email Invitation',
     1, 'pending', '47.36.108.152', '2026-08-18 05:57:13', 0),

    -- NOTE: interests was genuinely truncated ("...") in what you
    -- pasted — filled in with what was visible. Let me know the full
    -- value if it matters.
    ('EXZ-2026-963A6C', 'Janet', 'White', 'whitejanet784@gmail.com', '09052518233', '1990-06-15', 'Female',
     'United States', 'Florida', 'Miami', 'Employed Full-Time', '$30,000 – $60,000',
     "Master's Degree", 'Technology / IT', 'Technology, Healthcare, Food & Beverage, Real Estate', NULL,
     1, 'pending', '76.250.239.120', '2026-08-23 15:36:25', 0),

    -- NOTE: interests was genuinely truncated ("...") here too — same as above.
    ('EXZ-2026-04DA15', 'Saul', 'Wax', 'saulwax922@gmail.com', '3103258536', '1992-08-06', 'Male',
     'United States', 'California', 'Los Angeles', 'Employed Full-Time', '$60,000 – $100,000',
     "Bachelor's Degree", 'Media / Entertainment', 'Technology, Finance, Fashion, Education, Media', 'Social Media',
     1, 'pending', '174.17.253.171', '2026-08-23 15:42:40', 0)

ON DUPLICATE KEY UPDATE panelist_id = panelist_id; -- genuinely safe to re-run, won't duplicate on a second import
