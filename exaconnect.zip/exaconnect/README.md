# ExaConnect — Phase 1 (Panelist Registration & Approval)

This is the first phase of ExaConnect: a standalone panelist registration,
approval, and login system, separate from ExaVerify. It is meant to be
deployed at exaconnect.exazonresearch.com.

## Files in this phase

- `schema.sql` — run this once on a fresh database to create the tables.
- `config.sample.php` — copy to `config.php`, fill in your real DB
  credentials, and generate a real password hash for the seed admin account.
- `register.html` — the panelist-facing registration form (4 steps: personal
  info, email OTP, profile, done). Fill in your EmailJS keys near the top of
  the `<script>` block before this will actually send OTP emails.
- `register_submit.php` — backend that saves a new pending panelist to the
  database and returns their generated Panelist ID.
- `admin_login.php` / `admin_logout.php` — admin sign in/out.
- `admin_dashboard.php` — real counts (no demo data) and a pending-approval
  queue with Approve/Reject buttons.
- `admin_actions.php` — backend the dashboard calls to approve/reject.
- `panelist_login.php` / `panelist_logout.php` — panelist sign in/out by
  Panelist ID + email.
- `panelist_portal.php` — panelist's own dashboard. Surveys/points sections
  are placeholders for now — they'll populate once Phase 2 (rewards) and the
  survey-matching piece are built.

## Setup steps

1. Create a new database (e.g. `exaconnect`) on Hostinger for the
   `exaconnect.exazonresearch.com` subdomain.
2. Import `schema.sql` into that database.
3. Copy `config.sample.php` to `config.php` and fill in the real DB host,
   name, username, and password.
4. Generate a real admin password hash:
   `php -r "echo password_hash('yourpassword', PASSWORD_DEFAULT);"`
   and update the seed row in `exaconnect_admins` (or re-run the INSERT from
   schema.sql with the new hash).
5. In `register.html`, replace `YOUR_EMAILJS_PUBLIC_KEY`,
   `YOUR_EMAILJS_SERVICE_ID`, and `YOUR_OTP_TEMPLATE_ID` with your actual
   EmailJS account details (the same ones already used on the existing
   join-panel.html, if you want OTP emails to look consistent).
6. Upload all files to the exaconnect.exazonresearch.com document root.
7. Visit `register.html` to test registration, and `admin_login.php` to test
   approval.

## What's intentionally not in Phase 1

- Points, rewards, and redemption (Phase 2 — see below).
- Survey invitations / matching.
- Migrating the real existing panelist records from the current
  `exazon_panelists` table — do this once you're ready to cut over, with a
  simple export/import matching the column names in `schema.sql`.
- The IP/device fraud-check step from ExaVerify's `inc_exz.php` — this
  needs the connection mechanism (shared table vs internal API) to be
  decided first, per the open decisions list in the blueprint doc.

## Phase 2 — Rewards, points & redemption

Additional files:

- `schema_phase2.sql` — run after `schema.sql`. Adds `points_balance` to
  panelists, plus `exaconnect_point_ledger`, `exaconnect_redemptions`, and
  `exaconnect_webhook_keys` tables.
- `webhook_credit_points.php` — the endpoint ExaVerify's `track.php` (or a
  small connector script next to it) calls when a survey completes, to
  credit points automatically to a matching approved panelist by email.
  Update the placeholder secret in `exaconnect_webhook_keys` before using
  this in production, and use that same secret on the ExaVerify side.
- `admin_credit_points.php` — a manual "credit points to a panelist" tool
  for testing the reward flow before the ExaVerify webhook is wired up.
- `redemption_submit.php` — panelist-facing backend for requesting a
  redemption; deducts points immediately (refunded automatically if the
  request is later rejected).
- `panelist_portal.php` and `admin_dashboard.php` are both updated in
  place to show real points balances and a redemption request/review flow.
- `admin_actions.php` is updated to handle marking a redemption as paid, or
  rejecting it (which refunds the held points).

### Setup steps for Phase 2

1. Run `schema_phase2.sql` on the same database.
2. Replace the placeholder value in `exaconnect_webhook_keys` with a real
   random secret.
3. On the ExaVerify side, once you decide the exact trigger point in
   `track.php`, have it POST to `webhook_credit_points.php` with
   `{ key, email, points, reason }` whenever a survey completes.
4. Until that connection is wired up, use `admin_credit_points.php` to test
   the full points → redemption → admin review flow manually.

### Still open for Phase 2

- Exact points value per completed survey (flat vs per-project) — still an
  open decision from the blueprint.
- Whether to support gift cards at launch, or bank transfer only.
- Referral links / bonus points — not built yet.

## Phase 3 — Panel-list support tools

- `panelist_queries.php` / `query_submit.php` — panelist raises a support query.
- `admin_queries.php` / `query_reply.php` — admin views and replies.
- `admin_profile_questions.php` / `profile_question_actions.php` — admin can
  add/toggle registration profile questions without touching `register.html`
  directly (note: `register.html`'s fixed fields aren't yet wired to read
  from this table dynamically — that's a good next increment).
- `admin_categories.php` / `category_actions.php` — manage the interest
  taxonomy used for survey matching later.
- `admin_tasks.php` — aggregates pending approvals, redemptions, queries,
  and bids in one place, flagging anything older than 48 hours (24 hours
  for queries) as overdue.

## Phase 4 — Marketplace

- `vendor_bid_form.html` / `vendor_bid_submit.php` — a public link you can
  send vendors to collect bids against a project reference.
- `admin_bids.php` / `bid_actions.php` — review and accept/decline bids.
- `admin_open_projects.php` / `open_project_actions.php` — manually list
  which projects are currently open (until the ExaVerify read-only API
  connection is built, per the blueprint's open decisions).
- `api_open_projects.php` — a public JSON endpoint vendors can poll to see
  open projects; the "Insights Exchange" push-notification version is a
  future increment once you're ready to move past polling.

## Phase 5 — Master data & configuration

- `admin_geo_regions.php` / `geo_region_actions.php`
- `admin_companies.php`
- `admin_email_templates.php` — editable templates with `{{first_name}}` /
  `{{panelist_id}}` placeholders (not yet wired into the actual email-sending
  code — that hookup is a good next increment once you're ready).
- `admin_user_groups.php` — group/permission definitions exist, but
  assigning a specific admin to a group and enforcing permissions on each
  page is not yet built; treat this as the data model, not full enforcement.
- `schema_phase3to7.sql` adds a `role` column to `exaconnect_admins` as a
  simpler starting point if full group-based permissions feel like overkill
  initially.

## Phase 6 — Communication & content

- `admin_messages.php` — simple internal inbox/broadcast for the team.
- `admin_cms.php` — editable static page content (title + body), keyed by a
  page key like `faq` or `help`. Nothing reads from this table yet on the
  public site — that wiring is a next increment once you decide which pages
  should pull from here.

## Phase 7 — Accounting expansion

- `admin_accounts.php` — a basic chart of accounts (income/expense/asset/
  liability).
- `admin_commissions.php` / `commission_actions.php` — track a commission
  amount per project and team member, and mark it paid.

## Setup for Phases 3–7

1. Run `schema_phase3to7.sql` after the earlier schema files.
2. Link `admin.css` and `nav_include.php` are shared across all the new
   admin pages — make sure both are uploaded alongside everything else.
3. Everything reuses the same `config.php` and admin session as Phases 1–2.

## Honest gaps to know about

This is a working first pass across all 7 phases, built quickly per your
request — it is not the same as a fully hardened, production-tested
release. Before relying on this for real panelists and real money
(redemptions, commissions), it's worth:

- Testing every form for edge cases (empty fields, duplicate submissions).
- Adding real permission enforcement for User Groups (currently just a data
  model).
- Wiring `register.html` to read profile questions dynamically from
  `exaconnect_profile_questions` instead of its current fixed fields.
- Adding CSRF protection and rate-limiting to public-facing forms
  (`register.html`, `vendor_bid_form.html`) before real-world traffic.

## Survey links, taking a survey, and getting rewarded

This is the piece that connects everything end to end. New files:

- `build_survey_link()` (in `config.sample.php` / `config.php`) — generates
  a panelist's unique survey link using ExaVerify's existing vendor.php
  format: `?sid=PROJECT&vid=VENDOR_ID&uid=PANELIST_ID`. No custom encryption
  needed — the panelist_id itself is passed as the uid.
- `panelist_portal.php` now lists open projects (from
  `exaconnect_open_projects`) with a "Take survey" button using that link.
- `webhook_credit_points.php` now matches primarily by `panelist_id` (since
  that's what comes back as the uid), with email as a fallback.
- `track_php_patch_instructions.md` — exact instructions (not a file to
  upload) for the small addition needed in ExaVerify's own `track.php`, so
  that when a survey completes, ExaConnect gets notified and credits points
  automatically.

### One-time setup required on the ExaVerify side (do this once)

1. Add a vendor in ExaVerify representing "ExaConnect Panel" and note its
   vendor id.
2. Put that vendor id into ExaConnect's `config.php` as `EXAVERIFY_VENDOR_ID`.
3. For every project panelists should be able to take, assign that vendor
   to the project in ExaVerify (same "Assign Vendor" step as any vendor) —
   without this, `vendor.php`'s authorized-vendor check will reject the link.
4. Add a matching entry in ExaConnect's `admin_open_projects.php` (project
   ref, title, points value) so it shows up in panelists' portals.
5. Follow `track_php_patch_instructions.md` to add the small completion
   hook to ExaVerify's `track.php`.

### How "complete" is determined

Nothing new here — ExaVerify's `track.php` already decides complete vs.
terminate vs. quota-full exactly as it does for any respondent. The only
addition is a notification to ExaConnect at the moment a completion is
confirmed.

## Sending real rewards — Tremendous integration

Redemptions are paid out via [Tremendous](https://www.tremendous.com), which
handles gift cards, PayPal, and bank transfers across 200+ countries — this
covers Indian, US, UK, and other international panelists through one
integration, since Razorpay/RazorpayX only supports sending money to Indian
bank accounts.

New file:

- `tremendous_send.php` — a `send_tremendous_reward()` function that calls
  Tremendous's Orders API.

`admin_actions.php`'s redemption review now actually calls this when you
click "Send reward & mark paid" — it is no longer just a status change. If
the Tremendous call fails, the redemption stays pending and you'll see an
error message instead of a silent failure.

### Setup

1. Sign up at tremendous.com (any email works to start).
2. Copy your **test/sandbox API key** from the dashboard and put it in
   `config.php` as `TREMENDOUS_API_KEY`. Leave `TREMENDOUS_TEST_MODE` as
   `true` — this uses fake money so you can test the whole redemption flow
   safely.
3. `POINTS_PER_USD` in `config.php` controls the points-to-dollar
   conversion rate — adjust it to match your own economics.
4. Test a full redemption end to end in sandbox mode before touching
   `TREMENDOUS_TEST_MODE`.
5. When ready to go live: link a real funding source (bank account/card) in
   the Tremendous dashboard, copy its ID into `TREMENDOUS_FUNDING_SOURCE_ID`,
   and set `TREMENDOUS_TEST_MODE` to `false`.

### Worth knowing

- Tremendous's API can change over time — verify the request format
  against their current docs before relying on this for real payouts, and
  always test in sandbox first.
- Regularly sending money internationally (India ↔ other countries) can
  have real tax/compliance implications (e.g. FEMA rules, 1099 reporting).
  This isn't something either of us can advise on with certainty — worth a
  quick check with an accountant once volumes grow.




