-- ============================================================
-- Adds fields the website's join-panel.html asks for that
-- ExaConnect's panelists table didn't have yet, plus a genuine,
-- toggleable way to show a padded panel-size to prospective clients
-- without ever losing track of the real number internally.
-- ============================================================

-- Note: run this once. If you ever need to re-run it, phpMyAdmin will
-- just show a "duplicate column" error on any ALTER that already
-- applied — safe to ignore, just skip re-running the ones that error.

ALTER TABLE exaconnect_panelists ADD COLUMN dob DATE DEFAULT NULL;
ALTER TABLE exaconnect_panelists ADD COLUMN gender VARCHAR(30) DEFAULT NULL;
ALTER TABLE exaconnect_panelists ADD COLUMN ip_address VARCHAR(45) DEFAULT NULL;

-- is_demo: a genuine row in the real table, just flagged. Unlike the old
-- system's hardcoded PHP array (which could only be edited by touching
-- code), these are managed like any other panelist — addable/editable/
-- removable from the admin panel — and excluded from real business
-- counts by default, shown only when the toggle is switched on.
ALTER TABLE exaconnect_panelists ADD COLUMN is_demo TINYINT(1) NOT NULL DEFAULT 0;

CREATE INDEX idx_panelists_is_demo ON exaconnect_panelists(is_demo);
