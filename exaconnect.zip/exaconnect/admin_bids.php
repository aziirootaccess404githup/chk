<?php
session_start();
require_once __DIR__ . '/config.php';
if (empty($_SESSION['exaconnect_admin_id'])) { header('Location: admin_login.php'); exit; }
$conn = exaconnect_db();
$rows = $conn->query("SELECT * FROM exaconnect_vendor_bids ORDER BY (status='submitted') DESC, submitted_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"/><title>Bidding | ExaConnect</title><link rel="stylesheet" href="admin.css"></head>
<body>
<header><h1>ExaConnect Admin</h1><a class="signout" href="admin_logout.php">Sign out</a></header>
<?php include 'nav_include.php'; ?>
<main>
  <p style="font-size:13px;color:#8a9bb8;margin-bottom:14px;">Share <code>vendor_bid_form.html</code> with vendors to collect bids against an open project reference.</p>
  <table>
    <tr><th>Project</th><th>Vendor</th><th>Rate</th><th>Quota</th><th>Notes</th><th>Status</th><th>Action</th></tr>
    <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= htmlspecialchars($r['project_ref']) ?></td>
      <td><?= htmlspecialchars($r['vendor_name']) ?></td>
      <td><?= htmlspecialchars($r['bid_rate']) ?></td>
      <td><?= (int)$r['quota_offered'] ?></td>
      <td><?= htmlspecialchars($r['notes']) ?></td>
      <td><span class="badge <?= htmlspecialchars($r['status']) ?>"><?= htmlspecialchars($r['status']) ?></span></td>
      <td>
        <?php if ($r['status'] === 'submitted'): ?>
          <button onclick="decide(<?= $r['id'] ?>,'accepted')">Accept</button>
          <button class="reject" onclick="decide(<?= $r['id'] ?>,'declined')">Decline</button>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
  </table>
</main>
<script>
function decide(id, status) {
  fetch('bid_actions.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({id, status}) })
    .then(() => location.reload());
}
</script>
</body></html>
