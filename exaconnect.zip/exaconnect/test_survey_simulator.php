<?php
/**
 * ============================================================================
 * TEST SURVEY SIMULATOR — for ExaVerify + ExaConnect
 * ============================================================================
 * This is NOT a real survey — it's a stand-in so you can test the full
 * loop yourself: Panelist clicks "Take Survey" in ExaConnect's portal ->
 * ExaVerify's vendor.php -> this page (acting as "the survey") -> you
 * click a button -> ExaVerify's track.php records the outcome -> the
 * ExaConnect reward-hook fires -> points get credited.
 *
 * HOW TO USE:
 *   1. In ExaVerify, create (or edit) a test project.
 *   2. Set its Live URL to:
 *        https://exaconnect.exazonresearch.com/test_survey_simulator.php?uid=[UID]&sid=[SID]
 *      ([UID] and [SID] get genuinely substituted by ExaVerify's own
 *      vendor.php — same as any real survey's Live URL would.)
 *   3. Assign the "ExaConnect Panel" vendor to that test project.
 *   4. Log in as a genuinely approved test panelist in ExaConnect's
 *      portal, click "Take Survey" on that project — you'll land here.
 *   5. Click a button below. It redirects to ExaVerify's real
 *      pages/track.php with that outcome, exactly like a real survey's
 *      end-of-survey redirect would.
 *   6. Check: the lead shows up correctly in ExaVerify's Leads tab, and
 *      — if you clicked Complete — the panelist's points balance in
 *      ExaConnect went up.
 *
 * Elapsed time (LOI) is measured client-side from page-load to button-
 * click, in whole seconds, same as a real survey would report — though
 * ExaVerify genuinely recalculates this itself server-side anyway (via
 * TIMESTAMPDIFF against the real entry-time), so this value is mostly
 * just for realism, not something ExaVerify actually trusts blindly.
 * ============================================================================
 */

$uid = $_GET['uid'] ?? '';
$sid = $_GET['sid'] ?? '';

$looksUnsubstituted = function ($v) {
    return $v !== '' && (preg_match('/^\[.+\]$/', $v) || preg_match('/^\{\{.+\}\}$/', $v));
};

$warning = '';
if (!$uid) $warning .= "No uid parameter received — check the project's Live URL includes [UID].<br>";
if (!$sid) $warning .= "No sid parameter received — check the project's Live URL includes [SID].<br>";
if ($looksUnsubstituted($uid)) $warning .= "The uid still looks like a literal placeholder ($uid) — ExaVerify didn't substitute its own token.<br>";
if ($looksUnsubstituted($sid)) $warning .= "The sid still looks like a literal placeholder ($sid).<br>";

// This is genuinely the ONLY line that would ever need changing if
// ExaVerify's domain changes.
$exaverifyTrackUrl = 'https://exaverify.exazonresearch.com/pages/track.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Test Survey Simulator — ExaConnect</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body{font-family:'DM Sans',Arial,sans-serif;background:#0a1628;color:#e8edf5;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:20px;}
  .box{background:#111e38;border:1px solid rgba(255,255,255,.08);padding:36px;border-radius:14px;max-width:560px;text-align:center;}
  h2{margin-top:0;color:#e8c96a;font-weight:500;}
  .uid{background:#0a1628;border:1px solid rgba(255,255,255,.08);padding:8px 12px;border-radius:6px;font-family:monospace;display:inline-block;margin:6px 0;word-break:break-all;font-size:13px;}
  .btns{display:flex;flex-direction:column;gap:10px;margin-top:24px;}
  button{padding:13px;border:none;border-radius:8px;font-size:14px;cursor:pointer;color:#fff;font-family:inherit;}
  .complete{background:#2ecc71;color:#0a1628;font-weight:600;}
  .terminate{background:#e74c3c;}
  .quotafull{background:#6b7280;}
  .qualityfail{background:#374151;}
  .note{font-size:12px;color:#8a9bb8;margin-top:22px;text-align:left;line-height:1.6;}
  .warn{background:rgba(255,193,7,.1);border:1px solid rgba(255,193,7,.3);color:#ffc107;padding:12px;border-radius:8px;text-align:left;font-size:13px;margin-bottom:16px;}
  #loiDisplay{font-family:monospace;color:#8a9bb8;font-size:13px;}
</style>
</head>
<body>
  <div class="box">
    <h2>🧪 Test Survey Simulator</h2>
    <p style="color:#8a9bb8;font-size:13px;">Pretend this is the real survey the panelist is taking.</p>

    <?php if ($warning): ?>
      <div class="warn"><strong>⚠️ Heads up:</strong><br><?= $warning ?></div>
    <?php endif; ?>

    <p style="margin:16px 0 4px;font-size:13px;color:#8a9bb8;">Respondent UID</p>
    <div class="uid"><?= htmlspecialchars($uid ?: '(none received)') ?></div>
    <?php if ($sid): ?>
      <p style="margin:10px 0 4px;font-size:13px;color:#8a9bb8;">Project SID</p>
      <div class="uid"><?= htmlspecialchars($sid) ?></div>
    <?php endif; ?>
    <p id="loiDisplay">Elapsed time on this page: <span id="loiVal">0</span>s</p>

    <?php if ($uid && $sid): ?>
    <div class="btns">
      <button class="complete" onclick="go('complete')">✅ Simulate Complete</button>
      <button class="terminate" onclick="go('terminate')">🚫 Simulate Terminate</button>
      <button class="quotafull" onclick="go('quotafull')">📊 Simulate Overquota / Quota Full</button>
      <button class="qualityfail" onclick="go('quality_fail')">⛔ Simulate Quality Fail / Screenout</button>
    </div>
    <?php else: ?>
      <p style="color:#e74c3c;">Cannot show test buttons — missing uid or sid, see warning above.</p>
    <?php endif; ?>

    <p class="note">
      Clicking a button redirects to ExaVerify's real <code>pages/track.php</code> with that
      outcome — exactly what a genuine survey's end-of-survey redirect would do. If you click
      Complete, and the ExaConnect reward-hook + your project's vendor-assignment are set up
      correctly, this panelist's points balance should go up shortly after.
    </p>
  </div>

<script>
  const pageLoadTime = Date.now();
  setInterval(() => {
    document.getElementById('loiVal').innerText = Math.floor((Date.now() - pageLoadTime) / 1000);
  }, 1000);

  function go(status) {
    const elapsedSeconds = Math.floor((Date.now() - pageLoadTime) / 1000);
    const trackUrl = <?= json_encode($exaverifyTrackUrl) ?>;
    const sid = <?= json_encode($sid) ?>;
    const uid = <?= json_encode($uid) ?>;
    window.location.href = trackUrl + '?status=' + status
      + '&sid=' + encodeURIComponent(sid)
      + '&uid=' + encodeURIComponent(uid)
      + '&loi=' + elapsedSeconds;
  }
</script>
</body>
</html>
