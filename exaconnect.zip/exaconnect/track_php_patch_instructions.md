# Patch instructions for ExaVerify's track.php

This is NOT a file to upload as-is — it's instructions for a small addition
to your existing `track.php` (in the ExaVerify `pages/` folder), so that
completing a survey credits points to a matching ExaConnect panelist.

## Where to add it

In `track.php`, find this line (it's the point where a completed status is
confirmed and the quota check runs):

```php
if ($status === 'complete' && !$no_entry_record) exz_check_quota($db, $sid);
```

Right after that line, add the following block:

```php
// --- ExaConnect panelist reward hook -------------------------------
// If this completed entry's UID is a panelist_id from ExaConnect (they
// all start with "EXZ-"), notify ExaConnect so it can credit points.
// This does not affect normal third-party/vendor tracking in any way —
// it only fires for panelist traffic, and failures here are silent so
// they never block or break the existing completion flow.
//
// IMPORTANT: !$no_entry_record is required here. Without it, someone
// who simply knows their OWN panelist_id (which is shown to them
// directly after registering — it's not a secret) could repeatedly
// hit ExaVerify's completion URL directly, with no genuine survey
// ever taken, and farm free points every time. no_entry_record is
// exactly the flag ExaVerify already sets for this scenario — a
// completion with no matching entry-click on record — so requiring
// it to be false here closes this off using logic that already exists.
if ($status === 'complete' && !$no_entry_record && strpos($uid, 'EXZ-') === 0) {
    $ch = curl_init('https://exaconnect.exazonresearch.com/webhook_credit_points.php');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 5, // don't let a slow webhook delay the respondent's redirect
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode([
            'key' => 'REPLACE_WITH_THE_SAME_SECRET_FROM_exaconnect_webhook_keys',
            'panelist_id' => $uid,
            'project_ref' => $sid, // ExaConnect looks up this project's own points_value instead of trusting a hardcoded number
            'reason' => "Survey complete: {$sid}",
        ]),
    ]);
    $webhook_result = curl_exec($ch);
    $webhook_http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    // Genuinely logged (not silent) — a failed reward-credit is real money
    // a panelist didn't receive, and should be visible somewhere rather
    // than vanishing with no trace. Doesn't block or alter the respondent's
    // own redirect either way.
    if ($webhook_http_code !== 200) {
        error_log("ExaConnect reward-hook failed: HTTP $webhook_http_code, panelist=$uid, project=$sid, response=" . substr((string)$webhook_result, 0, 300));
    }
}
// ---------------------------------------------------------------------
```

## Important notes

- Replace `REPLACE_WITH_THE_SAME_SECRET_FROM_exaconnect_webhook_keys` with
  the actual secret you set in ExaConnect's `exaconnect_webhook_keys` table.
  Both sides must match exactly.
- Points value is no longer hardcoded here — `project_ref` (the `$sid`) is
  sent instead, and ExaConnect's `webhook_credit_points.php` looks up that
  project's own `points_value` from `exaconnect_open_projects`, falling
  back to `DEFAULT_POINTS_PER_SURVEY` if that project isn't registered
  there. This means changing a project's reward amount only needs updating
  it in ExaConnect's Open Projects page — no track.php edit needed.
- `$uid` here should already be the variable track.php uses to identify the
  respondent (the same one that came in as `uid` on the original
  `vendor.php` link) — check the exact variable name in your file if it
  differs from what's shown above.
- `$no_entry_record` is a variable track.php already computes earlier in
  the file (the same one the existing quota-check line uses) — this hook
  should sit right after that line specifically so the variable is
  already set.
- This uses PHP's `curl` extension, which should already be available on
  your Hostinger PHP setup. If it isn't, `file_get_contents` with a stream
  context is a drop-in alternative — ask if you'd like that version instead.

## One-time setup on the ExaVerify side

Before any of this works, you also need to:

1. Add a vendor entry in ExaVerify representing "ExaConnect Panel" (however
   you normally add a vendor), and note its vendor id.
2. Put that vendor id into ExaConnect's `config.php` as
   `EXAVERIFY_VENDOR_ID`.
3. For every project you want panelists to be able to take, assign that
   vendor to the project in ExaVerify (the same "Assign Vendor" step used
   for any other vendor) — without this, `vendor.php`'s authorized-vendor
   check will reject the panelist's link.
4. Add a matching entry for that same project in ExaConnect's
   `admin_open_projects.php` so it shows up in panelists' portals.
