-- ============================================================
-- ExaVerify — Full Database Schema
-- Generated: 26 August 2026 (matches ExaVerify_Updated_v13.zip)
-- ============================================================
--
-- WHAT THIS IS
-- Every table this system needs, extracted directly from the app's own
-- CREATE TABLE statements (index.php / inc_exz.php / pages/track.php /
-- reconcile.php etc.) by actually running the full app end-to-end against
-- a fresh database and dumping the resulting structure — not hand-typed,
-- so it's guaranteed to match the code exactly. Regenerated for v13 —
-- includes columns that didn't exist in earlier schema versions:
-- exz_audit_log.performed_by, survey_starts.device/country/city,
-- project_settings.parent_sid/is_parent, exz_status_synonyms table.
--
-- SAFE TO RUN ANYTIME
-- Every statement uses CREATE TABLE IF NOT EXISTS (no DROP TABLE at all).
-- This means:
--   - On a completely fresh database: creates all 23 tables from scratch.
--   - On your EXISTING production database: does nothing destructive —
--     tables that already exist are left untouched, your real data is
--     never touched or deleted. This mirrors exactly how the app already
--     behaves on its own (it self-creates any missing table/column on
--     first use).
--   - You do NOT need to run this at all if you're just updating an
--     existing deployment's PHP files — the app creates/updates its own
--     tables and columns automatically the first time each feature is
--     used. This file exists for a genuinely FRESH deployment (new
--     database, new subdomain, new server) where you'd rather have every
--     table ready upfront instead of tables appearing one-by-one as
--     features get used for the first time.
--
-- NOT INCLUDED (by design)
-- No real data — this is structure only. No DB name/CREATE DATABASE/USE
-- statement — run this against whichever database your inc_exz.php /
-- index.php DB constants (EXZ_DB_NAME etc.) already point to.
-- ============================================================

SET FOREIGN_KEY_CHECKS=0;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `dashboard_notes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `note` text NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_audit_log` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `action` varchar(60) NOT NULL,
  `detail` varchar(255) DEFAULT '',
  `performed_by` varchar(100) DEFAULT NULL,
  `performed_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_blocked_ips` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(64) NOT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `blocked_by` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_ip` (`ip`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_clients` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `client_name` varchar(150) NOT NULL,
  `contact_person` varchar(100) DEFAULT '',
  `email` varchar(150) DEFAULT '',
  `phone` varchar(40) DEFAULT '',
  `notes` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT 'active',
  `client_uid` varchar(20) DEFAULT NULL,
  `s2s_outbound_enabled` tinyint(1) DEFAULT '0',
  `s2s_outbound_endpoint` varchar(500) DEFAULT NULL,
  `s2s_outbound_token` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_invoice_status` (
  `survey_id` varchar(50) NOT NULL,
  `status` varchar(20) DEFAULT 'unpaid',
  `invoice_no` varchar(50) DEFAULT '',
  `notes` text,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`survey_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_prescreen_template_questions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `template_id` int unsigned NOT NULL,
  `question_id` int unsigned NOT NULL,
  `sort_order` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_template` (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_prescreen_templates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `template_name` varchar(150) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_project_activity_log` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` varchar(50) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `activity` varchar(150) NOT NULL,
  `sub_activity` varchar(150) DEFAULT '',
  `duration_minutes` int DEFAULT '0',
  `notes` text,
  `logged_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_survey` (`survey_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_project_country_links` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` varchar(50) NOT NULL,
  `country` varchar(100) NOT NULL,
  `live_url` varchar(500) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_sid_country` (`survey_id`,`country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_project_vendors` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` varchar(50) NOT NULL,
  `vendor_id` int unsigned NOT NULL,
  `status` varchar(20) DEFAULT 'active',
  `cpi` decimal(10,2) DEFAULT NULL,
  `max_limit` int unsigned DEFAULT NULL,
  `assigned_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `short_code` varchar(10) DEFAULT NULL,
  `click_quota` int unsigned DEFAULT NULL,
  `show_prescreener` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_proj_vendor` (`survey_id`,`vendor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_question_library` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `country` varchar(100) DEFAULT '',
  `language` varchar(50) DEFAULT '',
  `control_type` varchar(30) DEFAULT 'text',
  `title` varchar(200) NOT NULL,
  `question_text` text NOT NULL,
  `min_length` int DEFAULT NULL,
  `max_length` int DEFAULT NULL,
  `text_type` varchar(30) DEFAULT '',
  `options` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_screener_answers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` varchar(50) NOT NULL,
  `respondent` varchar(255) NOT NULL,
  `question_key` varchar(100) NOT NULL,
  `question_text` varchar(255) DEFAULT '',
  `answer_value` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_survey_respondent` (`survey_id`,`respondent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_share_links` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` varchar(50) NOT NULL,
  `token` varchar(64) NOT NULL,
  `is_revoked` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_status_synonyms` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` varchar(50) DEFAULT NULL,
  `synonym` varchar(50) NOT NULL,
  `maps_to` varchar(20) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_syn` (`survey_id`,`synonym`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_team` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) DEFAULT '',
  `password_hash` varchar(255) DEFAULT NULL,
  `role` varchar(20) DEFAULT 'viewer',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_uid_mapping` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `original_uid` varchar(255) NOT NULL,
  `encrypted_uid` varchar(255) NOT NULL,
  `survey_id` varchar(50) DEFAULT NULL,
  `source` varchar(50) DEFAULT 'vendor',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_enc` (`encrypted_uid`),
  KEY `idx_orig_sid` (`original_uid`,`survey_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `exz_vendors` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `vendor_name` varchar(150) NOT NULL,
  `contact_person` varchar(100) DEFAULT '',
  `email` varchar(150) DEFAULT '',
  `phone` varchar(40) DEFAULT '',
  `notes` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `complete_url` varchar(500) DEFAULT NULL,
  `terminate_url` varchar(500) DEFAULT NULL,
  `screenout_url` varchar(500) DEFAULT NULL,
  `quotafull_url` varchar(500) DEFAULT NULL,
  `end_behavior` varchar(20) DEFAULT 'show_page',
  `status` varchar(20) DEFAULT 'active',
  `panel_size` int unsigned DEFAULT NULL,
  `availability_status` varchar(20) DEFAULT 'open',
  `s2s_inbound_api_key` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `portal_clients` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(60) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `client_name` varchar(100) NOT NULL,
  `client_id` int unsigned DEFAULT NULL,
  `allowed_projects` text,
  `is_active` tinyint(1) DEFAULT '1',
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `project_settings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` varchar(50) NOT NULL,
  `project_name` varchar(150) DEFAULT '',
  `target` int unsigned DEFAULT '0',
  `cpi` decimal(10,2) DEFAULT '0.00',
  `vendor_cost` decimal(10,2) DEFAULT '0.00',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `client_id` int unsigned DEFAULT NULL,
  `status` varchar(20) DEFAULT 'active',
  `is_pinned` tinyint(1) DEFAULT '0',
  `color_tag` varchar(20) DEFAULT '',
  `project_type` varchar(20) DEFAULT 'direct',
  `notes` text,
  `live_url` text,
  `encrypt_uid` tinyint(1) DEFAULT '1',
  `ir` decimal(5,2) DEFAULT '0.00',
  `loi` int DEFAULT '0',
  `test_url` text,
  `description` text,
  `auto_report_enabled` tinyint(1) DEFAULT '0',
  `auto_report_freq` varchar(10) DEFAULT 'weekly',
  `auto_report_email` varchar(150) DEFAULT '',
  `auto_report_last_sent` datetime DEFAULT NULL,
  `target_countries` varchar(500) DEFAULT NULL,
  `parent_sid` varchar(50) DEFAULT NULL,
  `is_parent` tinyint(1) DEFAULT '0',
  `prescreen_template_id` int unsigned DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `project_manager` varchar(100) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `survey_id` (`survey_id`),
  KEY `idx_parent_sid` (`parent_sid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `reconcile_records` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` varchar(50) NOT NULL,
  `client_name` varchar(100) DEFAULT NULL,
  `period` varchar(30) DEFAULT NULL,
  `we_sent` int DEFAULT '0',
  `client_accepted` int DEFAULT '0',
  `client_rejected` int DEFAULT '0',
  `reject_reason` text,
  `our_completes` int DEFAULT '0',
  `difference` int DEFAULT '0',
  `cpi` decimal(10,2) DEFAULT '0.00',
  `currency` varchar(10) DEFAULT 'USD',
  `dispute_amount` decimal(12,2) DEFAULT '0.00',
  `status` varchar(20) DEFAULT 'open',
  `notes` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `survey_responses` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` varchar(50) NOT NULL,
  `respondent` varchar(100) NOT NULL,
  `status` varchar(30) NOT NULL,
  `source` varchar(100) DEFAULT '',
  `client_name` varchar(100) DEFAULT '',
  `ip` varchar(45) DEFAULT '',
  `device` varchar(20) DEFAULT '',
  `country` varchar(100) DEFAULT '',
  `city` varchar(100) DEFAULT '',
  `loi_seconds` int DEFAULT NULL,
  `is_duplicate` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `status_locked` tinyint(1) DEFAULT '0',
  `vendor_id` int unsigned DEFAULT NULL,
  `no_entry_record` tinyint(1) DEFAULT '0',
  `browser` varchar(30) DEFAULT '',
  `postback_status` varchar(20) DEFAULT 'pending',
  `postback_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_survey` (`survey_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `survey_starts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(255) NOT NULL,
  `sid` varchar(50) NOT NULL,
  `source` varchar(50) DEFAULT 'direct',
  `vendor_id` int unsigned DEFAULT NULL,
  `ip` varchar(45) DEFAULT '',
  `start_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `device` varchar(20) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uid_sid` (`uid`,`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


SET FOREIGN_KEY_CHECKS=1;
