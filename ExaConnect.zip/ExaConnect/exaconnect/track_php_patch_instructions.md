# Patch instructions for ExaVerify's track.php

This is NOT a file to upload as-is — it's instructions for a small addition
to your existing `track.php` (in the ExaVerify `pages/` folder), so that
completing a survey credits points to a matching ExaConnect panelist.

## Where to add it

In `track.php`, find this line (it's the point where a completed status is
confirmed and the quota check runs):

```php
if ($status === 'complete' && !$no_entry_record) exz_check_quota($db, $sid);
```

Right after that line, add the following block:

```php
// --- ExaConnect panelist reward hook -------------------------------
// If this completed entry's UID is a panelist_id from ExaConnect (they
// all start with "EXZ-"), notify ExaConnect so it can credit points.
// This does not affect normal third-party/vendor tracking in any way —
// it only fires for panelist traffic, and failures here are silent so
// they never block or break the existing completion flow.
if ($status === 'complete' && strpos($uid, 'EXZ-') === 0) {
    $ch = curl_init('https://exaconnect.exazonresearch.com/webhook_credit_points.php');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 5, // don't let a slow webhook delay the respondent's redirect
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode([
            'key' => 'REPLACE_WITH_THE_SAME_SECRET_FROM_exaconnect_webhook_keys',
            'panelist_id' => $uid,
            'points' => 50, // or look this up per-project if you want variable rates
            'reason' => "Survey complete: {$sid}",
        ]),
    ]);
    curl_exec($ch);
    curl_close($ch);
}
// ---------------------------------------------------------------------
```

## Important notes

- Replace `REPLACE_WITH_THE_SAME_SECRET_FROM_exaconnect_webhook_keys` with
  the actual secret you set in ExaConnect's `exaconnect_webhook_keys` table.
  Both sides must match exactly.
- The `50` points value is hardcoded here for simplicity. If you want
  different projects to award different points, you'd look up
  `points_value` from ExaConnect's `exaconnect_open_projects` table for
  this `$sid` instead — that requires either a shared database connection
  or a small additional read-only API call, which is one of the still-open
  connection-mechanism decisions from the blueprint.
- `$uid` here should already be the variable track.php uses to identify the
  respondent (the same one that came in as `uid` on the original
  `vendor.php` link) — check the exact variable name in your file if it
  differs from what's shown above.
- This uses PHP's `curl` extension, which should already be available on
  your Hostinger PHP setup. If it isn't, `file_get_contents` with a stream
  context is a drop-in alternative — ask if you'd like that version instead.

## One-time setup on the ExaVerify side

Before any of this works, you also need to:

1. Add a vendor entry in ExaVerify representing "ExaConnect Panel" (however
   you normally add a vendor), and note its vendor id.
2. Put that vendor id into ExaConnect's `config.php` as
   `EXAVERIFY_VENDOR_ID`.
3. For every project you want panelists to be able to take, assign that
   vendor to the project in ExaVerify (the same "Assign Vendor" step used
   for any other vendor) — without this, `vendor.php`'s authorized-vendor
   check will reject the panelist's link.
4. Add a matching entry for that same project in ExaConnect's
   `admin_open_projects.php` so it shows up in panelists' portals.
