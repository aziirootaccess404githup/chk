<?php
// webhook_credit_points.php
// Called by ExaVerify (via a small addition to track.php — see
// track_php_patch_instructions.md) when a survey completes for a known
// panelist. Matches primarily by panelist_id (since that's what's passed
// as the uid on the survey link), with email as a fallback.
//
// Expected POST JSON:
//   { "key": "the shared secret", "panelist_id": "EXZ-2026-UN0123",
//     "points": 50, "reason": "Survey complete: PRJ-1e92" }

header('Content-Type: application/json');
require_once __DIR__ . '/config.php';

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid payload.']);
    exit;
}

$conn = exaconnect_db();

// Validate shared secret
$keyRow = $conn->prepare("SELECT key_value FROM exaconnect_webhook_keys WHERE key_name = 'exaverify_completion' LIMIT 1");
$keyRow->execute();
$expectedKey = $keyRow->fetchColumn();

if (!$expectedKey || ($input['key'] ?? '') !== $expectedKey) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Invalid key.']);
    exit;
}

$panelist_id = trim($input['panelist_id'] ?? '');
$email = trim($input['email'] ?? '');
$points = (int)($input['points'] ?? 0);
$reason = trim($input['reason'] ?? 'Survey complete');

if ((!$panelist_id && !$email) || $points <= 0) {
    echo json_encode(['success' => false, 'message' => 'Missing or invalid panelist_id/email/points.']);
    exit;
}

if ($panelist_id) {
    $stmt = $conn->prepare("SELECT id FROM exaconnect_panelists WHERE panelist_id = ? AND status = 'approved' LIMIT 1");
    $stmt->execute([$panelist_id]);
} else {
    $stmt = $conn->prepare("SELECT id FROM exaconnect_panelists WHERE email = ? AND status = 'approved' LIMIT 1");
    $stmt->execute([$email]);
}
$panelist = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$panelist) {
    // No matching approved panelist — this is expected for third-party/vendor
    // respondents who aren't panelists at all. Not an error.
    echo json_encode(['success' => true, 'matched' => false]);
    exit;
}

$conn->beginTransaction();
$conn->prepare("UPDATE exaconnect_panelists SET points_balance = points_balance + ? WHERE id = ?")
     ->execute([$points, $panelist['id']]);
$conn->prepare("INSERT INTO exaconnect_point_ledger (panelist_id, points_change, reason, source) VALUES (?, ?, ?, 'webhook')")
     ->execute([$panelist['id'], $points, $reason]);
$conn->commit();

echo json_encode(['success' => true, 'matched' => true]);
