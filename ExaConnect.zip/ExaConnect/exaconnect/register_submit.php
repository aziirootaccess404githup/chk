<?php
header('Content-Type: application/json');
require_once __DIR__ . '/config.php';

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
    exit;
}

$first_name = trim($input['first_name'] ?? '');
$last_name  = trim($input['last_name'] ?? '');
$email      = trim($input['email'] ?? '');
$phone      = trim($input['phone'] ?? '');
$country    = trim($input['country'] ?? '');
$employment_status = trim($input['employment_status'] ?? '');
$income_range       = trim($input['income_range'] ?? '');
$education_level    = trim($input['education_level'] ?? '');
$industry           = trim($input['industry'] ?? '');
$interests          = trim($input['interests'] ?? '');
$referral_source    = trim($input['referral_source'] ?? '');
$otp_verified       = !empty($input['otp_verified']);

if (!$first_name || !$last_name || !filter_var($email, FILTER_VALIDATE_EMAIL) || !$otp_verified) {
    echo json_encode(['success' => false, 'message' => 'Please complete all required fields and verify your email.']);
    exit;
}

try {
    $conn = exaconnect_db();

    // Prevent duplicate registrations by email
    $chk = $conn->prepare("SELECT id FROM exaconnect_panelists WHERE email = ? LIMIT 1");
    $chk->execute([$email]);
    if ($chk->fetch()) {
        echo json_encode(['success' => false, 'message' => 'An account with this email already exists.']);
        exit;
    }

    $panelist_id = generate_panelist_id($conn);

    $stmt = $conn->prepare("INSERT INTO exaconnect_panelists
        (panelist_id, first_name, last_name, email, phone, country,
         employment_status, income_range, education_level, industry,
         interests, referral_source, otp_verified, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'pending')");

    $stmt->execute([
        $panelist_id, $first_name, $last_name, $email, $phone, $country,
        $employment_status, $income_range, $education_level, $industry,
        $interests, $referral_source
    ]);

    echo json_encode(['success' => true, 'panelist_id' => $panelist_id]);

} catch (Exception $e) {
    // Do not leak internal error details to the client.
    echo json_encode(['success' => false, 'message' => 'Registration failed. Please try again later.']);
}
