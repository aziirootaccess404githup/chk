<?php
// ============================================================
// Exazon Research — respondent_view.php
// Full detail view for a single respondent: session info,
// quality score breakdown, and pre-survey (screener) answers.
// Linked from Responses, Project View's Recent Leads, and
// Screener Data tabs.
// ============================================================
session_start();
require_once __DIR__ . '/inc_exz.php';

if (empty($_SESSION['ex_auth']) || empty($_SESSION['ex_team_id'])) {
    header('Location: index.php'); exit;
}

$db = exz_db();
$uid = trim($_GET['uid'] ?? '');
$sid = trim($_GET['sid'] ?? '');

if (!$uid) { header('Location: index.php#responses'); exit; }

// ── SESSION / LEAD ROW ──────────────────────────────────────
// $uid might be the original (pre-encryption) UID or the stored/encrypted
// one, depending on where the link came from — try a direct match first,
// then fall back to resolving it via the mapping table either way.
function exz_lookup_lead($db, $uid, $sid) {
    if ($sid) {
        $q = $db->prepare("SELECT * FROM survey_responses WHERE respondent=? AND survey_id=? ORDER BY id DESC LIMIT 1");
        $q->execute([$uid, $sid]);
    } else {
        $q = $db->prepare("SELECT * FROM survey_responses WHERE respondent=? ORDER BY id DESC LIMIT 1");
        $q->execute([$uid]);
    }
    return $q->fetch();
}
$lead = exz_lookup_lead($db, $uid, $sid);
if (!$lead) {
    // Direct match failed — resolve via uid_mapping (uid may be the
    // original value while survey_responses stores the encrypted one).
    try {
        $mm = $db->prepare("SELECT original_uid, encrypted_uid FROM exz_uid_mapping WHERE (original_uid=? OR encrypted_uid=?)" . ($sid ? " AND survey_id=?" : "") . " LIMIT 1");
        $mm_params = [$uid, $uid];
        if ($sid) $mm_params[] = $sid;
        $mm->execute($mm_params);
        $map = $mm->fetch();
        if ($map) {
            $lead = exz_lookup_lead($db, $map['encrypted_uid'], $sid);
            if ($lead) $uid = $map['encrypted_uid'];
        }
    } catch (Exception $e) {}
}
if ($lead) $sid = $lead['survey_id']; // authoritative sid

// Resolve original (pre-encryption) UID, if this respondent was encrypted
$original_uid = null;
if ($lead) {
    $um = $db->prepare("SELECT original_uid FROM exz_uid_mapping WHERE encrypted_uid=? AND survey_id=? LIMIT 1");
    $um->execute([$lead['respondent'], $sid]);
    $original_uid = $um->fetchColumn() ?: null;
}

$proj = null;
if ($sid) {
    $pp = $db->prepare("SELECT ps.*, c.client_name AS cname FROM project_settings ps
        LEFT JOIN exz_clients c ON c.id = ps.client_id WHERE ps.survey_id=? LIMIT 1");
    $pp->execute([$sid]);
    $proj = $pp->fetch();
}

// ── QUALITY SCORE (same formula as quality_score.php) ───────
function calcRespondentScore($r) {
    $score = 100; $reasons = [];
    $loi = intval($r['loi_seconds'] ?? 0);
    if ($loi > 0 && $loi < 180) { $score -= 40; $reasons[] = "⚡ Speeder (LOI: ".intdiv($loi,60)."m ".($loi%60)."s)"; }
    elseif ($loi === 0 || $r['loi_seconds'] === null) { $score -= 10; $reasons[] = "⏱ LOI not recorded"; }
    if (!empty($r['is_duplicate'])) { $score -= 30; $reasons[] = "⚠️ Duplicate UID"; }
    if (empty($r['device'])) { $score -= 5; $reasons[] = "📱 Device unknown"; }
    if (empty($r['country'])) { $score -= 5; $reasons[] = "🌍 Country unknown"; }
    if ($r['status'] === 'qc' || $r['status'] === 'quality') { $score -= 15; $reasons[] = "🔍 QC Fail"; }
    return [max(0, min(100, $score)), $reasons];
}
$score = null; $reasons = [];
if ($lead) [$score, $reasons] = calcRespondentScore($lead);

// ── PRE-SURVEY (SCREENER) ANSWERS ───────────────────────────
$screener_answers = [];
try {
    $sa = $db->prepare("SELECT * FROM exz_screener_answers WHERE respondent=?" . ($sid ? " AND survey_id=?" : "") . " ORDER BY created_at ASC");
    $sa->execute($sid ? [$uid, $sid] : [$uid]);
    $screener_answers = $sa->fetchAll();
} catch (Exception $e) {}

function fmt_loi_rv($sec){ if($sec===null) return '—'; $sec=(int)$sec; return sprintf('%dm %ds', intdiv($sec,60), $sec%60); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Respondent — <?= htmlspecialchars($uid) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&family=DM+Mono&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--navy:#0a1628;--gold:#c8a84b;--blue:#1b4fd8;--blue2:#3b82f6;--muted:#94a3b8}
body{font-family:'DM Sans',sans-serif;background:#f4f6fb;color:#0f172a;margin:0}

/* SIDEBAR LAYOUT (matches index.php) */
.app-layout{display:flex;min-height:100vh}
.sidebar{width:250px;flex-shrink:0;background:var(--navy);border-right:1px solid rgba(59,130,246,0.15);
         position:fixed;top:0;left:0;bottom:0;overflow-y:auto;overflow-x:hidden;z-index:200;padding:20px 14px;
         transition:width .2s ease}
.sidebar.collapsed{width:60px}
.sidebar.collapsed:hover{width:250px}
.sidebar-toggle{position:absolute;top:18px;right:10px;background:rgba(255,255,255,0.08);border:none;color:var(--muted);
                 width:22px;height:22px;border-radius:6px;cursor:pointer;font-size:12px;line-height:1;z-index:5}
.sidebar.collapsed .sidebar-brand,.sidebar.collapsed .sidebar-user,.sidebar.collapsed .sidebar-section-lbl{opacity:0;transition:opacity .1s}
.sidebar.collapsed:hover .sidebar-brand,.sidebar.collapsed:hover .sidebar-user,
.sidebar.collapsed:hover .sidebar-section-lbl{opacity:1}
.sidebar.collapsed .sb-link{overflow:hidden}
.sidebar.collapsed:hover .sb-link{overflow:visible}
.app-content{flex:1;margin-left:250px;min-width:0;transition:margin-left .2s ease}
.app-content.sidebar-collapsed{margin-left:60px}
.sidebar-brand{display:flex;align-items:center;gap:10px;padding:0 6px 18px;border-bottom:1px solid rgba(255,255,255,0.08);margin-bottom:16px;white-space:nowrap}
.sidebar .nav-logo{width:34px;height:34px;border-radius:50%;border:2px solid rgba(59,130,246,0.3);background:#fff;flex-shrink:0}
.sidebar .nav-name{font-family:'Bebas Neue',sans-serif;font-size:15px;letter-spacing:2px;color:#fff;line-height:1.2}
.sidebar .nav-tag{font-size:8px;letter-spacing:2px;text-transform:uppercase;color:var(--gold)}
.sidebar-user{padding:0 6px 16px;margin-bottom:10px;white-space:nowrap}
.sidebar-user-name{font-size:12px;font-weight:700;color:#fff}
.sidebar-user-role{font-size:9px;letter-spacing:1px;text-transform:uppercase;color:var(--gold)}
.sidebar-section-lbl{font-size:9px;letter-spacing:2px;text-transform:uppercase;color:rgba(255,255,255,0.25);padding:14px 6px 6px;white-space:nowrap}
.sb-link{display:flex;align-items:center;gap:8px;width:100%;text-align:left;padding:9px 10px;font-size:12px;font-weight:600;
         color:var(--muted);background:none;border:none;border-radius:8px;cursor:pointer;white-space:nowrap;transition:all .15s;text-decoration:none;box-sizing:border-box}
.sb-link.active,.sb-link:hover{color:#fff;background:rgba(59,130,246,0.15)}
@media(max-width:900px){
  .sidebar{position:static;width:100%;height:auto;display:flex;flex-wrap:wrap}
  .app-content{margin-left:0}
}

.topbar{background:#0a1628;padding:14px 28px;display:flex;align-items:center;justify-content:space-between}
.topbar-title{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:2px;color:#fff}
.btn-ghost{background:#fff;color:#374151;border:1px solid #e2e8f0;border-radius:8px;padding:9px 18px;font-size:13px;font-weight:600;text-decoration:none}
.content{max-width:900px;margin:0 auto;padding:24px 20px}
.card{background:#fff;border-radius:12px;padding:20px;margin-bottom:18px;border:1px solid #e5e9f2}
.card-title{font-size:11px;letter-spacing:1.5px;text-transform:uppercase;color:#94a3b8;font-weight:700;margin-bottom:14px}
.info-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.info-item .lbl{font-size:10px;letter-spacing:1px;text-transform:uppercase;color:#94a3b8;margin-bottom:3px}
.info-item .val{font-size:14px;font-weight:600}
.pill{display:inline-block;padding:3px 12px;border-radius:20px;font-size:11px;font-weight:700}
.pill-complete{background:rgba(34,197,94,.12);color:#15803d}
.pill-terminate{background:rgba(245,158,11,.12);color:#b45309}
.pill-qc{background:rgba(139,92,246,.12);color:#6d28d9}
.score-num{font-size:44px;font-weight:700}
.score-bar{background:#e2e8f0;border-radius:8px;height:12px;overflow:hidden;margin:10px 0}
.score-fill{height:100%}
.reason-tag{display:inline-block;background:#fef2f2;color:#b91c1c;border-radius:6px;padding:4px 10px;font-size:11px;margin:3px 4px 3px 0}
table{width:100%;border-collapse:collapse}
th{padding:8px 10px;font-size:10px;background:#f8faff;text-align:left;color:#94a3b8;text-transform:uppercase}
td{padding:8px 10px;font-size:12px;border-top:1px solid #f1f3f9}
.mono{font-family:'DM Mono',monospace}
</style>
</head>
<body>

<div class="app-layout">
<aside class="sidebar" id="appSidebar">
  <button class="sidebar-toggle" onclick="toggleSidebar()" title="Collapse/Expand sidebar">☰</button>
  <div class="sidebar-brand">
    <img src="logo.php" class="nav-logo" alt="Exazon">
    <div>
      <div class="nav-name">Exazon Research</div>
      <div class="nav-tag">Survey Dashboard v5</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="sidebar-user-name"><?= htmlspecialchars($_SESSION['ex_team_name'] ?? '') ?></div>
    <div class="sidebar-user-role"><?= htmlspecialchars($_SESSION['ex_team_role'] ?? '') ?></div>
  </div>

  <div class="sidebar-section-lbl">Main</div>
  <a class="sb-link" href="index.php#overview">📊 Dashboard</a>
  <a class="sb-link" href="index.php#projects">📁 Projects</a>
  <a class="sb-link active" href="index.php#responses">📋 Leads</a>
  <a class="sb-link" href="index.php#fraud">🚨 Fraud Detection</a>
  <a class="sb-link" href="index.php#screener">📄 Screener Data</a>
  <a class="sb-link" href="index.php#searchlookup">🔍 Search &amp; Lookup</a>
  <a class="sb-link" href="index.php#notes">📝 Notes</a>
  <a class="sb-link" href="index.php#billing">🧾 Billing</a>
  <a class="sb-link" href="index.php#qualityscore">⭐ Quality Score</a>
  <a class="sb-link" href="index.php#reconciletab">⚖️ Reconcile</a>
  <a class="sb-link" href="index.php#charts">📈 Analytics</a>
  <a class="sb-link" href="index.php#feasibility">📐 Feasibility Calc</a>

  <div class="sidebar-section-lbl">Management</div>
  <a class="sb-link" href="index.php#clientsmaster">🏢 Clients</a>
  <a class="sb-link" href="index.php#vendors">👥 Vendors</a>
  <a class="sb-link" href="index.php#clients">👤 Client Accounts</a>

  <div class="sidebar-section-lbl">Admin</div>
  <a class="sb-link" href="index.php#alerts">🔔 Alert Settings</a>
  <a class="sb-link" href="index.php#auditlog">📜 Audit Log</a>
  <?php if (($_SESSION['ex_team_role'] ?? '') === 'superadmin'): ?>
  <a class="sb-link" href="index.php#team">👥 Team</a>
  <?php endif; ?>

  <div class="sidebar-section-lbl">Account</div>
  <a class="sb-link" href="index.php#changepass">🔑 Change Password</a>
  <a class="sb-link" href="index.php?logout=1" style="color:#f87171">⏻ Logout</a>
</aside>

<div class="app-content" id="appContent">

<div class="topbar">
  <div class="topbar-title">Respondent Details</div>
  <a href="<?= $sid ? 'project_view.php?sid='.urlencode($sid) : 'index.php#responses' ?>" onclick="if(document.referrer && document.referrer.includes(window.location.host)){history.back();return false;}" class="btn-ghost">← Back</a>
</div>

<div class="content">
  <?php if (!$lead): ?>
  <div class="card">
    <div style="text-align:center;padding:30px;color:#94a3b8">No session record found for UID: <strong><?= htmlspecialchars($uid) ?></strong></div>
  </div>
  <?php else: ?>

  <div class="card">
    <div class="card-title">Session Details</div>
    <div class="info-grid">
      <div class="info-item"><div class="lbl">Respondent</div><div class="val mono">
        <?php if ($original_uid && $original_uid !== $lead['respondent']): ?>
        <?= htmlspecialchars($original_uid) ?>
        <div style="font-size:10px;color:#94a3b8;font-weight:400;margin-top:2px">🔒 Encrypted (client-facing): <?= htmlspecialchars($lead['respondent']) ?></div>
        <?php else: ?>
        <?= htmlspecialchars($lead['respondent']) ?>
        <?php endif; ?>
      </div></div>
      <div class="info-item"><div class="lbl">Project</div><div class="val"><?= htmlspecialchars($sid) ?></div></div>
      <div class="info-item"><div class="lbl">Client</div><div class="val"><?= htmlspecialchars($proj['cname'] ?? '—') ?></div></div>
      <div class="info-item"><div class="lbl">Status</div><div class="val"><span class="pill <?= $lead['status']==='complete'?'pill-complete':($lead['status']==='terminate'?'pill-terminate':'pill-qc') ?>"><?= ucfirst($lead['status']) ?></span></div></div>
      <div class="info-item"><div class="lbl">LOI</div><div class="val"><?= fmt_loi_rv($lead['loi_seconds']) ?></div></div>
      <div class="info-item"><div class="lbl">Country</div><div class="val"><?= htmlspecialchars($lead['country'] ?: '—') ?></div></div>
      <div class="info-item"><div class="lbl">City</div><div class="val"><?= htmlspecialchars($lead['city'] ?: '—') ?></div></div>
      <div class="info-item"><div class="lbl">Device</div><div class="val"><?= htmlspecialchars($lead['device'] ?: '—') ?></div></div>
      <div class="info-item"><div class="lbl">IP Address</div><div class="val mono"><?= htmlspecialchars($lead['ip'] ?: '—') ?></div></div>
      <div class="info-item"><div class="lbl">Source</div><div class="val"><?= htmlspecialchars($lead['source'] ?: '—') ?></div></div>
      <div class="info-item"><div class="lbl">Duplicate?</div><div class="val"><?= !empty($lead['is_duplicate']) ? '⚠️ Yes' : '✓ No' ?></div></div>
      <div class="info-item"><div class="lbl">Recorded</div><div class="val"><?= date('d M Y, H:i', strtotime($lead['created_at'].' UTC')) ?></div></div>
    </div>
  </div>

  <div class="card">
    <div class="card-title">Quality Score Breakdown</div>
    <div class="score-num" style="color:<?= $score>=80?'#22c55e':($score>=60?'#f59e0b':'#ef4444') ?>"><?= $score ?><span style="font-size:18px;color:#94a3b8">/100</span></div>
    <div class="score-bar"><div class="score-fill" style="width:<?= $score ?>%;background:<?= $score>=80?'#22c55e':($score>=60?'#f59e0b':'#ef4444') ?>"></div></div>
    <?php if (empty($reasons)): ?>
    <div style="color:#15803d;font-size:13px;margin-top:8px">✅ No quality issues detected.</div>
    <?php else: foreach($reasons as $r): ?>
    <span class="reason-tag"><?= htmlspecialchars($r) ?></span>
    <?php endforeach; endif; ?>
  </div>

  <div class="card">
    <div class="card-title">Pre-Survey Answers (Captured Before Client Survey)</div>
    <table>
      <thead><tr><th>Question</th><th>Answer</th><th>Captured At</th></tr></thead>
      <tbody>
      <?php if (empty($screener_answers)): ?>
      <tr><td colspan="3" style="text-align:center;color:#94a3b8;padding:20px">No pre-survey answers captured for this respondent.</td></tr>
      <?php else: foreach($screener_answers as $sa): ?>
      <tr>
        <td><?= htmlspecialchars($sa['question_text'] ?: $sa['question_key']) ?></td>
        <td><strong><?= htmlspecialchars($sa['answer_value']) ?></strong></td>
        <td style="color:#94a3b8"><?= date('d M H:i:s', strtotime($sa['created_at'].' UTC')) ?></td>
      </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <?php endif; ?>
</div>

</div><!-- /app-content -->
</div><!-- /app-layout -->

<script>
function toggleSidebar(){
  const sb = document.getElementById('appSidebar');
  const ac = document.getElementById('appContent');
  sb.classList.toggle('collapsed');
  ac.classList.toggle('sidebar-collapsed');
  localStorage.setItem('exz_sidebar_collapsed', sb.classList.contains('collapsed') ? '1' : '0');
}
(function(){
  if (localStorage.getItem('exz_sidebar_collapsed') === '1') {
    document.getElementById('appSidebar').classList.add('collapsed');
    document.getElementById('appContent').classList.add('sidebar-collapsed');
  }
})();
</script>
</body>
</html>
