<?php
// ============================================================
// EXAZON RESEARCH — UID Tools (Fully Standalone)
// File: uid_tools.php
// No dependencies — DB + Auth sab andar hai
// ============================================================
session_name('exazon_uid_tools');
session_start();
date_default_timezone_set('Asia/Kolkata');

// ── DB Config (embedded) ──────────────────────────────────────
$host     = "localhost";
$db_name  = "u994909610_Exaverify";
$username = "u994909610_Exaverify";
$password = "Exaverify@8181";

try {
    $conn = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die('<div style="font-family:monospace;padding:40px;color:#dc2626;background:#fef2f2;border:1px solid #fca5a5;border-radius:8px;margin:40px auto;max-width:600px">
        <strong>DB Connection Failed:</strong><br>' . htmlspecialchars($e->getMessage()) . '
    </div>');
}

// ── Auth ──────────────────────────────────────────────────────
define('UID_TOOL_PASS', 'Exazon@UID25'); // ← password change karo yahan

if (isset($_POST['do_login'])) {
    if ($_POST['pass'] === UID_TOOL_PASS) {
        $_SESSION['uid_auth'] = true;
    } else {
        $login_err = 'Wrong password!';
    }
}
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
    exit;
}

// ── Login page ────────────────────────────────────────────────
if (!isset($_SESSION['uid_auth'])): ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>UID Tools — Login</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:#0a1628;min-height:100vh;display:flex;align-items:center;justify-content:center}
.box{background:#112040;border:1px solid rgba(59,130,246,.2);border-radius:16px;padding:44px 38px;width:380px;box-shadow:0 24px 64px rgba(0,0,0,.5)}
.logo{font-family:'Syne',sans-serif;font-size:10px;letter-spacing:4px;color:#c8a84b;text-transform:uppercase;margin-bottom:8px}
.title{font-family:'Syne',sans-serif;font-size:24px;color:#fff;margin-bottom:6px}
.sub{font-size:12px;color:#64748b;margin-bottom:32px}
label{display:block;font-size:10px;font-weight:600;color:#94a3b8;letter-spacing:1px;text-transform:uppercase;margin-bottom:7px}
input[type=password]{width:100%;padding:13px 15px;background:#0d1f3c;border:1px solid rgba(59,130,246,.2);border-radius:8px;color:#fff;font-size:14px;outline:none;margin-bottom:18px;transition:border .2s}
input[type=password]:focus{border-color:#3b82f6}
button{width:100%;padding:14px;background:linear-gradient(135deg,#1b4fd8,#3b82f6);color:#fff;border:none;border-radius:8px;font-family:'Syne',sans-serif;font-size:13px;font-weight:600;letter-spacing:1.5px;cursor:pointer;transition:opacity .2s}
button:hover{opacity:.88}
.err{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#f87171;font-size:12px;padding:10px 14px;border-radius:7px;margin-bottom:16px}
</style>
</head>
<body>
<div class="box">
  <div class="logo">Exazon Research</div>
  <div class="title">UID Tools</div>
  <div class="sub">Bulk Checker &amp; Respondent Timeline</div>
  <?php if(isset($login_err)): ?><div class="err">⚠️ <?= htmlspecialchars($login_err) ?></div><?php endif; ?>
  <form method="POST">
    <label>Password</label>
    <input type="password" name="pass" autofocus placeholder="••••••••••">
    <button type="submit" name="do_login">Enter →</button>
  </form>
</div>
</body>
</html>
<?php
exit;
endif;

// ── Load projects ─────────────────────────────────────────────
$projects = [];
try {
    $projects = $conn->query("SELECT DISTINCT survey_id FROM survey_responses ORDER BY survey_id")->fetchAll(PDO::FETCH_COLUMN);
} catch(Exception $e){}

// ── Bulk UID Check ────────────────────────────────────────────
$bulk_results = [];
$bulk_done    = false;

if (isset($_POST['bulk_check'])) {
    $raw   = trim($_POST['uids'] ?? '');
    $proj  = trim($_POST['project'] ?? '');
    $lines = array_filter(array_map('trim', explode("\n", $raw)));
    $uids  = array_slice(
        array_unique(array_map(fn($l) => preg_replace('/[^a-zA-Z0-9_\-]/', '', $l), $lines)),
        0, 500
    );

    if (!empty($uids) && !empty($proj)) {
        foreach ($uids as $uid) {
            if (!$uid) continue;
            try {
                // ── Resolve raw + encrypted UID via uid_mapping ──
                $ids = [$uid];
                $mm = $conn->prepare(
                    "SELECT original_uid, encrypted_uid FROM uid_mapping
                     WHERE (original_uid = ? OR encrypted_uid = ?) AND sid = ? LIMIT 1"
                );
                $mm->execute([$uid, $uid, $proj]);
                $map_row = $mm->fetch(PDO::FETCH_ASSOC);
                if (!$map_row) {
                    $mm2 = $conn->prepare(
                        "SELECT original_uid, encrypted_uid FROM uid_mapping
                         WHERE original_uid = ? OR encrypted_uid = ? LIMIT 1"
                    );
                    $mm2->execute([$uid, $uid]);
                    $map_row = $mm2->fetch(PDO::FETCH_ASSOC);
                }
                if ($map_row) {
                    $ids[] = $map_row['original_uid'];
                    $ids[] = $map_row['encrypted_uid'];
                }
                $ids   = array_values(array_unique(array_filter($ids)));
                $in_ph = implode(',', array_fill(0, count($ids), '?'));

                $q = $conn->prepare(
                    "SELECT status, loi_seconds, is_duplicate, created_at, ip, device, country, source
                     FROM survey_responses WHERE respondent IN ($in_ph) AND survey_id = ? ORDER BY created_at DESC"
                );
                $q->execute([...$ids, $proj]);
                $data = $q->fetchAll(PDO::FETCH_ASSOC);

                $eq = $conn->prepare(
                    "SELECT quality_score, is_speeder, is_duplicate, status as ev_status, start_time, end_time
                     FROM exaverify_sessions WHERE uuid IN ($in_ph) ORDER BY id DESC LIMIT 1"
                );
                $eq->execute($ids);
                $ev_data = $eq->fetch(PDO::FETCH_ASSOC);

                if (empty($data)) {
                    $bulk_results[] = ['uid'=>$uid,'status'=>'not_found','flags'=>[],'rows'=>[],'ev'=>$ev_data,'map'=>$map_row];
                } else {
                    $r     = $data[0];
                    $flags = [];
                    if ($r['is_duplicate'])                            $flags[] = 'DUP';
                    if ($r['loi_seconds'] && $r['loi_seconds'] < 180) $flags[] = 'SPEEDER';
                    if (in_array($r['status'], ['qc','quality']))      $flags[] = 'QC';
                    if ($ev_data && $ev_data['is_speeder'])            $flags[] = 'EV_SPEEDER';

                    $tag = empty($flags) ? 'clean'
                         : (in_array('DUP',$flags) ? 'duplicate'
                         : (in_array('SPEEDER',$flags)||in_array('EV_SPEEDER',$flags) ? 'speeder'
                         : 'flagged'));

                    $bulk_results[] = ['uid'=>$uid,'status'=>$tag,'flags'=>$flags,'rows'=>$data,'ev'=>$ev_data,'map'=>$map_row];
                }
            } catch(Exception $e) {
                $bulk_results[] = ['uid'=>$uid,'status'=>'error','flags'=>[],'rows'=>[],'ev'=>null,'map'=>null];
            }
        }
        $bulk_done = true;
    }
}

// ── Timeline lookup ───────────────────────────────────────────
$timeline_uid       = trim($_GET['uid'] ?? '');
$timeline_data      = null;
$timeline_responses = [];
$timeline_ev        = null;
$timeline_answers   = [];

if ($timeline_uid) {
    try {
        // ── Resolve raw + encrypted UID via uid_mapping ──
        $tl_ids = [$timeline_uid];
        $tm = $conn->prepare(
            "SELECT original_uid, encrypted_uid FROM uid_mapping
             WHERE original_uid = ? OR encrypted_uid = ? LIMIT 1"
        );
        $tm->execute([$timeline_uid, $timeline_uid]);
        $tl_map = $tm->fetch(PDO::FETCH_ASSOC);
        if ($tl_map) {
            $tl_ids[] = $tl_map['original_uid'];
            $tl_ids[] = $tl_map['encrypted_uid'];
        }
        $tl_ids   = array_values(array_unique(array_filter($tl_ids)));
        $tl_in_ph = implode(',', array_fill(0, count($tl_ids), '?'));

        $s = $conn->prepare("SELECT * FROM exaverify_sessions WHERE uuid IN ($tl_in_ph) ORDER BY id DESC LIMIT 1");
        $s->execute($tl_ids);
        $timeline_ev = $s->fetch(PDO::FETCH_ASSOC);

        $a = $conn->prepare("SELECT question_key, answer_value FROM exaverify_answers WHERE uid IN ($tl_in_ph) ORDER BY id ASC");
        $a->execute($tl_ids);
        $timeline_answers = $a->fetchAll(PDO::FETCH_ASSOC);

        $r = $conn->prepare("SELECT * FROM survey_responses WHERE respondent IN ($tl_in_ph) ORDER BY created_at ASC");
        $r->execute($tl_ids);
        $timeline_responses = $r->fetchAll(PDO::FETCH_ASSOC);

        $ss = $conn->prepare("SELECT * FROM survey_starts WHERE uid IN ($tl_in_ph) ORDER BY id DESC LIMIT 1");
        $ss->execute($tl_ids);
        $timeline_data = $ss->fetch(PDO::FETCH_ASSOC);

    } catch(Exception $e){}
}

function fmt_loi($s) {
    if (!$s) return '—';
    return intdiv($s,60).'m '.($s%60).'s';
}
function time_since($t) {
    $d = time() - strtotime($t . ' UTC');
    if ($d < 60)    return $d.'s ago';
    if ($d < 3600)  return intdiv($d,60).'m ago';
    if ($d < 86400) return intdiv($d,3600).'h ago';
    return intdiv($d,86400).'d ago';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>UID Tools — Exazon Research</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@500;600;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
:root{
  --bg:#f0f4ff;--navy:#0a1628;--navy2:#112040;
  --blue:#1b4fd8;--blue2:#3b82f6;--gold:#c8a84b;
  --green:#22c55e;--red:#ef4444;--amber:#f59e0b;--purple:#8b5cf6;
  --muted:#94a3b8;--card:#fff;--border:#e2e8f0;
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:#1e293b;min-height:100vh}

/* NAV */
.nav{background:var(--navy);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 24px;border-bottom:1px solid rgba(59,130,246,.2);position:sticky;top:0;z-index:100}
.nav-brand{display:flex;flex-direction:column}
.nav-title{font-family:'Syne',sans-serif;font-size:14px;letter-spacing:2px;color:#fff}
.nav-sub{font-size:9px;letter-spacing:3px;color:var(--gold);text-transform:uppercase}
.logout-btn{background:transparent;border:1px solid rgba(160,190,255,.25);color:rgba(160,190,255,.6);padding:6px 14px;border-radius:6px;font-size:11px;cursor:pointer;font-family:'DM Sans',sans-serif;text-decoration:none;transition:all .2s}
.logout-btn:hover{border-color:rgba(160,190,255,.5);color:#fff}

/* TABS */
.tabs{background:var(--navy2);display:flex;padding:0 24px;border-bottom:1px solid rgba(59,130,246,.15)}
.tab{padding:12px 18px;font-size:11px;font-weight:600;letter-spacing:1px;text-transform:uppercase;color:var(--muted);background:none;border:none;cursor:pointer;border-bottom:2px solid transparent;transition:all .2s}
.tab.active{color:var(--gold);border-bottom-color:var(--gold)}
.tab:hover:not(.active){color:#cbd5e1}

/* PANES */
.pane{display:none}.pane.active{display:block}
.wrap{max-width:1100px;margin:0 auto;padding:24px 18px}

/* CARDS */
.card{background:var(--card);border-radius:14px;border:1px solid var(--border);padding:22px;margin-bottom:18px;box-shadow:0 1px 4px rgba(10,22,40,.05)}
.card-title{font-family:'Syne',sans-serif;font-size:14px;letter-spacing:1px;color:var(--navy);margin-bottom:16px}
.card-title-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px}

/* FORM ELEMENTS */
textarea{width:100%;padding:12px;border:1px solid var(--border);border-radius:10px;font-family:'DM Sans',sans-serif;font-size:13px;resize:vertical;outline:none;min-height:130px;color:#1e293b;background:#fafbff;transition:border .2s}
textarea:focus{border-color:var(--blue2)}
select,input[type=text]{padding:10px 14px;border:1px solid var(--border);border-radius:8px;font-family:'DM Sans',sans-serif;font-size:13px;outline:none;background:#fff;color:#1e293b;width:100%;transition:border .2s}
select:focus,input[type=text]:focus{border-color:var(--blue2)}

/* BUTTONS */
.btn{padding:11px 28px;background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff;border:none;border-radius:8px;font-family:'Syne',sans-serif;font-size:13px;font-weight:600;cursor:pointer;letter-spacing:1px;transition:opacity .2s}
.btn:hover{opacity:.88}
.btn-sm{padding:7px 16px;font-size:11px;letter-spacing:.5px}

/* LAYOUT */
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px}
.label{font-size:11px;font-weight:600;color:var(--muted);letter-spacing:.5px;text-transform:uppercase;margin-bottom:6px}

/* BULK RESULTS */
.result-row{display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:8px;border:1px solid var(--border);margin-bottom:6px;background:#fff;transition:box-shadow .2s}
.result-row:hover{box-shadow:0 2px 8px rgba(10,22,40,.08)}
.result-row.clean    {border-left:3px solid var(--green)}
.result-row.duplicate{border-left:3px solid var(--red)}
.result-row.speeder  {border-left:3px solid var(--amber)}
.result-row.flagged  {border-left:3px solid var(--purple)}
.result-row.not_found{border-left:3px solid var(--muted);opacity:.6}
.result-row.error    {border-left:3px solid #f87171;opacity:.7}
.result-uid{font-family:'Courier New',monospace;font-size:13px;font-weight:600;flex:1;word-break:break-all}
.flag-badge{display:inline-block;padding:2px 8px;border-radius:12px;font-size:10px;font-weight:700;margin-right:4px}
.flag-dup     {background:rgba(239,68,68,.1);color:#dc2626;border:1px solid rgba(239,68,68,.3)}
.flag-speeder {background:rgba(245,158,11,.1);color:#b45309;border:1px solid rgba(245,158,11,.3)}
.flag-qc      {background:rgba(139,92,246,.1);color:#7c3aed;border:1px solid rgba(139,92,246,.3)}
.flag-clean   {background:rgba(34,197,94,.1);color:#16a34a;border:1px solid rgba(34,197,94,.3)}
.flag-notfound{background:rgba(148,163,184,.1);color:#64748b;border:1px solid rgba(148,163,184,.3)}
.flag-error   {background:rgba(248,113,113,.1);color:#b91c1c;border:1px solid rgba(248,113,113,.3)}
.result-meta{font-size:11px;color:var(--muted);white-space:nowrap}

/* SUMMARY PILLS */
.summary-bar{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px}
.sum-pill{padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600}
.sum-total  {background:rgba(27,79,216,.1);color:#1b4fd8;border:1px solid rgba(27,79,216,.2)}
.sum-clean  {background:rgba(34,197,94,.1);color:#16a34a;border:1px solid rgba(34,197,94,.2)}
.sum-dup    {background:rgba(239,68,68,.1);color:#dc2626;border:1px solid rgba(239,68,68,.2)}
.sum-speeder{background:rgba(245,158,11,.1);color:#b45309;border:1px solid rgba(245,158,11,.2)}
.sum-flag   {background:rgba(139,92,246,.1);color:#7c3aed;border:1px solid rgba(139,92,246,.2)}
.sum-nf     {background:rgba(148,163,184,.1);color:#64748b;border:1px solid rgba(148,163,184,.2)}
.sum-err    {background:rgba(248,113,113,.1);color:#b91c1c;border:1px solid rgba(248,113,113,.2)}

/* TIMELINE */
.search-row{display:flex;gap:10px;margin-bottom:20px}
.search-row input{flex:1}
.tl-wrap{position:relative;padding-left:32px}
.tl-wrap::before{content:'';position:absolute;left:10px;top:6px;bottom:6px;width:2px;background:var(--border);border-radius:2px}
.tl-item{position:relative;margin-bottom:18px}
.tl-dot{position:absolute;left:-26px;width:18px;height:18px;border-radius:50%;border:2px solid #fff;display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:700;color:#fff;top:14px}
.tl-dot.entry     {background:#3b82f6;box-shadow:0 0 0 3px rgba(59,130,246,.2)}
.tl-dot.presurvey {background:#8b5cf6;box-shadow:0 0 0 3px rgba(139,92,246,.2)}
.tl-dot.start     {background:#f59e0b;box-shadow:0 0 0 3px rgba(245,158,11,.2)}
.tl-dot.complete  {background:#22c55e;box-shadow:0 0 0 3px rgba(34,197,94,.2)}
.tl-dot.terminate {background:#94a3b8;box-shadow:0 0 0 3px rgba(148,163,184,.2)}
.tl-dot.qc        {background:#8b5cf6;box-shadow:0 0 0 3px rgba(139,92,246,.2)}
.tl-dot.quotafull {background:#f59e0b;box-shadow:0 0 0 3px rgba(245,158,11,.2)}
.tl-card{background:#fff;border:1px solid var(--border);border-radius:10px;padding:12px 16px}
.tl-title{font-weight:600;font-size:13px;color:var(--navy);margin-bottom:4px}
.tl-time{font-size:11px;color:var(--muted);margin-bottom:7px}
.tl-meta{display:flex;gap:14px;flex-wrap:wrap;font-size:11px;color:#374151}
.tl-meta span{display:flex;align-items:center;gap:4px}
.kv-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:8px;margin-top:10px}
.kv{background:#f8faff;border-radius:6px;padding:7px 10px}
.kv-key{font-size:9px;text-transform:uppercase;letter-spacing:1px;color:var(--muted);margin-bottom:3px}
.kv-val{font-size:12px;font-weight:600;color:#1e293b}
.score-big{font-family:'Syne',sans-serif;font-size:32px;font-weight:700;line-height:1}
.not-found-msg{text-align:center;padding:48px;color:var(--muted);font-size:14px}
.limit-note{font-size:11px;color:var(--muted)}

@media(max-width:600px){
  .grid2{grid-template-columns:1fr}
  .result-row{flex-wrap:wrap}
  .result-meta{display:none}
}
</style>
</head>
<body>

<div class="nav">
  <div class="nav-brand">
    <div class="nav-title">UID TOOLS</div>
    <div class="nav-sub">Exazon Research</div>
  </div>
  <a href="?logout=1" class="logout-btn">Logout</a>
</div>

<div class="tabs">
  <button class="tab active" onclick="switchTab('bulk',this)">🔍 Bulk UID Checker</button>
  <button class="tab" onclick="switchTab('timeline',this)">📍 Respondent Timeline</button>
</div>

<!-- ══════════ BULK UID CHECKER ══════════ -->
<div class="pane active" id="pane-bulk">
<div class="wrap">

<div class="card">
  <div class="card-title">🔍 Bulk UID Checker</div>
  <form method="POST">
    <div class="grid2">
      <div>
        <div class="label">Project (Survey ID)</div>
        <select name="project" required>
          <option value="">— Select Project —</option>
          <?php foreach($projects as $p): ?>
          <option value="<?= htmlspecialchars($p) ?>" <?= (($_POST['project']??'')===$p)?'selected':'' ?>><?= htmlspecialchars($p) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div style="display:flex;align-items:flex-end">
        <p style="font-size:12px;color:var(--muted);padding-bottom:4px">Ek UID per line — max 500 at a time</p>
      </div>
    </div>
    <div class="label" style="margin-bottom:6px">UIDs — Ek per line</div>
    <textarea name="uids" placeholder="abc1&#10;abc2&#10;nomi312" required><?= htmlspecialchars($_POST['uids']??'') ?></textarea>
    <div style="margin-top:12px;display:flex;align-items:center;gap:16px">
      <button type="submit" name="bulk_check" class="btn">Check UIDs →</button>
      <span class="limit-note" id="uid-count-note"></span>
    </div>
  </form>
</div>

<?php if($bulk_done):
  $cnt = [
    'clean'    => count(array_filter($bulk_results, fn($r)=>$r['status']==='clean')),
    'duplicate'=> count(array_filter($bulk_results, fn($r)=>$r['status']==='duplicate')),
    'speeder'  => count(array_filter($bulk_results, fn($r)=>$r['status']==='speeder')),
    'flagged'  => count(array_filter($bulk_results, fn($r)=>$r['status']==='flagged')),
    'not_found'=> count(array_filter($bulk_results, fn($r)=>$r['status']==='not_found')),
    'error'    => count(array_filter($bulk_results, fn($r)=>$r['status']==='error')),
  ];
?>
<div class="card">
  <div class="card-title-row">
    <div class="card-title" style="margin-bottom:0">📊 Results — <?= count($bulk_results) ?> UIDs checked</div>
    <button onclick="exportCSV()" class="btn btn-sm">⬇ Export CSV</button>
  </div>

  <div class="summary-bar">
    <span class="sum-pill sum-total">Total: <?= count($bulk_results) ?></span>
    <span class="sum-pill sum-clean">✅ Clean: <?= $cnt['clean'] ?></span>
    <span class="sum-pill sum-dup">🔴 Duplicate: <?= $cnt['duplicate'] ?></span>
    <span class="sum-pill sum-speeder">⚡ Speeder: <?= $cnt['speeder'] ?></span>
    <?php if($cnt['flagged']): ?><span class="sum-pill sum-flag">⚠️ Flagged: <?= $cnt['flagged'] ?></span><?php endif; ?>
    <span class="sum-pill sum-nf">❓ Not Found: <?= $cnt['not_found'] ?></span>
    <?php if($cnt['error']): ?><span class="sum-pill sum-err">⛔ Error: <?= $cnt['error'] ?></span><?php endif; ?>
  </div>

  <?php foreach($bulk_results as $res):
    $r  = $res['rows'][0] ?? null;
    $ev = $res['ev'];
  ?>
  <div class="result-row <?= $res['status'] ?>">
    <div class="result-uid">
      <?= htmlspecialchars($res['uid']) ?>
      <?php if(!empty($res['map'])): ?>
      <div style="font-size:10px;color:var(--muted);font-weight:400;margin-top:2px">
        Raw: <?= htmlspecialchars($res['map']['original_uid']) ?> &nbsp;|&nbsp; Enc: <?= htmlspecialchars($res['map']['encrypted_uid']) ?>
      </div>
      <?php endif; ?>
    </div>
    <div style="flex:2">
      <?php if($res['status']==='not_found'): ?>
        <span class="flag-badge flag-notfound">NOT FOUND</span>
      <?php elseif($res['status']==='error'): ?>
        <span class="flag-badge flag-error">DB ERROR</span>
      <?php elseif(empty($res['flags'])): ?>
        <span class="flag-badge flag-clean">✅ CLEAN</span>
      <?php else: foreach($res['flags'] as $f): ?>
        <span class="flag-badge <?= $f==='DUP'?'flag-dup':($f==='SPEEDER'||$f==='EV_SPEEDER'?'flag-speeder':'flag-qc') ?>"><?= $f ?></span>
      <?php endforeach; endif; ?>
    </div>
    <?php if($r): ?>
    <div class="result-meta">
      <?= ucfirst($r['status']) ?>
      <?php if($r['loi_seconds']): ?> · LOI: <?= fmt_loi($r['loi_seconds']) ?><?php endif; ?>
      <?php if($r['country']): ?> · <?= htmlspecialchars($r['country']) ?><?php endif; ?>
      <?php if($ev && $ev['quality_score']): ?> · QS: <?= $ev['quality_score'] ?>/100<?php endif; ?>
    </div>
    <?php endif; ?>
    <a href="?uid=<?= urlencode($res['uid']) ?>" style="font-size:11px;color:var(--blue2);text-decoration:none;white-space:nowrap;flex-shrink:0">Timeline →</a>
  </div>
  <?php endforeach; ?>
</div>

<script>
const csvData = <?= json_encode(array_map(function($res){
  $r=$res['rows'][0]??null; $ev=$res['ev'];
  return [
    'uid'           => $res['uid'],
    'status'        => $res['status'],
    'flags'         => implode('|',$res['flags']??[]),
    'survey_status' => $r['status']??'',
    'loi_sec'       => $r['loi_seconds']??'',
    'country'       => $r['country']??'',
    'device'        => $r['device']??'',
    'source'        => $r['source']??'',
    'is_duplicate'  => $r['is_duplicate']??'',
    'quality_score' => $ev['quality_score']??'',
    'ev_speeder'    => isset($ev['is_speeder'])?($ev['is_speeder']?'YES':'NO'):'',
    'created_at'    => $r['created_at']??'',
  ];
},$bulk_results)) ?>;

function exportCSV(){
  const h=['UID','Status','Flags','Survey Status','LOI(sec)','Country','Device','Source','Is Duplicate','Quality Score','EV Speeder','Created At'];
  const rows=csvData.map(r=>[r.uid,r.status,r.flags,r.survey_status,r.loi_sec,r.country,r.device,r.source,r.is_duplicate,r.quality_score,r.ev_speeder,r.created_at].map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(','));
  const csv=[h.join(','),...rows].join('\n');
  const a=document.createElement('a');
  a.href='data:text/csv;charset=utf-8,\uFEFF'+encodeURIComponent(csv);
  a.download='uid_results_<?= date('Ymd_His') ?>.csv';
  a.click();
}
</script>

<?php endif; ?>
</div>
</div>

<!-- ══════════ TIMELINE ══════════ -->
<div class="pane" id="pane-timeline">
<div class="wrap">

<div class="card">
  <div class="card-title">📍 Respondent Timeline</div>
  <form method="GET" class="search-row">
    <input type="text" name="uid" id="tl-input" placeholder="UID daalo — e.g. abc1, SPEED_TEST_01" value="<?= htmlspecialchars($timeline_uid) ?>">
    <button type="submit" class="btn">Search →</button>
  </form>
</div>

<?php if($timeline_uid): ?>
<?php if(!$timeline_ev && empty($timeline_responses) && !$timeline_data): ?>
  <div class="card">
    <div class="not-found-msg">❓ UID "<strong><?= htmlspecialchars($timeline_uid) ?></strong>" — koi record nahi mila kisi bhi table mein.</div>
  </div>
<?php else: ?>

<!-- Quality Score Card -->
<?php if($timeline_ev && $timeline_ev['quality_score']):
  $qs  = $timeline_ev['quality_score'];
  $qsc = $qs>=80?'#16a34a':($qs>=60?'#b45309':'#dc2626');
  $loi_s = null;
  if (!empty($timeline_ev['loi_seconds'])) {
      $loi_s = $timeline_ev['loi_seconds'];
  } elseif (!empty($timeline_ev['end_time']) && !empty($timeline_ev['start_time'])) {
      $calc = strtotime($timeline_ev['end_time']) - strtotime($timeline_ev['start_time']);
      if ($calc > 0) $loi_s = $calc;
  }
?>
<div class="card" style="border-left:4px solid <?= $qsc ?>">
  <div style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:16px">
    <div>
      <div class="label" style="margin-bottom:6px">ExaVerify Quality Score</div>
      <div class="score-big" style="color:<?= $qsc ?>"><?= $qs ?><span style="font-size:16px;color:var(--muted)">/100</span></div>
    </div>
    <div class="kv-grid" style="flex:1;min-width:260px">
      <?php if($loi_s): ?><div class="kv"><div class="kv-key">LOI</div><div class="kv-val"><?= fmt_loi($loi_s) ?></div></div><?php endif; ?>
      <div class="kv"><div class="kv-key">Device</div><div class="kv-val"><?= htmlspecialchars($timeline_ev['device_type']??'—') ?></div></div>
      <div class="kv"><div class="kv-key">Country</div><div class="kv-val"><?= htmlspecialchars($timeline_ev['country']??'—') ?></div></div>
      <div class="kv"><div class="kv-key">Speeder</div><div class="kv-val" style="color:<?= $timeline_ev['is_speeder']?'#dc2626':'#16a34a' ?>"><?= $timeline_ev['is_speeder']?'YES':'NO' ?></div></div>
      <div class="kv"><div class="kv-key">Duplicate</div><div class="kv-val" style="color:<?= $timeline_ev['is_duplicate']?'#dc2626':'#16a34a' ?>"><?= $timeline_ev['is_duplicate']?'YES':'NO' ?></div></div>
      <div class="kv"><div class="kv-key">EV Status</div><div class="kv-val"><?= ucfirst($timeline_ev['ev_status']??'—') ?></div></div>
    </div>
  </div>
  <?php if(!empty($timeline_answers)): ?>
  <div style="margin-top:14px;border-top:1px solid var(--border);padding-top:12px">
    <div class="label" style="margin-bottom:8px">Pre-Survey Answers</div>
    <div class="kv-grid">
      <?php foreach($timeline_answers as $ans): ?>
      <div class="kv">
        <div class="kv-key"><?= htmlspecialchars($ans['question_key']) ?></div>
        <div class="kv-val"><?= htmlspecialchars($ans['answer_value']) ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<!-- Timeline -->
<div class="card">
  <div class="card-title">📍 Full Timeline — <span style="font-family:'Courier New',monospace;font-size:13px"><?= htmlspecialchars($timeline_uid) ?></span></div>
  <?php if(!empty($tl_map)): ?>
  <div style="font-size:11px;color:var(--muted);margin:-10px 0 14px;font-family:'Courier New',monospace">
    Raw: <?= htmlspecialchars($tl_map['original_uid']) ?> &nbsp;|&nbsp; Encrypted: <?= htmlspecialchars($tl_map['encrypted_uid']) ?>
  </div>
  <?php endif; ?>
  <div class="tl-wrap">

    <?php
    $entry_time = $timeline_ev['start_time'] ?? ($timeline_data['start_time'] ?? null);
    if($entry_time): ?>
    <div class="tl-item">
      <div class="tl-dot entry">1</div>
      <div class="tl-card">
        <div class="tl-title">🟢 Survey Entry</div>
        <div class="tl-time"><?= date('d M Y, H:i:s', strtotime($entry_time.' UTC')) ?> &nbsp;·&nbsp; <?= time_since($entry_time) ?></div>
        <div class="tl-meta">
          <?php if($timeline_ev): ?>
          <span>📱 <?= htmlspecialchars($timeline_ev['device_type']??'—') ?></span>
          <span>🌍 <?= htmlspecialchars(($timeline_ev['country']??'').(isset($timeline_ev['city'])&&$timeline_ev['city']?', '.$timeline_ev['city']:'')) ?></span>
          <span>🌐 <?= htmlspecialchars($timeline_ev['browser']??'—') ?></span>
          <span>🔗 <?= htmlspecialchars($timeline_ev['ip_address']??'—') ?></span>
          <?php elseif($timeline_data): ?>
          <span>📱 <?= htmlspecialchars($timeline_data['device']??'—') ?></span>
          <span>🔗 <?= htmlspecialchars($timeline_data['ip']??'—') ?></span>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <?php if(!empty($timeline_answers)): ?>
    <div class="tl-item">
      <div class="tl-dot presurvey">2</div>
      <div class="tl-card">
        <div class="tl-title">🟣 Pre-Survey Completed</div>
        <div class="tl-time">ExaVerify screening answers submitted</div>
        <div class="kv-grid">
          <?php foreach($timeline_answers as $ans): ?>
          <div class="kv">
            <div class="kv-key"><?= htmlspecialchars($ans['question_key']) ?></div>
            <div class="kv-val"><?= htmlspecialchars($ans['answer_value']) ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <?php $step = (!empty($timeline_answers)||$entry_time) ? 3 : 1;
    foreach($timeline_responses as $resp):
      $st = $resp['status'];
      $dot_class = in_array($st,['complete','terminate','quotafull','qc','quality']) ? $st : 'start';
      $icon = match(true) {
        $st==='complete'             => '✅',
        $st==='terminate'            => '🔴',
        $st==='quotafull'            => '🟡',
        in_array($st,['qc','quality'])=> '🟣',
        default                      => '⏳'
      };
    ?>
    <div class="tl-item">
      <div class="tl-dot <?= $dot_class ?>"><?= $step++ ?></div>
      <div class="tl-card">
        <div class="tl-title"><?= $icon ?> <?= ucfirst($resp['status']) ?></div>
        <div class="tl-time"><?= date('d M Y, H:i:s', strtotime($resp['created_at'].' UTC')) ?> &nbsp;·&nbsp; <?= time_since($resp['created_at']) ?></div>
        <div class="tl-meta">
          <?php if($resp['loi_seconds']): ?><span>⏱ LOI: <?= fmt_loi($resp['loi_seconds']) ?></span><?php endif; ?>
          <span>📱 <?= htmlspecialchars($resp['device']??'—') ?></span>
          <span>🌍 <?= htmlspecialchars($resp['country']??'—') ?></span>
          <span>📡 <?= htmlspecialchars($resp['source']??'—') ?></span>
          <?php if($resp['is_duplicate']): ?><span style="color:#dc2626;font-weight:700">⚠️ DUPLICATE</span><?php endif; ?>
          <?php if($resp['loi_seconds']&&$resp['loi_seconds']<180): ?><span style="color:#b45309;font-weight:700">⚡ SPEEDER</span><?php endif; ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>

    <?php if(!$entry_time && empty($timeline_answers) && empty($timeline_responses)): ?>
    <div class="not-found-msg">Koi timeline data nahi mila.</div>
    <?php endif; ?>

  </div>
</div>
<?php endif; ?>
<?php endif; ?>

</div>
</div>

<script>
// Tab switching
function switchTab(name, btn) {
  document.querySelectorAll('.pane').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(b => b.classList.remove('active'));
  document.getElementById('pane-' + name).classList.add('active');
  if (btn) btn.classList.add('active');
  else {
    const t = document.querySelector('.tab[onclick*="\''+name+'\'"]');
    if(t) t.classList.add('active');
  }
}

// Auto-switch to timeline if uid in URL
if (new URLSearchParams(window.location.search).get('uid')) {
  switchTab('timeline', null);
}

// UID live counter
const ta   = document.querySelector('textarea[name="uids"]');
const note = document.getElementById('uid-count-note');
if (ta && note) {
  const upd = () => {
    const n = ta.value.split('\n').filter(l => l.trim()).length;
    note.textContent = n > 0
      ? n + ' UIDs' + (n > 500 ? ' ⚠️ First 500 only process honge' : '')
      : '';
  };
  ta.addEventListener('input', upd);
  upd();
}
</script>
</body>
</html>
