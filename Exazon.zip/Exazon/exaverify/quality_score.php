<?php
// ============================================================
// Exazon Research — Quality Score Report
// File: hub/quality_score.php
// ============================================================
session_start();
define('DB_HOST','localhost');define('DB_NAME','u994909610_Exaverify');
define('DB_USER','u994909610_Exaverify');define('DB_PASS','Exaverify@8181');

// ── AUTH — shares the main dashboard's session (PIN + Team Login) ──
if (isset($_GET['logout'])) { session_destroy(); header('Location: index.php'); exit; }
if (empty($_SESSION['ex_auth']) || empty($_SESSION['ex_team_id'])) {
    header('Location: index.php'); exit;
}

function getDB(){static $p;if($p)return $p;$p=new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);return $p;}

define('SPD_LIMIT',180);
$pdo=getDB();

// Filters
$f_proj = $_GET['proj']??'';
$f_min  = intval($_GET['min']??0);
$f_max  = intval($_GET['max']??100);

// Load responses with quality score calculation
$where = "WHERE 1=1";
$params = [];
if($f_proj){ $where .= " AND survey_id=?"; $params[]=$f_proj; }

$stmt = $pdo->prepare("SELECT respondent as uid, survey_id, status, ip, device, country, city,
    loi_seconds, is_duplicate, client_name, source, created_at
    FROM survey_responses $where ORDER BY created_at DESC LIMIT 1000");
$stmt->execute($params);
$raw = $stmt->fetchAll();

// Calculate quality score per respondent
function calcScore($r){
    $score = 100;
    $reasons = [];
    // LOI score (40 pts)
    $loi = intval($r['loi_seconds']??0);
    if($loi > 0 && $loi < SPD_LIMIT){ $score -= 40; $reasons[] = "⚡ Speeder (LOI: ".intdiv($loi,60)."m ".($loi%60)."s)"; }
    elseif($loi === 0 || $loi === null){ $score -= 10; $reasons[] = "⏱ LOI not recorded"; }
    // Duplicate (30 pts)
    if($r['is_duplicate']??0){ $score -= 30; $reasons[] = "⚠️ Duplicate UID"; }
    // Device (10 pts)
    if(empty($r['device'])){ $score -= 5; $reasons[] = "📱 Device unknown"; }
    // Country (10 pts)
    if(empty($r['country'])){ $score -= 5; $reasons[] = "🌍 Country unknown"; }
    // Status bonus/penalty
    if($r['status']==='qc'||$r['status']==='quality'){ $score -= 15; $reasons[] = "🔍 QC Fail"; }
    return [max(0,min(100,$score)), $reasons];
}

$rows = [];
foreach($raw as $r){
    [$score,$reasons] = calcScore($r);
    if($score >= $f_min && $score <= $f_max) {
        $r['quality_score'] = $score;
        $r['score_reasons'] = $reasons;
        $rows[] = $r;
    }
}

// Export CSV
if(isset($_GET['export'])){
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="quality_scores_'.date('Ymd').'.csv"');
    $out = fopen('php://output','w');
    fputcsv($out,['UID','Survey ID','Status','Quality Score /100','LOI (sec)','LOI (min)','Duplicate','Device','Country','City','IP','Source','Timestamp','Issues']);
    foreach($rows as $r){
        $loi_min = $r['loi_seconds']?round($r['loi_seconds']/60,1).'m':'N/A';
        fputcsv($out,[$r['uid'],$r['survey_id'],$r['status'],$r['quality_score'],$r['loi_seconds']??'',$loi_min,$r['is_duplicate']?'YES':'NO',$r['device']??'',$r['country']??'',$r['city']??'',$r['ip']??'',$r['source']??'',date('d M Y H:i',strtotime($r['created_at'].' UTC')),implode('; ',$r['score_reasons'])]);
    }
    fclose($out); exit;
}

// Stats
$avg_score = count($rows)>0 ? round(array_sum(array_column($rows,'quality_score'))/count($rows),1) : 0;
$high  = count(array_filter($rows,fn($r)=>$r['quality_score']>=80));
$med   = count(array_filter($rows,fn($r)=>$r['quality_score']>=60&&$r['quality_score']<80));
$low   = count(array_filter($rows,fn($r)=>$r['quality_score']<60));

// Projects list
$projects=[];
try{$projects=$pdo->query("SELECT DISTINCT survey_id FROM survey_responses ORDER BY survey_id")->fetchAll(PDO::FETCH_COLUMN);}catch(Exception $e){}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Quality Score — Exazon Research</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--navy:#0a1628;--blue:#1b4fd8;--blue2:#3b82f6;--gold:#c8a84b;--green:#22c55e;--red:#ef4444;--yellow:#f59e0b;--purple:#8b5cf6;--off:#f0f4ff;--muted:#94a3b8}
body{font-family:'DM Sans',sans-serif;background:var(--off);color:#1e293b;min-height:100vh}
.nav{background:var(--navy);padding:0 24px;height:56px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(59,130,246,.2);position:sticky;top:0;z-index:100}
.nav-name{font-family:'Bebas Neue',sans-serif;font-size:15px;letter-spacing:2px;color:#fff}
.nav-tag{font-size:8px;letter-spacing:3px;text-transform:uppercase;color:var(--gold)}
.btn-sm{padding:5px 12px;border-radius:6px;font-size:10px;font-weight:600;letter-spacing:1px;text-transform:uppercase;cursor:pointer;border:none;text-decoration:none;display:inline-block}
.btn-blue{background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff}
.btn-green{background:linear-gradient(135deg,var(--green),#16a34a);color:#fff}
.btn-logout{background:rgba(255,255,255,.08);color:var(--muted);border:1px solid rgba(255,255,255,.1)}
.main{max-width:1200px;margin:0 auto;padding:24px 18px}
.sg4{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:18px}
.stat-card{background:#fff;border-radius:12px;padding:14px;border:1px solid #e2e8f0;text-align:center;box-shadow:0 1px 4px rgba(10,22,40,.05)}
.stat-num{font-family:'Bebas Neue',sans-serif;font-size:28px}
.stat-lbl{font-size:8px;letter-spacing:2px;text-transform:uppercase;color:var(--muted);margin-top:2px}
.filters-row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:14px}
.fsel,.finp{background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:7px 11px;font-family:'DM Sans',sans-serif;font-size:12px;color:#1e293b;outline:none}
.fsel:focus,.finp:focus{border-color:var(--blue2)}
.tbl-card{background:#fff;border-radius:12px;overflow:hidden;border:1px solid #e2e8f0;box-shadow:0 1px 4px rgba(10,22,40,.04)}
.tbl-head{background:var(--navy);padding:11px 16px;display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap}
.tbl-title{font-family:'Bebas Neue',sans-serif;font-size:13px;letter-spacing:2px;color:var(--gold)}
.tbl-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse}
th{padding:9px 12px;text-align:left;font-size:8px;letter-spacing:2px;text-transform:uppercase;color:#64748b;background:#f8faff;border-bottom:1px solid #e2e8f0;white-space:nowrap}
td{padding:9px 12px;font-size:12px;border-bottom:1px solid #f1f5f9;white-space:nowrap}
tr:hover td{background:#f8faff}
.score-badge{display:inline-flex;align-items:center;justify-content:center;width:42px;height:24px;border-radius:12px;font-weight:700;font-size:12px}
.score-high{background:rgba(34,197,94,.15);color:#16a34a}
.score-med{background:rgba(245,158,11,.15);color:#b45309}
.score-low{background:rgba(239,68,68,.15);color:#dc2626}
.score-bar-mini{width:60px;height:4px;background:#e2e8f0;border-radius:2px;overflow:hidden;margin-top:3px}
.score-bar-fill{height:100%;border-radius:2px}
.pill{display:inline-block;padding:2px 8px;border-radius:20px;font-size:10px;font-weight:600}
.pill.complete{background:rgba(34,197,94,.1);color:#16a34a;border:1px solid rgba(34,197,94,.3)}
.pill.terminate{background:rgba(100,116,139,.1);color:#475569;border:1px solid rgba(100,116,139,.3)}
.pill.qc,.pill.quality{background:rgba(139,92,246,.1);color:#7c3aed;border:1px solid rgba(139,92,246,.3)}
.pill.quotafull{background:rgba(245,158,11,.1);color:#b45309;border:1px solid rgba(245,158,11,.3)}
.reasons{font-size:9px;color:#94a3b8;margin-top:2px;max-width:200px;white-space:normal;line-height:1.4}
.formula-box{background:#fff;border-radius:12px;padding:16px;border:1px solid #e2e8f0;margin-bottom:16px}
.formula-row{display:flex;align-items:center;gap:12px;padding:8px 0;border-bottom:1px solid #f1f5f9;font-size:12px}
.formula-row:last-child{border:none}
.formula-pts{font-family:'Bebas Neue',sans-serif;font-size:16px;color:var(--red);min-width:50px}
@media(max-width:768px){.sg4{grid-template-columns:repeat(2,1fr)}}
</style>
</head>
<body>
<nav class="nav">
  <div><div class="nav-name">Exazon — Quality Score Report</div><div class="nav-tag">Per Respondent · Client Dispute Proof</div></div>
  <div style="display:flex;gap:8px;align-items:center">
    <a href="?<?= http_build_query(array_merge($_GET,['export'=>1])) ?>" class="btn-sm btn-green">⬇ Export CSV</a>
    <a href="index.php#qualityscore" target="_top" class="btn-sm btn-blue">← Dashboard</a>
    <a href="?logout=1" target="_top" class="btn-sm btn-logout">Logout</a>
  </div>
</nav>
<div class="main">

<!-- Stats -->
<div class="sg4">
  <div class="stat-card"><div class="stat-num" style="color:var(--blue)"><?= $avg_score ?>/100</div><div class="stat-lbl">Avg Quality Score</div></div>
  <div class="stat-card"><div class="stat-num" style="color:var(--green)"><?= $high ?></div><div class="stat-lbl">High ≥80 ✅</div></div>
  <div class="stat-card"><div class="stat-num" style="color:var(--yellow)"><?= $med ?></div><div class="stat-lbl">Medium 60-79 ⚠️</div></div>
  <div class="stat-card"><div class="stat-num" style="color:var(--red)"><?= $low ?></div><div class="stat-lbl">Low &lt;60 🚨</div></div>
</div>

<!-- Formula -->
<div class="formula-box" style="margin-bottom:16px">
  <div style="font-family:'Bebas Neue',sans-serif;font-size:13px;letter-spacing:2px;color:var(--navy);margin-bottom:10px">Quality Score Formula (Max 100)</div>
  <div class="formula-row"><span class="formula-pts">-40</span><span>⚡ <strong>Speeder</strong> — LOI under 3 minutes</span></div>
  <div class="formula-row"><span class="formula-pts">-30</span><span>⚠️ <strong>Duplicate UID</strong> — same respondent ID submitted again</span></div>
  <div class="formula-row"><span class="formula-pts">-15</span><span>🔍 <strong>Quality Fail</strong> — status = qc/quality</span></div>
  <div class="formula-row"><span class="formula-pts">-10</span><span>⏱ <strong>No LOI</strong> — entry time not recorded</span></div>
  <div class="formula-row"><span class="formula-pts">-5</span><span>📱 <strong>Device unknown</strong> — user agent missing</span></div>
  <div class="formula-row"><span class="formula-pts">-5</span><span>🌍 <strong>Country unknown</strong> — geo detection failed</span></div>
</div>

<!-- Filters -->
<div class="filters-row">
  <select class="fsel" id="fProj" onchange="applyFilters()">
    <option value="">All Projects</option>
    <?php foreach($projects as $pr): ?>
    <option value="<?= htmlspecialchars($pr) ?>" <?= $f_proj===$pr?'selected':'' ?>><?= htmlspecialchars($pr) ?></option>
    <?php endforeach; ?>
  </select>
  <select class="fsel" id="fRange" onchange="applyFilters()">
    <option value="">All Scores</option>
    <option value="high">High ≥80</option>
    <option value="med">Medium 60-79</option>
    <option value="low">Low &lt;60</option>
  </select>
  <select class="fsel" id="fStatus" onchange="filterTbl()">
    <option value="">All Status</option>
    <option value="complete">Complete</option>
    <option value="terminate">Terminate</option>
    <option value="qc">QC/Quality</option>
  </select>
  <input class="finp" id="fsrch" placeholder="Search UID, country..." oninput="filterTbl()" style="flex:1;min-width:160px">
</div>

<!-- Table -->
<div class="tbl-card">
  <div class="tbl-head">
    <div class="tbl-title">Quality Score — All Respondents</div>
    <div style="display:flex;gap:8px;align-items:center">
      <span style="font-size:10px;color:var(--muted)"><?= count($rows) ?> records</span>
      <a href="?export=1&proj=<?= urlencode($f_proj) ?>" class="btn-sm btn-green" style="font-size:9px">⬇ Export CSV</a>
    </div>
  </div>
  <div class="tbl-wrap">
  <table id="qTbl">
    <thead><tr><th>#</th><th>Quality Score</th><th>Respondent UID</th><th>Survey</th><th>Status</th><th>LOI</th><th>Dup</th><th>Device</th><th>Country</th><th>Issues</th><th>Date</th></tr></thead>
    <tbody>
    <?php foreach($rows as $i=>$r):
      $qs = $r['quality_score'];
      $qcls = $qs>=80?'score-high':($qs>=60?'score-med':'score-low');
      $qbar = $qs>=80?'#22c55e':($qs>=60?'#f59e0b':'#ef4444');
      $loi  = intval($r['loi_seconds']??0);
      $loi_s= $loi>0?(intdiv($loi,60).'m '.($loi%60).'s'):'—';
      $st   = ($r['status']==='quality')?'qc':$r['status'];
      $range= $qs>=80?'high':($qs>=60?'med':'low');
    ?>
    <tr data-status="<?= $st ?>" data-range="<?= $range ?>" data-s="<?= strtolower(htmlspecialchars($r['uid'].'|'.($r['country']??'').'|'.($r['survey_id']??''))) ?>">
      <td style="color:#94a3b8"><?= $i+1 ?></td>
      <td>
        <span class="score-badge <?= $qcls ?>"><?= $qs ?></span>
        <div class="score-bar-mini"><div class="score-bar-fill" style="width:<?= $qs ?>%;background:<?= $qbar ?>"></div></div>
      </td>
      <td style="font-family:monospace;font-size:11px"><?= htmlspecialchars($r['uid']) ?></td>
      <td><strong style="font-family:'Bebas Neue',sans-serif;color:var(--blue)"><?= htmlspecialchars($r['survey_id']) ?></strong></td>
      <td><span class="pill <?= $st ?>"><?= ucfirst($r['status']) ?></span></td>
      <td style="color:<?= $loi>0&&$loi<SPD_LIMIT?'#dc2626':($loi>0?'#16a34a':'#94a3b8') ?>"><?= $loi_s ?></td>
      <td><?= ($r['is_duplicate']??0)?'<span style="color:#dc2626;font-weight:700">DUP</span>':'<span style="color:#22c55e">✓</span>' ?></td>
      <td><?= htmlspecialchars($r['device']??'—') ?></td>
      <td><?= htmlspecialchars($r['country']??'—') ?></td>
      <td><div class="reasons"><?= implode('<br>',$r['score_reasons']) ?: '<span style="color:#22c55e">All OK ✅</span>' ?></div></td>
      <td style="font-size:10px;color:#94a3b8"><?= date('d M H:i',strtotime($r['created_at'].' UTC')) ?></td>
    </tr>
    <?php endforeach; if(empty($rows)): ?>
    <tr><td colspan="11" style="text-align:center;padding:28px;color:#94a3b8">No data found.</td></tr>
    <?php endif; ?>
    </tbody>
  </table>
  </div>
</div>
</div>
<script>
function applyFilters(){
  const proj=document.getElementById('fProj').value;
  const range=document.getElementById('fRange').value;
  const url=new URL(window.location);
  if(proj) url.searchParams.set('proj',proj); else url.searchParams.delete('proj');
  if(range==='high'){url.searchParams.set('min',80);url.searchParams.set('max',100);}
  else if(range==='med'){url.searchParams.set('min',60);url.searchParams.set('max',79);}
  else if(range==='low'){url.searchParams.set('min',0);url.searchParams.set('max',59);}
  else{url.searchParams.delete('min');url.searchParams.delete('max');}
  window.location=url;
}
function filterTbl(){
  const st=document.getElementById('fStatus').value;
  const s=document.getElementById('fsrch').value.toLowerCase();
  document.querySelectorAll('#qTbl tbody tr[data-status]').forEach(r=>{
    const ok=(!st||r.dataset.status===st)&&(!s||r.dataset.s.includes(s));
    r.style.display=ok?'':'none';
  });
}
</script>
</body>
</html>