<?php
// ============================================================
// EXAZON RESEARCH — Client Portal Dashboard
// File: hub/client/portal.php
// Read-only view — no pricing, no vendor, no fraud data
// ============================================================
session_start();
define('DB_HOST', 'localhost');
define('DB_NAME', 'u994909610_Exaverify');
define('DB_USER', 'u994909610_Exaverify');
define('DB_PASS', 'Exaverify@8181');

// Auth check
if (empty($_SESSION['client_auth']) || empty($_SESSION['client_id'])) {
    header('Location: login.php'); exit;
}

$client_name     = $_SESSION['client_name'] ?? 'Client';
$client_projects = $_SESSION['client_projects'] ?? '';

function getDB() {
    static $pdo;
    if ($pdo) return $pdo;
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
    return $pdo;
}

// Allowed projects array
$allowed = array_filter(array_map('trim', explode(',', $client_projects)));

if (empty($allowed)) {
    $no_projects = true;
} else {
    $no_projects = false;
}

// CSV Export (filtered to allowed projects only)
if (isset($_GET['export']) && !$no_projects) {
    $pdo = getDB();
    $esid = $_GET['esid'] ?? '';
    // Validate esid is in allowed list
    if ($esid && !in_array($esid, $allowed)) $esid = '';

    $placeholders = implode(',', array_fill(0, count($allowed), '?'));
    $where = "survey_id IN ($placeholders)";
    $params = $allowed;
    if ($esid) { $where .= ' AND survey_id=?'; $params[] = $esid; }

    $stmt = $pdo->prepare("SELECT survey_id, respondent, status, device, country, city, loi_seconds, created_at
        FROM survey_responses WHERE $where ORDER BY created_at DESC");
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="exazon_data_'.date('Ymd').'.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Survey ID','Respondent ID','Status','Device','Country','City','LOI (min)','Timestamp']);
    foreach ($rows as $r) {
        $r['loi_min'] = $r['loi_seconds'] > 0 ? round($r['loi_seconds']/60, 1).'m' : '-';
        fputcsv($out, [$r['survey_id'],$r['respondent'],$r['status'],$r['device'],$r['country'],$r['city'],$r['loi_min'],$r['created_at']]);
    }
    fclose($out); exit;
}

// Load data for allowed projects
$stats_all = [];
$projects_data = [];
$trend = [];
$countries = [];
$devices = [];

if (!$no_projects) {
    $pdo = getDB();
    $placeholders = implode(',', array_fill(0, count($allowed), '?'));

    // Per-project stats
    $stmt = $pdo->prepare("SELECT survey_id,
        COUNT(*) as total,
        SUM(status='complete')  as completes,
        SUM(status='terminate') as terminates,
        SUM(status='quotafull') as quotafull,
        SUM(status='qc' OR status='quality') as quality,
        ROUND(AVG(CASE WHEN status='complete' AND loi_seconds>0 THEN loi_seconds END)) as avg_loi,
        MIN(created_at) as first_response,
        MAX(created_at) as last_response
        FROM survey_responses WHERE survey_id IN ($placeholders)
        GROUP BY survey_id ORDER BY MAX(created_at) DESC");
    $stmt->execute($allowed);
    $projects_data = $stmt->fetchAll();

    // Overall totals
    $stmt2 = $pdo->prepare("SELECT
        COUNT(*) as total,
        SUM(status='complete')  as completes,
        SUM(status='terminate') as terminates,
        SUM(status='quotafull') as quotafull,
        SUM(status='qc' OR status='quality') as quality,
        ROUND(AVG(CASE WHEN status='complete' AND loi_seconds>0 THEN loi_seconds END)) as avg_loi
        FROM survey_responses WHERE survey_id IN ($placeholders)");
    $stmt2->execute($allowed);
    $stats_all = $stmt2->fetch();

    // Trend 7 days
    $stmt3 = $pdo->prepare("SELECT DATE(created_at) as day,
        SUM(status='complete') as c,
        SUM(status='terminate') as t,
        SUM(status='quotafull') as q
        FROM survey_responses
        WHERE survey_id IN ($placeholders) AND created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)
        GROUP BY DATE(created_at) ORDER BY day ASC");
    $stmt3->execute($allowed);
    $trend = $stmt3->fetchAll();

    // Country
    $stmt4 = $pdo->prepare("SELECT country, COUNT(*) as cnt FROM survey_responses
        WHERE survey_id IN ($placeholders) AND country!=''
        GROUP BY country ORDER BY cnt DESC LIMIT 8");
    $stmt4->execute($allowed);
    $countries = $stmt4->fetchAll();

    // Device
    $stmt5 = $pdo->prepare("SELECT device, COUNT(*) as cnt FROM survey_responses
        WHERE survey_id IN ($placeholders) AND device!=''
        GROUP BY device ORDER BY cnt DESC");
    $stmt5->execute($allowed);
    $devices = $stmt5->fetchAll();
}

$ir_overall = ($stats_all['completes']+$stats_all['terminates']) > 0
    ? round($stats_all['completes']/($stats_all['completes']+$stats_all['terminates'])*100,1) : 0;

function fmt_loi($s) {
    if (!$s || intval($s)===0) return '—';
    return intdiv($s,60).'m '.($s%60).'s';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="refresh" content="120">
<title>Exazon Research — <?= htmlspecialchars($client_name) ?> Portal</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--navy:#0a1628;--navy2:#112040;--blue:#1b4fd8;--blue2:#3b82f6;--gold:#c8a84b;--gold2:#e6c96a;--green:#22c55e;--red:#ef4444;--yellow:#f59e0b;--purple:#8b5cf6;--teal:#14b8a6;--muted:#94a3b8;--off:#f0f4ff}
body{font-family:'DM Sans',sans-serif;background:var(--off);color:#1e293b;min-height:100vh}

/* NAV */
.nav{background:var(--navy);padding:0 28px;height:58px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(59,130,246,0.2);position:sticky;top:0;z-index:100}
.nav-left{display:flex;align-items:center;gap:10px}
.nav-logo{width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#1b4fd8,#3b82f6);display:flex;align-items:center;justify-content:center;font-size:16px;color:#fff;flex-shrink:0}
.nav-name{font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:2px;color:#fff}
.nav-tag{font-size:8px;letter-spacing:3px;text-transform:uppercase;color:var(--gold)}
.nav-right{display:flex;align-items:center;gap:10px}
.nav-client{font-size:12px;color:var(--muted)}
.nav-client span{color:#fff;font-weight:600}
.live-dot{width:7px;height:7px;border-radius:50%;background:var(--green);animation:pulse 2s infinite;display:inline-block;margin-right:5px}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}
.btn-sm{padding:7px 14px;border-radius:6px;font-size:11px;font-weight:600;letter-spacing:1px;text-transform:uppercase;cursor:pointer;border:none;text-decoration:none;display:inline-block}
.btn-export{background:linear-gradient(135deg,var(--green),#16a34a);color:#fff}
.btn-logout{background:rgba(255,255,255,0.08);color:var(--muted);border:1px solid rgba(255,255,255,0.1)}

/* MAIN */
.main{max-width:1200px;margin:0 auto;padding:24px 20px}

/* WELCOME */
.welcome-card{background:linear-gradient(135deg,var(--navy),#1a3a6b);border-radius:14px;padding:22px 28px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px}
.welcome-title{font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:2px;color:#fff}
.welcome-sub{font-size:12px;color:rgba(160,190,255,0.7);margin-top:3px}
.refresh-info{font-size:10px;color:rgba(100,140,220,0.5);letter-spacing:1px}

/* STATS */
.stats-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin-bottom:20px}
.stat-card{background:#fff;border-radius:12px;padding:16px;border:1px solid #e2e8f0;box-shadow:0 1px 6px rgba(10,22,40,0.05);text-align:center}
.stat-num{font-family:'Bebas Neue',sans-serif;font-size:30px;letter-spacing:1px}
.stat-num.green{color:var(--green)}.stat-num.red{color:var(--red)}.stat-num.yellow{color:var(--yellow)}.stat-num.purple{color:var(--purple)}.stat-num.teal{color:var(--teal)}
.stat-lbl{font-size:9px;letter-spacing:2px;text-transform:uppercase;color:var(--muted);margin-top:3px}

/* CHARTS */
.charts-row{display:grid;grid-template-columns:2fr 1fr 1fr;gap:14px;margin-bottom:20px}
.chart-card{background:#fff;border-radius:12px;padding:18px;border:1px solid #e2e8f0;box-shadow:0 1px 6px rgba(10,22,40,0.04)}
.chart-title{font-family:'Bebas Neue',sans-serif;font-size:13px;letter-spacing:2px;color:var(--navy);margin-bottom:14px}

/* PROJECTS */
.section-title{font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:2px;color:var(--navy);margin-bottom:12px}
.projects-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px;margin-bottom:20px}
.proj-card{background:#fff;border-radius:12px;padding:18px;border:1px solid #e2e8f0;box-shadow:0 1px 6px rgba(10,22,40,0.04)}
.proj-id{font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:2px;color:var(--blue);margin-bottom:8px}
.proj-stats{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:8px}
.proj-stat{font-size:12px;color:#64748b}
.proj-stat span{font-weight:600;color:#1e293b}
.proj-bar{height:5px;background:#e2e8f0;border-radius:3px;overflow:hidden;margin-bottom:6px}
.proj-bar-fill{height:100%;background:linear-gradient(90deg,var(--blue),var(--blue2));border-radius:3px}
.proj-cr{font-size:12px;font-weight:600;color:var(--green);margin-bottom:4px}
.proj-loi{font-size:11px;color:#64748b;margin-bottom:4px}
.proj-dates{font-size:9px;color:var(--muted);margin-top:4px}
.proj-export{display:inline-block;margin-top:8px;padding:5px 12px;background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff;border-radius:6px;font-size:10px;font-weight:600;letter-spacing:1px;text-decoration:none;text-transform:uppercase}

/* STATUS PILLS */
.pill{display:inline-flex;align-items:center;gap:4px;border-radius:20px;padding:2px 9px;font-size:10px;font-weight:600}
.pill::before{content:'';width:5px;height:5px;border-radius:50%;flex-shrink:0}
.pill.complete{background:rgba(34,197,94,0.1);color:#16a34a;border:1px solid rgba(34,197,94,0.3)}.pill.complete::before{background:var(--green)}
.pill.terminate{background:rgba(100,116,139,0.1);color:#475569;border:1px solid rgba(100,116,139,0.3)}.pill.terminate::before{background:#64748b}
.pill.quotafull{background:rgba(245,158,11,0.1);color:#b45309;border:1px solid rgba(245,158,11,0.3)}.pill.quotafull::before{background:var(--yellow)}

/* NO PROJECTS */
.empty-card{background:#fff;border-radius:12px;padding:48px;text-align:center;border:1px solid #e2e8f0;color:#94a3b8}

/* RESPONSIVE */
@media(max-width:900px){.stats-grid{grid-template-columns:repeat(3,1fr)}.charts-row{grid-template-columns:1fr}}
@media(max-width:600px){.stats-grid{grid-template-columns:repeat(2,1fr)}}

/* FOOTER */
.portal-footer{text-align:center;font-size:11px;color:#94a3b8;padding-bottom:24px}
.confidential-banner{background:rgba(239,68,68,0.04);border:1px solid rgba(239,68,68,0.15);border-radius:8px;padding:8px 14px;font-size:11px;color:#94a3b8;text-align:center;margin-bottom:20px}
</style>
</head>
<body>

<nav class="nav">
  <div class="nav-left">
    <div class="nav-logo">🔬</div>
    <div>
      <div class="nav-name">Exazon Research</div>
      <div class="nav-tag">Client Portal</div>
    </div>
  </div>
  <div class="nav-right">
    <span class="nav-client">Welcome, <span><?= htmlspecialchars($client_name) ?></span></span>
    <span style="font-size:10px;color:var(--muted)"><span class="live-dot"></span>Live</span>
    <?php if (!$no_projects): ?>
    <a href="?export=csv" class="btn-sm btn-export">⬇ CSV</a>
    <?php endif; ?>
    <a href="logout.php" class="btn-sm btn-logout">Logout</a>
  </div>
</nav>

<div class="main">

  <!-- WELCOME -->
  <div class="welcome-card">
    <div>
      <div class="welcome-title">📊 <?= htmlspecialchars($client_name) ?> — Live Dashboard</div>
      <div class="welcome-sub">Real-time survey data · Read-only access · <?= date('d M Y') ?></div>
    </div>
    <div class="refresh-info">🔄 Auto-refreshes every 2 minutes</div>
  </div>

  <div class="confidential-banner">🔒 This data is confidential and intended only for <?= htmlspecialchars($client_name) ?>. Do not share or distribute.</div>

  <?php if ($no_projects): ?>
  <div class="empty-card">
    <div style="font-size:40px;margin-bottom:16px">📋</div>
    <div style="font-size:16px;font-weight:600;color:#1e293b;margin-bottom:8px">No Projects Assigned</div>
    <div style="font-size:13px">Please contact Exazon Research to get your projects assigned to this account.</div>
    <div style="margin-top:12px"><a href="mailto:info@exazonresearch.com" style="color:var(--blue);font-size:13px">info@exazonresearch.com</a></div>
  </div>

  <?php else: ?>

  <!-- OVERALL STATS -->
  <div class="stats-grid">
    <div class="stat-card"><div class="stat-num" style="color:var(--navy)"><?= $stats_all['total']??0 ?></div><div class="stat-lbl">Total Responses</div></div>
    <div class="stat-card"><div class="stat-num green"><?= $stats_all['completes']??0 ?></div><div class="stat-lbl">Completes</div></div>
    <div class="stat-card"><div class="stat-num red"><?= $stats_all['terminates']??0 ?></div><div class="stat-lbl">Terminates</div></div>
    <div class="stat-card"><div class="stat-num yellow"><?= $stats_all['quotafull']??0 ?></div><div class="stat-lbl">Quota Full</div></div>
    <div class="stat-card"><div class="stat-num teal"><?= $ir_overall ?>%</div><div class="stat-lbl">Incidence Rate</div></div>
  </div>

  <!-- CHARTS -->
  <div class="charts-row">
    <div class="chart-card">
      <div class="chart-title">Daily Trend — Last 7 Days</div>
      <canvas id="trendChart" height="110"></canvas>
    </div>
    <div class="chart-card">
      <div class="chart-title">Country Split</div>
      <canvas id="countryChart" height="160"></canvas>
    </div>
    <div class="chart-card">
      <div class="chart-title">Device Split</div>
      <canvas id="deviceChart" height="160"></canvas>
    </div>
  </div>

  <!-- PROJECTS -->
  <div class="section-title">Your Projects</div>
  <div class="projects-grid">
  <?php foreach ($projects_data as $p):
    $cr   = $p['total']>0 ? round($p['completes']/$p['total']*100) : 0;
    $ir_p = ($p['completes']+$p['terminates'])>0 ? round($p['completes']/($p['completes']+$p['terminates'])*100,1) : 0;
  ?>
  <div class="proj-card">
    <div class="proj-id"><?= htmlspecialchars($p['survey_id']) ?></div>
    <div class="proj-stats">
      <div class="proj-stat">Total: <span><?= $p['total'] ?></span></div>
      <div class="proj-stat"><span style="color:var(--green)">✓</span> <span><?= $p['completes'] ?></span></div>
      <div class="proj-stat"><span style="color:var(--red)">✗</span> <span><?= $p['terminates'] ?></span></div>
      <div class="proj-stat"><span style="color:var(--yellow)">⚠</span> <span><?= $p['quotafull'] ?></span></div>
    </div>
    <div class="proj-cr">CR: <?= $cr ?>% &nbsp;·&nbsp; <span style="color:var(--teal)">IR: <?= $ir_p ?>%</span></div>
    <div class="proj-bar"><div class="proj-bar-fill" style="width:<?= $cr ?>%"></div></div>
    <div class="proj-loi">⏱ Avg LOI: <?= fmt_loi($p['avg_loi']) ?></div>
    <div class="proj-dates">
      First: <?= date('d M Y', strtotime($p['first_response'].' UTC')) ?> &nbsp;·&nbsp;
      Last: <?= date('d M H:i', strtotime($p['last_response'].' UTC')) ?>
    </div>
    <a href="?export=csv&esid=<?= urlencode($p['survey_id']) ?>" class="proj-export">⬇ Download Data</a>
  </div>
  <?php endforeach; ?>
  </div>

  <?php endif; ?>

  <div class="portal-footer">
    © 2026 Exazon Research LLP &nbsp;·&nbsp; Client Portal &nbsp;·&nbsp; <?= date('d M Y H:i:s') ?> IST
    <br><span style="font-size:10px">Data is confidential. Unauthorized sharing is prohibited.</span>
  </div>

</div>

<script>
const trend    = <?= json_encode($trend) ?>;
const countries= <?= json_encode($countries) ?>;
const devices  = <?= json_encode($devices) ?>;

function makeChart(id,type,labels,datasets,opts={}){
  const ctx=document.getElementById(id); if(!ctx)return;
  new Chart(ctx,{type,data:{labels,datasets},options:{responsive:true,plugins:{legend:{position:'bottom',labels:{font:{size:10},boxWidth:10}}},...opts}});
}

makeChart('trendChart','line',
  trend.length ? trend.map(d=>d.day) : ['Today'],
  [
    {label:'Complete', data:trend.map(d=>parseInt(d.c)||0),borderColor:'#22c55e',backgroundColor:'rgba(34,197,94,0.1)',tension:0.4,fill:true,pointRadius:4},
    {label:'Terminate',data:trend.map(d=>parseInt(d.t)||0),borderColor:'#ef4444',backgroundColor:'rgba(239,68,68,0.05)',tension:0.4,fill:true,pointRadius:4},
    {label:'Quota',   data:trend.map(d=>parseInt(d.q)||0),borderColor:'#f59e0b',backgroundColor:'rgba(245,158,11,0.05)',tension:0.4,fill:true,pointRadius:4},
  ],
  {scales:{x:{ticks:{font:{size:9}}},y:{ticks:{font:{size:10}},beginAtZero:true}}}
);

makeChart('countryChart','doughnut',
  countries.length ? countries.map(c=>c.country) : ['No data'],
  [{data:countries.length ? countries.map(c=>parseInt(c.cnt)||0) : [1],
    backgroundColor:['#1b4fd8','#3b82f6','#22c55e','#f59e0b','#8b5cf6','#ef4444','#14b8a6','#c8a84b'],borderWidth:0}],
  {cutout:'60%'}
);

makeChart('deviceChart','doughnut',
  devices.length ? devices.map(d=>d.device) : ['No data'],
  [{data:devices.length ? devices.map(d=>parseInt(d.cnt)||0) : [1],
    backgroundColor:['#1b4fd8','#3b82f6','#c8a84b'],borderWidth:0}],
  {cutout:'60%'}
);
</script>
</body>
</html>
