<?php
// ============================================================
// EXAZON RESEARCH — Third Party Dashboard v3
// File: public_html/tp_dashboard.php
// v3: Add Project tab + survey_responses sync + all v2 features intact
// ============================================================

$DASHBOARD_PASSWORD = "exazon2026";

session_start();
if (isset($_POST['pass'])) {
    if ($_POST['pass'] === $DASHBOARD_PASSWORD) $_SESSION['tp_auth'] = true;
    else $error = "Wrong password!";
}
if (isset($_GET['logout'])) { session_destroy(); header("Location: tp_dashboard.php"); exit; }
if (!isset($_SESSION['tp_auth'])) { ?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><title>Exazon — TP Login</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{min-height:100vh;background:#0a1628;display:flex;align-items:center;justify-content:center;font-family:'DM Sans',sans-serif}
.card{background:rgba(8,20,45,.95);border:1px solid rgba(30,100,255,.2);border-radius:20px;padding:48px 44px;width:360px;text-align:center;backdrop-filter:blur(12px)}
h2{font-family:'Bebas Neue',sans-serif;color:#e8f0ff;font-size:22px;letter-spacing:2px;margin-bottom:6px}
p{font-size:13px;color:rgba(160,190,255,.5);margin-bottom:28px}
input{width:100%;padding:12px 16px;background:rgba(20,50,120,.3);border:1px solid rgba(30,100,255,.2);border-radius:10px;color:#e8f0ff;font-size:14px;outline:none;margin-bottom:14px;text-align:center;letter-spacing:4px}
input:focus{border-color:rgba(30,100,255,.5)}
button{width:100%;padding:13px;background:linear-gradient(135deg,#1e3fa0,#3b6ff5);border:none;border-radius:10px;color:#fff;font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:2px;cursor:pointer}
.err{color:#ff6b6b;font-size:13px;margin-bottom:12px}
.brand{margin-top:20px;font-size:10px;color:rgba(255,255,255,.2)}
</style></head><body>
<div class="card">
  <h2>TP Dashboard</h2>
  <p>Third Party Survey Panel</p>
  <?php if(isset($error)) echo '<p class="err">'.$error.'</p>'; ?>
  <form method="POST">
    <input type="password" name="pass" placeholder="Password" autofocus>
    <button type="submit">LOGIN</button>
  </form>
  <div class="brand">© 2026 Exazon Research LLP</div>
</div></body></html>
<?php exit; } ?>
<?php

// ── DB Connection ─────────────────────────────────────────────
$pdo = null;
$has_mysql = false;
try {
    $pdo = new PDO("mysql:host=localhost;dbname=u994909610_Exaverify;charset=utf8mb4",
        'u994909610_Exaverify', 'Exaverify@8181',
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
    $has_mysql = true;

    // Ensure surveys table has all needed columns
    $pdo->exec("CREATE TABLE IF NOT EXISTS `surveys` (
        `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `sid`         VARCHAR(50)  NOT NULL UNIQUE,
        `name`        VARCHAR(200) NOT NULL,
        `survey_url`  TEXT,
        `type`        VARCHAR(20)  DEFAULT 'thirdparty',
        `client`      VARCHAR(100) DEFAULT '',
        `target`      INT UNSIGNED DEFAULT 0,
        `vendor_name` VARCHAR(100) DEFAULT '',
        `cpi_client`  DECIMAL(10,2) DEFAULT 0.00,
        `cpi_vendor`  DECIMAL(10,2) DEFAULT 0.00,
        `encrypt_uid` TINYINT(1)   DEFAULT 1,
        `is_active`   TINYINT(1)   DEFAULT 1,
        `created_at`  DATETIME     DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_sid (`sid`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Add missing columns if surveys table existed before
    $cols_to_add = [
        'target'      => "ALTER TABLE surveys ADD COLUMN target INT UNSIGNED DEFAULT 0",
        'vendor_name' => "ALTER TABLE surveys ADD COLUMN vendor_name VARCHAR(100) DEFAULT ''",
        'cpi_client'  => "ALTER TABLE surveys ADD COLUMN cpi_client DECIMAL(10,2) DEFAULT 0.00",
        'cpi_vendor'  => "ALTER TABLE surveys ADD COLUMN cpi_vendor DECIMAL(10,2) DEFAULT 0.00",
        'encrypt_uid' => "ALTER TABLE surveys ADD COLUMN encrypt_uid TINYINT(1) DEFAULT 1",
    ];
    $existing_cols = $pdo->query("SHOW COLUMNS FROM surveys")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($cols_to_add as $col => $sql) {
        if (!in_array($col, $existing_cols)) { try { $pdo->exec($sql); } catch(Exception $e){} }
    }
} catch(Exception $e) { $has_mysql = false; }

// ── Handle Actions (Add/Edit/Toggle Project) ──────────────────
$action_msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $has_mysql) {

    if ($_POST['action'] === 'add_project') {
        $nsid    = preg_replace('/[^A-Z0-9_-]/', '', strtoupper(trim($_POST['p_sid']??'')));
        $nname   = trim($_POST['p_name']??'');
        $nurl    = trim($_POST['p_url']??'');
        $nclient = trim($_POST['p_client']??'');
        $nvendor = trim($_POST['p_vendor']??'');
        $ntarget = intval($_POST['p_target']??0);
        $ncpi_c  = floatval($_POST['p_cpi_client']??0);
        $ncpi_v  = floatval($_POST['p_cpi_vendor']??0);
        $ntype   = $_POST['p_type'] ?? 'thirdparty';
        $nencrypt = isset($_POST['p_encrypt_uid']) ? 1 : 0;

        if ($nsid && $nname) {
            try {
                $pdo->prepare("INSERT INTO surveys (sid,name,survey_url,type,client,vendor_name,target,cpi_client,cpi_vendor,encrypt_uid,is_active)
                    VALUES (?,?,?,?,?,?,?,?,?,?,1)
                    ON DUPLICATE KEY UPDATE
                    name=VALUES(name),survey_url=VALUES(survey_url),type=VALUES(type),
                    client=VALUES(client),vendor_name=VALUES(vendor_name),
                    target=VALUES(target),cpi_client=VALUES(cpi_client),cpi_vendor=VALUES(cpi_vendor),
                    is_active=1")
                ->execute([$nsid,$nname,$nurl,$ntype,$nclient,$nvendor,$ntarget,$ncpi_c,$ncpi_v,$nencrypt]);
                $action_msg = "success:Project <strong>{$nsid}</strong> added/updated successfully!";
            } catch(Exception $e) {
                $action_msg = "error:DB Error: " . htmlspecialchars($e->getMessage());
            }
        } else {
            $action_msg = "error:Project ID and Name are required.";
        }
    }

    if ($_POST['action'] === 'toggle_project') {
        $tsid  = $_POST['t_sid'] ?? '';
        $tact  = $_POST['t_active'] ?? '1';
        if ($tsid) {
            $pdo->prepare("UPDATE surveys SET is_active=? WHERE sid=?")->execute([$tact,$tsid]);
            $action_msg = "success:Project {$tsid} " . ($tact ? "activated." : "paused.");
        }
    }

    if ($_POST['action'] === 'delete_project') {
        $dsid = $_POST['d_sid'] ?? '';
        if ($dsid) {
            $pdo->prepare("DELETE FROM surveys WHERE sid=? AND type='thirdparty'")->execute([$dsid]);
            $action_msg = "success:Project {$dsid} deleted.";
        }
    }

    if ($_POST['action'] === 'uid_lookup_ajax') {
        header('Content-Type: application/json');
        $q     = trim($_POST['q'] ?? '');
        $stype = $_POST['stype'] ?? 'both';
        $results = [];
        if ($q) {
            try {
                if ($stype === 'original') {
                    $stmt = $pdo->prepare("SELECT original_uid, encrypted_uid, sid, source FROM uid_mapping WHERE original_uid LIKE ? LIMIT 50");
                    $stmt->execute(["%{$q}%"]);
                } elseif ($stype === 'encrypted') {
                    $stmt = $pdo->prepare("SELECT original_uid, encrypted_uid, sid, source FROM uid_mapping WHERE encrypted_uid LIKE ? LIMIT 50");
                    $stmt->execute(["%{$q}%"]);
                } else {
                    $stmt = $pdo->prepare("SELECT original_uid, encrypted_uid, sid, source FROM uid_mapping WHERE original_uid LIKE ? OR encrypted_uid LIKE ? LIMIT 50");
                    $stmt->execute(["%{$q}%", "%{$q}%"]);
                }
                $results = $stmt->fetchAll();
            } catch(Exception $e) {
                echo json_encode(['error' => $e->getMessage()]);
                exit;
            }
        }
        echo json_encode(['results' => $results, 'count' => count($results)]);
        exit;
    }

    if ($_POST['action'] === 'delete_tp_responses') {
        $ids = $_POST['del_ids'] ?? [];
        if (!empty($ids)) {
            $ids = array_map('intval', $ids);
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $pdo->prepare("DELETE FROM survey_responses WHERE id IN ($placeholders) AND source='thirdparty'")->execute($ids);
            $action_msg = "success:" . count($ids) . " response(s) deleted.";
        }
    }
}

if (isset($_POST['delete_csv_rows'])) {
    $del_uids  = $_POST['del_uids']  ?? [];
    $del_times = $_POST['del_times'] ?? [];
    $log_file_del = __DIR__ . "/tp_logs/survey_log.csv";
    if (!empty($del_uids) && file_exists($log_file_del)) {
        $all_lines = file($log_file_del, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $header    = array_shift($all_lines);
        $new_lines = [];
        foreach ($all_lines as $line) {
            $p = str_getcsv($line);
            $rt = $p[0] ?? ''; $ru = $p[3] ?? '';
            $found = false;
            for ($i = 0; $i < count($del_uids); $i++) {
                if (($del_times[$i] ?? '') === $rt && ($del_uids[$i] ?? '') === $ru) { $found = true; break; }
            }
            if (!$found) $new_lines[] = $line;
        }
        file_put_contents($log_file_del, $header . "\n" . implode("\n", $new_lines) . "\n");
    }
    header('Location: tp_dashboard.php'); exit;
}

// ── Load all TP surveys from DB ───────────────────────────────
$tp_surveys = [];
if ($has_mysql) {
    try {
        $tp_surveys = $pdo->query("SELECT s.*,
            COUNT(sr.id) as total_responses,
            SUM(sr.status='complete') as completes,
            SUM(sr.status='terminate') as terminates,
            SUM(sr.status='quotafull') as quotafull,
            SUM(sr.is_duplicate=1) as dups,
            ROUND(AVG(CASE WHEN sr.status='complete' AND sr.loi_seconds>0 THEN sr.loi_seconds END)) as avg_loi,
            MAX(sr.created_at) as last_response
            FROM surveys s
            LEFT JOIN survey_responses sr ON sr.survey_id=s.sid AND sr.source='thirdparty'
            WHERE s.type='thirdparty'
            GROUP BY s.id ORDER BY s.created_at DESC")->fetchAll();
    } catch(Exception $e){}
}


// ── Load CSV Log ──────────────────────────────────────────────
$log_file = __DIR__ . "/tp_logs/survey_log.csv";
$rows = [];
if (file_exists($log_file)) {
    $lines = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    array_shift($lines);
    foreach ($lines as $l) {
        $p = str_getcsv($l);
        if (count($p) >= 5) {
            $rows[] = [
                'time'   => $p[0] ?? '',
                'sid'    => $p[1] ?? '',
                'survey' => $p[2] ?? '',
                'uid'    => $p[3] ?? '',
                'ip'     => $p[4] ?? '',
                'device' => $p[5] ?? 'unknown',
                'type'   => $p[6] ?? 'thirdparty',
            ];
        }
    }
}
$rows = array_reverse($rows);

// ── MySQL rows (source=thirdparty) ────────────────────────────
$mysql_rows = [];
if ($has_mysql) {
    try {
        $mysql_rows = $pdo->query("SELECT id, survey_id as sid, respondent as uid, status,
            source, client_name, ip, device, country, city, loi_seconds, is_duplicate, created_at as time
            FROM survey_responses WHERE source='thirdparty' ORDER BY created_at DESC LIMIT 500")->fetchAll();
    } catch(Exception $e){}
}

// ── Stats from CSV ────────────────────────────────────────────
$total      = count($rows);
$today_d    = date("Y-m-d");
$yesterday_d= date("Y-m-d", strtotime("-1 day"));
$today_cnt  = count(array_filter($rows, fn($r)=>str_starts_with($r['time'],$today_d)));
$yest_cnt   = count(array_filter($rows, fn($r)=>str_starts_with($r['time'],$yesterday_d)));
$total_uids = count(array_unique(array_column($rows,'uid')));
$unique_ips = count(array_unique(array_column($rows,'ip')));
$dev_counts = [];
foreach($rows as $r) { $d=$r['device']?:'unknown'; $dev_counts[$d]=($dev_counts[$d]??0)+1; }

// ── Projects from CSV ─────────────────────────────────────────
$projects = [];
foreach ($rows as $r) {
    $sid = $r['sid'];
    if (!isset($projects[$sid])) {
        $projects[$sid] = ['sid'=>$sid,'name'=>$r['survey'],'count'=>0,'uids'=>[],'ips'=>[],'devices'=>[],'first'=>$r['time'],'last'=>$r['time'],'today'=>0,'rows'=>[]];
    }
    $p = &$projects[$sid];
    $p['count']++; $p['uids'][]=$r['uid']; $p['ips'][]=$r['ip']; $p['devices'][]=$r['device'];
    if($r['time']<$p['first']) $p['first']=$r['time'];
    if($r['time']>$p['last'])  $p['last']=$r['time'];
    if(str_starts_with($r['time'],$today_d)) $p['today']++;
    $p['rows'][]=$r;
}
foreach($projects as &$p) {
    $p['unique_uids']=count(array_unique($p['uids']));
    $p['unique_ips']=count(array_unique($p['ips']));
    $dc=array_count_values($p['devices']); arsort($dc);
    $p['top_device']=key($dc)?:'unknown';
}
unset($p);
uasort($projects,fn($a,$b)=>strcmp($b['last'],$a['last']));
$total_surveys=count($projects);

// ── Vendor Scorecard ──────────────────────────────────────────
$vendor_scores=[];
if($has_mysql){
    try{
        $vendor_scores=$pdo->query("SELECT COALESCE(NULLIF(source,''),'unknown') as vendor,
            COUNT(*) as total,SUM(status='complete') as completes,SUM(status='terminate') as terminates,
            SUM(is_duplicate=1) as dups,
            SUM(CASE WHEN loi_seconds IS NOT NULL AND loi_seconds>0 AND loi_seconds<180 THEN 1 ELSE 0 END) as speeders,
            ROUND(AVG(CASE WHEN status='complete' AND loi_seconds IS NOT NULL AND loi_seconds>0 THEN loi_seconds END)) as avg_loi,
            COUNT(DISTINCT country) as countries
            FROM survey_responses WHERE source='thirdparty'
            GROUP BY source ORDER BY total DESC LIMIT 20")->fetchAll();
    }catch(Exception $e){}
}

// ── Country breakdown ─────────────────────────────────────────
$country_counts=[];
if($has_mysql){
    try{
        $cc=$pdo->query("SELECT country,COUNT(*) as cnt FROM survey_responses
            WHERE source='thirdparty' AND country!='' GROUP BY country ORDER BY cnt DESC LIMIT 10")->fetchAll();
        foreach($cc as $c) $country_counts[$c['country']]=$c['cnt'];
    }catch(Exception $e){}
}

// ── LOI stats ─────────────────────────────────────────────────
$loi_stats=['avg'=>null,'min'=>null,'speeders'=>0];
if($has_mysql){
    try{
        $loi_stats=$pdo->query("SELECT
            ROUND(AVG(CASE WHEN status='complete' AND loi_seconds IS NOT NULL AND loi_seconds>0 THEN loi_seconds END)) as avg_loi,
            MIN(CASE WHEN status='complete' AND loi_seconds IS NOT NULL AND loi_seconds>0 THEN loi_seconds END) as min_loi,
            SUM(CASE WHEN loi_seconds IS NOT NULL AND loi_seconds>0 AND loi_seconds<180 THEN 1 ELSE 0 END) as speeders
            FROM survey_responses WHERE source='thirdparty'")->fetch();
    }catch(Exception $e){}
}

// ── Trend ─────────────────────────────────────────────────────
$trend=[];
for($i=6;$i>=0;$i--){
    $day=date("Y-m-d",strtotime("-{$i} days"));
    $trend[]=['day'=>date("D",strtotime($day)),'cnt'=>count(array_filter($rows,fn($r)=>str_starts_with($r['time'],$day)))];
}
$maxTrend=max(array_column($trend,'cnt')?:[1]);

// ── Filters ───────────────────────────────────────────────────
$filter_sid=$_GET['sid']??'';
$filter_uid=$_GET['uid']??'';
$filtered=$rows;
if($filter_sid) $filtered=array_filter($filtered,fn($r)=>$r['sid']===$filter_sid);
if($filter_uid) $filtered=array_filter($filtered,fn($r)=>stripos($r['uid'],$filter_uid)!==false);
$filtered=array_values($filtered);

// ── CSV Export ────────────────────────────────────────────────
if($_GET['export']??false){
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="exazon_tp_'.date('Ymd').'.csv"');
    echo "Time,Survey ID,Survey Name,UID,IP,Device,Type\n";
    foreach($filtered as $r)
        echo '"'.$r['time'].'","'.$r['sid'].'","'.$r['survey'].'","'.$r['uid'].'","'.$r['ip'].'","'.$r['device'].'","'.$r['type'].'"'."\n";
    exit;
}

// ── Helpers ───────────────────────────────────────────────────
function timeSince($t){$d=time()-strtotime($t);if($d<60)return $d.'s ago';if($d<3600)return intdiv($d,60).'m ago';if($d<86400)return intdiv($d,3600).'h ago';return intdiv($d,86400).'d ago';}
function fmt_loi($s){if(!$s)return '—';return intdiv($s,60).'m '.($s%60).'s';}
function loi_cls($s){if(!$s)return '';if($s<180)return 'loi-red';if($s<480)return 'loi-yellow';return 'loi-green';}

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Exazon — TP Dashboard v3</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
:root{--navy:#0a1628;--navy2:#112040;--blue:#1b4fd8;--blue2:#3b82f6;--gold:#c8a84b;--off:#f0f4ff;--muted:#94a3b8;--green:#22c55e;--red:#ef4444;--yellow:#f59e0b;--purple:#8b5cf6;--teal:#14b8a6;--orange:#f97316;}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'DM Sans',sans-serif;background:var(--off);color:#1e293b;min-height:100vh}
.nav{background:var(--navy);padding:0 24px;height:56px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(59,130,246,.2);position:sticky;top:0;z-index:100}
.nav-left{display:flex;align-items:center;gap:10px}
.nav-logo{width:32px;height:32px;border-radius:50%;border:2px solid rgba(59,130,246,.3);background:#fff}
.nav-name{font-family:'Bebas Neue',sans-serif;font-size:15px;letter-spacing:2px;color:#fff}
.nav-tag{font-size:8px;letter-spacing:3px;text-transform:uppercase;color:var(--gold)}
.nav-right{display:flex;align-items:center;gap:8px}
.btn-sm{padding:5px 12px;border-radius:6px;font-size:10px;font-weight:600;letter-spacing:1px;text-transform:uppercase;cursor:pointer;border:none;text-decoration:none;display:inline-block;white-space:nowrap}
.btn-green{background:linear-gradient(135deg,var(--green),#16a34a);color:#fff}
.btn-blue{background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff}
.btn-red{background:rgba(239,68,68,.15);color:#dc2626;border:1px solid rgba(239,68,68,.3)}
.btn-logout{background:rgba(255,255,255,.08);color:var(--muted);border:1px solid rgba(255,255,255,.1)}
.live-dot{width:7px;height:7px;border-radius:50%;background:var(--green);animation:pulse 2s infinite;display:inline-block;margin-right:4px}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
.tabs-bar{background:var(--navy2);padding:0 24px;display:flex;gap:2px;border-bottom:1px solid rgba(59,130,246,.15);overflow-x:auto}
.tab-btn{padding:11px 14px;font-size:11px;font-weight:600;letter-spacing:1px;text-transform:uppercase;color:var(--muted);background:none;border:none;cursor:pointer;border-bottom:2px solid transparent;white-space:nowrap;transition:all .2s}
.tab-btn.active,.tab-btn:hover{color:var(--gold);border-bottom-color:var(--gold)}
.tab-pane{display:none!important}.tab-pane.active{display:block!important}
.main{max-width:1280px;margin:0 auto;padding:20px 18px}
.sg6{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-bottom:14px}
.sg4{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:18px}
.sg3{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px}
.sg2{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:16px}
.stat-card{background:#fff;border-radius:12px;padding:14px 10px;border:1px solid #e2e8f0;box-shadow:0 1px 4px rgba(10,22,40,.05);text-align:center}
.stat-num{font-family:'Bebas Neue',sans-serif;font-size:24px;letter-spacing:1px}
.stat-num.blue{color:var(--blue)}.stat-num.green{color:var(--green)}.stat-num.navy{color:var(--navy)}.stat-num.purple{color:var(--purple)}.stat-num.yellow{color:var(--yellow)}.stat-num.teal{color:var(--teal)}.stat-num.red{color:var(--red)}.stat-num.orange{color:var(--orange)}
.stat-lbl{font-size:8px;letter-spacing:2px;text-transform:uppercase;color:var(--muted);margin-top:2px}
.stat-sub{font-size:10px;color:#94a3b8;margin-top:2px}
.chart-card{background:#fff;border-radius:12px;padding:16px;border:1px solid #e2e8f0;box-shadow:0 1px 4px rgba(10,22,40,.04);margin-bottom:16px}
.chart-title{font-family:'Bebas Neue',sans-serif;font-size:12px;letter-spacing:2px;color:var(--navy);margin-bottom:12px}
.trend-bars{display:flex;align-items:flex-end;gap:8px;height:64px}
.trend-bar-wrap{display:flex;flex-direction:column;align-items:center;gap:3px;flex:1}
.trend-cnt{font-size:9px;font-weight:600;color:var(--blue);min-height:12px}
.trend-day{font-size:9px;color:var(--muted)}
.sec-title{font-family:'Bebas Neue',sans-serif;font-size:15px;letter-spacing:2px;color:var(--navy);margin-bottom:10px}
/* PROJECTS ACCORDION */
.proj-item{background:#fff;border-radius:12px;border:1px solid #e2e8f0;margin-bottom:10px;overflow:hidden;box-shadow:0 1px 4px rgba(10,22,40,.04)}
.proj-header{padding:13px 16px;display:flex;align-items:center;gap:10px;cursor:pointer;transition:background .15s;flex-wrap:wrap}
.proj-header:hover{background:#f8faff}
.proj-sid{font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:2px;color:var(--blue);min-width:120px}
.proj-pills{display:flex;gap:6px;flex-wrap:wrap;flex:1}
.pill{display:inline-block;padding:2px 9px;border-radius:20px;font-size:10px;font-weight:600}
.pill-total{background:rgba(27,79,216,.1);color:#1b4fd8;border:1px solid rgba(27,79,216,.2)}
.pill-today{background:rgba(34,197,94,.1);color:#16a34a;border:1px solid rgba(34,197,94,.2)}
.pill-uid{background:rgba(139,92,246,.1);color:#7c3aed;border:1px solid rgba(139,92,246,.2)}
.pill-ip{background:rgba(245,158,11,.1);color:#b45309;border:1px solid rgba(245,158,11,.2)}
.pill-device{background:rgba(20,184,166,.1);color:#0f766e;border:1px solid rgba(20,184,166,.2)}
.pill-comp{background:rgba(34,197,94,.1);color:#16a34a;border:1px solid rgba(34,197,94,.2)}
.pill-term{background:rgba(100,116,139,.1);color:#475569;border:1px solid rgba(100,116,139,.2)}
.proj-last{font-size:10px;color:var(--muted);white-space:nowrap}
.proj-chevron{font-size:12px;color:var(--muted);transition:transform .3s;margin-left:4px}
.proj-chevron.open{transform:rotate(180deg)}
.proj-body{display:none;border-top:1px solid #e2e8f0}
.proj-body.open{display:block}
.proj-meta{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px;padding:12px 16px;background:#f8faff;border-bottom:1px solid #e2e8f0}
.proj-meta-label{font-size:8px;letter-spacing:2px;text-transform:uppercase;color:var(--muted);margin-bottom:3px}
.proj-meta-val{font-family:'Bebas Neue',sans-serif;font-size:14px;letter-spacing:1px;color:var(--navy)}
/* TABLE */
.tbl-card{background:#fff;border-radius:12px;overflow:hidden;border:1px solid #e2e8f0;box-shadow:0 1px 4px rgba(10,22,40,.04);margin-bottom:16px}
.tbl-head{background:var(--navy);padding:11px 16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px}
.tbl-title{font-family:'Bebas Neue',sans-serif;font-size:13px;letter-spacing:2px;color:var(--gold)}
.tbl-count{font-size:10px;color:var(--muted)}
.tbl-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse}
thead{background:#f8faff}
th{padding:9px 12px;text-align:left;font-size:8px;letter-spacing:2px;text-transform:uppercase;color:#64748b;font-weight:600;border-bottom:1px solid #e2e8f0;white-space:nowrap}
tbody tr{border-bottom:1px solid #f1f5f9;transition:background .12s}
tbody tr:hover{background:#f8faff}
td{padding:9px 12px;font-size:12px;color:#374151;vertical-align:middle;white-space:nowrap}
td.mono{font-family:'Courier New',monospace;font-size:11px}
.sid-badge{font-family:'Bebas Neue',sans-serif;font-size:13px;letter-spacing:1px;color:var(--blue)}
.loi-red{color:#dc2626;font-weight:700}.loi-yellow{color:#b45309;font-weight:600}.loi-green{color:#16a34a;font-weight:600}
.st-pill{display:inline-flex;align-items:center;gap:3px;border-radius:20px;padding:2px 8px;font-size:10px;font-weight:600}
.st-pill::before{content:'';width:5px;height:5px;border-radius:50%}
.st-complete{background:rgba(34,197,94,.1);color:#16a34a;border:1px solid rgba(34,197,94,.3)}.st-complete::before{background:#22c55e}
.st-terminate{background:rgba(100,116,139,.1);color:#475569;border:1px solid rgba(100,116,139,.3)}.st-terminate::before{background:#64748b}
.st-quotafull{background:rgba(245,158,11,.1);color:#b45309;border:1px solid rgba(245,158,11,.3)}.st-quotafull::before{background:#f59e0b}
.st-qc,.st-quality{background:rgba(139,92,246,.1);color:#7c3aed;border:1px solid rgba(139,92,246,.3)}.st-qc::before,.st-quality::before{background:#8b5cf6}
.filters-row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px}
.fsel{background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:7px 11px;font-family:'DM Sans',sans-serif;font-size:12px;outline:none;cursor:pointer}
.fsrch{flex:1;min-width:160px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:7px 12px;font-family:'DM Sans',sans-serif;font-size:12px;outline:none}
.score-bar{height:4px;background:#e2e8f0;border-radius:2px;overflow:hidden;margin-top:3px}
.score-fill{height:100%;border-radius:2px}
.mysql-badge{display:inline-block;background:rgba(34,197,94,.1);color:#16a34a;border:1px solid rgba(34,197,94,.3);border-radius:6px;padding:2px 8px;font-size:9px;font-weight:600;margin-left:6px}
.empty{text-align:center;padding:32px;color:var(--muted);font-size:13px}
/* ADD PROJECT FORM */
.form-card{background:#fff;border-radius:14px;border:1px solid #e2e8f0;box-shadow:0 1px 4px rgba(10,22,40,.05);padding:22px;margin-bottom:18px}
.form-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px;margin-bottom:14px}
.form-group label{display:block;font-size:10px;font-weight:600;letter-spacing:1px;text-transform:uppercase;color:#64748b;margin-bottom:5px}
.form-group input,.form-group select{width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:8px;font-family:'DM Sans',sans-serif;font-size:13px;outline:none;background:#fff;color:#1e293b;transition:border-color .15s}
.form-group input:focus,.form-group select:focus{border-color:var(--blue2)}
.form-group.full{grid-column:1/-1}
.btn-add{padding:10px 28px;background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff;border:none;border-radius:10px;font-family:'Bebas Neue',sans-serif;font-size:14px;letter-spacing:2px;cursor:pointer;transition:opacity .15s}
.btn-add:hover{opacity:.9}
.alert-box{padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:14px}
.alert-success{background:rgba(34,197,94,.1);color:#15803d;border:1px solid rgba(34,197,94,.3)}
.alert-error{background:rgba(239,68,68,.1);color:#dc2626;border:1px solid rgba(239,68,68,.3)}
/* TP SURVEY CARDS */
.tp-card{background:#fff;border-radius:12px;border:1px solid #e2e8f0;margin-bottom:12px;overflow:hidden}
.tp-card-header{background:linear-gradient(135deg,var(--navy),var(--navy2));padding:14px 18px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px}
.tp-card-sid{font-family:'Bebas Neue',sans-serif;font-size:19px;letter-spacing:2px;color:#fff}
.tp-card-name{font-size:12px;color:rgba(200,220,255,.7);margin-top:2px}
.tp-card-body{padding:14px 18px}
.tp-stats-row{display:grid;grid-template-columns:repeat(6,1fr);gap:8px;margin-bottom:12px}
.tp-stat{text-align:center}
.tp-stat-num{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:1px}
.tp-stat-lbl{font-size:8px;letter-spacing:1.5px;text-transform:uppercase;color:var(--muted);margin-top:1px}
.tp-meta-row{display:flex;gap:16px;flex-wrap:wrap;font-size:11px;color:#64748b;padding-top:10px;border-top:1px solid #f1f5f9}
.tp-meta-item strong{color:#374151}
.progress-wrap{background:#e2e8f0;border-radius:10px;height:6px;margin:6px 0 0;overflow:hidden}
.progress-fill{height:100%;border-radius:10px;background:linear-gradient(90deg,var(--blue),var(--green));transition:width .5s}
.badge-active{background:rgba(34,197,94,.1);color:#16a34a;border:1px solid rgba(34,197,94,.3);border-radius:6px;padding:2px 8px;font-size:9px;font-weight:700}
.badge-paused{background:rgba(245,158,11,.1);color:#b45309;border:1px solid rgba(245,158,11,.3);border-radius:6px;padding:2px 8px;font-size:9px;font-weight:700}
/* LINK BOX */
.link-box{background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:8px 12px;font-family:'Courier New',monospace;font-size:11px;color:#374151;word-break:break-all;margin-top:6px;display:flex;justify-content:space-between;align-items:center;gap:8px}
.copy-btn{padding:3px 10px;background:var(--navy);color:#fff;border:none;border-radius:5px;font-size:9px;cursor:pointer;white-space:nowrap}
@media(max-width:900px){.sg6{grid-template-columns:repeat(3,1fr)}.sg4{grid-template-columns:repeat(2,1fr)}.tp-stats-row{grid-template-columns:repeat(3,1fr)}}
@media(max-width:600px){.sg6{grid-template-columns:repeat(2,1fr)}.tp-stats-row{grid-template-columns:repeat(2,1fr)}}
</style>
</head>
<body>

<nav class="nav">
  <div class="nav-left">
    <img src="logo.php" class="nav-logo" alt="Exazon">
    <div>
      <div class="nav-name">Exazon Research</div>
      <div class="nav-tag">Third Party Dashboard v3</div>
    </div>
  </div>
  <div class="nav-right">
    <a href="hub/survey_dashboard.php" class="btn-sm btn-blue" style="background:rgba(30,79,216,.2);color:#a0c0ff;border:1px solid rgba(30,79,216,.3)">← Main Dashboard</a>
    <span style="font-size:10px;color:var(--muted)"><span class="live-dot"></span>Live</span>
    <a href="?export=1&sid=<?=urlencode($filter_sid)?>&uid=<?=urlencode($filter_uid)?>" class="btn-sm btn-green">⬇ CSV</a>
    <a href="?logout=1" class="btn-sm btn-logout">Logout</a>
  </div>
</nav>

<div class="tabs-bar">
  <button class="tab-btn active" onclick="sw('overview',this)">📊 Overview</button>
  <button class="tab-btn" onclick="sw('manage',this)">➕ Projects</button>
  <button class="tab-btn" onclick="sw('projects',this)">📁 Entry Log</button>
  <button class="tab-btn" onclick="sw('log',this)">📋 CSV Log</button>
  <?php if($has_mysql): ?>
  <button class="tab-btn" onclick="sw('mysql',this)">🗃️ MySQL Log</button>
  <button class="tab-btn" onclick="sw('vendors',this)">👥 Vendor Score</button>
  <button class="tab-btn" onclick="sw('uid_lookup',this)">🔍 UID Lookup</button>
  <?php endif; ?>
</div>

<div class="main">

<!-- ════════ MANAGE PROJECTS TAB ════════ -->
<div class="tab-pane" id="tab-manage">
<div style="margin-top:16px">

<?php
// Show action message
if($action_msg){
    list($type,$msg) = explode(':',$action_msg,2);
    echo '<div class="alert-box alert-'.$type.'">'.$msg.'</div>';
}
?>

<!-- ADD / EDIT PROJECT FORM -->
<div class="form-card">
  <div class="sec-title" style="margin-bottom:16px">➕ Add / Update TP Project</div>
  <form method="POST">
    <input type="hidden" name="action" value="add_project">
    <div class="form-grid">
      <div class="form-group">
        <label>Project ID (SID) *</label>
        <input type="text" name="p_sid" placeholder="e.g. MEXICO251254" style="text-transform:uppercase" required>
      </div>
      <div class="form-group">
        <label>Project / Survey Name *</label>
        <input type="text" name="p_name" placeholder="e.g. Mexico Vehicle Owners" required>
      </div>
      <div class="form-group">
        <label>Client Name</label>
        <input type="text" name="p_client" placeholder="e.g. Mindforce Research">
      </div>
      <div class="form-group">
        <label>Vendor / Panel (Your source)</label>
        <input type="text" name="p_vendor" placeholder="e.g. Cint, Dynata, Direct">
      </div>
      <div class="form-group">
        <label>Target Completes</label>
        <input type="number" name="p_target" placeholder="e.g. 300" min="0">
      </div>
      <div class="form-group">
        <label>CPI — Client pays you (₹)</label>
        <input type="number" name="p_cpi_client" placeholder="e.g. 500" step="0.01" min="0">
      </div>
      <div class="form-group">
        <label>CPI — You pay vendor (₹)</label>
        <input type="number" name="p_cpi_vendor" placeholder="e.g. 300" step="0.01" min="0">
      </div>
      <div class="form-group">
        <label>Survey Type</label>
        <select name="p_type">
          <option value="thirdparty">Third Party (Vendor)</option>
          <option value="direct">Direct Client</option>
        </select>
      </div>
      <div class="form-group full">
        <label>Survey Redirect URL (optional — dost ka survey link + UID placeholder)</label>
        <input type="text" name="p_url" placeholder="e.g. https://survey.mindforce.com/s/ABC?pid=">
      </div>
      <div class="form-group full">
        <label>Respondent ID Sent to Vendor/Friend's Link</label>
        <div style="display:flex;align-items:center;gap:8px;margin-top:4px">
          <input type="checkbox" name="p_encrypt_uid" id="p_encrypt_uid" checked style="width:auto">
          <span style="font-size:12px;color:var(--muted)">Encrypt the ID before sending it onward (recommended — uncheck only if the raw respondent ID is needed). This cannot be changed after the project is created.</span>
        </div>
      </div>
    </div>
    <button type="submit" class="btn-add">+ Add / Update Project</button>
    <span style="font-size:11px;color:var(--muted);margin-left:12px">Same SID = update existing</span>
  </form>
</div>

<!-- EXISTING TP PROJECTS TABLE -->
<div class="sec-title">📋 All TP Projects (<?= count($tp_surveys) ?>)</div>
<?php if(empty($tp_surveys)): ?>
<div class="empty">No TP projects yet. Add one above ☝️</div>
<?php else: foreach($tp_surveys as $ts):
    $cr = ($ts['total_responses']>0) ? round($ts['completes']/$ts['total_responses']*100) : 0;
    $pct_target = ($ts['target']>0) ? min(100,round($ts['completes']/$ts['target']*100)) : 0;
    $margin = ($ts['completes']>0) ? round(($ts['cpi_client']-$ts['cpi_vendor'])*$ts['completes'],0) : 0;
    // vendor.php entry link
    $entry_link = 'https://exazonresearch.com/vendor.php?sid='.urlencode($ts['sid']).'&uid=[UID]';
?>
<div class="tp-card">
  <div class="tp-card-header">
    <div>
      <div class="tp-card-sid"><?= htmlspecialchars($ts['sid']) ?></div>
      <div class="tp-card-name"><?= htmlspecialchars($ts['name']) ?> <?php if($ts['client']): ?>· <span style="color:rgba(200,168,75,.8)"><?= htmlspecialchars($ts['client']) ?></span><?php endif; ?></div>
    </div>
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
      <span class="<?= $ts['is_active']?'badge-active':'badge-paused' ?>"><?= $ts['is_active']?'ACTIVE':'PAUSED' ?></span>
      <!-- Toggle Active/Pause -->
      <form method="POST" style="display:inline">
        <input type="hidden" name="action" value="toggle_project">
        <input type="hidden" name="t_sid" value="<?= htmlspecialchars($ts['sid']) ?>">
        <input type="hidden" name="t_active" value="<?= $ts['is_active']?'0':'1' ?>">
        <button type="submit" class="btn-sm <?= $ts['is_active']?'btn-red':'btn-green' ?>" style="padding:4px 10px">
          <?= $ts['is_active']?'⏸ Pause':'▶ Activate' ?>
        </button>
      </form>
      <!-- Delete -->
      <form method="POST" style="display:inline" onsubmit="return confirm('Delete <?= htmlspecialchars($ts['sid']) ?>? This only removes the project record, not response data.')">
        <input type="hidden" name="action" value="delete_project">
        <input type="hidden" name="d_sid" value="<?= htmlspecialchars($ts['sid']) ?>">
        <button type="submit" class="btn-sm btn-red" style="padding:4px 10px">🗑 Delete</button>
      </form>
    </div>
  </div>
  <div class="tp-card-body">
    <!-- Stats row -->
    <div class="tp-stats-row">
      <div class="tp-stat"><div class="tp-stat-num blue"><?= $ts['total_responses']?:0 ?></div><div class="tp-stat-lbl">Total Entries</div></div>
      <div class="tp-stat"><div class="tp-stat-num green"><?= $ts['completes']?:0 ?></div><div class="tp-stat-lbl">Completes</div></div>
      <div class="tp-stat"><div class="tp-stat-num" style="color:var(--muted)"><?= $ts['terminates']?:0 ?></div><div class="tp-stat-lbl">Terminates</div></div>
      <div class="tp-stat"><div class="tp-stat-num navy"><?= $cr ?>%</div><div class="tp-stat-lbl">Conv. Rate</div></div>
      <div class="tp-stat"><div class="tp-stat-num <?= $ts['target']?'purple':'muted' ?>"><?= $ts['target']?:0 ?></div><div class="tp-stat-lbl">Target</div></div>
      <div class="tp-stat"><div class="tp-stat-num <?= $margin>0?'green':($margin<0?'red':'muted') ?>">₹<?= number_format($margin) ?></div><div class="tp-stat-lbl">Margin</div></div>
    </div>
    <?php if($ts['target']>0): ?>
    <div style="font-size:10px;color:var(--muted);margin-bottom:3px"><?= $ts['completes']?:0 ?>/<?= $ts['target'] ?> complete (<?= $pct_target ?>%)</div>
    <div class="progress-wrap"><div class="progress-fill" style="width:<?= $pct_target ?>%"></div></div>
    <?php endif; ?>
    <!-- Meta row -->
    <div class="tp-meta-row">
      <?php if($ts['vendor_name']): ?><span class="tp-meta-item">Panel: <strong><?= htmlspecialchars($ts['vendor_name']) ?></strong></span><?php endif; ?>
      <span class="tp-meta-item">UID Mode: <strong><?= !empty($ts['encrypt_uid']) ? 'Encrypted' : 'Raw UID' ?></strong></span>
      <?php if($ts['cpi_client']>0): ?><span class="tp-meta-item">Client CPI: <strong>₹<?= number_format($ts['cpi_client'],0) ?></strong></span><?php endif; ?>
      <?php if($ts['cpi_vendor']>0): ?><span class="tp-meta-item">Vendor CPI: <strong>₹<?= number_format($ts['cpi_vendor'],0) ?></strong></span><?php endif; ?>
      <?php if($ts['avg_loi']): ?><span class="tp-meta-item">Avg LOI: <strong><?= fmt_loi($ts['avg_loi']) ?></strong></span><?php endif; ?>
      <?php if($ts['last_response']): ?><span class="tp-meta-item">Last response: <strong><?= timeSince($ts['last_response']) ?></strong></span><?php endif; ?>
    </div>
    <!-- Entry link -->
    <?php if($ts['survey_url']): ?>
    <div style="margin-top:10px;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:1px;color:#64748b;margin-bottom:4px">Vendor Entry Link (share with respondents):</div>
    <div class="link-box">
      <span><?= htmlspecialchars($entry_link) ?></span>
      <button class="copy-btn" onclick="copyLink(this,'<?= htmlspecialchars($entry_link) ?>')">Copy</button>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php endforeach; endif; ?>

</div>
</div><!-- /manage -->

<!-- ════════ OVERVIEW ════════ -->
<div class="tab-pane active" id="tab-overview">

<?php if(($loi_stats['speeders']??0)>0): ?>
<div style="background:#fff;border-radius:10px;padding:11px 15px;border-left:4px solid var(--red);margin-bottom:12px;font-size:12px;color:#7f1d1d;display:flex;align-items:center;gap:8px">
  ⚡ <strong><?= $loi_stats['speeders'] ?> TP speeder(s)</strong> detected — LOI under 3 minutes.
</div>
<?php endif; ?>

<div style="margin-bottom:6px;font-size:10px;color:var(--muted)">Entry Log (CSV) <?php if($has_mysql): ?><span class="mysql-badge">+ MySQL data available</span><?php endif; ?></div>
<div class="sg6">
  <div class="stat-card"><div class="stat-num blue"><?= $total ?></div><div class="stat-lbl">Total Entries</div></div>
  <div class="stat-card"><div class="stat-num navy"><?= $total_surveys ?></div><div class="stat-lbl">Surveys</div></div>
  <div class="stat-card"><div class="stat-num green"><?= $today_cnt ?></div><div class="stat-lbl">Today</div><div class="stat-sub">Yesterday: <?= $yest_cnt ?></div></div>
  <div class="stat-card"><div class="stat-num purple"><?= $total_uids ?></div><div class="stat-lbl">Unique UIDs</div></div>
  <div class="stat-card"><div class="stat-num yellow"><?= $unique_ips ?></div><div class="stat-lbl">Unique IPs</div></div>
  <div class="stat-card">
    <?php $top_dev=array_keys($dev_counts)[0]??'N/A';$top_dev_cnt=array_values($dev_counts)[0]??0; ?>
    <div class="stat-num teal"><?= ucfirst($top_dev) ?></div>
    <div class="stat-lbl">Top Device</div><div class="stat-sub"><?= $top_dev_cnt ?> entries</div>
  </div>
</div>

<?php if($has_mysql): ?>
<div style="margin-bottom:6px;font-size:10px;color:var(--muted)">LOI & Quality (MySQL)</div>
<div class="sg4">
  <div class="stat-card"><div class="stat-num teal"><?= fmt_loi($loi_stats['avg_loi']??0) ?></div><div class="stat-lbl">Avg LOI</div><div class="stat-sub">TP Completes</div></div>
  <div class="stat-card"><div class="stat-num <?= ($loi_stats['min_loi']??0)>0&&($loi_stats['min_loi']??0)<180?'red':'teal' ?>"><?= fmt_loi($loi_stats['min_loi']??0) ?></div><div class="stat-lbl">Min LOI</div><div class="stat-sub">Fastest complete</div></div>
  <div class="stat-card"><div class="stat-num red"><?= $loi_stats['speeders']??0 ?></div><div class="stat-lbl">Speeders</div><div class="stat-sub">&lt;3 min LOI</div></div>
  <div class="stat-card"><div class="stat-num orange"><?= count($country_counts) ?></div><div class="stat-lbl">Countries</div><div class="stat-sub"><?= implode(', ',array_slice(array_keys($country_counts),0,3)) ?></div></div>
</div>
<?php endif; ?>

<div class="chart-card">
  <div class="chart-title">Last 7 Days — Entry Activity</div>
  <div class="trend-bars">
    <?php foreach($trend as $t): ?>
    <div class="trend-bar-wrap">
      <div class="trend-cnt"><?= $t['cnt']?:'' ?></div>
      <div style="width:100%;background:#e2e8f0;border-radius:3px;position:relative;height:48px">
        <div style="position:absolute;bottom:0;width:100%;height:<?= $maxTrend>0?round(($t['cnt']/$maxTrend)*100):0 ?>%;background:linear-gradient(180deg,var(--blue2),var(--blue));border-radius:3px"></div>
      </div>
      <div class="trend-day"><?= $t['day'] ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<?php if(!empty($dev_counts)): ?>
<div class="chart-card">
  <div class="chart-title">Device Breakdown</div>
  <div style="display:flex;gap:16px;flex-wrap:wrap;align-items:center">
    <?php foreach($dev_counts as $dv=>$dc): $pct=round($dc/$total*100); ?>
    <div style="display:flex;align-items:center;gap:8px">
      <span style="font-size:14px"><?= $dv==='mobile'?'📱':($dv==='tablet'?'📟':'💻') ?></span>
      <div>
        <div style="font-family:'Bebas Neue',sans-serif;font-size:16px;color:var(--navy)"><?= $dc ?> <span style="font-size:11px;color:var(--muted)"><?= $pct ?>%</span></div>
        <div style="font-size:9px;letter-spacing:1px;text-transform:uppercase;color:var(--muted)"><?= ucfirst($dv) ?></div>
        <div style="height:3px;width:60px;background:#e2e8f0;border-radius:2px;margin-top:3px"><div style="height:100%;width:<?= $pct ?>%;background:var(--blue2);border-radius:2px"></div></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<?php if(!empty($country_counts)): ?>
<div class="chart-card">
  <div class="chart-title">Country Distribution (MySQL)</div>
  <div style="display:flex;flex-direction:column;gap:6px">
    <?php $ctotal=array_sum($country_counts);foreach($country_counts as $c=>$cn):$cpct=round($cn/$ctotal*100); ?>
    <div style="display:flex;align-items:center;gap:10px">
      <div style="width:120px;font-size:12px;color:#374151;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($c) ?></div>
      <div style="flex:1;height:6px;background:#e2e8f0;border-radius:3px"><div style="height:100%;width:<?= $cpct ?>%;background:linear-gradient(90deg,var(--teal),var(--blue2));border-radius:3px"></div></div>
      <div style="font-size:11px;font-weight:600;color:var(--navy);width:30px;text-align:right"><?= $cn ?></div>
      <div style="font-size:10px;color:var(--muted);width:30px"><?= $cpct ?>%</div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

</div><!-- /overview -->

<!-- ════════ ENTRY LOG (CSV Projects) ════════ -->
<div class="tab-pane" id="tab-projects">
<div class="sec-title" style="margin-top:16px">Survey Projects (<?= $total_surveys ?>)</div>
<?php if(empty($projects)): ?>
<div class="empty">No entries yet.</div>
<?php else: foreach($projects as $proj): ?>
<div class="proj-item">
  <div class="proj-header" onclick="toggleProj('<?= htmlspecialchars($proj['sid']) ?>')">
    <div class="proj-sid"><?= htmlspecialchars($proj['sid']) ?></div>
    <div class="proj-pills">
      <span class="pill pill-total"><?= $proj['count'] ?> entries</span>
      <?php if($proj['today']>0): ?><span class="pill pill-today">+<?= $proj['today'] ?> today</span><?php endif; ?>
      <span class="pill pill-uid"><?= $proj['unique_uids'] ?> UIDs</span>
      <span class="pill pill-ip"><?= $proj['unique_ips'] ?> IPs</span>
      <span class="pill pill-device">📱 <?= ucfirst($proj['top_device']) ?></span>
    </div>
    <div class="proj-last"><?= timeSince($proj['last']) ?></div>
    <div class="proj-chevron" id="chev-<?= $proj['sid'] ?>">▼</div>
  </div>
  <div class="proj-body" id="body-<?= $proj['sid'] ?>">
    <div class="proj-meta">
      <div><div class="proj-meta-label">Survey Name</div><div style="font-size:13px;font-weight:600"><?= htmlspecialchars($proj['name']) ?></div></div>
      <div><div class="proj-meta-label">First Entry</div><div style="font-size:11px;color:var(--muted)"><?= $proj['first'] ?></div></div>
      <div><div class="proj-meta-label">Last Entry</div><div style="font-size:11px;color:var(--muted)"><?= $proj['last'] ?></div></div>
      <div><div class="proj-meta-label">Top Device</div><div class="proj-meta-val"><?= ucfirst($proj['top_device']) ?></div></div>
    </div>
    <div class="tbl-wrap">
    <table><thead><tr><th>#</th><th>Entry Time</th><th>Since</th><th>UID</th><th>IP</th><th>Device</th></tr></thead>
    <tbody>
    <?php $pi=count($proj['rows']);foreach($proj['rows'] as $r): ?>
    <tr><td style="color:#cbd5e1"><?= $pi-- ?></td><td class="mono"><?= htmlspecialchars($r['time']) ?></td><td style="color:var(--muted);font-size:11px"><?= timeSince($r['time']) ?></td><td style="font-weight:500"><?= htmlspecialchars($r['uid']) ?></td><td class="mono" style="color:#94a3b8"><?= htmlspecialchars($r['ip']) ?></td><td><?= ucfirst(htmlspecialchars($r['device'])) ?></td></tr>
    <?php endforeach; ?>
    </tbody></table>
    </div>
  </div>
</div>
<?php endforeach;endif; ?>
</div><!-- /projects -->

<!-- ════════ CSV LOG ════════ -->
<div class="tab-pane" id="tab-log">
<div style="margin-top:16px">
<div class="filters-row">
  <select class="fsel" id="fLogSid" onchange="filterLog()">
    <option value="">All Surveys</option>
    <?php foreach($projects as $proj): ?>
    <option value="<?= htmlspecialchars($proj['sid']) ?>"><?= htmlspecialchars($proj['sid']) ?></option>
    <?php endforeach; ?>
  </select>
  <input class="fsrch" id="fLogUid" placeholder="Search UID..." oninput="filterLog()">
  <a href="?export=1" class="btn-sm btn-green">⬇ CSV</a>
</div>
<div class="tbl-card">
  <div class="tbl-head">
  <div class="tbl-title">Entry Log (CSV)</div>
  <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
    <div class="tbl-count" id="logCount"><?= count($filtered) ?> records</div>
    <button type="button" onclick="csvSelAll(true)" style="background:rgba(255,255,255,.1);color:#94a3b8;border:1px solid rgba(255,255,255,.15);border-radius:5px;padding:3px 9px;font-size:10px;cursor:pointer">Select All</button>
    <button type="button" onclick="csvSelAll(false)" style="background:rgba(255,255,255,.1);color:#94a3b8;border:1px solid rgba(255,255,255,.15);border-radius:5px;padding:3px 9px;font-size:10px;cursor:pointer">Clear</button>
    <button type="button" onclick="csvConfirmDelete()" style="background:rgba(239,68,68,.15);color:#fca5a5;border:1px solid rgba(239,68,68,.35);border-radius:5px;padding:3px 11px;font-size:10px;font-weight:600;cursor:pointer">🗑 Delete Selected</button>
  </div>
</div>
<form method="POST" id="csvDelForm">
  <input type="hidden" name="delete_csv_rows" value="1">
  <div class="tbl-wrap">
  <?php if(empty($filtered)): ?>
  <div class="empty">No records found.</div>
  <?php else: ?>
  <table id="logTbl"><thead><tr>
    <th style="width:32px"><input type="checkbox" id="csvChkAll" onchange="csvSelAll(this.checked)" style="cursor:pointer"></th>
    <th>#</th><th>Entry Time</th><th>Since</th><th>Survey ID</th><th>Survey Name</th><th>UID</th><th>IP</th><th>Device</th>
  </tr></thead>
  <tbody>
  <?php $li=count($filtered);foreach($filtered as $r): ?>
  <tr data-sid="<?= strtolower(htmlspecialchars($r['sid'])) ?>" data-uid="<?= strtolower(htmlspecialchars($r['uid'])) ?>">
    <td>
      <input type="checkbox" class="csv-chk" name="del_uids[]" value="<?= htmlspecialchars($r['uid']) ?>" style="cursor:pointer">
      <input type="hidden" name="del_times[]" value="<?= htmlspecialchars($r['time']) ?>">
    </td>
    <td style="color:#cbd5e1"><?= $li-- ?></td>
    <td class="mono"><?= htmlspecialchars($r['time']) ?></td>
    <td style="color:var(--muted);font-size:11px"><?= timeSince($r['time']) ?></td>
    <td><span class="sid-badge"><?= htmlspecialchars($r['sid']) ?></span></td>
    <td style="color:#64748b;font-size:11px"><?= htmlspecialchars($r['survey']) ?></td>
    <td style="font-weight:500"><?= htmlspecialchars($r['uid']) ?></td>
    <td class="mono" style="color:#94a3b8"><?= htmlspecialchars($r['ip']) ?></td>
    <td><?= ucfirst(htmlspecialchars($r['device'])) ?></td>
  </tr>
  <?php endforeach; ?>
  </tbody></table>
  <?php endif; ?>
  </div>
</form>
</div>
</div><!-- /log -->
</div><!-- /tab-log -->

<?php if($has_mysql): ?>
<!-- ════════ MYSQL LOG ════════ -->
<div class="tab-pane" id="tab-mysql">
<div style="margin-top:16px">
<div class="sec-title">MySQL — TP Responses (survey_responses)</div>
<div class="tbl-card">
  <div class="tbl-head">
  <div class="tbl-title">MySQL Data</div>
  <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
    <div class="tbl-count"><?= count($mysql_rows) ?> records</div>
    <button type="button" onclick="tpSelAll(true)" style="background:rgba(255,255,255,.1);color:#94a3b8;border:1px solid rgba(255,255,255,.15);border-radius:5px;padding:3px 9px;font-size:10px;cursor:pointer">Select All</button>
    <button type="button" onclick="tpSelAll(false)" style="background:rgba(255,255,255,.1);color:#94a3b8;border:1px solid rgba(255,255,255,.15);border-radius:5px;padding:3px 9px;font-size:10px;cursor:pointer">Clear</button>
    <button type="button" onclick="tpConfirmDelete()" style="background:rgba(239,68,68,.15);color:#fca5a5;border:1px solid rgba(239,68,68,.35);border-radius:5px;padding:3px 11px;font-size:10px;font-weight:600;cursor:pointer">🗑 Delete Selected</button>
  </div>
</div>
<form method="POST" id="tpDelForm">
  <input type="hidden" name="action" value="delete_tp_responses">
  <div class="tbl-wrap">
  <?php if(empty($mysql_rows)): ?>
  <div class="empty">No MySQL records with source='thirdparty' yet.<br><span style="font-size:11px">vendor.php se entries aane par yahan dikhegi</span></div>
  <?php else: ?>
  <table><thead><tr>
    <th style="width:32px"><input type="checkbox" id="tpChkAll" onchange="tpSelAll(this.checked)" style="cursor:pointer"></th>
    <th>#</th><th>Status</th><th>UID</th><th>Survey ID</th><th>Client</th><th>Device</th><th>Country</th><th>City</th><th>LOI</th><th>Dup</th><th>Timestamp</th>
  </tr></thead>
  <tbody>
  <?php $mi=count($mysql_rows);foreach($mysql_rows as $r):$loi=$r['loi_seconds']?intval($r['loi_seconds']):null;$st=($r['status']==='quality')?'qc':$r['status']; ?>
  <tr>
    <td><input type="checkbox" name="del_ids[]" value="<?= intval($r['id'] ?? 0) ?>" class="tp-chk" style="cursor:pointer"></td>
    <td style="color:#94a3b8"><?= $mi-- ?></td>
    <td><span class="st-pill st-<?= $st ?>"><?= ucfirst($r['status']) ?></span><?= ($r['is_duplicate']??0)?'<span style="background:rgba(239,68,68,.1);color:#dc2626;border-radius:4px;padding:1px 5px;font-size:9px;font-weight:700;margin-left:3px">DUP</span>':'' ?></td>
    <td class="mono"><?= htmlspecialchars($r['uid']) ?></td>
    <td><b style="font-family:'Bebas Neue',sans-serif;color:var(--blue)"><?= htmlspecialchars($r['sid']) ?></b></td>
    <td><?= htmlspecialchars($r['client_name']??'—') ?></td>
    <td><?= htmlspecialchars($r['device']??'—') ?></td>
    <td><?= htmlspecialchars($r['country']??'—') ?></td>
    <td style="color:#94a3b8"><?= htmlspecialchars($r['city']??'—') ?></td>
    <td class="<?= loi_cls($loi) ?>"><?= fmt_loi($loi) ?></td>
    <td><?= ($r['is_duplicate']??0)?'<span style="color:#dc2626">⚠</span>':'✓' ?></td>
    <td class="mono" style="color:#94a3b8"><?= date('d M H:i',strtotime($r['time'])) ?></td>
  </tr>
  <?php endforeach; ?>
  </tbody></table>
  <?php endif; ?>
  </div>
</form>
</div>
</div><!-- /mysql -->
</div><!-- /tab-mysql -->

<!-- ════════ VENDOR SCORECARD ════════ -->
<div class="tab-pane" id="tab-vendors">
<div style="margin-top:16px">
<div class="sec-title">👥 TP Vendor Scorecard</div>
<div class="tbl-card">
  <div class="tbl-head"><div class="tbl-title">Vendor Performance</div><div class="tbl-count"><?= count($vendor_scores) ?> sources</div></div>
  <div class="tbl-wrap">
  <?php if(empty($vendor_scores)): ?>
  <div class="empty">No vendor data in MySQL yet.</div>
  <?php else: ?>
  <table><thead><tr><th>Vendor/Source</th><th>Total</th><th>Completes</th><th>Term</th><th>CR%</th><th>Speeders</th><th>Dups</th><th>Avg LOI</th><th>Countries</th><th>Score /100</th></tr></thead>
  <tbody>
  <?php foreach($vendor_scores as $v):
    $vcr=$v['total']>0?round($v['completes']/$v['total']*100):0;
    $qs=100;
    if($v['total']>0){$qs-=round($v['speeders']/$v['total']*40);$qs-=round($v['dups']/$v['total']*30);}
    $qs=max(0,min(100,$qs));
    $qsc=$qs>=80?'var(--green)':($qs>=60?'var(--yellow)':'var(--red)');
    $stars=$qs>=90?'⭐⭐⭐⭐⭐':($qs>=75?'⭐⭐⭐⭐':($qs>=60?'⭐⭐⭐':($qs>=40?'⭐⭐':'⭐')));
  ?>
  <tr>
    <td><strong><?= htmlspecialchars($v['vendor']) ?></strong></td>
    <td><?= $v['total'] ?></td>
    <td style="color:var(--green);font-weight:600"><?= $v['completes'] ?></td>
    <td style="color:var(--red)"><?= $v['terminates'] ?></td>
    <td><strong><?= $vcr ?>%</strong><div class="score-bar"><div class="score-fill" style="width:<?= $vcr ?>%;background:var(--blue2)"></div></div></td>
    <td style="color:<?= $v['speeders']>0?'var(--red)':'var(--green)' ?>"><?= $v['speeders'] ?></td>
    <td style="color:<?= $v['dups']>0?'var(--yellow)':'var(--green)' ?>"><?= $v['dups'] ?></td>
    <td class="<?= loi_cls($v['avg_loi']) ?>"><?= fmt_loi($v['avg_loi']) ?></td>
    <td style="color:var(--teal)"><?= $v['countries'] ?></td>
    <td><span style="font-family:'Bebas Neue',sans-serif;font-size:18px;color:<?= $qsc ?>"><?= $qs ?>/100</span><div style="font-size:10px"><?= $stars ?></div><div class="score-bar"><div class="score-fill" style="width:<?= $qs ?>%;background:<?= $qsc ?>"></div></div></td>
  </tr>
  <?php endforeach; ?>
  </tbody></table>
  <?php endif; ?>
  </div>
</div>
</div>
</div><!-- /vendors -->
<?php endif; ?>

<!-- ════════ UID LOOKUP TAB ════════ -->
<div class="tab-pane" id="tab-uid_lookup" style="display:none">
<div style="margin-top:16px">
<div class="sec-title">🔍 UID Lookup — uid_mapping Table</div>

<div class="tbl-card" style="margin-bottom:18px">
  <div class="tbl-head">
    <div class="tbl-title">Search by Original or Encrypted UID</div>
    <div style="font-size:10px;color:var(--muted)">uid_mapping table direct query</div>
  </div>
  <div style="padding:18px">
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:16px">
      <input type="text" id="uidSearchInput"
        placeholder="Original ya Encrypted UID daalo..."
        style="flex:1;min-width:260px;padding:10px 14px;border:1px solid #e2e8f0;border-radius:8px;font-family:'DM Sans',sans-serif;font-size:13px;outline:none;background:#fff;color:#1e293b"
        onkeydown="if(event.key==='Enter')doUidLookup()">
      <select id="uidSearchType"
        style="padding:10px 14px;border:1px solid #e2e8f0;border-radius:8px;font-family:'DM Sans',sans-serif;font-size:12px;outline:none;background:#fff;cursor:pointer">
        <option value="both">Both (Auto)</option>
        <option value="original">Original UID</option>
        <option value="encrypted">Encrypted UID</option>
      </select>
      <button onclick="doUidLookup()"
        style="padding:10px 22px;background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff;border:none;border-radius:8px;font-family:'Bebas Neue',sans-serif;font-size:14px;letter-spacing:2px;cursor:pointer">
        SEARCH
      </button>
      <button onclick="doUidClear()"
        style="padding:10px 16px;background:rgba(255,255,255,.7);color:var(--muted);border:1px solid #e2e8f0;border-radius:8px;font-size:11px;cursor:pointer">
        Clear
      </button>
    </div>
    <div id="uidSearchStatus" style="font-size:12px;color:var(--muted);margin-bottom:10px;display:none"></div>
  </div>
</div>

<!-- Results Table -->
<div class="tbl-card" id="uidResultCard" style="display:none">
  <div class="tbl-head">
    <div class="tbl-title">Search Results</div>
    <div class="tbl-count" id="uidResultCount">0 records</div>
  </div>
  <div class="tbl-wrap">
    <table id="uidResultTable">
      <thead><tr>
        <th>#</th>
        <th>Original UID</th>
        <th>Encrypted UID</th>
        <th>Survey ID</th>
        <th>Source</th>
        <th>Actions</th>
      </tr></thead>
      <tbody id="uidResultBody">
      </tbody>
    </table>
  </div>
</div>

<!-- No Result -->
<div id="uidNoResult" style="display:none;text-align:center;padding:40px;background:#fff;border-radius:12px;border:1px solid #e2e8f0">
  <div style="font-size:32px;margin-bottom:8px">🔎</div>
  <div style="font-size:14px;color:var(--navy);font-weight:600;margin-bottom:4px">Koi match nahi mila</div>
  <div style="font-size:12px;color:var(--muted)">Try karo dusra UID ya search type change karo</div>
</div>

</div>
</div><!-- /uid_lookup -->

<div style="text-align:center;font-size:11px;color:#94a3b8;padding-bottom:20px">
  © 2026 Exazon Research LLP &nbsp;·&nbsp; TP Dashboard v3 &nbsp;·&nbsp; <?= date('d M Y H:i:s') ?> IST
</div>

</div><!-- /main -->

<script>
function csvSelAll(checked){
  document.querySelectorAll('.csv-chk').forEach(c=>c.checked=checked);
  const ca=document.getElementById('csvChkAll');if(ca)ca.checked=checked;
}
function csvConfirmDelete(){
  const checked=document.querySelectorAll('.csv-chk:checked');
  if(checked.length===0){alert('Pehle koi entry select karo.');return;}
  if(confirm('⚠️ '+checked.length+' CSV entr'+(checked.length===1?'y':'ies')+' permanently delete karni hain?\n\nYe UNDO nahi hoga!')){
    document.getElementById('csvDelForm').submit();
  }
}
function tpSelAll(checked){
  document.querySelectorAll('.tp-chk').forEach(c=>c.checked=checked);
  const ca=document.getElementById('tpChkAll');if(ca)ca.checked=checked;
}
function tpConfirmDelete(){
  const checked=document.querySelectorAll('.tp-chk:checked');
  if(checked.length===0){alert('Pehle koi entry select karo.');return;}
  if(confirm('⚠️ '+checked.length+' MySQL entr'+(checked.length===1?'y':'ies')+' permanently delete karni hain?\n\nYe UNDO nahi hoga!')){
    document.getElementById('tpDelForm').submit();
  }
}
function sw(name,btn){
  document.querySelectorAll('.tab-pane').forEach(p=>{p.classList.remove('active');p.style.display='none';});
  document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
  var el=document.getElementById('tab-'+name);
  if(el){el.classList.add('active');el.style.display='block';}
  if(btn) btn.classList.add('active');
  // Auto-open manage tab if action happened
  <?php if($action_msg && strpos($action_msg,'success')===0): ?>
  if(name==='overview') sw('manage',document.querySelector('[onclick*="manage"]'));
  <?php endif; ?>
}
function toggleProj(sid){
  document.getElementById('body-'+sid).classList.toggle('open');
  document.getElementById('chev-'+sid).classList.toggle('open');
}
function filterLog(){
  const sid=document.getElementById('fLogSid').value.toLowerCase();
  const uid=document.getElementById('fLogUid').value.toLowerCase();
  const rows=document.querySelectorAll('#logTbl tbody tr');
  let vis=0;
  rows.forEach(r=>{const ok=(!sid||r.dataset.sid===sid)&&(!uid||r.dataset.uid.includes(uid));r.style.display=ok?'':'none';if(ok)vis++;});
  document.getElementById('logCount').textContent=vis+' records';
}
function copyLink(btn,txt){
  navigator.clipboard.writeText(txt).then(()=>{btn.textContent='Copied!';setTimeout(()=>btn.textContent='Copy',2000);});
}
// Auto-redirect to manage tab if action was performed
<?php if($action_msg): ?>
document.addEventListener('DOMContentLoaded',()=>sw('manage',document.querySelector('[onclick*="manage"]')));
<?php endif; ?>
// UID Lookup
function doUidLookup(){
  const q=document.getElementById('uidSearchInput').value.trim();
  const stype=document.getElementById('uidSearchType').value;
  const status=document.getElementById('uidSearchStatus');
  const card=document.getElementById('uidResultCard');
  const noRes=document.getElementById('uidNoResult');
  const tbody=document.getElementById('uidResultBody');
  const countEl=document.getElementById('uidResultCount');
  if(!q){alert('Koi UID daalo pehle!');return;}
  status.style.display='block';
  status.textContent='🔍 Searching...';
  card.style.display='none';noRes.style.display='none';
  const fd=new FormData();
  fd.append('action','uid_lookup_ajax');
  fd.append('q',q);fd.append('stype',stype);
  fetch('tp_dashboard.php',{method:'POST',body:fd})
  .then(r=>r.json())
  .then(data=>{
    status.style.display='none';
    if(data.error){alert('DB Error: '+data.error);return;}
    if(!data.results||data.results.length===0){noRes.style.display='block';return;}
    countEl.textContent=data.count+' record'+(data.count!==1?'s':'');
    tbody.innerHTML='';
    data.results.forEach((r,i)=>{
      const tr=document.createElement('tr');
      tr.innerHTML=`
        <td style="color:#94a3b8">${i+1}</td>
        <td class="mono" style="color:#1e293b;font-weight:600">${esc(r.original_uid)}</td>
        <td class="mono" style="color:var(--purple);word-break:break-all;max-width:260px">${esc(r.encrypted_uid)}</td>
        <td><b style="font-family:'Bebas Neue',sans-serif;color:var(--blue);font-size:14px">${esc(r.sid||'—')}</b></td>
        <td><span style="background:rgba(20,184,166,.1);color:#0f766e;border:1px solid rgba(20,184,166,.3);border-radius:4px;padding:1px 7px;font-size:10px;font-weight:600">${esc(r.source||'—')}</span></td>
        <td>
          <button onclick="copyToClip('${esc(r.original_uid)}',this)" style="padding:2px 8px;background:var(--navy);color:#fff;border:none;border-radius:4px;font-size:9px;cursor:pointer;margin-right:4px">Copy Orig</button>
          <button onclick="copyToClip('${esc(r.encrypted_uid)}',this)" style="padding:2px 8px;background:rgba(139,92,246,.15);color:#7c3aed;border:1px solid rgba(139,92,246,.3);border-radius:4px;font-size:9px;cursor:pointer">Copy Enc</button>
        </td>`;
      tbody.appendChild(tr);
    });
    card.style.display='block';
  })
  .catch(e=>{status.style.display='none';alert('Fetch error: '+e.message);});
}
function doUidClear(){
  document.getElementById('uidSearchInput').value='';
  document.getElementById('uidResultCard').style.display='none';
  document.getElementById('uidNoResult').style.display='none';
  document.getElementById('uidSearchStatus').style.display='none';
}
function copyToClip(txt,btn){
  navigator.clipboard.writeText(txt).then(()=>{const o=btn.textContent;btn.textContent='Copied!';setTimeout(()=>btn.textContent=o,1800);});
}
function esc(s){const d=document.createElement('div');d.textContent=s||'';return d.innerHTML;}

let idleTimer;
function resetIdle(){clearTimeout(idleTimer);idleTimer=setTimeout(()=>location.reload(),90000);}
['click','mousemove','keydown','scroll','touchstart'].forEach(ev=>document.addEventListener(ev,resetIdle,{passive:true}));
resetIdle();
</script>
</body>
</html>
