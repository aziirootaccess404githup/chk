<?php
// ============================================================
// Exazon Research — project_view.php
// Full Project Detail page: stats, redirect URLs, notes,
// client report link, API tokens, assigned vendors, recent leads.
// ============================================================
session_start();
require_once __DIR__ . '/inc_exz.php';

// ── AUTH (reuse index.php's session gates — no separate login here) ──
if (empty($_SESSION['ex_auth']) || empty($_SESSION['ex_team_id'])) {
    header('Location: index.php'); exit;
}

$db = exz_db();
$sid = trim($_GET['sid'] ?? '');
if (!$sid) { header('Location: index.php#projects'); exit; }

$msg = '';

// ── ACTIONS ─────────────────────────────────────────────────
if (isset($_GET['toggle_project'])) {
    $cur = $db->prepare("SELECT status FROM project_settings WHERE survey_id=?"); $cur->execute([$sid]);
    $now = $cur->fetchColumn();
    $next = ($now === 'active') ? 'paused' : 'active';
    $db->prepare("UPDATE project_settings SET status=? WHERE survey_id=?")->execute([$next,$sid]);
    header("Location: project_view.php?sid=".urlencode($sid)); exit;
}
if (isset($_POST['save_project_note'])) {
    $db->prepare("UPDATE project_settings SET notes=? WHERE survey_id=?")
        ->execute([trim($_POST['pn_text'] ?? ''), $sid]);
    header("Location: project_view.php?sid=".urlencode($sid)."&msg=".urlencode('Note saved')); exit;
}
if (isset($_POST['save_auto_report'])) {
    $ar_enabled = isset($_POST['ar_enabled']) ? 1 : 0;
    $ar_freq = in_array($_POST['ar_freq'] ?? '', ['daily','weekly']) ? $_POST['ar_freq'] : 'weekly';
    $ar_email = trim($_POST['ar_email'] ?? '');
    $db->prepare("UPDATE project_settings SET auto_report_enabled=?, auto_report_freq=?, auto_report_email=? WHERE survey_id=?")
        ->execute([$ar_enabled, $ar_freq, $ar_email, $sid]);
    exz_log_audit($db, 'update_auto_report', "SID: $sid -> ".($ar_enabled ? "ON ($ar_freq)" : "OFF"));
    header("Location: project_view.php?sid=".urlencode($sid)."&msg=".urlencode('Auto-report settings saved')); exit;
}
if (isset($_POST['save_project_edit'])) {
    exz_ensure_project_timeline_columns($db);
    $name   = trim($_POST['pe_name'] ?? '');
    $client = intval($_POST['pe_client'] ?? 0) ?: null;
    $ptype  = in_array($_POST['pe_type'] ?? '', ['direct','thirdparty']) ? $_POST['pe_type'] : 'direct';
    $cpi    = floatval($_POST['pe_cpi'] ?? 0);
    $vcost  = floatval($_POST['pe_vcost'] ?? 0);
    $target = intval($_POST['pe_target'] ?? 0);
    $liveurl= trim($_POST['pe_liveurl'] ?? '');
    $testurl= trim($_POST['pe_testurl'] ?? '');
    $desc   = trim($_POST['pe_description'] ?? '');
    $encrypt= isset($_POST['pe_encrypt']) ? 1 : 0;
    $startdate = $_POST['pe_start_date'] !== '' ? $_POST['pe_start_date'] : null;
    $enddate   = $_POST['pe_end_date'] !== '' ? $_POST['pe_end_date'] : null;
    $pmanager  = trim($_POST['pe_manager'] ?? '');
    $db->prepare("UPDATE project_settings SET project_name=?,client_id=?,project_type=?,cpi=?,vendor_cost=?,target=?,live_url=?,test_url=?,description=?,encrypt_uid=?,start_date=?,end_date=?,project_manager=? WHERE survey_id=?")
        ->execute([$name,$client,$ptype,$cpi,$vcost,$target,$liveurl,$testurl,$desc,$encrypt,$startdate,$enddate,$pmanager,$sid]);
    exz_log_audit($db, 'edit_project', "SID: $sid");
    header("Location: project_view.php?sid=".urlencode($sid)."&msg=".urlencode('Project updated')); exit;
}
if (isset($_POST['generate_share_link'])) {
    $token = bin2hex(random_bytes(16));
    $db->prepare("UPDATE exz_share_links SET is_revoked=1 WHERE survey_id=?")->execute([$sid]); // retire old ones
    $db->prepare("INSERT INTO exz_share_links (survey_id,token) VALUES (?,?)")->execute([$sid,$token]);
    exz_log_audit($db, 'generate_share_link', "SID: $sid");
    header("Location: project_view.php?sid=".urlencode($sid)."&msg=".urlencode('Report link generated')); exit;
}
if (isset($_GET['revoke_share_link'])) {
    $db->prepare("UPDATE exz_share_links SET is_revoked=1 WHERE survey_id=?")->execute([$sid]);
    exz_log_audit($db, 'revoke_share_link', "SID: $sid");
    header("Location: project_view.php?sid=".urlencode($sid)); exit;
}
// ── PM ACTIVITY LOG — add/delete handlers ─────────────────────
// ── CLONE PROJECT (Parent/Child) ──────────────────────────────
// Copies the settings that genuinely carry over (client, CPI, target,
// encryption, description, IR/LOI, prescreen template) into a NEW project
// with a new SID, and marks the new project's parent_sid = this one.
// Live URL / Test URL are deliberately left BLANK on the clone, since a
// different market/client almost always means a different survey link —
// safer to force it to be entered fresh than silently copy the wrong one.
if (isset($_POST['clone_project'])) {
    exz_ensure_parent_sid_column($db);
    exz_ensure_project_template_column($db);
    exz_ensure_project_timeline_columns($db);
    $new_sid = trim($_POST['clone_new_sid'] ?? '');
    $new_name = trim($_POST['clone_new_name'] ?? '');
    if ($new_sid && preg_match('/^[A-Za-z0-9_-]+$/', $new_sid)) {
        $existsChk = $db->prepare("SELECT id FROM project_settings WHERE survey_id=?");
        $existsChk->execute([$new_sid]);
        if ($existsChk->fetchColumn()) {
            header("Location: project_view.php?sid=".urlencode($sid)."&msg=".urlencode("Clone failed — SID '$new_sid' already exists")); exit;
        }
        $src = $db->prepare("SELECT * FROM project_settings WHERE survey_id=?");
        $src->execute([$sid]);
        $srcRow = $src->fetch();
        if ($srcRow) {
            $db->prepare("INSERT INTO project_settings
                (survey_id, project_name, client_id, target, cpi, vendor_cost, status, project_type, encrypt_uid, ir, loi, description, prescreen_template_id, project_manager, parent_sid)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
                ->execute([
                    $new_sid,
                    $new_name ?: ($srcRow['project_name'] . ' (Clone)'),
                    $srcRow['client_id'], $srcRow['target'], $srcRow['cpi'], $srcRow['vendor_cost'],
                    'active', $srcRow['project_type'], $srcRow['encrypt_uid'], $srcRow['ir'], $srcRow['loi'],
                    $srcRow['description'], $srcRow['prescreen_template_id'] ?? null, $srcRow['project_manager'] ?? '', $sid,
                ]);
            exz_log_audit($db, 'clone_project', "From: $sid -> New: $new_sid");
            header("Location: project_view.php?sid=".urlencode($new_sid)."&msg=".urlencode("Cloned from $sid — set the Live URL for this new project")); exit;
        }
    }
    header("Location: project_view.php?sid=".urlencode($sid)."&msg=".urlencode("Clone failed — please provide a valid new SID")); exit;
}

if (isset($_POST['add_activity_log'])) {
    exz_ensure_pm_activity_table($db);
    $act = trim($_POST['al_activity'] ?? '');
    if ($act) {
        try {
            $db->prepare("INSERT INTO exz_project_activity_log (survey_id, user_name, activity, sub_activity, duration_minutes, notes) VALUES (?,?,?,?,?,?)")
                ->execute([
                    $sid,
                    $_SESSION['ex_team_name'] ?? 'Admin',
                    $act,
                    trim($_POST['al_sub_activity'] ?? ''),
                    intval($_POST['al_duration'] ?? 0),
                    trim($_POST['al_notes'] ?? ''),
                ]);
        } catch (Exception $e) {}
    }
    header("Location: project_view.php?sid=".urlencode($sid)."#activitylog"); exit;
}
if (isset($_GET['delete_activity_log'])) {
    $db->prepare("DELETE FROM exz_project_activity_log WHERE id=? AND survey_id=?")
        ->execute([intval($_GET['delete_activity_log']), $sid]);
    header("Location: project_view.php?sid=".urlencode($sid)."#activitylog"); exit;
}

// ── MULTI-COUNTRY LINK — add/delete handlers ──────────────────
if (isset($_POST['add_country_link'])) {
    exz_ensure_country_links_table($db);
    $ccountry = trim($_POST['cl_country'] ?? '');
    $curl = trim($_POST['cl_url'] ?? '');
    if ($ccountry && $curl) {
        try {
            $db->prepare("INSERT INTO exz_project_country_links (survey_id, country, live_url) VALUES (?,?,?)
                ON DUPLICATE KEY UPDATE live_url=VALUES(live_url)")
                ->execute([$sid, $ccountry, $curl]);
        } catch (Exception $e) {}
    }
    header("Location: project_view.php?sid=".urlencode($sid)."#countrylinks"); exit;
}
if (isset($_GET['delete_country_link'])) {
    $db->prepare("DELETE FROM exz_project_country_links WHERE id=? AND survey_id=?")
        ->execute([intval($_GET['delete_country_link']), $sid]);
    header("Location: project_view.php?sid=".urlencode($sid)."#countrylinks"); exit;
}

if (isset($_POST['assign_vendor'])) {
    $vid = intval($_POST['av_vendor'] ?? 0);
    if ($vid) {
        try {
            exz_ensure_short_code_column($db);
            // Default the assignment's CPI to the project's own Vendor Cost,
            // so it starts in sync instead of showing ₹0.00. Can still be
            // overridden per-vendor afterward via the Edit button.
            $vc = $db->prepare("SELECT vendor_cost FROM project_settings WHERE survey_id=?");
            $vc->execute([$sid]);
            $default_cpi = $vc->fetchColumn() ?: 0;
            $newShortCode = exz_generate_short_code($db);
            $db->prepare("INSERT IGNORE INTO exz_project_vendors (survey_id,vendor_id,cpi,short_code) VALUES (?,?,?,?)")->execute([$sid,$vid,$default_cpi,$newShortCode]);
        }
        catch (Exception $e) {}
    }
    header("Location: project_view.php?sid=".urlencode($sid)); exit;
}
if (isset($_GET['unassign_vendor'])) {
    $db->prepare("DELETE FROM exz_project_vendors WHERE survey_id=? AND vendor_id=?")->execute([$sid, intval($_GET['unassign_vendor'])]);
    header("Location: project_view.php?sid=".urlencode($sid)); exit;
}
if (isset($_GET['toggle_project_vendor'])) {
    $vid_toggle = intval($_GET['toggle_project_vendor']);
    $cur = $db->prepare("SELECT status FROM exz_project_vendors WHERE survey_id=? AND vendor_id=?");
    $cur->execute([$sid, $vid_toggle]);
    $now = $cur->fetchColumn();
    $next = ($now === 'active' || !$now) ? 'paused' : 'active';
    $db->prepare("UPDATE exz_project_vendors SET status=? WHERE survey_id=? AND vendor_id=?")->execute([$next, $sid, $vid_toggle]);
    header("Location: project_view.php?sid=".urlencode($sid)); exit;
}
if (isset($_POST['save_project_vendor_edit'])) {
    exz_ensure_click_quota_column($db);
    exz_ensure_prescreener_toggle_column($db);
    $vid_edit = intval($_POST['pv_vendor_id'] ?? 0);
    $cpi_edit = $_POST['pv_cpi'] !== '' ? floatval($_POST['pv_cpi']) : null;
    $limit_edit = $_POST['pv_limit'] !== '' ? intval($_POST['pv_limit']) : null;
    $click_quota_edit = $_POST['pv_click_quota'] !== '' ? intval($_POST['pv_click_quota']) : null;
    $show_prescreener_edit = isset($_POST['pv_show_prescreener']) ? 1 : 0;
    $db->prepare("UPDATE exz_project_vendors SET cpi=?, max_limit=?, click_quota=?, show_prescreener=? WHERE survey_id=? AND vendor_id=?")
        ->execute([$cpi_edit, $limit_edit, $click_quota_edit, $show_prescreener_edit, $sid, $vid_edit]);
    header("Location: project_view.php?sid=".urlencode($sid)); exit;
}
if (isset($_GET['delete_all_leads'])) {
    $cnt = $db->prepare("SELECT COUNT(*) FROM survey_responses WHERE survey_id=?"); $cnt->execute([$sid]);
    $n = $cnt->fetchColumn();
    $db->prepare("DELETE FROM survey_responses WHERE survey_id=?")->execute([$sid]);
    exz_log_audit($db, 'delete_all_leads', "SID: $sid ($n rows)");
    header("Location: project_view.php?sid=".urlencode($sid)."&msg=".urlencode("$n lead(s) deleted")); exit;
}

if (isset($_GET['msg'])) $msg = $_GET['msg'];

// ── PROJECT DATA ────────────────────────────────────────────
exz_ensure_parent_sid_column($db);
exz_ensure_project_timeline_columns($db);
$pp = $db->prepare("SELECT ps.*, c.client_name AS cname FROM project_settings ps
    LEFT JOIN exz_clients c ON c.id = ps.client_id WHERE ps.survey_id=? LIMIT 1");
$pp->execute([$sid]);
$proj = $pp->fetch();
if (!$proj) { header('Location: index.php#projects'); exit; }

// ── PARENT / CHILD PROJECT LINKS ──────────────────────────────
$parent_project = null;
if (!empty($proj['parent_sid'])) {
    $ppq = $db->prepare("SELECT survey_id, project_name FROM project_settings WHERE survey_id=?");
    $ppq->execute([$proj['parent_sid']]);
    $parent_project = $ppq->fetch();
}
$child_projects = [];
try {
    $cpq = $db->prepare("SELECT survey_id, project_name, status FROM project_settings WHERE parent_sid=? ORDER BY created_at ASC");
    $cpq->execute([$sid]);
    $child_projects = $cpq->fetchAll();
} catch (Exception $e) {}

$master_clients = [];
try { $master_clients = $db->query("SELECT * FROM exz_clients ORDER BY client_name ASC")->fetchAll(); } catch (Exception $e) {}

// ── STATS ───────────────────────────────────────────────────
$st = $db->prepare("SELECT COUNT(*) as total, SUM(status='complete') as completes, SUM(status='terminate') as terminates
    FROM survey_responses WHERE survey_id=?");
$st->execute([$sid]);
$stats = $st->fetch();
$total = (int)($stats['total'] ?? 0);
$completes = (int)($stats['completes'] ?? 0);
$terminates = (int)($stats['terminates'] ?? 0);

// ── ASSIGNED VENDORS ────────────────────────────────────────
// ── VENDOR BREAKDOWN (per-vendor stats for THIS project) ──────
// Matches Kishan's panel's "Vendor Breakdown" table — shows every
// vendor working on this project with their clicks/completes/
// terminates/quality-fail/overquota counts + conversion%, in one
// place, without needing to open the Vendors list separately.
$vendor_breakdown = [];
try {
    $vb = $db->prepare("SELECT
            COALESCE(v.vendor_name, 'No Vendor / Direct') AS vendor_name,
            v.id AS vendor_id,
            COUNT(DISTINCT ss.id) AS clicks,
            SUM(CASE WHEN sr.status='complete' THEN 1 ELSE 0 END) AS completes,
            SUM(CASE WHEN sr.status='terminate' THEN 1 ELSE 0 END) AS terminates,
            SUM(CASE WHEN sr.status IN ('qc','quality') THEN 1 ELSE 0 END) AS quality_fail,
            SUM(CASE WHEN sr.status='overquota' THEN 1 ELSE 0 END) AS overquota
        FROM survey_starts ss
        LEFT JOIN exz_vendors v ON v.id = ss.vendor_id
        LEFT JOIN survey_responses sr ON sr.survey_id = ss.sid AND sr.respondent = ss.uid
        WHERE ss.sid = ?
        GROUP BY v.id, v.vendor_name
        ORDER BY clicks DESC");
    $vb->execute([$sid]);
    $vendor_breakdown = $vb->fetchAll();
} catch (Exception $e) {}

$assigned_vendors = [];
try {
    exz_ensure_short_code_column($db);
    exz_ensure_click_quota_column($db);
    exz_ensure_prescreener_toggle_column($db);
    $av = $db->prepare("SELECT v.*, pv.assigned_at, pv.status AS pv_status, pv.cpi AS pv_cpi, pv.max_limit AS pv_limit, pv.click_quota AS pv_click_quota, pv.show_prescreener AS pv_show_prescreener, pv.short_code AS pv_short_code FROM exz_project_vendors pv
        JOIN exz_vendors v ON v.id = pv.vendor_id WHERE pv.survey_id=? ORDER BY pv.assigned_at DESC");
    $av->execute([$sid]);
    $assigned_vendors = $av->fetchAll();
    // Backfill short_code for any assignments made before this feature existed
    foreach ($assigned_vendors as &$avrow) {
        if (empty($avrow['pv_short_code'])) {
            $newCode = exz_generate_short_code($db);
            $db->prepare("UPDATE exz_project_vendors SET short_code=? WHERE survey_id=? AND vendor_id=?")->execute([$newCode, $sid, $avrow['id']]);
            $avrow['pv_short_code'] = $newCode;
        }
    }
    unset($avrow);
} catch (Exception $e) {}

// ── Multi-Country Link ──────────────────────────────────────
exz_ensure_country_links_table($db);
$country_links = [];
try {
    $clq = $db->prepare("SELECT * FROM exz_project_country_links WHERE survey_id=? ORDER BY country ASC");
    $clq->execute([$sid]);
    $country_links = $clq->fetchAll();
} catch (Exception $e) {}

// ── PM Activity Log ──────────────────────────────────────────
exz_ensure_pm_activity_table($db);
$activity_logs = [];
try {
    $alq = $db->prepare("SELECT * FROM exz_project_activity_log WHERE survey_id=? ORDER BY logged_at DESC LIMIT 100");
    $alq->execute([$sid]);
    $activity_logs = $alq->fetchAll();
} catch (Exception $e) {}

// Per-project summary: total time + activity-count, per team-member, on THIS project
$activity_summary = [];
try {
    $asq = $db->prepare("SELECT user_name, SUM(duration_minutes) AS total_minutes, COUNT(*) AS total_activities
        FROM exz_project_activity_log WHERE survey_id=? GROUP BY user_name ORDER BY total_minutes DESC");
    $asq->execute([$sid]);
    $activity_summary = $asq->fetchAll();
} catch (Exception $e) {}

$all_vendors = [];
try { $all_vendors = $db->query("SELECT id, vendor_name FROM exz_vendors ORDER BY vendor_name ASC")->fetchAll(); } catch (Exception $e) {}

// ── RECENT LEADS (with pagination) ────────────────────────────
$leads_per_page = intval($_GET['leads_per_page'] ?? 50);
if (!in_array($leads_per_page, [10,25,50,100])) $leads_per_page = 50;
$leads_page = max(1, intval($_GET['leads_page'] ?? 1));
$leads_offset = ($leads_page - 1) * $leads_per_page;
$leads_total = 0;
$recent_leads = [];
try {
    exz_ensure_postback_status_columns($db);
    $ltc = $db->prepare("SELECT COUNT(*) FROM survey_responses WHERE survey_id=?");
    $ltc->execute([$sid]);
    $leads_total = (int)$ltc->fetchColumn();

    $rl = $db->prepare("SELECT sr.respondent, sr.status, sr.country, sr.device, sr.loi_seconds, sr.ip, sr.created_at, sr.postback_status, um.original_uid
        FROM survey_responses sr
        LEFT JOIN exz_uid_mapping um ON um.encrypted_uid = sr.respondent AND um.survey_id = sr.survey_id
        WHERE sr.survey_id=? ORDER BY sr.created_at DESC LIMIT $leads_per_page OFFSET $leads_offset");
    $rl->execute([$sid]);
    $recent_leads = $rl->fetchAll();
} catch (Exception $e) {}
$leads_total_pages = max(1, ceil($leads_total / $leads_per_page));

// ── ENTRY / CLICK LOG (individual survey_starts records) ──────
// The "Starts / Dropout" stat only ever showed a NUMBER — no way to see
// WHO actually clicked, or which specific clicks never got a matching
// completion back (the "stuck dropout" respondents). This shows the
// individual survey_starts rows for this project, each flagged with
// whether a matching survey_responses row exists yet.
$entries_per_page = intval($_GET['entries_per_page'] ?? 50);
if (!in_array($entries_per_page, [10,25,50,100])) $entries_per_page = 50;
$entries_page = max(1, intval($_GET['entries_page'] ?? 1));
$entries_offset = ($entries_page - 1) * $entries_per_page;
$entries_total = 0;
$entry_log = [];
try {
    $etc = $db->prepare("SELECT COUNT(*) FROM survey_starts WHERE sid=?");
    $etc->execute([$sid]);
    $entries_total = (int)$etc->fetchColumn();

    $el = $db->prepare("SELECT ss.uid, ss.source, ss.vendor_id, ss.ip, ss.start_time, v.vendor_name,
            sr.status AS completion_status
        FROM survey_starts ss
        LEFT JOIN exz_vendors v ON v.id = ss.vendor_id
        LEFT JOIN survey_responses sr ON sr.survey_id = ss.sid AND sr.respondent = ss.uid
        WHERE ss.sid=? ORDER BY ss.start_time DESC LIMIT $entries_per_page OFFSET $entries_offset");
    $el->execute([$sid]);
    $entry_log = $el->fetchAll();
} catch (Exception $e) {}
$entries_total_pages = max(1, ceil($entries_total / $entries_per_page));

// ── SHARE LINK ──────────────────────────────────────────────
$share_link = null;
try {
    $sl = $db->prepare("SELECT * FROM exz_share_links WHERE survey_id=? AND is_revoked=0 ORDER BY created_at DESC LIMIT 1");
    $sl->execute([$sid]);
    $share_link = $sl->fetch();
} catch (Exception $e) {}

$host = $_SERVER['HTTP_HOST'];
function fmt_loi_pv($sec){ if($sec===null) return '—'; $sec=(int)$sec; return sprintf('%dm %ds', intdiv($sec,60), $sec%60); }

// ── BULK ENTRY-LINK DOWNLOAD ────────────────────────────────
// Exports every assigned vendor's Entry Link + Short Link for this
// project as a single CSV — instead of opening the 🔗 modal one vendor
// at a time. Purely a convenience export; does not change any data.
if (isset($_GET['download_links'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9_-]/', '_', $sid) . '_entry_links.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Vendor Name', 'Entry Link', 'Entry Link (Pre-screener)', 'Short Link']);
    foreach ($assigned_vendors as $v) {
        $entryLink = "https://$host/vendor.php?sid=" . urlencode($sid) . "&vid=" . $v['id'] . "&uid=[UID]";
        $preLink   = "https://$host/vendor.php?sid=" . urlencode($sid) . "&vid=" . $v['id'] . "&pre=1&uid=[UID]";
        $shortLink = !empty($v['pv_short_code']) ? "https://$host/exaverify.php?c=" . urlencode($v['pv_short_code']) . "&pid=[UID]" : '';
        fputcsv($out, [$v['vendor_name'], $entryLink, $preLink, $shortLink]);
    }
    fclose($out);
    exit;
}

// ── ENTRY/CLICK LOG — full CSV download (all rows, not just current page) ──
if (isset($_GET['download_entries'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9_-]/', '_', $sid) . '_entry_log.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['UID', 'Vendor', 'IP', 'Time (UTC)', 'Completion Status']);
    try {
        $dl = $db->prepare("SELECT ss.uid, ss.ip, ss.start_time, v.vendor_name, sr.status AS completion_status
            FROM survey_starts ss
            LEFT JOIN exz_vendors v ON v.id = ss.vendor_id
            LEFT JOIN survey_responses sr ON sr.survey_id = ss.sid AND sr.respondent = ss.uid
            WHERE ss.sid=? ORDER BY ss.start_time DESC");
        $dl->execute([$sid]);
        while ($row = $dl->fetch()) {
            fputcsv($out, [$row['uid'], $row['vendor_name'] ?: '—', $row['ip'] ?: '—', $row['start_time'], $row['completion_status'] ? ucfirst($row['completion_status']) : 'Pending']);
        }
    } catch (Exception $e) {}
    fclose($out);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Project Details — <?= htmlspecialchars($proj['project_name'] ?: $sid) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --navy:#0a1628;--navy2:#112040;--blue:#1b4fd8;--blue2:#3b82f6;
  --gold:#c8a84b;--muted:#94a3b8;--green:#22c55e;--red:#ef4444;--yellow:#f59e0b;--purple:#8b5cf6;
}
body{font-family:'DM Sans',sans-serif;background:#f4f6fb;color:#0f172a;margin:0}

/* SIDEBAR LAYOUT (matches index.php) */
.app-layout{display:flex;min-height:100vh}
.sidebar{width:250px;flex-shrink:0;background:var(--navy);border-right:1px solid rgba(59,130,246,0.15);
         position:fixed;top:0;left:0;bottom:0;overflow-y:auto;overflow-x:hidden;z-index:200;padding:20px 14px;
         transition:width .2s ease}
.sidebar.collapsed{width:60px}
.sidebar.collapsed:hover{width:250px}
.sidebar-toggle{position:absolute;top:18px;right:10px;background:rgba(255,255,255,0.08);border:none;color:var(--muted);
                 width:22px;height:22px;border-radius:6px;cursor:pointer;font-size:12px;line-height:1;z-index:5}
.sidebar.collapsed .sidebar-brand,.sidebar.collapsed .sidebar-user,.sidebar.collapsed .sidebar-section-lbl{opacity:0;transition:opacity .1s}
.sidebar.collapsed:hover .sidebar-brand,.sidebar.collapsed:hover .sidebar-user,
.sidebar.collapsed:hover .sidebar-section-lbl{opacity:1}
.sidebar.collapsed .sb-link{overflow:hidden}
.sidebar.collapsed:hover .sb-link{overflow:visible}
.app-content{flex:1;margin-left:250px;min-width:0;transition:margin-left .2s ease}
.app-content.sidebar-collapsed{margin-left:60px}
.sidebar-brand{display:flex;align-items:center;gap:10px;padding:0 6px 18px;border-bottom:1px solid rgba(255,255,255,0.08);margin-bottom:16px;white-space:nowrap}
.sidebar .nav-logo{width:34px;height:34px;border-radius:50%;border:2px solid rgba(59,130,246,0.3);background:#fff;flex-shrink:0}
.sidebar .nav-name{font-family:'Bebas Neue',sans-serif;font-size:15px;letter-spacing:2px;color:#fff;line-height:1.2}
.sidebar .nav-tag{font-size:8px;letter-spacing:2px;text-transform:uppercase;color:var(--gold)}
.sidebar-user{padding:0 6px 16px;margin-bottom:10px;white-space:nowrap}
.sidebar-user-name{font-size:12px;font-weight:700;color:#fff}
.sidebar-user-role{font-size:9px;letter-spacing:1px;text-transform:uppercase;color:var(--gold)}
.sidebar-section-lbl{font-size:9px;letter-spacing:2px;text-transform:uppercase;color:rgba(255,255,255,0.25);padding:14px 6px 6px;white-space:nowrap}
.sb-link{display:flex;align-items:center;gap:8px;width:100%;text-align:left;padding:9px 10px;font-size:12px;font-weight:600;
         color:var(--muted);background:none;border:none;border-radius:8px;cursor:pointer;white-space:nowrap;transition:all .15s;text-decoration:none;box-sizing:border-box}
.sb-link.active,.sb-link:hover{color:#fff;background:rgba(59,130,246,0.15)}
@media(max-width:900px){
  .sidebar{position:static;width:100%;height:auto;display:flex;flex-wrap:wrap}
  .app-content{margin-left:0}
}

.topbar{background:var(--navy);padding:14px 28px;display:flex;align-items:center;justify-content:space-between}
.topbar-title{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:2px;color:#fff}
.content{max-width:1200px;margin:0 auto;padding:24px 20px}
.msg-banner{background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);color:#15803d;border-radius:8px;padding:12px 16px;font-size:13px;margin-bottom:18px}
.btn{display:inline-flex;align-items:center;gap:6px;padding:9px 18px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;border:none;text-decoration:none}
.btn-ghost{background:#fff;color:#374151;border:1px solid #e2e8f0}
.btn-amber{background:linear-gradient(135deg,#f59e0b,#d97706);color:#fff}
.btn-green{background:linear-gradient(135deg,#16a34a,#22c55e);color:#fff}
.btn-blue{background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff}
.btn-red{background:rgba(239,68,68,.12);color:#dc2626}
.stat-row{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:18px 0}
.stat-card{background:#fff;border-radius:12px;padding:18px;border-top:4px solid var(--blue2)}
.stat-card.green{border-top-color:var(--green)}
.stat-card.orange{border-top-color:var(--yellow)}
.stat-lbl{font-size:11px;letter-spacing:1px;text-transform:uppercase;color:var(--muted);margin-bottom:8px}
.stat-val{font-size:32px;font-weight:700}
.card{background:#fff;border-radius:12px;padding:20px;margin-bottom:18px;border:1px solid #e5e9f2}
.card-title{font-size:11px;letter-spacing:1.5px;text-transform:uppercase;color:var(--muted);font-weight:700;margin-bottom:14px}
.info-row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f3f9;font-size:13px}
.info-row:last-child{border-bottom:none}
.info-row span:first-child{color:var(--muted)}
.info-row span:last-child{font-weight:600}
.pill{display:inline-block;padding:3px 12px;border-radius:20px;font-size:11px;font-weight:700}
.pill-complete{background:rgba(34,197,94,.12);color:#15803d}
.pill-terminate{background:rgba(245,158,11,.12);color:#b45309}
.pill-overquota{background:rgba(59,130,246,.12);color:#1e40af}
.pill-qualityfail{background:rgba(239,68,68,.12);color:#b91c1c}
.url-row{margin-bottom:14px}
.url-box{display:flex;gap:8px;align-items:center;background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-family:monospace;font-size:11px;color:#334155;word-break:break-all}
.url-box button{flex-shrink:0;background:#e2e8f0;border:none;border-radius:6px;padding:5px 10px;font-size:11px;font-weight:600;cursor:pointer}
table{width:100%;border-collapse:collapse}
th{padding:8px 10px;font-size:10px;background:#f8faff;text-align:left;color:var(--muted);text-transform:uppercase;letter-spacing:.5px}
td{padding:8px 10px;font-size:12px;border-top:1px solid #f1f3f9}
textarea{width:100%;background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-family:'DM Sans',sans-serif;font-size:13px;min-height:80px;resize:vertical}
select,input[type=text]{background:#f8faff;border:1px solid #e2e8f0;border-radius:6px;padding:6px 10px;font-size:12px}
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:200;align-items:center;justify-content:center}
.modal-overlay.open{display:flex}
.modal{background:#fff;border-radius:16px;padding:26px;max-width:520px;width:90%;max-height:85vh;overflow-y:auto}
.modal-field{margin-bottom:12px}
.modal-field .lbl{font-size:10px;font-weight:600;color:#64748b;letter-spacing:1px;text-transform:uppercase;margin-bottom:4px}
.modal-field input[type=text],.modal-field input[type=number],.modal-field select,.modal-field textarea{width:100%;background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:12px;font-family:'DM Sans',sans-serif;outline:none}
.modal-field textarea{resize:vertical;min-height:60px}
</style>
</head>
<body>

<div class="app-layout">
<aside class="sidebar" id="appSidebar">
  <button class="sidebar-toggle" onclick="toggleSidebar()" title="Collapse/Expand sidebar">☰</button>
  <div class="sidebar-brand">
    <img src="logo.php" class="nav-logo" alt="Exazon">
    <div>
      <div class="nav-name">Exazon Research</div>
      <div class="nav-tag">Survey Dashboard v5</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="sidebar-user-name"><?= htmlspecialchars($_SESSION['ex_team_name'] ?? '') ?></div>
    <div class="sidebar-user-role"><?= htmlspecialchars($_SESSION['ex_team_role'] ?? '') ?></div>
  </div>

  <div class="sidebar-section-lbl">Main</div>
  <a class="sb-link" href="index.php#overview">📊 Dashboard</a>
  <a class="sb-link active" href="index.php#projects">📁 Projects</a>
  <a class="sb-link" href="index.php#responses">📋 Leads</a>
  <a class="sb-link" href="index.php#fraud">🚨 Fraud Detection</a>
  <a class="sb-link" href="index.php#screener">📄 Screener Data</a>
  <a class="sb-link" href="index.php#searchlookup">🔍 Search &amp; Lookup</a>
  <a class="sb-link" href="index.php#notes">📝 Notes</a>
  <a class="sb-link" href="index.php#billing">🧾 Billing</a>
  <a class="sb-link" href="index.php#qualityscore">⭐ Quality Score</a>
  <a class="sb-link" href="index.php#reconciletab">⚖️ Reconcile</a>
  <a class="sb-link" href="index.php#charts">📈 Analytics</a>
  <a class="sb-link" href="index.php#feasibility">📐 Feasibility Calc</a>

  <div class="sidebar-section-lbl">Management</div>
  <a class="sb-link" href="index.php#clientsmaster">🏢 Clients</a>
  <a class="sb-link" href="index.php#vendors">👥 Vendors</a>
  <a class="sb-link" href="index.php#clients">👤 Client Accounts</a>

  <div class="sidebar-section-lbl">Admin</div>
  <a class="sb-link" href="index.php#alerts">🔔 Alert Settings</a>
  <a class="sb-link" href="index.php#auditlog">📜 Audit Log</a>
  <?php if (($_SESSION['ex_team_role'] ?? '') === 'superadmin'): ?>
  <a class="sb-link" href="index.php#team">👥 Team</a>
  <?php endif; ?>

  <div class="sidebar-section-lbl">Account</div>
  <a class="sb-link" href="index.php#changepass">🔑 Change Password</a>
  <a class="sb-link" href="index.php?logout=1" style="color:#f87171">⏻ Logout</a>
</aside>

<div class="app-content" id="appContent">

<div class="topbar">
  <div class="topbar-title">Project Details</div>
  <a href="index.php#projects" class="btn btn-ghost">← Back to Projects</a>
</div>

<div class="content">
  <?php if($msg): ?><div class="msg-banner">✓ <?= htmlspecialchars($msg) ?></div><?php endif; ?>

  <div style="display:flex;gap:10px;margin-bottom:6px">
    <a href="?sid=<?= urlencode($sid) ?>&toggle_project=1" class="btn <?= $proj['status']==='active'?'btn-amber':'btn-green' ?>"><?= $proj['status']==='active' ? '⏸ Pause Project' : '▶ Resume Project' ?></a>
    <button type="button" onclick="document.getElementById('editProjectModal').classList.add('open')" class="btn btn-ghost">✏ Edit Project</button>
    <button type="button" onclick="document.getElementById('cloneProjectModal').classList.add('open')" class="btn btn-ghost">⧉ Clone Project</button>
  </div>

  <?php if ($parent_project || !empty($child_projects)): ?>
  <div class="card" style="margin-bottom:14px;background:#f8faff">
    <?php if ($parent_project): ?>
      <div style="font-size:12px;color:#64748b">🔼 Cloned from: <a href="project_view.php?sid=<?= urlencode($parent_project['survey_id']) ?>" style="color:var(--blue2);font-weight:600"><?= htmlspecialchars($parent_project['project_name'] ?: $parent_project['survey_id']) ?></a> (<?= htmlspecialchars($parent_project['survey_id']) ?>)</div>
    <?php endif; ?>
    <?php if (!empty($child_projects)): ?>
      <div style="font-size:12px;color:#64748b;margin-top:<?= $parent_project ? '8px' : '0' ?>">🔽 Child Projects (<?= count($child_projects) ?>):
        <?php foreach ($child_projects as $cp): ?>
        <a href="project_view.php?sid=<?= urlencode($cp['survey_id']) ?>" style="color:var(--blue2);font-weight:600;margin-right:10px"><?= htmlspecialchars($cp['project_name'] ?: $cp['survey_id']) ?> (<?= htmlspecialchars($cp['survey_id']) ?>)</a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <div class="stat-row">
    <div class="stat-card"><div class="stat-lbl">Clicks</div><div class="stat-val"><?= $total ?></div></div>
    <div class="stat-card green"><div class="stat-lbl">Completes</div><div class="stat-val"><?= $completes ?></div></div>
    <div class="stat-card orange"><div class="stat-lbl">Terminates</div><div class="stat-val"><?= $terminates ?></div></div>
  </div>

  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:18px">
    <div class="card">
      <div class="card-title">Project Info</div>
      <div class="info-row"><span>Project Name</span><span><?= htmlspecialchars($proj['project_name'] ?: '—') ?></span></div>
      <div class="info-row"><span>Project ID</span><span><?= htmlspecialchars($sid) ?></span></div>
      <div class="info-row"><span>Client</span><span><?= htmlspecialchars($proj['cname'] ?: '—') ?></span></div>
      <div class="info-row"><span>CPI</span><span>₹<?= number_format($proj['cpi'],2) ?></span></div>
      <div class="info-row"><span>Vendor Cost</span><span>₹<?= number_format($proj['vendor_cost'],2) ?></span></div>
      <div class="info-row"><span>IR%</span><span><?= number_format($proj['ir'] ?? 0,2) ?>%</span></div>
      <div class="info-row"><span>LOI</span><span><?= intval($proj['loi'] ?? 0) ?> min</span></div>
      <div class="info-row"><span>Max Completes (Quota)</span><span><?= intval($proj['target']) > 0 ? intval($proj['target']) : 'Unlimited' ?></span></div>
      <div class="info-row"><span>Start Date</span><span><?= !empty($proj['start_date']) ? date('d M Y', strtotime($proj['start_date'])) : '—' ?></span></div>
      <div class="info-row"><span>End Date</span><span><?= !empty($proj['end_date']) ? date('d M Y', strtotime($proj['end_date'])) : '—' ?></span></div>
      <div class="info-row"><span>Project Manager</span><span><?= htmlspecialchars($proj['project_manager'] ?: '—') ?></span></div>
      <div class="info-row"><span>Status</span><span><?= ucfirst($proj['status']) ?></span></div>
      <div class="info-row"><span>Encryption</span><span><?= !empty($proj['encrypt_uid']) ? 'ON' : 'OFF' ?></span></div>
      <div class="info-row"><span>Type</span><span><?= ucfirst($proj['project_type']) ?></span></div>
      <?php if(!empty($proj['test_url'])): ?>
      <div class="info-row" style="flex-direction:column;align-items:flex-start;gap:4px"><span>Test Survey URL</span><span style="font-size:11px;word-break:break-all;font-weight:400"><a href="<?= htmlspecialchars(str_replace(['[UID]','[SID]'], ['TEST_UID', $sid], $proj['test_url'])) ?>" target="_blank" style="color:var(--blue2)"><?= htmlspecialchars($proj['test_url']) ?></a></span></div>
      <?php endif; ?>
    </div>

    <div class="card">
      <div class="card-title">Description / Study Parameters</div>
      <?php if(!empty($proj['description'])): ?>
      <div style="font-size:13px;color:#334155;line-height:1.7"><?= nl2br(htmlspecialchars($proj['description'])) ?></div>
      <?php else: ?>
      <div style="font-size:13px;color:#94a3b8">No description added yet. Click "Edit Project" to add study parameters.</div>
      <?php endif; ?>
    </div>

    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
        <div class="card-title" style="margin-bottom:0">Redirect URLs</div>
        <select id="urlTypePicker" onchange="showUrlType(this.value)" style="width:150px">
          <option value="dynamic">Dynamic</option>
          <option value="static">Static</option>
        </select>
      </div>
      <?php $statuses = ['complete'=>['pill-complete','COMPLETE'],'terminate'=>['pill-terminate','TERMINATE'],'quotafull'=>['pill-overquota','OVERQUOTA'],'qc'=>['pill-qualityfail','QUALITY FAIL']]; ?>
      <?php $static_pages = ['complete'=>['pill-complete','complete.html'],'terminate'=>['pill-terminate','terminate.html'],'quotafull'=>['pill-overquota','quota-full.html'],'qc'=>['pill-qualityfail','quality-fail.html']]; ?>

      <div id="urltype-dynamic">
        <div style="font-size:11px;color:#94a3b8;margin-bottom:10px">Via track.php — SID-authority + status-lock automatically apply</div>
        <?php foreach($statuses as $st_key => $info): ?>
        <div class="url-row">
          <span class="pill <?= $info[0] ?>"><?= $info[1] ?></span>
          <div class="url-box" style="margin-top:6px">
            <span style="flex:1"><?= "https://$host/pages/track.php?status=$st_key&sid=".urlencode($sid)."&uid=[UID]" ?></span>
            <button onclick="copyText(this)" data-text="https://<?= $host ?>/pages/track.php?status=<?= $st_key ?>&sid=<?= urlencode($sid) ?>&uid=[UID]">Copy</button>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <div id="urltype-static" style="display:none">
        <div style="font-size:11px;color:#94a3b8;margin-bottom:10px">Direct to status pages — no tracking logic in between</div>
        <?php foreach($static_pages as $st_key => $info): ?>
        <div class="url-row">
          <span class="pill <?= $info[0] ?>"><?= strtoupper($st_key==='qc'?'quality fail':$st_key) ?></span>
          <div class="url-box" style="margin-top:6px">
            <span style="flex:1"><?= "https://$host/pages/{$info[1]}?sid=".urlencode($sid)."&uid=[UID]" ?></span>
            <button onclick="copyText(this)" data-text="https://<?= $host ?>/pages/<?= $info[1] ?>?sid=<?= urlencode($sid) ?>&uid=[UID]">Copy</button>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-title">Project Notes</div>
    <form method="POST">
      <input type="hidden" name="save_project_note" value="1">
      <textarea name="pn_text" placeholder="Add internal notes, client instructions, important dates..."><?= htmlspecialchars($proj['notes'] ?? '') ?></textarea>
      <button type="submit" class="btn btn-blue" style="margin-top:10px">Save Note</button>
    </form>
  </div>

  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
      <div class="card-title" style="margin-bottom:0">Client Report Link (Read-Only)</div>
      <div style="display:flex;gap:8px">
        <?php if($share_link): ?>
        <button type="button" onclick="openEmailClientModal()" class="btn btn-ghost">📧 Email Client</button>
        <?php endif; ?>
        <form method="POST" onsubmit="return confirm('Naya link banane se purana link kaam karna band ho jayega. Continue?')">
          <input type="hidden" name="generate_share_link" value="1">
          <button type="submit" class="btn btn-blue">+ Generate New Link</button>
        </form>
      </div>
    </div>
    <?php if($share_link): ?>
    <div style="margin-bottom:10px">
      <span class="pill pill-overquota">GENERATED <?= date('d M Y', strtotime($share_link['created_at'].' UTC')) ?></span>
      <a href="?sid=<?= urlencode($sid) ?>&revoke_share_link=1" class="btn btn-red" style="padding:4px 12px;font-size:11px;margin-left:8px" onclick="return confirm('Revoke this link? Client will lose access.')">Revoke</a>
    </div>
    <div class="url-row">
      <div class="url-box"><span style="flex:1">https://<?= $host ?>/report.php?token=<?= $share_link['token'] ?></span><button onclick="copyText(this)" data-text="https://<?= $host ?>/report.php?token=<?= $share_link['token'] ?>">Copy</button></div>
    </div>
    <div style="font-size:11px;color:var(--muted);margin:10px 0 4px">API — Summary (stats as JSON):</div>
    <div class="url-row">
      <div class="url-box"><span style="flex:1">https://<?= $host ?>/api.php?token=<?= $share_link['token'] ?></span><button onclick="copyText(this)" data-text="https://<?= $host ?>/api.php?token=<?= $share_link['token'] ?>">Copy</button></div>
    </div>
    <div style="font-size:11px;color:var(--muted);margin:10px 0 4px">API — Leads list (paginated JSON):</div>
    <div class="url-row">
      <div class="url-box"><span style="flex:1">https://<?= $host ?>/api.php?token=<?= $share_link['token'] ?>&action=leads&page=1</span><button onclick="copyText(this)" data-text="https://<?= $host ?>/api.php?token=<?= $share_link['token'] ?>&action=leads&page=1">Copy</button></div>
    </div>
    <?php else: ?>
    <div style="color:var(--muted);font-size:13px">Client ko share karne ke liye ek read-only link generate karo — koi login nahi chahiye, sirf project progress dikhega.</div>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="card-title">Scheduled Client Reports</div>
    <div style="font-size:12px;color:var(--muted);margin-bottom:14px">Ye ON karne se is project ka progress report client ko automatically Daily ya Weekly email ho jayega. Jab chaho OFF kar do — turant band ho jayega, kabhi bhi.</div>
    <form method="POST">
      <input type="hidden" name="save_auto_report" value="1">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
          <input type="checkbox" name="ar_enabled" <?= !empty($proj['auto_report_enabled']) ? 'checked' : '' ?> style="width:18px;height:18px">
          <span style="font-weight:600;font-size:13px"><?= !empty($proj['auto_report_enabled']) ? '✅ ON — Auto-reports active' : '⏸ OFF — Not sending' ?></span>
        </label>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
        <div>
          <div style="font-size:10px;font-weight:600;color:var(--muted);letter-spacing:1px;text-transform:uppercase;margin-bottom:4px">Frequency</div>
          <select name="ar_freq" style="width:100%;background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:13px">
            <option value="daily" <?= ($proj['auto_report_freq']??'weekly')==='daily'?'selected':'' ?>>Daily</option>
            <option value="weekly" <?= ($proj['auto_report_freq']??'weekly')==='weekly'?'selected':'' ?>>Weekly</option>
          </select>
        </div>
        <div>
          <div style="font-size:10px;font-weight:600;color:var(--muted);letter-spacing:1px;text-transform:uppercase;margin-bottom:4px">Client Email</div>
          <input type="email" name="ar_email" value="<?= htmlspecialchars($proj['auto_report_email'] ?? '') ?>" placeholder="client@example.com" style="width:100%;background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:13px">
        </div>
      </div>
      <?php if (!empty($proj['auto_report_last_sent'])): ?>
      <div style="font-size:11px;color:var(--muted);margin-bottom:12px">Last sent: <?= date('d M Y, H:i', strtotime($proj['auto_report_last_sent'].' UTC')) ?> IST</div>
      <?php else: ?>
      <div style="font-size:11px;color:var(--muted);margin-bottom:12px">Abhi tak koi auto-report bheja nahi gaya.</div>
      <?php endif; ?>
      <button type="submit" class="btn btn-blue">Save Schedule</button>
    </form>
  </div>

  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:8px">
      <div class="card-title" style="margin-bottom:0">Assigned Vendors (<?= count($assigned_vendors) ?>)</div>
      <?php if (!empty($assigned_vendors)): ?>
      <a href="?sid=<?= urlencode($sid) ?>&download_links=1" class="btn btn-ghost" style="padding:6px 14px;font-size:12px">⬇ Download All Links (CSV)</a>
      <?php endif; ?>
      <form method="POST" style="display:flex;gap:6px">
        <input type="hidden" name="assign_vendor" value="1">
        <select name="av_vendor" required>
          <option value="">Select vendor</option>
          <?php foreach($all_vendors as $v): ?>
          <option value="<?= $v['id'] ?>"><?= htmlspecialchars($v['vendor_name']) ?></option>
          <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-blue" style="padding:7px 14px;font-size:12px">+ Assign Vendor</button>
      </form>
    </div>
    <table>
      <thead><tr><th>Vendor</th><th>Email</th><th>CPI</th><th>Limit</th><th>Status</th><th>Entry Link</th><th>Actions</th></tr></thead>
      <tbody>
      <?php if(empty($assigned_vendors)): ?>
      <tr><td colspan="7" style="text-align:center;color:var(--muted);padding:20px">No vendors assigned yet.</td></tr>
      <?php else: foreach($assigned_vendors as $v): ?>
      <tr>
        <td><strong><?= htmlspecialchars($v['vendor_name']) ?></strong></td>
        <td><?= htmlspecialchars($v['email'] ?: '—') ?></td>
        <td>₹<?= $v['pv_cpi'] !== null ? number_format($v['pv_cpi'],2) : '0.00' ?></td>
        <td><?= $v['pv_limit'] !== null ? intval($v['pv_limit']) : 'Unlimited' ?> / <?= $v['pv_click_quota'] !== null ? intval($v['pv_click_quota']) : 'Unlimited' ?> <span style="color:var(--muted);font-size:9px">(complete/click)</span></td>
        <td><span class="pill <?= ($v['status']??'active')==='active'?'pill-complete':'pill-terminate' ?>"><?= ucfirst($v['status'] ?? 'active') ?></span></td>
        <td>
          <button type="button" onclick='openEntryLinkModal("<?= htmlspecialchars(addslashes($v["vendor_name"])) ?>", "<?= htmlspecialchars($sid) ?>", "https://<?= $host ?>/vendor.php?sid=<?= urlencode($sid) ?>&vid=<?= $v["id"] ?>&uid=[UID]", "")' class="btn btn-blue" style="padding:4px 10px;font-size:10px">🔗 Entry Link</button>
          <button type="button" onclick='openEntryLinkModal("<?= htmlspecialchars(addslashes($v["vendor_name"])) ?>", "<?= htmlspecialchars($sid) ?>", "https://<?= $host ?>/exaverify.php?c=<?= urlencode($v["pv_short_code"] ?? "") ?>&pid=[UID]", " (Short Link)")' class="btn" style="padding:4px 10px;font-size:10px;background:rgba(168,85,247,.12);color:#a855f7;border:none">✂️ Short Link</button>
          <button type="button" onclick='openEntryLinkModal("<?= htmlspecialchars(addslashes($v["vendor_name"])) ?>", "<?= htmlspecialchars($sid) ?>", "https://<?= $host ?>/vendor.php?sid=<?= urlencode($sid) ?>&vid=<?= $v["id"] ?>&pre=1&uid=[UID]", " (Pre-screener)")' class="btn btn-green" style="padding:4px 10px;font-size:10px">📋 Entry Link (Pre-screener)</button>
          <button type="button" onclick='openVendorEditModal(<?= json_encode(["id"=>$v["id"], "name"=>$v["vendor_name"], "cpi"=>$v["pv_cpi"], "limit"=>$v["pv_limit"], "click_quota"=>$v["pv_click_quota"], "show_prescreener"=>$v["pv_show_prescreener"]]) ?>)' class="btn btn-ghost" style="padding:4px 10px;font-size:10px">✏ Edit</button>
          <a href="?sid=<?= urlencode($sid) ?>&toggle_project_vendor=<?= $v['id'] ?>" class="btn <?= ($v['pv_status']??'active')==='active'?'btn-amber':'btn-green' ?>" style="padding:4px 10px;font-size:10px;text-decoration:none"><?= ($v['pv_status']??'active')==='active'?'⏸ Pause':'▶ Resume' ?></a>
        </td>
        <td><a href="?sid=<?= urlencode($sid) ?>&unassign_vendor=<?= $v['id'] ?>" class="btn btn-red" style="padding:4px 10px;font-size:11px" onclick="return confirm('Unassign this vendor?')">Remove</a></td>
      </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <div class="card">
    <div class="card-title">🌍 Multi-Country Link (optional)</div>
    <div style="font-size:12px;color:#64748b;margin-bottom:14px">Agar is project ka same SID kayi countries mein chalna hai, lekin har country ka survey-URL alag hai — yahan per-country override daal do. Respondent ka IP-detected country match hote hi wahi URL use hoga; koi match na mile toh Project ka default Live URL hi chalega, jaisa pehle.</div>

    <form method="POST" style="display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap">
      <input type="hidden" name="add_country_link" value="1">
      <input type="text" name="cl_country" required placeholder="Country — e.g. United States" style="background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:12px;min-width:180px">
      <input type="text" name="cl_url" required placeholder="Live URL for this country — [UID] supported" style="flex:1;min-width:280px;background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:12px">
      <button type="submit" class="btn btn-blue" style="padding:9px 18px;font-size:12px">+ Add / Update</button>
    </form>

    <table>
      <thead><tr><th>Country</th><th>Live URL</th><th>Action</th></tr></thead>
      <tbody>
      <?php if(empty($country_links)): ?>
      <tr><td colspan="3" style="text-align:center;padding:16px;color:#94a3b8">Koi country-specific URL nahi hai — default Live URL sab countries ke liye use hoga.</td></tr>
      <?php else: foreach($country_links as $cl): ?>
      <tr>
        <td style="font-size:12px;font-weight:600"><?= htmlspecialchars($cl['country']) ?></td>
        <td style="font-size:11px;font-family:monospace;word-break:break-all"><?= htmlspecialchars($cl['live_url']) ?></td>
        <td><a href="?sid=<?= urlencode($sid) ?>&delete_country_link=<?= $cl['id'] ?>#countrylinks" class="btn btn-red" style="padding:4px 10px;font-size:11px" onclick="return confirm('Remove country-link for <?= htmlspecialchars(addslashes($cl['country'])) ?>?')">Remove</a></td>
      </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <div class="card">
    <div class="card-title">🕒 Activity (PM Logs)</div>
    <div style="font-size:12px;color:#64748b;margin-bottom:14px">Is project pe kya kaam hua, kitna time laga — track karo.</div>

    <?php if (!empty($activity_summary)): ?>
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px">
      <?php foreach ($activity_summary as $asum):
        $h = intdiv($asum['total_minutes'], 60); $m = $asum['total_minutes'] % 60;
      ?>
      <div style="background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:10px 16px;min-width:150px">
        <div style="font-size:12px;font-weight:700;color:var(--navy)"><?= htmlspecialchars($asum['user_name'] ?: 'Unknown') ?></div>
        <div style="font-size:16px;font-weight:700;color:var(--blue)"><?= $h ?>h <?= $m ?>m</div>
        <div style="font-size:10px;color:#94a3b8"><?= $asum['total_activities'] ?> activities · is project pe</div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <form method="POST" style="display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap;align-items:flex-end">
      <input type="hidden" name="add_activity_log" value="1">
      <div>
        <div style="font-size:10px;font-weight:600;color:#64748b;text-transform:uppercase;margin-bottom:4px">Activity</div>
        <input type="text" name="al_activity" required placeholder="e.g. Client Call" style="background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:12px;min-width:160px">
      </div>
      <div>
        <div style="font-size:10px;font-weight:600;color:#64748b;text-transform:uppercase;margin-bottom:4px">Sub-Activity</div>
        <input type="text" name="al_sub_activity" placeholder="e.g. Scope discussion" style="background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:12px;min-width:160px">
      </div>
      <div>
        <div style="font-size:10px;font-weight:600;color:#64748b;text-transform:uppercase;margin-bottom:4px">Duration (min)</div>
        <input type="number" name="al_duration" placeholder="30" style="background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:12px;width:100px">
      </div>
      <div style="flex:1;min-width:180px">
        <div style="font-size:10px;font-weight:600;color:#64748b;text-transform:uppercase;margin-bottom:4px">Notes (optional)</div>
        <input type="text" name="al_notes" placeholder="Any extra detail..." style="width:100%;background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:12px">
      </div>
      <button type="submit" class="btn btn-blue" style="padding:9px 18px;font-size:12px">+ Log Activity</button>
    </form>

    <table>
      <thead><tr><th>Date</th><th>User</th><th>Activity</th><th>Sub-Activity</th><th>Duration</th><th>Notes</th><th>Action</th></tr></thead>
      <tbody>
      <?php if(empty($activity_logs)): ?>
      <tr><td colspan="7" style="text-align:center;padding:16px;color:#94a3b8">Koi activity log nahi hai abhi.</td></tr>
      <?php else: foreach($activity_logs as $al): ?>
      <tr>
        <td style="font-size:11px"><?= date('d M Y, H:i', strtotime($al['logged_at'])) ?></td>
        <td style="font-size:12px"><?= htmlspecialchars($al['user_name'] ?: '—') ?></td>
        <td style="font-size:12px;font-weight:600"><?= htmlspecialchars($al['activity']) ?></td>
        <td style="font-size:12px"><?= htmlspecialchars($al['sub_activity'] ?: '—') ?></td>
        <td style="font-size:12px"><?= $al['duration_minutes'] ?> min</td>
        <td style="font-size:12px"><?= htmlspecialchars($al['notes'] ?: '—') ?></td>
        <td><a href="?sid=<?= urlencode($sid) ?>&delete_activity_log=<?= $al['id'] ?>#activitylog" class="btn btn-red" style="padding:4px 10px;font-size:11px" onclick="return confirm('Delete this log entry?')">Del</a></td>
      </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <div class="card" style="margin-bottom:18px">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
      <div class="card-title" style="margin-bottom:0">Vendor Breakdown</div>
      <div style="display:flex;gap:8px">
        <a href="index.php?fPr=<?= urlencode($sid) ?>#tab-responses" class="btn btn-ghost" style="padding:6px 14px;font-size:12px">🔍 Search All Leads For This Project</a>
        <a href="?sid=<?= urlencode($sid) ?>&download_entries=1" class="btn btn-ghost" style="padding:6px 14px;font-size:12px">⬇ Export to Excel</a>
      </div>
    </div>
    <div style="font-size:11px;color:#94a3b8;margin:8px 0 12px">Is-project-pe-kaam-kar-rahe-har-vendor-ka-performance — bina-Vendors-list-khole.</div>
    <table>
      <thead><tr><th>Vendor</th><th>Clicks</th><th>Completes</th><th>Terminates</th><th>Quality-Fail</th><th>OverQuota</th><th>Conv%</th></tr></thead>
      <tbody>
      <?php if (empty($vendor_breakdown)): ?>
      <tr><td colspan="7" style="text-align:center;color:var(--muted);padding:20px">Abhi-tak-koi-entry-nahi-hui.</td></tr>
      <?php else: foreach ($vendor_breakdown as $vb_row):
          $conv = $vb_row['clicks'] > 0 ? round(($vb_row['completes'] / $vb_row['clicks']) * 100, 1) : 0;
      ?>
      <tr>
        <td>
          <?php if ($vb_row['vendor_id']): ?>
          <a href="vendor_view.php?vid=<?= $vb_row['vendor_id'] ?>" style="color:var(--blue2);font-weight:600;text-decoration:none"><?= htmlspecialchars($vb_row['vendor_name']) ?></a>
          <?php else: ?>
          <span style="color:var(--muted)"><?= htmlspecialchars($vb_row['vendor_name']) ?></span>
          <?php endif; ?>
        </td>
        <td><?= number_format($vb_row['clicks']) ?></td>
        <td style="color:#16a34a;font-weight:600"><?= number_format($vb_row['completes']) ?></td>
        <td style="color:#dc2626"><?= number_format($vb_row['terminates']) ?></td>
        <td style="color:#f59e0b"><?= number_format($vb_row['quality_fail']) ?></td>
        <td><?= number_format($vb_row['overquota']) ?></td>
        <td><?= $conv ?>%</td>
      </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <div class="card" id="leads-section">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:10px">
      <div class="card-title" style="margin-bottom:0">Recent Leads <span style="font-size:11px;color:#94a3b8;font-weight:400">(<?= number_format($leads_total) ?> total)</span></div>
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
        <form method="GET" style="display:flex;align-items:center;gap:6px">
          <input type="hidden" name="sid" value="<?= htmlspecialchars($sid) ?>">
          <span style="font-size:11px;color:#64748b">Show:</span>
          <select name="leads_per_page" onchange="this.form.submit()" style="font-size:11px;padding:4px 8px;border:1px solid #e2e8f0;border-radius:6px;background:#f8faff">
            <?php foreach ([10,25,50,100] as $opt): ?>
            <option value="<?= $opt ?>" <?= $leads_per_page==$opt?'selected':'' ?>><?= $opt ?></option>
            <?php endforeach; ?>
          </select>
          <span style="font-size:11px;color:#64748b">per page</span>
        </form>
        <a href="?sid=<?= urlencode($sid) ?>&delete_all_leads=1" class="btn btn-red" onclick="return confirm('Delete ALL leads for this project? This cannot be undone.')">🗑 Delete All Leads</a>
      </div>
    </div>
    <table>
      <thead><tr><th>UID</th><th>Status</th><th>Postback</th><th>Country</th><th>Device</th><th>LOI</th><th>IP</th><th>Date</th><th>View</th></tr></thead>
      <tbody>
      <?php if(empty($recent_leads)): ?>
      <tr><td colspan="9" style="text-align:center;color:var(--muted);padding:20px">No leads yet.</td></tr>
      <?php else: foreach($recent_leads as $r): ?>
      <tr>
        <td style="font-family:monospace">
          <?php if (!empty($r['original_uid']) && $r['original_uid'] !== $r['respondent']): ?>
          <div><?= htmlspecialchars($r['original_uid']) ?></div>
          <div style="font-size:9px;color:#94a3b8">🔒 <?= htmlspecialchars($r['respondent']) ?></div>
          <?php else: ?>
          <?= htmlspecialchars($r['respondent']) ?>
          <?php endif; ?>
        </td>
        <td><span class="pill <?= $r['status']==='complete'?'pill-complete':($r['status']==='terminate'?'pill-terminate':'pill-overquota') ?>"><?= ucfirst($r['status']) ?></span></td>
        <td>
          <?php
            $pbs = $r['postback_status'] ?? 'pending';
            $pbLabel = ['sent'=>'✓ Sent','failed'=>'✕ Failed','not_applicable'=>'— N/A','pending'=>'⏳ Pending'][$pbs] ?? $pbs;
            $pbColor = ['sent'=>'#16a34a','failed'=>'#dc2626','not_applicable'=>'#94a3b8','pending'=>'#f59e0b'][$pbs] ?? '#94a3b8';
          ?>
          <span style="font-size:11px;color:<?= $pbColor ?>;font-weight:600"><?= $pbLabel ?></span>
        </td>
        <td><?= htmlspecialchars($r['country'] ?: '—') ?></td>
        <td><?= htmlspecialchars($r['device'] ?: '—') ?></td>
        <td><?= fmt_loi_pv($r['loi_seconds']) ?></td>
        <td style="font-family:monospace;color:var(--muted)"><?= htmlspecialchars($r['ip'] ?: '—') ?></td>
        <td style="color:var(--muted)"><?= date('d M H:i', strtotime($r['created_at'].' UTC')) ?></td>
        <td><a href="respondent_view.php?uid=<?= urlencode($r['respondent']) ?>&sid=<?= urlencode($sid) ?>" class="btn btn-blue" style="padding:4px 12px;font-size:11px">View</a></td>
      </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
    <?php if ($leads_total_pages > 1): ?>
    <div style="display:flex;align-items:center;justify-content:center;gap:10px;margin-top:16px;padding-top:14px;border-top:1px solid #e2e8f0">
      <?php if ($leads_page > 1): ?>
      <a href="?sid=<?= urlencode($sid) ?>&leads_page=<?= $leads_page-1 ?>&leads_per_page=<?= $leads_per_page ?>#leads-section" class="btn btn-ghost" style="padding:6px 14px;font-size:12px">← Previous</a>
      <?php endif; ?>
      <span style="font-size:12px;color:#64748b">Page <?= $leads_page ?> of <?= $leads_total_pages ?> — showing <?= $leads_offset+1 ?>–<?= min($leads_offset+$leads_per_page, $leads_total) ?> of <?= number_format($leads_total) ?></span>
      <?php if ($leads_page < $leads_total_pages): ?>
      <a href="?sid=<?= urlencode($sid) ?>&leads_page=<?= $leads_page+1 ?>&leads_per_page=<?= $leads_per_page ?>#leads-section" class="btn btn-ghost" style="padding:6px 14px;font-size:12px">Next →</a>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>

  <div class="card" id="entries-section" style="margin-top:18px">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:10px">
      <div class="card-title" style="margin-bottom:0">Entry / Click Log <span style="font-size:11px;color:#94a3b8;font-weight:400">(<?= number_format($entries_total) ?> total clicks)</span></div>
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
      <?php if ($entries_total > 0): ?>
      <a href="?sid=<?= urlencode($sid) ?>&download_entries=1" class="btn btn-ghost" style="padding:6px 14px;font-size:12px">⬇ Download CSV</a>
      <?php endif; ?>
      <form method="GET" style="display:flex;align-items:center;gap:6px">
        <input type="hidden" name="sid" value="<?= htmlspecialchars($sid) ?>">
        <span style="font-size:11px;color:#64748b">Show:</span>
        <select name="entries_per_page" onchange="this.form.submit()" style="font-size:11px;padding:4px 8px;border:1px solid #e2e8f0;border-radius:6px;background:#f8faff">
          <?php foreach ([10,25,50,100] as $opt): ?>
          <option value="<?= $opt ?>" <?= $entries_per_page==$opt?'selected':'' ?>><?= $opt ?></option>
          <?php endforeach; ?>
        </select>
        <span style="font-size:11px;color:#64748b">per page</span>
      </form>
      </div>
    </div>
    <div style="font-size:11px;color:#94a3b8;margin-bottom:12px">Har entry-link-click yaha dikhता hai — jinke saamne "⏳ Pending" hai, unka koi complete/terminate-signal abhi tak wapas nahi aaya (agar bahut purane hon, ho sakता hai vendor ka postback missing ho).</div>
    <table>
      <thead><tr><th>UID</th><th>Vendor</th><th>IP</th><th>Time</th><th>Completion Status</th></tr></thead>
      <tbody>
      <?php if(empty($entry_log)): ?>
      <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:20px">No entries yet.</td></tr>
      <?php else: foreach($entry_log as $e): ?>
      <tr>
        <td style="font-family:monospace;font-size:11px"><?= htmlspecialchars($e['uid']) ?></td>
        <td><?= htmlspecialchars($e['vendor_name'] ?: '—') ?></td>
        <td style="font-family:monospace;color:var(--muted)"><?= htmlspecialchars($e['ip'] ?: '—') ?></td>
        <td style="color:var(--muted)"><?= date('d M H:i', strtotime($e['start_time'].' UTC')) ?></td>
        <td>
          <?php if ($e['completion_status']): ?>
          <span class="pill <?= $e['completion_status']==='complete'?'pill-complete':($e['completion_status']==='terminate'?'pill-terminate':'pill-overquota') ?>"><?= ucfirst($e['completion_status']) ?></span>
          <?php else: ?>
          <span style="font-size:11px;color:#f59e0b;font-weight:600">⏳ Pending</span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
    <?php if ($entries_total_pages > 1): ?>
    <div style="display:flex;align-items:center;justify-content:center;gap:10px;margin-top:16px;padding-top:14px;border-top:1px solid #e2e8f0">
      <?php if ($entries_page > 1): ?>
      <a href="?sid=<?= urlencode($sid) ?>&entries_page=<?= $entries_page-1 ?>&entries_per_page=<?= $entries_per_page ?>#entries-section" class="btn btn-ghost" style="padding:6px 14px;font-size:12px">← Previous</a>
      <?php endif; ?>
      <span style="font-size:12px;color:#64748b">Page <?= $entries_page ?> of <?= $entries_total_pages ?> — showing <?= $entries_offset+1 ?>–<?= min($entries_offset+$entries_per_page, $entries_total) ?> of <?= number_format($entries_total) ?></span>
      <?php if ($entries_page < $entries_total_pages): ?>
      <a href="?sid=<?= urlencode($sid) ?>&entries_page=<?= $entries_page+1 ?>&entries_per_page=<?= $entries_per_page ?>#entries-section" class="btn btn-ghost" style="padding:6px 14px;font-size:12px">Next →</a>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>

</div>

<!-- EDIT PROJECT MODAL -->
<div class="modal-overlay" id="editProjectModal">
  <div class="modal">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
      <div style="font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:1px">Edit Project</div>
      <span onclick="document.getElementById('editProjectModal').classList.remove('open')" style="cursor:pointer;font-size:18px;color:#94a3b8">✕</span>
    </div>
    <form method="POST">
      <input type="hidden" name="save_project_edit" value="1">
      <div class="modal-field"><div class="lbl">Project Name</div><input type="text" name="pe_name" value="<?= htmlspecialchars($proj['project_name'] ?? '') ?>"></div>
      <div class="modal-field"><div class="lbl">Client</div>
        <select name="pe_client">
          <option value="">— Select client —</option>
          <?php foreach($master_clients as $mc): ?>
          <option value="<?= $mc['id'] ?>" <?= ($proj['client_id']??null)==$mc['id']?'selected':'' ?>><?= htmlspecialchars($mc['client_name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div class="modal-field"><div class="lbl">CPI</div><input type="number" step="0.01" name="pe_cpi" value="<?= $proj['cpi'] ?? 0 ?>"></div>
        <div class="modal-field"><div class="lbl">Vendor Cost</div><input type="number" step="0.01" name="pe_vcost" value="<?= $proj['vendor_cost'] ?? 0 ?>"></div>
      </div>
      <div class="modal-field"><div class="lbl">Project Type</div>
        <select name="pe_type">
          <option value="direct" <?= ($proj['project_type']??'direct')==='direct'?'selected':'' ?>>Direct</option>
          <option value="thirdparty" <?= ($proj['project_type']??'')==='thirdparty'?'selected':'' ?>>Third Party</option>
        </select>
      </div>
      <div class="modal-field"><div class="lbl">Target Completes</div><input type="number" name="pe_target" value="<?= $proj['target'] ?? 0 ?>"></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div class="modal-field"><div class="lbl">Start Date</div><input type="date" name="pe_start_date" value="<?= htmlspecialchars($proj['start_date'] ?? '') ?>"></div>
        <div class="modal-field"><div class="lbl">End Date</div><input type="date" name="pe_end_date" value="<?= htmlspecialchars($proj['end_date'] ?? '') ?>"></div>
      </div>
      <div class="modal-field"><div class="lbl">Project Manager</div><input type="text" name="pe_manager" value="<?= htmlspecialchars($proj['project_manager'] ?? '') ?>" placeholder="e.g. Rahul Sharma"></div>
      <div class="modal-field"><div class="lbl">Live Survey URL</div><input type="text" name="pe_liveurl" value="<?= htmlspecialchars($proj['live_url'] ?? '') ?>"></div>
      <div class="modal-field"><div class="lbl">Test Survey URL</div><input type="text" name="pe_testurl" value="<?= htmlspecialchars($proj['test_url'] ?? '') ?>"></div>
      <div class="modal-field"><div class="lbl">Description / Study Parameters</div><textarea name="pe_description"><?= htmlspecialchars($proj['description'] ?? '') ?></textarea></div>
      <div class="modal-field" style="display:flex;align-items:center;gap:8px">
        <input type="checkbox" name="pe_encrypt" id="pe_encrypt" <?= !empty($proj['encrypt_uid'])?'checked':'' ?>>
        <label for="pe_encrypt" style="font-size:12px;color:#475569">Encrypt UID</label>
      </div>
      <div style="display:flex;gap:8px;margin-top:16px">
        <button type="submit" class="btn btn-blue">Save Changes</button>
        <button type="button" onclick="document.getElementById('editProjectModal').classList.remove('open')" class="btn btn-ghost">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- CLONE PROJECT MODAL -->
<div class="modal-overlay" id="cloneProjectModal">
  <div class="modal">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
      <div style="font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:1px">Clone Project</div>
      <span onclick="document.getElementById('cloneProjectModal').classList.remove('open')" style="cursor:pointer;font-size:18px;color:#94a3b8">✕</span>
    </div>
    <div style="font-size:12px;color:#64748b;margin-bottom:14px">Client, CPI, target, encryption, description, aur PreScreen-Template — sab copy ho jayenge naye project mein. Live/Test URL jaan-bujh kar khaali rahenge (alag market = alag survey-link, isliye fresh daalna hoga).</div>
    <form method="POST">
      <input type="hidden" name="clone_project" value="1">
      <div class="modal-field"><div class="lbl">New SID (Project Code)</div><input type="text" name="clone_new_sid" required placeholder="e.g. <?= htmlspecialchars($sid) ?>_UK"></div>
      <div class="modal-field"><div class="lbl">New Project Name (optional)</div><input type="text" name="clone_new_name" placeholder="Leave blank for '<?= htmlspecialchars($proj['project_name'] ?: $sid) ?> (Clone)'"></div>
      <div style="display:flex;gap:8px;margin-top:16px">
        <button type="submit" class="btn btn-blue">⧉ Clone Project</button>
        <button type="button" onclick="document.getElementById('cloneProjectModal').classList.remove('open')" class="btn btn-ghost">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- ENTRY LINK MODAL (view-only, copy-friendly — matches Azilytics pattern) -->
<div class="modal-overlay" id="entryLinkModal">
  <div class="modal" style="max-width:520px">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
      <div style="font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:1px">Entry Link</div>
      <span onclick="document.getElementById('entryLinkModal').classList.remove('open')" style="cursor:pointer;font-size:18px;color:#94a3b8">✕</span>
    </div>
    <div style="font-size:13px;color:#475569;margin-bottom:2px" id="elVendorName"></div>
    <div style="font-size:12px;color:#94a3b8;margin-bottom:14px" id="elProjectName"></div>
    <div class="url-box" style="margin-bottom:16px"><span style="flex:1" id="elUrlText"></span></div>
    <button type="button" onclick="copyEntryLink()" class="btn btn-blue" style="width:100%;justify-content:center">Copy Link</button>
  </div>
</div>

<!-- EMAIL CLIENT MODAL -->
<div class="modal-overlay" id="emailClientModal">
  <div class="modal" style="max-width:560px">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
      <div style="font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:1px">📧 Email Client</div>
      <span onclick="document.getElementById('emailClientModal').classList.remove('open')" style="cursor:pointer;font-size:18px;color:#94a3b8">✕</span>
    </div>
    <div style="font-size:11px;font-weight:600;color:#64748b;letter-spacing:1px;text-transform:uppercase;margin-bottom:4px">Subject</div>
    <div class="url-box" style="margin-bottom:14px"><span style="flex:1" id="ecSubject"></span></div>
    <div style="font-size:11px;font-weight:600;color:#64748b;letter-spacing:1px;text-transform:uppercase;margin-bottom:4px">Body</div>
    <textarea id="ecBody" readonly style="width:100%;min-height:220px;background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:12px;font-family:'DM Sans',sans-serif;font-size:13px;line-height:1.7;color:#334155;resize:vertical"></textarea>
    <div style="display:flex;gap:8px;margin-top:14px">
      <button type="button" onclick="copyEmailBody()" class="btn btn-blue">📋 Copy Email Text</button>
      <a href="report.php?token=<?= $share_link['token'] ?? '' ?>&print=1" target="_blank" class="btn btn-green" style="text-decoration:none">🖨 Open PDF Report</a>
    </div>
    <div style="font-size:11px;color:#94a3b8;margin-top:10px">Copy karke apne Gmail/Outlook mein paste kar do, ya PDF button se print/save-as-PDF kar sakte ho (browser ka print dialog khulega).</div>
  </div>
</div>

<!-- EDIT VENDOR ASSIGNMENT MODAL -->
<div class="modal-overlay" id="editVendorModal">
  <div class="modal" style="max-width:400px">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
      <div style="font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:1px" id="evTitle">Edit Vendor</div>
      <span onclick="document.getElementById('editVendorModal').classList.remove('open')" style="cursor:pointer;font-size:18px;color:#94a3b8">✕</span>
    </div>
    <form method="POST">
      <input type="hidden" name="save_project_vendor_edit" value="1">
      <input type="hidden" name="pv_vendor_id" id="ev_vendor_id">
      <div class="modal-field"><div class="lbl">CPI ($)</div><input type="number" step="0.01" name="pv_cpi" id="ev_cpi"></div>
      <div class="modal-field"><div class="lbl">Max Limit (completes)</div><input type="number" name="pv_limit" id="ev_limit" placeholder="Leave blank for unlimited"></div>
      <div class="modal-field"><div class="lbl">Click Quota (total clicks)</div><input type="number" name="pv_click_quota" id="ev_click_quota" placeholder="Leave blank for unlimited"></div>
      <div class="modal-field" style="display:flex;align-items:center;gap:8px">
        <input type="checkbox" name="pv_show_prescreener" id="ev_show_prescreener" style="width:auto">
        <label for="ev_show_prescreener" style="margin:0;font-size:12px">Always route this vendor's traffic through Pre-screener (even via the plain Entry Link)</label>
      </div>
      <div style="display:flex;gap:8px;margin-top:16px">
        <button type="submit" class="btn btn-blue">Save</button>
        <button type="button" onclick="document.getElementById('editVendorModal').classList.remove('open')" class="btn btn-ghost">Cancel</button>
      </div>
    </form>
  </div>
</div>

</div><!-- /app-content -->
</div><!-- /app-layout -->

<script>
function toggleSidebar(){
  const sb = document.getElementById('appSidebar');
  const ac = document.getElementById('appContent');
  sb.classList.toggle('collapsed');
  ac.classList.toggle('sidebar-collapsed');
  localStorage.setItem('exz_sidebar_collapsed', sb.classList.contains('collapsed') ? '1' : '0');
}
(function(){
  if (localStorage.getItem('exz_sidebar_collapsed') === '1') {
    document.getElementById('appSidebar').classList.add('collapsed');
    document.getElementById('appContent').classList.add('sidebar-collapsed');
  }
})();
const PROJ_NAME = <?= json_encode($proj['project_name'] ?: $sid) ?>;
const CLIENT_NAME = <?= json_encode($proj['cname'] ?: 'there') ?>;
const COMPLETES_N = <?= (int)$completes ?>;
const TARGET_N = <?= (int)($proj['target'] ?? 0) ?>;
const REPORT_URL = <?= json_encode($share_link ? "https://$host/report.php?token=".$share_link['token'] : '') ?>;

function openEmailClientModal(){
  const pct = TARGET_N > 0 ? Math.round(COMPLETES_N/TARGET_N*100) : null;
  const progressLine = TARGET_N > 0 ? `Progress: ${COMPLETES_N} / ${TARGET_N} completes (${pct}%)` : `Completes so far: ${COMPLETES_N}`;
  document.getElementById('ecSubject').textContent = `Project Update — ${PROJ_NAME}`;
  document.getElementById('ecBody').value =
`Hi ${CLIENT_NAME},

Sharing a quick update on ${PROJ_NAME}.

${progressLine}

You can view live progress anytime here (no login required):
${REPORT_URL}

Please let us know if you have any questions.

Best regards,
Exazon Research`;
  document.getElementById('emailClientModal').classList.add('open');
}
function copyEmailBody(){
  navigator.clipboard.writeText(document.getElementById('ecBody').value).then(()=>{
    event.target.textContent = '✓ Copied!';
    setTimeout(()=>{ event.target.textContent = '📋 Copy Email Text'; }, 1500);
  });
}
function openEntryLinkModal(vendorName, projectId, url, suffix){
  document.getElementById('elVendorName').textContent = vendorName + suffix;
  document.getElementById('elProjectName').textContent = 'Project: ' + projectId;
  document.getElementById('elUrlText').textContent = url;
  document.getElementById('entryLinkModal').classList.add('open');
}
function copyEntryLink(){
  const text = document.getElementById('elUrlText').textContent;
  navigator.clipboard.writeText(text).then(()=>{
    const btn = event.target;
    const old = btn.textContent; btn.textContent = 'Copied!';
    setTimeout(()=>btn.textContent=old, 1500);
  });
}
function openVendorEditModal(v){
  document.getElementById('evTitle').textContent = 'Edit: ' + v.name;
  document.getElementById('ev_vendor_id').value = v.id;
  document.getElementById('ev_cpi').value = v.cpi !== null ? v.cpi : '';
  document.getElementById('ev_limit').value = v.limit !== null ? v.limit : '';
  document.getElementById('ev_click_quota').value = v.click_quota !== null ? v.click_quota : '';
  document.getElementById('ev_show_prescreener').checked = !!(v.show_prescreener && v.show_prescreener != 0);
  document.getElementById('editVendorModal').classList.add('open');
}
function showUrlType(type){
  document.getElementById('urltype-dynamic').style.display = (type === 'dynamic') ? '' : 'none';
  document.getElementById('urltype-static').style.display = (type === 'static') ? '' : 'none';
}
function copyText(btn){
  navigator.clipboard.writeText(btn.getAttribute('data-text')).then(()=>{
    const old = btn.textContent; btn.textContent = 'Copied!';
    setTimeout(()=>btn.textContent=old, 1500);
  });
}
</script>
</body>
</html>
