<?php
// ============================================================
// Exazon Research — Reconciliation Report
// File: hub/reconcile.php
// ============================================================
session_start();
define('DB_HOST','localhost');
define('DB_NAME','u994909610_Exaverify');
define('DB_USER','u994909610_Exaverify');
define('DB_PASS','Exaverify@8181');

// ── AUTH — shares the main dashboard's session (PIN + Team Login) ──
// No separate login screen here; access flows from index.php.
if (isset($_GET['logout'])) { session_destroy(); header('Location: index.php'); exit; }
if (empty($_SESSION['ex_auth']) || empty($_SESSION['ex_team_id'])) {
    header('Location: index.php'); exit;
}

// ---- DB ----
function getDB(){
    static $pdo;
    if($pdo) return $pdo;
    $pdo = new PDO(
        "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]
    );
    return $pdo;
}
$pdo = getDB();

// ---- Create Table ----
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS reconcile_records (
        id INT AUTO_INCREMENT PRIMARY KEY,
        project_id VARCHAR(50) NOT NULL,
        client_name VARCHAR(100),
        period VARCHAR(30),
        we_sent INT DEFAULT 0,
        client_accepted INT DEFAULT 0,
        client_rejected INT DEFAULT 0,
        reject_reason TEXT,
        our_completes INT DEFAULT 0,
        difference INT DEFAULT 0,
        cpi DECIMAL(10,2) DEFAULT 0,
        currency VARCHAR(10) DEFAULT 'INR',
        dispute_amount DECIMAL(12,2) DEFAULT 0,
        status VARCHAR(20) DEFAULT 'open',
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch(Exception $e){ $dbErr = $e->getMessage(); }

// ---- Save Record ----
$saveErr = '';
if(isset($_POST['save_rec'])){
    $sent     = intval($_POST['we_sent'] ?? 0);
    $accepted = intval($_POST['client_accepted'] ?? 0);
    $rejected = intval($_POST['client_rejected'] ?? 0);
    $our_comp = intval($_POST['our_completes'] ?? 0);
    $diff     = $our_comp - $accepted;
    $cpi      = floatval($_POST['cpi'] ?? 0);
    $disp_amt = max(0, $diff * $cpi);
    try {
        $pdo->prepare("INSERT INTO reconcile_records
            (project_id, client_name, period, we_sent, client_accepted, client_rejected,
             reject_reason, our_completes, difference, cpi, currency, dispute_amount, status, notes)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
            ->execute([
                trim($_POST['project_id'] ?? ''),
                trim($_POST['client_name'] ?? ''),
                trim($_POST['period'] ?? date('M Y')),
                $sent, $accepted, $rejected,
                trim($_POST['reject_reason'] ?? ''),
                $our_comp, $diff, $cpi,
                $_POST['currency'] ?? 'INR',
                $disp_amt,
                $_POST['status'] ?? 'open',
                trim($_POST['notes'] ?? '')
            ]);
        header('Location: reconcile.php?saved=1');
        exit;
    } catch(Exception $e){ $saveErr = $e->getMessage(); }
}

// ---- CSV Parse ----
$csv_parsed = [];
if(isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] === 0){
    $lines = file($_FILES['csv_file']['tmp_name'], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    array_shift($lines); // skip header
    foreach($lines as $l){
        $r = str_getcsv($l);
        if(count($r) >= 2){
            $csv_parsed[] = [
                'uid'    => $r[0] ?? '',
                'status' => $r[1] ?? '',
                'reason' => $r[2] ?? ''
            ];
        }
    }
}

// ---- AUTO COMPARE: Matched / Mismatched / Missing ----
// Cross-references each parsed CSV row against our own survey_responses,
// so a client/vendor completes-list can be reconciled automatically
// instead of a fully manual dispute entry.
$compare_results = [];
$compare_summary = ['matched'=>0, 'mismatched'=>0, 'missing'=>0];
if (!empty($csv_parsed)) {
    $rec_sid_filter = trim($_POST['rec_sid'] ?? $_GET['rec_sid'] ?? '');
    foreach ($csv_parsed as $row) {
        $their_status = strtolower(trim($row['status']));
        try {
            $params = [$row['uid']];
            $where_sid = '';
            if ($rec_sid_filter !== '') { $where_sid = ' AND survey_id=?'; $params[] = $rec_sid_filter; }
            $q = $pdo->prepare("SELECT status, survey_id FROM survey_responses WHERE respondent=? $where_sid ORDER BY created_at DESC LIMIT 1");
            $q->execute($params);
            $our = $q->fetch();
        } catch (Exception $e) { $our = null; }

        if (!$our) {
            $compare_results[] = ['uid'=>$row['uid'], 'their_status'=>$row['status'], 'our_status'=>null, 'sid'=>null, 'verdict'=>'missing'];
            $compare_summary['missing']++;
        } else {
            $our_status = strtolower($our['status']);
            $our_norm = ($our_status === 'quality') ? 'qc' : $our_status;
            $their_norm = str_replace(['complete','completed'], ['complete','complete'], $their_status);
            if ($our_norm === $their_norm || (str_contains($their_norm,'complet') && $our_norm==='complete') || (str_contains($their_norm,'term') && $our_norm==='terminate')) {
                $compare_results[] = ['uid'=>$row['uid'], 'their_status'=>$row['status'], 'our_status'=>$our['status'], 'sid'=>$our['survey_id'], 'verdict'=>'matched'];
                $compare_summary['matched']++;
            } else {
                $compare_results[] = ['uid'=>$row['uid'], 'their_status'=>$row['status'], 'our_status'=>$our['status'], 'sid'=>$our['survey_id'], 'verdict'=>'mismatched'];
                $compare_summary['mismatched']++;
            }
        }
    }
}

// ---- Update Status ----
if(isset($_GET['close'])){
    try {
        $pdo->prepare("UPDATE reconcile_records SET status='closed' WHERE id=?")
            ->execute([intval($_GET['close'])]);
    } catch(Exception $e){}
    header('Location: reconcile.php');
    exit;
}

// ---- Delete Record ----
if(isset($_GET['delete'])){
    try {
        $pdo->prepare("DELETE FROM reconcile_records WHERE id=?")
            ->execute([intval($_GET['delete'])]);
    } catch(Exception $e){}
    header('Location: reconcile.php');
    exit;
}

// ---- Load Projects ----
$projects = [];
try {
    $projects = $pdo->query("SELECT survey_id,
        MAX(client_name) as client_name,
        SUM(status='complete') as completes
        FROM survey_responses
        GROUP BY survey_id
        ORDER BY MAX(created_at) DESC")->fetchAll();
} catch(Exception $e){}

// ---- Load Records ----
$records = [];
try {
    $records = $pdo->query("SELECT * FROM reconcile_records ORDER BY created_at DESC")->fetchAll();
} catch(Exception $e){}

// ---- Summary Stats ----
$total_diff   = array_sum(array_column($records, 'difference'));
$total_disp   = array_sum(array_column($records, 'dispute_amount'));
$open_count   = count(array_filter($records, fn($r) => $r['status'] === 'open'));
$closed_count = count(array_filter($records, fn($r) => $r['status'] === 'closed'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Reconciliation — Exazon Research</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
    --navy:#0a1628;--navy2:#112040;
    --blue:#1b4fd8;--blue2:#3b82f6;
    --gold:#c8a84b;--gold2:#a07828;
    --green:#22c55e;--green2:#16a34a;
    --red:#ef4444;--red2:#dc2626;
    --yellow:#f59e0b;
    --off:#f0f4ff;--muted:#94a3b8;--border:#e2e8f0;--text:#1e293b;--text2:#475569;
}
body{font-family:'DM Sans',sans-serif;background:var(--off);color:var(--text);min-height:100vh}

/* NAV */
.nav{background:var(--navy);padding:0 24px;height:58px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(59,130,246,.15);position:sticky;top:0;z-index:100;box-shadow:0 2px 12px rgba(0,0,0,.3)}
.nav-brand{display:flex;flex-direction:column;gap:1px}
.nav-name{font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:2.5px;color:#fff}
.nav-tag{font-size:8px;letter-spacing:3px;text-transform:uppercase;color:var(--gold)}
.nav-actions{display:flex;gap:8px;align-items:center}

/* BUTTONS */
.btn{padding:7px 14px;border-radius:7px;font-size:11px;font-weight:600;letter-spacing:.8px;text-transform:uppercase;cursor:pointer;border:none;text-decoration:none;display:inline-flex;align-items:center;gap:4px;white-space:nowrap;transition:opacity .15s,transform .1s}
.btn:hover{opacity:.85;transform:translateY(-1px)}
.btn-blue{background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff}
.btn-green{background:linear-gradient(135deg,var(--green),var(--green2));color:#fff}
.btn-gold{background:linear-gradient(135deg,var(--gold),var(--gold2));color:#fff}
.btn-red{background:linear-gradient(135deg,var(--red),var(--red2));color:#fff}
.btn-ghost{background:rgba(255,255,255,.07);color:var(--muted);border:1px solid rgba(255,255,255,.1)}
.btn-sm{padding:4px 10px;font-size:9px}

/* LAYOUT */
.main{max-width:1280px;margin:0 auto;padding:24px 18px}
.grid2{display:grid;grid-template-columns:1fr 1.4fr;gap:20px;align-items:start}

/* STATS */
.stat-row{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px}
.stat-card{background:#fff;border-radius:10px;padding:14px 16px;border:1px solid var(--border);box-shadow:0 1px 3px rgba(10,22,40,.05)}
.stat-num{font-family:'Bebas Neue',sans-serif;font-size:24px;letter-spacing:1px}
.stat-lbl{font-size:8.5px;letter-spacing:2px;text-transform:uppercase;color:var(--muted);margin-top:3px}

/* CARDS */
.card{background:#fff;border-radius:12px;padding:22px;border:1px solid var(--border);box-shadow:0 1px 4px rgba(10,22,40,.05)}
.sec-title{font-family:'Bebas Neue',sans-serif;font-size:15px;letter-spacing:2px;color:var(--navy);margin-bottom:16px}

/* FORM */
.form-row{margin-bottom:12px}
.form-lbl{font-size:9.5px;font-weight:600;color:#64748b;letter-spacing:1px;text-transform:uppercase;margin-bottom:4px;display:block}
.form-inp,.form-sel,.form-ta{width:100%;background:#f8faff;border:1.5px solid var(--border);border-radius:8px;padding:9px 13px;font-family:'DM Sans',sans-serif;font-size:13px;color:var(--text);outline:none;transition:border-color .15s}
.form-inp:focus,.form-sel:focus,.form-ta:focus{border-color:var(--blue2);background:#fff}
.form-ta{resize:vertical;min-height:60px}
.form-row2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.btn-save{width:100%;background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff;border:none;border-radius:10px;padding:13px;font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:2px;cursor:pointer;margin-top:14px;transition:opacity .15s}
.btn-save:hover{opacity:.9}

/* ALERTS */
.alert{border-radius:10px;padding:11px 16px;margin-bottom:16px;font-size:13px;display:flex;align-items:center;gap:8px}
.alert-success{background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);color:#15803d}
.alert-error{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#b91c1c}

/* DIFF BOX */
.diff-box{background:rgba(239,68,68,.05);border:1px solid rgba(239,68,68,.2);border-radius:8px;padding:12px;margin-top:10px;font-size:13px;display:none}
.diff-box.good{background:rgba(34,197,94,.05);border-color:rgba(34,197,94,.2)}

/* CSV BOX */
.csv-box{background:#f8faff;border:1px solid var(--border);border-radius:8px;padding:12px;margin-top:10px;max-height:180px;overflow-y:auto;font-size:11px}

/* TABLE */
.tbl-card{background:#fff;border-radius:12px;overflow:hidden;border:1px solid var(--border);box-shadow:0 1px 4px rgba(10,22,40,.05)}
.tbl-head{background:var(--navy);padding:12px 16px;display:flex;align-items:center;justify-content:space-between}
.tbl-title{font-family:'Bebas Neue',sans-serif;font-size:13px;letter-spacing:2px;color:var(--gold)}
.tbl-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse}
th{padding:9px 12px;text-align:left;font-size:8px;letter-spacing:2px;text-transform:uppercase;color:#64748b;background:#f8faff;border-bottom:2px solid var(--border);white-space:nowrap}
td{padding:9px 12px;font-size:12px;border-bottom:1px solid #f1f5f9;white-space:nowrap;vertical-align:middle}
tbody tr:hover td{background:#f8faff}
tbody tr:last-child td{border-bottom:none}

/* PILLS */
.pill{display:inline-block;padding:3px 9px;border-radius:20px;font-size:9.5px;font-weight:600;letter-spacing:.5px;text-transform:uppercase}
.pill.open{background:rgba(239,68,68,.1);color:#b91c1c;border:1px solid rgba(239,68,68,.25)}
.pill.closed{background:rgba(34,197,94,.1);color:#15803d;border:1px solid rgba(34,197,94,.25)}

.diff-pos{color:var(--red);font-weight:700}
.diff-zero{color:var(--green2);font-weight:600}
.diff-neg{color:var(--yellow);font-weight:600}

/* REASON ROW */
.reason-row td{background:#fef2f2!important;color:#7f1d1d;font-size:11px;white-space:normal}

/* EMPTY */
.empty-state{text-align:center;padding:36px;color:var(--muted);font-size:13px}

@media(max-width:900px){.grid2{grid-template-columns:1fr}.stat-row{grid-template-columns:1fr 1fr}}
@media(max-width:520px){.stat-row{grid-template-columns:1fr 1fr}.form-row2{grid-template-columns:1fr}.main{padding:14px 12px}}
@media print{
    .nav,.btn,.btn-save,form{display:none!important}
    body{background:#fff}
    .tbl-card{box-shadow:none;border:1px solid #ddd}
}
</style>
</head>
<body>

<!-- NAV -->
<nav class="nav">
    <div class="nav-brand">
        <div class="nav-name">Exazon — Reconciliation Report</div>
        <div class="nav-tag">Hub · Dispute Management</div>
    </div>
    <div class="nav-actions">
        <a href="index.php#reconciletab" target="_top" class="btn btn-blue">← Dashboard</a>
        <a href="?logout=1" target="_top" class="btn btn-ghost">Logout</a>
    </div>
</nav>

<div class="main">

<!-- ALERTS -->
<?php if(isset($_GET['saved'])): ?>
<div class="alert alert-success">✅ Reconciliation record saved successfully!</div>
<?php endif; ?>
<?php if($saveErr): ?>
<div class="alert alert-error">❌ Error: <?= htmlspecialchars($saveErr) ?></div>
<?php endif; ?>

<!-- STATS -->
<div class="stat-row">
    <div class="stat-card">
        <div class="stat-num" style="color:var(--red)"><?= $open_count ?></div>
        <div class="stat-lbl">Open Disputes</div>
    </div>
    <div class="stat-card">
        <div class="stat-num" style="color:var(--green2)"><?= $closed_count ?></div>
        <div class="stat-lbl">Resolved</div>
    </div>
    <div class="stat-card">
        <div class="stat-num" style="color:var(--yellow)"><?= $total_diff > 0 ? '+'.$total_diff : $total_diff ?></div>
        <div class="stat-lbl">Total Difference</div>
    </div>
    <div class="stat-card">
        <div class="stat-num" style="color:var(--blue)">₹<?= number_format($total_disp, 0) ?></div>
        <div class="stat-lbl">Dispute Amount</div>
    </div>
</div>

<div class="grid2">

<!-- LEFT: NEW RECORD FORM -->
<div class="card">
<div class="sec-title">➕ New Reconciliation</div>
<form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="save_rec" value="1">

    <!-- Project -->
    <?php if(!empty($projects)): ?>
    <div class="form-row">
        <label class="form-lbl">Auto-fill from Project</label>
        <select class="form-sel" id="projSel" onchange="fillProj()">
            <option value="">— Select Project —</option>
            <?php foreach($projects as $p): ?>
            <option value="<?= htmlspecialchars($p['survey_id']) ?>"
                data-client="<?= htmlspecialchars($p['client_name'] ?? '') ?>"
                data-completes="<?= intval($p['completes']) ?>">
                <?= htmlspecialchars($p['survey_id']) ?> (<?= intval($p['completes']) ?> completes)
            </option>
            <?php endforeach; ?>
        </select>
    </div>
    <?php endif; ?>

    <div class="form-row">
        <label class="form-lbl">Project ID</label>
        <input class="form-inp" type="text" name="project_id" id="projId" placeholder="Project ID" required>
    </div>

    <div class="form-row2">
        <div>
            <label class="form-lbl">Client Name</label>
            <input class="form-inp" type="text" name="client_name" id="clientName" placeholder="Client">
        </div>
        <div>
            <label class="form-lbl">Period</label>
            <input class="form-inp" type="text" name="period" value="<?= date('M Y') ?>" placeholder="May 2026">
        </div>
    </div>

    <div class="form-row2" style="margin-top:4px">
        <div>
            <label class="form-lbl">We Sent</label>
            <input class="form-inp" type="number" name="we_sent" id="weSent" placeholder="0" min="0" oninput="calcDiff()">
        </div>
        <div>
            <label class="form-lbl">Our Completes (DB)</label>
            <input class="form-inp" type="number" name="our_completes" id="ourComp" placeholder="0" min="0" oninput="calcDiff()">
        </div>
    </div>

    <div class="form-row2">
        <div>
            <label class="form-lbl">Client Accepted</label>
            <input class="form-inp" type="number" name="client_accepted" id="clientAcc" placeholder="0" min="0" oninput="calcDiff()">
        </div>
        <div>
            <label class="form-lbl">Client Rejected</label>
            <input class="form-inp" type="number" name="client_rejected" id="clientRej" placeholder="0" min="0" oninput="calcDiff()">
        </div>
    </div>

    <!-- Live Diff Box -->
    <div class="diff-box" id="diffBox">
        <strong>Difference: <span id="diffVal">0</span> completes</strong><br>
        <span style="font-size:11px;color:#64748b" id="diffMsg"></span>
    </div>

    <div class="form-row" style="margin-top:12px">
        <label class="form-lbl">Reject Reason (Client ne kya bola)</label>
        <textarea class="form-ta" name="reject_reason" placeholder="e.g. Bad quality, duplicate IPs, low LOI, speeder..."></textarea>
    </div>

    <div class="form-row2">
        <div>
            <label class="form-lbl">CPI</label>
            <input class="form-inp" type="number" name="cpi" placeholder="0.00" step="0.01" min="0">
        </div>
        <div>
            <label class="form-lbl">Currency</label>
            <select class="form-sel" name="currency">
                <option value="INR">INR ₹</option>
                <option value="USD">USD $</option>
                <option value="GBP">GBP £</option>
                <option value="EUR">EUR €</option>
                <option value="AED">AED</option>
            </select>
        </div>
    </div>

    <!-- CSV Upload -->
    <div class="form-row">
        <label class="form-lbl">Upload Client Rejection CSV (optional) — columns: UID, Status, Reason</label>
        <input type="file" name="csv_file" accept=".csv" class="form-inp" style="padding:7px">
    </div>
    <div class="form-row">
        <label class="form-lbl">Compare against Project (optional — SID, khaali chhodo to any project match ho)</label>
        <input type="text" name="rec_sid" class="form-inp" placeholder="e.g. KANTAR_UK_2026" value="<?= htmlspecialchars($_POST['rec_sid'] ?? '') ?>">
    </div>

    <?php if(!empty($csv_parsed)): ?>
    <div class="csv-box">
        <strong style="font-size:12px"><?= count($csv_parsed) ?> rows parsed:</strong><br><br>
        <?php foreach(array_slice($csv_parsed, 0, 20) as $cr): ?>
        <div style="padding:3px 0;border-bottom:1px solid #e2e8f0">
            <span style="color:var(--blue)"><?= htmlspecialchars($cr['uid']) ?></span>
            — <?= htmlspecialchars($cr['status']) ?>
            <?php if($cr['reason']): ?> — <span style="color:var(--red)"><?= htmlspecialchars($cr['reason']) ?></span><?php endif; ?>
        </div>
        <?php endforeach; ?>
        <?php if(count($csv_parsed) > 20): ?>
        <div style="color:var(--muted);font-size:10px;margin-top:6px">...and <?= count($csv_parsed)-20 ?> more rows</div>
        <?php endif; ?>
    </div>

    <!-- AUTO COMPARE RESULTS -->
    <div style="margin-top:16px">
        <div style="font-size:13px;font-weight:700;color:var(--navy);margin-bottom:10px">🔄 Auto Comparison — Apne Database Se</div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:12px">
            <div style="background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.25);border-radius:8px;padding:12px;text-align:center">
                <div style="font-size:22px;font-weight:700;color:#16a34a"><?= $compare_summary['matched'] ?></div>
                <div style="font-size:10px;letter-spacing:1px;text-transform:uppercase;color:#64748b">Matched</div>
            </div>
            <div style="background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.25);border-radius:8px;padding:12px;text-align:center">
                <div style="font-size:22px;font-weight:700;color:#d97706"><?= $compare_summary['mismatched'] ?></div>
                <div style="font-size:10px;letter-spacing:1px;text-transform:uppercase;color:#64748b">Mismatched</div>
            </div>
            <div style="background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.25);border-radius:8px;padding:12px;text-align:center">
                <div style="font-size:22px;font-weight:700;color:#dc2626"><?= $compare_summary['missing'] ?></div>
                <div style="font-size:10px;letter-spacing:1px;text-transform:uppercase;color:#64748b">Missing (not in our DB)</div>
            </div>
        </div>
        <div class="csv-box" style="max-height:240px">
            <?php foreach($compare_results as $cr): 
                $vcolor = $cr['verdict']==='matched' ? '#16a34a' : ($cr['verdict']==='mismatched' ? '#d97706' : '#dc2626');
            ?>
            <div style="padding:4px 0;border-bottom:1px solid #e2e8f0;display:flex;justify-content:space-between;gap:8px">
                <span><span style="color:var(--blue)"><?= htmlspecialchars($cr['uid']) ?></span> — Client: <?= htmlspecialchars($cr['their_status']) ?> | Ours: <?= $cr['our_status'] ? htmlspecialchars($cr['our_status']).' ('.htmlspecialchars($cr['sid']).')' : 'Not found' ?></span>
                <span style="font-weight:700;color:<?= $vcolor ?>;text-transform:uppercase;font-size:10px;white-space:nowrap"><?= $cr['verdict'] ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <div class="form-row" style="margin-top:12px">
        <label class="form-lbl">Status</label>
        <select class="form-sel" name="status">
            <option value="open">🔴 Open Dispute</option>
            <option value="closed">✅ Resolved</option>
        </select>
    </div>

    <div class="form-row">
        <label class="form-lbl">Notes</label>
        <textarea class="form-ta" name="notes" placeholder="Additional context, action taken..."></textarea>
    </div>

    <button type="submit" class="btn-save">💾 Save Record</button>
</form>
</div>

<!-- RIGHT: RECORDS TABLE -->
<div>
<div class="tbl-card">
    <div class="tbl-head">
        <div class="tbl-title">📋 Reconciliation Records (<?= count($records) ?>)</div>
        <button onclick="window.print()" class="btn btn-gold btn-sm">🖨 Print</button>
    </div>
    <div class="tbl-wrap">
    <?php if(empty($records)): ?>
    <div class="empty-state">
        <div style="font-size:32px;margin-bottom:8px">📭</div>
        No records yet. Add your first reconciliation on the left!
    </div>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th>Project</th>
                <th>Period</th>
                <th>We Sent</th>
                <th>Accepted</th>
                <th>Rejected</th>
                <th>Diff</th>
                <th>Dispute Amt</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach($records as $r):
            $diff = intval($r['difference']);
            $diffClass = $diff > 0 ? 'diff-pos' : ($diff < 0 ? 'diff-neg' : 'diff-zero');
            $sym = match($r['currency']){
                'USD' => '$', 'GBP' => '£', 'EUR' => '€', 'AED' => 'AED ', default => '₹'
            };
        ?>
        <tr>
            <td>
                <strong style="color:var(--blue);font-size:11px"><?= htmlspecialchars($r['project_id']) ?></strong>
                <?php if($r['client_name']): ?>
                <div style="font-size:10px;color:var(--muted)"><?= htmlspecialchars($r['client_name']) ?></div>
                <?php endif; ?>
            </td>
            <td style="font-size:11px"><?= htmlspecialchars($r['period']) ?></td>
            <td><?= number_format($r['we_sent']) ?></td>
            <td style="color:var(--green2);font-weight:600"><?= number_format($r['client_accepted']) ?></td>
            <td style="color:var(--red)"><?= number_format($r['client_rejected']) ?></td>
            <td class="<?= $diffClass ?>"><?= $diff > 0 ? '+'.$diff : $diff ?></td>
            <td><strong><?= $sym . number_format($r['dispute_amount'], 0) ?></strong></td>
            <td><span class="pill <?= htmlspecialchars($r['status']) ?>"><?= ucfirst($r['status']) ?></span></td>
            <td>
                <div style="display:flex;gap:4px">
                    <?php if($r['status'] === 'open'): ?>
                    <a href="?close=<?= $r['id'] ?>" class="btn btn-green btn-sm"
                       onclick="return confirm('Mark as resolved?')">Resolve</a>
                    <?php endif; ?>
                    <a href="?delete=<?= $r['id'] ?>" class="btn btn-ghost btn-sm"
                       onclick="return confirm('Delete this record?')" style="color:var(--muted)">🗑</a>
                </div>
            </td>
        </tr>
        <?php if(!empty($r['reject_reason'])): ?>
        <tr class="reason-row">
            <td colspan="9">⚠️ <strong>Client reason:</strong> <?= htmlspecialchars($r['reject_reason']) ?>
            <?php if($r['notes']): ?> · <em><?= htmlspecialchars($r['notes']) ?></em><?php endif; ?>
            </td>
        </tr>
        <?php endif; ?>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
    </div>
</div>
</div>

</div><!-- /grid2 -->
</div><!-- /main -->

<script>
function fillProj(){
    const sel = document.getElementById('projSel');
    const opt = sel.options[sel.selectedIndex];
    if(!opt || !opt.value) return;
    document.getElementById('projId').value    = opt.value;
    document.getElementById('clientName').value = opt.dataset.client || '';
    document.getElementById('ourComp').value   = opt.dataset.completes || '';
    calcDiff();
}

function calcDiff(){
    const our = parseInt(document.getElementById('ourComp').value)    || 0;
    const acc = parseInt(document.getElementById('clientAcc').value)  || 0;
    const rej = parseInt(document.getElementById('clientRej').value)  || 0;
    const diff = our - acc;
    const box  = document.getElementById('diffBox');
    const val  = document.getElementById('diffVal');
    const msg  = document.getElementById('diffMsg');

    if(our > 0 || acc > 0){
        box.style.display = 'block';
        val.textContent = (diff > 0 ? '+' : '') + diff;
        if(diff > 0){
            box.className = 'diff-box';
            val.style.color = '#ef4444';
            msg.textContent = 'Hamara data zyada hai — ExaVerify se proof attach karo dispute ke liye';
        } else if(diff < 0){
            box.className = 'diff-box';
            val.style.color = '#f59e0b';
            msg.textContent = 'Client ne zyada accept kiya — record note karo';
        } else {
            box.className = 'diff-box good';
            val.style.color = '#16a34a';
            msg.textContent = '✅ Match! Koi difference nahi hai';
        }
    } else {
        box.style.display = 'none';
    }
}
</script>
</body>
</html>
