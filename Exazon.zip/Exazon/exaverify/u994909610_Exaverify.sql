-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 18, 2026 at 12:28 AM
-- Server version: 11.8.8-MariaDB-log
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u994909610_Exaverify`
--

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_notes`
--

CREATE TABLE `dashboard_notes` (
  `id` int(10) UNSIGNED NOT NULL,
  `note` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `dashboard_notes`
--

INSERT INTO `dashboard_notes` (`id`, `note`, `created_at`) VALUES
(1, 'jhii', '2026-07-17 08:21:00'),
(2, 'hiii', '2026-07-17 08:21:05');

-- --------------------------------------------------------

--
-- Table structure for table `exz_audit_log`
--

CREATE TABLE `exz_audit_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `action` varchar(60) NOT NULL,
  `detail` varchar(255) DEFAULT '',
  `performed_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `exz_audit_log`
--

INSERT INTO `exz_audit_log` (`id`, `action`, `detail`, `performed_at`) VALUES
(1, 'update_auto_report', 'SID: TESTPRO01 -> ON (daily)', '2026-07-17 22:48:55'),
(2, 'auto_report_sent', 'SID: TESTPRO01 -> shavaz@exazonresearch.com (daily)', '2026-07-17 22:49:28'),
(3, 'update_auto_report', 'SID: TESTPRO01 -> OFF', '2026-07-17 22:55:57'),
(4, 'update_auto_report', 'SID: TESTPRO01 -> ON (daily)', '2026-07-17 23:06:04'),
(5, 'save_project', 'SID: FULLTEST01', '2026-07-17 23:19:24'),
(6, 'edit_project', 'SID: FULLTEST01', '2026-07-17 23:20:10'),
(7, 'edit_project', 'SID: FULLTEST01', '2026-07-17 23:25:27'),
(8, 'edit_project', 'SID: FULLTEST01', '2026-07-17 23:26:08'),
(9, 'edit_project', 'SID: FULLTEST01', '2026-07-17 23:41:59'),
(10, 'edit_project', 'SID: FULLTEST01', '2026-07-17 23:50:36'),
(11, 'edit_project', 'SID: FULLTEST01', '2026-07-17 23:53:26');

-- --------------------------------------------------------

--
-- Table structure for table `exz_clients`
--

CREATE TABLE `exz_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_name` varchar(150) NOT NULL,
  `contact_person` varchar(100) DEFAULT '',
  `email` varchar(150) DEFAULT '',
  `phone` varchar(40) DEFAULT '',
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `status` varchar(20) DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `exz_clients`
--

INSERT INTO `exz_clients` (`id`, `client_name`, `contact_person`, `email`, `phone`, `notes`, `created_at`, `status`) VALUES
(4, 'Nomi', '', '', '', NULL, '2026-07-17 03:40:23', 'active'),
(5, 'Test Client A', 'MR A', 'A@client.com', '9191919191', NULL, '2026-07-17 23:12:22', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `exz_invoice_status`
--

CREATE TABLE `exz_invoice_status` (
  `survey_id` varchar(50) NOT NULL,
  `status` varchar(20) DEFAULT 'unpaid',
  `invoice_no` varchar(50) DEFAULT '',
  `notes` text DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exz_project_vendors`
--

CREATE TABLE `exz_project_vendors` (
  `id` int(10) UNSIGNED NOT NULL,
  `survey_id` varchar(50) NOT NULL,
  `vendor_id` int(10) UNSIGNED NOT NULL,
  `assigned_at` datetime DEFAULT current_timestamp(),
  `status` varchar(20) DEFAULT 'active',
  `cpi` decimal(10,2) DEFAULT NULL,
  `max_limit` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `exz_project_vendors`
--

INSERT INTO `exz_project_vendors` (`id`, `survey_id`, `vendor_id`, `assigned_at`, `status`, `cpi`, `max_limit`) VALUES
(1, 'SIDD', 3, '2026-07-17 03:41:11', 'active', 5.00, NULL),
(11, 'TESTPRO01', 3, '2026-07-17 16:26:05', 'active', NULL, NULL),
(12, 'FULLTEST01', 6, '2026-07-17 23:21:06', 'active', 3.00, NULL),
(13, 'FULLTEST01', 5, '2026-07-17 23:54:25', 'active', 3.00, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `exz_screener_answers`
--

CREATE TABLE `exz_screener_answers` (
  `id` int(10) UNSIGNED NOT NULL,
  `survey_id` varchar(50) NOT NULL,
  `respondent` varchar(255) NOT NULL,
  `question_key` varchar(100) NOT NULL,
  `question_text` varchar(255) DEFAULT '',
  `answer_value` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `exz_screener_answers`
--

INSERT INTO `exz_screener_answers` (`id`, `survey_id`, `respondent`, `question_key`, `question_text`, `answer_value`, `created_at`) VALUES
(1, 'TESTPRO01', 'test000001', 'gender', 'What is your gender?', 'Male', '2026-07-17 15:41:23'),
(2, 'TESTPRO01', 'test000001', 'open_end', 'Tell us a little about yourself.', 'dsadsadsa fsfsf ffs', '2026-07-17 15:41:23'),
(3, 'TESTPRO01', 'test000001', 'device_self', 'What device are you using right now?', 'Desktop', '2026-07-17 15:41:23'),
(4, 'TESTPRO01', 'test000001', 'education', 'What is your highest education level?', 'Bachelor\'s degree', '2026-07-17 15:41:23'),
(5, 'TESTPRO01', 'test000001', 'age_group', 'What is your age group?', '55–64', '2026-07-17 15:41:23'),
(6, 'TESTPRO01', 'test000001', 'income', 'What is your approximate monthly household income?', '$75,000 to $99,999', '2026-07-17 15:41:23'),
(7, 'TESTPRO01', 'testpreentry00001', 'gender', 'What is your gender?', 'Male', '2026-07-17 15:44:45'),
(8, 'TESTPRO01', 'testpreentry00001', 'age_group', 'What is your age group?', '45–54', '2026-07-17 15:44:45'),
(9, 'TESTPRO01', 'testpreentry00001', 'education', 'What is your highest education level?', 'Bachelor\'s degree', '2026-07-17 15:44:45'),
(10, 'TESTPRO01', 'testpreentry00001', 'income', 'What is your approximate monthly household income?', '$75,000 to $99,999', '2026-07-17 15:44:45'),
(11, 'TESTPRO01', 'testpreentry00001', 'open_end', 'Tell us a little about yourself.', 'd rwrwqe hwqrwurwriwur wruewirwe r', '2026-07-17 15:44:45'),
(12, 'TESTPRO01', 'testpreentry00001', 'device_self', 'What device are you using right now?', 'Desktop', '2026-07-17 15:44:45'),
(13, 'TESTPRO01', 'flowvendpretst0001', 'gender', 'What is your gender?', 'Male', '2026-07-17 16:00:04'),
(14, 'TESTPRO01', 'flowvendpretst0001', 'device_self', 'What device are you using right now?', 'Desktop', '2026-07-17 16:00:04'),
(15, 'TESTPRO01', 'flowvendpretst0001', 'open_end', 'Tell us a little about yourself.', 'hi hi egef w rwewewqewqe qwrwe wew', '2026-07-17 16:00:04'),
(16, 'TESTPRO01', 'flowvendpretst0001', 'education', 'What is your highest education level?', 'Some college / Diploma', '2026-07-17 16:00:04'),
(17, 'TESTPRO01', 'flowvendpretst0001', 'income', 'What is your approximate monthly household income?', '$150,000 to $199,999', '2026-07-17 16:00:04'),
(18, 'TESTPRO01', 'flowvendpretst0001', 'age_group', 'What is your age group?', '45–54', '2026-07-17 16:00:04'),
(19, 'TESTPRO01', '8eecef4f9e', 'gender', 'What is your gender?', 'Male', '2026-07-17 16:27:30'),
(20, 'TESTPRO01', '8eecef4f9e', 'age_group', 'What is your age group?', '45–54', '2026-07-17 16:27:30'),
(21, 'TESTPRO01', '8eecef4f9e', 'education', 'What is your highest education level?', 'Bachelor\'s degree', '2026-07-17 16:27:30'),
(22, 'TESTPRO01', '8eecef4f9e', 'open_end', 'Tell us a little about yourself.', 'csd jsdnjdwnjj', '2026-07-17 16:27:30'),
(23, 'TESTPRO01', '8eecef4f9e', 'income', 'What is your approximate monthly household income?', '$200,000 to $249,999', '2026-07-17 16:27:30'),
(24, 'TESTPRO01', '8eecef4f9e', 'device_self', 'What device are you using right now?', 'Desktop', '2026-07-17 16:27:30');

-- --------------------------------------------------------

--
-- Table structure for table `exz_settings`
--

CREATE TABLE `exz_settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `exz_settings`
--

INSERT INTO `exz_settings` (`setting_key`, `setting_value`) VALUES
('alert_email', 'info@exazonresearch.com'),
('pv_cpi_backfilled_v1', '1'),
('telegram_bot_token', '8993325167:AAH8T70ipodxea-mjr4S5xlXf6GhYRCHYjQ'),
('telegram_chat_id', '887381966');

-- --------------------------------------------------------

--
-- Table structure for table `exz_share_links`
--

CREATE TABLE `exz_share_links` (
  `id` int(10) UNSIGNED NOT NULL,
  `survey_id` varchar(50) NOT NULL,
  `token` varchar(64) NOT NULL,
  `is_revoked` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `exz_share_links`
--

INSERT INTO `exz_share_links` (`id`, `survey_id`, `token`, `is_revoked`, `created_at`) VALUES
(1, 'SIDD', '85f0634b4216d5364f09792a4c21d32a', 1, '2026-07-17 06:21:12'),
(2, 'SIDD', '0851904f261c0739a14ecd054a415264', 0, '2026-07-17 15:11:30');

-- --------------------------------------------------------

--
-- Table structure for table `exz_team`
--

CREATE TABLE `exz_team` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) DEFAULT '',
  `password_hash` varchar(255) DEFAULT NULL,
  `role` varchar(20) DEFAULT 'viewer',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `exz_team`
--

INSERT INTO `exz_team` (`id`, `name`, `email`, `password_hash`, `role`, `is_active`, `created_at`) VALUES
(1, 'Super Admin', 'admin@exazonresearch.com', '$2y$10$.8eP2WKvVP6jNb5ggXTpy.burqY3mLMAEA7hAlovdNMr25c2x9vFe', 'superadmin', 1, '2026-07-17 03:05:25');

-- --------------------------------------------------------

--
-- Table structure for table `exz_uid_mapping`
--

CREATE TABLE `exz_uid_mapping` (
  `id` int(10) UNSIGNED NOT NULL,
  `original_uid` varchar(255) NOT NULL,
  `encrypted_uid` varchar(255) NOT NULL,
  `survey_id` varchar(50) DEFAULT NULL,
  `source` varchar(50) DEFAULT 'vendor',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `exz_uid_mapping`
--

INSERT INTO `exz_uid_mapping` (`id`, `original_uid`, `encrypted_uid`, `survey_id`, `source`, `created_at`) VALUES
(1, '[UID]', '278fca3c84', 'SIDD', 'vendor', '2026-07-17 06:52:45'),
(2, 'venserseentry', '2682e4e95e', 'SIDD', 'vendor', '2026-07-17 08:24:00'),
(3, 'testentryencryypted', '217aa1152e', 'TESTPRO01', 'vendor', '2026-07-17 16:26:50'),
(4, 'testpreecteyet', '8eecef4f9e', 'TESTPRO01', 'vendor', '2026-07-17 16:27:17'),
(5, 'dadada', 'db5f1fb00b', 'FULLTEST01', 'vendor', '2026-07-17 23:42:09'),
(6, 'fulltest001', 'b654faa289', 'FULLTEST01', 'vendor', '2026-07-17 23:45:58'),
(7, 'enctest001', '3964e62cf2', 'FULLTEST01', 'vendor', '2026-07-17 23:48:47'),
(8, 'duptest002', '884658744f', 'FULLTEST01', 'vendor', '2026-07-17 23:56:54');

-- --------------------------------------------------------

--
-- Table structure for table `exz_vendors`
--

CREATE TABLE `exz_vendors` (
  `id` int(10) UNSIGNED NOT NULL,
  `vendor_name` varchar(150) NOT NULL,
  `contact_person` varchar(100) DEFAULT '',
  `email` varchar(150) DEFAULT '',
  `phone` varchar(40) DEFAULT '',
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `complete_url` varchar(500) DEFAULT NULL,
  `terminate_url` varchar(500) DEFAULT NULL,
  `screenout_url` varchar(500) DEFAULT NULL,
  `quotafull_url` varchar(500) DEFAULT NULL,
  `end_behavior` varchar(20) DEFAULT 'show_page',
  `status` varchar(20) DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `exz_vendors`
--

INSERT INTO `exz_vendors` (`id`, `vendor_name`, `contact_person`, `email`, `phone`, `notes`, `created_at`, `complete_url`, `terminate_url`, `screenout_url`, `quotafull_url`, `end_behavior`, `status`) VALUES
(3, 'TestVendor', '', '', '', NULL, '2026-07-17 03:17:03', 'https://example.com/cb?uid=[UID]&status=complete', '', '', '', 'show_page', 'active'),
(5, 'FLOWVENDOR', '', '', '', NULL, '2026-07-17 15:39:02', '', '', '', '', 'show_page', 'active'),
(6, 'VENDOR TEST B', '', 'vender@B.com', '929292922', NULL, '2026-07-17 23:18:09', 'https://exaverify.exazonresearch.com/test_vendor_postback.php?status=complete&uid=[UID]&sid=[SID]', 'https://exaverify.exazonresearch.com/test_vendor_postback.php?status=terminate&uid=[UID]&sid=[SID]', 'https://exaverify.exazonresearch.com/test_vendor_postback.php?status=qc&uid=[UID]&sid=[SID]', 'https://exaverify.exazonresearch.com/test_vendor_postback.php?status=quotafull&uid=[UID]&sid=[SID]', 'show_page', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `portal_clients`
--

CREATE TABLE `portal_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(60) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `client_name` varchar(100) NOT NULL,
  `allowed_projects` text DEFAULT '',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `client_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_settings`
--

CREATE TABLE `project_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `survey_id` varchar(50) NOT NULL,
  `project_name` varchar(150) DEFAULT '',
  `target` int(10) UNSIGNED DEFAULT 0,
  `cpi` decimal(10,2) DEFAULT 0.00,
  `vendor_cost` decimal(10,2) DEFAULT 0.00,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `client_id` int(10) UNSIGNED DEFAULT NULL,
  `status` varchar(20) DEFAULT 'active',
  `is_pinned` tinyint(1) DEFAULT 0,
  `color_tag` varchar(20) DEFAULT '',
  `project_type` varchar(20) DEFAULT 'direct',
  `notes` text DEFAULT NULL,
  `live_url` text DEFAULT NULL,
  `encrypt_uid` tinyint(1) DEFAULT 1,
  `ir` decimal(5,2) DEFAULT 0.00,
  `loi` int(11) DEFAULT 0,
  `test_url` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `auto_report_enabled` tinyint(1) DEFAULT 0,
  `auto_report_freq` varchar(10) DEFAULT 'weekly',
  `auto_report_email` varchar(150) DEFAULT '',
  `auto_report_last_sent` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `project_settings`
--

INSERT INTO `project_settings` (`id`, `survey_id`, `project_name`, `target`, `cpi`, `vendor_cost`, `created_at`, `updated_at`, `client_id`, `status`, `is_pinned`, `color_tag`, `project_type`, `notes`, `live_url`, `encrypt_uid`, `ir`, `loi`, `test_url`, `description`, `auto_report_enabled`, `auto_report_freq`, `auto_report_email`, `auto_report_last_sent`) VALUES
(1, 'SIDD', 'jnsajndsa', 10, 5.00, 3.00, '2026-07-17 03:40:57', '2026-07-17 08:25:28', 4, 'active', 0, '', 'direct', 'dasd', '', 0, 0.00, 0, '', 'sdsadadadadad', 0, 'weekly', '', NULL),
(6, 'TESTPRO01', 'TESTINGFLOW', 20, 10.00, 4.00, '2026-07-17 15:37:33', '2026-07-17 23:06:04', 4, 'active', 0, '', 'direct', NULL, 'https://exaverify.exazonresearch.com/pages/track.php?status=complete&sid=TESTPRO01&uid=[UID]', 1, 0.00, 0, '', 'Hi Team', 1, 'daily', 'shavaz@exazonresearch.com', '2026-07-17 22:49:28'),
(7, 'FULLTEST01', 'FULLTEST01', 9, 5.00, 3.00, '2026-07-17 23:19:24', '2026-07-17 23:56:32', 5, 'active', 1, 'green', 'direct', NULL, 'https://exaverify.exazonresearch.com/test_client_survey.php?sid=[SID]&uid=[UID]', 1, 0.00, 0, '', 'TEST K LIYE POORA FLOW', 0, 'weekly', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `reconcile_records`
--

CREATE TABLE `reconcile_records` (
  `id` int(11) NOT NULL,
  `project_id` varchar(50) NOT NULL,
  `client_name` varchar(100) DEFAULT NULL,
  `period` varchar(30) DEFAULT NULL,
  `we_sent` int(11) DEFAULT 0,
  `client_accepted` int(11) DEFAULT 0,
  `client_rejected` int(11) DEFAULT 0,
  `reject_reason` text DEFAULT NULL,
  `our_completes` int(11) DEFAULT 0,
  `difference` int(11) DEFAULT 0,
  `cpi` decimal(10,2) DEFAULT 0.00,
  `currency` varchar(10) DEFAULT 'INR',
  `dispute_amount` decimal(12,2) DEFAULT 0.00,
  `status` varchar(20) DEFAULT 'open',
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `survey_responses`
--

CREATE TABLE `survey_responses` (
  `id` int(10) UNSIGNED NOT NULL,
  `survey_id` varchar(50) NOT NULL,
  `respondent` varchar(100) NOT NULL,
  `status` varchar(30) NOT NULL,
  `source` varchar(100) DEFAULT '',
  `client_name` varchar(100) DEFAULT '',
  `ip` varchar(45) DEFAULT '',
  `device` varchar(20) DEFAULT '',
  `country` varchar(100) DEFAULT '',
  `city` varchar(100) DEFAULT '',
  `loi_seconds` int(11) DEFAULT NULL,
  `is_duplicate` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `status_locked` tinyint(1) DEFAULT 0,
  `vendor_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `survey_responses`
--

INSERT INTO `survey_responses` (`id`, `survey_id`, `respondent`, `status`, `source`, `client_name`, `ip`, `device`, `country`, `city`, `loi_seconds`, `is_duplicate`, `created_at`, `status_locked`, `vendor_id`) VALUES
(1, 'Unknown_Project', 'Unknown_User', 'complete', 'direct', 'Unknown Client', '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', 'desktop', 'India', 'Lucknow', NULL, 0, '2026-07-17 15:41:23', 1, NULL),
(2, 'TESTPRO01', 'testttenltylink', 'complete', 'vendor', 'TESTINGFLOW', '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', 'desktop', 'India', 'Lucknow', 19800, 0, '2026-07-17 15:43:18', 1, 5),
(3, 'TESTPRO01', 'vendorflowtestwithentrylink0001', 'complete', 'vendor', 'TESTINGFLOW', '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', 'desktop', 'India', 'Lucknow', 19800, 0, '2026-07-17 15:58:17', 1, 5),
(4, 'TESTPRO01', 'flowvendpretst0001', 'complete', 'vendor', 'TESTINGFLOW', '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', 'desktop', 'India', 'Lucknow', 19817, 0, '2026-07-17 16:00:04', 1, 5),
(5, 'TESTPRO01', '217aa1152e', 'complete', 'FLOWVENDOR', 'Nomi', '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', 'desktop', 'India', 'Lucknow', 19800, 0, '2026-07-17 16:26:50', 1, 5),
(6, 'TESTPRO01', '8eecef4f9e', 'complete', 'TestVendor', 'Nomi', '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', 'desktop', 'India', 'Lucknow', 19814, 0, '2026-07-17 16:27:31', 1, 3),
(7, 'FULLTEST01', 'fulltest001', 'complete', 'VENDOR TEST B', 'Test Client A', '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', 'desktop', 'India', 'Lucknow', 19808, 0, '2026-07-17 23:28:45', 1, 6),
(8, 'FULLTEST01', 'RDIRECTRESTVENDR', 'complete', 'VENDOR TEST B', 'Test Client A', '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', 'desktop', 'India', 'Lucknow', 19807, 0, '2026-07-17 23:33:10', 1, 6),
(9, 'FULLTEST01', 'db5f1fb00b', 'complete', 'VENDOR TEST B', 'Test Client A', '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', 'desktop', 'India', 'Lucknow', 19802, 0, '2026-07-17 23:42:11', 1, 6),
(10, 'FULLTEST01', 'b654faa289', 'complete', 'VENDOR TEST B', 'Test Client A', '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', 'desktop', 'India', 'Lucknow', 19803, 0, '2026-07-17 23:46:01', 1, 6),
(11, 'FULLTEST01', '3964e62cf2', 'complete', 'VENDOR TEST B', 'Test Client A', '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', 'desktop', 'India', 'Lucknow', 19808, 0, '2026-07-17 23:48:55', 1, 6),
(12, 'FULLTEST01', '884658744f', 'complete', 'VENDOR TEST B', 'Test Client A', '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', 'desktop', 'India', 'Lucknow', 19802, 1, '2026-07-17 23:56:56', 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `survey_starts`
--

CREATE TABLE `survey_starts` (
  `id` int(10) UNSIGNED NOT NULL,
  `uid` varchar(255) NOT NULL,
  `sid` varchar(50) NOT NULL,
  `source` varchar(50) DEFAULT 'direct',
  `vendor_id` int(10) UNSIGNED DEFAULT NULL,
  `ip` varchar(45) DEFAULT '',
  `start_time` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `survey_starts`
--

INSERT INTO `survey_starts` (`id`, `uid`, `sid`, `source`, `vendor_id`, `ip`, `start_time`) VALUES
(1, 'test000001', 'TESTPRO01', 'vendor', 5, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 15:40:59'),
(2, 'testttenltylink', 'TESTPRO01', 'vendor', 5, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 15:43:18'),
(3, 'testpreentry00001', 'TESTPRO01', 'vendor', 5, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 15:44:28'),
(4, 'vendorflowtestwithentrylink0001', 'TESTPRO01', 'vendor', 5, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 15:58:17'),
(5, 'flowvendpretst0001', 'TESTPRO01', 'vendor', 5, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 15:59:47'),
(6, 'vendorflowtestwithentrylink0001', 'TESTPRO01', 'vendor', 5, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 16:03:10'),
(7, '217aa1152e', 'TESTPRO01', 'FLOWVENDOR', 5, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 16:26:50'),
(8, '8eecef4f9e', 'TESTPRO01', 'TestVendor', 3, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 16:27:17'),
(9, '[UID]', 'FULLTEST01', 'VENDOR TEST B', 6, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 23:21:50'),
(10, 'POORAflow', 'FULLTEST01', 'VENDOR TEST B', 6, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 23:22:02'),
(11, 'fulltest001', 'FULLTEST01', 'VENDOR TEST B', 6, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 23:23:55'),
(12, 'Fulltest001', 'FULLTEST01', 'VENDOR TEST B', 6, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 23:26:26'),
(13, 'fulltest001', 'FULLTEST01', 'VENDOR TEST B', 6, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 23:28:37'),
(14, 'RDIRECTRESTVENDR', 'FULLTEST01', 'VENDOR TEST B', 6, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 23:33:03'),
(15, 'RDIRECTRESTVENDR', 'FULLTEST01', 'VENDOR TEST B', 6, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 23:39:19'),
(16, 'RDIRECTRESTVENDR', 'FULLTEST01', 'VENDOR TEST B', 6, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 23:40:12'),
(17, 'db5f1fb00b', 'FULLTEST01', 'VENDOR TEST B', 6, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 23:42:09'),
(18, 'db5f1fb00b', 'FULLTEST01', 'VENDOR TEST B', 6, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 23:42:43'),
(19, 'b654faa289', 'FULLTEST01', 'VENDOR TEST B', 6, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 23:45:58'),
(20, '3964e62cf2', 'FULLTEST01', 'VENDOR TEST B', 6, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 23:48:47'),
(21, '884658744f', 'FULLTEST01', 'VENDOR TEST B', 6, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 23:56:54'),
(22, '884658744f', 'FULLTEST01', 'VENDOR TEST B', 6, '2401:4900:1c3c:446d:b0a7:48ee:84a5:cfdb', '2026-07-17 23:57:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dashboard_notes`
--
ALTER TABLE `dashboard_notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exz_audit_log`
--
ALTER TABLE `exz_audit_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exz_clients`
--
ALTER TABLE `exz_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exz_invoice_status`
--
ALTER TABLE `exz_invoice_status`
  ADD PRIMARY KEY (`survey_id`);

--
-- Indexes for table `exz_project_vendors`
--
ALTER TABLE `exz_project_vendors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_proj_vendor` (`survey_id`,`vendor_id`);

--
-- Indexes for table `exz_screener_answers`
--
ALTER TABLE `exz_screener_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_survey_respondent` (`survey_id`,`respondent`);

--
-- Indexes for table `exz_settings`
--
ALTER TABLE `exz_settings`
  ADD PRIMARY KEY (`setting_key`);

--
-- Indexes for table `exz_share_links`
--
ALTER TABLE `exz_share_links`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`);

--
-- Indexes for table `exz_team`
--
ALTER TABLE `exz_team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exz_uid_mapping`
--
ALTER TABLE `exz_uid_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_enc` (`encrypted_uid`),
  ADD KEY `idx_orig_sid` (`original_uid`,`survey_id`);

--
-- Indexes for table `exz_vendors`
--
ALTER TABLE `exz_vendors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `portal_clients`
--
ALTER TABLE `portal_clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `project_settings`
--
ALTER TABLE `project_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `survey_id` (`survey_id`);

--
-- Indexes for table `reconcile_records`
--
ALTER TABLE `reconcile_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `survey_responses`
--
ALTER TABLE `survey_responses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_survey` (`survey_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created` (`created_at`);

--
-- Indexes for table `survey_starts`
--
ALTER TABLE `survey_starts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_uid_sid` (`uid`,`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dashboard_notes`
--
ALTER TABLE `dashboard_notes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `exz_audit_log`
--
ALTER TABLE `exz_audit_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `exz_clients`
--
ALTER TABLE `exz_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `exz_project_vendors`
--
ALTER TABLE `exz_project_vendors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `exz_screener_answers`
--
ALTER TABLE `exz_screener_answers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `exz_share_links`
--
ALTER TABLE `exz_share_links`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `exz_team`
--
ALTER TABLE `exz_team`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `exz_uid_mapping`
--
ALTER TABLE `exz_uid_mapping`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `exz_vendors`
--
ALTER TABLE `exz_vendors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `portal_clients`
--
ALTER TABLE `portal_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project_settings`
--
ALTER TABLE `project_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `reconcile_records`
--
ALTER TABLE `reconcile_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `survey_responses`
--
ALTER TABLE `survey_responses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `survey_starts`
--
ALTER TABLE `survey_starts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
