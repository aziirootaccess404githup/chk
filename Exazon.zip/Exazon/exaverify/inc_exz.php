<?php
// ============================================================
// Exazon Research — inc_exz.php
// Shared tracking helper library used by vendor.php, entry.php,
// pages/track.php and the admin dashboard.
// Ported from the proven PanelEngine (Azilytics) architecture.
// ============================================================

date_default_timezone_set('Asia/Kolkata');

define('EXZ_DB_HOST', 'localhost');
define('EXZ_DB_NAME', 'u994909610_Exaverify');
define('EXZ_DB_USER', 'u994909610_Exaverify');
define('EXZ_DB_PASS', 'Exaverify@8181');
define('EXZ_SPEEDER_THRESHOLD', 180); // seconds

function exz_db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            "mysql:host=".EXZ_DB_HOST.";dbname=".EXZ_DB_NAME.";charset=utf8mb4",
            EXZ_DB_USER, EXZ_DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
             PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        );
        exz_ensure_tracking_tables($pdo);
    }
    return $pdo;
}

// Minimal, idempotent table set needed by the tracking scripts (vendor.php,
// entry.php, pages/track.php) so they work even before the admin dashboard
// has ever been opened (which normally creates these via its own ensureTables()).
// ── CLIENT EXTRA COLUMNS (client_uid — for client-level redirect URLs) ──
// Safely adds the column if it doesn't exist yet — no manual SQL needed.
function exz_ensure_client_extra_columns(PDO $db): void {
    try {
        $db->exec("ALTER TABLE exz_clients ADD COLUMN client_uid VARCHAR(20) DEFAULT NULL");
    } catch (PDOException $e) {
        // Column already exists — ignore (error 1060 = duplicate column)
    }
}

// Generates a short, unique, non-guessable code for a client (e.g. CLT7f3a2b),
// used in client-level redirect URLs so a client's own numeric database id
// is never exposed directly in a public-facing URL.
function exz_generate_client_uid(PDO $db): string {
    do {
        $code = 'CLT' . substr(bin2hex(random_bytes(4)), 0, 6);
        $chk = $db->prepare("SELECT id FROM exz_clients WHERE client_uid=? LIMIT 1");
        $chk->execute([$code]);
    } while ($chk->fetchColumn());
    return $code;
}

// ── SHORT LINK (exaverify.php?c=CODE) — a compact, optional alternative to
// the full vendor.php?sid=...&vid=...&uid=[UID] entry link. Purely
// additive — the regular vendor.php entry link keeps working exactly as
// before, side by side. (Also duplicated in index.php's own local scope,
// since index.php does not require this file — see the note there.)
function exz_ensure_short_code_column(PDO $db): void {
    try {
        $db->exec("ALTER TABLE exz_project_vendors ADD COLUMN short_code VARCHAR(10) DEFAULT NULL");
    } catch (PDOException $e) {
        // Column already exists — ignore (error 1060 = duplicate column)
    }
}

// ── CLICK-QUOTA (separate from max_limit / complete-quota) ────
// max_limit already existed as a column, but was never actually enforced
// anywhere in the code — a genuine pre-existing gap, fixed alongside this
// new feature. click_quota is a NEW, separate cap: how many total CLICKS
// (regardless of outcome) a vendor is allowed to send, useful for capping
// vendor spend/traffic even when completes are still under target.
function exz_ensure_click_quota_column(PDO $db): void {
    try {
        $db->exec("ALTER TABLE exz_project_vendors ADD COLUMN click_quota INT UNSIGNED DEFAULT NULL");
    } catch (PDOException $e) {}
}

// ── PER-VENDOR PRESCREENER TOGGLE ──────────────────────────────
// Previously, prescreener routing was decided entirely by which of the two
// entry-links a vendor was given (plain link vs "...&pre=1" link) — a
// manual, link-choice-based system. This adds an ADDITIONAL, optional
// database-level switch: if set on a specific vendor's mapping for a
// project, that vendor's traffic ALWAYS routes through the prescreener,
// even via the plain entry-link — without needing to hand them the
// separate pre-screener link at all. The existing &pre=1 URL-based system
// keeps working exactly as before for anyone not using this new toggle.
function exz_ensure_prescreener_toggle_column(PDO $db): void {
    try {
        $db->exec("ALTER TABLE exz_project_vendors ADD COLUMN show_prescreener TINYINT(1) DEFAULT 0");
    } catch (PDOException $e) {}
}

// ── PARENT/CHILD PROJECT CLONING ────────────────────────────────
// Lets a project be cloned into a new SID (e.g. same study, different
// country/market), copying over the relevant settings (client, CPI,
// target, encryption, description, etc.) while leaving fields that
// genuinely differ per-market (live_url/test_url, since each market's
// client survey link is typically different) blank on the clone.
// parent_sid records which project a clone came FROM, so "child projects"
// can be listed from the parent's own page.
function exz_ensure_parent_sid_column(PDO $db): void {
    try {
        $db->exec("ALTER TABLE project_settings ADD COLUMN parent_sid VARCHAR(50) DEFAULT NULL");
    } catch (PDOException $e) {}
}

// ── PROJECT TIMELINE + PROJECT MANAGER ─────────────────────────
// Matches MWR's "Project Start Date / End Date" and "Project Manager"
// fields, seen on their project-list and Statement-of-Work — genuinely
// useful, simple fields ExaVerify didn't have before.
function exz_ensure_project_timeline_columns(PDO $db): void {
    try { $db->exec("ALTER TABLE project_settings ADD COLUMN start_date DATE DEFAULT NULL"); } catch (PDOException $e) {}
    try { $db->exec("ALTER TABLE project_settings ADD COLUMN end_date DATE DEFAULT NULL"); } catch (PDOException $e) {}
    try { $db->exec("ALTER TABLE project_settings ADD COLUMN project_manager VARCHAR(100) DEFAULT ''"); } catch (PDOException $e) {}
}

// ── VENDOR EXTRA DETAILS (Panel Size + Availability Status) ────
// MWR's supplier record has a panel_size field and a survey_close (open/
// closed) status that ExaVerify's vendor record didn't have — genuinely
// useful at-a-glance info when deciding which vendor to assign traffic
// to. Purely informational — does not affect entry-flow/routing at all.
function exz_ensure_vendor_extra_columns(PDO $db): void {
    try { $db->exec("ALTER TABLE exz_vendors ADD COLUMN panel_size INT UNSIGNED DEFAULT NULL"); } catch (PDOException $e) {}
    try { $db->exec("ALTER TABLE exz_vendors ADD COLUMN availability_status VARCHAR(20) DEFAULT 'open'"); } catch (PDOException $e) {}
}

// ── POSTBACK STATUS (Redirect-Status log) ───────────────────────
// Records whether the vendor postback for a response actually fired
// successfully — separate from the respondent's own Complete/Terminate
// status. Values: 'sent' (network call completed, got a response),
// 'failed' (network call errored/timed out), 'not_applicable' (no
// postback URL configured for this vendor+status, so nothing was due
// to be sent), 'pending' (default, before any attempt/for direct traffic).
function exz_ensure_postback_status_columns(PDO $db): void {
    try { $db->exec("ALTER TABLE survey_responses ADD COLUMN postback_status VARCHAR(20) DEFAULT 'pending'"); } catch (PDOException $e) {}
    try { $db->exec("ALTER TABLE survey_responses ADD COLUMN postback_at DATETIME DEFAULT NULL"); } catch (PDOException $e) {}
}

function exz_generate_short_code(PDO $db): string {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I, avoids confusion
    do {
        $code = '';
        for ($i = 0; $i < 5; $i++) $code .= $chars[random_int(0, strlen($chars) - 1)];
        $chk = $db->prepare("SELECT id FROM exz_project_vendors WHERE short_code=? LIMIT 1");
        $chk->execute([$code]);
    } while ($chk->fetchColumn());
    return $code;
}

// ── BLOCKED IP LIST ──────────────────────────────────────────
// A manually-maintained blocklist — any respondent hitting vendor.php or
// prescreener.php from a blocked IP is stopped immediately, before any
// lead/click record is even created, with a reason logged for later review.
// ── BROWSER COLUMN (for IP Tracker — was captured by exz_browser() but
// never actually stored anywhere before this) ────────────────────────
// ── QUESTION LIBRARY + PRESCREEN TEMPLATES ────────────────────
// Reusable question bank (build once, use in any template/project) and
// reusable templates (a named, ordered set of questions) that a project
// can be assigned to — instead of rebuilding prescreener questions from
// scratch for every single project.
function exz_ensure_question_library_tables(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS exz_question_library (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        country VARCHAR(100) DEFAULT '',
        language VARCHAR(50) DEFAULT '',
        control_type VARCHAR(30) DEFAULT 'text',
        title VARCHAR(200) NOT NULL,
        question_text TEXT NOT NULL,
        min_length INT DEFAULT NULL,
        max_length INT DEFAULT NULL,
        text_type VARCHAR(30) DEFAULT '',
        options TEXT DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $db->exec("CREATE TABLE IF NOT EXISTS exz_prescreen_templates (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        template_name VARCHAR(150) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $db->exec("CREATE TABLE IF NOT EXISTS exz_prescreen_template_questions (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        template_id INT UNSIGNED NOT NULL,
        question_id INT UNSIGNED NOT NULL,
        sort_order INT DEFAULT 0,
        KEY idx_template (template_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

// Adds the project→template link column, so a project can (optionally)
// be assigned one saved template. If NULL, prescreener.php falls back to
// its original fixed 6-question set — fully backward compatible.
function exz_ensure_project_template_column(PDO $db): void {
    try {
        $db->exec("ALTER TABLE project_settings ADD COLUMN prescreen_template_id INT UNSIGNED DEFAULT NULL");
    } catch (PDOException $e) {}
}

// ── MULTI-COUNTRY LINK ────────────────────────────────────────
// Optional per-country URL overrides for a project. If a project has NO
// rows here, vendor.php uses project_settings.live_url exactly as before
// (100% backward compatible). If it DOES have country-link rows, the
// respondent's IP-detected country is checked against them — a match
// redirects to that country's specific URL instead of the default one.
function exz_ensure_country_links_table(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS exz_project_country_links (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        survey_id VARCHAR(50) NOT NULL,
        country VARCHAR(100) NOT NULL,
        live_url VARCHAR(500) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_sid_country (survey_id, country)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

// ── PM ACTIVITY LOG ────────────────────────────────────────────
// Per-project time/task tracking for project managers — a simple log of
// "who did what, for how long" against a specific project.
function exz_ensure_pm_activity_table(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS exz_project_activity_log (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        survey_id VARCHAR(50) NOT NULL,
        user_name VARCHAR(100) DEFAULT '',
        activity VARCHAR(150) NOT NULL,
        sub_activity VARCHAR(150) DEFAULT '',
        duration_minutes INT DEFAULT 0,
        notes TEXT DEFAULT NULL,
        logged_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        KEY idx_survey (survey_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}


function exz_ensure_browser_column(PDO $db): void {
    try {
        $db->exec("ALTER TABLE survey_responses ADD COLUMN browser VARCHAR(30) DEFAULT ''");
    } catch (PDOException $e) {
        // Column already exists — ignore (error 1060 = duplicate column)
    }
}

function exz_ensure_blocked_ips_table(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS exz_blocked_ips (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        ip VARCHAR(64) NOT NULL,
        comment VARCHAR(255) DEFAULT NULL,
        blocked_by VARCHAR(100) DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_ip (ip)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function exz_is_ip_blocked(PDO $db, string $ip): bool {
    try {
        exz_ensure_blocked_ips_table($db);
        $chk = $db->prepare("SELECT id FROM exz_blocked_ips WHERE ip=? LIMIT 1");
        $chk->execute([$ip]);
        return (bool)$chk->fetchColumn();
    } catch (Exception $e) {
        return false; // fail-open — never accidentally lock out all traffic due to a DB hiccup
    }
}

function exz_ensure_tracking_tables(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `survey_responses` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `survey_id`   VARCHAR(50)  NOT NULL,
        `respondent`  VARCHAR(100) NOT NULL,
        `status`      VARCHAR(30)  NOT NULL,
        `source`      VARCHAR(100) DEFAULT '',
        `client_name` VARCHAR(100) DEFAULT '',
        `ip`          VARCHAR(45)  DEFAULT '',
        `device`      VARCHAR(20)  DEFAULT '',
        `country`     VARCHAR(100) DEFAULT '',
        `city`        VARCHAR(100) DEFAULT '',
        `loi_seconds` INT DEFAULT NULL,
        `is_duplicate` TINYINT(1) DEFAULT 0,
        `status_locked` TINYINT(1) DEFAULT 0,
        `vendor_id`   INT UNSIGNED DEFAULT NULL,
        `created_at`  DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_survey (`survey_id`), INDEX idx_status (`status`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `survey_starts` (
        `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `uid`        VARCHAR(255) NOT NULL,
        `sid`        VARCHAR(50)  NOT NULL,
        `source`     VARCHAR(50)  DEFAULT 'direct',
        `vendor_id`  INT UNSIGNED DEFAULT NULL,
        `ip`         VARCHAR(45)  DEFAULT '',
        `start_time` DATETIME     DEFAULT CURRENT_TIMESTAMP,
        KEY idx_uid_sid (`uid`,`sid`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `project_settings` (
        `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `survey_id`    VARCHAR(50) NOT NULL UNIQUE,
        `project_name` VARCHAR(150) DEFAULT '',
        `client_id`    INT UNSIGNED DEFAULT NULL,
        `target`       INT UNSIGNED DEFAULT 0,
        `cpi`          DECIMAL(10,2) DEFAULT 0.00,
        `vendor_cost`  DECIMAL(10,2) DEFAULT 0.00,
        `status`       VARCHAR(20) DEFAULT 'active',
        `is_pinned`    TINYINT(1) DEFAULT 0,
        `color_tag`    VARCHAR(20) DEFAULT '',
        `project_type` VARCHAR(20) DEFAULT 'direct',
        `notes`        TEXT DEFAULT NULL,
        `live_url`     TEXT DEFAULT NULL,
        `test_url`     TEXT DEFAULT NULL,
        `description`  TEXT DEFAULT NULL,
        `encrypt_uid`  TINYINT(1) DEFAULT 1,
        `ir`           DECIMAL(5,2) DEFAULT 0,
        `loi`          INT DEFAULT 0,
        `created_at`   DATETIME DEFAULT CURRENT_TIMESTAMP,
        `updated_at`   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `exz_vendors` (
        `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `vendor_name`    VARCHAR(150) NOT NULL,
        `contact_person` VARCHAR(100) DEFAULT '',
        `email`          VARCHAR(150) DEFAULT '',
        `phone`          VARCHAR(40)  DEFAULT '',
        `complete_url`   VARCHAR(500) DEFAULT NULL,
        `terminate_url`  VARCHAR(500) DEFAULT NULL,
        `screenout_url`  VARCHAR(500) DEFAULT NULL,
        `quotafull_url`  VARCHAR(500) DEFAULT NULL,
        `end_behavior`   VARCHAR(20) DEFAULT 'show_page',
        `notes`          TEXT DEFAULT NULL,
        `created_at`     DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `exz_project_vendors` (
        `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `survey_id`  VARCHAR(50) NOT NULL,
        `vendor_id`  INT UNSIGNED NOT NULL,
        `status`     VARCHAR(20) DEFAULT 'active',
        `cpi`        DECIMAL(10,2) DEFAULT NULL,
        `max_limit`  INT UNSIGNED DEFAULT NULL,
        `assigned_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_proj_vendor (`survey_id`,`vendor_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `exz_uid_mapping` (
        `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `original_uid`  VARCHAR(255) NOT NULL,
        `encrypted_uid` VARCHAR(255) NOT NULL,
        `survey_id`     VARCHAR(50) DEFAULT NULL,
        `source`        VARCHAR(50) DEFAULT 'vendor',
        `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
        KEY idx_enc (`encrypted_uid`), KEY idx_orig_sid (`original_uid`,`survey_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `exz_settings` (
        `setting_key`   VARCHAR(100) PRIMARY KEY,
        `setting_value` TEXT DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `exz_audit_log` (
        `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `action`       VARCHAR(60) NOT NULL,
        `detail`       VARCHAR(255) DEFAULT '',
        `performed_at` DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `exz_share_links` (
        `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `survey_id`   VARCHAR(50) NOT NULL,
        `token`       VARCHAR(64) NOT NULL UNIQUE,
        `is_revoked`  TINYINT(1) DEFAULT 0,
        `created_at`  DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `exz_screener_answers` (
        `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `survey_id`     VARCHAR(50) NOT NULL,
        `respondent`    VARCHAR(255) NOT NULL,
        `question_key`  VARCHAR(100) NOT NULL,
        `question_text` VARCHAR(255) DEFAULT '',
        `answer_value`  TEXT DEFAULT NULL,
        `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
        KEY idx_survey_respondent (`survey_id`,`respondent`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

// ── IP / GEO / DEVICE / BROWSER ─────────────────────────────────
function exz_get_ip(): string {
    foreach (['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) return explode(',', $_SERVER[$k])[0];
    }
    return 'unknown';
}
function exz_geo(string $ip): array {
    // Primary provider
    $ctx = stream_context_create(['http' => ['timeout' => 3]]);
    $geo = @json_decode(@file_get_contents("http://ip-api.com/json/{$ip}", false, $ctx));
    if ($geo && $geo->status === 'success' && !empty($geo->country)) {
        return ['country' => $geo->country, 'city' => $geo->city ?? ''];
    }
    // Fallback provider (used if primary fails, times out, or is
    // rate-limited, e.g. under bursty traffic) - keeps country detection
    // working even if one provider is temporarily down.
    $ctx2 = stream_context_create(['http' => ['timeout' => 3]]);
    $geo2 = @json_decode(@file_get_contents("https://ipapi.co/{$ip}/json/", false, $ctx2));
    if ($geo2 && empty($geo2->error) && !empty($geo2->country_name)) {
        return ['country' => $geo2->country_name, 'city' => $geo2->city ?? ''];
    }
    return ['country' => 'Unknown', 'city' => ''];
}
function exz_device(): string {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (preg_match('/tablet|ipad/i', $ua)) return 'tablet';
    if (preg_match('/mobile|android|iphone/i', $ua)) return 'mobile';
    return 'desktop';
}
function exz_browser(): string {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (str_contains($ua,'Chrome')) return 'Chrome';
    if (str_contains($ua,'Firefox')) return 'Firefox';
    if (str_contains($ua,'Safari')) return 'Safari';
    if (str_contains($ua,'Edge')) return 'Edge';
    return 'Other';
}

// ── UID ENCRYPTION (opaque token + reverse-lookup mapping) ──────
function exz_encrypt_uid(PDO $db, string $uid, string $sid, string $source = 'vendor'): string {
    // Reuse existing token if this UID was already mapped for this project
    $chk = $db->prepare("SELECT encrypted_uid FROM exz_uid_mapping WHERE original_uid=? AND survey_id=? LIMIT 1");
    $chk->execute([$uid, $sid]);
    $existing = $chk->fetchColumn();
    if ($existing) return $existing;
    $token = bin2hex(random_bytes(5)); // 10-char opaque token
    $db->prepare("INSERT INTO exz_uid_mapping (original_uid,encrypted_uid,survey_id,source) VALUES (?,?,?,?)")
       ->execute([$uid, $token, $sid, $source]);
    return $token;
}
function exz_decrypt_uid(PDO $db, string $token, string $sid = ''): ?string {
    if ($sid) {
        $m = $db->prepare("SELECT original_uid FROM exz_uid_mapping WHERE encrypted_uid=? AND survey_id=? LIMIT 1");
        $m->execute([$token, $sid]);
        $row = $m->fetchColumn();
        if ($row) return $row;
    }
    // Fallback without sid filter — covers a client sending a mismatched sid
    $m2 = $db->prepare("SELECT original_uid FROM exz_uid_mapping WHERE encrypted_uid=? ORDER BY id DESC LIMIT 1");
    $m2->execute([$token]);
    $row2 = $m2->fetchColumn();
    return $row2 ?: null;
}

// ── SETTINGS (key/value config — alert email, telegram, etc.) ───
function exz_get_setting(PDO $db, string $key, string $default = ''): string {
    $s = $db->prepare("SELECT setting_value FROM exz_settings WHERE setting_key=?");
    $s->execute([$key]);
    $val = $s->fetchColumn();
    return $val !== false ? $val : $default;
}
function exz_set_setting(PDO $db, string $key, string $value): void {
    $db->prepare("INSERT INTO exz_settings (setting_key,setting_value) VALUES (?,?)
                  ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)")
       ->execute([$key, $value]);
}

// ── TELEGRAM / EMAIL ALERTS (settings-driven, not hardcoded) ────
function exz_send_telegram(PDO $db, string $msg): bool {
    $token = exz_get_setting($db, 'telegram_bot_token');
    $chat  = exz_get_setting($db, 'telegram_chat_id');
    if (!$token || !$chat) return false;
    $ctx = stream_context_create(['http' => [
        'method'  => 'POST',
        'header'  => 'Content-Type: application/x-www-form-urlencoded',
        'content' => http_build_query(['chat_id'=>$chat,'text'=>$msg,'parse_mode'=>'HTML']),
        'timeout' => 4,
    ]]);
    @file_get_contents("https://api.telegram.org/bot{$token}/sendMessage", false, $ctx);
    return true;
}
function exz_send_email(PDO $db, string $subject, string $msg): bool {
    $email = exz_get_setting($db, 'alert_email', 'info@exazonresearch.com');
    if (!$email) return false;
    $headers = "Content-Type: text/plain; charset=UTF-8\r\nFrom: dashboard@exazonresearch.com";
    return @mail($email, $subject, $msg, $headers);
}

// ── QUOTA AUTO-PAUSE ──────────────────────────────────────────
function exz_check_quota(PDO $db, string $sid): void {
    $p = $db->prepare("SELECT project_name,target,status FROM project_settings WHERE survey_id=? LIMIT 1");
    $p->execute([$sid]);
    $proj = $p->fetch();
    if (!$proj || $proj['status'] !== 'active' || empty($proj['target'])) return;
    $c = $db->prepare("SELECT COUNT(*) FROM survey_responses WHERE survey_id=? AND status='complete'");
    $c->execute([$sid]);
    if ((int)$c->fetchColumn() >= (int)$proj['target']) {
        $db->prepare("UPDATE project_settings SET status='paused' WHERE survey_id=?")->execute([$sid]);
        $msg = "🚨 Quota Reached\nProject: {$proj['project_name']} ($sid)\nTarget: {$proj['target']} completes\nStatus: Auto-paused";
        exz_send_telegram($db, $msg);
        exz_send_email($db, "Exazon Alert: Quota Reached — $sid", $msg);
    }
}

// ── SPEEDER ALERT ─────────────────────────────────────────────
function exz_speeder_check(PDO $db, ?array $proj, string $sid, string $uid, $actual_seconds): void {
    if ($actual_seconds === null || !is_numeric($actual_seconds)) return;
    if ((int)$actual_seconds >= EXZ_SPEEDER_THRESHOLD) return;
    $pname = $proj['project_name'] ?? $sid;
    $msg = "⚡ Speeder Detected\nProject: {$pname} ($sid)\nUID: {$uid}\nCompleted in ".round($actual_seconds/60,1)." min (under 3 min threshold)";
    exz_send_telegram($db, $msg);
}

// ── VENDOR POSTBACK / REDIRECT ───────────────────────────────
// Supports [UID] (vendor's own respondent id), [SID] (project code), [LOI] (seconds).
function exz_vendor_status_column(string $status): ?string {
    $map = ['complete'=>'complete_url','terminate'=>'terminate_url','quality_fail'=>'screenout_url','qc'=>'screenout_url','quotafull'=>'quotafull_url','overquota'=>'quotafull_url'];
    return $map[$status] ?? null;
}
function exz_get_vendor_url(PDO $db, ?int $vendor_id, string $status): ?string {
    if (!$vendor_id) return null;
    $col = exz_vendor_status_column($status);
    if (!$col) return null;
    $v = $db->prepare("SELECT $col FROM exz_vendors WHERE id=? LIMIT 1");
    $v->execute([$vendor_id]);
    $url = $v->fetchColumn();
    return $url ?: null;
}
function exz_get_vendor_behavior(PDO $db, ?int $vendor_id): string {
    if (!$vendor_id) return 'show_page';
    $v = $db->prepare("SELECT end_behavior FROM exz_vendors WHERE id=? LIMIT 1");
    $v->execute([$vendor_id]);
    return $v->fetchColumn() === 'redirect' ? 'redirect' : 'show_page';
}
// ── FLEXIBLE URL TOKEN REPLACEMENT ──────────────────────────────
// Replaces placeholder tokens inside ANY URL - a client's survey Live URL
// (vendor.php / prescreener.php) or a vendor's postback URL (exz_fire_vendor_postback
// / exz_build_vendor_redirect) - same engine, same behavior, both directions.
//
// Supports every bracket style seen across the industry (case-insensitive,
// whitespace-tolerant inside the brackets):
//   {{token}}   double-curly
//   [TOKEN]     square-bracket   (ExaVerify's own original style)
//   {token}     single-curly
//   %TOKEN%     percent-wrapped
//   <token>     angle-bracket
//   $token$     dollar-wrapped
//
// Anything not matching a known token is left completely untouched - this
// never guesses or invents a value for a token it wasn't given.
// $tokens is an associative array, e.g. ['uid' => $uid, 'sid' => $sid, 'loi' => $loi]
function exz_build_url(string $template, array $tokens): string {
    $url = $template;
    // Order matters: double-curly MUST be processed before single-curly,
    // otherwise the single-curly pattern would wrongly eat the inner half
    // of an unprocessed "{{token}}" (matching just "{token}" inside it).
    $wrapper_patterns = [
        '/\{\{\s*%s\s*\}\}/i',   // {{token}}
        '/\[\s*%s\s*\]/i',       // [TOKEN]
        '/\[#\s*%s\s*#\]/i',     // [#token#]  (e.g. OpinionSpark-style)
        '/\{\s*%s\s*\}/i',       // {token}
        '/%%\s*%s\s*%%/i',       // %TOKEN%
        '/<\s*%s\s*>/i',         // <token>
        '/\$\s*%s\s*\$/i',       // $token$
    ];
    foreach ($tokens as $key => $value) {
        if ($value === null) continue;
        $quoted_key = preg_quote((string)$key, '/');
        foreach ($wrapper_patterns as $pattern_template) {
            $pattern = sprintf($pattern_template, $quoted_key);
            $url = preg_replace($pattern, (string)$value, $url);
        }
    }
    return $url;
}

// Standard token set for vendor-postback URLs. $extra lets a call site
// add/override situational tokens (loi, status, etc).
function exz_build_token_set(string $uid, string $sid, array $extra = []): array {
    $base = [
        // 'pid' = Panelist ID (the respondent) — confirmed industry-standard
        // meaning per Medallia/SoSciSurvey/Qualtrics panel-integration docs.
        // NOT the project/survey ID (that's sid/studyid/surveyid below).
        'uid' => $uid, 'rid' => $uid, 'toid' => $uid, 'identifier' => $uid, 'tid' => $uid, 'pid' => $uid,
        'userid' => $uid, 'user_id' => $uid, 'respid' => $uid, 'resp_id' => $uid,
        'respondentid' => $uid, 'respondent_id' => $uid, 'panelistid' => $uid, 'panelist_id' => $uid,
        'participantid' => $uid, 'participant_id' => $uid, 'memberid' => $uid, 'member_id' => $uid,
        'entryid' => $uid, 'entry_id' => $uid, 'clickid' => $uid, 'subid' => $uid,
        'transactionid' => $uid, 'transaction_id' => $uid, 'qparm' => $uid, 'subject_id' => $uid,
        'ext_ref' => $uid, 'external_id' => $uid, 'id' => $uid, 'ticket' => $uid,
        'sid' => $sid, 'studyid' => $sid, 'surveyid' => $sid,
        'survey_id' => $sid, 'projectid' => $sid, 'project_id' => $sid, 'gid' => $sid,
        'project_code' => $sid, 'projectcode' => $sid,
        'date' => date('Y-m-d'),
        'timestamp' => (string)time(),
    ];
    return array_merge($base, $extra);
}

// Fills a vendor postback URL template with the respondent's data.
// Supports uid/rid/toid/identifier/tid, sid/pid/studyid, and loi - in any of
// the 6 bracket styles above. Existing vendor URLs using plain [UID]/[SID]/[LOI]
// keep working exactly as before (100% backward compatible).
function exz_fill_placeholders(string $tmpl, string $uid, string $sid, $loi = null): string {
    $tokens = exz_build_token_set(urlencode($uid), urlencode($sid), [
        'loi' => urlencode((string)($loi ?? '')),
    ]);
    return exz_build_url($tmpl, $tokens);
}
// Fires postback in background (non-blocking, safe no-op if no vendor/url configured)
function exz_fire_vendor_postback(PDO $db, ?int $vendor_id, string $status, string $uid, string $sid, $loi = null): void {
    exz_ensure_postback_status_columns($db);
    $tmpl = exz_get_vendor_url($db, $vendor_id, $status);
    if (!$tmpl) {
        // No postback URL configured for this vendor+status — nothing was due to be sent
        try {
            $db->prepare("UPDATE survey_responses SET postback_status='not_applicable' WHERE survey_id=? AND respondent=?")
                ->execute([$sid, $uid]);
        } catch (Exception $e) {}
        return;
    }
    $url = exz_fill_placeholders($tmpl, $uid, $sid, $loi);
    $result = 'failed';
    try {
        $ctx = stream_context_create(['http' => ['timeout' => 4, 'method' => 'GET']]);
        $response = @file_get_contents($url, false, $ctx);
        $result = ($response !== false) ? 'sent' : 'failed';
    } catch (Exception $e) { error_log("exz_fire_vendor_postback: ".$e->getMessage()); }
    try {
        $db->prepare("UPDATE survey_responses SET postback_status=?, postback_at=NOW() WHERE survey_id=? AND respondent=?")
            ->execute([$result, $sid, $uid]);
    } catch (Exception $e) {}
}
// Returns the fully-substituted redirect URL for redirect-mode vendors, or null.
function exz_build_vendor_redirect(PDO $db, ?int $vendor_id, string $status, string $uid, string $sid, $loi = null): ?string {
    if (exz_get_vendor_behavior($db, $vendor_id) !== 'redirect') return null;
    $tmpl = exz_get_vendor_url($db, $vendor_id, $status);
    if (!$tmpl) return null;
    return exz_fill_placeholders($tmpl, $uid, $sid, $loi);
}
// Deferred flush — respondent's own page is sent first, THEN the slow network
// calls (vendor postback + alerts) run, so a slow/down vendor server never
// delays what the respondent sees.
function exz_flush_and_defer(PDO $db, ?int $vendor_id, string $status, string $uid, string $sid, ?array $proj, $loi_seconds): void {
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    } else {
        if (ob_get_level() > 0) { @ob_end_flush(); }
        @flush();
    }
    if ($vendor_id) {
        exz_fire_vendor_postback($db, $vendor_id, $status, $uid, $sid, $loi_seconds);
    } else {
        // Direct traffic, no vendor to notify — nothing was due to be sent
        try {
            exz_ensure_postback_status_columns($db);
            $db->prepare("UPDATE survey_responses SET postback_status='not_applicable' WHERE survey_id=? AND respondent=?")
                ->execute([$sid, $uid]);
        } catch (Exception $e) {}
    }
    if ($status === 'complete' && $loi_seconds !== null) exz_speeder_check($db, $proj, $sid, $uid, $loi_seconds);

    // ── OUTBOUND S2S: report to the PROJECT'S CLIENT, if configured ──
    // This is the "we are the vendor/supplier reporting up to a
    // marketplace like Cint" direction — the mirror of the inbound
    // s2s_status.php endpoint (where WE receive reports from OUR OWN
    // vendors). Deliberately separate from exz_fire_vendor_postback
    // above, which reports to our own vendor, not the client.
    if ($proj && !empty($proj['client_id'])) {
        exz_fire_client_s2s($db, (int)$proj['client_id'], $status, $uid);
    }
}

function exz_fire_client_s2s(PDO $db, int $client_id, string $status, string $uid): void {
    try {
        $db->exec("ALTER TABLE exz_clients ADD COLUMN s2s_outbound_enabled TINYINT(1) DEFAULT 0");
        $db->exec("ALTER TABLE exz_clients ADD COLUMN s2s_outbound_endpoint VARCHAR(500) DEFAULT NULL");
        $db->exec("ALTER TABLE exz_clients ADD COLUMN s2s_outbound_token VARCHAR(200) DEFAULT NULL");
    } catch (PDOException $e) {}

    $cs = $db->prepare("SELECT s2s_outbound_enabled, s2s_outbound_endpoint, s2s_outbound_token FROM exz_clients WHERE id=? LIMIT 1");
    $cs->execute([$client_id]);
    $client = $cs->fetch();
    if (!$client || !$client['s2s_outbound_enabled'] || empty($client['s2s_outbound_endpoint'])) return;

    $ch = curl_init($client['s2s_outbound_endpoint']);
    $headers = ['Content-Type: application/json'];
    if (!empty($client['s2s_outbound_token'])) {
        $headers[] = 'Authorization: Bearer ' . $client['s2s_outbound_token'];
    }
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode(['respondent_id' => $uid, 'status' => $status]),
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => 4,
        CURLOPT_RETURNTRANSFER => true,
    ]);
    @curl_exec($ch); // fire-and-forget — never let a failed outbound S2S report break the respondent's own flow
    curl_close($ch);
}


// ── AUDIT LOG ─────────────────────────────────────────────────
function exz_log_audit(PDO $db, string $action, string $detail = ''): void {
    try { $db->prepare("INSERT INTO exz_audit_log (action,detail) VALUES (?,?)")->execute([$action,$detail]); }
    catch (Exception $e) {}
}

// ── PROJECT-ID RESOLUTION (client's own reference -> our internal survey_id) ──
// Different client survey platforms send back THEIR OWN project reference
// (not ours), under all sorts of different parameter names. This translates
// whatever they sent into our real internal survey_id, via a manually-
// maintained mapping table (exz_project_id_map). No auto-creation happens
// here on purpose - if no mapping exists yet, the value is returned
// UNCHANGED, and all of the EXISTING downstream SID-authority-resolution
// logic in pages/track.php keeps working exactly as it already does today
// for an unrecognized sid (it just becomes an unmatched response, visible
// on the dashboard for manual mapping later).
function exz_resolve_project_id(PDO $db, string $incoming_project_id): string {
    if ($incoming_project_id === '') return '';

    // 1) Is this already one of our own internal survey_ids? (e.g. a client
    // who happens to just pass through whatever survey_id we originally gave them)
    $ps = $db->prepare("SELECT survey_id FROM project_settings WHERE survey_id = ? LIMIT 1");
    $ps->execute([$incoming_project_id]);
    if ($ps->fetchColumn()) {
        return $incoming_project_id;
    }

    // 2) Look up the mapping table: client's own id -> our survey_id
    $ms = $db->prepare("SELECT sid FROM exz_project_id_map WHERE client_pid = ? LIMIT 1");
    $ms->execute([$incoming_project_id]);
    $mapped = $ms->fetchColumn();
    if ($mapped) {
        return $mapped;
    }

    // 3) No mapping found - return unchanged (unmatched). Nothing is
    // auto-created; existing fallback logic downstream handles this safely.
    return $incoming_project_id;
}
