<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);



require_once __DIR__ . "\x2f\x63\x6f\x6e\x66\x69\x67\x2e\x70\x68\x70";
rp_require_login();

$k2vPh_   = rp_db();
$aQAxJH = rp_current_user();
$G82gPq = $_GET["\x70\x61\x67\x65"] ?? "\x64\x61\x73\x68\x62\x6f\x61\x72\x64";
$v6hO9g  = "";
$dIi9Qh  = "";




if ($_SERVER["\x52\x45\x51\x55\x45\x53\x54\x5f\x4d\x45\x54\x48\x4f\x44"] === "\x50\x4f\x53\x54" && isset($_POST["\x61\x63\x74\x69\x6f\x6e"])) {
    $wlpgAb = $_POST["\x61\x63\x74\x69\x6f\x6e"];

    
    if ($wlpgAb === "\x74\x6f\x67\x67\x6c\x65\x5f\x70\x72\x6f\x6a\x65\x63\x74\x5f\x73\x74\x61\x74\x75\x73" && rp_is_manager()) {
        $hAuHcf = (int)$_POST["\x69\x64"];
        $_54bQ7 = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x73\x74\x61\x74\x75\x73\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x70\x72\x6f\x6a\x65\x63\x74\x73\x20\x57\x48\x45\x52\x45\x20\x69\x64\x3d\x3f");
        $_54bQ7->execute([$hAuHcf]);
        $OKXFHg = $_54bQ7->fetchColumn();
        $KWndfx = $OKXFHg === "\x61\x63\x74\x69\x76\x65" ? "\x70\x61\x75\x73\x65\x64" : "\x61\x63\x74\x69\x76\x65";
        $k2vPh_->prepare("\x55\x50\x44\x41\x54\x45\x20\x72\x70\x5f\x70\x72\x6f\x6a\x65\x63\x74\x73\x20\x53\x45\x54\x20\x73\x74\x61\x74\x75\x73\x3d\x3f\x20\x57\x48\x45\x52\x45\x20\x69\x64\x3d\x3f")->execute([$KWndfx, $hAuHcf]);
        $RUYfcG = $_SERVER["\x48\x54\x54\x50\x5f\x52\x45\x46\x45\x52\x45\x52"] ?? "";
        if (strpos($RUYfcG, "\x70\x72\x6f\x6a\x65\x63\x74\x5f\x76\x69\x65\x77") !== false) {
            header("Location: admin.php?page=project_view&id=$hAuHcf&msg=Project+".ucfirst($KWndfx));
        } else {
            header("\x4c\x6f\x63\x61\x74\x69\x6f\x6e\x3a\x20\x61\x64\x6d\x69\x6e\x2e\x70\x68\x70\x3f\x70\x61\x67\x65\x3d\x70\x72\x6f\x6a\x65\x63\x74\x73\x26\x6d\x73\x67\x3d\x50\x72\x6f\x6a\x65\x63\x74\x2b".ucfirst($KWndfx));
        }
        exit();
    }

    
    if ($wlpgAb === "\x64\x65\x6c\x65\x74\x65\x5f\x70\x72\x6f\x6a\x65\x63\x74" && rp_is_superadmin()) {
        $hAuHcf = (int)$_POST["\x69\x64"];
        $k2vPh_->prepare("\x44\x45\x4c\x45\x54\x45\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x70\x72\x6f\x6a\x65\x63\x74\x73\x20\x57\x48\x45\x52\x45\x20\x69\x64\x3d\x3f")->execute([$hAuHcf]);
        
        
        header("\x4c\x6f\x63\x61\x74\x69\x6f\x6e\x3a\x20\x61\x64\x6d\x69\x6e\x2e\x70\x68\x70\x3f\x70\x61\x67\x65\x3d\x70\x72\x6f\x6a\x65\x63\x74\x73\x26\x6d\x73\x67\x3d\x50\x72\x6f\x6a\x65\x63\x74\x2b\x64\x65\x6c\x65\x74\x65\x64");
        exit();
    }

    
    if ($wlpgAb === "\x73\x61\x76\x65\x5f\x6e\x6f\x74\x65\x73") {
        $QkM7eq = trim($_POST["\x63\x6f\x6e\x74\x65\x6e\x74"] ?? "");
        try {
            $N97s_D = $k2vPh_->query("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6e\x6f\x74\x65\x73")->fetchColumn();
            if ($N97s_D > 0) {
                $k2vPh_->prepare("\x55\x50\x44\x41\x54\x45\x20\x72\x70\x5f\x6e\x6f\x74\x65\x73\x20\x53\x45\x54\x20\x63\x6f\x6e\x74\x65\x6e\x74\x3d\x3f\x2c\x20\x75\x70\x64\x61\x74\x65\x64\x5f\x61\x74\x3d\x4e\x4f\x57\x28\x29\x20\x57\x48\x45\x52\x45\x20\x69\x64\x3d\x31")->execute([$QkM7eq]);
            } else {
                $k2vPh_->prepare("\x49\x4e\x53\x45\x52\x54\x20\x49\x4e\x54\x4f\x20\x72\x70\x5f\x6e\x6f\x74\x65\x73\x20\x28\x69\x64\x2c\x20\x63\x6f\x6e\x74\x65\x6e\x74\x2c\x20\x75\x70\x64\x61\x74\x65\x64\x5f\x61\x74\x29\x20\x56\x41\x4c\x55\x45\x53\x20\x28\x31\x2c\x20\x3f\x2c\x20\x4e\x4f\x57\x28\x29\x29")->execute([$QkM7eq]);
            }
            header("\x4c\x6f\x63\x61\x74\x69\x6f\x6e\x3a\x20\x61\x64\x6d\x69\x6e\x2e\x70\x68\x70\x3f\x70\x61\x67\x65\x3d\x6e\x6f\x74\x65\x73\x26\x6d\x73\x67\x3d\x4e\x6f\x74\x65\x73\x2b\x73\x61\x76\x65\x64");
        } catch (PDOException $PLys0H) {
            header("\x4c\x6f\x63\x61\x74\x69\x6f\x6e\x3a\x20\x61\x64\x6d\x69\x6e\x2e\x70\x68\x70\x3f\x70\x61\x67\x65\x3d\x6e\x6f\x74\x65\x73\x26\x65\x72\x72\x3d\x4e\x6f\x74\x65\x73\x2b\x74\x61\x62\x6c\x65\x2b\x6e\x6f\x74\x2b\x73\x65\x74\x2b\x75\x70\x2b\x79\x65\x74");
        }
        exit();
    }

    
    if ($wlpgAb === "\x63\x68\x61\x6e\x67\x65\x5f\x70\x61\x73\x73\x77\x6f\x72\x64") {
        $ZjpIcm = trim($_POST["\x63\x75\x72\x72\x65\x6e\x74\x5f\x70\x61\x73\x73\x77\x6f\x72\x64"] ?? "");
        $j7a_Xz     = trim($_POST["\x6e\x65\x77\x5f\x70\x61\x73\x73\x77\x6f\x72\x64"] ?? "");
        $jQc7jF = trim($_POST["\x63\x6f\x6e\x66\x69\x72\x6d\x5f\x70\x61\x73\x73\x77\x6f\x72\x64"] ?? "");
        $cyNJn3 = $aQAxJH["\x69\x64"];
        $Wsy1kv = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x75\x73\x65\x72\x73\x20\x57\x48\x45\x52\x45\x20\x69\x64\x3d\x3f");
        $Wsy1kv->execute([$cyNJn3]); $Wsy1kv = $Wsy1kv->fetch();
        if (!password_verify($ZjpIcm, $Wsy1kv["\x70\x61\x73\x73\x77\x6f\x72\x64"])) {
            header("\x4c\x6f\x63\x61\x74\x69\x6f\x6e\x3a\x20\x61\x64\x6d\x69\x6e\x2e\x70\x68\x70\x3f\x70\x61\x67\x65\x3d\x63\x68\x61\x6e\x67\x65\x5f\x70\x61\x73\x73\x77\x6f\x72\x64\x26\x65\x72\x72\x3d\x43\x75\x72\x72\x65\x6e\x74\x2b\x70\x61\x73\x73\x77\x6f\x72\x64\x2b\x69\x6e\x63\x6f\x72\x72\x65\x63\x74");
        } elseif (strlen($j7a_Xz) < 6) {
            header("\x4c\x6f\x63\x61\x74\x69\x6f\x6e\x3a\x20\x61\x64\x6d\x69\x6e\x2e\x70\x68\x70\x3f\x70\x61\x67\x65\x3d\x63\x68\x61\x6e\x67\x65\x5f\x70\x61\x73\x73\x77\x6f\x72\x64\x26\x65\x72\x72\x3d\x50\x61\x73\x73\x77\x6f\x72\x64\x2b\x6d\x75\x73\x74\x2b\x62\x65\x2b\x36\x2b\x63\x68\x61\x72\x73\x2b\x6d\x69\x6e\x69\x6d\x75\x6d");
        } elseif ($j7a_Xz !== $jQc7jF) {
            header("\x4c\x6f\x63\x61\x74\x69\x6f\x6e\x3a\x20\x61\x64\x6d\x69\x6e\x2e\x70\x68\x70\x3f\x70\x61\x67\x65\x3d\x63\x68\x61\x6e\x67\x65\x5f\x70\x61\x73\x73\x77\x6f\x72\x64\x26\x65\x72\x72\x3d\x50\x61\x73\x73\x77\x6f\x72\x64\x73\x2b\x64\x6f\x2b\x6e\x6f\x74\x2b\x6d\x61\x74\x63\x68");
        } else {
            $k2vPh_->prepare("\x55\x50\x44\x41\x54\x45\x20\x72\x70\x5f\x75\x73\x65\x72\x73\x20\x53\x45\x54\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x3d\x3f\x20\x57\x48\x45\x52\x45\x20\x69\x64\x3d\x3f")->execute([password_hash($j7a_Xz, PASSWORD_DEFAULT), $cyNJn3]);
            header("\x4c\x6f\x63\x61\x74\x69\x6f\x6e\x3a\x20\x61\x64\x6d\x69\x6e\x2e\x70\x68\x70\x3f\x70\x61\x67\x65\x3d\x63\x68\x61\x6e\x67\x65\x5f\x70\x61\x73\x73\x77\x6f\x72\x64\x26\x6d\x73\x67\x3d\x50\x61\x73\x73\x77\x6f\x72\x64\x2b\x63\x68\x61\x6e\x67\x65\x64\x2b\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6c\x6c\x79");
        }
        exit();
    }

    
    if ($wlpgAb === "\x73\x61\x76\x65\x5f\x70\x72\x6f\x6a\x65\x63\x74" && rp_is_manager()) {
        $hAuHcf = (int)($_POST["\x69\x64"] ?? 0);
        $sDiHyv = (int)($_POST["\x63\x6c\x69\x65\x6e\x74\x5f\x69\x64"] ?? 0);
        $uApzyj = "";
        if ($sDiHyv > 0) {
            $q7bpJt = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x63\x6c\x69\x65\x6e\x74\x73\x20\x57\x48\x45\x52\x45\x20\x69\x64\x3d\x3f");
            $q7bpJt->execute([$sDiHyv]);
            $uApzyj = $q7bpJt->fetchColumn() ?: "";
            if ($uApzyj === "") $sDiHyv = 0; 
        }
        $JmKUk_ = [
            "\x3a\x73\x69\x64"          => strtoupper(trim($_POST["\x73\x69\x64"])),
            "\x3a\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65" => trim($_POST["\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65"]),
            "\x3a\x63\x6c\x69\x65\x6e\x74\x5f\x69\x64"    => $sDiHyv > 0 ? $sDiHyv : null,
            "\x3a\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65"  => $uApzyj,
            "\x3a\x63\x70\x69"          => (float)($_POST["\x63\x70\x69"] ?? 0),
            "\x3a\x69\x72"           => (float)($_POST["\x69\x72"] ?? 0),
            "\x3a\x6c\x6f\x69"          => (int)($_POST["\x6c\x6f\x69"] ?? 0),
            "\x3a\x6d\x61\x78\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x73"=> (int)($_POST["\x6d\x61\x78\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x73"] ?? 0),
            "\x3a\x6c\x69\x76\x65\x5f\x75\x72\x6c"     => trim($_POST["\x6c\x69\x76\x65\x5f\x75\x72\x6c"] ?? ""),
            "\x3a\x74\x65\x73\x74\x5f\x75\x72\x6c"     => trim($_POST["\x74\x65\x73\x74\x5f\x75\x72\x6c"] ?? ""),
            "\x3a\x73\x74\x61\x74\x75\x73"       => $_POST["\x73\x74\x61\x74\x75\x73"] ?? "\x61\x63\x74\x69\x76\x65",
            "\x3a\x70\x72\x6f\x6a\x65\x63\x74\x5f\x74\x79\x70\x65" => $_POST["\x70\x72\x6f\x6a\x65\x63\x74\x5f\x74\x79\x70\x65"] ?? "\x64\x69\x72\x65\x63\x74",
            "\x3a\x65\x6e\x63\x72\x79\x70\x74\x5f\x75\x69\x64"  => isset($_POST["\x65\x6e\x63\x72\x79\x70\x74\x5f\x75\x69\x64"]) ? 1 : 0,
            "\x3a\x64\x65\x73\x63\x72\x69\x70\x74\x69\x6f\x6e"  => trim($_POST["\x64\x65\x73\x63\x72\x69\x70\x74\x69\x6f\x6e"] ?? ""),
        ];
        if ($hAuHcf > 0) {
            $m7RRoN = "UPDATE rp_projects SET sid=:sid, project_name=:project_name, client_id=:client_id, client_name=:client_name, cpi=:cpi, ir=:ir, loi=:loi, max_completes=:max_completes, live_url=:live_url, test_url=:test_url, status=:status, project_type=:project_type, encrypt_uid=:encrypt_uid, description=:description WHERE id=$hAuHcf";
        } else {
            $m7RRoN = "\x49\x4e\x53\x45\x52\x54\x20\x49\x4e\x54\x4f\x20\x72\x70\x5f\x70\x72\x6f\x6a\x65\x63\x74\x73\x20\x28\x73\x69\x64\x2c\x20\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65\x2c\x20\x63\x6c\x69\x65\x6e\x74\x5f\x69\x64\x2c\x20\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65\x2c\x20\x63\x70\x69\x2c\x20\x69\x72\x2c\x20\x6c\x6f\x69\x2c\x20\x6d\x61\x78\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x73\x2c\x20\x6c\x69\x76\x65\x5f\x75\x72\x6c\x2c\x20\x74\x65\x73\x74\x5f\x75\x72\x6c\x2c\x20\x73\x74\x61\x74\x75\x73\x2c\x20\x70\x72\x6f\x6a\x65\x63\x74\x5f\x74\x79\x70\x65\x2c\x20\x65\x6e\x63\x72\x79\x70\x74\x5f\x75\x69\x64\x2c\x20\x64\x65\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x29\x20\x56\x41\x4c\x55\x45\x53\x20\x28\x3a\x73\x69\x64\x2c\x3a\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65\x2c\x3a\x63\x6c\x69\x65\x6e\x74\x5f\x69\x64\x2c\x3a\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65\x2c\x3a\x63\x70\x69\x2c\x3a\x69\x72\x2c\x3a\x6c\x6f\x69\x2c\x3a\x6d\x61\x78\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x73\x2c\x3a\x6c\x69\x76\x65\x5f\x75\x72\x6c\x2c\x3a\x74\x65\x73\x74\x5f\x75\x72\x6c\x2c\x3a\x73\x74\x61\x74\x75\x73\x2c\x3a\x70\x72\x6f\x6a\x65\x63\x74\x5f\x74\x79\x70\x65\x2c\x3a\x65\x6e\x63\x72\x79\x70\x74\x5f\x75\x69\x64\x2c\x3a\x64\x65\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x29";
        }
        $k2vPh_->prepare($m7RRoN)->execute($JmKUk_);
        header("\x4c\x6f\x63\x61\x74\x69\x6f\x6e\x3a\x20\x61\x64\x6d\x69\x6e\x2e\x70\x68\x70\x3f\x70\x61\x67\x65\x3d\x70\x72\x6f\x6a\x65\x63\x74\x73\x26\x6d\x73\x67\x3d\x50\x72\x6f\x6a\x65\x63\x74\x2b\x73\x61\x76\x65\x64");
        exit();
    }
    
    if ($wlpgAb === "\x73\x61\x76\x65\x5f\x63\x6c\x69\x65\x6e\x74" && rp_is_manager()) {
        $hAuHcf = (int)($_POST["\x69\x64"] ?? 0);
        $JmKUk_ = [
            "\x3a\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65" => trim($_POST["\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65"]),
            "\x3a\x65\x6d\x61\x69\x6c"       => trim($_POST["\x65\x6d\x61\x69\x6c"] ?? ""),
            "\x3a\x70\x68\x6f\x6e\x65"       => trim($_POST["\x70\x68\x6f\x6e\x65"] ?? ""),
            "\x3a\x63\x6f\x6d\x70\x61\x6e\x79"     => trim($_POST["\x63\x6f\x6d\x70\x61\x6e\x79"] ?? ""),
            "\x3a\x73\x74\x61\x74\x75\x73"      => $_POST["\x73\x74\x61\x74\x75\x73"] ?? "\x61\x63\x74\x69\x76\x65",
        ];
        if ($hAuHcf > 0) {
            $k2vPh_->prepare("UPDATE rp_clients SET client_name=:client_name, email=:email, phone=:phone, company=:company, status=:status WHERE id=$hAuHcf")->execute($JmKUk_);
        } else {
            $k2vPh_->prepare("\x49\x4e\x53\x45\x52\x54\x20\x49\x4e\x54\x4f\x20\x72\x70\x5f\x63\x6c\x69\x65\x6e\x74\x73\x20\x28\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65\x2c\x20\x65\x6d\x61\x69\x6c\x2c\x20\x70\x68\x6f\x6e\x65\x2c\x20\x63\x6f\x6d\x70\x61\x6e\x79\x2c\x20\x73\x74\x61\x74\x75\x73\x29\x20\x56\x41\x4c\x55\x45\x53\x20\x28\x3a\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65\x2c\x3a\x65\x6d\x61\x69\x6c\x2c\x3a\x70\x68\x6f\x6e\x65\x2c\x3a\x63\x6f\x6d\x70\x61\x6e\x79\x2c\x3a\x73\x74\x61\x74\x75\x73\x29")->execute($JmKUk_);
        }
        header("\x4c\x6f\x63\x61\x74\x69\x6f\x6e\x3a\x20\x61\x64\x6d\x69\x6e\x2e\x70\x68\x70\x3f\x70\x61\x67\x65\x3d\x63\x6c\x69\x65\x6e\x74\x73\x26\x6d\x73\x67\x3d\x43\x6c\x69\x65\x6e\x74\x2b\x73\x61\x76\x65\x64");
        exit();
    }
    
    if ($wlpgAb === "\x73\x61\x76\x65\x5f\x76\x65\x6e\x64\x6f\x72" && rp_is_manager()) {
        $hAuHcf = (int)($_POST["\x69\x64"] ?? 0);
        $JmKUk_ = [
            "\x3a\x76\x65\x6e\x64\x6f\x72\x5f\x6e\x61\x6d\x65"   => trim($_POST["\x76\x65\x6e\x64\x6f\x72\x5f\x6e\x61\x6d\x65"]),
            "\x3a\x65\x6d\x61\x69\x6c"         => trim($_POST["\x65\x6d\x61\x69\x6c"] ?? ""),
            "\x3a\x70\x68\x6f\x6e\x65"         => trim($_POST["\x70\x68\x6f\x6e\x65"] ?? ""),
            "\x3a\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x75\x72\x6c"  => trim($_POST["\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x75\x72\x6c"] ?? ""),
            "\x3a\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x5f\x75\x72\x6c" => trim($_POST["\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x5f\x75\x72\x6c"] ?? ""),
            "\x3a\x73\x63\x72\x65\x65\x6e\x6f\x75\x74\x5f\x75\x72\x6c" => trim($_POST["\x73\x63\x72\x65\x65\x6e\x6f\x75\x74\x5f\x75\x72\x6c"] ?? ""),
            "\x3a\x71\x75\x6f\x74\x61\x66\x75\x6c\x6c\x5f\x75\x72\x6c" => trim($_POST["\x71\x75\x6f\x74\x61\x66\x75\x6c\x6c\x5f\x75\x72\x6c"] ?? ""),
            "\x3a\x65\x6e\x64\x5f\x62\x65\x68\x61\x76\x69\x6f\x72"  => in_array($_POST["\x65\x6e\x64\x5f\x62\x65\x68\x61\x76\x69\x6f\x72"] ?? "", ["\x73\x68\x6f\x77\x5f\x70\x61\x67\x65","\x72\x65\x64\x69\x72\x65\x63\x74"]) ? $_POST["\x65\x6e\x64\x5f\x62\x65\x68\x61\x76\x69\x6f\x72"] : "\x73\x68\x6f\x77\x5f\x70\x61\x67\x65",
            "\x3a\x73\x74\x61\x74\x75\x73"        => $_POST["\x73\x74\x61\x74\x75\x73"] ?? "\x61\x63\x74\x69\x76\x65",
        ];
        if ($hAuHcf > 0) {
            $k2vPh_->prepare("UPDATE rp_vendors SET vendor_name=:vendor_name, email=:email, phone=:phone, complete_url=:complete_url, terminate_url=:terminate_url, screenout_url=:screenout_url, quotafull_url=:quotafull_url, end_behavior=:end_behavior, status=:status WHERE id=$hAuHcf")->execute($JmKUk_);
        } else {
            $k2vPh_->prepare("\x49\x4e\x53\x45\x52\x54\x20\x49\x4e\x54\x4f\x20\x72\x70\x5f\x76\x65\x6e\x64\x6f\x72\x73\x20\x28\x76\x65\x6e\x64\x6f\x72\x5f\x6e\x61\x6d\x65\x2c\x20\x65\x6d\x61\x69\x6c\x2c\x20\x70\x68\x6f\x6e\x65\x2c\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x75\x72\x6c\x2c\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x5f\x75\x72\x6c\x2c\x20\x73\x63\x72\x65\x65\x6e\x6f\x75\x74\x5f\x75\x72\x6c\x2c\x20\x71\x75\x6f\x74\x61\x66\x75\x6c\x6c\x5f\x75\x72\x6c\x2c\x20\x65\x6e\x64\x5f\x62\x65\x68\x61\x76\x69\x6f\x72\x2c\x20\x73\x74\x61\x74\x75\x73\x29\x20\x56\x41\x4c\x55\x45\x53\x20\x28\x3a\x76\x65\x6e\x64\x6f\x72\x5f\x6e\x61\x6d\x65\x2c\x3a\x65\x6d\x61\x69\x6c\x2c\x3a\x70\x68\x6f\x6e\x65\x2c\x3a\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x75\x72\x6c\x2c\x3a\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x5f\x75\x72\x6c\x2c\x3a\x73\x63\x72\x65\x65\x6e\x6f\x75\x74\x5f\x75\x72\x6c\x2c\x3a\x71\x75\x6f\x74\x61\x66\x75\x6c\x6c\x5f\x75\x72\x6c\x2c\x3a\x65\x6e\x64\x5f\x62\x65\x68\x61\x76\x69\x6f\x72\x2c\x3a\x73\x74\x61\x74\x75\x73\x29")->execute($JmKUk_);
        }
        header("\x4c\x6f\x63\x61\x74\x69\x6f\x6e\x3a\x20\x61\x64\x6d\x69\x6e\x2e\x70\x68\x70\x3f\x70\x61\x67\x65\x3d\x76\x65\x6e\x64\x6f\x72\x73\x26\x6d\x73\x67\x3d\x56\x65\x6e\x64\x6f\x72\x2b\x73\x61\x76\x65\x64");
        exit();
    }
}


if ($G82gPq === "\x6c\x6f\x67\x6f\x75\x74") {
    rp_session_start();
    session_destroy();
    header("\x4c\x6f\x63\x61\x74\x69\x6f\x6e\x3a\x20\x6c\x6f\x67\x69\x6e\x2e\x70\x68\x70");
    exit();
}




$l81bu4 = [];
if ($G82gPq === "\x64\x61\x73\x68\x62\x6f\x61\x72\x64") {
    $l81bu4["\x74\x6f\x74\x61\x6c\x5f\x63\x6c\x69\x63\x6b\x73"]    = $k2vPh_->query("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73")->fetchColumn();
    $l81bu4["\x74\x6f\x74\x61\x6c\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x73"] = $k2vPh_->query("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73\x20\x57\x48\x45\x52\x45\x20\x73\x74\x61\x74\x75\x73\x3d\x27\x63\x6f\x6d\x70\x6c\x65\x74\x65\x27")->fetchColumn();
    $l81bu4["\x74\x6f\x74\x61\x6c\x5f\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x73"]= $k2vPh_->query("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73\x20\x57\x48\x45\x52\x45\x20\x73\x74\x61\x74\x75\x73\x3d\x27\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x27")->fetchColumn();
    $l81bu4["\x61\x63\x74\x69\x76\x65\x5f\x70\x72\x6f\x6a\x65\x63\x74\x73"] = $k2vPh_->query("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x70\x72\x6f\x6a\x65\x63\x74\x73\x20\x57\x48\x45\x52\x45\x20\x73\x74\x61\x74\x75\x73\x3d\x27\x61\x63\x74\x69\x76\x65\x27")->fetchColumn();
    $l81bu4["\x61\x63\x74\x69\x76\x65\x5f\x76\x65\x6e\x64\x6f\x72\x73"]  = $k2vPh_->query("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x76\x65\x6e\x64\x6f\x72\x73\x20\x57\x48\x45\x52\x45\x20\x73\x74\x61\x74\x75\x73\x3d\x27\x61\x63\x74\x69\x76\x65\x27")->fetchColumn();
    $l81bu4["\x74\x6f\x74\x61\x6c\x5f\x63\x6c\x69\x65\x6e\x74\x73"]   = $k2vPh_->query("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x63\x6c\x69\x65\x6e\x74\x73\x20\x57\x48\x45\x52\x45\x20\x73\x74\x61\x74\x75\x73\x3d\x27\x61\x63\x74\x69\x76\x65\x27")->fetchColumn();
}


$cQoAhS = [];
if ($G82gPq === "\x70\x72\x6f\x6a\x65\x63\x74\x73") {
    $ndzTbp = trim($_GET["\x70\x73\x65\x61\x72\x63\x68"] ?? "");
    if ($ndzTbp) {
        $OaWo9L = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x70\x2e\x2a\x2c\x20\x63\x2e\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65\x20\x61\x73\x20\x63\x6e\x61\x6d\x65\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x70\x72\x6f\x6a\x65\x63\x74\x73\x20\x70\x20\x4c\x45\x46\x54\x20\x4a\x4f\x49\x4e\x20\x72\x70\x5f\x63\x6c\x69\x65\x6e\x74\x73\x20\x63\x20\x4f\x4e\x20\x70\x2e\x63\x6c\x69\x65\x6e\x74\x5f\x69\x64\x3d\x63\x2e\x69\x64\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x57\x48\x45\x52\x45\x20\x70\x2e\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65\x20\x4c\x49\x4b\x45\x20\x3f\x20\x4f\x52\x20\x70\x2e\x73\x69\x64\x20\x4c\x49\x4b\x45\x20\x3f\x20\x4f\x52\x20\x63\x2e\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65\x20\x4c\x49\x4b\x45\x20\x3f\x20\x4f\x52\x44\x45\x52\x20\x42\x59\x20\x70\x2e\x69\x64\x20\x44\x45\x53\x43");
        $SEI6Zx = "%$ndzTbp%";
        $OaWo9L->execute([$SEI6Zx, $SEI6Zx, $SEI6Zx]);
        $cQoAhS = $OaWo9L->fetchAll();
    } else {
        $cQoAhS = $k2vPh_->query("\x53\x45\x4c\x45\x43\x54\x20\x70\x2e\x2a\x2c\x20\x63\x2e\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65\x20\x61\x73\x20\x63\x6e\x61\x6d\x65\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x70\x72\x6f\x6a\x65\x63\x74\x73\x20\x70\x20\x4c\x45\x46\x54\x20\x4a\x4f\x49\x4e\x20\x72\x70\x5f\x63\x6c\x69\x65\x6e\x74\x73\x20\x63\x20\x4f\x4e\x20\x70\x2e\x63\x6c\x69\x65\x6e\x74\x5f\x69\x64\x3d\x63\x2e\x69\x64\x20\x4f\x52\x44\x45\x52\x20\x42\x59\x20\x70\x2e\x69\x64\x20\x44\x45\x53\x43")->fetchAll();
    }
}


$C5P6NO = null;
if ($G82gPq === "\x70\x72\x6f\x6a\x65\x63\x74\x5f\x76\x69\x65\x77") {
    $dpRhB5 = (int)($_GET["\x69\x64"] ?? 0);
    $C5P6NO = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x2a\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x70\x72\x6f\x6a\x65\x63\x74\x73\x20\x57\x48\x45\x52\x45\x20\x69\x64\x3d\x3f");
    $C5P6NO->execute([$dpRhB5]);
    $C5P6NO = $C5P6NO->fetch();
    if ($C5P6NO) {
        
        $VwuomI = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x2a\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73\x20\x57\x48\x45\x52\x45\x20\x73\x69\x64\x3d\x3f\x20\x4f\x52\x44\x45\x52\x20\x42\x59\x20\x69\x64\x20\x44\x45\x53\x43\x20\x4c\x49\x4d\x49\x54\x20\x31\x30\x30");
        $VwuomI->execute([$C5P6NO["\x73\x69\x64"]]);
        $VwuomI = $VwuomI->fetchAll();
    }
}


$cYKgua = [];
if ($G82gPq === "\x63\x6c\x69\x65\x6e\x74\x73") {
    $cYKgua = $k2vPh_->query("\x53\x45\x4c\x45\x43\x54\x20\x2a\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x63\x6c\x69\x65\x6e\x74\x73\x20\x4f\x52\x44\x45\x52\x20\x42\x59\x20\x69\x64\x20\x44\x45\x53\x43")->fetchAll();
}


$ZgJMtg = [];
if ($G82gPq === "\x76\x65\x6e\x64\x6f\x72\x73") {
    $ZgJMtg = $k2vPh_->query("\x53\x45\x4c\x45\x43\x54\x20\x2a\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x76\x65\x6e\x64\x6f\x72\x73\x20\x4f\x52\x44\x45\x52\x20\x42\x59\x20\x69\x64\x20\x44\x45\x53\x43")->fetchAll();
}


$eI722w = null;
$pwH5Vw = [];
$TqUoDQ = [];
if ($G82gPq === "\x76\x65\x6e\x64\x6f\x72\x5f\x76\x69\x65\x77") {
    $N7XiRn = (int)($_GET["\x69\x64"] ?? 0);
    $aAhlql = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x2a\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x76\x65\x6e\x64\x6f\x72\x73\x20\x57\x48\x45\x52\x45\x20\x69\x64\x3d\x3f");
    $aAhlql->execute([$N7XiRn]);
    $eI722w = $aAhlql->fetch();
    if ($eI722w) {
        $YvQoi_ = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x6c\x2e\x2a\x2c\x20\x70\x2e\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73\x20\x6c\x20\x4c\x45\x46\x54\x20\x4a\x4f\x49\x4e\x20\x72\x70\x5f\x70\x72\x6f\x6a\x65\x63\x74\x73\x20\x70\x20\x4f\x4e\x20\x6c\x2e\x73\x69\x64\x3d\x70\x2e\x73\x69\x64\x20\x57\x48\x45\x52\x45\x20\x6c\x2e\x76\x65\x6e\x64\x6f\x72\x5f\x69\x64\x3d\x3f\x20\x4f\x52\x44\x45\x52\x20\x42\x59\x20\x6c\x2e\x69\x64\x20\x44\x45\x53\x43\x20\x4c\x49\x4d\x49\x54\x20\x32\x30\x30");
        $YvQoi_->execute([$N7XiRn]);
        $pwH5Vw = $YvQoi_->fetchAll();
        $q_0Skx = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x70\x76\x2e\x2a\x2c\x20\x70\x2e\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65\x2c\x20\x70\x2e\x73\x69\x64\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x70\x72\x6f\x6a\x65\x63\x74\x5f\x76\x65\x6e\x64\x6f\x72\x73\x20\x70\x76\x20\x4a\x4f\x49\x4e\x20\x72\x70\x5f\x70\x72\x6f\x6a\x65\x63\x74\x73\x20\x70\x20\x4f\x4e\x20\x70\x76\x2e\x70\x72\x6f\x6a\x65\x63\x74\x5f\x69\x64\x3d\x70\x2e\x69\x64\x20\x57\x48\x45\x52\x45\x20\x70\x76\x2e\x76\x65\x6e\x64\x6f\x72\x5f\x69\x64\x3d\x3f");
        $q_0Skx->execute([$N7XiRn]);
        $TqUoDQ = $q_0Skx->fetchAll();
    }
}


$l2Ujjb = [];
$BzIlzf = 0;
if ($G82gPq === "\x6c\x65\x61\x64\x73") {
    $ap_9j8         = trim($_GET["\x73\x65\x61\x72\x63\x68"] ?? "");
    $Aht9Ku  = $_GET["\x73\x74\x61\x74\x75\x73"] ?? "";
    $IuDAOU = $_GET["\x70\x72\x6f\x6a\x65\x63\x74"] ?? "";   
    $sBeN3J  = $_GET["\x64\x65\x76\x69\x63\x65"] ?? "";
    $LTs7ky  = $_GET["\x73\x6f\x75\x72\x63\x65"] ?? "";
    $m38dzQ  = (int) ($_GET["\x63\x6c\x69\x65\x6e\x74"] ?? 0);
    $dkAFb2 = $_GET["\x63\x6f\x75\x6e\x74\x72\x79"] ?? "";
    $G0ZjvK      = $_GET["\x64\x61\x74\x65\x5f\x66\x72\x6f\x6d"] ?? "";
    $M4d0nv        = $_GET["\x64\x61\x74\x65\x5f\x74\x6f"] ?? "";

    $hlxnd5  = max(1, (int)($_GET["\x6c\x70\x61\x67\x65"] ?? 1));
    $fOuz_T  = 50;
    $r5P36E = ($hlxnd5 - 1) * $fOuz_T;

    $LPQnbz  = "\x4c\x45\x46\x54\x20\x4a\x4f\x49\x4e\x20\x72\x70\x5f\x70\x72\x6f\x6a\x65\x63\x74\x73\x20\x70\x20\x4f\x4e\x20\x6c\x2e\x73\x69\x64\x20\x3d\x20\x70\x2e\x73\x69\x64\x20\x4c\x45\x46\x54\x20\x4a\x4f\x49\x4e\x20\x72\x70\x5f\x63\x6c\x69\x65\x6e\x74\x73\x20\x63\x20\x4f\x4e\x20\x70\x2e\x63\x6c\x69\x65\x6e\x74\x5f\x69\x64\x20\x3d\x20\x63\x2e\x69\x64";
    $Bun7BT  = "\x31\x3d\x31";
    $JePy4e = [];

    if ($ap_9j8)         { $Bun7BT .= "\x20\x41\x4e\x44\x20\x28\x6c\x2e\x6f\x72\x69\x67\x69\x6e\x61\x6c\x5f\x75\x69\x64\x20\x4c\x49\x4b\x45\x20\x3f\x20\x4f\x52\x20\x6c\x2e\x73\x69\x64\x20\x4c\x49\x4b\x45\x20\x3f\x29"; $JePy4e[] = "%$ap_9j8%"; $JePy4e[] = "%$ap_9j8%"; }
    if ($Aht9Ku)  { $Bun7BT .= "\x20\x41\x4e\x44\x20\x6c\x2e\x73\x74\x61\x74\x75\x73\x20\x3d\x20\x3f";  $JePy4e[] = $Aht9Ku; }
    if ($IuDAOU) { $Bun7BT .= "\x20\x41\x4e\x44\x20\x6c\x2e\x73\x69\x64\x20\x3d\x20\x3f";     $JePy4e[] = $IuDAOU; }
    if ($sBeN3J)  { $Bun7BT .= "\x20\x41\x4e\x44\x20\x6c\x2e\x64\x65\x76\x69\x63\x65\x20\x3d\x20\x3f";  $JePy4e[] = $sBeN3J; }
    if ($LTs7ky)  { $Bun7BT .= "\x20\x41\x4e\x44\x20\x6c\x2e\x73\x6f\x75\x72\x63\x65\x20\x3d\x20\x3f";  $JePy4e[] = $LTs7ky; }
    if ($m38dzQ)  { $Bun7BT .= "\x20\x41\x4e\x44\x20\x63\x2e\x69\x64\x20\x3d\x20\x3f";      $JePy4e[] = $m38dzQ; }
    if ($dkAFb2) { $Bun7BT .= "\x20\x41\x4e\x44\x20\x6c\x2e\x63\x6f\x75\x6e\x74\x72\x79\x20\x3d\x20\x3f"; $JePy4e[] = $dkAFb2; }
    if ($G0ZjvK)      { $Bun7BT .= "\x20\x41\x4e\x44\x20\x44\x41\x54\x45\x28\x6c\x2e\x63\x72\x65\x61\x74\x65\x64\x5f\x61\x74\x29\x20\x3e\x3d\x20\x3f"; $JePy4e[] = $G0ZjvK; }
    if ($M4d0nv)        { $Bun7BT .= "\x20\x41\x4e\x44\x20\x44\x41\x54\x45\x28\x6c\x2e\x63\x72\x65\x61\x74\x65\x64\x5f\x61\x74\x29\x20\x3c\x3d\x20\x3f"; $JePy4e[] = $M4d0nv; }

    
    $h8sOUt  = $k2vPh_->query("\x53\x45\x4c\x45\x43\x54\x20\x73\x69\x64\x2c\x20\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x70\x72\x6f\x6a\x65\x63\x74\x73\x20\x4f\x52\x44\x45\x52\x20\x42\x59\x20\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65")->fetchAll();
    $O_ptcp   = $k2vPh_->query("\x53\x45\x4c\x45\x43\x54\x20\x69\x64\x2c\x20\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x63\x6c\x69\x65\x6e\x74\x73\x20\x4f\x52\x44\x45\x52\x20\x42\x59\x20\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65")->fetchAll();
    $ecJRz2 = $k2vPh_->query("\x53\x45\x4c\x45\x43\x54\x20\x44\x49\x53\x54\x49\x4e\x43\x54\x20\x63\x6f\x75\x6e\x74\x72\x79\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73\x20\x57\x48\x45\x52\x45\x20\x63\x6f\x75\x6e\x74\x72\x79\x20\x49\x53\x20\x4e\x4f\x54\x20\x4e\x55\x4c\x4c\x20\x41\x4e\x44\x20\x63\x6f\x75\x6e\x74\x72\x79\x20\x3c\x3e\x20\x27\x27\x20\x4f\x52\x44\x45\x52\x20\x42\x59\x20\x63\x6f\x75\x6e\x74\x72\x79")->fetchAll(PDO::FETCH_COLUMN);
    $XcI1mt   = ["\x64\x65\x73\x6b\x74\x6f\x70", "\x6d\x6f\x62\x69\x6c\x65", "\x74\x61\x62\x6c\x65\x74"];
    $FfcP4v   = ["\x64\x69\x72\x65\x63\x74", "\x70\x72\x65\x73\x63\x72\x65\x65\x6e\x65\x72"];

    
    
    if (($_GET["\x65\x78\x70\x6f\x72\x74"] ?? "") === "\x63\x73\x76") {
        $r_M3PR = $k2vPh_->prepare("SELECT l.*, p.project_name, c.client_name FROM rp_leads l $LPQnbz WHERE $Bun7BT ORDER BY l.id DESC");
        $r_M3PR->execute($JePy4e);
        $nEwJUU = $r_M3PR->fetchAll();

        header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x54\x79\x70\x65\x3a\x20\x74\x65\x78\x74\x2f\x63\x73\x76\x3b\x20\x63\x68\x61\x72\x73\x65\x74\x3d\x75\x74\x66\x2d\x38");
        header("\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x44\x69\x73\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a\x20\x61\x74\x74\x61\x63\x68\x6d\x65\x6e\x74\x3b\x20\x66\x69\x6c\x65\x6e\x61\x6d\x65\x3d\x22\x6c\x65\x61\x64\x73\x5f\x65\x78\x70\x6f\x72\x74\x5f" . date("\x59\x2d\x6d\x2d\x64\x5f\x48\x69\x73") . "\x2e\x63\x73\x76\x22");
        $VPYurX = fopen("\x70\x68\x70\x3a\x2f\x2f\x6f\x75\x74\x70\x75\x74", "\x77");
        fputs($VPYurX, "\xef\xbb\xbf"); 
        fputcsv($VPYurX, ["\x23", "\x55\x49\x44", "\x45\x6e\x63\x72\x79\x70\x74\x65\x64\x20\x55\x49\x44", "\x53\x49\x44", "\x50\x72\x6f\x6a\x65\x63\x74", "\x43\x6c\x69\x65\x6e\x74", "\x53\x74\x61\x74\x75\x73", "\x43\x6f\x75\x6e\x74\x72\x79", "\x43\x69\x74\x79", "\x44\x65\x76\x69\x63\x65", "\x42\x72\x6f\x77\x73\x65\x72", "\x53\x6f\x75\x72\x63\x65", "\x4c\x4f\x49\x20\x28\x6d\x69\x6e\x29", "\x49\x50", "\x44\x75\x70\x6c\x69\x63\x61\x74\x65", "\x45\x6e\x74\x72\x79\x20\x54\x69\x6d\x65", "\x45\x6e\x64\x20\x54\x69\x6d\x65", "\x43\x72\x65\x61\x74\x65\x64\x20\x41\x74"]);
        foreach ($nEwJUU as $GqmAku => $Gz_OK0) {
            fputcsv($VPYurX, [
                $GqmAku + 1,
                $Gz_OK0["\x6f\x72\x69\x67\x69\x6e\x61\x6c\x5f\x75\x69\x64"],
                $Gz_OK0["\x65\x6e\x63\x72\x79\x70\x74\x65\x64\x5f\x75\x69\x64"],
                $Gz_OK0["\x73\x69\x64"],
                $Gz_OK0["\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65"],
                $Gz_OK0["\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65"],
                $Gz_OK0["\x73\x74\x61\x74\x75\x73"],
                $Gz_OK0["\x63\x6f\x75\x6e\x74\x72\x79"],
                $Gz_OK0["\x63\x69\x74\x79"],
                $Gz_OK0["\x64\x65\x76\x69\x63\x65"],
                $Gz_OK0["\x62\x72\x6f\x77\x73\x65\x72"],
                $Gz_OK0["\x73\x6f\x75\x72\x63\x65"],
                $Gz_OK0["\x6c\x6f\x69\x5f\x73\x65\x63\x6f\x6e\x64\x73"] ? round($Gz_OK0["\x6c\x6f\x69\x5f\x73\x65\x63\x6f\x6e\x64\x73"] / 60, 1) : "",
                $Gz_OK0["\x69\x70"],
                !empty($Gz_OK0["\x69\x73\x5f\x64\x75\x70\x6c\x69\x63\x61\x74\x65"]) ? "\x59\x65\x73" : "\x4e\x6f",
                $Gz_OK0["\x65\x6e\x74\x72\x79\x5f\x74\x69\x6d\x65"],
                $Gz_OK0["\x65\x6e\x64\x5f\x74\x69\x6d\x65"],
                $Gz_OK0["\x63\x72\x65\x61\x74\x65\x64\x5f\x61\x74"],
            ]);
        }
        fclose($VPYurX);
        exit;
    }

    $hU2R11 = $k2vPh_->prepare("SELECT COUNT(*) FROM rp_leads l $LPQnbz WHERE $Bun7BT");
    $hU2R11->execute($JePy4e);
    $BzIlzf = $hU2R11->fetchColumn();
    $OHqtR4 = $k2vPh_->prepare("SELECT l.*, p.project_name, c.client_name FROM rp_leads l $LPQnbz WHERE $Bun7BT ORDER BY l.id DESC LIMIT $fOuz_T OFFSET $r5P36E");
    $OHqtR4->execute($JePy4e);
    $l2Ujjb = $OHqtR4->fetchAll();
}


$PUSZz9 = "";
if ($G82gPq === "\x6e\x6f\x74\x65\x73") {
    try {
        $ndVVxL = $k2vPh_->query("\x53\x45\x4c\x45\x43\x54\x20\x63\x6f\x6e\x74\x65\x6e\x74\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6e\x6f\x74\x65\x73\x20\x57\x48\x45\x52\x45\x20\x69\x64\x3d\x31")->fetchColumn();
        $PUSZz9 = $ndVVxL ?: "";
    } catch (PDOException $PLys0H) {
        $PUSZz9 = "";
    }
}


$u6VvlJ = $k2vPh_->query("\x53\x45\x4c\x45\x43\x54\x20\x69\x64\x2c\x20\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x63\x6c\x69\x65\x6e\x74\x73\x20\x57\x48\x45\x52\x45\x20\x73\x74\x61\x74\x75\x73\x3d\x27\x61\x63\x74\x69\x76\x65\x27\x20\x4f\x52\x44\x45\x52\x20\x42\x59\x20\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65")->fetchAll();
$PB9X5i = $k2vPh_->query("\x53\x45\x4c\x45\x43\x54\x20\x69\x64\x2c\x20\x76\x65\x6e\x64\x6f\x72\x5f\x6e\x61\x6d\x65\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x76\x65\x6e\x64\x6f\x72\x73\x20\x57\x48\x45\x52\x45\x20\x73\x74\x61\x74\x75\x73\x3d\x27\x61\x63\x74\x69\x76\x65\x27\x20\x4f\x52\x44\x45\x52\x20\x42\x59\x20\x76\x65\x6e\x64\x6f\x72\x5f\x6e\x61\x6d\x65")->fetchAll();

$v6hO9g = $_GET["\x6d\x73\x67"] ?? "";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Matrix World Research Panel</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Mono&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#f4f6fb;
  --surface:#ffffff;
  --surface2:#f1f3f9;
  --border:rgba(15,23,42,0.08);
  --text:#0f172a;
  --text2:#475569;
  --text3:#94a3b8;
  --accent:#6366f1;
  --accent2:#8b5cf6;
  --green:#16a34a;
  --amber:#d97706;
  --blue:#2563eb;
  --red:#dc2626;
  --pink:#db2777;
  --sidebar-w:220px;
}
body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;min-height:100vh;display:flex}

/* ── SIDEBAR ── */
.sidebar{
  width:var(--sidebar-w);
  background:var(--surface);
  border-right:1px solid var(--border);
  display:flex;flex-direction:column;
  position:fixed;top:0;left:0;bottom:0;
  z-index:100;overflow-y:auto;
}
.sidebar-logo{
  padding:20px 18px 16px;
  border-bottom:1px solid var(--border);
  display:flex;align-items:center;justify-content:center;
}
.logo-icon{
  width:36px;height:36px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  border-radius:9px;
  display:flex;align-items:center;justify-content:center;
  font-size:11px;font-weight:700;color:#fff;letter-spacing:-0.3px;
  flex-shrink:0;
}
.logo-text{font-size:15px;font-weight:700;letter-spacing:1.5px;color:var(--text)}
.logo-sub{font-size:9px;letter-spacing:2px;color:var(--text3);margin-top:1px}

.sidebar-user{
  padding:14px 18px;
  border-bottom:1px solid var(--border);
  font-size:12px;
}
.sidebar-user-name{font-weight:600;color:var(--text);margin-bottom:2px}
.sidebar-user-role{
  font-size:10px;letter-spacing:1px;
  color:var(--accent);font-weight:600;
  text-transform:uppercase;
}

.sidebar-nav{flex:1;padding:10px 0}
.nav-section{
  font-size:9px;letter-spacing:2px;
  color:var(--text3);font-weight:600;
  padding:14px 18px 6px;
  text-transform:uppercase;
}
.nav-link{
  display:flex;align-items:center;gap:10px;
  padding:9px 18px;
  font-size:13px;font-weight:500;
  color:var(--text2);
  text-decoration:none;
  transition:all .15s;
  border-left:3px solid transparent;
}
.nav-link:hover{color:var(--text);background:rgba(15,23,42,0.04)}
.nav-link.active{
  color:var(--accent);
  background:rgba(99,102,241,0.08);
  border-left-color:var(--accent);
}
.nav-link .icon{font-size:15px;width:18px;text-align:center}

.sidebar-footer{
  padding:14px 18px;
  border-top:1px solid var(--border);
  font-size:11px;color:var(--text3);
}

/* ── MAIN ── */
.main{margin-left:var(--sidebar-w);flex:1;min-width:0;min-height:100vh;display:flex;flex-direction:column}

/* ── TOPBAR ── */
.topbar{
  background:var(--surface);
  border-bottom:1px solid var(--border);
  padding:14px 28px;
  display:flex;align-items:center;justify-content:space-between;
  position:sticky;top:0;z-index:50;
}
.topbar-title{font-size:16px;font-weight:600;color:var(--text)}
.topbar-right{display:flex;align-items:center;gap:12px}
.live-badge{
  display:flex;align-items:center;gap:6px;
  background:rgba(34,197,94,0.1);
  border:1px solid rgba(34,197,94,0.25);
  border-radius:20px;padding:4px 10px;
  font-size:11px;color:var(--green);font-weight:600;
}
.live-dot{width:6px;height:6px;border-radius:50%;background:var(--green);animation:pulse 2s infinite}

/* ── CONTENT ── */
.content{padding:24px 28px;flex:1;min-width:0}

/* ── FLASH MSG ── */
.flash{
  background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.2);
  border-radius:8px;padding:10px 16px;
  font-size:13px;color:var(--green);margin-bottom:20px;
}

/* ── STAT CARDS ── */
.stats-grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
  gap:16px;margin-bottom:24px;
}
.stat-card{
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:12px;
  padding:20px;
  position:relative;overflow:hidden;
  transition:border-color .2s;
}
.stat-card:hover{border-color:rgba(15,23,42,0.16)}
.stat-card::before{
  content:'';position:absolute;
  top:0;left:0;right:0;height:3px;
  background:var(--card-color,var(--accent));
}
.stat-label{font-size:11px;letter-spacing:1.5px;color:var(--text3);font-weight:600;text-transform:uppercase;margin-bottom:10px}
.stat-value{font-size:28px;font-weight:700;color:var(--text);line-height:1}
.stat-sub{font-size:11px;color:var(--text3);margin-top:6px}

/* ── SECTION HEADER ── */
.section-header{
  display:flex;align-items:center;justify-content:space-between;
  margin-bottom:18px;
}
.section-title{font-size:15px;font-weight:600;color:var(--text)}

/* ── BUTTONS ── */
.btn{
  display:inline-flex;align-items:center;gap:6px;
  padding:8px 16px;border-radius:8px;
  font-size:13px;font-weight:600;
  cursor:pointer;border:none;
  text-decoration:none;transition:opacity .15s;
  font-family:'DM Sans',sans-serif;
}
.btn:hover{opacity:0.85}
.btn-primary{background:linear-gradient(135deg,var(--accent),var(--accent2));color:#fff}
.btn-sm{padding:5px 12px;font-size:12px;border-radius:6px}
.btn-danger{background:rgba(239,68,68,0.15);color:var(--red);border:1px solid rgba(239,68,68,0.2)}
.btn-ghost{background:rgba(15,23,42,0.04);color:var(--text2);border:1px solid var(--border)}
.btn-green{background:rgba(34,197,94,0.15);color:var(--green);border:1px solid rgba(34,197,94,0.2)}
.btn-blue{background:rgba(59,130,246,0.15);color:var(--blue);border:1px solid rgba(59,130,246,0.2)}
.btn-amber{background:rgba(245,158,11,0.15);color:var(--amber);border:1px solid rgba(245,158,11,0.2)}
.btn-red{background:rgba(239,68,68,0.1);color:#ef4444;border:1px solid rgba(239,68,68,0.2)}
.btn-red:hover{background:rgba(239,68,68,0.18)}

/* ── TABLE ── */
.table-wrap{
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:12px;overflow-x:auto;
}
.table-toolbar{
  padding:14px 18px;
  border-bottom:1px solid var(--border);
  display:flex;align-items:center;gap:12px;flex-wrap:wrap;
}
table{width:100%;border-collapse:collapse}
thead th{
  padding:11px 16px;
  font-size:10px;letter-spacing:1.5px;
  color:var(--text3);font-weight:600;
  text-align:left;text-transform:uppercase;
  border-bottom:1px solid var(--border);
  background:var(--surface2);
}
tbody td{
  padding:12px 16px;
  font-size:13px;color:var(--text2);
  border-bottom:1px solid var(--border);
  vertical-align:middle;
}
tbody tr:last-child td{border-bottom:none}
tbody tr:hover td{background:rgba(15,23,42,0.025)}
.td-main{color:var(--text);font-weight:500}
.mono{font-family:'DM Mono',monospace;font-size:12px}

/* ── PILLS ── */
.pill{
  display:inline-flex;align-items:center;gap:4px;
  padding:3px 10px;border-radius:20px;
  font-size:11px;font-weight:600;letter-spacing:0.5px;
}
.pill-green{background:rgba(34,197,94,0.1);color:var(--green);border:1px solid rgba(34,197,94,0.2)}
.pill-amber{background:rgba(245,158,11,0.1);color:var(--amber);border:1px solid rgba(245,158,11,0.2)}
.pill-red{background:rgba(239,68,68,0.1);color:var(--red);border:1px solid rgba(239,68,68,0.2)}
.pill-blue{background:rgba(59,130,246,0.1);color:var(--blue);border:1px solid rgba(59,130,246,0.2)}
.pill-purple{background:rgba(99,102,241,0.1);color:var(--accent);border:1px solid rgba(99,102,241,0.2)}
.pill-gray{background:rgba(15,23,42,0.05);color:var(--text2);border:1px solid var(--border)}

/* ── MODAL ── */
.modal-overlay{
  display:none;position:fixed;inset:0;
  background:rgba(0,0,0,0.7);z-index:200;
  align-items:center;justify-content:center;
}
.modal-overlay.open{display:flex}
.modal{
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:16px;
  padding:28px;width:100%;max-width:560px;
  max-height:90vh;overflow-y:auto;
  position:relative;
}
.modal-title{font-size:16px;font-weight:600;margin-bottom:20px;color:var(--text)}
.modal-close{
  position:absolute;top:20px;right:20px;
  background:none;border:none;color:var(--text3);
  font-size:20px;cursor:pointer;line-height:1;
}
.modal-close:hover{color:var(--text)}

/* ── FORM ── */
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.form-grid.full{grid-template-columns:1fr}
.field{display:flex;flex-direction:column;gap:6px}
.field.span2{grid-column:span 2}
.field label{font-size:11px;font-weight:600;letter-spacing:1px;color:var(--text3);text-transform:uppercase}
.field input,.field select,.field textarea{
  background:var(--bg);border:1px solid var(--border);
  border-radius:8px;padding:9px 12px;
  font-size:13px;color:var(--text);
  font-family:'DM Sans',sans-serif;
  outline:none;transition:border-color .15s;
  width:100%;
}
.field input:focus,.field select:focus,.field textarea:focus{border-color:var(--accent)}
.field textarea{resize:vertical;min-height:80px}
.field select option{background:var(--surface)}

/* ── SEARCH ── */
.search-input{
  background:var(--bg);border:1px solid var(--border);
  border-radius:8px;padding:8px 12px;
  font-size:13px;color:var(--text);
  font-family:'DM Sans',sans-serif;
  outline:none;min-width:200px;
}
.search-input:focus{border-color:var(--accent)}

/* ── URL BOX ── */
.url-box{
  background:var(--bg);border:1px solid var(--border);
  border-radius:8px;padding:10px 14px;
  display:flex;align-items:center;justify-content:space-between;gap:10px;
  margin-bottom:8px;
}
.url-label{font-size:10px;letter-spacing:1px;color:var(--text3);font-weight:600;text-transform:uppercase;margin-bottom:4px}
.url-val{font-family:'DM Mono',monospace;font-size:11px;color:var(--accent);word-break:break-all;flex:1}
.copy-btn{
  background:rgba(99,102,241,0.1);border:1px solid rgba(99,102,241,0.2);
  color:var(--accent);border-radius:6px;padding:4px 10px;
  font-size:11px;font-weight:600;cursor:pointer;white-space:nowrap;
  font-family:'DM Sans',sans-serif;
}
.copy-btn:hover{background:rgba(99,102,241,0.2)}

/* ── CARDS GRID ── */
.cards-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-bottom:24px}
.info-card{
  background:var(--surface);border:1px solid var(--border);
  border-radius:12px;padding:20px;
}
.info-card-title{font-size:11px;letter-spacing:1.5px;color:var(--text3);font-weight:600;text-transform:uppercase;margin-bottom:14px}
.info-row{display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border)}
.info-row:last-child{border-bottom:none}
.info-key{font-size:12px;color:var(--text3)}
.info-val{font-size:13px;color:var(--text);font-weight:500}

/* ── PAGINATION ── */
.pagination{display:flex;gap:6px;margin-top:16px;justify-content:center}
.page-btn{
  background:var(--surface);border:1px solid var(--border);
  border-radius:6px;padding:6px 12px;font-size:13px;color:var(--text2);
  text-decoration:none;transition:all .15s;
}
.page-btn:hover,.page-btn.active{background:var(--accent);color:#fff;border-color:var(--accent)}

@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}

/* ── RESPONSIVE ── */
@media(max-width:768px){
  .sidebar{width:100%;height:auto;position:relative;flex-direction:row;flex-wrap:wrap}
  .main{margin-left:0}
  .form-grid{grid-template-columns:1fr}
  .field.span2{grid-column:span 1}
}
</style>
</head>
<body>

<!-- SIDEBAR -->
<aside class="sidebar">
  <div class="sidebar-logo">
    <img src="data:image/webp;base64,UklGRjgkAABXRUJQVlA4ICwkAACQewCdASpoAZYAPjEWiUMiISEUul3gIAMEpu3V7xo/+i7HuY/KX6n+2+k/yL1xec/EfB81t5Y/lf63/rP6x/cf2Q+d3/E/4H9V93X9e/YD8//oH/ST/W/1Lry+YL+k/3j/wf5/3Uv9n+p3vL/Xn9h/8t8gH9D/yH/o9p7/ueyl6Bv7seml+1fwp/1T/c/tN7QH/51i3y//Wfx38KP65/Y/2Z/cr2J/F/nn6r+R37z9J3pv/nehv8Y+sX2T+7/tF/dv2Y+ZP8h+I/5Fe6fx8/fvUC/E/5B/b/7R+yX9Y/afkgNf8wX2J+gf4T/A/uF/a/TN/svQz64/5/7hvsA/jv9D/w35rf5j///W3/A8Gj7p/tf2F+AH+R/1T/T/3/++/sl9MH8t/y/8b+Vntc/Lv8B/yf8t/nv20+wn+Pf0j/Yf3H/K/9//Nf///6/dD7IPRG/Y//5n3z2Y/7aEzAA2RbsXdH/ZxuOpd4lEdNn//CCFNr+hrgR6p6NLgfzbHml+kjxL0/TYaYINZ9YN8GJu7QyuGdLUicNFGHzWPK781wI9R1aWjrpMPQgx12SBbTSPEJp0/zTAZBoElRIKfcRlgJ5wKuyBwCMfvnQBR9owumKbBAenoiaxGsstQg0+Q2tC3Z2NkRR4VVdXfF1kTDAaEFV7/hARJU8votWZTmz1S7+fmLIcpFdVH6QLdWtVfZSNR2LbK4SOTFHnaajXy/PIjklbcWyPn6uvd45vwWa+eqFzh7T3q2YkuWGhJ82fefSr2MoZCbSX2jxNdjPuS+hcO292fbjnUI3mJb3zbDEVn0y5xhIDqG7bCp5W6sy810ilMTfl8R/BTZBE5P3vuA9swCXKWRBJr5Ui2Xzq4b20c9dMk/bXa3Iz8nMiywjZZtP1PAPvJeIk2jfSAhboUua0VXMZ7s9bd71w/WgZ3NQBc95vZU+OHw1ohrqNhrVft+8BgFfkQqlq2d+z1phtAcVo1MH0JLup2ECb90BRbAMGPUU2haUNhzN3b67NAa7zBVkf9i38Tzp6K9YokZa6RiNY6ozPnEKfsb9QI+h64T74v7Gs9EdX8mym3eEZeJZ7fTTUix8idpBZ+HaGJ8VWp6RRVKbIAFjEB826S4LI9MP23FAHByR5l7IUP3sUNda1JzEammrJ/wJJt1H+3T3NmQMnaeNKJo1ekvDT5leSuAbMvhRy3fCnCQDfJSsSceONlfvxcaP/kcn522d00lGuj/ylYINzCB/OfAPJ2+cAyuETpaGNvQaNT3UaxXRI/1FT8ifW34Ivt34ddkoCZvYxlOSvr3ksgztKWY2seXbcqmpSsrvzXAj1T0UgAP7+3XoxAYBMjmU8lWHODUejfcRyFLqF6yY3xPaJEb9WNJsLuIRineoX3PE7cDnXnYgHQl5ygHf/zK2YRka/9OeAxpLIMyQNSa7LEk4ChWhdlhoNUMeX5r5Ln3Nu2+7UzhEnsfeWofB9Cz2EtppHJ63NPRbkwjFtJInA8Aj6fvvYKkkkdpf/86+rJWUt4Z80UOEMcGqU9bZIgA7E5H94kd6RGSKYZWXwOcikuvGDhsjMQID3io7/XjbMAAACTPJXteq/8f++EVTUTl7iNFRjP8+xh0DxCoUsc06X1xR+qFnMDD/rNa/535sc/2B4Ycr2lf5eroC7DTMRNBM11TOWzuD7gseoyUvb0aNTe0F2uodvaSQlL9Zm2Tkzm35wxey6sxm8c+QEEjjUkXIo6/gMAeAn4liSZmWISKbZE9lWamCmtg97h1u59wnf8oCcrXf3/8zlj/93lM5xTHnc/2gkc/cc/x66Ox8jdONsnQhV/M02SHGmUnONH+oiqej0nb/X8YK0hbsj/AjsfizuiIpKCgwVssWmxc3WfyMkbq81kbOn1CJZlttEHnbuunfy/TAApxfciSd6uaZg7cSGP2qAPif/2Uh+dNkg3occk/2OKYWPtpgbTN08ssrc3K0H6ERfGcZfa+CMAvn2KqMLNPnQwbxBYFDVCP8UgdCkQ/AAACYXgsJWf/5sATVg3L2zCP69WPfGnQYFgyAABxNDy/NppR8yDiKUV1sEPALMRNIxQ/tpkTzglz2HIf2SJo7psRtnpt5GoSQDym0Dy5n5TQF4o+xA2bYlbdc7++euhkNgzEqngZOni+LtJpE8Qd50GydZEpg01AYcGdT6mAIafoM9EsS7kn3ddtr8bFjFPZ/urtGysMO3/2JTMPlkCjDlLikLtSIKjy8t99QF66T5f+UAvDD0/qhpMiNEzlVGWIBLbA7oRZ3aGI/2/vrEw16LrJav2KHc45yP+Upyu8sRfAzPIGG7dI6J7csicLSlvumZNHIl5e7mIYwguf2Qg0OHjWJ5aSafEck2vN4fsbt/MDRyAhVSYdcoLLdWPfQiSR/1+uIUih0Kj45/n7daS42jIFUp5jzg3NIKH9phV97mjbJRzdj/Kk2rGBpQaiRUMMkVNkF1IikIT4uR76Iim4pNufanXvQ5lgHreQX3Pbp6wqqvQRFowjL9gkXpR6bIZj8ITvmZtvlb0hIxgzeP9+M8xwFUgy6Siuef/j/CHbZM40QABLokYCP8jHMZPZkYETSYQsuaIoNelG2+7TaKYUV9YF66/4Soqo5mBtZFic1XoB3FPebUiveJziOkXYPdOpT7MDHVtbKeUJMsJpnf5QWDCL3wEhEdq3fUPw8JPHnMMzPXCjUFQszDqh6SRXwFIWS8cXsRuSrYCJihpz7r1JpxWWtM0e06Ti+21aCDu+TQ45qL0N7kzYGLOPPCh8dcm1DsSIeaN3NHQ0QSu2CG7pbfNqB4DE8wv9E2hgHb9CvHLEtHeLOHO4Xllrj6wstGh4cxdfVsZjuDDauW2v5Hq3X8HO01XA5E0H9KSNpiLmckJoNPjExCStCR2pfy9AJiVDgfx4AcYSYjXNxCZJFbpBtYm6FB2W8BK30VI4bne4g36u9JNceGSwcxZ5kRhs++IpeFzLl/8BdEIYgaLyQNfxOlEjI4rtc7OINDH1M6ei7Of2Os1nRjTliFrEYXPGoxs3CTAton6bgezvPm8zuFU2n7ZQQLJlLriBF8Z2YiMwHmIjYUV90J9BrdVbDP8W1OGImXSwbHmO4w5d3cf2jp/Gm0I+vcJy6MGw/I8Cu1FBI5utnT8zzv3ugEAIDFoaESLAgP4FssIXhZAGLUTbSvPNBd5dlGXEN3HV2xAh4VIt8nVC7UENV4kYR/VSch410xmvSthnXpMQNG9YoiSksEKKgDiWuGWiNIJ6SUOOMzxyENe4yqwJHWZVEinRsfRV60sguCvf6QErdWeW2AxnSNTTI9alurrQkNbybrx6/7NTq2ZgSZgUGp8iNWA77R0O1ygCOd5W5F2CrMolaYlLTkV6tmGKRT40X6iay8smsmIfOL61Pf/QrIALYchLn2GSaf37AADeu+EfbnOCE42lZcpS5UXjkzdpgPhLJcnMNhOM4cZzgVWWTc5idHg5Rqlfu+VAHuSsDa+ZJD7L9U8Dr0OO/m1tI2/ducw6+bhdOvB3NCNmMLkRZCNBWTfkVvlb1Zkw75KdGld6UAp1mSyWXfD/zjS8n1n9lJkC/ZUgcf8k1LNIhrI5J3rU/PSDMF9FpadrpLfrcHp9IhsZVkfSW5dMXnw6/N/99zFrKaJanakwnEo4tivaUnXmNAf/xKDOGGVyzNkCfBGMdAzg6YhscK1uVk7pCn4dMzWuGeIaUv4lRC8CPJKCvKzpHFYQYLDZLrOf1K1JSo1jwT+V8tjflt3Y7K07NgvBo4eL137jVXVYTijXslCXbGgcOFUEoF6jLn+f3askte79y7hf40l3ss/Kt4DEYD/HNT61pDGxnpCBtm/SHI0i1UsyUEs8eYE4TsxhS4LUkcRctd1hBTrscqjMa1ryev+dV8BgIBh8CHJfXkCo+8chPxTMG8nPZfxQS8DKJ6+XNtK4q2eJA0DgyH4fKqUxgjDLO/VrsN4WVNVUdu5Ctn9NIojYJ9RoEZ6xcq+Sc6Y84NNhTib3nrI5C8c2W/FoV1fpTYFlaU15WfjC3mzqV2NRdfFknEobKwBhgIhT49B6f8T2BgO5nJDIzTAnBV/GDAmsuf/nSwPMaWAQcKES7meIzV9Zw6f4NpivTqEv5BM0UCc0CtQ3MU3ALP633RMAlnABo8Ot/QChZ6qQaawtxAsyM7GLcbzVdIFkKxqDfHjL+H9FBvaQwxJXPPllM8I+sfL9lMx1vTwK2bvSSGBEHk8Nnz3/xjQHuQ6X78s07ivlpMGiRg/A4R2eUDxBTeuwvErJhS0Do9qZARvsp7vCc09zzgkZzIQ3T+9ZE/QDgnl0lyuc8+AEwfF8TKgbwWUnD06D0PP+tkdpWkgORx7yC2OyYKcpc65A1VEkmrr/5hh5bb/OAtpx0WeywVDKcZmVR1cuqkez7ZdPJMMjtQTSeJ7Mh0+mTcCz4LoKaSxZTXKLdQLIOdGaVmVJi1olJFhmlDItkknlWDVJT3yoYls+sACwaJokbSVeD5VpDwgRHZolkkLWlhaJligt3YaaQkrEn9+V5TiriuxbsxmQsIlz2PtsaaI/JMSkBwRVrSMMffUR6iPxUAT52IUGktzVHcVAQGACJnnpKVOOV+4AwhMOvXmImPjuTvXzxDnJZqzSI3kR5BkKgGKarUM9nspfj/BUg63V6lpRcQaa2SYYMHR2XREbQ3v2WstBAFev79BI+R39cq6vsbN/ul4PvV/tkDD5zKXN0B74EXKUtf07n8u9QW4m2VVs+7VHoXn1XnvVU3sN7GFYZEUl9HfVQXspW8VidgkZRAnZNc2dx7lI+pQ3SCv0v3XzyqwrIv0bikfoFb+NqK3Zws9mesrpKTyatUMFZYwg5AqQKIT6cnSUhtQG/x/no6M6RB6c5FD+ceN2695B3aLpvCquF50kiqIXTbeDM5UNTa403K0rWJJZjJMjYbvLDwUER0EiEEtzZo6zZti4XgvZs/YR3fQDqWuvMzF7opqzepsGgnCdFH3zoCeGUqyb7RtbKtpBb1pIVKVIu2l7aFiE72J7gAzYa/5lJEfta44lCtdDLfI5Rfrw5cn/PnGWO63gw3GE8dQpQR5VsxXY6SxOaZY2Y41ecqhN1vThqERc56hTUdzMDs5epFialuChGW7qREptkAQfQIQkaTWqO2irIe1y3HEhSxVxFXhR3Xd7esXwuY+eHJoG54GHrad/ZJQu+ibEp0U8/WSjoiJ1sysRPLq7fJmzCOHsrkLGTwBNhXzbl8KfZ+Ov48yEWcR6hOWWzAFdxNF9fSzKw7nOjR7pWENq7JRdM6G2iOoXseUcNsnFLRVQYxGUucQROowRRJb1ECL5Zc48TjF9BNM55ABobF2NMz3ETWTFh3jc12yRK6h/VgibqQMQEeDMXaClW782fv6DvgTMEsgpSc5Mtm6PoSIVpaHPA9+idLKa6Q12SytVRTNqwSrT2W+N1oMfO0nxqORs/ceYD+X8ww/rGgq7I8ELtkfUDkoHcbkRDpKqHigI1glxrIALgVir7Na0MDexxGe3kEK4TSZbQi3e4gjaPW2OLhW1zOZixLltA4msAF1uoJn0dGRyvRnBoS2HB1Q1xTuYNpYi+y8ipuJcTD9UMaFheJoQNzkgh8jiHbuy5Eub+qtTGwN/NNLxqMxvYe7ccl6AsoGCRADwmhxOx23nFc22YxWvEkebjyQxboc6NoMFyCeqYZpS6zGgZGFzIOB4slts2g/sUdLybs2pRnzkzpzYktjhWqrCMeAm03hPa59u2ZvmDKEVJpgtB1jLQYT4IG8MWMZgLeXbb7SlD2s2sIjE+/UvMn88yBrgGOIKyM9PGCna9JeKmrutvlJzMxKID/Opfmiz3LVjg//BvBFqU/w0gm+iUoGfnHXi3ahzWvn6dBRSV/qsUl/kgSgDQmpI9Pj5A6gXQMBjezHzKZlFqxn22ng3GtEkNregpOOV8D8g/z4PZVrTDf1DKJg+w/oA3U572a19C0C5+Y5snjZCUAzowW1oQLTM+jpai3nzpWT3v4xEFhNCbZV2S69FZ02nMvs3ygudK99Em8QMtmZgdmWbSF5LzfBtHUtwha/6OK5oF6dgL5m5KD/yxxZ82NDViWoBgkmNFqlOtPAJc5Z1H9G0vHLGiEYWquOfan841B7Ddgjb50Odf139+ETYoewVW89kDC86EGgxz98AOZU1Aj8P3Dci+hipidq5Wqadjud+Pqe0/61WHz3bP61RNHwarlN5cdWZioDZeldQwXgmcz4RdZi1sW6/RrCDZUYFJZxaBAMe3j+zMgDrV3iVfNi30TjvQ1v5+KazwP8KBh2Som2cJWiw6HBMAJx0vZ1vnwZhqkN9xUXCx1S/ROmQ6feUeyzNAVMYnaIAr2jMAudRI2CouZFIm6I3fInuXwdbFS38cGQ0fRLyaWzF3bcyrnswh6rDKPF6g6kGllt5iuX09nEP5/CsUTxraDtG4nNPCzS5BkP6iqq+Zx6dkgUAzUVa0t4HQbnz8QOf5B0S+VpItZsQo4NhsuYUZMA+VskQwFLqipJqoRzudOgbVlvR+DTVGQlH0KWUKUG0ILfSiWPfI+f7EWY+Kk+SpGhu4ufQ8Xkn/ZDqc52A2uVEazlYWi0B0+IgfdRAwSfJOOwmcpiGpoBIrexDphqOQdDV4p2j0BfXPuO9RQl4DCscD1Mwln1Olp9Nr7mARM7buEY27sPonMdvPzqtBv1UAPVBIPa40YrSKyuinn5p8QKyVzSqSg3+Le0rrTwmZ4roKmrpiCiy7FymvxmnslR5V7mWySGEtyg6aABZGDUIjMjL0M4uePsOLItXXRZeOk7Sp2lAKRQDdJLJkYGgvN6Q8hexzGH95i/KmHB0oJEQyxK8zTUGTa9GKCDCmqac5+8G1VXlaq9AkR5dEOVqIkLj9xHshh0/uiPr/uflbNZGeskSEMZFymFO16bUfLegEWPWxrvHB7o/bb7l+HWJxyxXB8+c0CfEzRBowJVDdDuXB6pTlLvnXCGQbxlOMPWpvH17c8bz09x5Pnc2z1d73lBCP6ANYiAq6FVpKWj1+6ocaAoYTycu1aanw7xphRG14p/zGyUKWPGonel1rjUYbYuGBugNH8fACv5CEt9xxUDuWLcEab8MXR5EpeXom/oVFzkiUUW80zzYwWJEWkLpw4Dg99pLkkKX+RrvYNCjdGnyO6JnA7yHRDv4xzJQDpHhKN0XuOyT5/3EZSzm6XSjv72GO/zM7AAbjh9uevuzpZbnYo9ADMi8y2TYhEt7zHEc+z7YQq7T37ZU6V+tetYvIqeSOLSfw9VMLS/i38RCdWxwOiO4ZTBB8/uodcldf1sVGezLjIOQTTitn7BYHPBEq/EwU7VnwzENmTwsJdDTFDympB5r9+quV0VjR4UAK2AwpGUTrfJyW+Meu8KhBKudQsdqqbYRtF1iqJOCoRyjXUVMCgmsogDvbu+vcI1l0xzs9Ne9SUGQjcgB366yOhl+iwplk7tzOeA4zzsW3ttYoYixC275clnYP0NXMhSeEVnKggOzN25F3tZFYkxeOKk+MiMLMV0/OXPYuEbzo69zg0/birRldEJTaPoWf+mG97kckbt/TWsc01Uvc5Tw53wY6YCukai0G3OPJTz+leZgPfMjJ74Er4418BfuLs+XKOnz9YUv7KmbKpcZA0RONoFBlypj3i4QNcoEBs36aeAoFe9OAuroeQflrXa66VSDltawbJXXnwJ/SLDCBL4iCmEyj/rurac8PIWSN8qjgmxLjd8gRGT3p6UwSmjR5cmjW8aKVdck2O9ivBfAYXhyRxfffVK5CW6g56IagSaZe1oDY5moBntHZUIMZyc/ZehUFOY1OOAelTs3msl3vWzso/BMbvhNPgoEjnWxJXrxTHVxML9NHvgT2p4LBjwy9Q4CJH5KbnZndH8hNSfad0Y0ThyqQ90m3PO45uc2VZrod9yxdTDVef6cvzXtFEivf5lkVzw3ns7TbXfgpPSgfOxpUgW45f9v2aEqnYrlq0jFFlMcvdqCo3j8N8rVmJafwIHbxo7gyAIQuNKxXNaf0kNJv50y1AQ6j1pC6klnMmdSFoGIm8Yisp6Y1nq8MMNdlFONqU3SDDnqh662qJBOr7/TvE06Px4AUB1eieGnCoAgmIur65TFs8AAAAAFYK+pPadtpqlRzVi4MbSE+mj1/3iGIIRqF8TEPG1AsqG7cEiko63Nkp2nbWLMuN8cL1UZGj8jVlDG7+WRfPTas2eMtlfZUr2K7xXz41G+3Zbg/e6DtzQeUNpezFaOEIfZYmNbLGxMScsn6IDm8rQQwbyhNNgdcOVg1AS/qIgikSTFoqZ4M6/JI5gwfn+FeLNS/HHHJFcR3lNAeeOl33ToUkdNCDKsMzLk3ZJwXWEoGJg5qhotCAgigPrsPJfFDjZCs6cvm4QWyg6xBAYxEJxzVQpBW8DZ8OYzP8Qv3/RMTxmYQlh5vB/XmZCLz6azWw/PEjqC8vuJiN7kLjfiPhhEME6YnXOgwQVDPrU7VG79C85hygrhrLP1nqIx2jKK+xc8ZtDebPBkrEj9ki+eYtzPaJIP4oHGQSdFN7HP3PpqEQaCW/61lFxk/QGjobqKwJniCQPc5gqrm746K+9tSOZs5GuEf7JRaThgVjhSKPOZ1tKgXuRDtxZlESi4YkzCxYWkT+Nc2ur5y9qiJ6pUHRCi8aNZtlV10he9wkCDPg3wcwbnH3wJhbyBoFlKufce+xX0VXpVhVeFiX0cJc/gnok/3CcgN/WzVZ45fQ76iXIA8qGnnapyMeE3lz/elrGLxGvSkykIEZQDaz2pXTxYhMrkxMTFAIWU+nV3JC1UPfWZABl+hiby6VNavvBmzHfK74by4sTMbSib8q1ZIG1UwTd/8pa4J+5BBQaTeioh3oe488AjjQMLxB6qpj3Wykf3bLN4ZWJQfzXudKOcKV51reTVr5eWFagTNLPEuxwyp8Zh0OgTNRzm7/j0RuSna6H/2uVXbm7Nlu36gI7+j/diWJ/iNtZrJtzO/cO/pOTscnJt5NlBXX5/4RTFjwGZDEqioAMBm3Of8a8zuY8661GmcDlyEpG3Lnn3i77OkJPdHL34tDCKq7G+Ydrb+Idmk8dj9i0oLIW/AF7fIQZizNxHnscQY3QbXD7VVbjo63jY3AnY+FiKbMoBuLsIQWH3x9Atexl6ADGhY+2zZt+nGk1JBKj6n5JPAgxst7Rh59UWOW6s8MWY806D4ofzUwwDp3vCmUepEE/mL3nqi7pEXHT5h94904OuuLzNceijrCeCkIfR051JBo0AXxppqdZ0FWRlhxc9H11ojTIqccxpuc0tYSMCHjgYtsZImNb3gX9gJF3O381tyQvMPS8yRL7InjOXzEZ7DNsCCs57OL7/VdK4HFlWvXqnEZP2CNtdCVkovjxyD6hUlJAQqxPO/gaccYSwVQipU875nGC15B18DgGaVuDgYYFpdRcr0uRk98GRns50XbzHD+JAJO1yq8V5aUm1BpEpcYqJ9Q5xeuCyV51je/C41k2Q6vUUBf9jLd6mUt+JYHBJeTXfaPBmPzyoErUmuB4IhHCsc2qJAY9/fVo1Ovl6Da1aBLdrO2LKq8SdL6NOcgU2OQZ0N0ZOQyFcQlDN5UAiAk+gNcg3O8bdJsYxgylZdC4EscQ2SfzXlz0PLL+WcypAdH5Pc2a27NsHCrjVC8Wy8A9feMl6cq5HBV6xC/XKT8AwFy1mOGGhswNFNejKMPzItn8kuyOn1HZjd4f7sTotc+BSwsG+v44ELulRF+D5m3xsH8qDaI+YS6EkqGCBEgvRo0Dobb5t+QaME6nAqdLhKMgfpDWMbM4/jVAttaOUcBY10sJCnEShlzBLsI0cJmsetv1+Ru/UGfFqnk3UuYt72eVjzX1A45uWHED0wleDd4jkTLBPAAMhYrQKWncPfTupCI1SBX8PXFZj6KZJ31SED3cDrg/7FetntfPHOZJjhYH2DbpKmj//pgajKnORTd0HyxrvFd8YmQS+cIlqmSD/Nint6AbmrKT4CenBrwiokguXyt1B5ZKY9bg6YQt+dT76jNa2+gk2NlxeyExveY1j/PM+r+12aNLSr7j8bmJY1pXmEZF+7XiUCv5X+JeHG+6PaUyNv2dPsIgg8BE5BdiWopSraskpbz6M2MZQrMDYChxySZTVYHVSEuaIKf9GqAnVRVd3dOA8DN2Ob9pSkmiBzDkGhH4DUHlch215JZlOVEcaweWNzTyMc8PkCMfhkxQ1H0VMnRdYAcPSSILbWQRiBTqKuiKWWiEcf+MfJvHuB4HXV472RAe+1hGwKWZmkaPcAFFRAmHXtk7Wd1S1UseMf3C8VfSkfzZQGhOEDDfE2dOYFOrVDHk95NlXm8p1ik5MuuJLlVFCwTaW+eD6IfQxgnpfL4g1sYti9NmSR7Ckq6qD1JJ03t0z/nUEqKMYQKGECb1gFuSwOfPHNUkDcsRrLbVQv2EQPz7rDREvQ/pyt0TUL3SHjwyo2oc4fCBeFTNEjSd4+JZ87X5UXPXtgerXszLLh9X43GSXdpsSEKbas0+pt7Pbe4BSn/FI+bVnsrHE9RXU4MXDrWPqAqIi0YI0F3h3rdOC1Dx2BKz0wtUoPSNuM7CWIadk0WL1CNtC+FfJuP9miegiwO3VxetNPaYNWkP2ckZ1JA87GmdbI3WShRkmTk1EtMtPwWEpK8d08l+fW0W4BY6dZPId+1969FbnC2tDGAWI7PrZGFWclCMrs9pxlyoavInOaXLvb/3JbUC4YkPz1f5fnOompI5K0PtgNKL/xPbjq58aeUIxuyzsasAz2kvGUxPtwpFkYOR8lmpFeMOBy3bxVOutnNGz++XhdeLHaa8Rf1sFNHPnv+Uxt3qneEUR2bYozwBcHsdMsZacLR/KvzuV6s1ZzFJOSILoPzt3kJYzpWrrh3mrUDoLCUddg8c05jyAoMXOTjwfqHsQGTeH30dLiiDcx2QYy/2jlrQpGouBCq0O9l6rGn91ZaEdY+RJDnKvVme/DX93YuiDgggx9SGxwvgnBXqJ3CpAKKYn9HqnRxjqgDEjZzLUcfudUXgKMXcYDhH170FIx1t2CH495Ajm/XU5Y5Lk2UzkP7wkXqVOW5W6i0IIWy61E3J0wAip74n01kM48lxvQmwqVTS0cTHXYuBbep1lGjvnRBOUvmSslPEXiCc8K2V9Dbvd04+sbDcu82/jxep4Ad2H3Yp2fXOzz+piDP952GgkgjrLAc3tx+tixJn15574saBbYlmxbT0oY35L/b/6DRV7mshWbeqIb0PaQK8+TY1z1Sc0DbveLbGB42IxDddIFiax147bQrNSInT1ezLjrFKsV+Yvn8YEpED1Oj1Ci0WcGiCVOrivpFp4B9RploEByIxvePZDK2U4A3yIcPH8JwGC2mddTnKu23Ol13TKi4ZX4BQMOcbDdmRr5sqkTp/s5OjExgQ0YM/aYjFFGf4sGZoF0u1SWgL5j1+EpGFJZXQOWbElHw9JJp/5adX8v7kkudUheU9XfJNLl5N7loHCoHmdzpmYNjSbO3ofM+XaMkJqcFO3j5iiaL0B9ZjDSQ3FayZ2zFojhgaEw6I3wNWwgailNzUh8FCJHX1hSXhtTZ3cEPz8krqH7AUy7lP4Yh8hY/ShX+51JL/NiWOoEbuJ8NIn315HKtb1IcAIzJojS3bFJdMEGCHRYXf/uZnReKVs8o9UzVO5sJPTFXxbiC7B4R0i8Rn94NIot54HjPcfnB4nWphGQIZjFt+5L3uyj5MDVQbGzwUIBG0O27zlR08J4uh5GaBS5O1ivwQwfO4YZxQnX9a8ZnJUfoqve/Chluuo0wg2J8rDOY7ELecnN4Gi/rscbbHhYhF8nfQHfTb6LcfKuWFgCRFrDcPdzTK4ADPdF1maLeV0keDep+l5aA35dFrskmb/WtPu8xT7t2YSOIsT5t7rbVHP9Yv7byCSeSeUBTke5zGGm86SBAH461AjXieb9QD8UHI64I2HkpbFFa4NMvKHd5PAuAvnVy3vAQlfy0hmH3F4OfHNrcuottJAyZWw/ULR3hWhxGmMBAz6F4xiDDXLIQAz7UGQUPH6gaxfDya4nWdO0F4O8oCm8/d06FDX8qBrkGl4pLJMO6IfoCZAYftWWIlWmohE+QzUjkSeSsnXm9U9053b4KVXgYPeatuZK3Z5YZnSne+Mg4Sv7YB2RznqWJraJGYGf1KUbgHWSWX7thaxZPb/kYUE8E6w21n+FmMzS/ExQEbzPnKyHu6R62UQQB9A8Nrx6LnDNFxOS//bknkwigcGDUA/KnxM2w6NYXPgVzkoixwX1Io7Nw8OMtFzkGJTh8VBHhAXVFVIxqY1RkvK9hj0UN4RPuAAAAAAAAAAAAAA==" alt="Matrix World Research" style="width:100%;max-width:170px;height:auto;display:block">
  </div>
  <div class="sidebar-user">
    <div class="sidebar-user-name"><?= htmlspecialchars($aQAxJH["\x6e\x61\x6d\x65"]) ?></div>
    <div class="sidebar-user-role"><?= htmlspecialchars($aQAxJH["\x72\x6f\x6c\x65"]) ?></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section">Main</div>
    <a href="?page=dashboard" class="nav-link <?= $G82gPq==="\x64\x61\x73\x68\x62\x6f\x61\x72\x64"?"\x61\x63\x74\x69\x76\x65":"" ?>">
      <span class="icon">📊</span> Dashboard
    </a>
    <a href="?page=projects" class="nav-link <?= in_array($G82gPq,["\x70\x72\x6f\x6a\x65\x63\x74\x73","\x70\x72\x6f\x6a\x65\x63\x74\x5f\x76\x69\x65\x77"])?"\x61\x63\x74\x69\x76\x65":"" ?>">
      <span class="icon">📁</span> Projects
    </a>
    <a href="?page=leads" class="nav-link <?= $G82gPq==="\x6c\x65\x61\x64\x73"?"\x61\x63\x74\x69\x76\x65":"" ?>">
      <span class="icon">📋</span> Leads
    </a>
    <div class="nav-section">Management</div>
    <a href="?page=clients" class="nav-link <?= $G82gPq==="\x63\x6c\x69\x65\x6e\x74\x73"?"\x61\x63\x74\x69\x76\x65":"" ?>">
      <span class="icon">🏢</span> Clients
    </a>
    <a href="?page=vendors" class="nav-link <?= in_array($G82gPq,["\x76\x65\x6e\x64\x6f\x72\x73","\x76\x65\x6e\x64\x6f\x72\x5f\x76\x69\x65\x77"])?"\x61\x63\x74\x69\x76\x65":"" ?>">
      <span class="icon">🤝</span> Vendors
    </a>
    <div class="nav-section">Account</div>
    <a href="?page=notes" class="nav-link <?= $G82gPq==="\x6e\x6f\x74\x65\x73"?"\x61\x63\x74\x69\x76\x65":"" ?>">
      <span class="icon">📝</span> Notes
    </a>
    <a href="?page=change_password" class="nav-link <?= $G82gPq==="\x63\x68\x61\x6e\x67\x65\x5f\x70\x61\x73\x73\x77\x6f\x72\x64"?"\x61\x63\x74\x69\x76\x65":"" ?>">
      <span class="icon">🔑</span> Change Password
    </a>
  </nav>
  <div class="sidebar-footer">
    <a href="?page=logout" style="color:var(--red);text-decoration:none;font-size:12px">⏻ Logout</a>
  </div>
</aside>

<!-- MAIN -->
<div class="main">

  <!-- TOPBAR -->
  <div class="topbar">
    <div class="topbar-title">
      <?php
      $ydkYw9 = ["\x64\x61\x73\x68\x62\x6f\x61\x72\x64"=>"\x44\x61\x73\x68\x62\x6f\x61\x72\x64","\x70\x72\x6f\x6a\x65\x63\x74\x73"=>"\x50\x72\x6f\x6a\x65\x63\x74\x73","\x70\x72\x6f\x6a\x65\x63\x74\x5f\x76\x69\x65\x77"=>"\x50\x72\x6f\x6a\x65\x63\x74\x20\x44\x65\x74\x61\x69\x6c\x73","\x63\x6c\x69\x65\x6e\x74\x73"=>"\x43\x6c\x69\x65\x6e\x74\x73","\x76\x65\x6e\x64\x6f\x72\x73"=>"\x56\x65\x6e\x64\x6f\x72\x73","\x76\x65\x6e\x64\x6f\x72\x5f\x76\x69\x65\x77"=>"\x56\x65\x6e\x64\x6f\x72\x20\x44\x65\x74\x61\x69\x6c\x73","\x6c\x65\x61\x64\x73"=>"\x4c\x65\x61\x64\x73","\x6e\x6f\x74\x65\x73"=>"\x4e\x6f\x74\x65\x73","\x63\x68\x61\x6e\x67\x65\x5f\x70\x61\x73\x73\x77\x6f\x72\x64"=>"\x43\x68\x61\x6e\x67\x65\x20\x50\x61\x73\x73\x77\x6f\x72\x64"];
      echo $ydkYw9[$G82gPq] ?? "\x44\x61\x73\x68\x62\x6f\x61\x72\x64";
      ?>
    </div>
    <div class="topbar-right">
      <div class="live-badge"><div class="live-dot"></div> LIVE</div>
    </div>
  </div>

  <!-- CONTENT -->
  <div class="content">

  <?php if ($G82gPq === "\x64\x61\x73\x68\x62\x6f\x61\x72\x64"): ?>
  <script>
  setTimeout(() => window.location.reload(), 60000);
  </script>
  <div style="font-size:11px;color:var(--text3);margin-bottom:16px;text-align:right">
    🔄 Auto-refresh: 60s &nbsp;|&nbsp; Updated: <?= date("\x48\x3a\x69\x3a\x73") ?> IST
  </div>
  <?php endif; ?>

  <?php if ($v6hO9g): ?>
  <div class="flash">✓ <?= htmlspecialchars($v6hO9g) ?></div>
  <?php endif; ?>

  <?php

  
  
  
  if ($G82gPq === "\x64\x61\x73\x68\x62\x6f\x61\x72\x64"):
  ?>
  <div class="stats-grid">
    <div class="stat-card" style="--card-color:#6366f1">
      <div class="stat-label">Total Clicks</div>
      <div class="stat-value"><?= number_format($l81bu4["\x74\x6f\x74\x61\x6c\x5f\x63\x6c\x69\x63\x6b\x73"]) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#22c55e">
      <div class="stat-label">Completes</div>
      <div class="stat-value"><?= number_format($l81bu4["\x74\x6f\x74\x61\x6c\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x73"]) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#f59e0b">
      <div class="stat-label">Terminates</div>
      <div class="stat-value"><?= number_format($l81bu4["\x74\x6f\x74\x61\x6c\x5f\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x73"]) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#3b82f6">
      <div class="stat-label">Active Projects</div>
      <div class="stat-value"><?= number_format($l81bu4["\x61\x63\x74\x69\x76\x65\x5f\x70\x72\x6f\x6a\x65\x63\x74\x73"]) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#ec4899">
      <div class="stat-label">Active Vendors</div>
      <div class="stat-value"><?= number_format($l81bu4["\x61\x63\x74\x69\x76\x65\x5f\x76\x65\x6e\x64\x6f\x72\x73"]) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#8b5cf6">
      <div class="stat-label">Clients</div>
      <div class="stat-value"><?= number_format($l81bu4["\x74\x6f\x74\x61\x6c\x5f\x63\x6c\x69\x65\x6e\x74\x73"]) ?></div>
    </div>
  </div>

  <?php endif; ?>

  <?php
  
  
  
  if ($G82gPq === "\x70\x72\x6f\x6a\x65\x63\x74\x73"):
  ?>
  <div class="section-header">
    <div class="section-title">All Projects (<?= count($cQoAhS) ?>)</div>
    <?php if (rp_is_manager()): ?>
    <button class="btn btn-primary" onclick="openModal('modalProject',{})">+ Add Project</button>
    <?php endif; ?>
  </div>

  <form method="GET" style="display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap">
    <input type="hidden" name="page" value="projects">
    <input class="search-input" type="text" name="psearch" placeholder="Search project, SID or client..." value="<?= htmlspecialchars($_GET["\x70\x73\x65\x61\x72\x63\x68"]??"") ?>">
    <button type="submit" class="btn btn-primary btn-sm">Search</button>
    <?php if (!empty($_GET["\x70\x73\x65\x61\x72\x63\x68"])): ?>
    <a href="?page=projects" class="btn btn-ghost btn-sm">Clear</a>
    <?php endif; ?>
  </form>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th><th>Project</th><th>Client</th><th>CPI</th><th>IR%</th><th>LOI</th><th>Completes</th><th>Conv%</th><th>Status</th><th>Type</th><th>Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($cQoAhS as $GqmAku => $xBa1v_):
        $n_nSdE = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73\x20\x57\x48\x45\x52\x45\x20\x73\x69\x64\x3d\x3f\x20\x41\x4e\x44\x20\x73\x74\x61\x74\x75\x73\x3d\x27\x63\x6f\x6d\x70\x6c\x65\x74\x65\x27");
        $n_nSdE->execute([$xBa1v_["\x73\x69\x64"]]); $BeGlbB = $n_nSdE->fetchColumn();
        $RqfoN6 = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73\x20\x57\x48\x45\x52\x45\x20\x73\x69\x64\x3d\x3f");
        $RqfoN6->execute([$xBa1v_["\x73\x69\x64"]]); $rKf2jC = $RqfoN6->fetchColumn();
      ?>
        <tr>
          <td><?= $GqmAku+1 ?></td>
          <td>
            <div class="td-main"><?= htmlspecialchars($xBa1v_["\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65"]) ?></div>
            <div class="mono" style="color:var(--text3)"><?= htmlspecialchars($xBa1v_["\x73\x69\x64"]) ?></div>
          </td>
          <td><?= htmlspecialchars($xBa1v_["\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65"] ?: "\xe2\x80\x94") ?></td>
          <td>$<?= number_format($xBa1v_["\x63\x70\x69"],2) ?></td>
          <td><?= $xBa1v_["\x69\x72"] ?>%</td>
          <td><?= $xBa1v_["\x6c\x6f\x69"] ?>m</td>
          <td><?= $BeGlbB ?> / <?= $rKf2jC ?></td>
          <td style="color:<?= $rKf2jC>0&&($BeGlbB/$rKf2jC)>0.5?"\x76\x61\x72\x28\x2d\x2d\x67\x72\x65\x65\x6e\x29":"\x76\x61\x72\x28\x2d\x2d\x61\x6d\x62\x65\x72\x29" ?>;font-weight:600">
            <?= $rKf2jC > 0 ? round(($BeGlbB/$rKf2jC)*100,1)."\x25" : "\xe2\x80\x94" ?>
          </td>
          <td>
            <?php
            $pz2gRa = ["\x61\x63\x74\x69\x76\x65"=>"\x70\x69\x6c\x6c\x2d\x67\x72\x65\x65\x6e","\x70\x61\x75\x73\x65\x64"=>"\x70\x69\x6c\x6c\x2d\x61\x6d\x62\x65\x72","\x63\x6c\x6f\x73\x65\x64"=>"\x70\x69\x6c\x6c\x2d\x67\x72\x61\x79"];
            echo "\x3c\x73\x70\x61\x6e\x20\x63\x6c\x61\x73\x73\x3d\x22\x70\x69\x6c\x6c\x20".($pz2gRa[$xBa1v_["\x73\x74\x61\x74\x75\x73"]]??"\x70\x69\x6c\x6c\x2d\x67\x72\x61\x79")."\x22\x3e".ucfirst($xBa1v_["\x73\x74\x61\x74\x75\x73"])."\x3c\x2f\x73\x70\x61\x6e\x3e";
            ?>
          </td>
          <td><span class="pill pill-blue"><?= ucfirst($xBa1v_["\x70\x72\x6f\x6a\x65\x63\x74\x5f\x74\x79\x70\x65"]) ?></span></td>
          <td>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              <a href="?page=project_view&id=<?= $xBa1v_["\x69\x64"] ?>" class="btn btn-sm btn-ghost">View</a>
              <?php if (rp_is_manager()): ?>
              <button class="btn btn-sm btn-ghost" onclick='openModal("modalProject",<?= json_encode($xBa1v_) ?>)'>Edit</button>
              <form method="POST" style="display:inline">
                <input type="hidden" name="action" value="toggle_project_status">
                <input type="hidden" name="id" value="<?= $xBa1v_["\x69\x64"] ?>">
                <button type="submit" class="btn btn-sm <?= $xBa1v_["\x73\x74\x61\x74\x75\x73"]==="\x61\x63\x74\x69\x76\x65" ? "\x62\x74\x6e\x2d\x61\x6d\x62\x65\x72" : "\x62\x74\x6e\x2d\x67\x72\x65\x65\x6e" ?>">
                  <?= $xBa1v_["\x73\x74\x61\x74\x75\x73"]==="\x61\x63\x74\x69\x76\x65" ? "\xe2\x8f\xb8\x20\x50\x61\x75\x73\x65" : "\xe2\x96\xb6\x20\x52\x65\x73\x75\x6d\x65" ?>
                </button>
              </form>
              <?php endif; ?>
              <?php if (rp_is_superadmin()): ?>
              <form method="POST" style="display:inline" onsubmit="return confirm('Delete project \'<?= htmlspecialchars(addslashes($xBa1v_["\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65"])) ?>\'? This cannot be undone. Existing leads will be kept for records, but the project itself will be removed.');">
                <input type="hidden" name="action" value="delete_project">
                <input type="hidden" name="id" value="<?= $xBa1v_["\x69\x64"] ?>">
                <button type="submit" class="btn btn-sm btn-red">🗑 Delete</button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($cQoAhS)): ?>
      <tr><td colspan="10" style="text-align:center;color:var(--text3);padding:32px"><?= !empty($_GET["\x70\x73\x65\x61\x72\x63\x68"]) ? "\x4e\x6f\x20\x70\x72\x6f\x6a\x65\x63\x74\x73\x20\x6d\x61\x74\x63\x68\x20\x79\x6f\x75\x72\x20\x73\x65\x61\x72\x63\x68\x2e" : "\x4e\x6f\x20\x70\x72\x6f\x6a\x65\x63\x74\x73\x20\x79\x65\x74\x2e\x20\x41\x64\x64\x20\x79\x6f\x75\x72\x20\x66\x69\x72\x73\x74\x20\x70\x72\x6f\x6a\x65\x63\x74\x21" ?></td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  
  
  
  if ($G82gPq === "\x70\x72\x6f\x6a\x65\x63\x74\x5f\x76\x69\x65\x77" && $C5P6NO):
    $wolakY = (isset($_SERVER["\x48\x54\x54\x50\x53"]) ? "\x68\x74\x74\x70\x73" : "\x68\x74\x74\x70") . "\x3a\x2f\x2f" . $_SERVER["\x48\x54\x54\x50\x5f\x48\x4f\x53\x54"];
    $Y8Iaoy = rtrim(str_replace("\x5c", "\x2f", dirname($_SERVER["\x53\x43\x52\x49\x50\x54\x5f\x4e\x41\x4d\x45"])), "\x2f"); 
    $wolakY = $wolakY . $Y8Iaoy;
    $XtSKIY = $C5P6NO["\x73\x69\x64"];
    $LavTQ5 = $C5P6NO["\x65\x6e\x63\x72\x79\x70\x74\x5f\x75\x69\x64"] ? "\x5b\x45\x4e\x43\x52\x59\x50\x54\x45\x44\x5f\x55\x49\x44\x5d" : "\x5b\x55\x49\x44\x5d";
  ?>
  <div style="margin-bottom:16px;display:flex;align-items:center;gap:10px">
    <a href="?page=projects" class="btn btn-ghost btn-sm">← Back to Projects</a>
    <?php if (rp_is_manager()): ?>
    <form method="POST" style="display:inline">
      <input type="hidden" name="action" value="toggle_project_status">
      <input type="hidden" name="id" value="<?= $C5P6NO["\x69\x64"] ?>">
      <button type="submit" class="btn btn-sm <?= $C5P6NO["\x73\x74\x61\x74\x75\x73"]==="\x61\x63\x74\x69\x76\x65" ? "\x62\x74\x6e\x2d\x61\x6d\x62\x65\x72" : "\x62\x74\x6e\x2d\x67\x72\x65\x65\x6e" ?>">
        <?= $C5P6NO["\x73\x74\x61\x74\x75\x73"]==="\x61\x63\x74\x69\x76\x65" ? "\xe2\x8f\xb8\x20\x50\x61\x75\x73\x65\x20\x50\x72\x6f\x6a\x65\x63\x74" : "\xe2\x96\xb6\x20\x52\x65\x73\x75\x6d\x65\x20\x50\x72\x6f\x6a\x65\x63\x74" ?>
      </button>
    </form>
    <button class="btn btn-sm btn-ghost" onclick='openModal("modalProject",<?= json_encode($C5P6NO) ?>)'>✏ Edit Project</button>
    <?php endif; ?>
    <?php if (rp_is_superadmin()): ?>
    <form method="POST" style="display:inline" onsubmit="return confirm('Delete project \'<?= htmlspecialchars(addslashes($C5P6NO["\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65"])) ?>\'? This cannot be undone. Existing leads will be kept for records, but the project itself will be removed.');">
      <input type="hidden" name="action" value="delete_project">
      <input type="hidden" name="id" value="<?= $C5P6NO["\x69\x64"] ?>">
      <button type="submit" class="btn btn-sm btn-red">🗑 Delete Project</button>
    </form>
    <?php endif; ?>
  </div>

  <!-- Stat cards -->
  <?php
    $tcWAAE    = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73\x20\x57\x48\x45\x52\x45\x20\x73\x69\x64\x3d\x3f"); $tcWAAE->execute([$XtSKIY]); $zJryAo = $tcWAAE->fetchColumn();
    $qkAfiL = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73\x20\x57\x48\x45\x52\x45\x20\x73\x69\x64\x3d\x3f\x20\x41\x4e\x44\x20\x73\x74\x61\x74\x75\x73\x3d\x27\x63\x6f\x6d\x70\x6c\x65\x74\x65\x27"); $qkAfiL->execute([$XtSKIY]); $W0Ldml = $qkAfiL->fetchColumn();
    $q4zCgJ= $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73\x20\x57\x48\x45\x52\x45\x20\x73\x69\x64\x3d\x3f\x20\x41\x4e\x44\x20\x73\x74\x61\x74\x75\x73\x3d\x27\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x27"); $q4zCgJ->execute([$XtSKIY]); $H9N8S6 = $q4zCgJ->fetchColumn();
    $J1Wrg6 = (int)$C5P6NO["\x6d\x61\x78\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x73"];
    $gPD_8J = ($J1Wrg6 > 0) ? min(100, round(($W0Ldml/$J1Wrg6)*100)) : null;
  ?>
  <div class="stats-grid" style="grid-template-columns:repeat(<?= $J1Wrg6?"\x34":"\x33" ?>,1fr);margin-bottom:20px">
    <div class="stat-card" style="--card-color:#6366f1"><div class="stat-label">Clicks</div><div class="stat-value"><?= $zJryAo ?></div></div>
    <div class="stat-card" style="--card-color:#22c55e"><div class="stat-label">Completes</div><div class="stat-value"><?= $W0Ldml ?></div></div>
    <div class="stat-card" style="--card-color:#f59e0b"><div class="stat-label">Terminates</div><div class="stat-value"><?= $H9N8S6 ?></div></div>
    <?php if ($J1Wrg6 > 0): ?>
    <div class="stat-card" style="--card-color:#8b5cf6">
      <div class="stat-label">Quota</div>
      <div class="stat-value"><?= $gPD_8J ?>%</div>
      <div style="margin-top:8px;background:rgba(15,23,42,0.08);border-radius:4px;height:4px;overflow:hidden">
        <div style="width:<?= $gPD_8J ?>%;height:100%;background:<?= $gPD_8J>=100?"\x76\x61\x72\x28\x2d\x2d\x72\x65\x64\x29":($gPD_8J>=80?"\x76\x61\x72\x28\x2d\x2d\x61\x6d\x62\x65\x72\x29":"\x76\x61\x72\x28\x2d\x2d\x61\x63\x63\x65\x6e\x74\x29") ?>;border-radius:4px;transition:width .3s"></div>
      </div>
      <div class="stat-sub"><?= $W0Ldml ?> / <?= $J1Wrg6 ?></div>
    </div>
    <?php endif; ?>
  </div>

  <!-- Project Info -->
  <div class="cards-grid">
    <div class="info-card">
      <div class="info-card-title">Project Info</div>
      <div class="info-row"><span class="info-key">Project Name</span><span class="info-val"><?= htmlspecialchars($C5P6NO["\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65"]) ?></span></div>
      <div class="info-row"><span class="info-key">Project ID</span><span class="info-val mono"><?= htmlspecialchars($XtSKIY) ?></span></div>
      <div class="info-row"><span class="info-key">Client</span><span class="info-val"><?= htmlspecialchars($C5P6NO["\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65"] ?: "\xe2\x80\x94") ?></span></div>
      <div class="info-row"><span class="info-key">CPI</span><span class="info-val">$<?= number_format($C5P6NO["\x63\x70\x69"],2) ?></span></div>
      <div class="info-row"><span class="info-key">IR%</span><span class="info-val"><?= $C5P6NO["\x69\x72"] ?>%</span></div>
      <div class="info-row"><span class="info-key">LOI</span><span class="info-val"><?= $C5P6NO["\x6c\x6f\x69"] ?> min</span></div>
      <div class="info-row"><span class="info-key">Max Completes (Quota)</span><span class="info-val" style="color:var(--accent);font-weight:600"><?= $C5P6NO["\x6d\x61\x78\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x73"] ? number_format($C5P6NO["\x6d\x61\x78\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x73"]) : "\x55\x6e\x6c\x69\x6d\x69\x74\x65\x64" ?></span></div>
      <div class="info-row"><span class="info-key">Status</span><span class="info-val"><?= ucfirst($C5P6NO["\x73\x74\x61\x74\x75\x73"]) ?></span></div>
      <div class="info-row"><span class="info-key">Encryption</span><span class="info-val"><?= $C5P6NO["\x65\x6e\x63\x72\x79\x70\x74\x5f\x75\x69\x64"] ? "\x4f\x4e" : "\x4f\x46\x46" ?></span></div>
    </div>

    <?php if (!empty($C5P6NO["\x64\x65\x73\x63\x72\x69\x70\x74\x69\x6f\x6e"])): ?>
    <!-- Description / Study Parameters -->
    <div class="info-card" style="margin-top:16px">
      <div class="info-card-title">Description / Study Parameters</div>
      <div style="padding:12px 0;font-size:13px;color:var(--text2);line-height:1.7">
        <?= $C5P6NO["\x64\x65\x73\x63\x72\x69\x70\x74\x69\x6f\x6e"] ?>
      </div>
    </div>
    <?php endif; ?>

    <!-- Redirect URLs -->
    <div class="info-card">
      <div class="info-card-title">End Redirect URLs (Dynamic)</div>
      <?php
      $hU3LyS = [
        "\x63\x6f\x6d\x70\x6c\x65\x74\x65"  => ["\x43\x6f\x6d\x70\x6c\x65\x74\x65",  "\x70\x69\x6c\x6c\x2d\x67\x72\x65\x65\x6e"],
        "\x74\x65\x72\x6d\x69\x6e\x61\x74\x65" => ["\x54\x65\x72\x6d\x69\x6e\x61\x74\x65", "\x70\x69\x6c\x6c\x2d\x61\x6d\x62\x65\x72"],
        "\x6f\x76\x65\x72\x71\x75\x6f\x74\x61" => ["\x4f\x76\x65\x72\x71\x75\x6f\x74\x61", "\x70\x69\x6c\x6c\x2d\x62\x6c\x75\x65"],
        "\x71\x75\x61\x6c\x69\x74\x79\x5f\x66\x61\x69\x6c" => ["\x51\x75\x61\x6c\x69\x74\x79\x20\x46\x61\x69\x6c","\x70\x69\x6c\x6c\x2d\x72\x65\x64"],
      ];
      foreach ($hU3LyS as $Q0BE2n => [$nHFvG8, $yevgeg]):
        $qBemlg = "$wolakY/end.php?status=$Q0BE2n&sid=$XtSKIY&uid=$LavTQ5";
      ?>
      <div class="url-label"><span class="pill <?= $yevgeg ?>"><?= $nHFvG8 ?></span></div>
      <div class="url-box">
        <div class="url-val"><?= htmlspecialchars($qBemlg) ?></div>
        <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($qBemlg) ?>')">Copy</button>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Static URLs -->
  <div class="info-card" style="margin-bottom:20px">
    <div class="info-card-title">Static Redirect URLs</div>
    <?php foreach ($hU3LyS as $Q0BE2n => [$nHFvG8, $yevgeg]):
      $_vtCbD = "$wolakY/pages/".str_replace("\x5f","\x2d",$Q0BE2n).".html?sid=$XtSKIY&uid=$LavTQ5";
    ?>
    <div class="url-label"><span class="pill <?= $yevgeg ?>"><?= $nHFvG8 ?></span></div>
    <div class="url-box">
      <div class="url-val"><?= htmlspecialchars($_vtCbD) ?></div>
      <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($_vtCbD) ?>')">Copy</button>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Vendor Entry Links -->
  <div class="info-card" style="margin-bottom:20px">
    <div class="info-card-title">Vendor Entry Link Generator</div>
    <div style="font-size:12px;color:var(--text3);margin-bottom:12px">Pick a vendor to instantly generate their entry link for this project — copy and send it to them.</div>
    <div class="field" style="max-width:320px;margin-bottom:14px">
      <label>Vendor</label>
      <select id="velVendorSelect" onchange="rpUpdateVendorEntryLinks()">
        <option value="">— Select a vendor —</option>
        <?php foreach ($PB9X5i as $q3wG48): ?>
        <option value="<?= $q3wG48["\x69\x64"] ?>"><?= htmlspecialchars($q3wG48["\x76\x65\x6e\x64\x6f\x72\x5f\x6e\x61\x6d\x65"]) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div id="velLinksWrap" style="display:none">
      <div class="url-label"><span class="pill pill-blue">Without Prescreener</span></div>
      <div class="url-box">
        <div class="url-val" id="velNoScreener">—</div>
        <button class="copy-btn" onclick="copyText(document.getElementById('velNoScreener').textContent)">Copy</button>
      </div>
      <div class="url-label"><span class="pill pill-green">With Prescreener</span></div>
      <div class="url-box">
        <div class="url-val" id="velWithScreener">—</div>
        <button class="copy-btn" onclick="copyText(document.getElementById('velWithScreener').textContent)">Copy</button>
      </div>
    </div>
  </div>
  <script>
  function rpUpdateVendorEntryLinks() {
    const vid = document.getElementById('velVendorSelect').value;
    const wrap = document.getElementById('velLinksWrap');
    if (!vid) { wrap.style.display = 'none'; return; }
    const base = <?= json_encode($wolakY) ?>;
    const sid  = <?= json_encode($XtSKIY) ?>;
    document.getElementById('velNoScreener').textContent   = `${base}/vendor.php?sid=${sid}&vid=${vid}&uid=[UID]`;
    document.getElementById('velWithScreener').textContent = `${base}/start.php?sid=${sid}&vid=${vid}&uid=[UID]`;
    wrap.style.display = 'block';
  }
  </script>

  <!-- Recent Leads -->
  <div class="section-header">
    <div class="section-title" style="margin-bottom:0">Recent Leads</div>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>UID</th><th>Status</th><th>Country</th><th>Device</th><th>LOI</th><th>IP</th><th>Date</th></tr></thead>
      <tbody>
      <?php foreach ($VwuomI as $V2tzwf):
        $WHgE3z = ["\x63\x6f\x6d\x70\x6c\x65\x74\x65"=>"\x70\x69\x6c\x6c\x2d\x67\x72\x65\x65\x6e","\x74\x65\x72\x6d\x69\x6e\x61\x74\x65"=>"\x70\x69\x6c\x6c\x2d\x61\x6d\x62\x65\x72","\x6f\x76\x65\x72\x71\x75\x6f\x74\x61"=>"\x70\x69\x6c\x6c\x2d\x62\x6c\x75\x65","\x71\x75\x61\x6c\x69\x74\x79\x5f\x66\x61\x69\x6c"=>"\x70\x69\x6c\x6c\x2d\x72\x65\x64","\x63\x6c\x69\x63\x6b"=>"\x70\x69\x6c\x6c\x2d\x67\x72\x61\x79","\x70\x65\x6e\x64\x69\x6e\x67"=>"\x70\x69\x6c\x6c\x2d\x61\x6d\x62\x65\x72"];
      ?>
        <tr>
          <td class="mono">
            <?= htmlspecialchars($V2tzwf["\x6f\x72\x69\x67\x69\x6e\x61\x6c\x5f\x75\x69\x64"] ?: "\xe2\x80\x94") ?>
            <?php if (!empty($V2tzwf["\x65\x6e\x63\x72\x79\x70\x74\x65\x64\x5f\x75\x69\x64"]) && $V2tzwf["\x65\x6e\x63\x72\x79\x70\x74\x65\x64\x5f\x75\x69\x64"] !== $V2tzwf["\x6f\x72\x69\x67\x69\x6e\x61\x6c\x5f\x75\x69\x64"]): ?>
            <div style="font-size:10px;color:var(--text3);margin-top:2px">🔒 <?= htmlspecialchars(substr($V2tzwf["\x65\x6e\x63\x72\x79\x70\x74\x65\x64\x5f\x75\x69\x64"],0,24)) ?>...</div>
            <?php endif; ?>
          </td>
          <td><span class="pill <?= $WHgE3z[$V2tzwf["\x73\x74\x61\x74\x75\x73"]]??"\x70\x69\x6c\x6c\x2d\x67\x72\x61\x79" ?>"><?= ucfirst(str_replace("\x5f","\x20",$V2tzwf["\x73\x74\x61\x74\x75\x73"])) ?></span></td>
          <td><?= htmlspecialchars($V2tzwf["\x63\x6f\x75\x6e\x74\x72\x79"] ?: "\xe2\x80\x94") ?></td>
          <td><?= htmlspecialchars($V2tzwf["\x64\x65\x76\x69\x63\x65"] ?: "\xe2\x80\x94") ?></td>
          <td><?= $V2tzwf["\x6c\x6f\x69\x5f\x73\x65\x63\x6f\x6e\x64\x73"] ? round($V2tzwf["\x6c\x6f\x69\x5f\x73\x65\x63\x6f\x6e\x64\x73"]/60,1)."\x6d" : "\xe2\x80\x94" ?></td>
          <td class="mono"><?= htmlspecialchars($V2tzwf["\x69\x70"] ?: "\xe2\x80\x94") ?></td>
          <td><?= $V2tzwf["\x63\x72\x65\x61\x74\x65\x64\x5f\x61\x74"] ? date("\x64\x20\x4d\x20\x48\x3a\x69", strtotime($V2tzwf["\x63\x72\x65\x61\x74\x65\x64\x5f\x61\x74"])) : "\xe2\x80\x94" ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($VwuomI)): ?>
      <tr><td colspan="7" style="text-align:center;color:var(--text3);padding:24px">No leads yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php endif; ?>

  <?php
  
  
  
  if ($G82gPq === "\x63\x6c\x69\x65\x6e\x74\x73"):
  ?>
  <div class="section-header">
    <div class="section-title">Clients (<?= count($cYKgua) ?>)</div>
    <?php if (rp_is_manager()): ?>
    <button class="btn btn-primary" onclick="openModal('modalClient',{})">+ Add Client</button>
    <?php endif; ?>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Client Name</th><th>Email</th><th>Company</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($cYKgua as $GqmAku => $vVKgZj): ?>
        <tr>
          <td><?= $GqmAku+1 ?></td>
          <td class="td-main"><?= htmlspecialchars($vVKgZj["\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65"]) ?></td>
          <td><?= htmlspecialchars($vVKgZj["\x65\x6d\x61\x69\x6c"] ?: "\xe2\x80\x94") ?></td>
          <td><?= htmlspecialchars($vVKgZj["\x63\x6f\x6d\x70\x61\x6e\x79"] ?: "\xe2\x80\x94") ?></td>
          <td><span class="pill <?= $vVKgZj["\x73\x74\x61\x74\x75\x73"]==="\x61\x63\x74\x69\x76\x65"?"\x70\x69\x6c\x6c\x2d\x67\x72\x65\x65\x6e":"\x70\x69\x6c\x6c\x2d\x67\x72\x61\x79" ?>"><?= ucfirst($vVKgZj["\x73\x74\x61\x74\x75\x73"]) ?></span></td>
          <td>
            <div style="display:flex;gap:6px">
              <?php if (rp_is_manager()): ?>
              <button class="btn btn-sm btn-ghost" onclick='openModal("modalClient",<?= json_encode($vVKgZj) ?>)'>Edit</button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($cYKgua)): ?>
      <tr><td colspan="6" style="text-align:center;color:var(--text3);padding:32px">No clients yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  
  
  
  if ($G82gPq === "\x76\x65\x6e\x64\x6f\x72\x73"):
  ?>
  <div class="section-header">
    <div class="section-title">Vendors (<?= count($ZgJMtg) ?>)</div>
    <?php if (rp_is_manager()): ?>
    <button class="btn btn-primary" onclick="openModal('modalVendor',{})">+ Add Vendor</button>
    <?php endif; ?>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Vendor</th><th>Email</th><th>Clicks</th><th>Completes</th><th>Terminates</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($ZgJMtg as $GqmAku => $yWpVqk):
        $gJ09kM = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73\x20\x57\x48\x45\x52\x45\x20\x76\x65\x6e\x64\x6f\x72\x5f\x69\x64\x3d\x3f"); $gJ09kM->execute([$yWpVqk["\x69\x64"]]); $f7pOFh=$gJ09kM->fetchColumn();
        $r0PXCq= $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73\x20\x57\x48\x45\x52\x45\x20\x76\x65\x6e\x64\x6f\x72\x5f\x69\x64\x3d\x3f\x20\x41\x4e\x44\x20\x73\x74\x61\x74\x75\x73\x3d\x27\x63\x6f\x6d\x70\x6c\x65\x74\x65\x27"); $r0PXCq->execute([$yWpVqk["\x69\x64"]]); $nt8kIw=$r0PXCq->fetchColumn();
        $fEcBRx = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73\x20\x57\x48\x45\x52\x45\x20\x76\x65\x6e\x64\x6f\x72\x5f\x69\x64\x3d\x3f\x20\x41\x4e\x44\x20\x73\x74\x61\x74\x75\x73\x3d\x27\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x27"); $fEcBRx->execute([$yWpVqk["\x69\x64"]]); $WeaDCe=$fEcBRx->fetchColumn();
      ?>
        <tr>
          <td><?= $GqmAku+1 ?></td>
          <td class="td-main">
            <a href="?page=vendor_view&id=<?= $yWpVqk["\x69\x64"] ?>" style="color:var(--accent);text-decoration:none">
              <?= htmlspecialchars($yWpVqk["\x76\x65\x6e\x64\x6f\x72\x5f\x6e\x61\x6d\x65"]) ?>
            </a>
          </td>
          <td><?= htmlspecialchars($yWpVqk["\x65\x6d\x61\x69\x6c"] ?: "\xe2\x80\x94") ?></td>
          <td><?= $f7pOFh ?></td>
          <td><?= $nt8kIw ?></td>
          <td><?= $WeaDCe ?></td>
          <td><span class="pill <?= $yWpVqk["\x73\x74\x61\x74\x75\x73"]==="\x61\x63\x74\x69\x76\x65"?"\x70\x69\x6c\x6c\x2d\x67\x72\x65\x65\x6e":"\x70\x69\x6c\x6c\x2d\x67\x72\x61\x79" ?>"><?= ucfirst($yWpVqk["\x73\x74\x61\x74\x75\x73"]) ?></span></td>
          <td>
            <div style="display:flex;gap:6px">
              <?php if (rp_is_manager()): ?>
              <button class="btn btn-sm btn-ghost" onclick='openModal("modalVendor",<?= json_encode($yWpVqk) ?>)'>Edit</button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($ZgJMtg)): ?>
      <tr><td colspan="8" style="text-align:center;color:var(--text3);padding:32px">No vendors yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  
  
  
  if ($G82gPq === "\x6c\x65\x61\x64\x73"):
    $MiWb3q = ceil($BzIlzf / 50);
  ?>
  <div class="section-header">
    <div class="section-title">Leads (<?= number_format($BzIlzf) ?> total)</div>
  </div>

  <form method="GET" style="display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap">
    <input type="hidden" name="page" value="leads">
    <input class="search-input" type="text" name="search" placeholder="Search UID or SID..." value="<?= htmlspecialchars($_GET["\x73\x65\x61\x72\x63\x68"]??"") ?>">
    <select class="search-input" name="status" style="min-width:140px">
      <option value="">All Statuses</option>
      <option value="complete" <?= ($_GET["\x73\x74\x61\x74\x75\x73"]??"")==="\x63\x6f\x6d\x70\x6c\x65\x74\x65"?"\x73\x65\x6c\x65\x63\x74\x65\x64":"" ?>>Complete</option>
      <option value="terminate" <?= ($_GET["\x73\x74\x61\x74\x75\x73"]??"")==="\x74\x65\x72\x6d\x69\x6e\x61\x74\x65"?"\x73\x65\x6c\x65\x63\x74\x65\x64":"" ?>>Terminate</option>
      <option value="overquota" <?= ($_GET["\x73\x74\x61\x74\x75\x73"]??"")==="\x6f\x76\x65\x72\x71\x75\x6f\x74\x61"?"\x73\x65\x6c\x65\x63\x74\x65\x64":"" ?>>Overquota</option>
      <option value="quality_fail" <?= ($_GET["\x73\x74\x61\x74\x75\x73"]??"")==="\x71\x75\x61\x6c\x69\x74\x79\x5f\x66\x61\x69\x6c"?"\x73\x65\x6c\x65\x63\x74\x65\x64":"" ?>>Quality Fail</option>
      <option value="click" <?= ($_GET["\x73\x74\x61\x74\x75\x73"]??"")==="\x63\x6c\x69\x63\x6b"?"\x73\x65\x6c\x65\x63\x74\x65\x64":"" ?>>Click Only</option>
      <option value="pending" <?= ($_GET["\x73\x74\x61\x74\x75\x73"]??"")==="\x70\x65\x6e\x64\x69\x6e\x67"?"\x73\x65\x6c\x65\x63\x74\x65\x64":"" ?>>Pending</option>
      <option value="unmatched" <?= ($_GET["\x73\x74\x61\x74\x75\x73"]??"")==="\x75\x6e\x6d\x61\x74\x63\x68\x65\x64"?"\x73\x65\x6c\x65\x63\x74\x65\x64":"" ?>>Unmatched</option>
    </select>
    <select class="search-input" name="project" style="min-width:160px">
      <option value="">All Projects</option>
      <?php foreach ($h8sOUt as $UOCeHZ): ?>
      <option value="<?= htmlspecialchars($UOCeHZ["\x73\x69\x64"]) ?>" <?= ($_GET["\x70\x72\x6f\x6a\x65\x63\x74"]??"")===$UOCeHZ["\x73\x69\x64"]?"\x73\x65\x6c\x65\x63\x74\x65\x64":"" ?>><?= htmlspecialchars($UOCeHZ["\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65"]) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="search-input" name="device" style="min-width:130px">
      <option value="">All Devices</option>
      <?php foreach ($XcI1mt as $KkOdvs): ?>
      <option value="<?= $KkOdvs ?>" <?= ($_GET["\x64\x65\x76\x69\x63\x65"]??"")===$KkOdvs?"\x73\x65\x6c\x65\x63\x74\x65\x64":"" ?>><?= ucfirst($KkOdvs) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="search-input" name="source" style="min-width:130px">
      <option value="">All Sources</option>
      <?php foreach ($FfcP4v as $Bw26hg): ?>
      <option value="<?= $Bw26hg ?>" <?= ($_GET["\x73\x6f\x75\x72\x63\x65"]??"")===$Bw26hg?"\x73\x65\x6c\x65\x63\x74\x65\x64":"" ?>><?= ucfirst($Bw26hg) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="search-input" name="client" style="min-width:150px">
      <option value="">All Clients</option>
      <?php foreach ($O_ptcp as $RGHgcl): ?>
      <option value="<?= $RGHgcl["\x69\x64"] ?>" <?= ((int)($_GET["\x63\x6c\x69\x65\x6e\x74"]??0))===(int)$RGHgcl["\x69\x64"]?"\x73\x65\x6c\x65\x63\x74\x65\x64":"" ?>><?= htmlspecialchars($RGHgcl["\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65"]) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="search-input" name="country" style="min-width:140px">
      <option value="">All Countries</option>
      <?php foreach ($ecJRz2 as $qD_VHU): ?>
      <option value="<?= htmlspecialchars($qD_VHU) ?>" <?= ($_GET["\x63\x6f\x75\x6e\x74\x72\x79"]??"")===$qD_VHU?"\x73\x65\x6c\x65\x63\x74\x65\x64":"" ?>><?= htmlspecialchars($qD_VHU) ?></option>
      <?php endforeach; ?>
    </select>
    <input class="search-input" type="date" name="date_from" value="<?= htmlspecialchars($_GET["\x64\x61\x74\x65\x5f\x66\x72\x6f\x6d"]??"") ?>" title="From date" style="min-width:150px">
    <input class="search-input" type="date" name="date_to" value="<?= htmlspecialchars($_GET["\x64\x61\x74\x65\x5f\x74\x6f"]??"") ?>" title="To date" style="min-width:150px">
    <button type="submit" class="btn btn-primary btn-sm">Filter</button>
    <a href="?page=leads" class="btn btn-ghost btn-sm">Clear</a>
    <?php
      $YME1tp = http_build_query([
        "\x70\x61\x67\x65"=>"\x6c\x65\x61\x64\x73","\x65\x78\x70\x6f\x72\x74"=>"\x63\x73\x76",
        "\x73\x65\x61\x72\x63\x68"=>$_GET["\x73\x65\x61\x72\x63\x68"]??"", "\x73\x74\x61\x74\x75\x73"=>$_GET["\x73\x74\x61\x74\x75\x73"]??"",
        "\x70\x72\x6f\x6a\x65\x63\x74"=>$_GET["\x70\x72\x6f\x6a\x65\x63\x74"]??"", "\x64\x65\x76\x69\x63\x65"=>$_GET["\x64\x65\x76\x69\x63\x65"]??"",
        "\x73\x6f\x75\x72\x63\x65"=>$_GET["\x73\x6f\x75\x72\x63\x65"]??"", "\x63\x6c\x69\x65\x6e\x74"=>$_GET["\x63\x6c\x69\x65\x6e\x74"]??"",
        "\x63\x6f\x75\x6e\x74\x72\x79"=>$_GET["\x63\x6f\x75\x6e\x74\x72\x79"]??"", "\x64\x61\x74\x65\x5f\x66\x72\x6f\x6d"=>$_GET["\x64\x61\x74\x65\x5f\x66\x72\x6f\x6d"]??"", "\x64\x61\x74\x65\x5f\x74\x6f"=>$_GET["\x64\x61\x74\x65\x5f\x74\x6f"]??"",
      ]);
    ?>
    <a href="?<?= $YME1tp ?>" class="btn btn-green btn-sm">⬇ Export to Excel</a>
  </form>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th><th>UID</th><th>Project</th><th>Client</th><th>Status</th><th>Country</th><th>Device</th><th>Source</th><th>LOI</th><th>IP</th><th>Date</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($l2Ujjb as $GqmAku => $V2tzwf):
        $WHgE3z = ["\x63\x6f\x6d\x70\x6c\x65\x74\x65"=>"\x70\x69\x6c\x6c\x2d\x67\x72\x65\x65\x6e","\x74\x65\x72\x6d\x69\x6e\x61\x74\x65"=>"\x70\x69\x6c\x6c\x2d\x61\x6d\x62\x65\x72","\x6f\x76\x65\x72\x71\x75\x6f\x74\x61"=>"\x70\x69\x6c\x6c\x2d\x62\x6c\x75\x65","\x71\x75\x61\x6c\x69\x74\x79\x5f\x66\x61\x69\x6c"=>"\x70\x69\x6c\x6c\x2d\x72\x65\x64","\x63\x6c\x69\x63\x6b"=>"\x70\x69\x6c\x6c\x2d\x67\x72\x61\x79","\x70\x65\x6e\x64\x69\x6e\x67"=>"\x70\x69\x6c\x6c\x2d\x61\x6d\x62\x65\x72","\x75\x6e\x6d\x61\x74\x63\x68\x65\x64"=>"\x70\x69\x6c\x6c\x2d\x67\x72\x61\x79"];
        $OXqshS = !empty($V2tzwf["\x69\x73\x5f\x64\x75\x70\x6c\x69\x63\x61\x74\x65"]);
      ?>
        <tr style="<?= $OXqshS ? "\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x3a\x72\x67\x62\x61\x28\x32\x33\x39\x2c\x36\x38\x2c\x36\x38\x2c\x30\x2e\x30\x35\x29" : "" ?>">
          <td><?= ($hlxnd5-1)*50 + $GqmAku + 1 ?></td>
          <td class="mono">
            <?= htmlspecialchars($V2tzwf["\x6f\x72\x69\x67\x69\x6e\x61\x6c\x5f\x75\x69\x64"] ?: "\xe2\x80\x94") ?>
            <?php if (!empty($V2tzwf["\x65\x6e\x63\x72\x79\x70\x74\x65\x64\x5f\x75\x69\x64"]) && $V2tzwf["\x65\x6e\x63\x72\x79\x70\x74\x65\x64\x5f\x75\x69\x64"] !== $V2tzwf["\x6f\x72\x69\x67\x69\x6e\x61\x6c\x5f\x75\x69\x64"]): ?>
            <div style="font-size:10px;color:var(--text3);margin-top:2px">🔒 <?= htmlspecialchars(substr($V2tzwf["\x65\x6e\x63\x72\x79\x70\x74\x65\x64\x5f\x75\x69\x64"],0,24)) ?>...</div>
            <?php endif; ?>
            <?php if ($OXqshS): ?>
            <span class="pill pill-red" style="font-size:9px;padding:1px 6px;margin-left:4px">DUP</span>
            <?php endif; ?>
          </td>
          <td>
            <div style="font-size:12px;color:var(--text)"><?= htmlspecialchars($V2tzwf["\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65"] ?: "\xe2\x80\x94") ?></div>
            <div class="mono" style="color:var(--text3)"><?= htmlspecialchars($V2tzwf["\x73\x69\x64"]) ?></div>
          </td>
          <td><?= htmlspecialchars($V2tzwf["\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65"] ?: "\xe2\x80\x94") ?></td>
          <td><span class="pill <?= $WHgE3z[$V2tzwf["\x73\x74\x61\x74\x75\x73"]]??"\x70\x69\x6c\x6c\x2d\x67\x72\x61\x79" ?>"><?= ucfirst(str_replace("\x5f","\x20",$V2tzwf["\x73\x74\x61\x74\x75\x73"])) ?></span></td>
          <td><?= htmlspecialchars($V2tzwf["\x63\x6f\x75\x6e\x74\x72\x79"] ?: "\xe2\x80\x94") ?></td>
          <td><?= htmlspecialchars($V2tzwf["\x64\x65\x76\x69\x63\x65"] ?: "\xe2\x80\x94") ?></td>
          <td><?= htmlspecialchars($V2tzwf["\x73\x6f\x75\x72\x63\x65"] ?: "\xe2\x80\x94") ?></td>
          <td><?= $V2tzwf["\x6c\x6f\x69\x5f\x73\x65\x63\x6f\x6e\x64\x73"] ? round($V2tzwf["\x6c\x6f\x69\x5f\x73\x65\x63\x6f\x6e\x64\x73"]/60,1)."\x6d" : "\xe2\x80\x94" ?></td>
          <td class="mono"><?= htmlspecialchars(substr($V2tzwf["\x69\x70"]??"\xe2\x80\x94",0,15)) ?></td>
          <td><?= $V2tzwf["\x63\x72\x65\x61\x74\x65\x64\x5f\x61\x74"] ? date("\x64\x20\x4d\x20\x48\x3a\x69", strtotime($V2tzwf["\x63\x72\x65\x61\x74\x65\x64\x5f\x61\x74"])) : "\xe2\x80\x94" ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($l2Ujjb)): ?>
      <tr><td colspan="11" style="text-align:center;color:var(--text3);padding:32px">No leads found.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php if ($MiWb3q > 1): ?>
  <div class="pagination">
    <?php
      $xfJ4Hb = ["\x73\x65\x61\x72\x63\x68"=>$_GET["\x73\x65\x61\x72\x63\x68"]??"", "\x73\x74\x61\x74\x75\x73"=>$_GET["\x73\x74\x61\x74\x75\x73"]??"",
        "\x70\x72\x6f\x6a\x65\x63\x74"=>$_GET["\x70\x72\x6f\x6a\x65\x63\x74"]??"", "\x64\x65\x76\x69\x63\x65"=>$_GET["\x64\x65\x76\x69\x63\x65"]??"",
        "\x73\x6f\x75\x72\x63\x65"=>$_GET["\x73\x6f\x75\x72\x63\x65"]??"", "\x63\x6c\x69\x65\x6e\x74"=>$_GET["\x63\x6c\x69\x65\x6e\x74"]??"",
        "\x63\x6f\x75\x6e\x74\x72\x79"=>$_GET["\x63\x6f\x75\x6e\x74\x72\x79"]??"", "\x64\x61\x74\x65\x5f\x66\x72\x6f\x6d"=>$_GET["\x64\x61\x74\x65\x5f\x66\x72\x6f\x6d"]??"", "\x64\x61\x74\x65\x5f\x74\x6f"=>$_GET["\x64\x61\x74\x65\x5f\x74\x6f"]??""];
    ?>
    <?php
      $base = "?page=leads&lpage=";
      $qs = "&" . http_build_query($xfJ4Hb);
      $winStart = max(1, $hlxnd5-2);
      $winEnd = min($MiWb3q, $hlxnd5+2);
    ?>
    <?php if ($hlxnd5 > 1): ?>
      <a href="<?= $base ?><?= $hlxnd5-1 ?><?= $qs ?>" class="page-btn">&laquo; Prev</a>
    <?php endif; ?>
    <?php if ($winStart > 1): ?>
      <a href="<?= $base ?>1<?= $qs ?>" class="page-btn">1</a>
      <?php if ($winStart > 2): ?><span style="padding:6px 4px;color:var(--text3)">...</span><?php endif; ?>
    <?php endif; ?>
    <?php for ($xBa1v_=$winStart; $xBa1v_<=$winEnd; $xBa1v_++): ?>
      <a href="<?= $base ?><?= $xBa1v_ ?><?= $qs ?>" class="page-btn <?= $xBa1v_==$hlxnd5?"active":"" ?>"><?= $xBa1v_ ?></a>
    <?php endfor; ?>
    <?php if ($winEnd < $MiWb3q): ?>
      <?php if ($winEnd < $MiWb3q-1): ?><span style="padding:6px 4px;color:var(--text3)">...</span><?php endif; ?>
      <a href="<?= $base ?><?= $MiWb3q ?><?= $qs ?>" class="page-btn"><?= $MiWb3q ?></a>
    <?php endif; ?>
    <?php if ($hlxnd5 < $MiWb3q): ?>
      <a href="<?= $base ?><?= $hlxnd5+1 ?><?= $qs ?>" class="page-btn">Next &raquo;</a>
    <?php endif; ?>
  </div>
  <?php endif; ?>
  <?php endif; ?>

  <?php
  
  
  
  if ($G82gPq === "\x76\x65\x6e\x64\x6f\x72\x5f\x76\x69\x65\x77" && $eI722w):
    $QR8vGU    = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73\x20\x57\x48\x45\x52\x45\x20\x76\x65\x6e\x64\x6f\x72\x5f\x69\x64\x3d\x3f"); $QR8vGU->execute([$eI722w["\x69\x64"]]); $aJ_IyA=$QR8vGU->fetchColumn();
    $zkgyZ4 = $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73\x20\x57\x48\x45\x52\x45\x20\x76\x65\x6e\x64\x6f\x72\x5f\x69\x64\x3d\x3f\x20\x41\x4e\x44\x20\x73\x74\x61\x74\x75\x73\x3d\x27\x63\x6f\x6d\x70\x6c\x65\x74\x65\x27"); $zkgyZ4->execute([$eI722w["\x69\x64"]]); $EJOiRG=$zkgyZ4->fetchColumn();
    $fTwESE= $k2vPh_->prepare("\x53\x45\x4c\x45\x43\x54\x20\x43\x4f\x55\x4e\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20\x72\x70\x5f\x6c\x65\x61\x64\x73\x20\x57\x48\x45\x52\x45\x20\x76\x65\x6e\x64\x6f\x72\x5f\x69\x64\x3d\x3f\x20\x41\x4e\x44\x20\x73\x74\x61\x74\x75\x73\x3d\x27\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x27"); $fTwESE->execute([$eI722w["\x69\x64"]]); $z6sKth=$fTwESE->fetchColumn();
  ?>
  <div style="margin-bottom:16px">
    <a href="?page=vendors" class="btn btn-ghost btn-sm">← Back to Vendors</a>
  </div>

  <!-- Stat Cards -->
  <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:20px">
    <div class="stat-card" style="--card-color:#6366f1"><div class="stat-label">Clicks</div><div class="stat-value"><?= $aJ_IyA ?></div></div>
    <div class="stat-card" style="--card-color:#22c55e"><div class="stat-label">Completes</div><div class="stat-value"><?= $EJOiRG ?></div></div>
    <div class="stat-card" style="--card-color:#f59e0b"><div class="stat-label">Terminates</div><div class="stat-value"><?= $z6sKth ?></div></div>
  </div>

  <!-- Vendor Info -->
  <div class="info-card" style="margin-bottom:20px">
    <div class="info-card-title">Vendor Info</div>
    <div class="info-row"><span class="info-key">Name</span><span class="info-val"><?= htmlspecialchars($eI722w["\x76\x65\x6e\x64\x6f\x72\x5f\x6e\x61\x6d\x65"]) ?></span></div>
    <div class="info-row"><span class="info-key">Email</span><span class="info-val"><?= htmlspecialchars($eI722w["\x65\x6d\x61\x69\x6c"] ?: "\xe2\x80\x94") ?></span></div>
    <div class="info-row"><span class="info-key">Phone</span><span class="info-val"><?= htmlspecialchars($eI722w["\x70\x68\x6f\x6e\x65"] ?: "\xe2\x80\x94") ?></span></div>
    <div class="info-row"><span class="info-key">Status</span><span class="info-val"><span class="pill <?= $eI722w["\x73\x74\x61\x74\x75\x73"]==="\x61\x63\x74\x69\x76\x65"?"\x70\x69\x6c\x6c\x2d\x67\x72\x65\x65\x6e":"\x70\x69\x6c\x6c\x2d\x67\x72\x61\x79" ?>"><?= ucfirst($eI722w["\x73\x74\x61\x74\x75\x73"]) ?></span></span></div>
    <div class="info-row"><span class="info-key">Conv%</span><span class="info-val" style="color:var(--green);font-weight:600"><?= $aJ_IyA>0 ? round(($EJOiRG/$aJ_IyA)*100,1)."\x25" : "\xe2\x80\x94" ?></span></div>
  </div>

  <!-- Assigned Projects with Entry Links -->
  <?php if (!empty($TqUoDQ)): ?>
  <div class="section-title" style="margin-bottom:12px">Assigned Projects & Entry Links</div>
  <div class="table-wrap" style="margin-bottom:20px">
    <table>
      <thead><tr><th>Project</th><th>SID</th><th>CPI</th><th>Limit</th><th>Status</th><th>Entry Link</th></tr></thead>
      <tbody>
      <?php foreach ($TqUoDQ as $q_0Skx):
        $artpRb = rtrim(str_replace("\x5c", "\x2f", dirname($_SERVER["\x53\x43\x52\x49\x50\x54\x5f\x4e\x41\x4d\x45"])), "\x2f");
        $CpvY3u = (isset($_SERVER["\x48\x54\x54\x50\x53"])?"\x68\x74\x74\x70\x73":"\x68\x74\x74\x70")."\x3a\x2f\x2f".$_SERVER["\x48\x54\x54\x50\x5f\x48\x4f\x53\x54"].$artpRb."/vendor.php?sid={$q_0Skx["\x73\x69\x64"]}&vid={$eI722w["\x69\x64"]}&uid=[UID]";
      ?>
        <tr>
          <td class="td-main"><?= htmlspecialchars($q_0Skx["\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65"]) ?></td>
          <td class="mono"><?= htmlspecialchars($q_0Skx["\x73\x69\x64"]) ?></td>
          <td>$<?= number_format($q_0Skx["\x63\x70\x69"],2) ?></td>
          <td><?= $q_0Skx["\x6d\x61\x78\x5f\x6c\x69\x6d\x69\x74"] ?: "\x55\x6e\x6c\x69\x6d\x69\x74\x65\x64" ?></td>
          <td><span class="pill pill-<?= $q_0Skx["\x73\x74\x61\x74\x75\x73"]==="\x61\x63\x74\x69\x76\x65"?"\x67\x72\x65\x65\x6e":"\x61\x6d\x62\x65\x72" ?>"><?= ucfirst($q_0Skx["\x73\x74\x61\x74\x75\x73"]) ?></span></td>
          <td>
            <button class="btn btn-sm btn-blue" onclick="showEntryLink('<?= htmlspecialchars($eI722w["\x76\x65\x6e\x64\x6f\x72\x5f\x6e\x61\x6d\x65"]) ?>','<?= htmlspecialchars($q_0Skx["\x73\x69\x64"]) ?>','<?= htmlspecialchars($CpvY3u) ?>')">🔗 Entry Link</button>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <!-- Vendor Leads -->
  <div class="section-header">
    <div class="section-title">Leads (<?= count($pwH5Vw) ?>)</div>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>UID</th><th>Project</th><th>Status</th><th>Country</th><th>Device</th><th>LOI</th><th>IP</th><th>Date</th></tr></thead>
      <tbody>
      <?php foreach ($pwH5Vw as $V2tzwf):
        $WHgE3z = ["\x63\x6f\x6d\x70\x6c\x65\x74\x65"=>"\x70\x69\x6c\x6c\x2d\x67\x72\x65\x65\x6e","\x74\x65\x72\x6d\x69\x6e\x61\x74\x65"=>"\x70\x69\x6c\x6c\x2d\x61\x6d\x62\x65\x72","\x6f\x76\x65\x72\x71\x75\x6f\x74\x61"=>"\x70\x69\x6c\x6c\x2d\x62\x6c\x75\x65","\x71\x75\x61\x6c\x69\x74\x79\x5f\x66\x61\x69\x6c"=>"\x70\x69\x6c\x6c\x2d\x72\x65\x64","\x63\x6c\x69\x63\x6b"=>"\x70\x69\x6c\x6c\x2d\x67\x72\x61\x79","\x70\x65\x6e\x64\x69\x6e\x67"=>"\x70\x69\x6c\x6c\x2d\x61\x6d\x62\x65\x72"];
      ?>
        <tr>
          <td class="mono"><?= htmlspecialchars($V2tzwf["\x6f\x72\x69\x67\x69\x6e\x61\x6c\x5f\x75\x69\x64"] ?: "\xe2\x80\x94") ?></td>
          <td>
            <div style="font-size:12px"><?= htmlspecialchars($V2tzwf["\x70\x72\x6f\x6a\x65\x63\x74\x5f\x6e\x61\x6d\x65"] ?: "\xe2\x80\x94") ?></div>
            <div class="mono" style="color:var(--text3)"><?= htmlspecialchars($V2tzwf["\x73\x69\x64"]) ?></div>
          </td>
          <td><span class="pill <?= $WHgE3z[$V2tzwf["\x73\x74\x61\x74\x75\x73"]]??"\x70\x69\x6c\x6c\x2d\x67\x72\x61\x79" ?>"><?= ucfirst(str_replace("\x5f","\x20",$V2tzwf["\x73\x74\x61\x74\x75\x73"])) ?></span></td>
          <td><?= htmlspecialchars($V2tzwf["\x63\x6f\x75\x6e\x74\x72\x79"] ?: "\xe2\x80\x94") ?></td>
          <td><?= htmlspecialchars($V2tzwf["\x64\x65\x76\x69\x63\x65"] ?: "\xe2\x80\x94") ?></td>
          <td><?= $V2tzwf["\x6c\x6f\x69\x5f\x73\x65\x63\x6f\x6e\x64\x73"] ? round($V2tzwf["\x6c\x6f\x69\x5f\x73\x65\x63\x6f\x6e\x64\x73"]/60,1)."\x6d" : "\xe2\x80\x94" ?></td>
          <td class="mono"><?= htmlspecialchars(substr($V2tzwf["\x69\x70"]??"\xe2\x80\x94",0,15)) ?></td>
          <td><?= $V2tzwf["\x63\x72\x65\x61\x74\x65\x64\x5f\x61\x74"] ? date("\x64\x20\x4d\x20\x48\x3a\x69", strtotime($V2tzwf["\x63\x72\x65\x61\x74\x65\x64\x5f\x61\x74"])) : "\xe2\x80\x94" ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($pwH5Vw)): ?>
      <tr><td colspan="8" style="text-align:center;color:var(--text3);padding:24px">No leads yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
  <?php
  
  
  
  if ($G82gPq === "\x6e\x6f\x74\x65\x73"):
    $fKvNwI = $_GET["\x65\x72\x72"] ?? "";
    $QV8Ecw = $_GET["\x6d\x73\x67"] ?? "";
  ?>
  <div style="max-width:720px">
    <?php if ($fKvNwI): ?>
    <div style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);border-radius:8px;padding:10px 16px;font-size:13px;color:#f87171;margin-bottom:16px">⚠ <?= htmlspecialchars($fKvNwI) ?></div>
    <?php endif; ?>
    <?php if ($QV8Ecw): ?>
    <div class="flash">✓ <?= htmlspecialchars($QV8Ecw) ?></div>
    <?php endif; ?>

    <div class="info-card">
      <div class="info-card-title">Notes</div>
      <div style="font-size:12px;color:var(--text3);margin-bottom:14px">A shared notepad for anything important you want to keep track of — reminders, credentials references, to-dos, etc. Visible to anyone logged into this admin panel.</div>
      <form method="POST">
        <input type="hidden" name="action" value="save_notes">
        <textarea name="content" rows="16" style="width:100%;background:var(--bg2);border:1px solid var(--border);border-radius:8px;padding:14px;font-size:13px;color:var(--text1);font-family:'DM Mono',monospace;line-height:1.6;resize:vertical" placeholder="Write anything here..."><?= htmlspecialchars($PUSZz9) ?></textarea>
        <div style="margin-top:14px">
          <button type="submit" class="btn btn-primary">Save Notes</button>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>
  <?php
  
  
  
  if ($G82gPq === "\x63\x68\x61\x6e\x67\x65\x5f\x70\x61\x73\x73\x77\x6f\x72\x64"):
    $_qzQXg = $_GET["\x65\x72\x72"] ?? "";
    $UGFBeD = $_GET["\x6d\x73\x67"] ?? "";
  ?>
  <div style="max-width:480px">
    <?php if ($_qzQXg): ?>
    <div style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);border-radius:8px;padding:10px 16px;font-size:13px;color:#f87171;margin-bottom:16px">⚠ <?= htmlspecialchars($_qzQXg) ?></div>
    <?php endif; ?>
    <?php if ($UGFBeD): ?>
    <div class="flash">✓ <?= htmlspecialchars($UGFBeD) ?></div>
    <?php endif; ?>

    <div class="info-card">
      <div class="info-card-title">Change Your Password</div>
      <form method="POST" style="margin-top:16px">
        <input type="hidden" name="action" value="change_password">
        <div class="form-grid full">
          <div class="field">
            <label>Current Password</label>
            <input type="password" name="current_password" required placeholder="••••••••">
          </div>
          <div class="field">
            <label>New Password</label>
            <input type="password" name="new_password" required placeholder="Min 6 characters">
          </div>
          <div class="field">
            <label>Confirm New Password</label>
            <input type="password" name="confirm_password" required placeholder="Repeat new password">
          </div>
        </div>
        <div style="margin-top:16px">
          <button type="submit" class="btn btn-primary">🔑 Update Password</button>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>

  </div><!-- /content -->
</div><!-- /main -->

<!-- Entry Link Modal -->
<div class="modal-overlay" id="entryLinkModal">
  <div class="modal" style="max-width:480px">
    <button class="modal-close" onclick="closeModal('entryLinkModal')">×</button>
    <div class="modal-title">Entry Link</div>
    <div id="entryLinkVendorName" style="font-size:12px;color:var(--text3);margin-bottom:4px"></div>
    <div id="entryLinkProject" style="font-size:12px;color:var(--text3);margin-bottom:16px"></div>
    <div class="url-box">
      <div class="url-val" id="entryLinkUrl"></div>
    </div>
    <button class="btn btn-primary" style="margin-top:12px;width:100%" onclick="copyText(document.getElementById('entryLinkUrl').textContent)">Copy Link</button>
  </div>
</div>

<!-- ── MODALS ── -->

<!-- Project Modal -->
<div class="modal-overlay" id="modalProject">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('modalProject')">×</button>
    <div class="modal-title" id="modalProjectTitle">Add Project</div>
    <form method="POST">
      <input type="hidden" name="action" value="save_project">
      <input type="hidden" name="id" id="proj_id" value="">
      <div class="form-grid">
        <div class="field"><label>Project ID (SID)</label><input type="text" name="sid" id="proj_sid" placeholder="e.g. RP001" required></div>
        <div class="field"><label>Project Name</label><input type="text" name="project_name" id="proj_name" required></div>
        <div class="field"><label>Client</label>
          <select name="client_id" id="proj_client">
            <option value="">-- Select Client --</option>
            <?php foreach ($u6VvlJ as $vVKgZj): ?>
            <option value="<?= $vVKgZj["\x69\x64"] ?>"><?= htmlspecialchars($vVKgZj["\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65"]) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field"><label>Status</label>
          <select name="status" id="proj_status">
            <option value="active">Active</option>
            <option value="paused">Paused</option>
            <option value="closed">Closed</option>
          </select>
        </div>
        <div class="field"><label>CPI ($)</label><input type="number" name="cpi" id="proj_cpi" step="0.01" value="0"></div>
        <div class="field"><label>IR (%)</label><input type="number" name="ir" id="proj_ir" step="0.1" value="0"></div>
        <div class="field"><label>LOI (minutes)</label><input type="number" name="loi" id="proj_loi" value="0"></div>
        <div class="field"><label>Max Completes</label><input type="number" name="max_completes" id="proj_max" value="0"></div>
        <div class="field"><label>Project Type</label>
          <select name="project_type" id="proj_type">
            <option value="direct">Direct</option>
            <option value="thirdparty">Third Party</option>
          </select>
        </div>
        <div class="field" style="align-items:center;justify-content:center;flex-direction:row;gap:10px;padding-top:20px">
          <input type="checkbox" name="encrypt_uid" id="proj_enc" value="1" style="width:auto">
          <label for="proj_enc" style="text-transform:none;font-size:13px;color:var(--text2)">Encrypt UID</label>
        </div>
        <div class="field span2"><label>Live Survey URL</label><input type="text" name="live_url" id="proj_live" placeholder="https://..."></div>
        <div class="field span2"><label>Test Survey URL</label><input type="text" name="test_url" id="proj_test" placeholder="https://..."></div>
        <div class="field span2"><label>Description / Study Parameters</label><textarea name="description" id="proj_desc"></textarea></div>
      </div>
      <div style="margin-top:16px;display:flex;gap:10px">
        <button type="submit" class="btn btn-primary">Save Project</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('modalProject')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Client Modal -->
<div class="modal-overlay" id="modalClient">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('modalClient')">×</button>
    <div class="modal-title" id="modalClientTitle">Add Client</div>
    <form method="POST">
      <input type="hidden" name="action" value="save_client">
      <input type="hidden" name="id" id="cl_id" value="">
      <div class="form-grid">
        <div class="field span2"><label>Client Name</label><input type="text" name="client_name" id="cl_name" required></div>
        <div class="field"><label>Email</label><input type="email" name="email" id="cl_email"></div>
        <div class="field"><label>Phone</label><input type="text" name="phone" id="cl_phone"></div>
        <div class="field span2"><label>Company</label><input type="text" name="company" id="cl_company"></div>
        <div class="field"><label>Status</label>
          <select name="status" id="cl_status">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div style="margin-top:16px;display:flex;gap:10px">
        <button type="submit" class="btn btn-primary">Save Client</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('modalClient')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Vendor Modal -->
<div class="modal-overlay" id="modalVendor">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('modalVendor')">×</button>
    <div class="modal-title">Add / Edit Vendor</div>
    <form method="POST">
      <input type="hidden" name="action" value="save_vendor">
      <input type="hidden" name="id" id="vn_id" value="">
      <div class="form-grid">
        <div class="field span2"><label>Vendor Name</label><input type="text" name="vendor_name" id="vn_name" required></div>
        <div class="field"><label>Email</label><input type="email" name="email" id="vn_email"></div>
        <div class="field"><label>Phone</label><input type="text" name="phone" id="vn_phone"></div>
        <div class="field span2"><label>Complete URL</label><input type="text" name="complete_url" id="vn_complete"></div>
        <div class="field span2"><label>Terminate URL</label><input type="text" name="terminate_url" id="vn_terminate"></div>
        <div class="field span2"><label>Screenout URL</label><input type="text" name="screenout_url" id="vn_screenout"></div>
        <div class="field span2"><label>Quotafull URL</label><input type="text" name="quotafull_url" id="vn_quotafull"></div>
        <div class="field span2"><label>End Page Behavior <span style="font-weight:400;color:var(--text3)">(what a respondent sees after complete/terminate/etc.)</span></label>
          <select name="end_behavior" id="vn_end_behavior">
            <option value="show_page">Show our confirmation page (recommended) — vendor is notified silently in the background</option>
            <option value="redirect">Redirect respondent straight to the vendor's own page (uses the URLs above)</option>
          </select>
        </div>
        <div class="field"><label>Status</label>
          <select name="status" id="vn_status">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div style="margin-top:16px;display:flex;gap:10px">
        <button type="submit" class="btn btn-primary">Save Vendor</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('modalVendor')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>
// ── Modal helpers ──
function openModal(id, data) {
  document.getElementById(id).classList.add('open');
  if (id === 'modalProject') {
    document.getElementById('modalProjectTitle').textContent = data.id ? 'Edit Project' : 'Add Project';
    document.getElementById('proj_id').value    = data.id || '';
    document.getElementById('proj_sid').value   = data.sid || '';
    document.getElementById('proj_name').value  = data.project_name || '';
    document.getElementById('proj_cpi').value   = data.cpi || '0';
    document.getElementById('proj_ir').value    = data.ir || '0';
    document.getElementById('proj_loi').value   = data.loi || '0';
    document.getElementById('proj_max').value   = data.max_completes || '0';
    document.getElementById('proj_live').value  = data.live_url || '';
    document.getElementById('proj_test').value  = data.test_url || '';
    document.getElementById('proj_desc').value  = data.description || '';
    document.getElementById('proj_enc').checked = data.encrypt_uid == 1;
    if (data.status) document.getElementById('proj_status').value = data.status;
    if (data.project_type) document.getElementById('proj_type').value = data.project_type;
    if (data.client_id) document.getElementById('proj_client').value = data.client_id;
  }
  if (id === 'modalClient') {
    document.getElementById('modalClientTitle').textContent = data.id ? 'Edit Client' : 'Add Client';
    document.getElementById('cl_id').value      = data.id || '';
    document.getElementById('cl_name').value    = data.client_name || '';
    document.getElementById('cl_email').value   = data.email || '';
    document.getElementById('cl_phone').value   = data.phone || '';
    document.getElementById('cl_company').value = data.company || '';
    if (data.status) document.getElementById('cl_status').value = data.status;
  }
  if (id === 'modalVendor') {
    document.getElementById('vn_id').value        = data.id || '';
    document.getElementById('vn_name').value      = data.vendor_name || '';
    document.getElementById('vn_email').value     = data.email || '';
    document.getElementById('vn_phone').value     = data.phone || '';
    document.getElementById('vn_complete').value  = data.complete_url || '';
    document.getElementById('vn_terminate').value = data.terminate_url || '';
    document.getElementById('vn_screenout').value = data.screenout_url || '';
    document.getElementById('vn_quotafull').value = data.quotafull_url || '';
    document.getElementById('vn_end_behavior').value = data.end_behavior || 'show_page';
    if (data.status) document.getElementById('vn_status').value = data.status;
  }
}

function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

// Modals only close via the X button, Cancel button, or successful Save — accidental backdrop clicks no longer dismiss them.

// ── Entry Link Modal ──
function showEntryLink(vendor, sid, url) {
  document.getElementById('entryLinkVendorName').textContent = vendor;
  document.getElementById('entryLinkProject').textContent = 'Project: ' + sid;
  document.getElementById('entryLinkUrl').textContent = url;
  document.getElementById('entryLinkModal').classList.add('open');
}

// ── Copy helper ──
function copyText(text) {
  navigator.clipboard.writeText(text).then(() => {
    const btn = event.target;
    const orig = btn.textContent;
    btn.textContent = 'Copied!';
    btn.style.background = 'rgba(34,197,94,0.2)';
    btn.style.color = '#22c55e';
    setTimeout(() => { btn.textContent = orig; btn.style.background=''; btn.style.color=''; }, 1500);
  });
}
</script>

</body>
</html>
