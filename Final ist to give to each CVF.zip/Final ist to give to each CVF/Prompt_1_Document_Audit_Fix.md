# PROMPT 1 — Document Audit & Fix (paste this as-is)

I'm attaching a zip file containing multiple business documents for my company (contracts, forms, marketing materials, rate cards, etc. — could be PDF, DOCX, or HTML). I need you to audit ALL of them together and fix issues before I send them out. Please do the following:

## Company facts (edit this section with your real details before pasting)
- Company name: [YOUR COMPANY NAME]
- We are NOT a certified/registered member of any industry body (e.g. ESOMAR, ISO, MRSI, or others) — we only voluntarily follow their guidelines/principles.
- Our actual certifications/memberships (if any): [LIST REAL ONES, OR WRITE "NONE AT PRESENT"]
- Our proprietary system/product names (so you can check consistent branding across docs): [E.G. "ExaVerify" for our QC process]
- Any other facts you should treat as ground truth: [ADD HERE]

## What to check across EVERY document, and across documents together
1. **False certification/membership claims**: Search for words like "Member", "Certified", "Compliant", "Accredited", "operates in compliance with", "holds certifications", "fully adheres". Anywhere these imply formal membership/certification we don't actually have, soften to honest language like "voluntarily aligned with X (not a registered member)" or "X planned as we scale." Do NOT just remove the mention — replace it with an honest, still-professional version.
2. **Branding/naming consistency**: If we have a proprietary process/tool name, check every document uses the SAME name for it. Flag and fix any document using a different name for the same thing.
3. **Cross-document contradictions**: Read every document as if they'll all be seen by the same recipient. Specifically check:
   - Do any two documents disagree on who owns data/deliverables/IP?
   - Do any two documents disagree on payment terms, confidentiality duration, or governing law?
   - Does any document reference the wrong company name (e.g., leftover text from a template that was copy-pasted from a different client/vendor)?
4. **Confidentiality/distribution labels**: Check if any document is marked "internal use only," "do not share externally," "BD use only," etc. If I've told you it's meant to go to an external party, flag this and offer to soften the label rather than silently sending internal-marked material outside.
5. **Placeholder/template leftovers**: Find any unfilled placeholder text (e.g. "e.g. ...", "[Client Name]", "TBD", empty signature blocks, mm/dd/yyyy) in documents that are meant to be final/signed. List everything still blank so I know what I still need to provide.
6. **Typos and formatting**: Fix any obvious typos, duplicated words, or broken layout from template use.
7. **Numbers/claims sanity check**: If any document states figures (panel size, years in business, team size, etc.) that seem inconsistent with other documents or with how new/small the company is, flag it for me to confirm rather than assuming it's correct.

## How to work
- Go through every file in the zip one by one, then do a final cross-document pass specifically hunting for contradictions between files.
- When editing PDFs with custom/designed layouts, don't just visually cover old text — make sure the underlying text is actually replaced (not just hidden), and re-render/screenshot each edited page so I can visually confirm nothing broke.
- For anything ambiguous (e.g., "is this claim true or not?", "which number is correct?"), ask me rather than guessing.
- At the end, give me a clean summary table: file name → what was changed → what still needs my input.

Attached: [ZIP FILE]
