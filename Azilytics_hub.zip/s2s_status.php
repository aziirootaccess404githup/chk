<?php
// ============================================================
// PanelEngine Survey Panel — s2s_status.php
// Inbound Server-to-Server (S2S) status API.
//
// POST /s2s_status.php
// Header: Authorization: Bearer <vendor's s2s_inbound_api_key>
// Body (JSON): { "respondent_id": "...", "status": "complete" }
//
// This is the "we act as the client/hub, a vendor's own server calls
// us" direction — the mirror image of client_redirect.php's vendor-
// postback mechanism (which fires when WE report OUT to a vendor).
// Genuinely reuses the exact same status_aliases map client_redirect.php
// already uses, so a status this endpoint doesn't recognize becomes
// 'unmatched' here too — never silently counted as complete.
// ============================================================
require_once __DIR__ . '/config.php';

header('Content-Type: application/json');
$db = rp_db();

// ── Authenticate via Bearer token ──────────────────────────────
$headers = getallheaders();
$auth = $headers['Authorization'] ?? $headers['authorization'] ?? '';
$token = null;
if (preg_match('/^Bearer\s+(.+)$/i', trim($auth), $m)) {
    $token = trim($m[1]);
}

if (!$token) {
    http_response_code(401);
    echo json_encode(['error' => 'Missing Authorization: Bearer <token> header.']);
    exit;
}

try { $db->exec("ALTER TABLE rp_vendors ADD COLUMN s2s_inbound_api_key VARCHAR(80) DEFAULT NULL"); } catch (PDOException $e) {}

$vs = $db->prepare("SELECT id, vendor_name, status FROM rp_vendors WHERE s2s_inbound_api_key = ? LIMIT 1");
$vs->execute([$token]);
$vendor = $vs->fetch();

if (!$vendor) {
    http_response_code(401);
    echo json_encode(['error' => 'Invalid or unrecognized API token.']);
    exit;
}
if (($vendor['status'] ?? 'active') !== 'active') {
    http_response_code(403);
    echo json_encode(['error' => 'This vendor account is not currently active.']);
    exit;
}

// ── Parse the JSON body ─────────────────────────────────────────
$raw = file_get_contents('php://input');
$body = json_decode($raw, true);
if (!is_array($body)) {
    http_response_code(400);
    echo json_encode(['error' => 'Request body must be valid JSON.']);
    exit;
}

$respondent_id = trim($body['respondent_id'] ?? $body['uid'] ?? $body['pid'] ?? '');
$raw_status = trim($body['status'] ?? '');

if (!$respondent_id) {
    http_response_code(400);
    echo json_encode(['error' => 'respondent_id is required.']);
    exit;
}

// Same status_aliases map as client_redirect.php — anything unrecognized
// becomes 'unmatched', never silently 'complete'.
$status_aliases = [
    'complete'      => 'complete',      'success'   => 'complete',   'completed' => 'complete',
    'terminate'     => 'terminate',     'terminated'=> 'terminate',  'term'      => 'terminate',
    'overquota'     => 'overquota',     'quotafull' => 'overquota',  'quota_full'=> 'overquota', 'full' => 'overquota',
    'quality_fail'  => 'quality_fail',  'qc'        => 'quality_fail','quality'  => 'quality_fail',
    'screenout'     => 'quality_fail',  'screened_out' => 'quality_fail', 'disqualified' => 'quality_fail',
];
$status_key = strtolower($raw_status);
$status = $status_aliases[$status_key] ?? 'unmatched';
$is_unmatched = ($status === 'unmatched');

// ── Find the matching lead — scoped to THIS vendor, so one vendor's
// API key can never touch another vendor's records ─────────────
$rs = $db->prepare("SELECT id, status, status_locked, sid FROM rp_leads WHERE (original_uid = ? OR encrypted_uid = ?) AND vendor_id = ? ORDER BY id DESC LIMIT 1");
$rs->execute([$respondent_id, $respondent_id, $vendor['id']]);
$existing = $rs->fetch();

if (!$existing) {
    http_response_code(404);
    echo json_encode(['error' => 'No matching entry found for this respondent_id under your vendor account. The respondent must have entered through your own entry-link first.']);
    exit;
}

if ($existing['status_locked']) {
    echo json_encode(['respondent_id' => $respondent_id, 'status' => $existing['status'], 'note' => 'Already locked to a final status — no change made.']);
    exit;
}

$lock_value = $is_unmatched ? 0 : 1;
$db->prepare("UPDATE rp_leads SET status=?, status_locked=?, end_time=NOW() WHERE id=?")
   ->execute([$status, $lock_value, $existing['id']]);

echo json_encode(['respondent_id' => $respondent_id, 'status' => $status, 'received_at' => date('c')]);
