<?php
// ============================================================
// Exazon Research — vendor_view.php
// Full Vendor Detail page: stats, redirect URLs, assigned
// projects, recent leads, pause/activate, edit.
// Mirrors project_view.php's pattern/layout for consistency.
// ============================================================
session_start();
require_once __DIR__ . '/inc_exz.php';

// ── AUTH (reuse index.php's session gates — no separate login here) ──
if (empty($_SESSION['ex_auth']) || empty($_SESSION['ex_team_id'])) {
    header('Location: index.php'); exit;
}

$db = exz_db();
$vid = intval($_GET['vid'] ?? 0);
if (!$vid) { header('Location: index.php#vendors'); exit; }

$msg = '';

// ── ACTIONS ─────────────────────────────────────────────────
if (isset($_GET['toggle_vendor'])) {
    $cur = $db->prepare("SELECT status FROM exz_vendors WHERE id=?"); $cur->execute([$vid]);
    $now = $cur->fetchColumn();
    $next = ($now === 'inactive') ? 'active' : 'inactive';
    $db->prepare("UPDATE exz_vendors SET status=? WHERE id=?")->execute([$next, $vid]);
    exz_log_audit($db, 'toggle_vendor', "Vendor ID: $vid -> $next");
    header("Location: vendor_view.php?vid=$vid"); exit;
}
if (isset($_POST['generate_s2s_key'])) {
    try { $db->exec("ALTER TABLE exz_vendors ADD COLUMN s2s_inbound_api_key VARCHAR(80) DEFAULT NULL"); } catch (PDOException $e) {}
    $newKey = 's2s_' . bin2hex(random_bytes(24));
    $db->prepare("UPDATE exz_vendors SET s2s_inbound_api_key=? WHERE id=?")->execute([$newKey, $vid]);
    exz_log_audit($db, 'generate_s2s_key', "Vendor ID: $vid");
    header("Location: vendor_view.php?vid=$vid#s2s"); exit;
}
if (isset($_POST['save_vendor_edit'])) {
    $name    = trim($_POST['ve_name'] ?? '');
    $contact = trim($_POST['ve_contact'] ?? '');
    $email   = trim($_POST['ve_email'] ?? '');
    $phone   = trim($_POST['ve_phone'] ?? '');
    $curl    = trim($_POST['ve_complete_url'] ?? '');
    $turl    = trim($_POST['ve_terminate_url'] ?? '');
    $surl    = trim($_POST['ve_screenout_url'] ?? '');
    $qurl    = trim($_POST['ve_quotafull_url'] ?? '');
    $notes   = trim($_POST['ve_notes'] ?? '');
    $db->prepare("UPDATE exz_vendors SET vendor_name=?,contact_person=?,email=?,phone=?,complete_url=?,terminate_url=?,screenout_url=?,quotafull_url=?,notes=? WHERE id=?")
        ->execute([$name,$contact,$email,$phone,$curl,$turl,$surl,$qurl,$notes,$vid]);
    exz_log_audit($db, 'edit_vendor', "Vendor ID: $vid");
    header("Location: vendor_view.php?vid=$vid&msg=".urlencode('Vendor updated')); exit;
}
if (isset($_GET['unassign_project'])) {
    $db->prepare("DELETE FROM exz_project_vendors WHERE vendor_id=? AND survey_id=?")->execute([$vid, $_GET['unassign_project']]);
    header("Location: vendor_view.php?vid=$vid"); exit;
}
if (isset($_GET['msg'])) $msg = $_GET['msg'];

// ── VENDOR DATA ───────────────────────────────────────────────
$vp = $db->prepare("SELECT * FROM exz_vendors WHERE id=? LIMIT 1");
$vp->execute([$vid]);
$vendor = $vp->fetch();
if (!$vendor) { header('Location: index.php#vendors'); exit; }

// ── STATS (aggregate across ALL projects this vendor is on) ───
$st = $db->prepare("SELECT COUNT(*) as total, SUM(status='complete') as completes, SUM(status='terminate') as terminates
    FROM survey_responses WHERE vendor_id=?");
$st->execute([$vid]);
$stats = $st->fetch();
$total = (int)($stats['total'] ?? 0);
$completes = (int)($stats['completes'] ?? 0);
$terminates = (int)($stats['terminates'] ?? 0);
$conv = $total > 0 ? round($completes / $total * 100, 1) : 0;

// ── VENDOR SCORECARD — aggregates existing Quality Score / Fraud /
// Reconcile data, grouped by this vendor instead of by project. No new
// data collection — just re-running the same logic already used
// elsewhere, scoped to vendor_id=$vid. ──────────────────────────
define('SC_SPD_LIMIT', 180);
$sc_date_from = trim($_GET['sc_from'] ?? '');
$sc_date_to   = trim($_GET['sc_to'] ?? '');
$sc_where = "vendor_id=?";
$sc_params = [$vid];
if ($sc_date_from) { $sc_where .= " AND created_at >= ?"; $sc_params[] = $sc_date_from.' 00:00:00'; }
if ($sc_date_to)   { $sc_where .= " AND created_at <= ?"; $sc_params[] = $sc_date_to.' 23:59:59'; }

$sc_rows = [];
try {
    $sc = $db->prepare("SELECT status, is_duplicate, loi_seconds, device, country, ip, survey_id, created_at
        FROM survey_responses WHERE $sc_where");
    $sc->execute($sc_params);
    $sc_rows = $sc->fetchAll();
} catch (Exception $e) {}

$sc_total = count($sc_rows);
$sc_completes = 0; $sc_dupes = 0; $sc_loi_sum = 0; $sc_loi_n = 0;
$sc_quality_sum = 0;
foreach ($sc_rows as $r) {
    if ($r['status'] === 'complete') $sc_completes++;
    if (!empty($r['is_duplicate'])) $sc_dupes++;
    if (!empty($r['loi_seconds']) && $r['loi_seconds'] > 0) { $sc_loi_sum += $r['loi_seconds']; $sc_loi_n++; }
    // Same calcScore() logic as quality_score.php, kept in sync deliberately
    $score = 100;
    $loi = intval($r['loi_seconds'] ?? 0);
    if ($loi > 0 && $loi < SC_SPD_LIMIT) $score -= 40;
    elseif ($loi === 0 || $loi === null) $score -= 10;
    if (!empty($r['is_duplicate'])) $score -= 30;
    if (empty($r['device'])) $score -= 5;
    if (empty($r['country'])) $score -= 5;
    if ($r['status'] === 'qc' || $r['status'] === 'quality') $score -= 15;
    $sc_quality_sum += max(0, min(100, $score));
}
$sc_ir = $sc_total > 0 ? round($sc_completes / $sc_total * 100, 1) : 0;
$sc_avg_quality = $sc_total > 0 ? round($sc_quality_sum / $sc_total, 1) : 0;
$sc_avg_loi = $sc_loi_n > 0 ? round($sc_loi_sum / $sc_loi_n) : null;

// Fraud flag rate — duplicates + same-IP-with-another-UID hits, scoped to this vendor
$sc_same_ip_flagged = 0;
try {
    $sip = $db->prepare("SELECT COUNT(DISTINCT ip) FROM (
        SELECT ip FROM survey_responses WHERE $sc_where AND ip IS NOT NULL AND ip<>''
        GROUP BY ip, survey_id HAVING COUNT(DISTINCT respondent) > 1
    ) t");
    $sip->execute($sc_params);
    $sc_same_ip_flagged = (int)$sip->fetchColumn();
} catch (Exception $e) {}
$sc_fraud_flagged = $sc_dupes + $sc_same_ip_flagged;
$sc_fraud_rate = $sc_total > 0 ? round($sc_fraud_flagged / $sc_total * 100, 1) : 0;

// Reconcile mismatch — reconcile_records is PROJECT-level, not vendor-level,
// so on a multi-vendor project we can only ESTIMATE this vendor's share —
// proportional to their share of that project's completes. Clearly labelled
// as an estimate in the UI below, not treated as an exact figure.
$sc_reconcile_est = 0; $sc_reconcile_n = 0;
try {
    $vendor_proj_completes = $db->prepare("SELECT survey_id, COUNT(*) as vc FROM survey_responses
        WHERE vendor_id=? AND status='complete' GROUP BY survey_id");
    $vendor_proj_completes->execute([$vid]);
    foreach ($vendor_proj_completes->fetchAll() as $vpc) {
        $rec = $db->prepare("SELECT difference, our_completes FROM reconcile_records WHERE project_id=? ORDER BY created_at DESC LIMIT 1");
        $rec->execute([$vpc['survey_id']]);
        $recRow = $rec->fetch();
        if (!$recRow || empty($recRow['our_completes'])) continue;
        $share = $vpc['vc'] / max(1, $recRow['our_completes']);
        $sc_reconcile_est += $recRow['difference'] * $share;
        $sc_reconcile_n++;
    }
} catch (Exception $e) {}

// On-time delivery — for this vendor's assigned projects with an end_date,
// did the PROJECT (overall, not vendor-isolated — target is per-project)
// hit its target by that date?
$sc_ontime = 0; $sc_ontime_total = 0;
try {
    $otp = $db->prepare("SELECT ps.survey_id, ps.target, ps.end_date,
        (SELECT COUNT(*) FROM survey_responses WHERE survey_id=ps.survey_id AND status='complete') as done
        FROM exz_project_vendors pv JOIN project_settings ps ON ps.survey_id=pv.survey_id
        WHERE pv.vendor_id=? AND ps.end_date IS NOT NULL AND ps.end_date <= CURDATE()");
    $otp->execute([$vid]);
    foreach ($otp->fetchAll() as $op) {
        $sc_ontime_total++;
        if (!empty($op['target']) && $op['done'] >= $op['target']) $sc_ontime++;
    }
} catch (Exception $e) {}
$sc_ontime_pct = $sc_ontime_total > 0 ? round($sc_ontime / $sc_ontime_total * 100, 1) : null;

// ── SCORECARD CSV EXPORT ─────────────────────────────────────
if (isset($_GET['export_scorecard'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="vendor_scorecard_'.preg_replace('/[^a-zA-Z0-9]/','_',$vendor['vendor_name']).'_'.date('Ymd').'.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Metric', 'Value']);
    fputcsv($out, ['Vendor', $vendor['vendor_name']]);
    fputcsv($out, ['Date Range', ($sc_date_from ?: 'All time').' to '.($sc_date_to ?: 'now')]);
    fputcsv($out, ['Total Completes (in range)', $sc_completes]);
    fputcsv($out, ['Overall IR %', $sc_ir]);
    fputcsv($out, ['Fraud Flag Rate %', $sc_fraud_rate]);
    fputcsv($out, ['Avg Quality Score /100', $sc_avg_quality]);
    fputcsv($out, ['Avg LOI (sec)', $sc_avg_loi ?? 'N/A']);
    fputcsv($out, ['Reconcile Mismatch (est.)', $sc_reconcile_n > 0 ? $sc_reconcile_est : 'N/A']);
    fputcsv($out, ['On-Time Delivery %', $sc_ontime_pct ?? 'N/A']);
    fclose($out);
    exit;
}

// ── ASSIGNED PROJECTS ───────────────────────────────────────
$assigned_projects = [];
try {
    $ap = $db->prepare("SELECT ps.*, pv.status AS pv_status, pv.cpi AS pv_cpi, pv.max_limit AS pv_limit, pv.assigned_at
        FROM exz_project_vendors pv
        JOIN project_settings ps ON ps.survey_id = pv.survey_id
        WHERE pv.vendor_id=? ORDER BY pv.assigned_at DESC");
    $ap->execute([$vid]);
    $assigned_projects = $ap->fetchAll();
} catch (Exception $e) {}

// ── RECENT LEADS (this vendor, across all projects) ──────────
// Search/filter - by status (Complete/Terminate/Quotafull/etc) and/or by
// respondent UID, scoped to just this vendor's own leads.
$vv_status = trim($_GET['vstatus'] ?? '');
$vv_search = trim($_GET['vsearch'] ?? '');
$recent_leads = [];
try {
    $vv_where = 'sr.vendor_id=?';
    $vv_params = [$vid];
    if ($vv_status) { $vv_where .= ' AND sr.status=?'; $vv_params[] = $vv_status; }
    if ($vv_search) { $vv_where .= ' AND (sr.respondent LIKE ? OR um.original_uid LIKE ?)'; $vv_params[] = "%$vv_search%"; $vv_params[] = "%$vv_search%"; }
    $rl = $db->prepare("SELECT sr.respondent, sr.status, sr.survey_id, sr.country, sr.device, sr.loi_seconds, sr.ip, sr.created_at, um.original_uid
        FROM survey_responses sr
        LEFT JOIN exz_uid_mapping um ON um.encrypted_uid = sr.respondent AND um.survey_id = sr.survey_id
        WHERE $vv_where ORDER BY sr.created_at DESC LIMIT 200");
    $rl->execute($vv_params);
    $recent_leads = $rl->fetchAll();
} catch (Exception $e) {}

$host = $_SERVER['HTTP_HOST'];
function fmt_loi_vv($sec){ if($sec===null) return '—'; $sec=(int)$sec; return sprintf('%dm %ds', intdiv($sec,60), $sec%60); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Vendor Details — <?= htmlspecialchars($vendor['vendor_name']) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --navy:#0a1628;--navy2:#112040;--blue:#1b4fd8;--blue2:#3b82f6;
  --gold:#c8a84b;--muted:#94a3b8;--green:#22c55e;--red:#ef4444;--yellow:#f59e0b;--purple:#8b5cf6;
}
body{font-family:'DM Sans',sans-serif;background:#f4f6fb;color:#0f172a;margin:0}

/* SIDEBAR LAYOUT (matches index.php) */
.app-layout{display:flex;min-height:100vh}
.sidebar{width:250px;flex-shrink:0;background:var(--navy);border-right:1px solid rgba(59,130,246,0.15);
         position:fixed;top:0;left:0;bottom:0;overflow-y:auto;overflow-x:hidden;z-index:200;padding:20px 14px;
         transition:width .2s ease}
.sidebar.collapsed{width:60px}
.sidebar.collapsed:hover{width:250px}
.sidebar-toggle{position:absolute;top:18px;right:10px;background:rgba(255,255,255,0.08);border:none;color:var(--muted);
                 width:22px;height:22px;border-radius:6px;cursor:pointer;font-size:12px;line-height:1;z-index:5}
.sidebar.collapsed .sidebar-brand,.sidebar.collapsed .sidebar-user,.sidebar.collapsed .sidebar-section-lbl{opacity:0;transition:opacity .1s}
.sidebar.collapsed:hover .sidebar-brand,.sidebar.collapsed:hover .sidebar-user,
.sidebar.collapsed:hover .sidebar-section-lbl{opacity:1}
.sidebar.collapsed .sb-link{overflow:hidden}
.sidebar.collapsed:hover .sb-link{overflow:visible}
.app-content{flex:1;margin-left:250px;min-width:0;transition:margin-left .2s ease}
.app-content.sidebar-collapsed{margin-left:60px}
.sidebar-brand{display:flex;align-items:center;gap:10px;padding:0 6px 18px;border-bottom:1px solid rgba(255,255,255,0.08);margin-bottom:16px;white-space:nowrap}
.sidebar .nav-logo{width:34px;height:34px;border-radius:50%;border:2px solid rgba(59,130,246,0.3);background:#fff;flex-shrink:0}
.sidebar .nav-name{font-family:'Bebas Neue',sans-serif;font-size:15px;letter-spacing:2px;color:#fff;line-height:1.2}
.sidebar .nav-tag{font-size:8px;letter-spacing:2px;text-transform:uppercase;color:var(--gold)}
.sidebar-user{padding:0 6px 16px;margin-bottom:10px;white-space:nowrap}
.sidebar-user-name{font-size:12px;font-weight:700;color:#fff}
.sidebar-user-role{font-size:9px;letter-spacing:1px;text-transform:uppercase;color:var(--gold)}
.sidebar-section-lbl{font-size:9px;letter-spacing:2px;text-transform:uppercase;color:rgba(255,255,255,0.25);padding:14px 6px 6px;white-space:nowrap}
.sb-link{display:flex;align-items:center;gap:8px;width:100%;text-align:left;padding:9px 10px;font-size:12px;font-weight:600;
         color:var(--muted);background:none;border:none;border-radius:8px;cursor:pointer;white-space:nowrap;transition:all .15s;text-decoration:none;box-sizing:border-box}
.sb-link.active,.sb-link:hover{color:#fff;background:rgba(59,130,246,0.15)}
@media(max-width:900px){
  .sidebar{position:static;width:100%;height:auto;display:flex;flex-wrap:wrap}
  .app-content{margin-left:0}
}

.topbar{background:var(--navy);padding:14px 28px;display:flex;align-items:center;justify-content:space-between}
.topbar-title{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:2px;color:#fff}
.content{max-width:1200px;margin:0 auto;padding:24px 20px}
.msg-banner{background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);color:#15803d;border-radius:8px;padding:12px 16px;font-size:13px;margin-bottom:18px}
.btn{display:inline-flex;align-items:center;gap:6px;padding:9px 18px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;border:none;text-decoration:none}
.btn-ghost{background:#fff;color:#374151;border:1px solid #e2e8f0}
.btn-amber{background:linear-gradient(135deg,#f59e0b,#d97706);color:#fff}
.btn-green{background:linear-gradient(135deg,#16a34a,#22c55e);color:#fff}
.btn-blue{background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff}
.btn-red{background:rgba(239,68,68,.12);color:#dc2626}
.stat-row{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:18px 0}
.stat-card{background:#fff;border-radius:12px;padding:18px;border-top:4px solid var(--blue2)}
.stat-card.green{border-top-color:var(--green)}
.stat-card.orange{border-top-color:var(--yellow)}
.stat-card.purple{border-top-color:var(--purple)}
.stat-card.blue{border-top-color:var(--blue2)}
.stat-lbl{font-size:11px;letter-spacing:1px;text-transform:uppercase;color:var(--muted);margin-bottom:8px}
.stat-val{font-size:32px;font-weight:700}
.card{background:#fff;border-radius:12px;padding:20px;margin-bottom:18px;border:1px solid #e5e9f2}
.card-title{font-size:11px;letter-spacing:1.5px;text-transform:uppercase;color:var(--muted);font-weight:700;margin-bottom:14px}
.info-row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f3f9;font-size:13px}
.info-row:last-child{border-bottom:none}
.info-row span:first-child{color:var(--muted)}
.info-row span:last-child{font-weight:600}
.pill{display:inline-block;padding:3px 12px;border-radius:20px;font-size:11px;font-weight:700}
.pill-complete{background:rgba(34,197,94,.12);color:#15803d}
.pill-terminate{background:rgba(245,158,11,.12);color:#b45309}
.pill-quotafull{background:rgba(59,130,246,.12);color:#1e40af}
.pill-qc,.pill-quality{background:rgba(239,68,68,.12);color:#b91c1c}
.pill-active{background:rgba(34,197,94,.12);color:#15803d}
.pill-inactive{background:rgba(148,163,184,.15);color:#64748b}
.url-row{margin-bottom:14px}
.url-box{display:flex;gap:8px;align-items:center;background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-family:monospace;font-size:11px;color:#334155;word-break:break-all}
.url-box button{flex-shrink:0;background:#e2e8f0;border:none;border-radius:6px;padding:5px 10px;font-size:11px;font-weight:600;cursor:pointer}
table{width:100%;border-collapse:collapse}
th{padding:8px 10px;font-size:10px;background:#f8faff;text-align:left;color:var(--muted);text-transform:uppercase;letter-spacing:.5px}
td{padding:8px 10px;font-size:12px;border-top:1px solid #f1f3f9}
textarea{width:100%;background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-family:'DM Sans',sans-serif;font-size:13px;min-height:80px;resize:vertical}
select,input[type=text]{background:#f8faff;border:1px solid #e2e8f0;border-radius:6px;padding:6px 10px;font-size:12px}
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:200;align-items:center;justify-content:center}
.modal-overlay.open{display:flex}
.modal{background:#fff;border-radius:16px;padding:26px;max-width:520px;width:90%;max-height:85vh;overflow-y:auto}
.modal-field{margin-bottom:12px}
.modal-field .lbl{font-size:10px;font-weight:600;color:#64748b;letter-spacing:1px;text-transform:uppercase;margin-bottom:4px}
.modal-field input[type=text],.modal-field input[type=number],.modal-field select,.modal-field textarea{width:100%;background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:12px;font-family:'DM Sans',sans-serif;outline:none}
.modal-field textarea{resize:vertical;min-height:60px}
</style>
</head>
<body>

<div class="app-layout">
<aside class="sidebar" id="appSidebar">
  <button class="sidebar-toggle" onclick="toggleSidebar()" title="Collapse/Expand sidebar">☰</button>
  <div class="sidebar-brand">
    <img src="logo.php" class="nav-logo" alt="ExaVerify">
    <div>
      <div class="nav-name">Exazon Research</div>
      <div class="nav-tag">Survey Dashboard v5</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="sidebar-user-name"><?= htmlspecialchars($_SESSION['ex_team_name'] ?? '') ?></div>
    <div class="sidebar-user-role"><?= htmlspecialchars($_SESSION['ex_team_role'] ?? '') ?></div>
  </div>

  <div class="sidebar-section-lbl">Main</div>
  <a class="sb-link" href="index.php#overview">📊 Dashboard</a>
  <a class="sb-link" href="index.php#createproject">➕ Create Project</a>
  <a class="sb-link" href="index.php#projects">📁 All Projects</a>
  <a class="sb-link" href="index.php#responses">📋 Leads</a>
  <a class="sb-link" href="index.php#fraud">🚨 Fraud Detection</a>
  <a class="sb-link" href="index.php#screener">📄 Screener Data</a>
  <a class="sb-link" href="index.php#searchlookup">🔍 Search &amp; Lookup</a>
  <a class="sb-link" href="index.php#notes">📝 Notes</a>
  <a class="sb-link" href="index.php#billing">🧾 Billing</a>
  <a class="sb-link" href="index.php#qualityscore">⭐ Quality Score</a>
  <a class="sb-link" href="index.php#reconciletab">⚖️ Reconcile</a>
  <a class="sb-link" href="index.php#charts">📈 Analytics</a>
  <a class="sb-link" href="index.php#feasibility">📐 Feasibility Calc</a>

  <div class="sidebar-section-lbl">Management</div>
  <a class="sb-link" href="index.php#clientsmaster">🏢 Clients</a>
  <a class="sb-link active" href="index.php#vendors">👥 Vendors</a>
  <a class="sb-link" href="index.php#clients">👤 Client Accounts</a>

  <div class="sidebar-section-lbl">Admin</div>
  <a class="sb-link" href="index.php#alerts">🔔 Alert Settings</a>
  <a class="sb-link" href="index.php#auditlog">📜 Audit Log</a>
  <?php if (($_SESSION['ex_team_role'] ?? '') === 'superadmin'): ?>
  <a class="sb-link" href="index.php#team">👥 Team</a>
  <?php endif; ?>

  <div class="sidebar-section-lbl">Account</div>
  <a class="sb-link" href="index.php#changepass">🔑 Change Password</a>
  <a class="sb-link" href="index.php?logout=1" style="color:#f87171">⏻ Logout</a>
</aside>

<div class="app-content" id="appContent">

<div class="topbar">
  <div class="topbar-title">Vendor Details</div>
  <a href="index.php#vendors" class="btn btn-ghost">← Back to Vendors</a>
</div>

<div class="content">
  <?php if($msg): ?><div class="msg-banner">✓ <?= htmlspecialchars($msg) ?></div><?php endif; ?>

  <div style="display:flex;align-items:center;gap:14px;margin-bottom:6px">
    <div>
      <div style="font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:1px"><?= htmlspecialchars($vendor['vendor_name']) ?></div>
      <span class="pill pill-<?= ($vendor['status']??'active')==='active' ? 'active' : 'inactive' ?>"><?= ($vendor['status']??'active')==='active' ? '● Active' : '⏸ Paused' ?></span>
    </div>
  </div>

  <div style="display:flex;gap:10px;margin:14px 0">
    <a href="?vid=<?= $vid ?>&toggle_vendor=1" class="btn <?= ($vendor['status']??'active')==='active' ? 'btn-amber' : 'btn-green' ?>" onclick="return confirm('<?= ($vendor['status']??'active')==='active' ? 'Pause' : 'Activate' ?> this vendor? This blocks/unblocks their traffic link across ALL projects immediately.')"><?= ($vendor['status']??'active')==='active' ? '⏸ Pause Vendor' : '▶ Activate Vendor' ?></a>
    <button type="button" onclick="document.getElementById('editVendorModal').classList.add('open')" class="btn btn-ghost">✏ Edit Vendor</button>
    <a href="index.php?fVd=<?= $vid ?>#tab-responses" class="btn" style="padding:6px 14px;font-size:12px;background:rgba(255,255,255,0.05);color:#e2e8f0;border-radius:6px;text-decoration:none">🔍 Search All Leads For This Vendor</a>
    <a href="index.php?export=xlsx&evid=<?= $vid ?>" class="btn" style="padding:6px 14px;font-size:12px;background:rgba(255,255,255,0.05);color:#e2e8f0;border-radius:6px;text-decoration:none">⬇ Export to Excel</a>
  </div>

  <div class="stat-row">
    <div class="stat-card"><div class="stat-lbl">Total Clicks</div><div class="stat-val"><?= $total ?></div></div>
    <div class="stat-card green"><div class="stat-lbl">Completes</div><div class="stat-val"><?= $completes ?></div></div>
    <div class="stat-card orange"><div class="stat-lbl">Terminates</div><div class="stat-val"><?= $terminates ?></div></div>
    <div class="stat-card purple"><div class="stat-lbl">Conversion</div><div class="stat-val"><?= $conv ?>%</div></div>
  </div>

  <div class="card" style="margin:18px 0">
    <div class="card-title">📊 Vendor Scorecard</div>
    <div style="font-size:12px;color:#64748b;margin-bottom:14px">Aggregates Quality Score, Fraud Detection, and Reconcile data for this vendor across all their projects — no new data, just the existing per-response data grouped by vendor instead of by project.</div>
    <form method="GET" style="display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap;align-items:flex-end">
      <input type="hidden" name="vid" value="<?= $vid ?>">
      <div>
        <div style="font-size:10px;font-weight:600;color:#64748b;text-transform:uppercase;margin-bottom:4px">From</div>
        <input type="date" name="sc_from" value="<?= htmlspecialchars($sc_date_from) ?>" style="background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:12px">
      </div>
      <div>
        <div style="font-size:10px;font-weight:600;color:#64748b;text-transform:uppercase;margin-bottom:4px">To</div>
        <input type="date" name="sc_to" value="<?= htmlspecialchars($sc_date_to) ?>" style="background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-size:12px">
      </div>
      <button type="submit" style="background:var(--blue2);color:#fff;border:none;border-radius:8px;padding:9px 18px;font-size:12px;cursor:pointer">Apply</button>
      <a href="?vid=<?= $vid ?>&sc_from=<?= urlencode($sc_date_from) ?>&sc_to=<?= urlencode($sc_date_to) ?>&export_scorecard=1" style="background:#f1f3f9;color:#334155;border-radius:8px;padding:9px 18px;font-size:12px;text-decoration:none;font-weight:600">⬇ Export CSV</a>
    </form>
    <div class="stat-row">
      <div class="stat-card green"><div class="stat-lbl">Completes (in range)</div><div class="stat-val"><?= $sc_completes ?></div></div>
      <div class="stat-card blue"><div class="stat-lbl">Overall IR%</div><div class="stat-val"><?= $sc_ir ?>%</div></div>
      <div class="stat-card orange"><div class="stat-lbl">Fraud Flag Rate</div><div class="stat-val"><?= $sc_fraud_rate ?>%</div></div>
      <div class="stat-card purple"><div class="stat-lbl">Avg Quality Score</div><div class="stat-val"><?= $sc_avg_quality ?>/100</div></div>
    </div>
    <div class="stat-row" style="margin-top:10px">
      <div class="stat-card"><div class="stat-lbl">Avg LOI</div><div class="stat-val"><?= $sc_avg_loi !== null ? sprintf('%dm %ds', intdiv($sc_avg_loi,60), $sc_avg_loi%60) : '—' ?></div></div>
      <div class="stat-card"><div class="stat-lbl">Reconcile Mismatch (est.)</div><div class="stat-val"><?= $sc_reconcile_n > 0 ? ($sc_reconcile_est>=0?'+':'').round($sc_reconcile_est) : '—' ?></div></div>
      <div class="stat-card"><div class="stat-lbl">On-Time Delivery</div><div class="stat-val"><?= $sc_ontime_pct !== null ? $sc_ontime_pct.'%' : '—' ?></div></div>
      <div class="stat-card"><div class="stat-lbl">Projects Evaluated</div><div class="stat-val"><?= $sc_ontime_total ?></div></div>
    </div>
    <?php if ($sc_reconcile_n > 0): ?>
    <div style="font-size:10px;color:#94a3b8;margin-top:10px">⚠ Reconcile Mismatch is an <b>estimate</b> — reconcile records are tracked per-project, not per-vendor, so on a multi-vendor project this vendor's share is proportionally estimated from their share of that project's completes.</div>
    <?php endif; ?>
  </div>

  <div class="card" id="s2s" style="margin:18px 0">
    <div class="card-title">🔐 Server-to-Server (S2S) Status API</div>
    <div style="font-size:12px;color:#64748b;margin-bottom:10px">If this vendor's own system reports respondent status via a server-to-server call instead of a browser redirect, generate a key below and share it with them.</div>
    <?php if (!empty($vendor['s2s_inbound_api_key'])): ?>
      <div style="margin-bottom:10px">
        <code style="background:#f1f3f9;padding:6px 10px;border-radius:4px;font-size:12px"><?= htmlspecialchars($vendor['s2s_inbound_api_key']) ?></code>
      </div>
      <div style="font-size:12px;color:#64748b;margin-bottom:10px">
        <b>Send to this vendor:</b> POST to <code>https://<?= htmlspecialchars($_SERVER['HTTP_HOST']) ?>/s2s_status.php</code>
        with header <code>Authorization: Bearer &lt;key above&gt;</code> and JSON body
        <code>{ "respondent_id": "...", "status": "complete" }</code>.
      </div>
    <?php else: ?>
      <div style="font-size:12px;color:#94a3b8;margin-bottom:10px">No key generated yet.</div>
    <?php endif; ?>
    <form method="POST" onsubmit="return <?= !empty($vendor['s2s_inbound_api_key']) ? "confirm('This vendor is already using a key. Generating a new one will immediately stop the old one from working. Continue?')" : 'true' ?>">
      <input type="hidden" name="generate_s2s_key" value="1">
      <button type="submit" class="btn btn-blue"><?= !empty($vendor['s2s_inbound_api_key']) ? '🔄 Regenerate Key' : '＋ Generate Key' ?></button>
    </form>
  </div>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px">
    <div class="card">
      <div class="card-title">Contact Info</div>
      <div class="info-row"><span>Contact Person</span><span><?= htmlspecialchars($vendor['contact_person'] ?: '—') ?></span></div>
      <div class="info-row"><span>Email</span><span><?= htmlspecialchars($vendor['email'] ?: '—') ?></span></div>
      <div class="info-row"><span>Phone</span><span><?= htmlspecialchars($vendor['phone'] ?: '—') ?></span></div>
      <div class="info-row"><span>Vendor Since</span><span><?= date('d M Y', strtotime($vendor['created_at'])) ?></span></div>
    </div>

    <div class="card">
      <div class="card-title">Redirect URLs (Static — <?= htmlspecialchars($vendor['end_behavior'] ?? 'show_page') ?>)</div>
      <div class="url-row">
        <div style="font-size:10px;color:var(--muted);margin-bottom:4px">Complete</div>
        <div class="url-box"><span style="flex:1"><?= htmlspecialchars($vendor['complete_url'] ?: '— not set —') ?></span></div>
      </div>
      <div class="url-row">
        <div style="font-size:10px;color:var(--muted);margin-bottom:4px">Terminate</div>
        <div class="url-box"><span style="flex:1"><?= htmlspecialchars($vendor['terminate_url'] ?: '— not set —') ?></span></div>
      </div>
      <div class="url-row">
        <div style="font-size:10px;color:var(--muted);margin-bottom:4px">Screenout</div>
        <div class="url-box"><span style="flex:1"><?= htmlspecialchars($vendor['screenout_url'] ?: '— not set —') ?></span></div>
      </div>
      <div class="url-row">
        <div style="font-size:10px;color:var(--muted);margin-bottom:4px">Quota Full</div>
        <div class="url-box"><span style="flex:1"><?= htmlspecialchars($vendor['quotafull_url'] ?: '— not set —') ?></span></div>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-title">Assigned Projects (<?= count($assigned_projects) ?>)</div>
    <table>
      <thead><tr><th>Project</th><th>SID</th><th>Status</th><th>CPI</th><th>Limit</th><th>Assigned</th><th></th></tr></thead>
      <tbody>
        <?php if (empty($assigned_projects)): ?>
        <tr><td colspan="7" style="text-align:center;color:#94a3b8;padding:20px">Not assigned to any project yet.</td></tr>
        <?php else: foreach ($assigned_projects as $ap): ?>
        <tr>
          <td><a href="project_view.php?sid=<?= urlencode($ap['survey_id']) ?>" style="color:var(--blue2);text-decoration:none;font-weight:600"><?= htmlspecialchars($ap['project_name']) ?></a></td>
          <td class="mono"><?= htmlspecialchars($ap['survey_id']) ?></td>
          <td><span class="pill pill-<?= ($ap['pv_status']??'active')==='active' ? 'active' : 'inactive' ?>"><?= ($ap['pv_status']??'active')==='active' ? 'Active' : 'Paused' ?></span></td>
          <td>$<?= number_format((float)($ap['pv_cpi'] ?? 0), 2) ?></td>
          <td><?= $ap['pv_limit'] ?: '—' ?></td>
          <td style="color:#94a3b8"><?= date('d M Y', strtotime($ap['assigned_at'])) ?></td>
          <td><a href="?vid=<?= $vid ?>&unassign_project=<?= urlencode($ap['survey_id']) ?>" class="btn btn-red" style="padding:5px 10px;font-size:11px" onclick="return confirm('Unassign this vendor from the project?')">Unassign</a></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <div class="card">
    <div class="card-title">Recent Leads (up to 200)</div>
    <form method="GET" style="display:flex;gap:10px;margin-bottom:14px;flex-wrap:wrap">
      <input type="hidden" name="vid" value="<?= $vid ?>">
      <input type="text" name="vsearch" placeholder="Search by UID..." value="<?= htmlspecialchars($vv_search) ?>" style="padding:8px 12px;border-radius:6px;border:1px solid rgba(255,255,255,0.1);background:#0a1628;color:#e2e8f0;min-width:200px">
      <select name="vstatus" style="padding:8px 12px;border-radius:6px;border:1px solid rgba(255,255,255,0.1);background:#0a1628;color:#e2e8f0">
        <option value="">All Statuses</option>
        <option value="complete" <?= $vv_status==='complete'?'selected':'' ?>>Complete</option>
        <option value="terminate" <?= $vv_status==='terminate'?'selected':'' ?>>Terminate</option>
        <option value="overquota" <?= $vv_status==='overquota'?'selected':'' ?>>Quotafull</option>
        <option value="quality" <?= $vv_status==='quality'?'selected':'' ?>>Quality Fail</option>
      </select>
      <button type="submit" class="btn-sm" style="background:rgba(59,130,246,.15);color:#3b82f6;border:none;cursor:pointer">Filter</button>
      <?php if ($vv_status || $vv_search): ?><a href="?vid=<?= $vid ?>" class="btn-sm" style="background:rgba(255,255,255,.06);color:#94a3b8;text-decoration:none">Clear</a><?php endif; ?>
    </form>
    <table>
      <thead><tr><th>UID</th><th>Status</th><th>Project</th><th>Country</th><th>Device</th><th>LOI</th><th>IP</th><th>Date</th></tr></thead>
      <tbody>
        <?php if (empty($recent_leads)): ?>
        <tr><td colspan="8" style="text-align:center;color:#94a3b8;padding:20px">No leads yet from this vendor.</td></tr>
        <?php else: foreach ($recent_leads as $lr): ?>
        <tr>
          <td class="mono"><?= htmlspecialchars($lr['original_uid'] ?: $lr['respondent']) ?></td>
          <td><span class="pill pill-<?= $lr['status']==='quality' ? 'qc' : $lr['status'] ?>"><?= ucfirst($lr['status']) ?></span></td>
          <td><?= htmlspecialchars($lr['survey_id']) ?></td>
          <td><?= htmlspecialchars($lr['country'] ?: '—') ?></td>
          <td><?= htmlspecialchars($lr['device'] ?: '—') ?></td>
          <td><?= fmt_loi_vv($lr['loi_seconds'] ?? null) ?></td>
          <td class="mono" style="color:#94a3b8"><?= htmlspecialchars($lr['ip'] ?? '') ?></td>
          <td style="color:#94a3b8"><?= date('d M Y H:i', strtotime($lr['created_at'])) ?></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

</div><!-- /content -->
</div><!-- /app-content -->
</div><!-- /app-layout -->

<!-- Edit Vendor Modal -->
<div class="modal-overlay" id="editVendorModal">
  <div class="modal">
    <div style="font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:1px;margin-bottom:16px">Edit Vendor</div>
    <form method="POST">
      <input type="hidden" name="save_vendor_edit" value="1">
      <div class="modal-field"><div class="lbl">Vendor Name</div><input type="text" name="ve_name" value="<?= htmlspecialchars($vendor['vendor_name']) ?>" required></div>
      <div class="modal-field"><div class="lbl">Contact Person</div><input type="text" name="ve_contact" value="<?= htmlspecialchars($vendor['contact_person'] ?? '') ?>"></div>
      <div class="modal-field"><div class="lbl">Email</div><input type="text" name="ve_email" value="<?= htmlspecialchars($vendor['email'] ?? '') ?>"></div>
      <div class="modal-field"><div class="lbl">Phone</div><input type="text" name="ve_phone" value="<?= htmlspecialchars($vendor['phone'] ?? '') ?>"></div>
      <div class="modal-field"><div class="lbl">Complete URL</div><input type="text" name="ve_complete_url" value="<?= htmlspecialchars($vendor['complete_url'] ?? '') ?>" placeholder="https://...&uid={{uid}}"></div>
      <div class="modal-field"><div class="lbl">Terminate URL</div><input type="text" name="ve_terminate_url" value="<?= htmlspecialchars($vendor['terminate_url'] ?? '') ?>"></div>
      <div class="modal-field"><div class="lbl">Screenout URL</div><input type="text" name="ve_screenout_url" value="<?= htmlspecialchars($vendor['screenout_url'] ?? '') ?>"></div>
      <div class="modal-field"><div class="lbl">Quota Full URL</div><input type="text" name="ve_quotafull_url" value="<?= htmlspecialchars($vendor['quotafull_url'] ?? '') ?>"></div>
      <div class="modal-field"><div class="lbl">Notes</div><textarea name="ve_notes"><?= htmlspecialchars($vendor['notes'] ?? '') ?></textarea></div>
      <div style="display:flex;gap:10px;margin-top:16px">
        <button type="submit" class="btn btn-blue" style="flex:1;justify-content:center">Save Changes</button>
        <button type="button" class="btn btn-ghost" onclick="document.getElementById('editVendorModal').classList.remove('open')">Cancel</button>
      </div>
    </form>
  </div>
</div>


<script>
function toggleSidebar(){
  document.getElementById('appSidebar').classList.toggle('collapsed');
  document.getElementById('appContent').classList.toggle('sidebar-collapsed');
}
</script>
</body>
</html>
