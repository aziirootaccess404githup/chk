<?php
// ============================================================
// Exazon Research — pages/survey_start.php
// Direct-flow entry point / start-tracker. Called when a respondent
// begins the survey (either via /survey/PROJECT/UID short-link, or
// pinged directly by the client's survey page on load).
// Logs the start time so track.php can compute a reliable, self-
// measured LOI at completion.
// ============================================================
date_default_timezone_set('Asia/Kolkata');
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/../inc_exz.php';

$uid = trim($_GET['uid'] ?? '');
$sid = trim($_GET['sid'] ?? '');
$src = trim($_GET['src'] ?? 'direct');
$vid = (int)($_GET['vid'] ?? 0);
$ip  = exz_get_ip();

if (empty($uid) || empty($sid)) {
    echo json_encode(['ok' => false, 'msg' => 'uid/sid missing']);
    exit;
}

$db = exz_db();

try {
    $db->prepare("INSERT INTO survey_starts (uid, sid, source, vendor_id, ip, start_time) VALUES (?,?,?,?,?,NOW())")
       ->execute([$uid, $sid, $src, $vid ?: null, $ip]);
    echo json_encode(['ok' => true, 'uid' => $uid, 'sid' => $sid, 'src' => $src]);
} catch (Exception $e) {
    error_log("survey_start.php error: " . $e->getMessage());
    echo json_encode(['ok' => false, 'msg' => 'Could not log start']);
}
exit;
