<?php
// ============================================================
// Exazon Research — capture_screener.php
// Records a single pre-survey (screener) answer. Called via AJAX
// from a prescreener page as the respondent answers each question.
// POST: sid, uid, question_key, question_text, answer_value
// ============================================================
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
require_once __DIR__ . '/inc_exz.php';

$sid   = trim($_POST['sid'] ?? '');
$uid   = trim($_POST['uid'] ?? '');
$qkey  = trim($_POST['question_key'] ?? '');
$qtext = trim($_POST['question_text'] ?? '');
$ans   = trim($_POST['answer_value'] ?? '');

if (!$sid || !$uid || !$qkey) {
    echo json_encode(['ok' => false, 'msg' => 'sid/uid/question_key required']);
    exit;
}

$db = exz_db();
try {
    $db->prepare("INSERT INTO exz_screener_answers (survey_id,respondent,question_key,question_text,answer_value)
        VALUES (?,?,?,?,?)")->execute([$sid, $uid, $qkey, $qtext, $ans]);
    echo json_encode(['ok' => true]);
} catch (Exception $e) {
    error_log("capture_screener.php: " . $e->getMessage());
    echo json_encode(['ok' => false, 'msg' => 'Could not save answer']);
}
