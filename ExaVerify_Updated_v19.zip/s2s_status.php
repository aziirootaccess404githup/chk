<?php
// ============================================================
// Exazon Research — s2s_status.php
// Inbound Server-to-Server (S2S) status API.
//
// POST /s2s_status.php
// Header: Authorization: Bearer <vendor's s2s_inbound_api_key>
// Body (JSON): { "respondent_id": "...", "status": "complete" }
//
// This is the "we act as the client/hub, a vendor's own server calls
// us" direction — the mirror image of the existing vendor-postback
// mechanism in track.php (which fires when WE report OUT to a
// vendor). Genuinely reuses the same known-statuses / unmatched-status
// convention track.php already uses, so a status this endpoint
// doesn't recognize becomes 'unmatched' here too — never silently
// counted as complete.
// ============================================================
require_once __DIR__ . '/inc_exz.php';

header('Content-Type: application/json');
$db = exz_db();

// ── Authenticate via Bearer token ──────────────────────────────
$headers = getallheaders();
$auth = $headers['Authorization'] ?? $headers['authorization'] ?? '';
$token = null;
if (preg_match('/^Bearer\s+(.+)$/i', trim($auth), $m)) {
    $token = trim($m[1]);
}

if (!$token) {
    http_response_code(401);
    echo json_encode(['error' => 'Missing Authorization: Bearer <token> header.']);
    exit;
}

try {
    $db->exec("ALTER TABLE exz_vendors ADD COLUMN s2s_inbound_api_key VARCHAR(80) DEFAULT NULL");
} catch (PDOException $e) {}

$vs = $db->prepare("SELECT id, vendor_name FROM exz_vendors WHERE s2s_inbound_api_key = ? LIMIT 1");
$vs->execute([$token]);
$vendor = $vs->fetch();

if (!$vendor) {
    http_response_code(401);
    echo json_encode(['error' => 'Invalid or unrecognized API token.']);
    exit;
}

// ── Parse the JSON body ─────────────────────────────────────────
$raw = file_get_contents('php://input');
$body = json_decode($raw, true);
if (!is_array($body)) {
    http_response_code(400);
    echo json_encode(['error' => 'Request body must be valid JSON.']);
    exit;
}

$respondent_id = trim($body['respondent_id'] ?? $body['uid'] ?? $body['pid'] ?? '');
$raw_status = strtolower(trim($body['status'] ?? ''));

if (!$respondent_id) {
    http_response_code(400);
    echo json_encode(['error' => 'respondent_id is required.']);
    exit;
}

// Same known-statuses convention as track.php — anything unrecognized
// becomes 'unmatched', never silently 'complete'.
$status_map = [
    'complete' => 'complete', 'terminate' => 'terminate',
    'qc' => 'qc', 'quality' => 'qc', 'quality_fail' => 'qc',
    'quotafull' => 'quotafull', 'overquota' => 'quotafull',
];
$known_statuses = ['complete', 'terminate', 'qc', 'quotafull'];
$status = $status_map[$raw_status] ?? 'unmatched';
$is_unmatched = !in_array($status, $known_statuses);

// ── Find the matching entry — scoped to THIS vendor, so one vendor's
// API key can never touch another vendor's records. Mirrors track.php's
// own multi-tier lookup: survey_responses may not have a row yet if
// this is the respondent's first-ever status report (vendor.php only
// writes to survey_starts at entry time, survey_responses only gets
// its first row at the FIRST completion/status report) ──────────
$rs = $db->prepare("SELECT id, status, status_locked, survey_id FROM survey_responses WHERE respondent = ? AND vendor_id = ? ORDER BY id DESC LIMIT 1");
$rs->execute([$respondent_id, $vendor['id']]);
$existing = $rs->fetch();

$entry_sid = null;
if (!$existing) {
    // No survey_responses row yet — check survey_starts (written by
    // vendor.php at entry time) to confirm this respondent genuinely
    // entered through THIS vendor's own link, and to get the correct sid.
    $ss = $db->prepare("SELECT sid FROM survey_starts WHERE uid = ? AND vendor_id = ? ORDER BY id DESC LIMIT 1");
    $ss->execute([$respondent_id, $vendor['id']]);
    $entry_sid = $ss->fetchColumn();
}

if (!$existing && !$entry_sid) {
    http_response_code(404);
    echo json_encode(['error' => 'No matching entry found for this respondent_id under your vendor account. The respondent must have entered through your own entry-link first.']);
    exit;
}

if ($existing && $existing['status_locked']) {
    echo json_encode(['respondent_id' => $respondent_id, 'status' => $existing['status'], 'note' => 'Already locked to a final status — no change made.']);
    exit;
}

$lock_value = $is_unmatched ? 0 : 1;

if ($existing) {
    $db->prepare("UPDATE survey_responses SET status=?, status_locked=? WHERE id=?")
       ->execute([$status, $lock_value, $existing['id']]);
    $final_sid = $existing['survey_id'];
} else {
    // First-ever status report for this respondent — insert the row
    // (same as track.php would on a first completion), using the sid
    // survey_starts already has on file.
    $db->prepare("INSERT INTO survey_responses (survey_id, respondent, status, vendor_id, status_locked, created_at) VALUES (?,?,?,?,?,NOW())")
       ->execute([$entry_sid, $respondent_id, $status, $vendor['id'], $lock_value]);
    $final_sid = $entry_sid;
}

if ($status === 'complete') {
    try { exz_check_quota($db, $final_sid); } catch (Exception $e) {}
}

echo json_encode(['respondent_id' => $respondent_id, 'status' => $status, 'received_at' => date('c')]);
