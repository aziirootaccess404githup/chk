<?php
// ============================================================
// Exazon Research — api.php
// Token-based JSON API for client-facing integrations.
// No login required — access is gated entirely by a valid,
// non-revoked share-link token. UID and IP are never returned
// (privacy — clients get behavioral/status data only).
// ============================================================
header('Content-Type: application/json');
require_once __DIR__ . '/inc_exz.php';

$db = exz_db();
$token = trim($_GET['token'] ?? '');

if (!$token) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Missing token']);
    exit;
}

$sl = $db->prepare("SELECT * FROM exz_share_links WHERE token=? AND is_revoked=0 LIMIT 1");
$sl->execute([$token]);
$link = $sl->fetch();

if (!$link) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Invalid or revoked token']);
    exit;
}

$sid = $link['survey_id'];
$action = trim($_GET['action'] ?? 'summary');

if ($action === 'leads') {
    $page = max(1, intval($_GET['page'] ?? 1));
    $perPage = 100;
    $offset = ($page - 1) * $perPage;

    $cnt = $db->prepare("SELECT COUNT(*) FROM survey_responses WHERE survey_id=?");
    $cnt->execute([$sid]);
    $totalRows = (int)$cnt->fetchColumn();

    // UID and IP intentionally excluded from the public API for privacy.
    $stmt = $db->prepare("SELECT status, country, device, loi_seconds, created_at
        FROM survey_responses WHERE survey_id=? ORDER BY created_at DESC LIMIT $perPage OFFSET $offset");
    $stmt->execute([$sid]);
    $rows = $stmt->fetchAll();

    echo json_encode([
        'ok' => true,
        'sid' => $sid,
        'page' => $page,
        'per_page' => $perPage,
        'total' => $totalRows,
        'total_pages' => (int)ceil($totalRows / $perPage),
        'leads' => $rows,
    ]);
    exit;
}

// Default: summary
$st = $db->prepare("SELECT COUNT(*) as total, SUM(status='complete') as completes,
    SUM(status='terminate') as terminates, SUM(status='quotafull') as quotafull,
    SUM(status='qc' OR status='quality') as quality_fail
    FROM survey_responses WHERE survey_id=?");
$st->execute([$sid]);
$stats = $st->fetch();

$proj = $db->prepare("SELECT project_name, status, target FROM project_settings WHERE survey_id=?");
$proj->execute([$sid]);
$p = $proj->fetch();

$total = (int)($stats['total'] ?? 0);
$completes = (int)($stats['completes'] ?? 0);

echo json_encode([
    'ok' => true,
    'sid' => $sid,
    'project_name' => $p['project_name'] ?? '',
    'status' => $p['status'] ?? '',
    'target' => (int)($p['target'] ?? 0),
    'clicks' => $total,
    'completes' => $completes,
    'terminates' => (int)($stats['terminates'] ?? 0),
    'quotafull' => (int)($stats['quotafull'] ?? 0),
    'quality_fail' => (int)($stats['quality_fail'] ?? 0),
    'conversion_rate' => $total > 0 ? round($completes / $total * 100, 2) : 0,
]);
