<?php
// ============================================================
// Exazon Research — process.php
// Legacy TP end-redirect entry point. Forwards to the single
// authoritative status handler (pages/track.php) so there's only
// one place that implements SID-resolution, status-lock, and
// vendor postback logic.
// ============================================================
$qs = $_SERVER['QUERY_STRING'] ?? '';
header("Location: pages/track.php" . ($qs ? "?$qs" : ''));
exit();
