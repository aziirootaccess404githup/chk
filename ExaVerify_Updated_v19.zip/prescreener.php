<?php
// ============================================================
// Exazon Research — prescreener.php
// Shown after vendor.php, before the respondent reaches the
// client's live survey. Captures 6 quick profile questions,
// then forwards to the actual survey URL.
// Design: matches ExaVerify's original navy/gold aesthetic.
// ============================================================
require_once __DIR__ . '/inc_exz.php';

$sid = trim($_GET['sid'] ?? '');
$uid = trim($_GET['uid'] ?? '');
$vid = trim($_GET['vid'] ?? '');

if (!$sid || !$uid) { die('<h3>Invalid access.</h3>'); }

$db = exz_db();
$pp = $db->prepare("SELECT * FROM project_settings WHERE survey_id=? LIMIT 1");
$pp->execute([$sid]);
$project = $pp->fetch();

// Auto-detect respondent's country (for the Country-question below and its
// local-currency income display) — reuses the same 3-provider geo-lookup
// used for tracking, so this stays free and doesn't need a separate call.
$detected_country = '';
try { $detected_country = exz_geo(exz_get_ip())['country'] ?? ''; } catch (Exception $e) {}

if (!$project || empty($project['live_url'])) {
    die('<h3>Survey not available. Please contact support.</h3>');
}

// ── DYNAMIC PRESCREEN TEMPLATE (optional) ──────────────────────
// If this project has a PreScreen Template assigned, render ITS questions
// dynamically instead of the original fixed 6. If not assigned (NULL),
// falls back to the exact original fixed 6 questions below — 100%
// backward compatible, no existing project is ever affected by this.
$template_questions = [];
if (!empty($project['prescreen_template_id'])) {
    try {
        $tq = $db->prepare("SELECT ql.* FROM exz_prescreen_template_questions ptq
            JOIN exz_question_library ql ON ql.id = ptq.question_id
            WHERE ptq.template_id=? ORDER BY ptq.sort_order ASC");
        $tq->execute([$project['prescreen_template_id']]);
        $template_questions = $tq->fetchAll();
    } catch (Exception $e) {}
}
$using_dynamic_template = !empty($template_questions);

$survey_url = $project['live_url'];
// Replace standard placeholders - now supports {{token}}, [TOKEN], {token},
// %TOKEN%, <token>, and $token$ styles (case-insensitive), not just [TOKEN].
// Existing client Live URLs using [UID]/[SID]/[VID] keep working exactly as
// before (100% backward compatible) - this only ADDS new bracket styles.
$survey_url = exz_build_url($survey_url, [
    'uid' => $uid, 'rid' => $uid, 'toid' => $uid, 'identifier' => $uid, 'tid' => $uid,
    'userid' => $uid, 'user_id' => $uid, 'respid' => $uid, 'resp_id' => $uid,
    'respondentid' => $uid, 'respondent_id' => $uid, 'panelistid' => $uid, 'panelist_id' => $uid,
    'participantid' => $uid, 'participant_id' => $uid, 'memberid' => $uid, 'member_id' => $uid,
    'entryid' => $uid, 'entry_id' => $uid, 'clickid' => $uid, 'subid' => $uid,
    'transactionid' => $uid, 'transaction_id' => $uid, 'qparm' => $uid, 'subject_id' => $uid,
    'sid' => $sid, 'studyid' => $sid, 'surveyid' => $sid, 'survey_id' => $sid,
    'projectid' => $sid, 'project_id' => $sid,
    'vid' => $vid,
]);
$survey_url = html_entity_decode($survey_url, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="referrer" content="unsafe-url">
<title>Survey — Exazon Research</title>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
:root{
  --navy:#050e1d; --navy2:#0a1628; --navy3:#0d2045;
  --gold:#c8a84b; --gold2:#e8c96b;
  --blue:#1b4fd8; --blue2:#3b82f6;
  --text:#e8f0ff; --muted:rgba(160,190,255,0.55);
  --border:rgba(200,168,75,0.15); --border2:rgba(255,255,255,0.06);
}
html,body{height:100%;min-height:100vh;}
body{font-family:'DM Sans',sans-serif;background:var(--navy);color:var(--text);overflow-x:hidden;}
.bg-wrap{position:fixed;inset:0;z-index:0;overflow:hidden;}
.bg-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(27,79,216,0.04) 1px,transparent 1px),linear-gradient(90deg,rgba(27,79,216,0.04) 1px,transparent 1px);background-size:60px 60px;}
.bg-orb1{position:absolute;top:-200px;left:-200px;width:700px;height:700px;background:radial-gradient(circle,rgba(27,79,216,0.12) 0%,transparent 65%);border-radius:50%;}
.bg-orb2{position:absolute;bottom:-150px;right:-150px;width:600px;height:600px;background:radial-gradient(circle,rgba(200,168,75,0.08) 0%,transparent 65%);border-radius:50%;}
.page{position:relative;z-index:1;min-height:100vh;display:grid;grid-template-rows:auto 1fr auto;}
.topbar{padding:16px 40px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border);background:rgba(5,14,29,0.8);backdrop-filter:blur(12px);}
.brand{display:flex;align-items:center;gap:14px;}
.brand-logo{width:48px;height:48px;object-fit:contain;border-radius:8px;}
.brand-name{font-family:'Cormorant Garamond',serif;font-size:17px;font-weight:700;letter-spacing:2px;color:#fff;line-height:1.1;}
.brand-tag{font-size:8px;letter-spacing:4px;text-transform:uppercase;color:var(--gold);}
.topbar-right{display:flex;align-items:center;gap:12px;}
.badge-live{display:flex;align-items:center;gap:6px;font-size:10px;color:rgba(160,190,255,0.5);letter-spacing:1px;}
.dot-live{width:6px;height:6px;border-radius:50%;background:#22c55e;box-shadow:0 0 6px #22c55e;}
.badge-ev{background:rgba(200,168,75,0.1);border:1px solid rgba(200,168,75,0.3);border-radius:4px;padding:4px 12px;font-size:9px;letter-spacing:3px;color:var(--gold);font-weight:700;}
.body{display:grid;grid-template-columns:380px 1fr;}
@media(max-width:900px){.body{grid-template-columns:1fr;}}
.left{padding:48px 40px;border-right:1px solid var(--border2);display:flex;flex-direction:column;gap:32px;}
@media(max-width:900px){.left{display:none;}}
.left-step-tag{font-size:9px;letter-spacing:4px;text-transform:uppercase;color:var(--gold);margin-bottom:6px;}
.left-title{font-family:'Cormorant Garamond',serif;font-size:36px;font-weight:700;color:#fff;line-height:1.2;margin-bottom:10px;}
.left-title em{color:var(--gold);font-style:normal;}
.left-desc{font-size:13px;color:var(--muted);line-height:1.9;}
.steps-list{display:flex;flex-direction:column;gap:0;}
.step-item{display:flex;align-items:flex-start;gap:14px;padding-bottom:24px;position:relative;}
.step-item:not(:last-child)::after{content:'';position:absolute;left:14px;top:30px;width:1px;bottom:0;background:linear-gradient(to bottom,rgba(200,168,75,0.2),transparent);}
.step-circle{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;flex-shrink:0;}
.step-circle.done{background:rgba(34,197,94,0.15);border:1px solid rgba(34,197,94,0.4);color:#4ade80;}
.step-circle.active{background:rgba(200,168,75,0.15);border:1px solid rgba(200,168,75,0.5);color:var(--gold);}
.step-circle.todo{background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);color:rgba(160,190,255,0.3);}
.step-title{font-size:13px;font-weight:600;color:#e8f0ff;line-height:1.3;}
.step-title.muted{color:rgba(160,190,255,0.35);font-weight:400;}
.step-sub{font-size:11px;color:var(--muted);margin-top:2px;}
.stats-row{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.stat-box{background:rgba(255,255,255,0.03);border:1px solid var(--border2);border-radius:10px;padding:14px 16px;}
.stat-num{font-family:'Cormorant Garamond',serif;font-size:24px;font-weight:700;color:var(--gold);}
.stat-label{font-size:9px;letter-spacing:2px;text-transform:uppercase;color:var(--muted);margin-top:2px;}
.trust-list{display:flex;flex-direction:column;gap:8px;}
.trust-item{display:flex;align-items:flex-start;gap:12px;padding:12px 14px;background:rgba(255,255,255,0.02);border:1px solid var(--border2);border-radius:10px;}
.trust-icon{font-size:16px;margin-top:1px;}
.trust-title{font-size:12px;font-weight:600;color:#e8f0ff;margin-bottom:2px;}
.trust-sub{font-size:11px;color:var(--muted);line-height:1.5;}
.contact-block{margin-top:auto;padding-top:24px;border-top:1px solid var(--border2);}
.contact-label{font-size:9px;letter-spacing:3px;text-transform:uppercase;color:rgba(160,190,255,0.2);margin-bottom:12px;}
.contact-row{display:flex;align-items:center;gap:10px;margin-bottom:8px;}
.contact-icon{width:22px;height:22px;border-radius:5px;background:rgba(27,79,216,0.15);display:flex;align-items:center;justify-content:center;font-size:10px;flex-shrink:0;}
.contact-text{font-size:11px;color:rgba(160,190,255,0.5);}
.contact-text a{color:rgba(160,190,255,0.65);text-decoration:none;}
.right{padding:48px 52px;overflow-y:auto;}
@media(max-width:900px){.right{padding:32px 24px;}}
.uid-badge{display:inline-flex;align-items:center;gap:8px;background:rgba(27,79,216,0.1);border:1px solid rgba(27,79,216,0.22);border-radius:50px;padding:6px 18px;font-size:11px;color:rgba(160,190,255,0.8);margin-bottom:20px;letter-spacing:0.5px;}
.uid-badge strong{color:#fff;font-weight:600;}
.form-title{font-family:'Cormorant Garamond',serif;font-size:30px;font-weight:700;color:#fff;margin-bottom:4px;}
.form-sub{font-size:13px;color:var(--muted);margin-bottom:28px;line-height:1.7;}
.prog-wrap{margin-bottom:28px;}
.prog-meta{display:flex;justify-content:space-between;font-size:10px;color:var(--muted);margin-bottom:8px;letter-spacing:0.5px;}
.prog-bar{height:2px;background:rgba(255,255,255,0.06);border-radius:2px;overflow:hidden;}
.prog-fill{height:100%;width:0%;background:linear-gradient(90deg,var(--blue),var(--gold));border-radius:2px;transition:width 0.4s ease;}
.q-block{margin-bottom:22px;}
.q-label{display:block;font-size:10px;font-weight:700;color:rgba(160,190,255,0.5);letter-spacing:2px;text-transform:uppercase;margin-bottom:10px;}
.radio-group{display:flex;flex-direction:column;gap:7px;}
.radio-row{display:flex;align-items:center;gap:12px;padding:11px 16px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.06);border-radius:10px;cursor:pointer;font-size:13px;color:rgba(200,220,255,0.75);transition:all 0.2s;user-select:none;}
.radio-row:hover{background:rgba(27,79,216,0.08);border-color:rgba(27,79,216,0.25);}
.radio-row.selected{background:rgba(200,168,75,0.07);border-color:rgba(200,168,75,0.3);color:#fff;}
.radio-dot{width:16px;height:16px;border-radius:50%;border:1.5px solid rgba(100,150,255,0.3);flex-shrink:0;transition:all 0.2s;display:flex;align-items:center;justify-content:center;}
.radio-dot.filled{border-color:var(--gold);background:var(--gold);}
.radio-dot.filled::after{content:'';width:6px;height:6px;border-radius:50%;background:var(--navy);}
.q-select{width:100%;padding:12px 16px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:10px;font-family:'DM Sans',sans-serif;font-size:13px;color:rgba(200,220,255,0.75);outline:none;transition:border-color 0.2s;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='rgba(160,190,255,0.4)' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 14px center;}
.q-select:focus{border-color:rgba(27,79,216,0.4);}
.q-select option{background:#0a1628;color:#e8f0ff;}
.err-msg{background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.25);border-radius:8px;padding:11px 16px;color:#fca5a5;font-size:12px;margin-bottom:18px;display:none;}
.btn-continue{width:100%;padding:15px;margin-top:10px;background:linear-gradient(135deg,var(--gold),var(--gold2));color:var(--navy);border:none;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:13px;font-weight:700;letter-spacing:2px;text-transform:uppercase;cursor:pointer;transition:all 0.2s;box-shadow:0 4px 20px rgba(200,168,75,0.25);}
.btn-continue:hover{transform:translateY(-2px);box-shadow:0 8px 28px rgba(200,168,75,0.35);}
.btn-continue:active{transform:translateY(0);}
.footer{padding:14px 40px;border-top:1px solid var(--border2);display:flex;justify-content:space-between;align-items:center;background:rgba(5,14,29,0.6);}
.footer-left{font-size:9px;letter-spacing:2px;color:rgba(160,190,255,0.15);text-transform:uppercase;}
.footer-right{font-size:9px;letter-spacing:3px;color:rgba(200,168,75,0.3);text-transform:uppercase;}
</style>
</head>
<body>

<div class="bg-wrap"><div class="bg-grid"></div><div class="bg-orb1"></div><div class="bg-orb2"></div></div>

<div class="page">

  <div class="topbar">
    <div class="brand">
      <img class="brand-logo" src="logo.php" alt="Exazon Research">
      <div class="brand-text">
        <div class="brand-name">Exazon Research</div>
        <div class="brand-tag">ExaVerify™ · Quality Intelligence</div>
      </div>
    </div>
    <div class="topbar-right">
      <div class="badge-live"><div class="dot-live"></div>LIVE SURVEY</div>
      <div class="badge-ev">EXAVERIFY™</div>
    </div>
  </div>

  <div class="body">

    <div class="left">
      <div>
        <div class="left-step-tag">Survey Pre-Screening</div>
        <div class="left-title">Before We <em>Begin</em></div>
        <p class="left-desc">A few quick questions help us match you to the right survey and ensure data integrity.</p>
      </div>

      <div class="steps-list">
        <div class="step-item">
          <div class="step-circle done">✓</div>
          <div class="step-text"><div class="step-title">Identity Verified</div><div class="step-sub">Participant ID confirmed</div></div>
        </div>
        <div class="step-item">
          <div class="step-circle active">2</div>
          <div class="step-text"><div class="step-title">Profile Questions</div><div class="step-sub">6 quick questions · &lt;60 seconds</div></div>
        </div>
        <div class="step-item">
          <div class="step-circle todo">3</div>
          <div class="step-text"><div class="step-title muted">Enter Survey</div><div class="step-sub">Redirected automatically</div></div>
        </div>
      </div>

      <div class="stats-row">
        <div class="stat-box"><div class="stat-num">&lt;60s</div><div class="stat-label">Completion Time</div></div>
        <div class="stat-box"><div class="stat-num">6</div><div class="stat-label">Questions Total</div></div>
      </div>

      <div class="trust-list">
        <div class="trust-item"><div class="trust-icon">🔒</div><div class="trust-text"><div class="trust-title">Encrypted Identity</div><div class="trust-sub">Your identity is anonymized before reaching the client.</div></div></div>
        <div class="trust-item"><div class="trust-icon">🎯</div><div class="trust-text"><div class="trust-title">Better Survey Match</div><div class="trust-sub">Profile data ensures you receive the most relevant surveys.</div></div></div>
        <div class="trust-item"><div class="trust-icon">✅</div><div class="trust-text"><div class="trust-title">ISO-Compliant Panel</div><div class="trust-sub">Exazon Research follows global research ethics standards.</div></div></div>
      </div>

      <div class="contact-block">
        <div class="contact-label">Support</div>
        <div class="contact-row"><div class="contact-icon">✉</div><div class="contact-text"><a href="mailto:info@exazonresearch.com">info@exazonresearch.com</a></div></div>
        <div class="contact-row"><div class="contact-icon">🌐</div><div class="contact-text"><a href="https://exazonresearch.com" target="_blank">exazonresearch.com</a></div></div>
      </div>
    </div><!-- /left -->

    <div class="right">
      <div class="uid-badge">Participant ID: <strong><?= htmlspecialchars($uid) ?></strong></div>
      <div class="form-title">Profile Questions</div>
      <p class="form-sub">Please complete all fields before continuing to your survey.</p>

      <div class="prog-wrap">
        <div class="prog-meta"><span>Progress</span><span id="progText">0 of <?= $using_dynamic_template ? count($template_questions) : 6 ?></span></div>
        <div class="prog-bar"><div class="prog-fill" id="progFill"></div></div>
      </div>

      <div class="err-msg" id="errMsg">⚠ Please answer all questions before continuing.</div>

      <?php if ($using_dynamic_template): ?>
      <?php foreach ($template_questions as $tq):
        $qkey = 'q_' . $tq['id'];
        $opts = $tq['options'] ? array_map('trim', explode(',', $tq['options'])) : [];
      ?>
      <div class="q-block">
        <label class="q-label"><?= htmlspecialchars($tq['title']) ?></label>
        <?php if ($tq['control_type'] === 'radio'): ?>
          <div class="radio-group" id="grp-<?= $qkey ?>">
            <?php foreach ($opts as $oi => $opt): ?>
            <div class="radio-row" onclick="selectRadio('<?= $qkey ?>','<?= htmlspecialchars(addslashes($opt)) ?>',this)"><div class="radio-dot" id="dot-<?= $qkey ?>-<?= $oi ?>"></div><?= htmlspecialchars($opt) ?></div>
            <?php endforeach; ?>
          </div>
        <?php elseif ($tq['control_type'] === 'checkbox'): ?>
          <div class="radio-group" id="grp-<?= $qkey ?>">
            <?php foreach ($opts as $oi => $opt): ?>
            <div class="radio-row" onclick="toggleCheckboxOpt('<?= $qkey ?>','<?= htmlspecialchars(addslashes($opt)) ?>',this)"><div class="radio-dot" id="dot-<?= $qkey ?>-<?= $oi ?>"></div><?= htmlspecialchars($opt) ?></div>
            <?php endforeach; ?>
          </div>
        <?php elseif ($tq['control_type'] === 'select'): ?>
          <select class="q-select" id="<?= $qkey ?>" onchange="updateProgress()">
            <option value="">— Select —</option>
            <?php foreach ($opts as $opt): ?><option><?= htmlspecialchars($opt) ?></option><?php endforeach; ?>
          </select>
        <?php else: ?>
          <textarea id="<?= $qkey ?>" maxlength="<?= (int)($tq['max_length'] ?: 200) ?>" oninput="updateProgress()" placeholder="<?= htmlspecialchars($tq['question_text']) ?>" style="width:100%;padding:12px 16px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:10px;font-family:'DM Sans',sans-serif;font-size:13px;color:rgba(200,220,255,0.75);outline:none;resize:none;height:70px;line-height:1.7;"></textarea>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>

      <button class="btn-continue" onclick="submitPreSurveyDynamic()">Continue to Survey →</button>

      <?php else: ?>
      <div class="q-block">
        <label class="q-label">Gender</label>
        <div class="radio-group" id="grp-gender">
          <div class="radio-row" onclick="selectRadio('gender','Male',this)"><div class="radio-dot" id="dot-gender-Male"></div>Male</div>
          <div class="radio-row" onclick="selectRadio('gender','Female',this)"><div class="radio-dot" id="dot-gender-Female"></div>Female</div>
          <div class="radio-row" onclick="selectRadio('gender','Other',this)"><div class="radio-dot" id="dot-gender-Other"></div>Other / Prefer not to say</div>
        </div>
      </div>

      <div class="q-block">
        <label class="q-label">Age Group</label>
        <select class="q-select" id="age_group" onchange="updateProgress()">
          <option value="">— Select —</option>
          <option>18–24</option><option>25–34</option><option>35–44</option>
          <option>45–54</option><option>55–64</option><option>65+</option>
        </select>
      </div>

      <div class="q-block">
        <label class="q-label">Highest Education</label>
        <select class="q-select" id="education" onchange="updateProgress()">
          <option value="">— Select —</option>
          <option>Less than high school</option>
          <option>High school / Secondary</option>
          <option>Some college / Diploma</option>
          <option>Bachelor's degree</option>
          <option>Postgraduate / Masters</option>
          <option>Doctorate / PhD</option>
        </select>
      </div>

      <div class="q-block">
        <label class="q-label">Which country are you in?</label>
        <select class="q-select" id="prescreen_country" onchange="updateIncomeCurrency()">
          <option value="">— Select —</option>
        </select>
      </div>

      <div class="q-block">
        <label class="q-label">Monthly Household Income</label>
        <select class="q-select" id="income" onchange="updateProgress()">
          <option value="">— Select —</option>
          <option value="Less than $15,000">Less than $15,000</option>
          <option value="$15,000 to $24,999">$15,000 to $24,999</option>
          <option value="$24,000 to $49,999">$24,000 to $49,999</option>
          <option value="$50,000 to $74,999">$50,000 to $74,999</option>
          <option value="$75,000 to $99,999">$75,000 to $99,999</option>
          <option value="$100,000 to $149,999">$100,000 to $149,999</option>
          <option value="$150,000 to $199,999">$150,000 to $199,999</option>
          <option value="$200,000 to $249,999">$200,000 to $249,999</option>
          <option value="$250,000 or greater">$250,000 or greater</option>
          <option value="Prefer not to say">Prefer not to say</option>
        </select>
      </div>

      <div class="q-block">
        <label class="q-label">Device You Are Using</label>
        <div class="radio-group" id="grp-device_self">
          <div class="radio-row" onclick="selectRadio('device_self','Mobile',this)"><div class="radio-dot" id="dot-device_self-Mobile"></div>Mobile / Smartphone</div>
          <div class="radio-row" onclick="selectRadio('device_self','Tablet',this)"><div class="radio-dot" id="dot-device_self-Tablet"></div>Tablet</div>
          <div class="radio-row" onclick="selectRadio('device_self','Desktop',this)"><div class="radio-dot" id="dot-device_self-Desktop"></div>Desktop / Laptop</div>
        </div>
      </div>

      <div class="q-block">
        <label class="q-label">About You <span style="color:rgba(200,168,75,0.6);font-size:9px;letter-spacing:1px;">REQUIRED</span></label>
        <p style="font-size:12px;color:rgba(160,190,255,0.45);margin-bottom:10px;line-height:1.7;">In your own words, tell us a little about yourself and what a typical day looks like for you.</p>
        <textarea id="open_end" maxlength="200" oninput="updateCounter(); updateProgress();" placeholder="e.g. I work in marketing, usually start my day with emails, evening is family time..." style="width:100%;padding:12px 16px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:10px;font-family:'DM Sans',sans-serif;font-size:13px;color:rgba(200,220,255,0.75);outline:none;resize:none;height:90px;line-height:1.7;transition:border-color 0.2s;" onfocus="this.style.borderColor='rgba(27,79,216,0.4)'" onblur="this.style.borderColor='rgba(255,255,255,0.08)'"></textarea>
        <div style="display:flex;justify-content:flex-end;margin-top:5px;"><span id="charCount" style="font-size:10px;color:rgba(160,190,255,0.3);letter-spacing:0.5px;">0 / 200</span></div>
      </div>

      <button class="btn-continue" onclick="submitPreSurvey()">Continue to Survey →</button>
      <?php endif; ?>
    </div><!-- /right -->

  </div><!-- /body -->

  <div class="footer">
    <div class="footer-left">© <?= date('Y') ?> Exazon Research LLP · Lucknow, India · info@exazonresearch.com</div>
    <div class="footer-right">ExaVerify™ Quality Intelligence</div>
  </div>

</div><!-- /page -->

<script>
const SID = <?= json_encode($sid) ?>;
const UID = <?= json_encode($uid) ?>;
const SURVEY_URL = <?= json_encode($survey_url) ?>;
const USING_DYNAMIC = <?= json_encode($using_dynamic_template) ?>;
const TEMPLATE_QUESTIONS = <?= json_encode(array_map(function($tq){ return ['key'=>'q_'.$tq['id'],'title'=>$tq['title'],'text'=>$tq['question_text'],'type'=>$tq['control_type'],'min'=>$tq['min_length']]; }, $template_questions)) ?>;

const dynVals = {};
TEMPLATE_QUESTIONS.forEach(q => { dynVals[q.key] = (q.type === 'checkbox') ? [] : ''; });

function toggleCheckboxOpt(key, value, el) {
    const arr = dynVals[key];
    const idx = arr.indexOf(value);
    if (idx > -1) { arr.splice(idx, 1); el.classList.remove('selected'); el.querySelector('.radio-dot').classList.remove('filled'); }
    else { arr.push(value); el.classList.add('selected'); el.querySelector('.radio-dot').classList.add('filled'); }
    updateProgressDynamic();
}

function updateProgressDynamic() {
    TEMPLATE_QUESTIONS.forEach(q => {
        if (q.type === 'select' || q.type === 'text') {
            const el = document.getElementById(q.key);
            if (el) dynVals[q.key] = el.value;
        }
    });
    let filled = 0;
    TEMPLATE_QUESTIONS.forEach(q => {
        const v = dynVals[q.key];
        const minLen = q.min || (q.type === 'text' ? 10 : 1);
        if (q.type === 'checkbox') { if (v.length > 0) filled++; }
        else if (v && v.toString().trim().length >= (q.type === 'text' ? minLen : 1)) filled++;
    });
    document.getElementById('progFill').style.width = (filled / TEMPLATE_QUESTIONS.length * 100) + '%';
    document.getElementById('progText').textContent = filled + ' of ' + TEMPLATE_QUESTIONS.length;
}

function submitPreSurveyDynamic() {
    updateProgressDynamic();
    const err = document.getElementById('errMsg');
    let allFilled = true;
    TEMPLATE_QUESTIONS.forEach(q => {
        const v = dynVals[q.key];
        const minLen = q.min || (q.type === 'text' ? 10 : 1);
        if (q.type === 'checkbox') { if (v.length === 0) allFilled = false; }
        else if (!v || v.toString().trim().length < (q.type === 'text' ? minLen : 1)) allFilled = false;
    });
    if (!allFilled) {
        err.textContent = '⚠ Please answer all questions before continuing.';
        err.style.display = 'block';
        err.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        return;
    }
    err.style.display = 'none';

    TEMPLATE_QUESTIONS.forEach(q => {
        const answerVal = q.type === 'checkbox' ? dynVals[q.key].join('; ') : dynVals[q.key];
        fetch('capture_screener.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ sid: SID, uid: UID, question_key: q.key, question_text: q.title, answer_value: answerVal })
        }).catch(() => {});
    });

    window.location.href = SURVEY_URL;
}

// ── Country dropdown + local-currency income display ──────────
// Matches Kishan's panel's approach: respondent SEES their income
// options converted to local currency (so it's meaningful to them),
// but the SUBMITTED value (income select's .value) always stays the
// original USD bracket string — the <option value="..."> attributes
// added above never change, only the visible text does. This keeps
// analytics/reports/exports consistent across every country, while
// still being readable for the respondent filling it out.
const DETECTED_COUNTRY = <?= json_encode($detected_country) ?>;
const COUNTRY_CURRENCY = {
  'India': {symbol:'₹', rate:83},
  'United States': {symbol:'$', rate:1},
  'United Kingdom': {symbol:'£', rate:0.79},
  'Canada': {symbol:'C$', rate:1.36},
  'Australia': {symbol:'A$', rate:1.52},
  'Germany': {symbol:'€', rate:0.92},
  'France': {symbol:'€', rate:0.92},
  'Philippines': {symbol:'₱', rate:56},
  'United Arab Emirates': {symbol:'AED', rate:3.67},
  'Singapore': {symbol:'S$', rate:1.35},
  'South Africa': {symbol:'R', rate:18.5},
  'New Zealand': {symbol:'NZ$', rate:1.65},
  'Pakistan': {symbol:'Rs', rate:278},
  'Bangladesh': {symbol:'Tk', rate:110},
  'Indonesia': {symbol:'Rp', rate:15600},
  'Malaysia': {symbol:'RM', rate:4.7},
  'Brazil': {symbol:'R$', rate:5.0},
  'Mexico': {symbol:'Mex$', rate:17},
  'Japan': {symbol:'¥', rate:150},
};
const INCOME_USD_RANGES = [
  [null, 15000], [15000, 24999], [24000, 49999], [50000, 74999],
  [75000, 99999], [100000, 149999], [150000, 199999], [200000, 249999], [250000, null]
];
function fmtLocal(n, symbol) {
  return symbol + Math.round(n).toLocaleString('en-US');
}
function populateCountryDropdown() {
  const sel = document.getElementById('prescreen_country');
  const names = Object.keys(COUNTRY_CURRENCY).sort();
  names.forEach(name => {
    const opt = document.createElement('option');
    opt.value = name; opt.textContent = name;
    sel.appendChild(opt);
  });
  const otherOpt = document.createElement('option');
  otherOpt.value = 'Other'; otherOpt.textContent = 'Other / Not listed (USD)';
  sel.appendChild(otherOpt);
  if (DETECTED_COUNTRY && COUNTRY_CURRENCY[DETECTED_COUNTRY]) {
    sel.value = DETECTED_COUNTRY;
    updateIncomeCurrency();
  }
}
function updateIncomeCurrency() {
  const country = document.getElementById('prescreen_country').value;
  const info = COUNTRY_CURRENCY[country];
  const incomeSelect = document.getElementById('income');
  const options = incomeSelect.querySelectorAll('option');
  options.forEach((opt, i) => {
    if (!opt.value || opt.value === 'Prefer not to say') return;
    const range = INCOME_USD_RANGES[i - 1];
    if (!range) return;
    if (!info) {
      // Reset to original USD label
      opt.textContent = opt.value;
      return;
    }
    const [lo, hi] = range;
    if (lo === null) opt.textContent = 'Less than ' + fmtLocal(hi * info.rate, info.symbol);
    else if (hi === null) opt.textContent = fmtLocal(lo * info.rate, info.symbol) + ' or greater';
    else opt.textContent = fmtLocal(lo * info.rate, info.symbol) + ' to ' + fmtLocal(hi * info.rate, info.symbol);
  });
}
document.addEventListener('DOMContentLoaded', populateCountryDropdown);

const vals = { gender: '', age_group: '', education: '', income: '', device_self: '' };
const qLabels = {
  gender: 'What is your gender?',
  age_group: 'What is your age group?',
  education: 'What is your highest education level?',
  income: 'What is your approximate monthly household income?',
  device_self: 'What device are you using right now?',
  open_end: 'Tell us a little about yourself.'
};

function selectRadio(name, value, el) {
    if (USING_DYNAMIC) { dynVals[name] = value; }
    else { vals[name] = value; }
    document.querySelectorAll('#grp-' + name + ' .radio-row').forEach(r => r.classList.remove('selected'));
    document.querySelectorAll('#grp-' + name + ' .radio-dot').forEach(d => d.classList.remove('filled'));
    el.classList.add('selected');
    el.querySelector('.radio-dot').classList.add('filled');
    if (USING_DYNAMIC) { updateProgressDynamic(); } else { updateProgress(); }
}

function updateCounter() {
    const len = document.getElementById('open_end').value.length;
    const el = document.getElementById('charCount');
    el.textContent = len + ' / 200';
    el.style.color = len >= 180 ? 'rgba(200,168,75,0.7)' : 'rgba(160,190,255,0.3)';
}

function updateProgress() {
    vals.age_group = document.getElementById('age_group').value;
    vals.education = document.getElementById('education').value;
    vals.income    = document.getElementById('income').value;
    const filled   = Object.values(vals).filter(v => v).length;
    const openEnd  = document.getElementById('open_end').value.trim().length >= 10 ? 1 : 0;
    const total    = filled + openEnd;
    document.getElementById('progFill').style.width = (total / 6 * 100) + '%';
    document.getElementById('progText').textContent = total + ' of 6';
}

function submitPreSurvey() {
    updateProgress();
    const err = document.getElementById('errMsg');
    if (Object.values(vals).some(v => !v)) {
        err.textContent = '⚠ Please answer all questions before continuing.';
        err.style.display = 'block';
        err.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        return;
    }
    const openVal = document.getElementById('open_end').value.trim();
    if (openVal.length < 10) {
        err.textContent = '⚠ Please tell us a little about yourself to continue (minimum 10 characters).';
        err.style.display = 'block';
        err.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        return;
    }
    err.style.display = 'none';

    const answers = { gender: vals.gender, age_group: vals.age_group, education: vals.education,
        income: vals.income, device_self: vals.device_self, open_end: openVal };

    // Fire-and-forget: one capture call per answer. Redirect happens
    // immediately regardless of whether these complete — the respondent
    // must never be stuck waiting on a slow/flaky network call.
    Object.keys(answers).forEach(key => {
        fetch('capture_screener.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ sid: SID, uid: UID, question_key: key, question_text: qLabels[key], answer_value: answers[key] })
        }).catch(() => {});
    });

    window.location.href = SURVEY_URL;
}
</script>
</body>
</html>
