<?php
// ============================================================
// Exazon Research — report.php
// Public, no-login, read-only project report — accessed via a
// share-link token generated from Project Details.
// ============================================================
require_once __DIR__ . '/inc_exz.php';

$db = exz_db();
$token = trim($_GET['token'] ?? '');

$sl = $db->prepare("SELECT * FROM exz_share_links WHERE token=? AND is_revoked=0 LIMIT 1");
$sl->execute([$token]);
$link = $sl->fetch();

if (!$link) {
    http_response_code(403);
    die('<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Link Invalid</title>
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0a1628;color:#e2e8f0;margin:0}
    .box{text-align:center;padding:40px;background:#0f1f38;border-radius:12px;border:1px solid rgba(59,130,246,0.15)}
    h2{color:#f59e0b}p{color:#94a3b8}</style></head>
    <body><div class="box"><h2>⚠ Link Invalid or Revoked</h2><p>Please request a new report link from Exazon Research.</p></div></body></html>');
}

$sid = $link['survey_id'];

$proj = $db->prepare("SELECT ps.*, c.client_name AS cname FROM project_settings ps
    LEFT JOIN exz_clients c ON c.id = ps.client_id WHERE ps.survey_id=? LIMIT 1");
$proj->execute([$sid]);
$p = $proj->fetch();

$st = $db->prepare("SELECT COUNT(*) as total, SUM(status='complete') as completes,
    SUM(status='terminate') as terminates FROM survey_responses WHERE survey_id=?");
$st->execute([$sid]);
$stats = $st->fetch();
$total = (int)($stats['total'] ?? 0);
$completes = (int)($stats['completes'] ?? 0);
$terminates = (int)($stats['terminates'] ?? 0);
$target = (int)($p['target'] ?? 0);
$pct = $target > 0 ? min(100, round($completes / $target * 100)) : 0;

$trend = $db->prepare("SELECT DATE(created_at) as day, SUM(status='complete') as c
    FROM survey_responses WHERE survey_id=? AND created_at >= DATE_SUB(NOW(), INTERVAL 14 DAY)
    GROUP BY DATE(created_at) ORDER BY day ASC");
$trend->execute([$sid]);
$trendData = $trend->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Project Report — <?= htmlspecialchars($p['project_name'] ?: $sid) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'DM Sans',sans-serif;background:#f4f6fb;color:#0f172a}
.header{background:#0a1628;padding:20px 28px}
.header .brand{font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:2px;color:#fff}
.header .sub{font-size:10px;letter-spacing:2px;color:#c8a84b;text-transform:uppercase}
.content{max-width:900px;margin:0 auto;padding:28px 20px}
.title{font-size:22px;font-weight:700;margin-bottom:4px}
.subtitle{color:#64748b;font-size:13px;margin-bottom:24px}
.stat-row{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:24px}
.stat-card{background:#fff;border-radius:12px;padding:20px;border-top:4px solid #3b82f6;text-align:center}
.stat-card.green{border-top-color:#22c55e}
.stat-card.orange{border-top-color:#f59e0b}
.stat-lbl{font-size:11px;letter-spacing:1px;text-transform:uppercase;color:#94a3b8;margin-bottom:8px}
.stat-val{font-size:34px;font-weight:700}
.card{background:#fff;border-radius:12px;padding:22px;margin-bottom:20px;border:1px solid #e5e9f2}
.card-title{font-size:12px;letter-spacing:1.5px;text-transform:uppercase;color:#94a3b8;font-weight:700;margin-bottom:16px}
.progress-bar{background:#e2e8f0;border-radius:8px;height:14px;overflow:hidden;margin-bottom:8px}
.progress-fill{background:linear-gradient(90deg,#3b82f6,#22c55e);height:100%}
.confidential{background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.25);color:#92400e;border-radius:8px;padding:10px 16px;font-size:12px;text-align:center;margin-bottom:20px}
footer{text-align:center;color:#94a3b8;font-size:11px;padding:20px}
@media print{ .no-print{display:none !important} body{background:#fff} }
</style>
</head>
<body>

<div class="header">
  <div class="brand">EXAZON RESEARCH</div>
  <div class="sub">Client Project Report</div>
</div>

<div class="content">
  <div class="confidential">🔒 This report is confidential and intended only for <?= htmlspecialchars($p['cname'] ?: 'the assigned client') ?>. Please do not share or distribute.</div>

  <div class="title"><?= htmlspecialchars($p['project_name'] ?: $sid) ?></div>
  <div class="subtitle">Project ID: <?= htmlspecialchars($sid) ?> · Client: <?= htmlspecialchars($p['cname'] ?: '—') ?></div>
  <div class="no-print" style="margin-bottom:20px">
    <button onclick="window.print()" style="background:linear-gradient(135deg,#1b4fd8,#3b82f6);color:#fff;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:600;cursor:pointer">🖨 Print / Save as PDF</button>
  </div>

  <div class="stat-row">
    <div class="stat-card"><div class="stat-lbl">Total Clicks</div><div class="stat-val"><?= $total ?></div></div>
    <div class="stat-card green"><div class="stat-lbl">Completes</div><div class="stat-val"><?= $completes ?></div></div>
    <div class="stat-card orange"><div class="stat-lbl">Terminates</div><div class="stat-val"><?= $terminates ?></div></div>
  </div>

  <?php if ($target > 0): ?>
  <div class="card">
    <div class="card-title">Quota Progress</div>
    <div class="progress-bar"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
    <div style="font-size:13px;color:#475569"><?= $completes ?> / <?= $target ?> completes (<?= $pct ?>%)</div>
  </div>
  <?php endif; ?>

  <div class="card">
    <div class="card-title">Project Status</div>
    <div style="font-size:14px"><strong>Status:</strong> <?= ucfirst($p['status'] ?? '—') ?></div>
    <div style="font-size:14px;margin-top:6px"><strong>Last Updated:</strong> <?= date('d M Y, H:i') ?> IST</div>
  </div>
</div>

<footer>© <?= date('Y') ?> Exazon Research LLP · This link is read-only and can be revoked at any time by Exazon Research.</footer>
<?php if (isset($_GET['print'])): ?>
<script>window.addEventListener('load', () => setTimeout(() => window.print(), 400));</script>
<?php endif; ?>
</body>
</html>
