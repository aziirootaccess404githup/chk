<?php
// ============================================================
// test_client_survey.php — MOCK CLIENT SURVEY (testing only)
// Set this file's URL as a project's "Live Survey URL" to test
// the full flow without a real client survey. It reads whatever
// uid/sid vendor.php or prescreener.php passed in, and gives you
// 4 buttons to simulate the respondent finishing the "survey"
// with each possible outcome.
// ============================================================
$sid = trim($_GET['sid'] ?? $_GET['SID'] ?? '');
$uid = trim($_GET['uid'] ?? $_GET['r'] ?? $_GET['rid'] ?? '');
$host = $_SERVER['HTTP_HOST'];

function trackUrl($host, $status, $sid, $uid) {
    return "https://$host/pages/track.php?status=$status&sid=" . urlencode($sid) . "&uid=" . urlencode($uid);
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>TEST — Client Survey Simulator</title>
<style>
  body{font-family:'DM Sans',Arial,sans-serif;background:#f4f6fb;margin:0;padding:40px 20px;color:#1e293b}
  .wrap{max-width:640px;margin:0 auto;background:#fff;border-radius:14px;padding:32px;box-shadow:0 4px 20px rgba(0,0,0,.06)}
  .badge{background:#fef3c7;color:#92400e;font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;padding:5px 12px;border-radius:6px;display:inline-block;margin-bottom:16px}
  h1{font-size:22px;margin:0 0 6px}
  .sub{color:#64748b;font-size:13px;margin-bottom:24px}
  .info-row{display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #f1f5f9;font-size:13px}
  .info-row span:first-child{color:#94a3b8;font-weight:600}
  .info-row span:last-child{font-family:monospace;color:#1b4fd8}
  .q{background:#f8faff;border-radius:10px;padding:20px;margin:20px 0;font-size:14px}
  .btns{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:24px}
  a.btn{display:block;text-align:center;padding:14px;border-radius:10px;font-weight:700;font-size:13px;text-decoration:none;color:#fff}
  .b-complete{background:linear-gradient(135deg,#16a34a,#22c55e)}
  .b-terminate{background:linear-gradient(135deg,#64748b,#94a3b8)}
  .b-quota{background:linear-gradient(135deg,#1b4fd8,#3b82f6)}
  .b-qc{background:linear-gradient(135deg,#dc2626,#ef4444)}
  .warn{background:#fef2f2;border:1px solid #fecaca;color:#b91c1c;padding:12px 16px;border-radius:8px;font-size:12px;margin-top:16px}
</style>
</head>
<body>
<div class="wrap">
  <div class="badge">🧪 Test Mode — Not A Real Client Survey</div>
  <h1>Sample Health Awareness Study</h1>
  <div class="sub">This page simulates a client's live survey so you can test the whole ExaVerify flow end-to-end.</div>

  <div class="info-row"><span>Respondent ID received</span><span><?= htmlspecialchars($uid ?: '(none — check the entry link)') ?></span></div>
  <div class="info-row"><span>Project SID received</span><span><?= htmlspecialchars($sid ?: '(none — check the entry link)') ?></span></div>

  <div class="q">
    <strong>Q1.</strong> How satisfied are you with your current healthcare provider?<br>
    <label><input type="radio" checked> Very satisfied</label><br>
    <label><input type="radio"> Somewhat satisfied</label><br>
    <label><input type="radio"> Not satisfied</label>
  </div>

  <?php if (!$sid || !$uid): ?>
  <div class="warn">⚠️ sid/uid missing from the URL — this page was opened directly instead of via a vendor/entry link. Open it through Project View's Entry Link (with a real [UID] filled in) to test properly.</div>
  <?php else: ?>
  <p style="font-size:13px;color:#64748b">Click one of these to simulate the respondent finishing the survey with that outcome — this fires the real track.php exactly like a live client survey would:</p>
  <div class="btns">
    <a class="btn b-complete" href="<?= trackUrl($host,'complete',$sid,$uid) ?>">✅ Complete</a>
    <a class="btn b-terminate" href="<?= trackUrl($host,'terminate',$sid,$uid) ?>">⛔ Terminate</a>
    <a class="btn b-quota" href="<?= trackUrl($host,'quotafull',$sid,$uid) ?>">📊 Overquota</a>
    <a class="btn b-qc" href="<?= trackUrl($host,'qc',$sid,$uid) ?>">🚫 Quality Fail</a>
  </div>
  <?php endif; ?>
</div>
</body>
</html>
