<?php
// ============================================================
// test_vendor_postback.php — MOCK VENDOR POSTBACK RECEIVER
// Set this file's URL as a vendor's Complete/Terminate/Quotafull/
// Screenout postback URL (with [UID]/[SID]/[LOI] placeholders,
// e.g. https://yourhost/test_vendor_postback.php?status=complete&uid=[UID]&sid=[SID])
// to test that our system's background postback call actually
// fires with the right data. Every call gets logged below; visit
// this file directly (no params) to see the log.
// ============================================================
$log_file = __DIR__ . '/test_postback_log.json';

$has_params = !empty($_GET) && (isset($_GET['uid']) || isset($_GET['status']));

if ($has_params) {
    // This is a real (or test) postback call — log it and return a tiny OK response.
    $entry = [
        'received_at' => date('Y-m-d H:i:s'),
        'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
        'params' => $_GET,
    ];
    $log = [];
    if (file_exists($log_file)) {
        $log = json_decode(file_get_contents($log_file), true) ?: [];
    }
    array_unshift($log, $entry);
    $log = array_slice($log, 0, 100); // keep last 100
    @file_put_contents($log_file, json_encode($log, JSON_PRETTY_PRINT));
    header('Content-Type: text/plain');
    echo "OK";
    exit;
}

// No params — show the log viewer
$log = [];
if (file_exists($log_file)) {
    $log = json_decode(file_get_contents($log_file), true) ?: [];
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>TEST — Vendor Postback Log</title>
<style>
  body{font-family:'DM Sans',Arial,sans-serif;background:#f4f6fb;margin:0;padding:40px 20px;color:#1e293b}
  .wrap{max-width:900px;margin:0 auto}
  .badge{background:#dbeafe;color:#1e40af;font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;padding:5px 12px;border-radius:6px;display:inline-block;margin-bottom:16px}
  h1{font-size:22px;margin:0 0 6px}
  .sub{color:#64748b;font-size:13px;margin-bottom:24px}
  .card{background:#fff;border-radius:10px;padding:16px 20px;margin-bottom:12px;box-shadow:0 2px 8px rgba(0,0,0,.05)}
  .time{font-size:11px;color:#94a3b8;float:right}
  .params{font-family:monospace;font-size:12px;background:#f8faff;border-radius:6px;padding:10px;margin-top:8px}
  .empty{text-align:center;padding:60px;color:#94a3b8}
  .clear{background:#fee2e2;color:#b91c1c;border:none;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;margin-bottom:20px}
</style>
</head>
<body>
<div class="wrap">
  <div class="badge">🧪 Test Mode — Mock Vendor Postback Receiver</div>
  <h1>Received Postback Calls</h1>
  <div class="sub">Use this file's URL as a vendor's postback URL (with [UID]/[SID]/[LOI] placeholders) to verify our system actually fires postbacks correctly. Newest first, last 100 kept.</div>

  <form method="POST" onsubmit="return confirm('Clear the log?')">
    <?php if (isset($_POST['clear'])) { @unlink($log_file); $log = []; } ?>
    <button class="clear" type="submit" name="clear" value="1">🗑 Clear Log</button>
  </form>

  <?php if (empty($log)): ?>
  <div class="card empty">No postback calls received yet. Set a vendor's postback URL to this file (with placeholders) and complete a test respondent to see it appear here.</div>
  <?php else: foreach ($log as $entry): ?>
  <div class="card">
    <span class="time"><?= htmlspecialchars($entry['received_at']) ?> · from <?= htmlspecialchars($entry['ip']) ?></span>
    <strong>Postback received</strong>
    <div class="params"><?php foreach ($entry['params'] as $k => $v) echo htmlspecialchars($k).' = '.htmlspecialchars($v).'<br>'; ?></div>
  </div>
  <?php endforeach; endif; ?>
</div>
</body>
</html>
