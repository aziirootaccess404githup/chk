<?php
// ============================================================
// Exazon Research — exaverify.php
// Short-link resolver: /exaverify.php?c=6BDBZ&pid=[UID]
//
// A compact, optional alternative to the full vendor.php entry link. The
// short code (e.g. 6BDBZ) maps internally to a specific project+vendor
// pairing, so the public URL never needs to expose sid/vid directly.
//
// This file does NOT duplicate vendor.php's logic - it resolves the code,
// then does a genuine redirect straight to vendor.php with the real
// sid/vid/uid filled in. This guarantees the short link always behaves
// EXACTLY like the full entry link (encryption, geo, vendor-pause checks,
// everything) with zero risk of the two ever drifting out of sync, since
// there's only one real implementation (vendor.php) to maintain.
// ============================================================
require_once __DIR__ . '/inc_exz.php';

$code = trim($_GET['c'] ?? '');
// Accept pid/uid/rid/toid as the incoming respondent-id param name, in
// case a vendor's own system prefers a different one - same flexibility
// as the rest of this project's token support.
$uid = trim($_GET['pid'] ?? $_GET['uid'] ?? $_GET['rid'] ?? $_GET['toid'] ?? '');

if (!$code) {
    http_response_code(400);
    die('<h3 style="font-family:sans-serif;text-align:center;margin-top:40px;color:#ef4444">Invalid link.</h3>');
}

$db = exz_db();
$row = $db->prepare("SELECT survey_id, vendor_id FROM exz_project_vendors WHERE short_code = ? LIMIT 1");
$row->execute([$code]);
$match = $row->fetch();

if (!$match) {
    http_response_code(404);
    die('
    <!DOCTYPE html><html><head><meta charset="UTF-8"><title>Not Available</title>
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0a1628;color:#e2e8f0;margin:0}
    .box{text-align:center;padding:40px;background:#111c30;border-radius:12px;border:1px solid rgba(255,255,255,0.07)}
    h2{color:#f59e0b}p{color:#94a3b8;margin-top:8px}</style>
    </head><body><div class="box"><h2>⚠ Link Not Valid</h2><p>This link is no longer active. Please contact your panel provider.</p></div></body></html>
    ');
}

$base = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
$target = "$base/vendor.php?sid=" . urlencode($match['survey_id']) . "&vid=" . urlencode($match['vendor_id']) . "&uid=" . urlencode($uid);
header("Location: $target");
exit();
