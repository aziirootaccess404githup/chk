<?php
// ============================================================
// EXAZON RESEARCH — Client Portal Login
// File: hub/client/login.php
// ============================================================
session_start();
define('DB_HOST', 'localhost');
define('DB_NAME', 'u994909610_Exaverify');
define('DB_USER', 'u994909610_Exaverify');
define('DB_PASS', 'Exaverify@8181');

function getDB() {
    static $pdo;
    if ($pdo) return $pdo;
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
    return $pdo;
}

// Ensure clients table exists
function ensureClientsTable() {
    $pdo = getDB();
    $pdo->exec("CREATE TABLE IF NOT EXISTS `portal_clients` (
        `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `username`         VARCHAR(60) NOT NULL UNIQUE,
        `password_hash`    VARCHAR(255) NOT NULL,
        `client_name`      VARCHAR(100) NOT NULL,
        `allowed_projects` TEXT DEFAULT NULL,
        `is_active`        TINYINT(1) DEFAULT 1,
        `last_login`       DATETIME DEFAULT NULL,
        `created_at`       DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

ensureClientsTable();

$error = '';

// Already logged in
if (!empty($_SESSION['client_auth']) && !empty($_SESSION['client_id'])) {
    header('Location: portal.php'); exit;
}

// Login submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($username && $password) {
        try {
            $pdo  = getDB();
            $stmt = $pdo->prepare("SELECT * FROM portal_clients WHERE username=? AND is_active=1");
            $stmt->execute([$username]);
            $client = $stmt->fetch();

            if ($client && password_verify($password, $client['password_hash'])) {
                $_SESSION['client_auth']     = true;
                $_SESSION['client_id']       = $client['id'];
                $_SESSION['client_name']     = $client['client_name'];
                $_SESSION['client_username'] = $client['username'];

                // Auto-derive SIDs from the linked master Client record (project_settings.client_id)
                // so newly-added projects for this client show up automatically —
                // merged with any manually-added extra SIDs.
                $auto_sids = [];
                if (!empty($client['client_id'])) {
                    try {
                        $asid = $pdo->prepare("SELECT survey_id FROM project_settings WHERE client_id=?");
                        $asid->execute([$client['client_id']]);
                        $auto_sids = $asid->fetchAll(PDO::FETCH_COLUMN);
                    } catch (Exception $e) {}
                }
                $manual_sids = array_filter(array_map('trim', explode(',', $client['allowed_projects'] ?? '')));
                $_SESSION['client_projects'] = implode(',', array_unique(array_merge($auto_sids, $manual_sids)));

                // Update last login
                $pdo->prepare("UPDATE portal_clients SET last_login=NOW() WHERE id=?")->execute([$client['id']]);

                header('Location: portal.php'); exit;
            } else {
                $error = 'Invalid username or password.';
            }
        } catch (Exception $e) {
            $error = 'System error. Please try again.';
        }
    } else {
        $error = 'Please enter username and password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Exazon Research — Client Portal</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'DM Sans',sans-serif;background:#040d1a;min-height:100vh;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden}
.bg-grid{position:fixed;inset:0;background-image:linear-gradient(rgba(30,80,180,0.06) 1px,transparent 1px),linear-gradient(90deg,rgba(30,80,180,0.06) 1px,transparent 1px);background-size:44px 44px;pointer-events:none}
.bg-glow{position:fixed;top:-100px;left:50%;transform:translateX(-50%);width:700px;height:500px;background:radial-gradient(ellipse,rgba(20,80,220,0.15) 0%,transparent 70%);pointer-events:none}
.wrap{position:relative;z-index:10;width:100%;max-width:420px;padding:20px}
.card{background:rgba(8,18,40,0.92);border:1px solid rgba(30,100,255,0.18);border-radius:20px;padding:44px 38px;backdrop-filter:blur(14px);box-shadow:0 24px 64px rgba(0,0,0,0.4)}
.logo-row{display:flex;flex-direction:column;align-items:center;margin-bottom:28px}
.logo-circle{width:62px;height:62px;border-radius:50%;background:linear-gradient(135deg,#1b4fd8,#3b82f6);display:flex;align-items:center;justify-content:center;font-size:26px;margin-bottom:12px;box-shadow:0 0 32px rgba(59,130,246,0.3)}
.brand{font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:3px;color:#fff}
.brand-sub{font-size:9px;letter-spacing:4px;text-transform:uppercase;color:#c8a84b;margin-top:3px}
.portal-tag{background:rgba(27,79,216,0.15);border:1px solid rgba(27,79,216,0.3);border-radius:20px;padding:5px 16px;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#60a5fa;margin-top:10px}
.divider{height:1px;background:linear-gradient(90deg,transparent,rgba(30,100,255,0.3),transparent);margin:24px 0}
.form-label{display:block;font-size:10px;font-weight:600;letter-spacing:2px;text-transform:uppercase;color:#64748b;margin-bottom:6px}
.form-input{width:100%;background:rgba(255,255,255,0.04);border:1px solid rgba(30,100,255,0.18);border-radius:10px;padding:13px 16px;font-family:'DM Sans',sans-serif;font-size:14px;color:#e2e8f0;outline:none;transition:border-color 0.2s;margin-bottom:14px}
.form-input:focus{border-color:#3b82f6;background:rgba(59,130,246,0.06)}
.form-input::placeholder{color:#334155}
.btn-login{width:100%;background:linear-gradient(135deg,#1b4fd8,#3b82f6);color:#fff;border:none;border-radius:10px;padding:14px;font-family:'Bebas Neue',sans-serif;font-size:17px;letter-spacing:3px;cursor:pointer;margin-top:4px;transition:all 0.2s;box-shadow:0 4px 20px rgba(27,79,216,0.3)}
.btn-login:hover{transform:translateY(-1px);box-shadow:0 8px 28px rgba(27,79,216,0.45)}
.error-box{background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.25);border-radius:8px;padding:10px 14px;font-size:12px;color:#fca5a5;margin-bottom:14px;text-align:center}
.footer-note{text-align:center;margin-top:20px;font-size:11px;color:#1e3a5f}
.footer-note a{color:#3b82f6;text-decoration:none}
.secure-badge{display:flex;align-items:center;justify-content:center;gap:6px;margin-top:16px;font-size:10px;color:#1e3a5f;letter-spacing:1px}
</style>
</head>
<body>
<div class="bg-grid"></div>
<div class="bg-glow"></div>
<div class="wrap">
  <div class="card">
    <div class="logo-row">
      <div class="logo-circle">🔬</div>
      <div class="brand">Exazon Research</div>
      <div class="brand-sub">Insight · Innovation · Impact</div>
      <div class="portal-tag">Client Portal</div>
    </div>
    <div class="divider"></div>

    <?php if ($error): ?>
    <div class="error-box">⚠️ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" autocomplete="off">
      <label class="form-label">Username</label>
      <input class="form-input" type="text" name="username" placeholder="Your username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" autofocus>
      <label class="form-label">Password</label>
      <input class="form-input" type="password" name="password" placeholder="••••••••">
      <button class="btn-login" type="submit">Access Portal →</button>
    </form>

    <div class="secure-badge">🔒 Secure · Encrypted · Read-Only Access</div>
    <div class="footer-note">Need access? <a href="mailto:info@exazonresearch.com">Contact ExaVerify</a></div>
  </div>
</div>
</body>
</html>
