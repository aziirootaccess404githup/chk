<?php
// ============================================================
// Exazon Research — client_redirect.php
// CLIENT-LEVEL status handler: complete / terminate / quotafull / qc
// URL: /client_redirect.php?client=CLT7f3a2b&type=complete&uid=[UID]
//
// Unlike pages/track.php (which needs a project sid in the URL), this
// endpoint only needs a CLIENT code + the respondent uid. It looks across
// every project belonging to that client to find the matching lead, so the
// SAME 4 URLs keep working correctly no matter how many new projects get
// created for that client in the future — never regenerated or edited.
//
// Once the lead is found, this uses the exact same status-lock, duplicate-
// check, quota-check, and vendor-postback logic as pages/track.php, then
// redirects to the SAME existing branded status pages (pages/complete.html
// etc.) that track.php already uses — no new UI, fully consistent.
// ============================================================
require_once __DIR__ . '/inc_exz.php';

$db = exz_db();
exz_ensure_client_extra_columns($db);

// ── PARAMETERS ──────────────────────────────────────────────
$status = trim($_GET['type'] ?? $_GET['status'] ?? 'unknown');
// Flexible param-name fallback — some client platforms send the identifier
// back under a different name (same fallback list as track.php).
$uid = trim($_GET['uid'] ?? $_GET['rid'] ?? $_GET['toid'] ?? $_GET['identifier'] ?? $_GET['tid'] ?? $_GET['pid'] ?? '');
$client_code = trim($_GET['client'] ?? '');
$ip  = exz_get_ip();

if (!$client_code || !$uid) {
    die('
    <!DOCTYPE html><html><head><meta charset="UTF-8"><title>Not Available</title>
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0a1628;color:#e2e8f0;margin:0}
    .box{text-align:center;padding:40px;background:#111c30;border-radius:12px;border:1px solid rgba(255,255,255,0.07)}
    h2{color:#f59e0b}p{color:#94a3b8;margin-top:8px}</style>
    </head><body><div class="box"><h2>⚠ Link Not Valid</h2><p>This link is missing required information. Please contact your panel provider.</p></div></body></html>
    ');
}

// ── Find the client ────────────────────────────────────────
$cs = $db->prepare("SELECT * FROM exz_clients WHERE client_uid = ? LIMIT 1");
$cs->execute([$client_code]);
$client = $cs->fetch();

if (!$client) {
    die('
    <!DOCTYPE html><html><head><meta charset="UTF-8"><title>Not Available</title>
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0a1628;color:#e2e8f0;margin:0}
    .box{text-align:center;padding:40px;background:#111c30;border-radius:12px;border:1px solid rgba(255,255,255,0.07)}
    h2{color:#f59e0b}p{color:#94a3b8;margin-top:8px}</style>
    </head><body><div class="box"><h2>⚠ Link Not Valid</h2><p>This link is missing required information. Please contact your panel provider.</p></div></body></html>
    ');
}

// ── Find the lead: search across ALL of this client's projects ──
// Matches survey_responses.respondent directly (a repeat/known hit), with a
// fallback to survey_starts.uid (covers a respondent's very FIRST
// completion, before any survey_responses row exists yet for them) —
// same two-tier logic track.php already uses for its own sid-fallback,
// just scoped by client instead of starting from a URL sid.
$sid = '';
$existing = null;

$lc = $db->prepare("
    SELECT sr.* FROM survey_responses sr
    JOIN project_settings ps ON ps.survey_id = sr.survey_id
    WHERE ps.client_id = ? AND sr.respondent = ?
    ORDER BY sr.id DESC LIMIT 1
");
$lc->execute([$client['id'], $uid]);
$existing = $lc->fetch();

if ($existing) {
    $sid = $existing['survey_id'];
} else {
    // No completion on file yet for this respondent - check survey_starts
    // (written by vendor.php at entry time) across this client's projects.
    $ss = $db->prepare("
        SELECT ss.sid FROM survey_starts ss
        JOIN project_settings ps ON ps.survey_id = ss.sid
        WHERE ps.client_id = ? AND ss.uid = ?
        ORDER BY ss.id DESC LIMIT 1
    ");
    $ss->execute([$client['id'], $uid]);
    $sid = $ss->fetchColumn() ?: '';
}

if (!$sid) {
    // Genuinely no record of this respondent under this client at all.
    die('
    <!DOCTYPE html><html><head><meta charset="UTF-8"><title>Under Review</title>
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0a1628;color:#e2e8f0;margin:0}
    .box{text-align:center;padding:40px;background:#111c30;border-radius:12px;border:1px solid rgba(255,255,255,0.07)}
    h2{color:#94a3b8}p{color:#94a3b8;margin-top:8px}</style>
    </head><body><div class="box"><h2>⏳ Thank You</h2><p>Your response has been received and is currently under review.</p></div></body></html>
    ');
}

$is_repeat_locked = false;
if ($existing && !empty($existing['status_locked'])) {
    $status = $existing['status'];
    $is_repeat_locked = true;
}

// ── DUPLICATE DETECTION ON ALREADY-LOCKED LEADS (same as track.php) ──
// A repeat hit here is genuinely useful fraud signal (a vendor/client
// resubmitting, or a respondent trying again) — must not be silently
// invisible to Fraud Detection just because the lead is locked and no
// further write happens to it. Flag is_duplicate=1 and fire the Telegram
// alert, but only the FIRST time a repeat is seen for this lead.
if ($is_repeat_locked && $existing && empty($existing['is_duplicate'])) {
    try {
        $db->prepare("UPDATE survey_responses SET is_duplicate=1 WHERE id=?")->execute([$existing['id']]);
        exz_send_telegram($db, "⚠️ Duplicate UID! (repeat hit on an already-locked lead, via client-level link)\nProject: $sid\nUID: $uid\nStatus: $status | IP: $ip\nThe same respondent attempted again after their result was already locked in!");
    } catch (Exception $e) {}
}

// ── Status recognition — dynamic synonym table (same as track.php) ──
// Runs BEFORE the unmatched-check below (matching track.php's order) so
// a client-specific word like "success" gets resolved to "complete"
// first, instead of the unmatched-check clobbering it before synonym
// resolution ever got a chance to run.
exz_ensure_status_synonyms_table($db);
exz_seed_default_status_synonyms($db);
$resolved = exz_resolve_status_synonym($db, $status, $sid);
if ($resolved !== null) {
    $status = $resolved;
} else {
    $status_map = ['complete'=>'complete','terminate'=>'terminate','quotafull'=>'quotafull','overquota'=>'quotafull','qc'=>'qc','quality'=>'qc','screenout'=>'qc'];
    $status = $status_map[strtolower($status)] ?? $status;
}

// ── UNMATCHED-STATUS SAFETY NET (same as pages/track.php) ────
// Prevents an unrecognized/missing status from silently looking like (or
// being counted as) a genuine complete — which is exactly the kind of
// mismatch that causes a payment dispute later.
$known_statuses = ['complete', 'terminate', 'qc', 'quality', 'quotafull'];
$is_unmatched = !$is_repeat_locked && !in_array($status, $known_statuses);
if ($is_unmatched) {
    $status = 'unmatched';
}

// ── GHOST-ENTRY CHECK (same as pages/track.php) ──────────────
// Did this UID ever actually enter via our own entry link (vendor.php)?
// If survey_starts has NO record for this UID at all, this completion
// arrived out of nowhere. We still SAVE it (fully auditable), but flag
// it so it doesn't get silently counted as a normal, trustworthy complete.
$no_entry_record = 0;
try {
    $anyStart = $db->prepare("SELECT COUNT(*) FROM survey_starts WHERE uid=?");
    $anyStart->execute([$uid]);
    if ($anyStart->fetchColumn() == 0) $no_entry_record = 1;
} catch (Exception $e) { error_log("client_redirect.php ghost-entry check error: ".$e->getMessage()); }

// ── PROJECT + CLIENT NAME ──────────────────────────────────
$proj = null;
$client_name = $client['client_name'];
$pp = $db->prepare("SELECT * FROM project_settings WHERE survey_id=? LIMIT 1");
$pp->execute([$sid]);
$proj = $pp->fetch();

// ── GEO / DEVICE / BROWSER ──────────────────────────────────
exz_ensure_browser_column($db);
$geo     = exz_geo($ip);
$device  = exz_device();
$browser = exz_browser();

// ── LOI CALCULATION (self-measured, same as track.php) ──────
// NOTE: computed via SQL TIMESTAMPDIFF (not PHP DateTime math) deliberately
// — survey_starts.start_time is written by MySQL's own CURRENT_TIMESTAMP
// (DB server's own timezone), while this app's PHP timezone is set to
// Asia/Kolkata. Diffing via `new DateTime($dbString)` would silently
// misinterpret that string as IST, adding a ~5.5-hour offset to every LOI.
// TIMESTAMPDIFF keeps both sides of the diff on the DB's own clock.
$loi_seconds = null;
$vendor_id   = null;
$st = $db->prepare("SELECT TIMESTAMPDIFF(SECOND, start_time, NOW()) AS loi_calc, vendor_id, source FROM survey_starts WHERE uid=? AND sid=? ORDER BY id DESC LIMIT 1");
$st->execute([$uid, $sid]);
$srow = $st->fetch();
$source = 'direct';
if ($srow) {
    if ($srow['loi_calc'] !== null) {
        $loi_seconds = max(0, (int)$srow['loi_calc']);
    }
    $vendor_id = $srow['vendor_id'] ?: null;
    $source = $srow['source'] ?: 'direct';
}
if ($is_repeat_locked && $existing) {
    $vendor_id   = $existing['vendor_id'] ?: $vendor_id;
    $loi_seconds = $existing['loi_seconds'] ?? $loi_seconds;
}

// ── DUPLICATE CHECK ─────────────────────────────────────────
$is_duplicate = 0;
if (!$is_repeat_locked) {
    $dup = $db->prepare("SELECT COUNT(*) FROM survey_responses WHERE respondent=? AND survey_id=?");
    $dup->execute([$uid, $sid]);
    if ($dup->fetchColumn() > 0) $is_duplicate = 1;
}

// ── SAVE / UPDATE (status-lock: only write if not already locked) ────
$lock_value = $is_unmatched ? 0 : 1; // unmatched stays UNLOCKED, so a real status arriving later can still overwrite it
if (!$is_repeat_locked) {
    if ($existing) {
        $db->prepare("UPDATE survey_responses SET status=?,ip=?,country=?,city=?,device=?,browser=?,source=?,client_name=?,loi_seconds=?,is_duplicate=?,vendor_id=?,status_locked=?,no_entry_record=? WHERE id=?")
           ->execute([$status,$ip,$geo['country'],$geo['city'],$device,$browser,$source,$client_name,$loi_seconds,$is_duplicate,$vendor_id,$lock_value,$no_entry_record,$existing['id']]);
    } else {
        $db->prepare("INSERT INTO survey_responses
            (survey_id,respondent,status,ip,country,city,device,browser,source,client_name,loi_seconds,is_duplicate,vendor_id,status_locked,no_entry_record,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())")
           ->execute([$sid,$uid,$status,$ip,$geo['country'],$geo['city'],$device,$browser,$source,$client_name,$loi_seconds,$is_duplicate,$vendor_id,$lock_value,$no_entry_record]);
    }
    if ($status === 'complete' && !$no_entry_record) exz_check_quota($db, $sid);
}

if (!$is_repeat_locked && $no_entry_record === 1) {
    exz_send_telegram($db, "👻 Ghost Entry! (via client-level link)\nProject: $sid\nUID: $uid\nStatus: $status | IP: $ip\nThis completion has NO matching entry-click on record — recorded but excluded from stats/billing/vendor-postback.");
}

if (!$is_repeat_locked && $is_duplicate === 1) {
    exz_send_telegram($db, "⚠️ Duplicate UID! (via client-level link)\nProject: $sid\nUID: $uid\nStatus: $status | IP: $ip");
}

// ── VENDOR REDIRECT-MODE CHECK ───────────────────────────────
$vendor_redirect = ($is_unmatched || $no_entry_record) ? null : exz_build_vendor_redirect($db, $vendor_id, $status, $uid, $sid, $loi_seconds);
if ($vendor_redirect) {
    header("Location: $vendor_redirect");
    exit();
}

// ── REDIRECT TO THE SAME EXISTING STATUS PAGES track.php USES ──
$pages = ['complete'=>'complete','terminate'=>'terminate','qc'=>'quality-fail','quotafull'=>'quota-full','unmatched'=>'unmatched'];
$page = $pages[$status] ?? 'unmatched';
header("Location: /pages/{$page}.html?status=$status&sid=$sid&uid=$uid");

// ── DEFERRED: vendor postback + speeder alert (after response sent) ──
if (!$is_repeat_locked) {
    exz_flush_and_defer($db, ($is_unmatched || $no_entry_record) ? null : $vendor_id, $status, $uid, $sid, $proj, $loi_seconds);
}
exit();
