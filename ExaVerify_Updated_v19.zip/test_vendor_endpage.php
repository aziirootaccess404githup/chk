<?php
// ============================================================
// test_vendor_endpage.php — MOCK VENDOR'S OWN END PAGE
// Set this file's URL as a vendor's Complete/Terminate/Quotafull/
// Screenout URL (with [UID]/[SID] placeholders) AND set that
// vendor's "End Page Behavior" to "Redirect to vendor's page" to
// test that mode — the respondent's own browser should land here
// (instead of our complete.html etc.) with the right data.
// ============================================================
$status = trim($_GET['status'] ?? '(not passed)');
$sid = trim($_GET['sid'] ?? $_GET['SID'] ?? '(not passed)');
$uid = trim($_GET['uid'] ?? $_GET['UID'] ?? '(not passed)');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>TEST — Vendor's Own End Page</title>
<style>
  body{font-family:'DM Sans',Arial,sans-serif;background:#111827;margin:0;padding:60px 20px;color:#e5e7eb;display:flex;align-items:center;justify-content:center;min-height:100vh}
  .wrap{max-width:520px;text-align:center}
  .badge{background:#374151;color:#facc15;font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;padding:5px 12px;border-radius:6px;display:inline-block;margin-bottom:20px}
  h1{font-size:26px;margin:0 0 10px}
  .sub{color:#9ca3af;font-size:14px;margin-bottom:30px}
  .card{background:#1f2937;border-radius:12px;padding:24px;text-align:left}
  .row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #374151;font-size:13px}
  .row:last-child{border-bottom:none}
  .row span:first-child{color:#9ca3af}
  .row span:last-child{font-family:monospace;color:#60a5fa}
</style>
</head>
<body>
<div class="wrap">
  <div class="badge">🧪 Test Mode — This Is The VENDOR'S Page, Not Ours</div>
  <h1>Thanks for participating!</h1>
  <div class="sub">This page simulates where a respondent lands when a vendor's End Page Behavior = "Redirect to vendor's page" — you should NOT see ExaVerify's own thank-you page in that mode, only this one.</div>
  <div class="card">
    <div class="row"><span>Status received</span><span><?= htmlspecialchars($status) ?></span></div>
    <div class="row"><span>SID received</span><span><?= htmlspecialchars($sid) ?></span></div>
    <div class="row"><span>UID received</span><span><?= htmlspecialchars($uid) ?></span></div>
  </div>
</div>
</body>
</html>
