<?php
// ============================================================
// Exazon Research — ajax_search.php
// Handles the "Global Search" quick-search box (header) and the
// Bulk UID Check tool — both called via fetch() from index.php's JS,
// returning an HTML fragment that gets injected into #slResultsArea.
//
// Two real bugs fixed here:
//  1) This file didn't exist at all — the search box always failed
//     (404), even though index.php had matching query-logic sitting
//     unused ($gs_results was computed but never actually rendered
//     anywhere, in index.php or otherwise).
//  2) That query started FROM survey_responses — meaning only
//     respondents who already have a final complete/terminate/etc.
//     status could ever be found. Anyone who only CLICKED an entry
//     link (or went through a prescreener) but never got a postback
//     back was invisible to search, even though their original-UID
//     mapping and entry genuinely exist in the system. Fixed by
//     searching survey_starts (all entries) as the base, LEFT JOINing
//     survey_responses (final status, if any) and exz_uid_mapping
//     (original UID, if encrypted) — so ANY respondent who ever
//     clicked an entry link is now findable, complete or not.
// ============================================================
require_once __DIR__ . '/inc_exz.php';

session_start();
if (empty($_SESSION['ex_auth'])) {
    http_response_code(401);
    echo '<div style="text-align:center;padding:30px;color:#dc2626">Session expired — please refresh the page and log in again.</div>';
    exit;
}

$db = exz_db();

function badge($tag) {
    $colors = ['clean'=>'#16a34a','duplicate'=>'#dc2626','speeder'=>'#f59e0b','flagged'=>'#f59e0b'];
    $labels = ['clean'=>'Clean','duplicate'=>'Duplicate','speeder'=>'Speeder','flagged'=>'Flagged'];
    $c = $colors[$tag] ?? '#94a3b8'; $l = $labels[$tag] ?? ucfirst($tag);
    return "<span style=\"font-size:10px;font-weight:700;color:$c;background:{$c}18;padding:3px 8px;border-radius:10px\">$l</span>";
}

// ── BULK UID CHECK (POST) ───────────────────────────────────────
if (isset($_POST['check_uids'])) {
    $sid = trim($_POST['ul_sid'] ?? '');
    $uids_raw = trim($_POST['ul_uids'] ?? '');
    $uids = array_filter(array_map('trim', preg_split('/[\r\n,]+/', $uids_raw)));
    if (empty($uids)) {
        echo '<div style="text-align:center;padding:30px;color:#94a3b8">No UIDs entered.</div>';
        exit;
    }
    $placeholders = implode(',', array_fill(0, count($uids), '?'));
    $sqlSid = $sid ? " AND ss.sid = ?" : "";
    $params = $uids;
    if ($sid) $params[] = $sid;
    try {
        $stmt = $db->prepare("SELECT ss.uid, ss.sid, ss.start_time, sr.status, um.original_uid
            FROM survey_starts ss
            LEFT JOIN survey_responses sr ON sr.survey_id = ss.sid AND sr.respondent = ss.uid
            LEFT JOIN exz_uid_mapping um ON um.encrypted_uid = ss.uid AND um.survey_id = ss.sid
            WHERE (ss.uid IN ($placeholders) OR um.original_uid IN ($placeholders))" . $sqlSid);
        $stmt->execute(array_merge($uids, $uids, $sid ? [$sid] : []));
        $rows = $stmt->fetchAll();
    } catch (Exception $e) { $rows = []; }

    $found_uids = array_map(fn($r) => $r['original_uid'] ?: $r['uid'], $rows);
    echo '<table style="width:100%;border-collapse:collapse"><thead><tr>';
    echo '<th style="padding:8px;font-size:10px;background:#f8faff;text-align:left">UID Searched</th><th style="padding:8px;font-size:10px;background:#f8faff;text-align:left">Project</th><th style="padding:8px;font-size:10px;background:#f8faff;text-align:left">Status</th><th style="padding:8px;font-size:10px;background:#f8faff;text-align:left">Entry Time</th>';
    echo '</tr></thead><tbody>';
    foreach ($uids as $u) {
        $match = null;
        foreach ($rows as $r) { if ($r['uid'] === $u || $r['original_uid'] === $u) { $match = $r; break; } }
        if ($match) {
            $statusLabel = $match['status'] ? ucfirst($match['status']) : '⏳ Pending (no completion yet)';
            echo "<tr><td style='padding:8px;font-family:monospace;font-size:11px'>" . htmlspecialchars($u) . "</td><td style='padding:8px;font-size:11px'>" . htmlspecialchars($match['sid']) . "</td><td style='padding:8px;font-size:11px'>$statusLabel</td><td style='padding:8px;font-size:11px;color:#64748b'>" . htmlspecialchars($match['start_time']) . "</td></tr>";
        } else {
            echo "<tr><td style='padding:8px;font-family:monospace;font-size:11px'>" . htmlspecialchars($u) . "</td><td colspan='3' style='padding:8px;font-size:11px;color:#dc2626'>Not found — no entry recorded for this UID</td></tr>";
        }
    }
    echo '</tbody></table>';
    exit;
}

// ── GLOBAL QUICK SEARCH (GET) ────────────────────────────────────
$gs_query = trim($_GET['gs_query'] ?? '');
if ($gs_query === '') {
    echo '<div style="text-align:center;padding:30px;color:#94a3b8">Type a UID, SID, IP, or Country to search.</div>';
    exit;
}

$like = '%' . $gs_query . '%';
try {
    // Base table is survey_starts (every entry, regardless of whether it
    // ever got a completion back) — NOT survey_responses. This is the fix:
    // a respondent who only clicked (or only got as far as a prescreener)
    // is now findable, not just ones with a final complete/terminate status.
    $stmt = $db->prepare("SELECT ss.uid AS encrypted_or_raw_uid, ss.sid, ss.vendor_id, ss.ip AS entry_ip, ss.start_time,
            sr.status, sr.ip AS completion_ip, sr.country, sr.city, sr.device, sr.loi_seconds, sr.is_duplicate, sr.created_at AS completion_time,
            um.original_uid
        FROM survey_starts ss
        LEFT JOIN survey_responses sr ON sr.survey_id = ss.sid AND sr.respondent = ss.uid
        LEFT JOIN exz_uid_mapping um ON um.encrypted_uid = ss.uid AND um.survey_id = ss.sid
        WHERE ss.uid LIKE ? OR um.original_uid LIKE ? OR ss.sid LIKE ? OR ss.ip LIKE ? OR sr.country LIKE ? OR sr.city LIKE ?
        ORDER BY ss.start_time DESC LIMIT 100");
    $stmt->execute([$like, $like, $like, $like, $like, $like]);
    $results = $stmt->fetchAll();
} catch (Exception $e) {
    echo '<div style="text-align:center;padding:30px;color:#dc2626">Search error — please try again.</div>';
    exit;
}

if (empty($results)) {
    echo '<div style="text-align:center;padding:30px;color:#94a3b8">No matches found for "' . htmlspecialchars($gs_query) . '".</div>';
    exit;
}

echo '<table style="width:100%;border-collapse:collapse"><thead><tr>';
echo '<th style="padding:8px;font-size:10px;background:#f8faff;text-align:left">UID</th>';
echo '<th style="padding:8px;font-size:10px;background:#f8faff;text-align:left">Project</th>';
echo '<th style="padding:8px;font-size:10px;background:#f8faff;text-align:left">Status</th>';
echo '<th style="padding:8px;font-size:10px;background:#f8faff;text-align:left">IP</th>';
echo '<th style="padding:8px;font-size:10px;background:#f8faff;text-align:left">Country</th>';
echo '<th style="padding:8px;font-size:10px;background:#f8faff;text-align:left">Entry Time</th>';
echo '</tr></thead><tbody>';
foreach ($results as $r) {
    $display_uid = $r['original_uid'] ?: $r['encrypted_or_raw_uid'];
    if ($r['status']) {
        $tag = !empty($r['is_duplicate']) ? 'duplicate' : (in_array($r['status'], ['qc','quality']) ? 'flagged' : 'clean');
        $statusHtml = ucfirst($r['status']) . ' ' . badge($tag);
    } else {
        $statusHtml = '<span style="color:#f59e0b;font-weight:600;font-size:11px">⏳ Pending — no completion yet</span>';
    }
    echo '<tr>';
    echo '<td style="padding:8px;font-family:monospace;font-size:11px">' . htmlspecialchars($display_uid) . '</td>';
    echo '<td style="padding:8px;font-size:11px"><a href="project_view.php?sid=' . urlencode($r['sid']) . '" style="color:#3b5bdb">' . htmlspecialchars($r['sid']) . '</a></td>';
    echo '<td style="padding:8px;font-size:11px">' . $statusHtml . '</td>';
    echo '<td style="padding:8px;font-family:monospace;font-size:11px;color:#64748b">' . htmlspecialchars($r['completion_ip'] ?: $r['entry_ip'] ?: '—') . '</td>';
    echo '<td style="padding:8px;font-size:11px">' . htmlspecialchars($r['country'] ?: '—') . '</td>';
    echo '<td style="padding:8px;font-size:11px;color:#64748b">' . htmlspecialchars($r['start_time']) . '</td>';
    echo '</tr>';
}
echo '</tbody></table>';
