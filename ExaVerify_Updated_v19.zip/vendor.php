<?php
// ============================================================
// Exazon Research — vendor.php
// Vendor/third-party entry point — tracks the click, encrypts the
// UID if needed, and redirects to the client's live survey.
// URL: /vendor.php?sid=PROJECTCODE&vid=3&uid=[UID]
// ============================================================
require_once __DIR__ . '/inc_exz.php';

$sid = trim($_GET['sid'] ?? '');
$uid = trim($_GET['uid'] ?? '');
$vid = (int)($_GET['vid'] ?? 0);

if (empty($sid) || empty($uid)) {
    die('<h3>Invalid link. Please contact support.</h3>');
}

$db = exz_db();
$ip = exz_get_ip();

// ── Blocked-IP check — stop immediately, before any lead/click is logged ──
if (exz_is_ip_blocked($db, $ip)) {
    http_response_code(403);
    die('
    <!DOCTYPE html><html><head><meta charset="UTF-8"><title>Access Denied</title>
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0a1628;color:#e2e8f0;margin:0}
    .box{text-align:center;padding:40px;background:#111c30;border-radius:12px;border:1px solid rgba(255,255,255,0.07)}
    h2{color:#ef4444}p{color:#94a3b8;margin-top:8px}</style>
    </head><body><div class="box"><h2>⛔ Access Denied</h2><p>This request could not be processed.</p></div></body></html>
    ');
}

// Look up the actual vendor name (used as the "source" of this respondent,
// instead of a generic hardcoded string) so Responses/Leads shows who
// actually sent this traffic.
$vendor_name_src = 'vendor';
if ($vid) {
    $vn = $db->prepare("SELECT vendor_name FROM exz_vendors WHERE id=?");
    $vn->execute([$vid]);
    $vname = $vn->fetchColumn();
    if ($vname) $vendor_name_src = $vname;
}

// ── FETCH PROJECT ────────────────────────────────────────────
$ps = $db->prepare("SELECT * FROM project_settings WHERE survey_id=? AND status='active' LIMIT 1");
$ps->execute([$sid]);
$project = $ps->fetch();

if (!$project) {
    die('<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Survey Not Available</title>
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0a1628;color:#e2e8f0;margin:0}
    .box{text-align:center;padding:40px;background:#0f1f38;border-radius:12px;border:1px solid rgba(59,130,246,0.15)}
    h2{color:#f59e0b;margin-bottom:10px}p{color:#94a3b8}</style></head>
    <body><div class="box"><h2>⚠ Survey Not Available</h2><p>This survey is currently not active. Please try again later.</p></div></body></html>');
}

// ── AUTHORIZED-VENDOR CHECK: this link must carry a vid that was actually
// assigned to THIS project via "Assign Vendor" in the dashboard. Without
// this check, anyone who could guess a valid sid could enter with no vid
// (or a made-up one) and still generate a fully legitimate-looking entry —
// this is what actually creates the survey_starts record other checks
// (like Ghost Entry Detection) rely on, so it has to be locked down here,
// at the source, not downstream. No vid, or a vid never assigned to this
// specific project = reject outright, nothing is recorded at all. ──
if (empty($vid)) {
    http_response_code(403);
    die('<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Invalid Link</title>
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0a1628;color:#e2e8f0;margin:0}
    .box{text-align:center;padding:40px;background:#111c30;border-radius:12px;border:1px solid rgba(255,255,255,0.07)}
    h2{color:#ef4444}p{color:#94a3b8;margin-top:8px}</style>
    </head><body><div class="box"><h2>⛔ Invalid or Unauthorized Link</h2><p>This entry link is missing required information. Please contact your panel manager.</p></div></body></html>');
}
$va_exists = $db->prepare("SELECT status FROM exz_project_vendors WHERE survey_id=? AND vendor_id=? LIMIT 1");
$va_exists->execute([$sid, $vid]);
if ($va_exists->rowCount() === 0) {
    http_response_code(403);
    die('<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Invalid Link</title>
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0a1628;color:#e2e8f0;margin:0}
    .box{text-align:center;padding:40px;background:#111c30;border-radius:12px;border:1px solid rgba(255,255,255,0.07)}
    h2{color:#ef4444}p{color:#94a3b8;margin-top:8px}</style>
    </head><body><div class="box"><h2>⛔ Invalid or Unauthorized Link</h2><p>This vendor is not authorized for this survey. Please contact your panel manager.</p></div></body></html>');
}

// ── VENDOR ASSIGNMENT STATUS (paused?) ───────────────────────
if ($vid) {
    $vcheck = $db->prepare("SELECT status FROM exz_vendors WHERE id=? LIMIT 1");
    $vcheck->execute([$vid]);
    $vstatus = $vcheck->fetchColumn();
    if ($vstatus === 'inactive') {
        die('<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Survey Not Available</title>
        <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0a1628;color:#e2e8f0;margin:0}
        .box{text-align:center;padding:40px;background:#0f1f38;border-radius:12px;border:1px solid rgba(59,130,246,0.15)}
        h2{color:#f59e0b;margin-bottom:10px}p{color:#94a3b8}</style></head>
        <body><div class="box"><h2>⏸ Survey Paused</h2><p>This survey link is currently paused. Please contact your panel manager.</p></div></body></html>');
    }
    // exz_project_vendors is keyed by survey_id directly (not project_id) in this build
    $va = $db->prepare("SELECT status FROM exz_project_vendors WHERE survey_id=? AND vendor_id=? LIMIT 1");
    $va->execute([$sid, $vid]);
    $va_status = $va->fetchColumn();
    if ($va_status === 'paused') {
        die('<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Survey Not Available</title>
        <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0a1628;color:#e2e8f0;margin:0}
        .box{text-align:center;padding:40px;background:#0f1f38;border-radius:12px;border:1px solid rgba(59,130,246,0.15)}
        h2{color:#f59e0b;margin-bottom:10px}p{color:#94a3b8}</style></head>
        <body><div class="box"><h2>⏸ Survey Paused</h2><p>This survey link is currently paused for this vendor. Please contact your panel manager.</p></div></body></html>');
    }

    // ── PER-VENDOR QUOTA ENFORCEMENT ──────────────────────────
    // Two SEPARATE caps, both optional (NULL = unlimited):
    //   max_limit    → how many COMPLETES this vendor may send (existing
    //                  column — it turned out this was never actually
    //                  enforced anywhere before now, a genuine pre-existing
    //                  gap fixed here alongside the new click_quota feature)
    //   click_quota  → how many total CLICKS (any outcome) this vendor may
    //                  send — lets you cap vendor spend/traffic even while
    //                  completes are still under target
    exz_ensure_click_quota_column($db);
    $vq = $db->prepare("SELECT max_limit, click_quota FROM exz_project_vendors WHERE survey_id=? AND vendor_id=? LIMIT 1");
    $vq->execute([$sid, $vid]);
    $vqrow = $vq->fetch();
    if ($vqrow) {
        if (!empty($vqrow['max_limit'])) {
            $completeCount = $db->prepare("SELECT COUNT(*) FROM survey_responses WHERE survey_id=? AND vendor_id=? AND status='complete'");
            $completeCount->execute([$sid, $vid]);
            if ((int)$completeCount->fetchColumn() >= (int)$vqrow['max_limit']) {
                die('<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Quota Reached</title>
                <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0a1628;color:#e2e8f0;margin:0}
                .box{text-align:center;padding:40px;background:#0f1f38;border-radius:12px;border:1px solid rgba(59,130,246,0.15)}
                h2{color:#3b82f6;margin-bottom:10px}p{color:#94a3b8}</style></head>
                <body><div class="box"><h2>✓ Quota Reached</h2><p>This vendor has reached its complete quota for this project.</p></div></body></html>');
            }
        }
        if (!empty($vqrow['click_quota'])) {
            $clickCount = $db->prepare("SELECT COUNT(*) FROM survey_starts WHERE sid=? AND vendor_id=?");
            $clickCount->execute([$sid, $vid]);
            if ((int)$clickCount->fetchColumn() >= (int)$vqrow['click_quota']) {
                die('<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Click Quota Reached</title>
                <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0a1628;color:#e2e8f0;margin:0}
                .box{text-align:center;padding:40px;background:#0f1f38;border-radius:12px;border:1px solid rgba(59,130,246,0.15)}
                h2{color:#3b82f6;margin-bottom:10px}p{color:#94a3b8}</style></head>
                <body><div class="box"><h2>✓ Click Quota Reached</h2><p>This vendor has reached its click quota for this project.</p></div></body></html>');
            }
        }
    }
}

// ── ENCRYPT UID (reuse existing mapping if present) ──────────
$encrypted_uid = $uid;
if (!empty($project['encrypt_uid'])) {
    $encrypted_uid = exz_encrypt_uid($db, $uid, $sid, 'vendor');
}

// ── BUILD SURVEY URL ──────────────────────────────────────────
$survey_url = $project['live_url'] ?? '';

// Multi-Country Link (optional) — if this project has per-country URL
// overrides defined, check the respondent's IP-detected country against
// them. A match uses that country's specific URL instead of the default
// live_url above. No country-links defined, or no match found → falls
// straight back to the default live_url, exactly as before.
exz_ensure_country_links_table($db);
$cl_check = $db->prepare("SELECT COUNT(*) FROM exz_project_country_links WHERE survey_id=?");
$cl_check->execute([$sid]);
if ($cl_check->fetchColumn() > 0) {
    $geo_for_link = exz_geo($ip);
    if (!empty($geo_for_link['country']) && $geo_for_link['country'] !== 'Unknown') {
        $cl_match = $db->prepare("SELECT live_url FROM exz_project_country_links WHERE survey_id=? AND country=? LIMIT 1");
        $cl_match->execute([$sid, $geo_for_link['country']]);
        $matched_url = $cl_match->fetchColumn();
        if ($matched_url) $survey_url = $matched_url;
    }
}

if (empty($survey_url)) {
    die('<h3>Survey URL not configured for this project. Please contact support.</h3>');
}

// ── LOG SURVEY START (for LOI calc + vendor attribution later in track.php) ──
// IMPORTANT: log the identity that will actually come back from the client
// survey (the encrypted UID, since that's what we send them) — not the raw
// vendor-side uid — so track.php's LOI lookup matches correctly.
exz_ensure_survey_starts_geo_columns($db);
// Reuse the geo lookup above if the country-links check already ran it for
// this project — otherwise do it now. Device is a pure User-Agent parse
// (no API call), so it's always free to capture. Both let a "Pending" /
// "Click Only" entry (no completion signal ever arrives) still show where
// the traffic came from, instead of every field but IP staying blank.
$geo_at_entry = $geo_for_link ?? exz_geo($ip);
$device_at_entry = exz_device();
try {
    $db->prepare("INSERT INTO survey_starts (uid, sid, source, vendor_id, ip, device, country, city, start_time) VALUES (?,?,?,?,?,?,?,?,NOW())")
       ->execute([$encrypted_uid, $sid, $vendor_name_src, $vid ?: null, $ip, $device_at_entry, $geo_at_entry['country'] ?? null, $geo_at_entry['city'] ?? null]);
} catch (Exception $e) { error_log("vendor.php survey_starts insert: ".$e->getMessage()); }

// ── PRESCREENER IS OPTIONAL — only routed through if the link explicitly
// asks for it (&pre=1). This matches the two-link pattern: a plain "Entry
// Link" goes straight to the client survey, while a separate "Entry Link
// (Pre-screener)" adds the 6-question profile step first. ──
// ── PRESCREENER ROUTING — two ways to trigger it ────────────────
// (1) Existing: the link explicitly asks for it (&pre=1) — the original
//     two-link pattern (plain "Entry Link" vs "Entry Link (Pre-screener)").
// (2) New: a per-vendor database toggle (show_prescreener) — if set for
//     this specific vendor's mapping on this project, ALWAYS route through
//     prescreener, even via the plain entry-link, no separate link needed.
$route_to_prescreener = !empty($_GET['pre']);
if (!$route_to_prescreener && $vid) {
    exz_ensure_prescreener_toggle_column($db);
    $psq = $db->prepare("SELECT show_prescreener FROM exz_project_vendors WHERE survey_id=? AND vendor_id=? LIMIT 1");
    $psq->execute([$sid, $vid]);
    if ((int)$psq->fetchColumn() === 1) $route_to_prescreener = true;
}
if ($route_to_prescreener) {
    $prescreener_url = "prescreener.php?sid=".urlencode($sid)."&uid=".urlencode($encrypted_uid).($vid ? "&vid=".urlencode($vid) : '');
    header("Location: $prescreener_url");
    exit();
}

// Replace standard placeholders - now supports {{token}}, [TOKEN], {token},
// %TOKEN%, <token>, and $token$ styles (case-insensitive), not just [TOKEN].
// Existing client Live URLs using [UID]/[SID]/[VID]/[IP] keep working exactly
// as before (100% backward compatible) - this only ADDS new bracket styles.
$survey_url = exz_build_url($survey_url, [
    'uid' => $encrypted_uid, 'rid' => $encrypted_uid, 'toid' => $encrypted_uid, 'pid' => $encrypted_uid,
    'identifier' => $encrypted_uid, 'tid' => $encrypted_uid,
    'userid' => $encrypted_uid, 'user_id' => $encrypted_uid,
    'respid' => $encrypted_uid, 'resp_id' => $encrypted_uid,
    'respondentid' => $encrypted_uid, 'respondent_id' => $encrypted_uid,
    'panelistid' => $encrypted_uid, 'panelist_id' => $encrypted_uid,
    'participantid' => $encrypted_uid, 'participant_id' => $encrypted_uid,
    'memberid' => $encrypted_uid, 'member_id' => $encrypted_uid,
    'entryid' => $encrypted_uid, 'entry_id' => $encrypted_uid,
    'clickid' => $encrypted_uid, 'subid' => $encrypted_uid,
    'transactionid' => $encrypted_uid, 'transaction_id' => $encrypted_uid,
    'qparm' => $encrypted_uid, 'subject_id' => $encrypted_uid,
    'ext_ref' => $encrypted_uid, 'external_id' => $encrypted_uid,
    'id' => $encrypted_uid, 'ticket' => $encrypted_uid,
    'sid' => $sid, 'studyid' => $sid, 'surveyid' => $sid, 'survey_id' => $sid,
    'projectid' => $sid, 'project_id' => $sid, 'gid' => $sid,
    'vid' => (string)$vid,
    'ip'  => $ip,
]);
$survey_url = html_entity_decode($survey_url, ENT_QUOTES, 'UTF-8');

header("Location: $survey_url");
exit();
