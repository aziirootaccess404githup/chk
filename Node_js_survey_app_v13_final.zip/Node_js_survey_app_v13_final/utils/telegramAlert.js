// ============================================================
// Telegram Alerts — direct port of ExaVerify's exz_send_telegram().
// Checks app_settings (DB) FIRST for telegram_bot_token/telegram_chat_id
// (configurable via the in-app Settings page), falling back to
// TELEGRAM_BOT_TOKEN/TELEGRAM_CHAT_ID environment-variables if the DB
// values are empty — so this keeps working unchanged for anyone who
// only ever set the env-vars, while also letting a superadmin change
// it from within the app itself (matching ExaVerify's "Alert Settings"
// tab, which this previously had no equivalent of).
// If neither source has a value, this is a silent no-op — never
// blocks or errors the calling code.
// ============================================================

import { supabaseAdmin } from "@/utils/supabase";

async function sendTelegramAlert(message) {
    let token = process.env.TELEGRAM_BOT_TOKEN;
    let chatId = process.env.TELEGRAM_CHAT_ID;

    try {
        const { data } = await supabaseAdmin
            .from('app_settings')
            .select('setting_key, setting_value')
            .in('setting_key', ['telegram_bot_token', 'telegram_chat_id']);
        (data || []).forEach(row => {
            if (row.setting_key === 'telegram_bot_token' && row.setting_value) token = row.setting_value;
            if (row.setting_key === 'telegram_chat_id' && row.setting_value) chatId = row.setting_value;
        });
    } catch (e) {
        // DB lookup failing should never block the alert-attempt from
        // at least trying the env-var fallback below.
    }

    if (!token || !chatId) return; // not configured anywhere — silently skip

    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 4000);
        await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ chat_id: chatId, text: message }),
            signal: controller.signal,
        });
        clearTimeout(timeout);
    } catch (error) {
        console.error('Telegram alert failed:', error);
        // Never throw — an alert failing must never affect the respondent's flow.
    }
}

export { sendTelegramAlert };
