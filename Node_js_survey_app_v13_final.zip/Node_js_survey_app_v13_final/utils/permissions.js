// ============================================================
// Shared role-permission checks — ported/consolidated from the
// existing checkAdminRole/checkWriteAccess logic that already lived
// only inside app/admin/actions.js (used only for the /admin user-
// management page itself). This file makes the SAME checks reusable
// across the rest of the app, so role actually matters everywhere —
// not just for who can open /admin.
//
// Role tiers (matches ExaVerify's 3-tier system):
//   superadmin — full access, including destructive actions (delete)
//   manager    — can create/edit, cannot delete
//   viewer     — read-only, cannot create/edit/delete anything
// ============================================================
'use server';

import { createAdminClient } from '@/utils/supabase/admin';
import { createClient } from '@/utils/supabase/server';

async function getCurrentUserRole() {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Unauthorized — please log in.');

    const supabaseAdmin = createAdminClient();
    const { data: profile } = await supabaseAdmin
        .from('profiles')
        .select('role')
        .eq('id', user.id)
        .single();

    return profile?.role || 'viewer';
}

// Blocks viewer-role from any write action (create/update). Call this
// at the start of any action that creates or edits data.
export async function requireWriteAccess() {
    const role = await getCurrentUserRole();
    if (role === 'viewer') {
        throw new Error('Forbidden: your account is read-only (Viewer role). Ask a superadmin to change your role if you need write access.');
    }
    return role;
}

// Blocks anyone below superadmin. Call this at the start of any
// destructive action (delete) or superadmin-only settings.
export async function requireSuperadmin() {
    const role = await getCurrentUserRole();
    if (role !== 'superadmin') {
        throw new Error('Forbidden: this action requires Superadmin access.');
    }
    return role;
}

export { getCurrentUserRole };
