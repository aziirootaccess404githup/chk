// ============================================================
// Geo / Device / Browser detection — direct port of ExaVerify's
// exz_geo() / exz_device() / exz_browser() (inc_exz.php).
// Free services, no API key needed. Never throws — always
// resolves to a safe fallback so it can never block a respondent.
// ============================================================

/**
 * Look up country + city for an IP address.
 * Tries ip-api.com first, falls back to ipapi.co if the primary
 * fails, times out, or is rate-limited.
 */
async function getGeo(ip) {
    if (!ip || ip === '0.0.0.0' || ip === 'Unknown IP' || ip === '::1') {
        return { country: 'Unknown', city: '' };
    }

    try {
        const controller1 = new AbortController();
        const timeout1 = setTimeout(() => controller1.abort(), 1500);
        const res1 = await fetch(`http://ip-api.com/json/${ip}`, { signal: controller1.signal });
        clearTimeout(timeout1);
        const data1 = await res1.json();
        if (data1?.status === 'success' && data1.country) {
            return { country: data1.country, city: data1.city || '' };
        }
    } catch (e) {
        // fall through to fallback provider
    }

    try {
        const controller2 = new AbortController();
        const timeout2 = setTimeout(() => controller2.abort(), 1500);
        const res2 = await fetch(`https://ipapi.co/${ip}/json/`, { signal: controller2.signal });
        clearTimeout(timeout2);
        const data2 = await res2.json();
        if (!data2?.error && data2?.country_name) {
            return { country: data2.country_name, city: data2.city || '' };
        }
    } catch (e) {
        // fall through to third provider
    }

    // Third, independent fallback provider (own separate rate-limit bucket) —
    // ported from the same fix applied to Kishan's panel and ExaVerify: under
    // high-volume traffic, two providers can occasionally both be
    // rate-limited/down at once. ipinfo.io only returns a 2-letter country
    // code, so it's normalized to a full name to match the other providers.
    const COUNTRY_CODE_MAP = { US:'United States', GB:'United Kingdom', IN:'India', CA:'Canada', AU:'Australia', DE:'Germany', FR:'France', ES:'Spain', IT:'Italy', NL:'Netherlands', BR:'Brazil', MX:'Mexico', JP:'Japan', CN:'China', PH:'Philippines', AE:'United Arab Emirates', SG:'Singapore', ZA:'South Africa', NZ:'New Zealand', IE:'Ireland', PK:'Pakistan', BD:'Bangladesh', ID:'Indonesia', MY:'Malaysia', TH:'Thailand', VN:'Vietnam', KR:'South Korea', SA:'Saudi Arabia', EG:'Egypt', NG:'Nigeria', KE:'Kenya', AR:'Argentina', CL:'Chile', CO:'Colombia', PE:'Peru', PL:'Poland', SE:'Sweden', NO:'Norway', DK:'Denmark', FI:'Finland', CH:'Switzerland', AT:'Austria', BE:'Belgium', PT:'Portugal', GR:'Greece', TR:'Turkey', IL:'Israel', RU:'Russia', UA:'Ukraine' };
    try {
        const controller3 = new AbortController();
        const timeout3 = setTimeout(() => controller3.abort(), 1500);
        const res3 = await fetch(`https://ipinfo.io/${ip}/json`, { signal: controller3.signal });
        clearTimeout(timeout3);
        const data3 = await res3.json();
        if (data3?.country) {
            return { country: COUNTRY_CODE_MAP[data3.country] || data3.country, city: data3.city || '' };
        }
    } catch (e) {
        // all three providers failed
    }

    return { country: 'Unknown', city: '' };
}

/**
 * Detect device type (mobile / tablet / desktop) from a User-Agent string.
 */
function getDevice(userAgent) {
    const ua = userAgent || '';
    if (/tablet|ipad/i.test(ua)) return 'tablet';
    if (/mobile|android|iphone/i.test(ua)) return 'mobile';
    return 'desktop';
}

/**
 * Detect browser family from a User-Agent string.
 */
function getBrowser(userAgent) {
    const ua = userAgent || '';
    if (ua.includes('Edg')) return 'Edge';
    if (ua.includes('Chrome')) return 'Chrome';
    if (ua.includes('Firefox')) return 'Firefox';
    if (ua.includes('Safari')) return 'Safari';
    return 'Other';
}

export { getGeo, getDevice, getBrowser };
