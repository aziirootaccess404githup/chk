// Encryption utility for UID encryption

import crypto from 'crypto';

// Use a secret key from environment or fallback
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'mwr-exazon-secret-key-2026-prod!';
const ALGORITHM = 'aes-256-cbc';

// ── SECURITY WARNING ──────────────────────────────────────────
// The fallback key above is a fixed, publicly-known string (visible in
// this source file). It works correctly and won't break anything — but
// if ENCRYPTION_KEY is ever missing in production, respondent UIDs are
// only as protected as this one, shared, guessable string. This warning
// prints once at server-startup so it's visible in Hostinger's logs —
// setting a real ENCRYPTION_KEY env-var closes this gap with zero code
// changes needed (both old and new encrypted UIDs keep decrypting fine
// either way, since decryptUID tries multiple formats already).
if (!process.env.ENCRYPTION_KEY) {
    console.warn(
        '[SECURITY WARNING] ENCRYPTION_KEY environment variable is not set. ' +
        'Falling back to a fixed, publicly-known key. This still works, but ' +
        'respondent UID encryption is only as strong as this shared fallback. ' +
        'Set ENCRYPTION_KEY in your hosting environment variables to fix this.'
    );
}

// Derive a 32-byte key from the secret
function getKey() {
    return crypto.createHash('sha256').update(ENCRYPTION_KEY).digest();
}

// Derive a deterministic 16-byte IV from the secret
// Using a fixed IV means the same UID always produces the same encrypted string, removing the need to transmit the IV.
function getIV() {
    return crypto.createHash('md5').update(ENCRYPTION_KEY).digest();
}

export function encryptUID(uid) {
    if (!uid) return uid;
    try {
        const key = getKey();
        const iv = getIV();
        // Use CTR mode for zero-padding, making the output exactly the same length as the input
        const cipher = crypto.createCipheriv('aes-256-ctr', key, iv);
        let encrypted = cipher.update(String(uid), 'utf8', 'base64url');
        encrypted += cipher.final('base64url');
        // Prefix with '.' to identify the new CTR format
        return '.' + encrypted;
    } catch (error) {
        console.error('Encryption error:', error);
        return uid; // Fallback to plain UID
    }
}

export function decryptUID(encryptedUid) {
    if (!encryptedUid) return encryptedUid;
    
    // Legacy support 1: If the string contains a colon, it's the old 64-char Hex format with a prepended IV.
    if (encryptedUid.includes(':')) {
        try {
            const key = getKey();
            const parts = encryptedUid.split(':');
            if (parts.length !== 2) return encryptedUid;
            const iv = Buffer.from(parts[0], 'hex');
            const encrypted = parts[1];
            const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
            let decrypted = decipher.update(encrypted, 'hex', 'utf8');
            decrypted += decipher.final('utf8');
            return decrypted;
        } catch (error) {
            console.error('Legacy Decryption error:', error);
            return encryptedUid;
        }
    }

    // New format (Shortest): CTR mode indicated by '.' prefix
    if (encryptedUid.startsWith('.')) {
        try {
            const key = getKey();
            const iv = getIV();
            const decipher = crypto.createDecipheriv('aes-256-ctr', key, iv);
            let decrypted = decipher.update(encryptedUid.substring(1), 'base64url', 'utf8');
            decrypted += decipher.final('utf8');
            return decrypted;
        } catch (error) {
            console.error('CTR Decryption error:', error);
            return encryptedUid;
        }
    }

    // Legacy support 2: CBC Base64URL without prefix (22+ chars)
    try {
        const key = getKey();
        const iv = getIV();
        const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
        let decrypted = decipher.update(encryptedUid, 'base64url', 'utf8');
        decrypted += decipher.final('utf8');
        return decrypted;
    } catch (error) {
        console.error('Decryption error:', error);
        return encryptedUid; // Fallback
    }
}
