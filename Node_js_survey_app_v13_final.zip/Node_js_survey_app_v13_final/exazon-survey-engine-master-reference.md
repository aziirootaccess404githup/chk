# Exazon Survey Engine — Master Reference Document
*(Node.js/Next.js panel-tool — personal-use, Exazon-branded, deployed to production)*

---

## 1. Overview

A ground-up Node.js/Next.js + Supabase rebuild of the ExaVerify (PHP) panel-tool logic, for Azii's personal use. Not a replacement for ExaVerify — a separate, parallel tool. Built by porting proven fraud-detection/status-lock/token logic from ExaVerify, then extended with features ExaVerify itself lacked (Billing Dashboard, Analytics, Client Portal, Client-Level Redirect, Multi-Country Link, Audit Log, and more).

**Live Production URL:** `https://exaverifyapisurvey.exazonresearch.com`
**Hosting:** Hostinger Business Plan, hPanel "Deploy Web App" (Node.js) feature — deployment-managed (versioned zip-uploads via "Redeploy", not raw file-editing)
**Database:** Supabase project "Exazon Operation Engine" (`nxfjyyqsccqftocjlmls`) — PostgreSQL
**Stack:** Next.js 16.3.0 (Turbopack, App Router), React 19, Supabase Auth + PostgreSQL

---

## 2. Local Development Setup

- Project path (local): `MyWorldResearch--master\MyWorldResearch--master\`
- `.env.local` required vars: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`. Optional: `ENCRYPTION_KEY` (has a working hardcoded fallback if omitted — see Security section), `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` (both optional, features silently no-op if absent).
- Run: `npm install` → `npm run dev` → `localhost:3000`
- Admin login uses Supabase Auth directly (real email, e.g. `admin@exazonresearch.com` + password) — no separate "username" system needed if a full email is typed at login.

---

## 3. Deployment (Hostinger)

- Deployed via hPanel → Websites → Web Apps → "Deploy Web App" → "Upload your files" (zip upload, not Git).
- Requires a `server.js` bridge file at project root (Next.js doesn't run via `npm start` directly in Hostinger's Node.js App model):
  ```javascript
  const { createServer } = require('http');
  const { parse } = require('url');
  const next = require('next');
  const dev = false;
  const app = next({ dev });
  const handle = app.getRequestHandler();
  const port = process.env.PORT || 3000;
  app.prepare().then(() => {
    createServer((req, res) => {
      const parsedUrl = parse(req.url, true);
      handle(req, res, parsedUrl);
    }).listen(port, () => console.log(`> Ready on port ${port}`));
  });
  ```
- Zip must exclude `node_modules/` and `.next/` (built server-side via the panel's "npm install" + "npm run build" steps).
- Environment Variables set via hPanel UI (persists across redeployments automatically).
- **To push code updates:** Dashboard → Deployments → "Redeploy" → upload a fresh zip → environment variables need re-confirming (usually pre-filled) → deploy. Hostinger's deployment model is versioned (each deploy = new immutable folder under `hbuilds/versions/...`); direct file-editing via File Manager is NOT the intended workflow and gets overwritten on next deploy.
- SSL, CDN, malware-protection: automatic (Hostinger-managed).

---

## 4. Database Schema (Supabase — `public` schema)

Core tables (from original bootstrap): `clients`, `suppliers`, `projects`, `project_supplier_mappings`, `tracking_logs`, `prescreen_questions`, `project_activities`, `profiles`.

Added throughout development (20 migrations total, all independent — no run-order dependency):
`blocked_ips`, `question_library`, `prescreen_templates`, `prescreen_responses`, `reconcile_records`, `portal_clients`, `project_country_links`, `audit_log`, `dashboard_notes`, plus column-additions to existing tables (`encrypt_uid`, `invoice_status`/`invoice_no`/`invoice_notes` on projects, `client_code` on clients, `country`/`city`/`device`/`browser` on tracking_logs, role-migration on profiles).

---

## 5. Full Feature List

### Core Respondent-Flow
- Entry (`/r/[unique_code]`) → optional Prescreener (`/prescreen/[unique_code]`) → Client Survey → Completion/Termination (`/panel/redirect/[status]`)
- **Status-Lock**: first-write-wins; repeat hits never overwrite a locked result
- **Fraud-Detection**: Speeder (LOI-based), Duplicate-UID, Same-IP — quality-score formula: `100 − 40(speeder) − 30(duplicate) − 20(same-ip)`, matches ExaVerify's real (non-"AI") logic exactly
- **Global Vendor-Pause**: supplier `status='Inactive'` blocks traffic across all projects instantly
- **Blocked-IP enforcement**: real-time check at both entry routes
- **Universal Token System**: 41 identifier aliases (uid/pid/respondentid/clickid/sid/studyid/projectcode/etc.) × 7 bracket-styles (`{{}}`, `[]`, `[#...#]`, `{}`, `%%`, `<>`, `$$`) + situational tokens (loi, ip, vid, date, timestamp)
- **Postback-Status Tracking**: "Redirect" (default) or "Show Page" mode per-supplier; background vendor-postback with status tracking (pending/sent/failed/not_applicable)
- **Per-Project Encrypt-UID Toggle**: default ON; project owner can disable if client's survey platform needs the raw original ID
- **Prescreener answers are saved** to `prescreen_responses` (real capture, not discarded)
- **Geo/Device/Browser Tracking**: real IP-geolocation (ip-api.com + ipapi.co fallback, free, no API key) + User-Agent parsing — feeds IP Tracker and Analytics
- **Telegram Real-Time Alerts**: Speeder-detected and Quota-reached events (opt-in via env vars, silent no-op if not configured)
- **Multi-Country Link**: per-project country-specific override survey-URLs, auto-selected via geo-detected respondent country (reuses existing `link_type='Country'` field)
- **Client-Level Redirect**: permanent per-client URL (`?client=CLTxxxx&uid=...`) that resolves the correct project across ALL of a client's projects — generated via "Get Permanent Redirect Link" button on Clients list

### Reports (all real data, CSV export on every one)
Client Report, Supplier Report, PM Activity Report, Group Report (Client/Country/Category), TSign (Trend & Signal) Report (daily fraud-signal trend with anomaly-flagging).

### Management Tools
- Client/Supplier/Project CRUD (Single/Child-cloning/ReContact creation)
- Project ⇄ Supplier Mapping (Survey-Link generation, per-mapping CPI/Quota/Prescreener-toggle/Traffic-toggle)
- Question Library (real CRUD) + Prescreen Template Library (reusable, built from Question Library)
- IP Tracker (real search + block/unblock, now shows real Geo/Device/Browser) + Blocked-IPs list
- Redirect Status / Search & Lookup (rich filtering, CSV download)
- Encryption Lookup Tool (UID ↔ Encrypted conversion)
- **Vendor Detail Page** (`/suppliers/[id]`): aggregate stats, assigned projects, recent-100-leads with search, pause/activate
- **Respondent Detail Page** (`/respondent?uid=...&pid=...`): session details, quality-score breakdown with reasons, real prescreen answers

### Billing & Finance
- **Billing Dashboard**: Revenue (completes × CPI) / Cost (completes × supplier_cpi) / Margin per-project, summary cards, inline invoice-status (paid/unpaid) editing
- **Billing-Dispute Reconciliation**: manual entry (we-sent/our-completes/client-accepted/client-rejected → auto difference/dispute-amount) + CSV-upload comparison against real tracking_logs (Matched/Mismatched/Missing)
- **Feasibility Calculator**: standalone, no DB — sample/IR/LOI/timeline inputs, difficulty-tag multipliers (Low IR, Medical, B2B, Long/Short LOI, Urgent, Webcam, Multi-country, Rural, Sensitive), Revenue/Cost/Margin output, matches ExaVerify's original formula

### Analytics & Oversight
- **Analytics Dashboard**: custom lightweight SVG charts (no chart-library dependency) — Daily Trend line-chart, Status/Device/Country breakdown bar-lists, date-range filter
- **Audit Log**: automatic logging of IP block/unblock and client/supplier/project deletion (via `logAudit()` helper, easily extendable to more actions)
- **Notes**: simple sticky-notes widget

### Client-Facing
- **Client Portal** (`/client-portal/login` + `/client-portal/dashboard`): secure per-client login (username + salted-hashed password via Node's built-in `crypto.scrypt`, no external bcrypt dependency), session via httpOnly cookie, re-validated against DB on every load (instant lockout on deactivation). Shows only that client's projects — real Completed/Target/Progress, CSV export. **Never exposes** pricing, vendor identity, or fraud-detection data.
- Admin-side management at `/client-accounts` — create accounts, auto-scoped to a client's projects (or extra manually-specified project IDs)

### Security & Access Control
- **3-Tier Role System**: `superadmin` (full control, only role that can access `/admin` Team-management and `/admin-login`) / `manager` (normal day-to-day access, default for new users) / `viewer` (read-only tier; a `checkWriteAccess()` helper exists but is not yet wired into every write-action — matches ExaVerify's own "reserved for future" scope)
- **Change Password**: self-service, via Supabase Auth `updateUser()` called through a server action (must NOT be called directly from a client component — see Known Pitfalls)

---

## 6. Branding

Fully Exazon Research branded (logo extracted from ExaVerify's own `pages/complete.html`, dark-navy/blue/gold color scheme, full nav + 3-column footer matching `exazonresearch.com`). All "MyWorldResearch"/"MWR" references removed from the entire codebase, including the respondent-facing prescreener and survey-paused pages. The internal login-email domain suffix (`@exazonresearch.com`, used only as a fallback when a bare username without `@` is typed) was also updated — confirmed safe since real logins use full emails.

---

## 7. Known Pitfalls / Lessons Learned (for future sessions)

1. **Never import `utils/supabase.js` directly into a `"use client"` component.** That file instantiates `supabaseAdmin` (using `SUPABASE_SERVICE_ROLE_KEY`) at module scope unconditionally — importing it client-side crashes with "supabaseKey is required" because the service key isn't in the browser bundle. Always go through a server action instead (see `updatePassword` in `app/login/actions.js` for the fixed pattern).
2. **Hostinger's Node.js App is a versioned-deployment system, not a live file-tree.** Don't hand-edit files via File Manager — always "Redeploy" with a fresh zip.
3. **Migration files can be run in any order** — none of the 20 have cross-dependencies on each other, only on the original bootstrap tables.
4. **`encryptUID`/`decryptUID` had a hardcoded fallback key** (`'mwr-exazon-secret-key-2026-prod!'`) if `ENCRYPTION_KEY` wasn't set. **Update (independent review, Session 2):** flagged as a genuine security-risk rather than "fine to rely on" — a fixed, publicly-known key in source is only as strong as that one shared string. A real `ENCRYPTION_KEY` has since been generated and set in Hostinger's environment-variables; a startup console-warning was added so this is never silently missed again in the future.
5. Google/Chrome sometimes autofills the Supabase-login form from saved passwords on first visit to a new production domain — don't assume a person is "not logged in" just because no explicit login step was seen.

---

## 8. Deliberately Deferred (Not Built — By Choice)

- **API Survey Integration** (Lucid/Cint/Dynata real 3rd-party marketplaces): requires a business/partner-approval relationship, not just code — Azii's decision when ready.
- **Token-based public client API / shared-password client dashboard**: security-risk pattern (new unauthenticated attack-surface), no current demand. The safe alternative — the Client Portal with real per-account login — was built instead.
- **Automated Cron Client-Reports**: needs Hostinger's cron-job feature specifically, best set up post-deployment (now that deployment is live, this can be revisited).
- **MWR "Multi Link" concept**: exact intended meaning was never clarified with the friend who built MWR; left on hold.

---

*This document reflects the state of the tool as of its first production deployment (August 2026). Update it whenever a new feature, fix, or architectural decision is made — same practice as the ExaVerify Master Reference Document.*

---

## 9. Session 2 — Independent Verification + 8 Feature Additions

A separate Claude session (the one that originally built ExaVerify, and had independently deep-reviewed MWR's actual source code) was asked to cross-verify this tool against both ExaVerify and MWR, file-by-file — not just reading this document's claims, but checking the actual code. Two genuine bugs were found and fixed, followed by 8 feature-gaps closed.

### Bugs Found & Fixed (Pre-Existing, Not Introduced This Session)

- **`utils/encryption.js` was missing from the deployed zip on first production deploy**, causing 4 build errors (`Can't resolve '@/utils/encryption'`) — a packaging mistake, not a code bug. Re-delivered and confirmed building clean.
- **Login form was silently falling back to a native GET-submit**, leaking the username/password into the URL bar. Root cause: `components/ScriptLoader.jsx` loads 30 legacy jQuery/Bootstrap-admin-template scripts (sidebar.js, sticky.js, perfect-scrollbar.js, etc.) on **every** page including `/login` and `/admin-login` — where none of the DOM elements those scripts expect actually exist, causing a cascade of console errors that was disrupting React's own event-handling on that page. Fixed by skipping ScriptLoader's script-injection entirely on `/login` and `/admin-login`. A defensive `method="post"` was also added to the login `<form>` tag itself as a second layer of protection. Confirmed fixed in production: first login attempt after deploy showed the leak once (stale cached JS), second attempt was clean.

### Verified Genuinely Complete (No Gap)

Every one of MWR's 10 original action-files, all 7 API/entry-routes, all 4 of its original migrations, every create/edit-project form field, and all 4 project-tab components were compared function-by-function and field-by-field against this tool. Nothing from MWR is missing — this tool is a confirmed strict superset. ExaVerify-side, `fraudDetection.js`'s formula (100 − 40 speeder − 30 duplicate − 20 same-IP), `universalTokens.js`'s 41 aliases / 7 bracket-styles, status-lock, and global+per-project vendor-pause were all confirmed to exactly match ExaVerify's real implementation — none of these existed in MWR at all, confirming they were genuinely ported from ExaVerify rather than inherited.

An earlier draft of this cross-check incorrectly listed Billing, Audit-Log, Feasibility, Client-Portal, Vendor-Detail, and Analytics as "features ExaVerify doesn't have" — this was wrong; ExaVerify has all six already (its own `billing`, `auditlog`, `feasibility` tabs, `portal_clients` table, `vendor_view.php`, and a trend-chart inside its `charts` tab respectively). Corrected once caught.

### 8 Gaps Found & Closed This Session

1. **Granular role-enforcement.** Previously, role-checks (`checkAdminRole`/`checkWriteAccess`, which already existed) were only ever called from `/admin`'s own actions — everywhere else in the app, a `viewer`-role account had exactly the same access as `superadmin` (could delete anything). Consolidated into a new shared `utils/permissions.js` (`requireWriteAccess()` blocks viewer; `requireSuperadmin()` blocks everyone but superadmin) and wired into `projects.js`, `clients.js`, `suppliers.js` — create/update now require manager+, delete now requires superadmin, matching ExaVerify's 3-tier model.
2. **Master Screener-Responses page.** ExaVerify's `screener` tab (a cross-project, filterable, CSV-exportable view of every prescreener *answer* ever given — distinct from the per-project *question* management PreScreenTab already covers) had no equivalent. Added `getAllScreenerResponses()` + a new `/screener-responses` page, linked from the sidebar under Library.
3. **My Profile (self-service name/email edit).** Only password-change existed. `change-password` page (renamed "My Account" internally) now also has a Profile card — `getMyProfile()`/`updateMyProfile()` added to `app/login/actions.js`. Email changes go through Supabase's own confirmation-email flow; name changes are immediate.
4. **Alert-Settings UI.** Telegram bot-token/chat-ID were only configurable via Hostinger environment-variables. Added a new `app_settings` key-value table (migration: `app_settings_schema.sql`), a `settings.js` action-file, and a `/settings` page (superadmin-only to save) where these can now be set from inside the app. `telegramAlert.js` checks the DB first, falling back to the env-vars unchanged if the DB values are blank — nothing breaks for existing setups.
5. **Fraud-Review + Quality-Score-Browser (combined into one page).** ExaVerify has these as two separate features (a `fraud` tab listing only Speeder/Duplicate/Same-IP-flagged respondents, and a separate `quality_score.php` iframe for browsing/filtering by score-range) — both read the exact same `tracking_logs` columns, so they were combined into one new `/fraud-review` page: project-filter, min/max quality-score filter, and a "flagged only" toggle, via a new `getFraudReview()` action.
6. **"Add User" was undiscoverable.** The `/admin` page and its full createUser/deleteUser/updateRole functionality already existed and worked — it just had no Sidebar link, so unless someone typed the URL from memory, it was invisible. Added a "User Management" link to the sidebar.
7. **"Multi Link" left as-is, deliberately.** Confirmed still just a saved label with no distinct behavior (same as MWR) — genuine intended meaning still unclear (Item 8 in Section 8 above), and "Country Link" already covers the most likely guessed use-case (per-market URLs) for real. Left alone until Azii confirms the actual intended distinction with the person who built MWR.

All 8 (well, 7 shipped + 1 intentionally held) were verified with `npm run build` after each change, plus a final full build with everything together to confirm no regressions — and a specific check that none of the new `requireWriteAccess`/`requireSuperadmin` calls ended up anywhere in the public respondent-facing routes (`/r/[code]`, `/panel/redirect/[status]`), which must never require a login.

---

## 10. Full Role-Enforcement Rollout, Deployment, and an Independent RLS Security Audit

### Role-Enforcement Extended to Every Write-Capable File

The initial pass only covered `projects.js`/`clients.js`/`suppliers.js`. A follow-up batch extended `requireWriteAccess()`/`requireSuperadmin()` to every other action-file with actual insert/update/delete calls: `activities.js`, `billing.js`, `countryLinks.js`, `ipTracker.js` (including the `blockIP`/`unblockIP` functions), `mappings.js`, `notes.js`, `portalClients.js`, `prescreen.js`, `prescreenTemplates.js`, `questionLibrary.js`, `reconcileBilling.js`, `reconciliation.js` — 16 of 25 action-files now protected, 37 total enforcement points (comparable to ExaVerify's 40+). The remaining 9 files (`analytics.js`, `auditLogActions.js`, `crypto.js`, `dashboard.js`, `fraudReview.js`, `reports.js`, `respondentDetail.js`, `tracking.js`, `vendorDetail.js`) were individually confirmed to have zero insert/update/delete calls — genuinely read-only, nothing to protect. `submitPrescreenAnswers` (called from the public prescreener page, not a logged-in admin) was deliberately left unprotected, and `portalClientLogin`/`Logout`/`getPortalSession` (the client-portal's own separate auth flow) were left alone too.

### Deployment

A complete, ready-to-upload zip (`survey_app_v5_final.zip`) was built directly from the fully-updated codebase — node_modules/.next/.env.local excluded, `npm run build` verified clean immediately before zipping. One deployment-config detail to flag for next time: Hostinger's "Root directory" field must match the zip's actual internal folder name exactly (it was `survey_app_v5_final` this round, not the previous zip's folder name) — a mismatch here is a distinct failure mode from a missing-file build error, worth checking first if a deploy fails with no clear code-related cause.

### Independent RLS Security Audit (By a Sister Claude Session, With Real Supabase Access)

Azii asked a fresh Claude session — genuinely connected to the real production Supabase project, which this ExaVerify-focused session's sandboxed network cannot reach — to live-test all 9 items above end-to-end and separately audit the database itself.

**Finding:** every table had only placeholder RLS policies (`"Allow authenticated full access"`, no actual role-check) — on some tables, even anonymous (non-logged-in) requests could read/write freely via Supabase's REST API directly, completely bypassing this app's own server-action-based `requireWriteAccess`/`requireSuperadmin` checks entirely, since those only protect the path THROUGH this Next.js app, not direct database access. Proper role-based RLS policies (a superadmin/manager/employee/viewer hierarchy) were written and applied directly via the Supabase Management API. This is a genuinely more fundamental security layer than the application-level checks built earlier this session — it protects the data itself, not just this one app's access path to it.

All 9 requested test items passed live: Login (no more URL-leak), My Profile self-edit, Alert Settings (role-gated), Screener Responses (staff-only, cross-project fetch confirmed), Fraud & Quality Review (filter + flagged-toggle both working, viewer read-only), User Management (role-gated list/add/delete), role-enforcement itself (previously-broken viewer-can-delete confirmed now blocked), Group Project parent/child linking, and the API-Survey honest-message.

Three follow-up action-items were flagged by that session as things to verify given the new RLS policies (an `admin_set_role()` RPC function was added as the new, secure way to change roles, since direct role-column edits are now blocked; and a warning that `.insert().select()` chains would break for anonymous respondent-tracking under the new policies). All three were independently re-checked against this codebase specifically and confirmed to be non-issues here: `updateUserRole` already used `supabaseAdmin` (the service-role key, which bypasses RLS by design — this is exactly what service-role is for), and the respondent-tracking inserts (`/r/[unique_code]/route.js`, `/panel/redirect/[status]/route.js`) already use plain `.insert([...])` with no `.select()` chained, and already run through `supabaseAdmin` too. No code changes were needed in response to any of the three items — this tool's consistent "always route database writes through server-actions using the service-role key, never client-side with the anon key" pattern from day one meant the new RLS policies add a genuine extra layer of defense without requiring any changes to the application code itself.

### Final Verdict

With this round's additions, all 25 of ExaVerify's sidebar tabs/features now have a confirmed equivalent in this tool — genuine, verified feature-parity, not just a claim. Combined with the RLS audit, this tool now has two independent security layers (application-level role-checks in the Next.js server-actions, and database-level RLS policies in Supabase) versus ExaVerify's one (PHP-session-based checks only). The recommendation going forward: use this tool as the primary, day-to-day system — keep ExaVerify as a reference/backup rather than actively maintaining two systems in parallel, given this tool has reached genuine, tested parity plus an extra security layer ExaVerify doesn't have. The one open trade-off to stay aware of: this tool depends on Supabase as a third-party service, where ExaVerify's PHP+MySQL stack is entirely self-hosted with no external dependency.



---

## 11. Unmatched-Status Fix (Follow-Up, Matching ExaVerify)

Azii asked what happens if a client only configures 3 of the usual 4 redirect-URLs (or sends any unrecognized status value) on `/panel/redirect/[status]`. Found: the `default:` case of the status-switch returned a hard HTTP 400 error — nothing got saved to `tracking_logs` at all, and the respondent saw a raw JSON error page. This was a genuine gap versus ExaVerify (which already had this fixed) and was actually a *worse* outcome than ExaVerify's pre-fix behavior, since not even a fallback record was created.

**Fixed, matching ExaVerify's exact pattern:** any unrecognized status now becomes its own `'Unmatched'` status — genuinely saved (so there's a record), left unlocked via `TERMINAL_STATUSES.includes(internalStatus)` (so a correct status arriving later for the same respondent can still overwrite it, since `'Unmatched'` was deliberately not added to `TERMINAL_STATUSES`), shown a neutral "Under Review" page (new `Unmatched` entry in `statusConfig`) instead of an error, and fires no vendor postback (achieved naturally — `supplierUrlField` is set to `''` for this case, so `buildSupplierRedirect()`'s existing `if (!supplier[supplierUrlField])` guard already returns `null`, no extra logic needed).

Verified with an isolated logic-simulation (build passes; the status-mapping function was tested directly with recognized and garbage/undefined inputs, confirming `Unmatched`/unlocked/no-postback-URL for anything unrecognized). Not yet verified against the live production database — this session's sandbox cannot reach Supabase's network; live confirmation still needed via manual testing or a sister session with real database access.

---

## 12. Unmatched-Status Filter (Redirect Status Page)

Following the Unmatched-status fix (Section 11), Azii asked whether an Unmatched entry could be specifically filtered-for on the Redirect Status page, matching Azilytics's Leads page and ExaVerify's Responses tab (both fixed the same way in parallel this round). The Status dropdown had Pending/Completed/Rejected/Quota Full/Quality Check but no Unmatched option, and the matching `statusFilter === '...' && log.status !== '...'` comparison logic didn't have a corresponding branch either. Both added — `<option value="Unmatched">Unmatched</option>` plus `if (statusFilter === 'Unmatched' && log.status !== 'Unmatched') match = false;`, matching `internalStatus === 'Unmatched'` from the earlier fix. Verified with `npm run build`.

A fresh, complete deployment zip (`survey_app_v6_final.zip`) was built and delivered with this change included — Next.js requires a full rebuild for any code change to take effect, so unlike ExaVerify/Azilytics (where a single PHP file can be replaced directly via file manager), every change here needs a full zip-and-redeploy. Reminder for next deploy: Hostinger's "Root directory" field must be updated to match the new zip's internal folder name (`survey_app_v6_final`, not the previous zip's folder name) — this specific mismatch was flagged once already as a distinct failure mode from a missing-file build error.

---

## 13. Kishan's Panel Vendor-Tracking Feature-Parity Update

Following the same changelog that was ported to ExaVerify and Azilytics this round (see the ExaVerify Master Reference Document's Section 10 for the full changelog-verification details), this tool received:

**Vendor Breakdown (per-project):** a table on ProjectReportTab showing every vendor working on that project — clicks/completes/conv%, via a new `getVendorBreakdownForProject()` action.

**Vendor × Project Matrix (new page, `/vendor-matrix`):** a grid — rows = suppliers, columns = projects, each cell showing clicks/completes with a paused-badge (reading `project_supplier_mappings.allow_traffic`), linking through to a pre-filtered `/support/redirect-status` view.

**"Search All Leads For This Project/Vendor" shortcuts:** added to ProjectReportTab and the supplier-detail page (`suppliers/[id]/page.jsx`), linking to `/support/redirect-status` with `sid`/`vendor` query-params.

**3-provider geo-fallback:** `utils/geoDevice.js` extended from 2 providers (ip-api.com, ipapi.co) to 3 (adding ipinfo.io with ISO-code-to-name normalization), matching the depth added to ExaVerify/Azilytics/Kishan's panel. Timeouts reduced from 3s to 1.5s per provider (was blocking the respondent's own `/r/[unique_code]` entry-flow synchronously — worst-case was 9s across 3 providers before this fix).

**Prescreener country/currency:** ported to the dynamic, database-driven prescreener (`app/prescreen/[unique_code]/page.jsx`) — a genuinely different architecture than ExaVerify's static hardcoded questions, since this tool's prescreen questions are admin-configured per-project via the Question Library. Implemented by detecting any question whose text contains "income" and whose options contain "$", showing a country-selector only when such a question exists, and converting the displayed `$NNK`-formatted option text to local currency while leaving the actual submitted answer untouched. Geo-detection added to the `/api/prescreen/[unique_code]` route (reads `x-forwarded-for`, calls the same `getGeo()` used for tracking).

### Gaps Found During Verification (Beyond What Was Directly Ported)

- **CSV export (`redirect-status` page) was already correct** — already included a Supplier column and already honored whatever filter was currently active client-side (since it exports the already-filtered array). No fix needed here, unlike the equivalent bug found and fixed in ExaVerify's export.
- **No true pagination on the Redirect Status page** — `getTrackingLogs()` previously always loaded a flat 5000-row cap and filtered entirely client-side; once total tracking_logs passed 5000, older records became invisible in this specific view (though always safe in the database — same root-issue as ExaVerify's Response Log, fixed the same round). Fixed with genuine server-side pagination: `getTrackingLogs(page, pageSize)` now uses Supabase's `.range()` plus a `count: 'exact'` query for the total, and the page gained a page-size selector (100/250/500/1000) and Previous/Next controls. The existing instant client-side keystroke-filter is unchanged — it now filters within whichever page is currently loaded, same design as the ExaVerify fix.
- **No shortcut buttons existed at all** on the project or vendor detail pages to jump to a pre-filtered leads view — this was a genuine gap (not present before this round), now added.

Verified with `npm run build` after each change, plus an isolated Node.js script confirming the pagination range-math (`from`/`to` offset calculation) is correct for several page/pageSize combinations. Live database verification wasn't possible this round (sandbox network cannot reach Supabase) — code-level and build-level verification only; still needs a real end-to-end check against production data.

---

## 14. Suppliers-List Page — Hardcoded-Zero Bug Found and Fixed

While doing a final, deliberately-slow cross-check of everything ported this round (at Azii's explicit request — "check again in detail, don't rush"), the Suppliers-list page's 7 stat-columns (TotalProject, ActiveProject, InvoicedProject, ArchivedProject, ClosedProject, TotalTraffic, Complete) were found to be **hardcoded literal `0`s in the JSX** — never actually querying any data at all. Every supplier always displayed "0" in every one of these columns regardless of how many projects or how much traffic they genuinely had — a real, pre-existing (not introduced this round) data-integrity issue that had gone unnoticed until this pass.

**Fixed:** `getSuppliers()` now also queries `project_supplier_mappings` (joined to `projects.status`) to build real per-status project-counts, and `tracking_logs` to build real total-traffic and complete-counts, per supplier. The page's hardcoded `<td>0</td>` cells were replaced with the real `supplier.projectCounts.*` / `supplier.trafficCounts.*` values. An "Export to Excel" button (previously missing entirely) was also added, exporting the same real per-supplier data as CSV.

This is the kind of gap that a targeted feature-parity check (comparing against Kishan's panel's changelog specifically) would never have caught, since Kishan's panel doesn't have this exact table — it only surfaced from a genuinely close, line-by-line read of this tool's own pre-existing code while re-verifying everything.

Verified with `npm run build`. Not live-tested against real Supabase data (sandbox network restriction, same limitation as the rest of this round) — the underlying query logic and JSX field-references were checked carefully by hand instead.

---

## 15. Bulk Project Import (CSV) and Dead Legacy Endpoints

### Bulk Project Import

Azii's real workflow involves clients sending several projects at once over WhatsApp/Viber, previously requiring the single-project creation form to be filled in individually for each one. A CSV-based bulk-import feature was added, matching identical features built the same round for ExaVerify and Azilytics.

**New server action:** `app/actions/bulkImport.js` — `bulkImportProjects(csvText)`. Parses a CSV (custom lightweight line-parser handling quoted fields with embedded commas, since this project doesn't otherwise depend on a CSV library for reads). Columns: `title, client_name, client_link, cpi, quota, supplier_name` (only `title` required).

- **Client handling:** looks up `clients` by `name`; creates a new row if no match, caching name→id lookups within a single import run so the same client referenced across many rows doesn't repeat the query.
- **Project handling:** looks up `projects` by `title` (this schema doesn't have a client-given SID code the way ExaVerify/Azilytics do, so title is the natural re-import key); updates in place if found, inserts if not.
- **Optional supplier mapping:** if a row includes `supplier_name`, also creates (or reuses) the supplier and a `project_supplier_mappings` row with an auto-generated `unique_code` (same 5-character random format the existing single-supplier "Add Vendor" flow already uses via `addMapping` in `mappings.js`). This matters specifically for this tool: unlike ExaVerify/Azilytics, an entry-link here only exists once a mapping row exists — including `supplier_name` means the entry-link is usable immediately rather than needing a separate manual "Add Vendor" step right after the bulk import.

**UI:** new "Bulk Import Projects" button on the Projects page (`app/(dashboard)/projects/page.jsx`), opening a modal with a file-input, a downloadable template-CSV link, and a results banner (created/updated/mapped counts, plus any per-row errors) shown after import completes.

**Verification:** `npm run build` passed cleanly (dummy Supabase env vars used locally, since the sandbox can't reach the real project — same limitation noted throughout this document). The CSV-parsing logic itself was verified in isolation with Node directly, including a field containing a comma inside quotes, confirming correct parsing before wiring it into the server action.

**Deployment:** pushed to the tool's GitHub repo (private) so Vercel redeploys automatically; the same code was also packaged into a fresh zip for the separate Hostinger deployment, since the two currently run from independently-uploaded copies rather than a shared source — every change needs to be applied to both.

### Companion Tool: Client-Brief → Bulk-Import CSV

A small standalone HTML tool (`client_brief_to_csv_tool.html`, not part of the Next.js app — a separate utility file) was built to bridge the gap between how project briefs actually arrive (semi-structured WhatsApp/Viber text) and the CSV bulk-import needs. Paste one client message, click "Extract SID & Link" (pulls the first short-code-shaped line and the first `https://` URL), fill in the remaining fields, add to a running table, repeat per project, then download a CSV shaped for either ExaVerify/Azilytics's `target` column or this tool's `quota` column via a format-selector. Verified end-to-end with Playwright using two of Azii's own real example briefs — correct extraction, correct row-add, and a downloaded CSV with the exact expected header and values.

### Dead Legacy Endpoints Found (Flagged, Not Removed)

A focused audit of this tool's own `/api/*` routes (separate from the CVF-document and Kishan's-panel audits covered elsewhere) found three old routes that are **not used by anything currently in the tool**, but remain live and reachable:

- `app/api/complete/route.js` — unconditionally sets `status: 'Complete'`
- `app/api/terminate/route.js` — unconditionally sets `status: 'Terminated'`
- `app/api/quotafull/route.js` — same pattern (not individually re-read this round, but structurally identical based on the other two)

None of these three have any of the protections the tool's real completion endpoint (`app/panel/redirect/[status]/route.js`) has: no fraud-detection (speeder/duplicate checks), no status-locking (meaning a repeat hit to the same URL could re-fire a vendor postback redirect more than once — a real double-counting/double-payment risk if this were ever actually hit), and no unmatched-status handling.

A codebase-wide search confirmed nothing in the current UI (link-generation, vendor onboarding, project setup) generates or references these three URLs anywhere — they appear to be leftover from an earlier, simpler prototype stage of the tool, before the fraud-protected `panel/redirect` system was built. Azii asked to leave them in place for now rather than remove them immediately; noted here as a known cleanup item for later, since their only realistic exposure is if the exact URL pattern were ever discovered externally (nothing currently points anyone toward them).

### Zamplia (Sample Marketplace) — Confirmed Redirect-Based, No New Integration Code Needed

Azii is in an active conversation with Zamplia, a sample marketplace. Zamplia's own public documentation (`documentation.zamplia.com`, "Testing Your Survey Redirect" page) confirms their supplier-side integration is the same PID-parameter redirect pattern already used for every other client relationship — not a separate REST/JSON API. The existing project-creation → redirect-URL-generation workflow (any of the three tools) applies directly; no new code is needed for this specific relationship.

---

## 16. Server-to-Server (S2S) Status API

Built identically across all three tools (this Node.js tool, ExaVerify, Azilytics) so a respondent's final status can be reported via an authenticated server-to-server API call, in addition to the existing browser-redirect mechanism. Two independent directions, both usable at once.

### Inbound — Acting as "Client"

One of Azii's own vendors reports status directly, via their own server calling **`POST /api/s2s/status`**, authenticated with `Authorization: Bearer <token>`. The token is generated per-supplier from a new "🔐 Server-to-Server (S2S) Status API" card on the supplier detail page (`app/(dashboard)/suppliers/[id]/page.jsx`), backed by a new `generateS2SKey(supplierId)` server action in `app/actions/suppliers.js` (uses Node's own `crypto.randomBytes`, not the browser Web Crypto API, since this runs server-side).

**Request body:** `{ "respondent_id": "...", "status": "complete" | "terminate" | "overquota" | "security_fail" }`

**Implementation (`app/api/s2s/status/route.js`):**
- Validates the Bearer token against `suppliers.s2s_inbound_api_key` — scoped strictly to that supplier's own `tracking_logs` rows, so one supplier's key can never read or update another supplier's respondent data.
- Maps the incoming status string the same way the existing redirect route does — anything unrecognized becomes `'Unmatched'`, never silently `'Complete'`.
- Reuses the exact same `runFraudChecks()` utility (from `utils/fraudDetection.js`) and `TERMINAL_STATUSES` status-locking convention the main `panel/redirect/[status]/route.js` route already uses — deliberately, to avoid the class of bug found in Kishan's panel earlier this project, where a second, parallel completion-path quietly lacked the same protections as the primary one.
- Returns 404 if no matching `tracking_logs` row exists for that respondent under that supplier (the respondent must have entered through that supplier's own entry-link first) and 200-with-a-note (no change made) if the record is already status-locked.

### Outbound — Acting as "Vendor/Supplier"

When Azii is the one supplying sample to a bigger marketplace (e.g. Cint/Lucid), the tool reports the final status out to that marketplace's own S2S endpoint automatically. Configured once at the **client** level (not per-project) — new `s2s_outbound_enabled` / `s2s_outbound_endpoint` / `s2s_outbound_token` fields on the client-edit modal (`app/(dashboard)/clients/page.jsx`), stored on `clients` and passed through `updateClient()`.

Fires from inside `app/panel/redirect/[status]/route.js` via a new `fireClientS2SIfNeeded()` function, added alongside (not replacing) the existing `firePostbackIfNeeded()` supplier-postback mechanism — the two are deliberately separate: the existing one reports to *our own* supplier who sent the respondent; this new one reports to the *client* whose survey it is. Fire-and-forget with a 4-second timeout, matching the existing postback's own timeout convention; a failed outbound S2S call can never block or break the respondent's own redirect/status page.

### Confirmed Against Real Industry Practice

Checked against Cint's and Zamplia's own public developer documentation. Confirmed: simple browser-redirect for basic integrations, authenticated S2S API call for higher-security ones, is the standard pattern these marketplaces themselves use — nothing invented here.

### Cross-Tool Consistency Check

During verification, ExaVerify's equivalent `s2s_status.php` was found to have a genuine bug: it only checked for an *existing* `survey_responses` row to update, but that table only gets its first row created at the *first* status report — a respondent who had only entered (never yet completed) had no matching row yet, so their first-ever S2S report incorrectly returned "no matching entry." Fixed there by also checking `survey_starts` (written at entry time) as a fallback and inserting a fresh row when needed, matching `track.php`'s own existing multi-tier lookup pattern. This Node.js tool's `tracking_logs` table doesn't have the equivalent issue — a row already exists from the moment of entry (created in `app/r/[unique_code]/route.js`), so no matching fix was needed here.

### Outstanding Note

The outbound direction's live network round-trip could not be fully exercised end-to-end in the sandbox this round (dev-environment limitations — could not keep two local test servers running simultaneously, and calls to public test-echo services were blocked). The outbound code path mirrors the exact same fire-and-forget fetch() pattern already used by the existing, already-proven `firePostbackIfNeeded()` mechanism — same structure, different destination and payload shape. Recommended first real-world check once live credentials from an actual client (e.g. Cint) are available: point their S2S endpoint at a temporary webhook.site URL first, fire one real test completion, and confirm the request arrives before wiring in the real endpoint.
