-- ============================================================
-- App Settings — simple key/value store for settings that were
-- previously only configurable via Hostinger environment-variables
-- (e.g. Telegram alert bot-token/chat-ID). Lets a superadmin change
-- these from within the app itself, without needing server-access.
-- A value stored here takes priority; if empty, code falls back to
-- the matching environment-variable (so nothing breaks for anyone
-- who already has it set via .env only).
-- ============================================================
CREATE TABLE IF NOT EXISTS public.app_settings (
    setting_key TEXT PRIMARY KEY,
    setting_value TEXT,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow authenticated full access" ON public.app_settings;
CREATE POLICY "Allow authenticated full access" ON public.app_settings FOR ALL USING (auth.role() = 'authenticated');
DROP POLICY IF EXISTS "Allow service role full access" ON public.app_settings;
CREATE POLICY "Allow service role full access" ON public.app_settings FOR ALL USING (true);
