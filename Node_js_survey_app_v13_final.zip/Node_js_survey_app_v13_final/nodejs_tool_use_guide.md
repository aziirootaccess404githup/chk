# Exazon Survey Engine — Poora Use-Guide / Map

*Ye document batata hai — kya-kya-hai tool mein, kaunsa-feature-kya-karta-hai, aur kaise-use-karna-hai. Technical-details (code) ke liye Master-Reference-Document dekho — ye sirf "kaise-use-karoon" ke liye hai.*

---

## 🗺️ Sidebar Navigation Map

```
🏠 Dashboard (Home)
📁 Projects
   ├── All Projects (list)
   └── Create → Single / Child / Group / Recontact / API-Survey
👥 Clients
🏢 Suppliers (Vendors)
🔐 Client Accounts (Client-Portal management)
📚 Library
   ├── Questions
   ├── Prescreen Templates
   └── Screener Responses
📊 Reports
   ├── Client Report
   ├── Group Report
   ├── PM Activity
   ├── Supplier Report
   └── TSign Report
💰 Billing
🧾 Reconciliation & Billing
🛠️ Support
   ├── Blocked IPs
   ├── Encryption Lookup
   ├── IP Tracker
   ├── Reconciliation
   └── Redirect Status
⚡ Fraud & Quality Review
📈 Analytics
🧮 Feasibility Calculator
📋 Audit Log
📝 Notes
🔔 Alert Settings
👤 My Account (Change Password + Profile)
🔑 User Management (Admin-only, superadmin)
```

---

## 1. Dashboard (Home)

**Kya hai:** Sabse pehla page jo login ke baad khulta hai — overall snapshot.

**Kya dikhta hai:** Total projects, total completes/terminates, recent activity, quick-stats charts (trend, device/country breakdown).

**Kab use karo:** Roz-ka quick overview lene ke liye — "aaj kitna kaam hua" dekhne ke liye.

---

## 2. Projects

### 2a. All Projects (List)
**Kya hai:** Har project ki ek row — status, client, target vs completes.
**Kaise use karo:** Kisi bhi project pe click karke uska detail-page kholo. Yahin se Clone bhi kar sakte ho.

### 2b. Create → Single Project
**Kya hai:** Naya, normal project banane ka form.
**Zaroori fields:** Title, Client, CPI, Target, Country, Live Survey URL, Start/End Date, Project Manager, Status (Draft/Live/Paused/Closed/Invoiced/Archive).
**Yaad rakho:** Status "Live" hona chahiye tabhi respondent-traffic allow hoga — baaki sab (Draft/Paused/Closed/Invoiced/Archive) traffic block kar dete hain.

### 2c. Create → Child Project
**Kya hai:** Kisi existing project ka "child" — parent se linked, lekin apna alag SID/tracking.
**Kab use karo:** Jab same-study ka doosra phase/market chahiye, purane project se connected rehte hue.

### 2d. Create → Group Project
**Kya hai:** Ek project jo automatically kayi-countries ke liye alag-alag child-projects bana deta hai (parent + ek child per country).
**Kaise use karo:** Group-name daalo, countries select karo (multi-select), sample-size — system automatically total ko countries ke beech baँt deta hai. Har country ka apna alag SID/Live-URL hoga (jo tumhe baad mein individually set karna hoga, kyunki har market ka survey-link alag hota hai).

### 2e. Create → Recontact
**Kya hai:** Purane respondents ko dobara contact karne wala project-type.

### 2f. Create → API-Survey
**Kya hai:** Lucid/Cint/Dynata jaise real-time marketplaces se seedha connect karne ka placeholder.
**Zaroori baat:** Ye abhi genuinely functional-nahi-hai — kyunki in marketplaces se real partnership/approval chahiye hoti hai, sirf-code se nahi ho sakta. Form submit karne pe ek honest message dikhega "not yet connected, partner-approval-pending".

### 2g. Project Detail Page (kisi bhi project pe click karke)
**Tabs jo yahaँ milते hain:**
- **Survey Link** — Live/Test URL, Link-Type (Single/Multi/Country — Multi abhi sirf label hai, kaam nahi karta), Country-wise-links (agar Country-type select kiya ho)
- **PreScreen** — is specific project ke prescreener-questions add/edit/delete karo
- **Activity Log** — project pe kiya gaya kaam (team-member ne kya-kab kiya) log karo
- **Report** — is project ka apna performance-report (Complete/Terminate/OverQuota counts, download karne ka option)

---

## 3. Clients

**Kya hai:** Tumhare research-clients ki master-list (jinke liye tum survey chalate ho).
**Kaise use karo:** Naya client add karo (naam, contact-details) — phir Projects banate waqt "Client" dropdown mein wahi dikhega.

---

## 4. Suppliers (Vendors)

**Kya hai:** Tumhare traffic-vendors ki list — jo respondents bhejte hain.
**Har vendor mein:** Naam, complete/terminate/quotafull/quality — 4 redirect-URLs (jo vendor ko dete ho), status (Active/Inactive — Inactive karne se us vendor ka SAARA traffic turant block ho jaata hai, sab-projects mein ek-saath).
**Suppliers/[id] page (kisi vendor pe click karke):** Us vendor ka cross-project performance-history — kitne projects mein kaam kiya, kitne completes diye, sab ek-jagah.

---

## 5. Client Accounts (Client Portal)

**Kya hai:** Tumhare CLIENTS ke liye ek alag, simple login-system — jaha wo sirf apne-hi projects ka status dekh sakein (tumhare poore admin-dashboard tak unki pahunch nahi hoti).
**Kaise use karo:** Naya portal-account banao, client se link karo, unhe username/password de do — wo apna alag chhota dashboard dekh payenge.

---

## 6. Library

### 6a. Questions
**Kya hai:** Prescreener-questions ka reusable "bank" — ek baar banao, kayi projects mein reuse karo.

### 6b. Prescreen Templates
**Kya hai:** Poore-ka-poora question-sets (templates) jo ek-click mein kisi naye project pe apply ho jaayein.

### 6c. Screener Responses
**Kya hai:** Sab-projects ke prescreener-JAWAB (answers) — ek jagah, project-filter + CSV-export ke saath.
**Kaise use karo:** Kisi respondent ne prescreener mein kya-jawab diya tha, wo dhoondhna ho — yahaँ search/filter karo.

---

## 7. Reports

Har report ka apna focus hai:
- **Client Report** — client-wise performance summary
- **Group Report** — Group-projects (parent+children) ka combined-view
- **PM Activity** — team-members ne kitna time/kaam kiya, project-wise
- **Supplier Report** — vendor-wise performance
- **TSign Report** — traffic-signup/entry counts

---

## 8. Billing

**Kya hai:** Automatic Revenue/Cost/Margin calculation — CPI aur completes ke hisaab se.
**Kaise use karo:** Invoice-status update karo (Pending/Sent/Paid) — margin automatically calculate ho jaata hai.

---

## 9. Reconciliation & Billing

**Kya hai:** Vendor-invoices ko apni-tracking-se match karne ka tool — "vendor ne bola 500 completes, mere-system mein kitne genuinely-dikhte hain" compare karne ke liye.

---

## 10. Support Section

### 10a. Blocked IPs
Manually kisi IP ko block karo (fraud/bot-traffic rokne ke liye).

### 10b. Encryption Lookup
Kisi encrypted-UID ka original-UID dhoondho, ya ulta.

### 10c. IP Tracker
Kisi specific-IP ki poori-activity dekho — genuinely enforce bhi hoti hai (blocked-IP se traffic automatically reject).

### 10d. Reconciliation
General reconciliation-tools.

### 10e. Redirect Status
**Sabse zaroori page** — HAR respondent ka status (Complete/Terminate/OverQuota/Quality-Check/**Unmatched**/Pending) — project-filter ke saath.
**"Unmatched" filter specifically use karo** — ye batata hai kaha koi-mismatch/galti hui (client ne galat-status bheja, ya redirect-URL galat-set-hui, ya koi standalone-test kiya).

---

## 11. Fraud & Quality Review

**Kya hai:** Speeder/Duplicate/Same-IP se flagged respondents — plus Quality-Score se filter karne ka combined-tool.
**Kaise use karo:** "Flagged only" toggle-on karke sirf-suspicious-respondents dekho. Ya Min/Max-score daalke kisi bhi range ke respondents dhoondho.

---

## 12. Analytics

**Kya hai:** Trend-charts (Complete/Terminate/OverQuota over-time), Device-breakdown, Country-breakdown.

---

## 13. Feasibility Calculator

**Kya hai:** Ek chhota calculator — Sample-size, IR, LOI, Timeline, CPI daalke dekho project-genuinely-feasible-hai-ya-nahi (client-ko-quote-dene-se-pehle).

---

## 14. Audit Log

**Kya hai:** Kisne-kya-kiya, kab-kiya — poora system-wide history.

---

## 15. Notes

**Kya hai:** Chhoti sticky-notes, apne-liye ya team ke liye reminders.

---

## 16. Alert Settings

**Kya hai:** Telegram bot-token aur chat-ID yahaँ set karo — taaki quota-reached jaisी important-events pe turant Telegram-pe alert mile.
**Kaun use kar sakta hai:** Sirf Superadmin/Manager (Viewer ko ye page dikhta hi nahi).

---

## 17. My Account (Change Password Page)

**2 hisse:**
- **My Profile** — apna naam/email khud edit karo
- **Change Password** — apna password badlo

---

## 18. User Management (`/admin`)

**⚠️ Sidebar mein "User Management" naam se hai — sirf Superadmin ise khol sakta hai.**

**Yahaँ kya karo:**
- Naye team-members add karo (email, password, role)
- **3 Roles:**
  - **Superadmin** — sab kuch kar sakta hai, delete bhi
  - **Manager** — create/edit kar sakta hai, delete NAHI
  - **Viewer** — sirf dekh sakta hai, kuch bhi edit/delete nahi kar sakta
- Kisi ka role badlo, ya account delete karo

---

## 🎯 Common Workflows — Step-By-Step

### Naya Client Onboard Karna
1. **Clients** → naya client add karo
2. **Suppliers** → agar naya vendor bhi hai, add karo (4 redirect-URLs generate honge)
3. Vendor ko redirect-URLs bhejo
4. **Projects → Create → Single** → naya project banao, client select karo, Live-URL mein client ki survey-link daalo
5. Project ke andar **"Assign Vendor"** karo — tumhe entry-link milega
6. Khud us entry-link ko test karo (genuine end-to-end verify ke liye — [PID] ki jagah koi test-value daal ke)
7. Vendor ko entry-link do — traffic shuru

### Kisi Respondent Ka Status Check Karna
1. **Support → Redirect Status**
2. Project-filter select karo (ya "All")
3. UID search karo, ya Status-filter use karo

### Fraud-Suspect Respondents Dhoondhna
1. **Fraud & Quality Review**
2. "Flagged only" ON karo
3. Dekho kaunse UIDs Speeder/Duplicate/Same-IP flag hue

### Naya Team-Member Add Karna
1. **User Management** (sirf Superadmin)
2. "Add New User" — email, password, role choose karo
3. Unhe login-details bhejo

---

*Document banaya gaya: is session ke pura hone ke baad, tool ke sabhi features cover karte hue. Agar koi naya feature add ho, isko bhi update karna.*
