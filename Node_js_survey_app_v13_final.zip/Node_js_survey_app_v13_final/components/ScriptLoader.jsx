"use client";
import { useEffect } from 'react';
import { usePathname } from 'next/navigation';

export default function ScriptLoader() {
  const pathname = usePathname();

  useEffect(() => {
    // These 30 scripts are the legacy jQuery/Bootstrap admin-template's
    // full JS stack — genuinely needed on dashboard pages (sidebar,
    // charts, dropdowns, etc.), but the /login and /admin-login pages
    // have none of those DOM elements. Loading them there was causing a
    // cascade of "Cannot read properties of null" / "element not
    // specified" errors (sidebar.js, sticky.js, perfect-scrollbar.js all
    // expect elements that don't exist on a bare login form) — which was
    // very likely disrupting React's own event-handling on that page too
    // (jQuery and React both fighting over the same DOM), which is the
    // most likely explanation for the login form silently falling back
    // to a native GET-submit (credentials ending up in the URL) instead
    // of the intended onSubmit handler firing.
    if (pathname === '/login' || pathname === '/admin-login') {
      return;
    }

    const scripts = [
      "/lib/jquery/dist/jquery.min.js",
      "https://code.jquery.com/jquery-1.12.4.js",
      "/js/vendor.min.js",
      "/lib/bootstrap-select/bootstrap-select.min.js",
      "/js/app.min.js",
      "/js/sweetalert.min.js",
      "https://code.jquery.com/ui/1.12.1/jquery-ui.js",
      "/js/multiselect-dropdown.js",
      "/js/custom.js",
      "https://code.highcharts.com/maps/highmaps.js",
      "https://code.highcharts.com/maps/modules/exporting.js",
      "https://code.highcharts.com/maps/modules/data.js",
      "https://code.highcharts.com/maps/modules/accessibility.js",
      "https://cdn.jsdelivr.net/npm/apexcharts",
      "https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js",
      "/js/jquery.validate.min.js",
      "/js/jquery.validate.unobtrusive.min.js",
      "/js/site.js",
      "/assets/plugins/bootstrap/js/bootstrap.bundle.min.js",
      "/assets/plugins/chart.js/Chart.bundle.min.js",
      "/assets/plugins/ionicons/ionicons.js",
      "/assets/plugins/moment/moment.js",
      "/assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js",
      "/assets/plugins/rating/jquery.rating-stars.js",
      "/assets/plugins/rating/jquery.barrating.js",
      "/assets/plugins/side-menu/sidemenu.js",
      "/assets/plugins/sidebar/sidebar.js",
      "/assets/plugins/sidebar/sidebar-custom.js",
      "/assets/js/sticky.js",
      "/assets/js/eva-icons.min.js",
      "/assets/js/custom.js"
    ];

    const loadScript = (src) => new Promise(resolve => {
       const s = document.createElement('script');
       s.src = src;
       s.async = false; 
       
       let resolved = false;
       const handleResolve = () => {
           if (!resolved) {
               resolved = true;
               resolve();
           }
       };

       s.onload = handleResolve;
       s.onerror = handleResolve; 
       
       // Fallback timeout just in case the script is blocked by an adblocker and fires neither event
       setTimeout(handleResolve, 500);

       document.body.appendChild(s);
    });

    const run = async () => {
       for (const src of scripts) {
           if (!document.querySelector(`script[src="${src}"]`)) {
               await loadScript(src);
           }
       }
       console.log("All legacy scripts loaded sequentially.");
    };

    run();
  }, [pathname]);

  return null;
}
