'use server'

import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { createClient } from '@/utils/supabase/server'
import { supabaseAdmin } from '@/utils/supabase'

export async function login(formData) {
  const supabase = await createClient()

  let email = formData.get('username')
  if (!email.includes('@')) {
    email = `${email}@exazonresearch.com`
  }

  const data = {
    email: email,
    password: formData.get('password'),
  }

  const { error } = await supabase.auth.signInWithPassword(data)

  if (error) {
    return { error: error.message }
  }

  revalidatePath('/', 'layout')
  return { success: true }
}

export async function updatePassword(newPassword) {
  const supabase = await createClient()
  const { error } = await supabase.auth.updateUser({ password: newPassword })
  if (error) return { error: error.message }
  return { success: true }
}

// ── My Profile (self-service name/email editing) ────────────────
// Matches ExaVerify's "My Profile" section — lets the logged-in user
// edit their own name (stored in profiles.full_name) and email
// (Supabase Auth). Previously only password-change existed here.
export async function getMyProfile() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { error: 'Not logged in' }

  const { data: profile } = await supabaseAdmin
    .from('profiles')
    .select('full_name')
    .eq('id', user.id)
    .single()

  return {
    success: true,
    data: {
      name: profile?.full_name || '',
      email: user.email || '',
    },
  }
}

export async function updateMyProfile(name, email) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { error: 'Not logged in' }

  // Update name in profiles table
  const { error: profileError } = await supabaseAdmin
    .from('profiles')
    .update({ full_name: name })
    .eq('id', user.id)
  if (profileError) return { error: profileError.message }

  // Update email in Supabase Auth, only if it actually changed — this
  // triggers Supabase's own confirmation-email flow (the change isn't
  // final until the user clicks the confirmation link Supabase sends),
  // so the name-update above still succeeds independently either way.
  if (email && email !== user.email) {
    const { error: emailError } = await supabase.auth.updateUser({ email })
    if (emailError) return { error: emailError.message, nameUpdated: true }
    return { success: true, emailConfirmationSent: true }
  }

  revalidatePath('/', 'layout')
  return { success: true }
}

export async function logout() {
  const supabase = await createClient()
  
  await supabase.auth.signOut()
  
  redirect('/login')
}
