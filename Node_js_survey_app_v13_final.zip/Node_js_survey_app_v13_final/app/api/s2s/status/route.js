import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/utils/supabase';
import { runFraudChecks, TERMINAL_STATUSES } from '@/utils/fraudDetection';

// ============================================================
// Inbound Server-to-Server (S2S) status API
// POST /api/s2s/status
// Header: Authorization: Bearer <supplier's s2s_inbound_api_key>
// Body (JSON): { "respondent_id": "...", "status": "complete" | "terminate" | "overquota" | "security_fail" }
//
// This is the "we act as the client/hub, a vendor's own server calls
// us" direction — the mirror image of the existing outbound postback
// in app/panel/redirect/[status]/route.js (which fires when WE are
// the supplier reporting to someone else). Genuinely reuses the same
// runFraudChecks utility that route already uses, rather than
// re-implementing fraud-detection separately here — avoids the exact
// class of bug found in Kishan's panel, where a second, parallel
// completion-path quietly lacked protections the main one had.
//
// Why POST + JSON + Bearer-token here (vs. the GET+URL-param pattern
// used for browser-redirect-based suppliers): S2S calls are
// server-to-server, never touch a respondent's browser, so there's no
// need to keep the format URL-friendly — and a bearer-token in a
// header is the standard, more secure way to authenticate a
// server-to-server caller (never exposed to a browser or logged in
// URL-access-logs the way a URL query-param would be).
// ============================================================

const STATUS_MAP = {
    complete: 'Complete',
    terminate: 'Terminate',
    overquota: 'OverQuota',
    quotafull: 'OverQuota',
    security_fail: 'SecurityFail',
    quality_fail: 'SecurityFail',
};

export async function POST(request) {
    try {
        // ── Authenticate via Bearer token ──────────────────────────
        const authHeader = request.headers.get('authorization') || '';
        const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : null;

        if (!token) {
            return NextResponse.json({ error: 'Missing Authorization: Bearer <token> header.' }, { status: 401 });
        }

        const { data: supplier, error: supplierError } = await supabaseAdmin
            .from('suppliers')
            .select('id, name, status, s2s_inbound_api_key')
            .eq('s2s_inbound_api_key', token)
            .single();

        if (supplierError || !supplier) {
            return NextResponse.json({ error: 'Invalid or unrecognized API token.' }, { status: 401 });
        }
        if (supplier.status !== 'Active') {
            return NextResponse.json({ error: 'This vendor account is not currently active.' }, { status: 403 });
        }

        // ── Parse and validate the body ────────────────────────────
        let body;
        try {
            body = await request.json();
        } catch (e) {
            return NextResponse.json({ error: 'Request body must be valid JSON.' }, { status: 400 });
        }

        const respondentId = (body.respondent_id || body.uid || body.pid || '').trim();
        const rawStatus = (body.status || '').trim().toLowerCase();

        if (!respondentId) {
            return NextResponse.json({ error: 'respondent_id is required.' }, { status: 400 });
        }

        // Same "don't guess" principle as everywhere else in this project:
        // an unrecognized status becomes Unmatched, never silently Complete.
        const internalStatus = STATUS_MAP[rawStatus] || 'Unmatched';

        // ── Find the tracking log for this respondent + this supplier ──
        // Scoped to this supplier's own id (from the validated token) so
        // one vendor's API key can never be used to update another
        // vendor's respondent records.
        const { data: logs } = await supabaseAdmin
            .from('tracking_logs')
            .select('id, project_id, supplier_id, status, status_locked, started_at')
            .eq('supplier_id', supplier.id)
            .eq('respondent_uid', respondentId)
            .order('started_at', { ascending: false })
            .limit(1);

        const matchedLog = logs && logs.length > 0 ? logs[0] : null;

        if (!matchedLog) {
            return NextResponse.json({
                error: 'No matching entry found for this respondent_id under your vendor account. The respondent must have entered through your own entry-link first.',
            }, { status: 404 });
        }

        // ── Status-lock check (same rule as the redirect route) ────
        const isAlreadyLocked = !!(matchedLog.status_locked && TERMINAL_STATUSES.includes(matchedLog.status));
        if (isAlreadyLocked) {
            return NextResponse.json({
                respondent_id: respondentId,
                status: matchedLog.status,
                note: 'This respondent already has a final, locked status — no change was made.',
            }, { status: 200 });
        }

        // ── Fraud checks (same utility the redirect route uses) ────
        const forwarded = request.headers.get('x-forwarded-for');
        const ip = forwarded ? forwarded.split(',')[0].trim() : request.headers.get('x-real-ip') || '0.0.0.0';

        const fraudResult = await runFraudChecks(supabaseAdmin, {
            projectId: matchedLog.project_id,
            uid: respondentId,
            ip,
            startedAt: matchedLog.started_at,
            excludeLogId: matchedLog.id,
        });

        await supabaseAdmin
            .from('tracking_logs')
            .update({
                status: internalStatus,
                completed_at: new Date().toISOString(),
                status_locked: TERMINAL_STATUSES.includes(internalStatus),
                ...fraudResult,
            })
            .eq('id', matchedLog.id);

        return NextResponse.json({
            respondent_id: respondentId,
            status: internalStatus,
            received_at: new Date().toISOString(),
        }, { status: 200 });

    } catch (error) {
        console.error('S2S inbound status error:', error);
        return NextResponse.json({ error: 'Internal error processing the status update.' }, { status: 500 });
    }
}
