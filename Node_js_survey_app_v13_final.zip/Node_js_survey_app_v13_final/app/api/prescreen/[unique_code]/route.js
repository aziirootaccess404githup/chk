import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/utils/supabase';
import { getGeo } from '@/utils/geoDevice';

export async function GET(request, { params }) {
    const { unique_code } = await params;

    try {
        // Look up mapping to get project_id
        const { data: mapping, error: mappingError } = await supabaseAdmin
            .from('project_supplier_mappings')
            .select('project_id, projects ( title, status )')
            .eq('unique_code', unique_code)
            .single();

        if (mappingError || !mapping) {
            return NextResponse.json({ success: false, error: 'Invalid survey link.' }, { status: 404 });
        }

        // Fetch prescreen questions for this project
        const { data: questions, error: questionsError } = await supabaseAdmin
            .from('prescreen_questions')
            .select('*')
            .eq('project_id', mapping.project_id)
            .order('created_at', { ascending: true });

        if (questionsError) throw questionsError;

        // Auto-detect respondent's country — used client-side to show
        // income-style questions in local currency (display only; the
        // submitted answer always stays the original USD-bracket text,
        // same design as the same fix applied to ExaVerify/Kishan's panel).
        const ip = request.headers.get('x-forwarded-for')?.split(',')[0] || request.headers.get('x-real-ip') || '';
        let detectedCountry = '';
        try { detectedCountry = (await getGeo(ip)).country; } catch (e) {}

        return NextResponse.json({
            success: true,
            questions: questions || [],
            projectTitle: mapping.projects?.title || 'Survey',
            projectId: mapping.project_id,
            detectedCountry,
        });

    } catch (error) {
        console.error('Prescreen API error:', error);
        return NextResponse.json({ success: false, error: 'Internal Server Error' }, { status: 500 });
    }
}
