"use client";
import React, { useState, useEffect } from 'react';
import { submitPrescreenAnswers } from '@/app/actions/prescreen';

export default function PrescreenerPage({ params }) {
    const { unique_code } = React.use(params);
    const [questions, setQuestions] = useState([]);
    const [answers, setAnswers] = useState({});
    const [uid, setUid] = useState('');
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState('');
    const [projectTitle, setProjectTitle] = useState('');
    const [projectId, setProjectId] = useState('');
    const [selectedCountry, setSelectedCountry] = useState('');

    // Country -> currency-symbol + USD conversion-rate. Used ONLY to change
    // what the respondent SEES for income-style questions (any question
    // whose text mentions "income" and whose options contain "$") — the
    // value actually submitted/saved always stays the original USD-bracket
    // text untouched, same design as the matching fix on ExaVerify and
    // Kishan's panel, so analytics/exports stay consistent across countries.
    const COUNTRY_CURRENCY = {
        'India': { symbol: '₹', rate: 83 }, 'United Kingdom': { symbol: '£', rate: 0.79 },
        'Canada': { symbol: 'C$', rate: 1.36 }, 'Australia': { symbol: 'A$', rate: 1.52 },
        'Germany': { symbol: '€', rate: 0.92 }, 'France': { symbol: '€', rate: 0.92 },
        'Philippines': { symbol: '₱', rate: 56 }, 'United Arab Emirates': { symbol: 'AED', rate: 3.67 },
        'Singapore': { symbol: 'S$', rate: 1.35 }, 'South Africa': { symbol: 'R', rate: 18.5 },
        'Pakistan': { symbol: 'Rs', rate: 278 }, 'Bangladesh': { symbol: 'Tk', rate: 110 },
        'Indonesia': { symbol: 'Rp', rate: 15600 }, 'Malaysia': { symbol: 'RM', rate: 4.7 },
        'Brazil': { symbol: 'R$', rate: 5.0 }, 'Mexico': { symbol: 'Mex$', rate: 17 },
        'Japan': { symbol: '¥', rate: 150 }, 'United States': { symbol: '$', rate: 1 },
    };

    function isIncomeQuestion(q) {
        return /income/i.test(q.question_text || '') && (q.options || '').includes('$');
    }

    function formatOptionDisplay(opt) {
        const info = COUNTRY_CURRENCY[selectedCountry];
        if (!info) return opt;
        // Parse every $-amount in the option text (handles "Less than $15,000",
        // "$15,000 to $24,999", "$250,000 or greater") and replace each with
        // the local-currency equivalent, keeping the rest of the text as-is.
        return opt.replace(/\$([\d,]+)/g, (match, numStr) => {
            const num = parseInt(numStr.replace(/,/g, ''), 10);
            const converted = Math.round(num * info.rate);
            return info.symbol + converted.toLocaleString('en-US');
        });
    }

    useEffect(() => {
        // Extract uid from URL query params on client side
        const urlParams = new URLSearchParams(window.location.search);
        const respondentUid = urlParams.get('uid') || urlParams.get('pid') || urlParams.get('id') || urlParams.get('rid') || '';
        setUid(respondentUid);

        // Fetch prescreen questions for this mapping
        fetch(`/api/prescreen/${unique_code}`)
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    setQuestions(data.questions || []);
                    setProjectTitle(data.projectTitle || 'Survey');
                    setProjectId(data.projectId || '');
                    if (data.detectedCountry && COUNTRY_CURRENCY[data.detectedCountry]) {
                        setSelectedCountry(data.detectedCountry);
                    }
                } else {
                    setError(data.error || 'Failed to load prescreener.');
                }
            })
            .catch(() => setError('Failed to load prescreener.'))
            .finally(() => setLoading(false));
    }, [unique_code]);

    const handleChange = (questionId, value, isMultiple = false) => {
        if (isMultiple) {
            setAnswers(prev => {
                const existing = prev[questionId] || [];
                if (existing.includes(value)) {
                    return { ...prev, [questionId]: existing.filter(v => v !== value) };
                }
                return { ...prev, [questionId]: [...existing, value] };
            });
        } else {
            setAnswers(prev => ({ ...prev, [questionId]: value }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSubmitting(true);

        // Actually save what the respondent answered (previously this was
        // collected in state and then discarded — never persisted anywhere).
        // Never blocks navigation even if saving fails.
        if (projectId && uid && Object.keys(answers).length > 0) {
            try {
                await submitPrescreenAnswers(projectId, uid, answers);
            } catch (err) {
                console.error('Failed to save prescreen answers:', err);
            }
        }

        // Build query string and redirect to the actual survey route
        const params = new URLSearchParams();
        if (uid) params.set('uid', uid);
        params.set('prescreened', '1');
        
        // Navigate to the actual survey link
        window.location.href = `/r/${unique_code}?${params.toString()}`;
    };

    if (loading) {
        return (
            <div style={styles.body}>
                <div style={styles.card}>
                    <div style={styles.loadingSpinner}></div>
                    <p style={{ color: '#6b7280', marginTop: '16px' }}>Loading prescreener...</p>
                </div>
            </div>
        );
    }

    if (error) {
        return (
            <div style={styles.body}>
                <div style={styles.card}>
                    <span style={{ fontSize: '60px' }}>⚠️</span>
                    <h2 style={{ color: '#1f2937', marginTop: '12px' }}>Unable to Load</h2>
                    <p style={{ color: '#6b7280' }}>{error}</p>
                </div>
            </div>
        );
    }

    if (questions.length === 0) {
        // No prescreen questions — auto-redirect to survey
        if (typeof window !== 'undefined' && uid) {
            window.location.href = `/r/${unique_code}?uid=${uid}&prescreened=1`;
        }
        return null;
    }

    return (
        <>
            <style>{`
                @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
                * { box-sizing: border-box; margin: 0; padding: 0; }
                body { font-family: 'Poppins', Arial, sans-serif; background: #f4f7fb; }
                .ps-body { font-family: 'Poppins', Arial, sans-serif; background: #f4f7fb; min-height: 100vh; padding: 40px 20px; }
                .ps-container { max-width: 700px; margin: 0 auto; background: #fff; border-radius: 16px; box-shadow: 0 8px 30px rgba(0,0,0,0.12); padding: 40px 45px; animation: fadeIn 0.4s ease; }
                @keyframes fadeIn { from { opacity:0; transform:translateY(20px); } to { opacity:1; transform:translateY(0); } }
                .ps-header { border-bottom: 2px solid #e5e7eb; padding-bottom: 20px; margin-bottom: 28px; }
                .ps-logo { font-size: 22px; font-weight: 700; color: #1f4e79; letter-spacing: -0.5px; }
                .ps-logo span { color: #2563eb; }
                .ps-title { font-size: 24px; font-weight: 700; color: #1f2937; margin-top: 14px; }
                .ps-subtitle { font-size: 14px; color: #6b7280; margin-top: 6px; line-height: 1.6; }
                .ps-progress { background: #e5e7eb; height: 6px; border-radius: 3px; margin-bottom: 28px; overflow: hidden; }
                .ps-progress-bar { height: 100%; background: linear-gradient(90deg, #2563eb, #3b82f6); border-radius: 3px; transition: width 0.3s; }
                .ps-question { margin: 22px 0; padding: 20px; border: 1px solid #e5e7eb; border-radius: 12px; background: #f9fafb; }
                .ps-question:hover { border-color: #93c5fd; background: #eff6ff; transition: all 0.2s; }
                .ps-question label.main { display: block; margin-bottom: 12px; font-weight: 600; color: #1f2937; font-size: 15px; line-height: 1.5; }
                .ps-question input[type="text"],
                .ps-question input[type="number"],
                .ps-question select,
                .ps-question textarea { width: 100%; padding: 11px 14px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 14px; font-family: 'Poppins', sans-serif; color: #374151; background: #fff; outline: none; transition: border 0.2s; }
                .ps-question input:focus, .ps-question select:focus, .ps-question textarea:focus { border-color: #2563eb; box-shadow: 0 0 0 3px rgba(37,99,235,0.1); }
                .ps-option { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 8px; cursor: pointer; transition: background 0.15s; }
                .ps-option:hover { background: #dbeafe; }
                .ps-option input[type="radio"],
                .ps-option input[type="checkbox"] { width: 18px; height: 18px; cursor: pointer; accent-color: #2563eb; }
                .ps-option span { font-size: 14px; color: #374151; }
                .ps-btn { display: block; width: 100%; margin-top: 28px; background: linear-gradient(135deg, #1f4e79, #2563eb); color: #fff; border: none; padding: 15px 28px; border-radius: 10px; font-weight: 600; font-size: 16px; font-family: 'Poppins', sans-serif; cursor: pointer; transition: opacity 0.2s, transform 0.1s; }
                .ps-btn:hover { opacity: 0.92; transform: translateY(-1px); }
                .ps-btn:disabled { opacity: 0.7; cursor: not-allowed; }
                .ps-footer { margin-top: 24px; text-align: center; font-size: 13px; color: #9ca3af; }
                @media (max-width: 600px) { .ps-container { padding: 24px 20px; } }
            `}</style>

            <div className="ps-body">
                <div className="ps-container">
                    <div className="ps-header">
                        <div className="ps-logo" style={{ display: 'flex', alignItems: 'center', gap: '10px', justifyContent: 'center' }}>
                            <img src="/images/exazon-logo.jpg" alt="Exazon Research" style={{ height: '32px', borderRadius: '4px' }} />
                            Exazon<span>Research</span>
                        </div>
                        <h1 className="ps-title">Survey Prescreener</h1>
                        <p className="ps-subtitle">
                            Please answer a few quick questions to determine your eligibility.
                            This will take less than 2 minutes.
                        </p>
                    </div>

                    <div className="ps-progress">
                        <div className="ps-progress-bar" style={{ width: '15%' }}></div>
                    </div>

                    <form onSubmit={handleSubmit}>
                        {questions.some(isIncomeQuestion) && (
                            <div className="ps-question">
                                <label className="main">Which country are you in?</label>
                                <select
                                    value={selectedCountry}
                                    onChange={e => setSelectedCountry(e.target.value)}
                                    style={{ width: '100%', padding: '10px', borderRadius: '8px', border: '1px solid #d1d5db' }}
                                >
                                    <option value="">— Select —</option>
                                    {Object.keys(COUNTRY_CURRENCY).sort().map(c => (
                                        <option key={c} value={c}>{c}</option>
                                    ))}
                                    <option value="Other">Other / Not listed (USD)</option>
                                </select>
                            </div>
                        )}
                        {questions.map((q, index) => (
                            <div className="ps-question" key={q.id}>
                                <label className="main">
                                    {index + 1}. {q.question_text}
                                </label>

                                {q.question_type === 'Open Ended' && (
                                    <input
                                        type="text"
                                        placeholder="Your answer..."
                                        value={answers[q.id] || ''}
                                        onChange={e => handleChange(q.id, e.target.value)}
                                    />
                                )}

                                {q.question_type === 'Single Choice' && q.options && (
                                    <div>
                                        {(Array.isArray(q.options) ? q.options : q.options.split('\n').filter(Boolean)).map((opt, oi) => (
                                            <label className="ps-option" key={oi}>
                                                <input
                                                    type="radio"
                                                    name={`q_${q.id}`}
                                                    value={opt}
                                                    checked={answers[q.id] === opt}
                                                    onChange={() => handleChange(q.id, opt)}
                                                />
                                                <span>{isIncomeQuestion(q) ? formatOptionDisplay(opt) : opt}</span>
                                            </label>
                                        ))}
                                    </div>
                                )}

                                {q.question_type === 'Multiple Choice' && q.options && (
                                    <div>
                                        {(Array.isArray(q.options) ? q.options : q.options.split('\n').filter(Boolean)).map((opt, oi) => (
                                            <label className="ps-option" key={oi}>
                                                <input
                                                    type="checkbox"
                                                    value={opt}
                                                    checked={(answers[q.id] || []).includes(opt)}
                                                    onChange={() => handleChange(q.id, opt, true)}
                                                />
                                                <span>{opt}</span>
                                            </label>
                                        ))}
                                    </div>
                                )}

                                {/* Fallback: if no options defined */}
                                {(q.question_type === 'Single Choice' || q.question_type === 'Multiple Choice') && !q.options && (
                                    <input
                                        type="text"
                                        placeholder="Your answer..."
                                        value={answers[q.id] || ''}
                                        onChange={e => handleChange(q.id, e.target.value)}
                                    />
                                )}
                            </div>
                        ))}

                        <button
                            type="submit"
                            className="ps-btn"
                            disabled={submitting}
                        >
                            {submitting ? 'Processing...' : 'Continue to Survey →'}
                        </button>
                    </form>

                    <div className="ps-footer">
                        © 2026 Exazon Research · Your responses are kept confidential.
                    </div>
                </div>
            </div>
        </>
    );
}

const styles = {
    body: {
        fontFamily: 'Arial, sans-serif',
        background: '#f4f7fb',
        minHeight: '100vh',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '20px',
    },
    card: {
        background: '#fff',
        borderRadius: '16px',
        padding: '50px 40px',
        textAlign: 'center',
        boxShadow: '0 8px 30px rgba(0,0,0,0.1)',
        maxWidth: '500px',
        width: '100%',
    },
};
