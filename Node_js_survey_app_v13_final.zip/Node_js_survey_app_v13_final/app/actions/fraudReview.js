"use server";

import { supabaseAdmin } from "@/utils/supabase";

// ── Fraud & Quality Review ────────────────────────────────────────
// Matches ExaVerify's "fraud" tab (Speeders/Duplicates list) AND its
// separate quality_score.php (score-range browser) — combined into
// one page here since both read the exact same tracking_logs columns
// (is_speeder, is_duplicate, same_ip_flag, quality_score, score_reasons).
// filters:
//   projectId    — optional, restrict to one project
//   minScore/maxScore — quality_score range (0-100)
//   flaggedOnly  — if true, only rows where is_speeder OR is_duplicate
//                  OR same_ip_flag is true (the "fraud review" view)
export async function getFraudReview({ projectId = null, minScore = 0, maxScore = 100, flaggedOnly = false } = {}) {
    try {
        let query = supabaseAdmin
            .from('tracking_logs')
            .select('id, respondent_uid, status, loi_seconds, is_speeder, is_duplicate, same_ip_flag, quality_score, score_reasons, started_at, project_id, supplier_id, projects ( title ), suppliers ( name )')
            .gte('quality_score', minScore)
            .lte('quality_score', maxScore)
            .order('quality_score', { ascending: true })
            .limit(1000);

        if (projectId) {
            query = query.eq('project_id', projectId);
        }
        if (flaggedOnly) {
            query = query.or('is_speeder.eq.true,is_duplicate.eq.true,same_ip_flag.eq.true');
        }

        const { data, error } = await query;
        if (error) throw error;
        return { success: true, data: data || [] };
    } catch (error) {
        console.error("Error fetching fraud review:", error);
        return { success: false, error: error.message };
    }
}
