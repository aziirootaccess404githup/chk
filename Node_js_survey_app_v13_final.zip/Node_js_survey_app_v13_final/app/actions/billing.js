"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { revalidatePath } from "next/cache";
import { requireWriteAccess, requireSuperadmin } from "@/utils/permissions";

// ── BILLING DASHBOARD ─────────────────────────────────────────
// Revenue = completes × cpi (what the client pays us)
// Cost    = completes × supplier_cpi (what we pay the supplier)
// Margin  = Revenue − Cost
// Ported from ExaVerify's index.php Billing tab query.
export async function getBillingData() {
    try {
        const { data: projects, error: projErr } = await supabaseAdmin
            .from('projects')
            .select(`
                id, title, cpi, supplier_cpi, currency,
                invoice_status, invoice_no, invoice_notes,
                client_id, clients ( name )
            `)
            .order('created_at', { ascending: false });
        if (projErr) throw projErr;
        if (!projects || projects.length === 0) return { success: true, data: [] };

        const projectIds = projects.map(p => p.id);
        const { data: logs, error: logsErr } = await supabaseAdmin
            .from('tracking_logs')
            .select('project_id, status')
            .in('project_id', projectIds)
            .eq('status', 'Complete');
        if (logsErr) throw logsErr;

        const completesByProject = {};
        (logs || []).forEach(l => {
            completesByProject[l.project_id] = (completesByProject[l.project_id] || 0) + 1;
        });

        const result = projects.map(p => {
            const completes = completesByProject[p.id] || 0;
            const cpi = p.cpi || 0;
            const supplierCpi = p.supplier_cpi || 0;
            const revenue = completes * cpi;
            const cost = completes * supplierCpi;
            const margin = revenue - cost;
            return {
                id: p.id,
                code: 'PRJ-' + p.id.substring(0, 4).toUpperCase(),
                name: p.title,
                clientName: p.clients?.name || 'N/A',
                completes,
                cpi,
                supplierCpi,
                currency: p.currency || 'USD',
                revenue,
                cost,
                margin,
                invoiceStatus: p.invoice_status || 'unpaid',
                invoiceNo: p.invoice_no || '',
                invoiceNotes: p.invoice_notes || '',
            };
        });

        return { success: true, data: result };
    } catch (error) {
        console.error("Error fetching billing data:", error);
        return { success: false, error: error.message };
    }
}

export async function updateInvoiceStatus(projectId, invoiceStatus, invoiceNo, invoiceNotes) {
    try {
        await requireWriteAccess();
        const { error } = await supabaseAdmin
            .from('projects')
            .update({
                invoice_status: invoiceStatus,
                invoice_no: invoiceNo || null,
                invoice_notes: invoiceNotes || null,
            })
            .eq('id', projectId);

        if (error) throw error;

        revalidatePath('/billing');
        return { success: true };
    } catch (error) {
        console.error("Error updating invoice status:", error);
        return { success: false, error: error.message };
    }
}
