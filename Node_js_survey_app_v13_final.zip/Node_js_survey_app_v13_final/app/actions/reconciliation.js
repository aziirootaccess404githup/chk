"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { revalidatePath } from "next/cache";
import { requireWriteAccess, requireSuperadmin } from "@/utils/permissions";

// ── SEARCH BY IDENTIFIERS ────────────────────────────────────
// Real search across tracking_logs by a list of respondent UIDs
// (comma or newline separated). No fake geo/device/browser — those
// aren't captured anywhere in the real schema, so this shows the real
// fields instead: quality score, duplicate/speeder flags, IP.
export async function searchReconciliation(identifiersRaw) {
    try {
        const identifiers = identifiersRaw
            .split(/[\n,]/)
            .map(s => s.trim())
            .filter(Boolean);

        if (identifiers.length === 0) return { success: true, data: [] };

        const { data, error } = await supabaseAdmin
            .from('tracking_logs')
            .select(`
                id,
                respondent_uid,
                status,
                status_locked,
                started_at,
                ip_address,
                is_duplicate,
                is_speeder,
                quality_score,
                projects ( title ),
                suppliers ( name )
            `)
            .in('respondent_uid', identifiers)
            .order('started_at', { ascending: false });

        if (error) throw error;

        const result = (data || []).map(l => ({
            id: l.id,
            pName: l.projects?.title || 'N/A',
            sName: l.suppliers?.name || 'N/A',
            uid: l.respondent_uid,
            status: l.status,
            statusLocked: l.status_locked,
            date: l.started_at ? new Date(l.started_at).toLocaleString() : 'N/A',
            ip: l.ip_address,
            isDuplicate: l.is_duplicate,
            isSpeeder: l.is_speeder,
            qualityScore: l.quality_score,
        }));

        return { success: true, data: result };
    } catch (error) {
        console.error("Error searching reconciliation data:", error);
        return { success: false, error: error.message };
    }
}

// ── RECONCILE (manual status override) ───────────────────────
// For support staff to manually correct a lead's status — e.g. a
// respondent genuinely completed but the vendor's own tracking shows
// otherwise, or a log got stuck on "Started". This intentionally
// bypasses the normal status-lock (support tool = explicit override),
// but always re-locks it afterward so it can't drift again.
export async function reconcileLogs(logIds, newStatus) {
    try {
        await requireWriteAccess();
        if (!logIds || logIds.length === 0) {
            return { success: false, error: "No records selected." };
        }
        const validStatuses = ['Complete', 'Terminate', 'OverQuota', 'SecurityFail'];
        if (!validStatuses.includes(newStatus)) {
            return { success: false, error: "Invalid target status." };
        }

        const { error } = await supabaseAdmin
            .from('tracking_logs')
            .update({ status: newStatus, status_locked: true })
            .in('id', logIds);

        if (error) throw error;

        revalidatePath('/support/reconciliation');
        return { success: true };
    } catch (error) {
        console.error("Error reconciling logs:", error);
        return { success: false, error: error.message };
    }
}
