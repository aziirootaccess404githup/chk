"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { revalidatePath } from "next/cache";
import { logAudit } from "@/utils/auditLog";
import { requireWriteAccess, requireSuperadmin } from "@/utils/permissions";

export async function getSuppliers() {
    try {
        const { data, error } = await supabaseAdmin
            .from('suppliers')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) throw error;

        // Real per-status project-counts per supplier — these were
        // previously hardcoded to 0 in the UI (never actually queried),
        // meaning every supplier always showed "0" projects in every
        // status column regardless of how many they genuinely had.
        const { data: mappings } = await supabaseAdmin
            .from('project_supplier_mappings')
            .select('supplier_id, projects ( status )');

        const counts = {};
        (mappings || []).forEach(m => {
            if (!m.supplier_id) return;
            if (!counts[m.supplier_id]) counts[m.supplier_id] = { total: 0, active: 0, invoiced: 0, archived: 0, closed: 0 };
            counts[m.supplier_id].total++;
            const st = m.projects?.status;
            if (st === 'Live') counts[m.supplier_id].active++;
            else if (st === 'Invoiced') counts[m.supplier_id].invoiced++;
            else if (st === 'Archive') counts[m.supplier_id].archived++;
            else if (st === 'Closed') counts[m.supplier_id].closed++;
        });

        // Real total-traffic + total-completes per supplier — also
        // previously hardcoded to 0.
        const { data: trackingRows } = await supabaseAdmin
            .from('tracking_logs')
            .select('supplier_id, status')
            .not('supplier_id', 'is', null);

        const traffic = {};
        (trackingRows || []).forEach(t => {
            if (!traffic[t.supplier_id]) traffic[t.supplier_id] = { total: 0, complete: 0 };
            traffic[t.supplier_id].total++;
            if (t.status === 'Complete') traffic[t.supplier_id].complete++;
        });

        const enriched = data.map(s => ({
            ...s,
            projectCounts: counts[s.id] || { total: 0, active: 0, invoiced: 0, archived: 0, closed: 0 },
            trafficCounts: traffic[s.id] || { total: 0, complete: 0 },
        }));

        return { success: true, data: enriched };
    } catch (error) {
        console.error("Error fetching suppliers:", error);
        return { success: false, error: error.message };
    }
}

export async function createSupplier(formData) {
    try {
        await requireWriteAccess();
        const name = formData.get('name');
        const contact_email = formData.get('contact_email');
        const cpi_rate = formData.get('cpi_rate');
        const contact_person = formData.get('contact_person');
        const phone = formData.get('phone');
        const website = formData.get('website');
        const status = formData.get('status');
        const country = formData.get('country');
        const address = formData.get('address');
        const complete_url = formData.get('complete_url');
        const terminate_url = formData.get('terminate_url');
        const quotafull_url = formData.get('quotafull_url');
        const quality_url = formData.get('quality_url');
        const supplier_type = formData.get('supplier_type');
        const end_behavior = formData.get('end_behavior');
        const panel_size = formData.get('panel_size');
        const survey_close = formData.get('survey_close');
        const postback_url = formData.get('postback_url');

        if (!name) {
            return { success: false, error: "Name is required" };
        }

        const { data, error } = await supabaseAdmin
            .from('suppliers')
            .insert([{ 
                name, 
                contact_email: contact_email || null, 
                cpi_rate: cpi_rate ? parseFloat(cpi_rate) : null,
                contact_person: contact_person || null,
                phone: phone || null,
                website: website || null,
                status: status || 'Active',
                country: country || null,
                address: address || null,
                supplier_type: supplier_type || 'Static',
                end_behavior: end_behavior || 'redirect',
                complete_url: complete_url || null,
                terminate_url: terminate_url || null,
                quotafull_url: quotafull_url || null,
                quality_url: quality_url || null,
                panel_size: panel_size ? parseInt(panel_size, 10) : null,
                survey_close: survey_close || null,
                postback_url: postback_url || null
            }])
            .select()
            .single();

        if (error) throw error;

        revalidatePath('/suppliers');
        return { success: true, data };
    } catch (error) {
        console.error("Error creating supplier:", error);
        return { success: false, error: error.message };
    }
}

export async function deleteSupplier(id) {
    try {
        await requireSuperadmin();
        const { error } = await supabaseAdmin
            .from('suppliers')
            .delete()
            .eq('id', id);

        if (error) throw error;

        await logAudit('delete_supplier', `Supplier ID: ${id}`);

        revalidatePath('/suppliers');
        return { success: true };
    } catch (error) {
        console.error("Error deleting supplier:", error);
        return { success: false, error: error.message };
    }
}

export async function updateSupplier(id, updateData) {
    try {
        await requireWriteAccess();
        const { data, error } = await supabaseAdmin
            .from('suppliers')
            .update(updateData)
            .eq('id', id)
            .select()
            .single();

        if (error) throw error;

        revalidatePath('/suppliers');
        return { success: true, data };
    } catch (error) {
        console.error("Error updating supplier:", error);
        return { success: false, error: error.message };
    }
}

// ── S2S Inbound API Key ─────────────────────────────────────────
// Generates (or regenerates) the token this specific vendor's own
// server will use to authenticate against POST /api/s2s/status —
// i.e., this is the credential WE hand out when WE are acting as the
// client/hub and this vendor wants to report respondent status via
// server-to-server calls rather than a browser redirect.
export async function generateS2SKey(supplierId) {
    try {
        await requireWriteAccess();
        if (!supplierId) return { success: false, error: "Supplier ID is required" };

        // Genuinely random, URL-safe, long enough to not be practically
        // guessable — this token is a real credential, not a display code.
        // Uses Node's own crypto module (server-side), not the browser
        // Web Crypto API, since this runs as a server action.
        const { randomBytes } = await import('crypto');
        const key = 's2s_' + randomBytes(24).toString('hex');

        const { error } = await supabaseAdmin
            .from('suppliers')
            .update({ s2s_inbound_api_key: key })
            .eq('id', supplierId);

        if (error) throw error;

        revalidatePath(`/suppliers/${supplierId}`);
        return { success: true, key };
    } catch (error) {
        console.error("Error generating S2S key:", error);
        return { success: false, error: error.message };
    }
}
