"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { revalidatePath } from "next/cache";
import { requireWriteAccess, requireSuperadmin } from "@/utils/permissions";

export async function getTemplates(searchTerm) {
    try {
        let query = supabaseAdmin
            .from('prescreen_templates')
            .select('*')
            .order('created_at', { ascending: false });

        if (searchTerm) query = query.ilike('name', `%${searchTerm}%`);

        const { data, error } = await query;
        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error("Error fetching templates:", error);
        return { success: false, error: error.message };
    }
}

export async function createTemplate(name, questionIds) {
    try {
        await requireWriteAccess();
        if (!name) return { success: false, error: "Template name is required." };

        const { data, error } = await supabaseAdmin
            .from('prescreen_templates')
            .insert([{ name, question_ids: questionIds || [] }])
            .select()
            .single();

        if (error) throw error;
        revalidatePath('/library/prescreen-templates');
        return { success: true, data };
    } catch (error) {
        console.error("Error creating template:", error);
        return { success: false, error: error.message };
    }
}

export async function updateTemplateQuestions(id, questionIds) {
    try {
        await requireWriteAccess();
        const { error } = await supabaseAdmin
            .from('prescreen_templates')
            .update({ question_ids: questionIds || [] })
            .eq('id', id);

        if (error) throw error;
        revalidatePath('/library/prescreen-templates');
        return { success: true };
    } catch (error) {
        console.error("Error updating template:", error);
        return { success: false, error: error.message };
    }
}

export async function deleteTemplate(id) {
    try {
        await requireWriteAccess();
        const { error } = await supabaseAdmin
            .from('prescreen_templates')
            .delete()
            .eq('id', id);

        if (error) throw error;
        revalidatePath('/library/prescreen-templates');
        return { success: true };
    } catch (error) {
        console.error("Error deleting template:", error);
        return { success: false, error: error.message };
    }
}

// Fetches the full question objects for a template's question_ids
// (used by the "View" action to show what's inside a template).
export async function getTemplateQuestionDetails(questionIds) {
    try {
        if (!questionIds || questionIds.length === 0) return { success: true, data: [] };
        const { data, error } = await supabaseAdmin
            .from('question_library')
            .select('id, title, question_text, category')
            .in('id', questionIds);

        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error("Error fetching template question details:", error);
        return { success: false, error: error.message };
    }
}
