"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { revalidatePath } from "next/cache";
import { logAudit } from "@/utils/auditLog";
import { requireWriteAccess, requireSuperadmin } from "@/utils/permissions";

export async function getProjects() {
    try {
        const { data, error } = await supabaseAdmin
            .from('projects')
            .select(`
                *,
                clients ( name )
            `)
            .order('created_at', { ascending: false });

        if (error) throw error;

        // Fetch tracking logs for these projects to calculate stats
        // Use pagination to get ALL logs (avoid Supabase 1000-row default limit)
        const projectIds = data.map(p => p.id);
        let logsData = [];
        if (projectIds.length > 0) {
            let from = 0;
            const pageSize = 1000;
            while (true) {
                const { data: logs, error: logError } = await supabaseAdmin
                    .from('tracking_logs')
                    .select('project_id, status')
                    .in('project_id', projectIds)
                    .range(from, from + pageSize - 1);
                if (logError) break;
                if (!logs || logs.length === 0) break;
                logsData = logsData.concat(logs);
                if (logs.length < pageSize) break;
                from += pageSize;
            }
        }

        // Aggregate stats per project
        const projectsWithStats = data.map(project => {
            const projectLogs = logsData.filter(log => log.project_id === project.id);
            const stats = {
                clicks: projectLogs.length,
                completes: projectLogs.filter(l => l.status === 'Complete').length,
                terminates: projectLogs.filter(l => l.status === 'Terminate').length,
                overQuota: projectLogs.filter(l => l.status === 'OverQuota').length,
                securityFails: projectLogs.filter(l => l.status === 'SecurityFail').length,
                dropouts: projectLogs.filter(l => l.status === 'Started').length
            };
            return { ...project, stats };
        });

        return { success: true, data: projectsWithStats };
    } catch (error) {
        console.error("Error fetching projects:", error);
        return { success: false, error: error.message };
    }
}
export async function getProjectById(id) {
    try {
        const { data, error } = await supabaseAdmin
            .from('projects')
            .select(`
                *,
                clients ( name )
            `)
            .eq('id', id)
            .single();

        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error("Error fetching project by id:", error);
        return { success: false, error: error.message };
    }
}

export async function createProject(formData) {
    try {
        await requireWriteAccess();
        const title = formData.get('title');
        const client_id = formData.get('client_id');
        const status = formData.get('status') || 'Draft';
        const client_link = formData.get('client_link');
        const quota = formData.get('quota');
        const cpi = formData.get('cpi');
        
        // New comprehensive fields
        const project_manager = formData.get('project_manager');
        const country = formData.get('country');
        const language = formData.get('language');
        const category = formData.get('category');
        const description = formData.get('description');
        const loi = formData.get('loi');
        const ir = formData.get('ir');
        const sample_size = formData.get('sample_size');
        const currency = formData.get('currency');
        const supplier_cpi = formData.get('supplier_cpi');
        const start_date = formData.get('start_date');
        const end_date = formData.get('end_date');
        
        const client_complete_url = formData.get('client_complete_url');
        const client_terminate_url = formData.get('client_terminate_url');
        const client_quota_url = formData.get('client_quota_url');
        const client_quality_url = formData.get('client_quality_url');
        
        const parent_id = formData.get('parent_id');
        const encrypt_uid = formData.get('encrypt_uid');

        if (!title) {
            return { success: false, error: "Title is required" };
        }

        const { data, error } = await supabaseAdmin
            .from('projects')
            .insert([{ 
                title, 
                client_id: client_id || null,
                status,
                client_link: client_link || null,
                quota: quota ? parseInt(quota, 10) : 0,
                cpi: cpi ? parseFloat(cpi) : null,
                project_manager: project_manager || null,
                country: country || null,
                language: language || null,
                category: category || null,
                description: description || null,
                loi: loi ? parseInt(loi, 10) : null,
                ir: ir ? parseInt(ir, 10) : null,
                sample_size: sample_size ? parseInt(sample_size, 10) : null,
                currency: currency || null,
                supplier_cpi: supplier_cpi ? parseFloat(supplier_cpi) : null,
                start_date: start_date || null,
                end_date: end_date || null,
                client_complete_url: client_complete_url || null,
                client_terminate_url: client_terminate_url || null,
                client_quota_url: client_quota_url || null,
                client_quality_url: client_quality_url || null,
                parent_id: parent_id || null,
                encrypt_uid: encrypt_uid !== null ? encrypt_uid === 'true' : true
            }])
            .select()
            .single();

        if (error) throw error;

        // Clone supplier mappings if parent_id is present
        if (parent_id) {
            const { data: parentMappings, error: mappingsError } = await supabaseAdmin
                .from('project_supplier_mappings')
                .select('*')
                .eq('project_id', parent_id);

            if (!mappingsError && parentMappings && parentMappings.length > 0) {
                const parsedSupplierCpi = supplier_cpi ? parseFloat(supplier_cpi) : null;
                const newMappings = parentMappings.map(mapping => {
                    const { id, created_at, project_id, unique_code, cpi, ...rest } = mapping;
                    // Generate a new 5-character uppercase unique code
                    const newCode = Math.random().toString(36).substring(2, 7).toUpperCase();
                    return {
                        ...rest,
                        project_id: data.id,
                        unique_code: newCode,
                        cpi: parsedSupplierCpi !== null ? parsedSupplierCpi : cpi
                    };
                });
                
                await supabaseAdmin
                    .from('project_supplier_mappings')
                    .insert(newMappings);
            }
        }

        revalidatePath('/projects');
        return { success: true, data };
    } catch (error) {
        console.error("Error creating project:", error);
        return { success: false, error: error.message };
    }
}

export async function deleteProject(id) {
    try {
        await requireSuperadmin();
        const { error } = await supabaseAdmin
            .from('projects')
            .delete()
            .eq('id', id);

        if (error) throw error;

        await logAudit('delete_project', `Project ID: ${id}`);

        revalidatePath('/projects');
        return { success: true };
    } catch (error) {
        console.error("Error deleting project:", error);
        return { success: false, error: error.message };
    }
}

export async function updateProject(id, updateData) {
    try {
        await requireWriteAccess();
        const { data, error } = await supabaseAdmin
            .from('projects')
            .update(updateData)
            .eq('id', id)
            .select()
            .single();

        if (error) throw error;

        revalidatePath('/projects');
        return { success: true, data };
    } catch (error) {
        console.error("Error updating project:", error);
        return { success: false, error: error.message };
    }
}

export async function cloneProject(id) {
    try {
        await requireWriteAccess();
        // 1. Fetch the original project
        const { data: original, error: fetchError } = await supabaseAdmin
            .from('projects')
            .select('*')
            .eq('id', id)
            .single();

        if (fetchError) throw fetchError;

        // 2. Remove id and created_at, modify title
        const { id: _id, created_at: _ca, ...cloneData } = original;
        cloneData.title = 'Copy of ' + cloneData.title;
        cloneData.status = 'Draft';

        // 3. Insert the clone
        const { data, error } = await supabaseAdmin
            .from('projects')
            .insert([cloneData])
            .select()
            .single();

        if (error) throw error;

        revalidatePath('/projects');
        return { success: true, data };
    } catch (error) {
        console.error('Error cloning project:', error);
        return { success: false, error: error.message };
    }
}

export async function getProjectAndChildLinks(projectId) {
    try {
        const { data: projects, error: projectsError } = await supabaseAdmin
            .from('projects')
            .select('id, title, country')
            .or(`id.eq.${projectId},parent_id.eq.${projectId}`);
            
        if (projectsError) throw projectsError;
        if (!projects || projects.length === 0) return { success: true, data: [] };
        
        const projectIds = projects.map(p => p.id);
        
        const { data: mappings, error: mappingsError } = await supabaseAdmin
            .from('project_supplier_mappings')
            .select(`
                project_id,
                unique_code,
                suppliers ( name )
            `)
            .in('project_id', projectIds);
            
        if (mappingsError) throw mappingsError;
        
        const result = [];
        for (const mapping of mappings) {
            const proj = projects.find(p => p.id === mapping.project_id);
            result.push({
                projectName: proj.title,
                country: proj.country || 'N/A',
                supplierName: mapping.suppliers ? mapping.suppliers.name : 'Unknown',
                unique_code: mapping.unique_code
            });
        }
        
        return { success: true, data: result };
    } catch (error) {
        console.error("Error fetching links:", error);
        return { success: false, error: error.message };
    }
}
