"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { revalidatePath } from "next/cache";
import { requireWriteAccess, requireSuperadmin } from "@/utils/permissions";

export async function getReconcileRecords() {
    try {
        const { data, error } = await supabaseAdmin
            .from('reconcile_records')
            .select('*, projects ( title )')
            .order('created_at', { ascending: false });

        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error("Error fetching reconcile records:", error);
        return { success: false, error: error.message };
    }
}

export async function createReconcileRecord(formData) {
    try {
        await requireWriteAccess();
        const project_id = formData.get('project_id') || null;
        const client_name = formData.get('client_name');
        const period = formData.get('period');
        const we_sent = parseInt(formData.get('we_sent')) || 0;
        const our_completes = parseInt(formData.get('our_completes')) || 0;
        const client_accepted = parseInt(formData.get('client_accepted')) || 0;
        const client_rejected = parseInt(formData.get('client_rejected')) || 0;
        const reject_reason = formData.get('reject_reason');
        const cpi = parseFloat(formData.get('cpi')) || 0;
        const currency = formData.get('currency') || 'USD';
        const status = formData.get('status') || 'open';
        const notes = formData.get('notes');

        // Same formula as ExaVerify: difference = our_completes - client_accepted
        const difference = our_completes - client_accepted;
        const dispute_amount = difference * cpi;

        const { data, error } = await supabaseAdmin
            .from('reconcile_records')
            .insert([{
                project_id, client_name, period, we_sent, our_completes,
                client_accepted, client_rejected, reject_reason,
                difference, cpi, currency, dispute_amount, status, notes,
            }])
            .select()
            .single();

        if (error) throw error;

        revalidatePath('/reconciliation-billing');
        return { success: true, data };
    } catch (error) {
        console.error("Error creating reconcile record:", error);
        return { success: false, error: error.message };
    }
}

export async function updateReconcileStatus(id, status, notes) {
    try {
        await requireWriteAccess();
        const { error } = await supabaseAdmin
            .from('reconcile_records')
            .update({ status, notes })
            .eq('id', id);

        if (error) throw error;

        revalidatePath('/reconciliation-billing');
        return { success: true };
    } catch (error) {
        console.error("Error updating reconcile record:", error);
        return { success: false, error: error.message };
    }
}

export async function deleteReconcileRecord(id) {
    try {
        await requireSuperadmin();
        const { error } = await supabaseAdmin
            .from('reconcile_records')
            .delete()
            .eq('id', id);

        if (error) throw error;

        revalidatePath('/reconciliation-billing');
        return { success: true };
    } catch (error) {
        console.error("Error deleting reconcile record:", error);
        return { success: false, error: error.message };
    }
}

// ── CSV COMPARISON ────────────────────────────────────────────
// Takes the client/vendor's own completes-list (already parsed on the
// client side into [{uid, status}]) and compares it against our real
// tracking_logs for the given project — Matched / Mismatched / Missing.
export async function compareReconcileCsv(projectId, csvRows) {
    try {
        if (!projectId || !csvRows || csvRows.length === 0) {
            return { success: false, error: "Project and CSV data are required." };
        }

        const uids = csvRows.map(r => r.uid).filter(Boolean);
        const { data: ourLogs, error } = await supabaseAdmin
            .from('tracking_logs')
            .select('respondent_uid, status')
            .eq('project_id', projectId)
            .in('respondent_uid', uids);

        if (error) throw error;

        const ourStatusByUid = {};
        (ourLogs || []).forEach(l => { ourStatusByUid[l.respondent_uid] = l.status; });

        const result = csvRows.map(row => {
            const ourStatus = ourStatusByUid[row.uid];
            let matchResult;
            if (!ourStatus) {
                matchResult = 'Missing'; // client has it, we don't
            } else if (ourStatus.toLowerCase() === (row.status || '').toLowerCase()) {
                matchResult = 'Matched';
            } else {
                matchResult = 'Mismatched';
            }
            return { uid: row.uid, clientStatus: row.status, ourStatus: ourStatus || 'N/A', result: matchResult };
        });

        const summary = {
            matched: result.filter(r => r.result === 'Matched').length,
            mismatched: result.filter(r => r.result === 'Mismatched').length,
            missing: result.filter(r => r.result === 'Missing').length,
        };

        return { success: true, data: { rows: result, summary } };
    } catch (error) {
        console.error("Error comparing reconcile CSV:", error);
        return { success: false, error: error.message };
    }
}
