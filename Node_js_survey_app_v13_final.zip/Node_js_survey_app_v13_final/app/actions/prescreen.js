"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { revalidatePath } from "next/cache";
import { requireWriteAccess, requireSuperadmin } from "@/utils/permissions";

export async function getPreScreenQuestions(projectId) {
    try {
        const { data, error } = await supabaseAdmin
            .from('prescreen_questions')
            .select('*')
            .eq('project_id', projectId)
            .order('created_at', { ascending: true });

        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error("Error fetching prescreen questions:", error);
        return { success: false, error: error.message };
    }
}

export async function addPreScreenQuestion(formData) {
    try {
        await requireWriteAccess();
        const project_id = formData.get('project_id');
        const language = formData.get('language') || 'EN';
        const question_text = formData.get('question_text');
        const question_type = formData.get('question_type');

        if (!project_id || !question_text || !question_type) {
            return { success: false, error: "Missing required fields" };
        }

        const { data, error } = await supabaseAdmin
            .from('prescreen_questions')
            .insert([{ project_id, language, question_text, question_type }])
            .select()
            .single();

        if (error) throw error;

        revalidatePath(`/projects/${project_id}`);
        return { success: true, data };
    } catch (error) {
        console.error("Error adding prescreen question:", error);
        return { success: false, error: error.message };
    }
}

// ── SAVE RESPONDENT ANSWERS ──────────────────────────────────
// The respondent-facing prescreener page collects answers in the
// browser; this actually persists them (previously they were
// collected then silently discarded on submit).
export async function submitPrescreenAnswers(projectId, respondentUid, answers) {
    try {
        if (!projectId || !respondentUid || !answers) {
            return { success: false, error: "Missing required fields" };
        }

        const rows = Object.entries(answers).map(([questionId, answer]) => ({
            project_id: projectId,
            respondent_uid: respondentUid,
            question_id: questionId,
            answer: Array.isArray(answer) ? answer.join(', ') : String(answer ?? ''),
        }));

        if (rows.length === 0) return { success: true, data: [] };

        const { data, error } = await supabaseAdmin
            .from('prescreen_responses')
            .insert(rows)
            .select();

        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error("Error saving prescreen answers:", error);
        // Never block the respondent's survey flow because saving their
        // answers failed — log it and let them continue.
        return { success: false, error: error.message };
    }
}

export async function deletePreScreenQuestion(id, projectId) {
    try {
        await requireWriteAccess();
        const { error } = await supabaseAdmin
            .from('prescreen_questions')
            .delete()
            .eq('id', id);

        if (error) throw error;

        revalidatePath(`/projects/${projectId}`);
        return { success: true };
    } catch (error) {
        console.error("Error deleting prescreen question:", error);
        return { success: false, error: error.message };
    }
}

// ── Master, cross-project Screener-Responses view ────────────────
// Matches ExaVerify's "screener" tab — a filterable-by-project,
// exportable list of every prescreener answer ever given, not just
// per-project (which PreScreenTab already covers for QUESTIONS —
// this is for browsing/exporting the actual RESPONSES).
export async function getAllScreenerResponses(projectId = null) {
    try {
        let query = supabaseAdmin
            .from('prescreen_responses')
            .select('id, respondent_uid, question_text, answer, created_at, project_id, projects ( title, id )')
            .order('created_at', { ascending: false })
            .limit(2000);

        if (projectId) {
            query = query.eq('project_id', projectId);
        }

        const { data, error } = await query;
        if (error) throw error;
        return { success: true, data: data || [] };
    } catch (error) {
        console.error("Error fetching screener responses:", error);
        return { success: false, error: error.message };
    }
}
