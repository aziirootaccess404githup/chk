"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { revalidatePath } from "next/cache";
import { requireSuperadmin } from "@/utils/permissions";

export async function getSettings(keys) {
    try {
        const { data, error } = await supabaseAdmin
            .from('app_settings')
            .select('setting_key, setting_value')
            .in('setting_key', keys);
        if (error) throw error;

        const result = {};
        keys.forEach(k => { result[k] = ''; });
        (data || []).forEach(row => { result[row.setting_key] = row.setting_value || ''; });
        return { success: true, data: result };
    } catch (error) {
        console.error("Error fetching settings:", error);
        return { success: false, error: error.message };
    }
}

export async function saveSettings(settingsObj) {
    try {
        await requireSuperadmin();
        const rows = Object.entries(settingsObj).map(([setting_key, setting_value]) => ({
            setting_key,
            setting_value,
            updated_at: new Date().toISOString(),
        }));

        const { error } = await supabaseAdmin
            .from('app_settings')
            .upsert(rows, { onConflict: 'setting_key' });
        if (error) throw error;

        revalidatePath('/settings');
        return { success: true };
    } catch (error) {
        console.error("Error saving settings:", error);
        return { success: false, error: error.message };
    }
}
