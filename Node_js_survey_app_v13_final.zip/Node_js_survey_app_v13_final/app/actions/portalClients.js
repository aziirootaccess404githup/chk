"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { hashPassword, verifyPassword } from "@/utils/portalAuth";
import { cookies } from "next/headers";
import { revalidatePath } from "next/cache";
import { requireWriteAccess, requireSuperadmin } from "@/utils/permissions";

const SESSION_COOKIE = 'exz_portal_session';

// ── ADMIN SIDE: manage client portal accounts ──────────────────
export async function getPortalClients() {
    try {
        const { data, error } = await supabaseAdmin
            .from('portal_clients')
            .select('*, clients ( name )')
            .order('created_at', { ascending: false });

        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error("Error fetching portal clients:", error);
        return { success: false, error: error.message };
    }
}

export async function createPortalClient(formData) {
    try {
        await requireWriteAccess();
        const client_id = formData.get('client_id');
        const username = formData.get('username')?.trim();
        const password = formData.get('password');
        const extraProjectsRaw = formData.get('extra_project_ids') || '';

        if (!client_id || !username || !password) {
            return { success: false, error: "Client, username, and password are required." };
        }

        const extra_project_ids = extraProjectsRaw
            .split(',')
            .map(s => s.trim())
            .filter(Boolean);

        const { hash, salt } = hashPassword(password);

        const { data, error } = await supabaseAdmin
            .from('portal_clients')
            // upsert on username: same username = password & projects update
            .upsert([{
                client_id, username,
                password_hash: hash, password_salt: salt,
                extra_project_ids, status: 'active',
            }], { onConflict: 'username' })
            .select()
            .single();

        if (error) throw error;

        revalidatePath('/client-accounts');
        return { success: true, data };
    } catch (error) {
        console.error("Error creating portal client:", error);
        return { success: false, error: error.message };
    }
}

export async function togglePortalClientStatus(id, currentStatus) {
    try {
        await requireWriteAccess();
        const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
        const { error } = await supabaseAdmin
            .from('portal_clients')
            .update({ status: newStatus })
            .eq('id', id);

        if (error) throw error;
        revalidatePath('/client-accounts');
        return { success: true };
    } catch (error) {
        console.error("Error toggling portal client status:", error);
        return { success: false, error: error.message };
    }
}

export async function deletePortalClient(id) {
    try {
        await requireSuperadmin();
        const { error } = await supabaseAdmin
            .from('portal_clients')
            .delete()
            .eq('id', id);

        if (error) throw error;
        revalidatePath('/client-accounts');
        return { success: true };
    } catch (error) {
        console.error("Error deleting portal client:", error);
        return { success: false, error: error.message };
    }
}

// ── CLIENT SIDE: login / session / logout ───────────────────────
export async function portalClientLogin(username, password) {
    try {
        const { data: account, error } = await supabaseAdmin
            .from('portal_clients')
            .select('*')
            .eq('username', username)
            .maybeSingle();

        if (error) throw error;
        if (!account) return { success: false, error: "Invalid username or password." };
        if (account.status !== 'active') return { success: false, error: "This account is inactive." };

        const valid = verifyPassword(password, account.password_hash, account.password_salt);
        if (!valid) return { success: false, error: "Invalid username or password." };

        // Set an HTTP-only session cookie holding just the portal_clients row id.
        // Not a JWT — kept intentionally simple; the id is re-validated against
        // the DB (status check) on every portal page load.
        const cookieStore = await cookies();
        cookieStore.set(SESSION_COOKIE, account.id, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'lax',
            maxAge: 60 * 60 * 24 * 7, // 7 days
            path: '/',
        });

        await supabaseAdmin
            .from('portal_clients')
            .update({ last_login: new Date().toISOString() })
            .eq('id', account.id);

        return { success: true };
    } catch (error) {
        console.error("Error during portal client login:", error);
        return { success: false, error: "Login failed. Please try again." };
    }
}

export async function portalClientLogout() {
    const cookieStore = await cookies();
    cookieStore.delete(SESSION_COOKIE);
    return { success: true };
}

// Re-validates the session against the DB every time (so a deactivated
// account is locked out immediately, not just until cookie expiry).
export async function getPortalSession() {
    try {
        const cookieStore = await cookies();
        const sessionId = cookieStore.get(SESSION_COOKIE)?.value;
        if (!sessionId) return { success: false, error: "Not logged in." };

        const { data: account, error } = await supabaseAdmin
            .from('portal_clients')
            .select('id, client_id, username, status, extra_project_ids, clients ( name )')
            .eq('id', sessionId)
            .maybeSingle();

        if (error) throw error;
        if (!account || account.status !== 'active') {
            return { success: false, error: "Session invalid or account inactive." };
        }

        return { success: true, data: account };
    } catch (error) {
        console.error("Error validating portal session:", error);
        return { success: false, error: "Session check failed." };
    }
}

// ── CLIENT SIDE: read-only project data (privacy-safe) ──────────
// Never exposes pricing, vendor identity, fraud-detection details, or
// raw respondent identifiers — only aggregate counts + status.
export async function getPortalClientProjects() {
    try {
        const sessionResult = await getPortalSession();
        if (!sessionResult.success) return sessionResult;

        const { client_id, extra_project_ids } = sessionResult.data;

        let query = supabaseAdmin.from('projects').select('id, title, status, country, quota, start_date, end_date');
        const ids = extra_project_ids && extra_project_ids.length > 0 ? extra_project_ids : null;

        if (ids) {
            query = query.or(`client_id.eq.${client_id},id.in.(${ids.join(',')})`);
        } else {
            query = query.eq('client_id', client_id);
        }

        const { data: projects, error: projErr } = await query;
        if (projErr) throw projErr;
        if (!projects || projects.length === 0) return { success: true, data: [] };

        const projectIds = projects.map(p => p.id);
        const { data: logs, error: logsErr } = await supabaseAdmin
            .from('tracking_logs')
            .select('project_id, status')
            .in('project_id', projectIds);
        if (logsErr) throw logsErr;

        const result = projects.map(p => {
            const projLogs = (logs || []).filter(l => l.project_id === p.id);
            return {
                id: p.id,
                name: p.title,
                status: p.status,
                country: p.country || 'N/A',
                target: p.quota || 0,
                completed: projLogs.filter(l => l.status === 'Complete').length,
                terminated: projLogs.filter(l => l.status === 'Terminate').length,
                startDate: p.start_date,
                endDate: p.end_date,
            };
        });

        return { success: true, data: result };
    } catch (error) {
        console.error("Error fetching portal client projects:", error);
        return { success: false, error: error.message };
    }
}
