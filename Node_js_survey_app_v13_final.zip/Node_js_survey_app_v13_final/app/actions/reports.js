"use server";

import { supabaseAdmin } from "@/utils/supabase";

export async function getProjectStats(projectId) {
    try {
        const { data, error } = await supabaseAdmin
            .from('tracking_logs')
            .select('status')
            .eq('project_id', projectId);

        if (error) throw error;

        const stats = {
            completes: 0,
            terminates: 0,
            overQuota: 0,
            securityFails: 0,
            dropouts: 0,
            total: data.length
        };

        data.forEach(log => {
            if (log.status === 'Complete') stats.completes++;
            else if (log.status === 'Terminate') stats.terminates++;
            else if (log.status === 'OverQuota') stats.overQuota++;
            else if (log.status === 'SecurityFail') stats.securityFails++;
            else if (log.status === 'Started') stats.dropouts++;
        });

        return { success: true, data: stats };
    } catch (error) {
        console.error("Error fetching project stats:", error);
        return { success: false, error: error.message };
    }
}

// ── CLIENT REPORT ────────────────────────────────────────────
// For a client (matched by name search), lists every one of their
// projects with real Completed-vs-Target numbers from tracking_logs.
export async function getClientReport(clientSearch, fromDate, toDate) {
    try {
        if (!clientSearch) return { success: true, data: [] };

        const { data: clients, error: clientErr } = await supabaseAdmin
            .from('clients')
            .select('id, name')
            .ilike('name', `%${clientSearch}%`);
        if (clientErr) throw clientErr;
        if (!clients || clients.length === 0) return { success: true, data: [] };

        const clientIds = clients.map(c => c.id);
        const { data: projects, error: projErr } = await supabaseAdmin
            .from('projects')
            .select('id, title, country, quota')
            .in('client_id', clientIds);
        if (projErr) throw projErr;
        if (!projects || projects.length === 0) return { success: true, data: [] };

        const projectIds = projects.map(p => p.id);
        let logsQuery = supabaseAdmin
            .from('tracking_logs')
            .select('project_id, status, completed_at')
            .in('project_id', projectIds);
        if (fromDate) logsQuery = logsQuery.gte('completed_at', fromDate);
        if (toDate) logsQuery = logsQuery.lte('completed_at', `${toDate}T23:59:59`);
        const { data: logs, error: logsErr } = await logsQuery;
        if (logsErr) throw logsErr;

        const result = projects.map(p => {
            const projLogs = (logs || []).filter(l => l.project_id === p.id);
            return {
                id: p.id,
                code: 'PRJ-' + p.id.substring(0, 4).toUpperCase(),
                name: p.title,
                country: p.country || 'N/A',
                completed: projLogs.filter(l => l.status === 'Complete').length,
                target: p.quota || 0,
            };
        });

        return { success: true, data: result };
    } catch (error) {
        console.error("Error fetching client report:", error);
        return { success: false, error: error.message };
    }
}

// ── SUPPLIER REPORT ──────────────────────────────────────────
// For a supplier (matched by name search), lists every project they're
// mapped to with real Completed-vs-Allocation numbers from tracking_logs.
export async function getSupplierReport(supplierSearch, fromDate, toDate) {
    try {
        if (!supplierSearch) return { success: true, data: [] };

        const { data: suppliers, error: supErr } = await supabaseAdmin
            .from('suppliers')
            .select('id, name')
            .ilike('name', `%${supplierSearch}%`);
        if (supErr) throw supErr;
        if (!suppliers || suppliers.length === 0) return { success: true, data: [] };

        const supplierIds = suppliers.map(s => s.id);
        const { data: mappings, error: mapErr } = await supabaseAdmin
            .from('project_supplier_mappings')
            .select(`
                project_id,
                supplier_id,
                allocation,
                projects ( title, country )
            `)
            .in('supplier_id', supplierIds);
        if (mapErr) throw mapErr;
        if (!mappings || mappings.length === 0) return { success: true, data: [] };

        const projectIds = [...new Set(mappings.map(m => m.project_id))];
        let logsQuery = supabaseAdmin
            .from('tracking_logs')
            .select('project_id, supplier_id, status, completed_at')
            .in('project_id', projectIds)
            .in('supplier_id', supplierIds);
        if (fromDate) logsQuery = logsQuery.gte('completed_at', fromDate);
        if (toDate) logsQuery = logsQuery.lte('completed_at', `${toDate}T23:59:59`);
        const { data: logs, error: logsErr } = await logsQuery;
        if (logsErr) throw logsErr;

        const result = mappings.map(m => {
            const relevantLogs = (logs || []).filter(
                l => l.project_id === m.project_id && l.supplier_id === m.supplier_id
            );
            return {
                id: `${m.project_id}-${m.supplier_id}`,
                projectId: m.project_id,
                code: 'PRJ-' + m.project_id.substring(0, 4).toUpperCase(),
                name: m.projects?.title || 'Unknown',
                country: m.projects?.country || 'N/A',
                completed: relevantLogs.filter(l => l.status === 'Complete').length,
                target: m.allocation || 0,
            };
        });

        return { success: true, data: result };
    } catch (error) {
        console.error("Error fetching supplier report:", error);
        return { success: false, error: error.message };
    }
}

// ── PM ACTIVITY REPORT ───────────────────────────────────────
// NOTE: project_activities has no per-user or status column in the real
// schema (only project_id, date, activity, sub_activity, duration).
// So this uses the project's Project Manager field (the closest real
// "who" data) and shows Sub-Activity instead of a fabricated status badge.
export async function getPMActivityReport(projectSearch, fromDate, toDate) {
    try {
        if (!projectSearch) return { success: true, data: [] };

        const { data: projects, error: projErr } = await supabaseAdmin
            .from('projects')
            .select('id, title, project_manager')
            .ilike('title', `%${projectSearch}%`);
        if (projErr) throw projErr;
        if (!projects || projects.length === 0) return { success: true, data: [] };

        const projectIds = projects.map(p => p.id);
        let query = supabaseAdmin
            .from('project_activities')
            .select('id, project_id, date, activity, sub_activity, duration')
            .in('project_id', projectIds)
            .order('date', { ascending: false });
        if (fromDate) query = query.gte('date', fromDate);
        if (toDate) query = query.lte('date', toDate);
        const { data: activities, error: actErr } = await query;
        if (actErr) throw actErr;

        const projectMap = Object.fromEntries(projects.map(p => [p.id, p]));
        const result = (activities || []).map(a => ({
            id: a.id,
            projectManager: projectMap[a.project_id]?.project_manager || 'Unassigned',
            activity: a.activity,
            subActivity: a.sub_activity || '-',
            date: a.date,
            duration: a.duration,
        }));

        return { success: true, data: result };
    } catch (error) {
        console.error("Error fetching PM activity report:", error);
        return { success: false, error: error.message };
    }
}

// ── GROUP REPORT ──────────────────────────────────────────────
// Groups multiple projects together (by Client, Country, or Category)
// and shows their Completed-vs-Target side by side, with an overall
// aggregate total — this is what "grouping" means with our real data
// (we don't store individual survey answers, only routing/completion
// data, so this is a project-rollup, not a Yes/No answer breakdown).
export async function getGroupReport(groupBy, groupValue, fromDate, toDate) {
    try {
        if (!groupBy || !groupValue) return { success: true, data: [] };

        let projectQuery = supabaseAdmin
            .from('projects')
            .select('id, title, country, quota, client_id, category');

        if (groupBy === 'client') {
            const { data: clients, error: clientErr } = await supabaseAdmin
                .from('clients')
                .select('id')
                .ilike('name', `%${groupValue}%`);
            if (clientErr) throw clientErr;
            const clientIds = (clients || []).map(c => c.id);
            if (clientIds.length === 0) return { success: true, data: [] };
            projectQuery = projectQuery.in('client_id', clientIds);
        } else if (groupBy === 'country') {
            projectQuery = projectQuery.ilike('country', `%${groupValue}%`);
        } else if (groupBy === 'category') {
            projectQuery = projectQuery.ilike('category', `%${groupValue}%`);
        }

        const { data: projects, error: projErr } = await projectQuery;
        if (projErr) throw projErr;
        if (!projects || projects.length === 0) return { success: true, data: [] };

        const projectIds = projects.map(p => p.id);
        let logsQuery = supabaseAdmin
            .from('tracking_logs')
            .select('project_id, status, completed_at')
            .in('project_id', projectIds);
        if (fromDate) logsQuery = logsQuery.gte('completed_at', fromDate);
        if (toDate) logsQuery = logsQuery.lte('completed_at', `${toDate}T23:59:59`);
        const { data: logs, error: logsErr } = await logsQuery;
        if (logsErr) throw logsErr;

        const result = projects.map(p => {
            const projLogs = (logs || []).filter(l => l.project_id === p.id);
            return {
                id: p.id,
                code: 'PRJ-' + p.id.substring(0, 4).toUpperCase(),
                name: p.title,
                country: p.country || 'N/A',
                completed: projLogs.filter(l => l.status === 'Complete').length,
                target: p.quota || 0,
            };
        });

        return { success: true, data: result };
    } catch (error) {
        console.error("Error fetching group report:", error);
        return { success: false, error: error.message };
    }
}

// ── TSIGN (TREND & SIGNAL) REPORT ────────────────────────────
// "TSign" = Trend/Signal — a day-by-day breakdown of fraud-detection
// signals (speeder-rate, duplicate-rate, avg quality-score) so a PM can
// spot anomalous days at a glance. Flags a day as a "Signal" when
// speeder-rate or duplicate-rate exceeds 30%, or avg quality drops below 60.
export async function getTSignReport(fromDate, toDate, projectSearch) {
    try {
        let projectIds = null;
        if (projectSearch) {
            const { data: projects, error: projErr } = await supabaseAdmin
                .from('projects')
                .select('id')
                .ilike('title', `%${projectSearch}%`);
            if (projErr) throw projErr;
            projectIds = (projects || []).map(p => p.id);
            if (projectIds.length === 0) return { success: true, data: [] };
        }

        let query = supabaseAdmin
            .from('tracking_logs')
            .select('started_at, status, is_speeder, is_duplicate, same_ip_flag, quality_score');
        if (projectIds) query = query.in('project_id', projectIds);
        if (fromDate) query = query.gte('started_at', fromDate);
        if (toDate) query = query.lte('started_at', `${toDate}T23:59:59`);

        const { data: logs, error } = await query;
        if (error) throw error;

        const byDate = {};
        (logs || []).forEach(l => {
            const date = l.started_at ? l.started_at.substring(0, 10) : 'Unknown';
            if (!byDate[date]) {
                byDate[date] = { date, total: 0, completes: 0, speeders: 0, duplicates: 0, sameIp: 0, scoreSum: 0, scoreCount: 0 };
            }
            byDate[date].total++;
            if (l.status === 'Complete') byDate[date].completes++;
            if (l.is_speeder) byDate[date].speeders++;
            if (l.is_duplicate) byDate[date].duplicates++;
            if (l.same_ip_flag) byDate[date].sameIp++;
            if (l.quality_score !== null && l.quality_score !== undefined) {
                byDate[date].scoreSum += l.quality_score;
                byDate[date].scoreCount++;
            }
        });

        const result = Object.values(byDate)
            .sort((a, b) => b.date.localeCompare(a.date))
            .map(d => {
                const speederRate = d.total > 0 ? d.speeders / d.total : 0;
                const duplicateRate = d.total > 0 ? d.duplicates / d.total : 0;
                const avgScore = d.scoreCount > 0 ? Math.round(d.scoreSum / d.scoreCount) : null;
                const isSignal = speederRate > 0.3 || duplicateRate > 0.3 || (avgScore !== null && avgScore < 60);
                return {
                    ...d,
                    speederRate: Math.round(speederRate * 100),
                    duplicateRate: Math.round(duplicateRate * 100),
                    avgScore,
                    isSignal,
                };
            });

        return { success: true, data: result };
    } catch (error) {
        console.error("Error fetching TSign report:", error);
        return { success: false, error: error.message };
    }
}

export async function exportProjectLogs(projectId) {
    try {
        const { data, error } = await supabaseAdmin
            .from('tracking_logs')
            .select(`
                *,
                suppliers ( name )
            `)
            .eq('project_id', projectId)
            .order('started_at', { ascending: false });

        if (error) throw error;
        
        // Return raw data so the client can convert it to CSV and download
        return { success: true, data };
    } catch (error) {
        console.error("Error exporting project logs:", error);
        return { success: false, error: error.message };
    }
}

// ── Vendor Breakdown (per-project) ────────────────────────────
// Matches Kishan's panel's "Vendor Breakdown" table — every vendor
// working on this specific project, with clicks/completes/terminates/
// security-fails/overquota + conversion%, in one place, without
// needing to open the Suppliers list separately.
export async function getVendorBreakdownForProject(projectId) {
    try {
        const { data, error } = await supabaseAdmin
            .from('tracking_logs')
            .select('status, supplier_id, suppliers ( id, name )')
            .eq('project_id', projectId);

        if (error) throw error;

        const grouped = {};
        data.forEach(log => {
            const key = log.supplier_id || 'direct';
            if (!grouped[key]) {
                grouped[key] = {
                    vendorId: log.supplier_id,
                    vendorName: log.suppliers?.name || 'No Vendor / Direct',
                    clicks: 0, completes: 0, terminates: 0, securityFails: 0, overQuota: 0,
                };
            }
            grouped[key].clicks++;
            if (log.status === 'Complete') grouped[key].completes++;
            else if (log.status === 'Terminate') grouped[key].terminates++;
            else if (log.status === 'SecurityFail') grouped[key].securityFails++;
            else if (log.status === 'OverQuota') grouped[key].overQuota++;
        });

        const result = Object.values(grouped)
            .map(v => ({ ...v, convPct: v.clicks > 0 ? Math.round((v.completes / v.clicks) * 1000) / 10 : 0 }))
            .sort((a, b) => b.clicks - a.clicks);

        return { success: true, data: result };
    } catch (error) {
        console.error("Error fetching vendor breakdown:", error);
        return { success: false, error: error.message };
    }
}

// ── Vendor × Project Matrix (grid view) ────────────────────────
// Matches Kishan's panel's new Matrix page — every vendor's
// clicks/completes per project, in one grid, instead of opening
// each Vendor or Project page separately.
export async function getVendorProjectMatrix() {
    try {
        const { data: suppliers, error: sErr } = await supabaseAdmin
            .from('suppliers').select('id, name').order('name');
        if (sErr) throw sErr;

        const { data: projects, error: pErr } = await supabaseAdmin
            .from('projects').select('id, title').order('created_at', { ascending: false }).limit(30);
        if (pErr) throw pErr;

        const { data: logs, error: lErr } = await supabaseAdmin
            .from('tracking_logs')
            .select('supplier_id, project_id, status')
            .not('supplier_id', 'is', null);
        if (lErr) throw lErr;

        const { data: mappings } = await supabaseAdmin
            .from('project_supplier_mappings')
            .select('supplier_id, project_id, allow_traffic');

        const cells = {};
        logs.forEach(log => {
            const key = `${log.supplier_id}_${log.project_id}`;
            if (!cells[key]) cells[key] = { clicks: 0, completes: 0 };
            cells[key].clicks++;
            if (log.status === 'Complete') cells[key].completes++;
        });
        (mappings || []).forEach(m => {
            const key = `${m.supplier_id}_${m.project_id}`;
            if (cells[key]) cells[key].paused = m.allow_traffic === false;
        });

        return { success: true, data: { suppliers, projects, cells } };
    } catch (error) {
        console.error("Error fetching vendor-project matrix:", error);
        return { success: false, error: error.message };
    }
}
