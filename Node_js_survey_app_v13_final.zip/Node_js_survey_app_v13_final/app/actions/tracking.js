"use server";

import { supabaseAdmin } from "@/utils/supabase";

// Server-side pagination added — previously this always loaded a flat
// 5000-row cap into the browser and filtered entirely client-side.
// Genuinely fine for most projects, but once total tracking_logs passed
// 5000, older records became invisible in this view even though the
// data was safe in the database (same root-issue fixed on ExaVerify's
// Response Log this round). The instant client-side filter/search on
// the page is left exactly as-is — it now filters within whichever
// page is currently loaded.
export async function getTrackingLogs(page = 1, pageSize = 500) {
    try {
        const from = (page - 1) * pageSize;
        const to = from + pageSize - 1;

        const { count } = await supabaseAdmin
            .from('tracking_logs')
            .select('*', { count: 'exact', head: true });

        const { data, error } = await supabaseAdmin
            .from('tracking_logs')
            .select(`
                *,
                projects ( title, cpi, clients ( name ) ),
                suppliers ( name )
            `)
            .order('started_at', { ascending: false })
            .range(from, to);

        if (error) throw error;
        return { success: true, data, total: count || 0, page, pageSize };
    } catch (error) {
        console.error('Error fetching tracking logs:', error);
        return { success: false, error: error.message };
    }
}
