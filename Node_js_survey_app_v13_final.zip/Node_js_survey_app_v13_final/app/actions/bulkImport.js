"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { revalidatePath } from "next/cache";
import { logAudit } from "@/utils/auditLog";
import { requireWriteAccess } from "@/utils/permissions";

// ── BULK PROJECT IMPORT (CSV) ──────────────────────────────────
// Lets a manager create many projects in one go from a CSV, instead of
// filling the Add Project form individually for each one — genuinely
// useful when a client sends a batch of surveys at once (e.g. several
// projects in a single WhatsApp/email brief). Matches the same
// title/client_link/cpi/quota fields as the single-project form
// (createProject in projects.js), and optionally creates a
// project_supplier_mapping too (with an auto-generated unique_code,
// same 5-char random format as addMapping in mappings.js) if a
// supplier_name column is present, so the entry-link becomes usable
// immediately rather than needing a second manual step.
export async function bulkImportProjects(csvText) {
    try {
        await requireWriteAccess();

        const results = { created: 0, updated: 0, mapped: 0, errors: [] };

        const lines = csvText.split(/\r?\n/).filter(l => l.trim() !== '');
        if (lines.length < 2) {
            return { success: false, error: "CSV needs a header row plus at least one data row." };
        }

        // Simple CSV-line parser that handles quoted fields containing commas
        function parseCsvLine(line) {
            const out = [];
            let cur = '';
            let inQuotes = false;
            for (let i = 0; i < line.length; i++) {
                const ch = line[i];
                if (inQuotes) {
                    if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; }
                    else if (ch === '"') { inQuotes = false; }
                    else { cur += ch; }
                } else {
                    if (ch === '"') { inQuotes = true; }
                    else if (ch === ',') { out.push(cur); cur = ''; }
                    else { cur += ch; }
                }
            }
            out.push(cur);
            return out.map(s => s.trim());
        }

        const header = parseCsvLine(lines[0]).map(h => h.toLowerCase());
        const colIndex = {};
        header.forEach((h, i) => { colIndex[h] = i; });

        const get = (row, key) => (colIndex[key] !== undefined && row[colIndex[key]] !== undefined) ? row[colIndex[key]] : '';

        // Cache client/supplier name → id lookups within this single import,
        // so re-referencing the same client/supplier across many rows in the
        // same file doesn't hit the database repeatedly.
        const clientCache = {};
        const supplierCache = {};

        async function getOrCreateClientId(name) {
            if (!name) return null;
            if (clientCache[name]) return clientCache[name];
            const { data: existing } = await supabaseAdmin.from('clients').select('id').eq('name', name).limit(1).single();
            if (existing) { clientCache[name] = existing.id; return existing.id; }
            const { data: created, error } = await supabaseAdmin.from('clients').insert([{ name, status: 'Active' }]).select('id').single();
            if (error) throw error;
            clientCache[name] = created.id;
            return created.id;
        }

        async function getOrCreateSupplierId(name) {
            if (!name) return null;
            if (supplierCache[name]) return supplierCache[name];
            const { data: existing } = await supabaseAdmin.from('suppliers').select('id').eq('name', name).limit(1).single();
            if (existing) { supplierCache[name] = existing.id; return existing.id; }
            const { data: created, error } = await supabaseAdmin.from('suppliers').insert([{ name, status: 'Active' }]).select('id').single();
            if (error) throw error;
            supplierCache[name] = created.id;
            return created.id;
        }

        for (let i = 1; i < lines.length; i++) {
            const rowNum = i + 1;
            const row = parseCsvLine(lines[i]);
            const title = get(row, 'title');
            if (!title) continue; // skip genuinely blank rows

            try {
                const client_name = get(row, 'client_name');
                const client_link = get(row, 'client_link');
                const cpi = get(row, 'cpi');
                const quota = get(row, 'quota');
                const supplier_name = get(row, 'supplier_name');

                const client_id = await getOrCreateClientId(client_name);

                // Check for an existing project with the exact same title —
                // used as the "same row re-imported" signal, since projects
                // in this schema are identified by title, not a client-given
                // SID code the way ExaVerify/Azilytics are.
                const { data: existingProject } = await supabaseAdmin
                    .from('projects').select('id').eq('title', title).limit(1).single();

                let projectId;
                if (existingProject) {
                    const { error: updateErr } = await supabaseAdmin
                        .from('projects')
                        .update({
                            client_id,
                            client_link: client_link || null,
                            cpi: cpi ? parseFloat(cpi) : null,
                            quota: quota ? parseInt(quota, 10) : 0,
                        })
                        .eq('id', existingProject.id);
                    if (updateErr) throw updateErr;
                    projectId = existingProject.id;
                    results.updated++;
                } else {
                    const { data: newProject, error: insertErr } = await supabaseAdmin
                        .from('projects')
                        .insert([{
                            title,
                            client_id,
                            client_link: client_link || null,
                            cpi: cpi ? parseFloat(cpi) : null,
                            quota: quota ? parseInt(quota, 10) : 0,
                            status: 'Live',
                            encrypt_uid: true,
                        }])
                        .select('id')
                        .single();
                    if (insertErr) throw insertErr;
                    projectId = newProject.id;
                    results.created++;
                }

                // Optional: create the project-supplier mapping too, so an
                // entry-link exists immediately (this schema requires a
                // mapping to exist before any entry-link is usable at all).
                if (supplier_name) {
                    const supplier_id = await getOrCreateSupplierId(supplier_name);
                    const { data: existingMapping } = await supabaseAdmin
                        .from('project_supplier_mappings')
                        .select('id').eq('project_id', projectId).eq('supplier_id', supplier_id).limit(1).single();
                    if (!existingMapping) {
                        const { error: mapErr } = await supabaseAdmin
                            .from('project_supplier_mappings')
                            .insert([{
                                project_id: projectId,
                                supplier_id,
                                unique_code: Math.random().toString(36).substring(2, 7).toUpperCase(),
                                cpi: cpi ? parseFloat(cpi) : null,
                                allow_traffic: true,
                            }]);
                        if (mapErr) throw mapErr;
                        results.mapped++;
                    }
                }
            } catch (rowError) {
                results.errors.push(`Row ${rowNum} (${title}): ${rowError.message}`);
            }
        }

        await logAudit('bulk_import_projects', `Created: ${results.created}, Updated: ${results.updated}, Mapped: ${results.mapped}, Errors: ${results.errors.length}`);
        revalidatePath('/projects');

        return { success: true, results };
    } catch (error) {
        console.error("Error in bulk project import:", error);
        return { success: false, error: error.message };
    }
}
