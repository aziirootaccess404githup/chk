"use client";
import React, { useState, useEffect } from 'react';
import { getSettings, saveSettings } from '@/app/actions/settings';

export default function Settings() {
    const [botToken, setBotToken] = useState('');
    const [chatId, setChatId] = useState('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [message, setMessage] = useState(null);

    useEffect(() => {
        async function load() {
            const result = await getSettings(['telegram_bot_token', 'telegram_chat_id']);
            if (result.success) {
                setBotToken(result.data.telegram_bot_token);
                setChatId(result.data.telegram_chat_id);
            }
            setLoading(false);
        }
        load();
    }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage(null);
        setSaving(true);
        const result = await saveSettings({
            telegram_bot_token: botToken,
            telegram_chat_id: chatId,
        });
        setSaving(false);
        if (result.error) {
            setMessage({ type: 'danger', text: result.error });
        } else {
            setMessage({ type: 'success', text: 'Settings saved!' });
        }
    };

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><a href="/">Home</a></li>
                            <li className="breadcrumb-item active">Settings</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">🔔 Alert Settings</h4>
                </div>
            </div>

            <div className="col-sm-12 col-md-7">
                <div className="card">
                    <div className="card-body">
                        <p className="text-muted mb-3">Configure the Telegram bot used for quota-reached and other automated alerts. These values take priority over the TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID environment-variables if set here — leave blank to keep using the environment-variable values instead.</p>
                        {loading ? (
                            <p className="text-muted">Loading...</p>
                        ) : (
                        <form onSubmit={handleSubmit}>
                            <div className="form-group">
                                <label>Telegram Bot Token</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    value={botToken}
                                    onChange={(e) => setBotToken(e.target.value)}
                                    placeholder="e.g. 123456789:ABCdefGhIJKlmNoPQRstuVwxyZ"
                                />
                            </div>
                            <div className="form-group">
                                <label>Telegram Chat ID</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    value={chatId}
                                    onChange={(e) => setChatId(e.target.value)}
                                    placeholder="e.g. -1001234567890"
                                />
                            </div>

                            {message && (
                                <div className={`alert alert-${message.type}`}>{message.text}</div>
                            )}

                            <button type="submit" className="btn btn-primary" disabled={saving}>
                                {saving ? 'Saving...' : 'Save Settings'}
                            </button>
                        </form>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
