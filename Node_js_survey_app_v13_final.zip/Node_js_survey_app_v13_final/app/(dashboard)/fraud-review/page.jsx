"use client";
import React, { useState, useEffect } from 'react';
import { getFraudReview } from '@/app/actions/fraudReview';
import { getProjects } from '@/app/actions/projects';

export default function FraudReview() {
    const [projects, setProjects] = useState([]);
    const [selectedProject, setSelectedProject] = useState("");
    const [minScore, setMinScore] = useState(0);
    const [maxScore, setMaxScore] = useState(100);
    const [flaggedOnly, setFlaggedOnly] = useState(true);
    const [rows, setRows] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        async function fetchProjects() {
            const res = await getProjects();
            if (res.success) setProjects(res.data);
        }
        fetchProjects();
        handleLoad();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleLoad = async () => {
        setLoading(true);
        const result = await getFraudReview({
            projectId: selectedProject || null,
            minScore: Number(minScore),
            maxScore: Number(maxScore),
            flaggedOnly,
        });
        setLoading(false);
        if (result.success) {
            setRows(result.data);
        } else {
            alert("Error loading fraud review: " + result.error);
        }
    };

    const flagBadge = (row) => {
        const flags = [];
        if (row.is_speeder) flags.push(<span key="s" className="badge badge-danger mr-1">Speeder</span>);
        if (row.is_duplicate) flags.push(<span key="d" className="badge badge-warning mr-1">Duplicate</span>);
        if (row.same_ip_flag) flags.push(<span key="i" className="badge badge-info mr-1">Same-IP</span>);
        if (flags.length === 0) return <span className="badge badge-success">Clean</span>;
        return flags;
    };

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><a href="/">Home</a></li>
                            <li className="breadcrumb-item active">Fraud & Quality Review</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">⚡ Fraud & Quality Review</h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <p className="text-muted mb-3">Browse respondents by quality-score range, or toggle &quot;Flagged only&quot; to see just Speeders / Duplicates / Same-IP hits — across one project or all of them.</p>

                        <div className="row mb-3" style={{ alignItems: 'flex-end' }}>
                            <div className="col-md-3">
                                <label className="mb-1">Project</label>
                                <select className="form-control" value={selectedProject} onChange={(e) => setSelectedProject(e.target.value)}>
                                    <option value="">All Projects</option>
                                    {projects.map(p => (
                                        <option key={p.id} value={p.id}>{p.title}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-md-2">
                                <label className="mb-1">Min Score</label>
                                <input type="number" className="form-control" min="0" max="100" value={minScore} onChange={(e) => setMinScore(e.target.value)} />
                            </div>
                            <div className="col-md-2">
                                <label className="mb-1">Max Score</label>
                                <input type="number" className="form-control" min="0" max="100" value={maxScore} onChange={(e) => setMaxScore(e.target.value)} />
                            </div>
                            <div className="col-md-3">
                                <div className="custom-control custom-checkbox mb-2">
                                    <input type="checkbox" className="custom-control-input" id="flaggedOnly" checked={flaggedOnly} onChange={(e) => setFlaggedOnly(e.target.checked)} />
                                    <label className="custom-control-label" htmlFor="flaggedOnly">Flagged only (Speeder/Duplicate/Same-IP)</label>
                                </div>
                            </div>
                            <div className="col-md-2">
                                <button className="btn btn-primary w-100" onClick={handleLoad}>Filter</button>
                            </div>
                        </div>

                        {loading ? (
                            <p className="text-center text-muted">Loading...</p>
                        ) : (
                            <div className="table-responsive">
                                <table className="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>UID</th>
                                            <th>Project</th>
                                            <th>Vendor</th>
                                            <th>Status</th>
                                            <th>LOI</th>
                                            <th>Score</th>
                                            <th>Flags</th>
                                            <th>Reasons</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {rows.length === 0 ? (
                                            <tr><td colSpan="9" className="text-center text-muted">No matching respondents.</td></tr>
                                        ) : (
                                            rows.map(r => (
                                                <tr key={r.id}>
                                                    <td style={{ fontFamily: 'monospace', fontSize: '12px' }}>{r.respondent_uid}</td>
                                                    <td>{r.projects?.title || '—'}</td>
                                                    <td>{r.suppliers?.name || 'Direct'}</td>
                                                    <td>{r.status}</td>
                                                    <td>{r.loi_seconds ? `${Math.floor(r.loi_seconds / 60)}m ${r.loi_seconds % 60}s` : '—'}</td>
                                                    <td><strong>{r.quality_score}</strong></td>
                                                    <td>{flagBadge(r)}</td>
                                                    <td style={{ fontSize: '11px' }}>{r.score_reasons || '—'}</td>
                                                    <td className="text-muted">{new Date(r.started_at).toLocaleString()}</td>
                                                </tr>
                                            ))
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
