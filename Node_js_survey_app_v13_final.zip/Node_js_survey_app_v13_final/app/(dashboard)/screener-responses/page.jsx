"use client";
import React, { useState, useEffect } from 'react';
import { getAllScreenerResponses } from '@/app/actions/prescreen';
import { getProjects } from '@/app/actions/projects';

export default function ScreenerResponses() {
    const [projects, setProjects] = useState([]);
    const [selectedProject, setSelectedProject] = useState("");
    const [responses, setResponses] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        async function fetchProjects() {
            const res = await getProjects();
            if (res.success) setProjects(res.data);
        }
        fetchProjects();
        handleLoad("");
    }, []);

    const handleLoad = async (projectId) => {
        setLoading(true);
        const result = await getAllScreenerResponses(projectId || null);
        setLoading(false);
        if (result.success) {
            setResponses(result.data);
        } else {
            alert("Error loading screener responses: " + result.error);
        }
    };

    const handleFilterChange = (e) => {
        const val = e.target.value;
        setSelectedProject(val);
        handleLoad(val);
    };

    const handleDownload = () => {
        if (responses.length === 0) return;
        const headers = ["Respondent UID", "Project", "Question", "Answer", "Submitted At"];
        const rows = responses.map(r => [
            r.respondent_uid,
            r.projects?.title || '—',
            r.question_text || '—',
            r.answer || '—',
            new Date(r.created_at).toLocaleString(),
        ]);
        const csvContent = [headers, ...rows]
            .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(","))
            .join("\n");
        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = `screener-responses-${Date.now()}.csv`;
        link.click();
    };

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><a href="/">Home</a></li>
                            <li className="breadcrumb-item active">Screener Responses</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Screener Responses</h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <p className="text-muted mb-3">Every prescreener answer, across all projects — filterable by project, exportable as CSV. (Per-project question management is on each Project's own PreScreen tab — this is for browsing/exporting the respondent-given ANSWERS.)</p>
                        <div className="d-flex justify-content-between mb-3" style={{ gap: '10px', flexWrap: 'wrap' }}>
                            <select className="form-control" style={{ maxWidth: '320px' }} value={selectedProject} onChange={handleFilterChange}>
                                <option value="">All Projects</option>
                                {projects.map(p => (
                                    <option key={p.id} value={p.id}>{p.title}</option>
                                ))}
                            </select>
                            <button className="btn btn-success" onClick={handleDownload} disabled={responses.length === 0}>
                                <i className="fa fa-download" aria-hidden="true"></i> Export CSV
                            </button>
                        </div>

                        {loading ? (
                            <p className="text-center text-muted">Loading...</p>
                        ) : (
                            <div className="table-responsive">
                                <table className="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Respondent UID</th>
                                            <th>Project</th>
                                            <th>Question</th>
                                            <th>Answer</th>
                                            <th>Submitted At</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {responses.length === 0 ? (
                                            <tr><td colSpan="5" className="text-center text-muted">No screener responses yet.</td></tr>
                                        ) : (
                                            responses.map(r => (
                                                <tr key={r.id}>
                                                    <td style={{ fontFamily: 'monospace', fontSize: '12px' }}>{r.respondent_uid}</td>
                                                    <td>{r.projects?.title || '—'}</td>
                                                    <td>{r.question_text || '—'}</td>
                                                    <td>{r.answer || '—'}</td>
                                                    <td className="text-muted">{new Date(r.created_at).toLocaleString()}</td>
                                                </tr>
                                            ))
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
