"use client";
import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { getTrackingLogs } from '@/app/actions/tracking';
import { getSuppliers } from '@/app/actions/suppliers';

export default function RedirectStatus() {
    const searchParams = useSearchParams();
    const [logs, setLogs] = useState([]);
    const [logPage, setLogPage] = useState(1);
    const [logPageSize, setLogPageSize] = useState(500);
    const [logTotal, setLogTotal] = useState(0);
    const [loading, setLoading] = useState(true);
    
    // Filter States
    const [projectId, setProjectId] = useState('');
    const [companyName, setCompanyName] = useState('');
    const [userId, setUserId] = useState('');
    const [encryptedId, setEncryptedId] = useState('');
    const [cpi, setCpi] = useState('');
    const [statusFilter, setStatusFilter] = useState('All');
    const [supplierFilter, setSupplierFilter] = useState('');
    const [suppliers, setSuppliers] = useState([]);

    // Pre-fill filters from URL query-params — e.g. links from the
    // Vendor × Project Matrix ("?sid=...&vendor=VendorName"). Without this,
    // deep-links into this page did nothing: the filter-state here is
    // purely client-side useState, never read from the URL on load.
    useEffect(() => {
        const sidParam = searchParams.get('sid');
        const vendorParam = searchParams.get('vendor');
        if (sidParam) setProjectId(sidParam);
        if (vendorParam) setSupplierFilter(vendorParam);
    }, [searchParams]);

    // To store currently displayed logs after filtering
    const [filteredLogs, setFilteredLogs] = useState([]);

    useEffect(() => {
        async function fetchLogs() {
            setLoading(true);
            try {
                const [result, suppliersRes] = await Promise.all([
                    getTrackingLogs(logPage, logPageSize),
                    getSuppliers()
                ]);
                if (result.success) {
                    setLogs(result.data || []);
                    setFilteredLogs(result.data || []);
                    setLogTotal(result.total || 0);
                }
                if (suppliersRes.success) {
                    setSuppliers(suppliersRes.data || []);
                }
            } catch (err) {
                console.error('Failed to fetch tracking logs:', err);
            } finally {
                setLoading(false);
            }
        }
        fetchLogs();
    }, [logPage, logPageSize]);

    const getStatusIcon = (status) => {
        switch (status) {
            case 'Complete': return '✅';
            case 'Terminate': return '❌';
            case 'OverQuota': return '⚠️';
            case 'SecurityFail': return '🔍';
            case 'Started': return '🔵';
            default: return '⚪';
        }
    };

    const handleFilter = () => {
        const filtered = logs.filter(log => {
            let match = true;
            
            // Match Project ID on either the UUID or the actual project title (which PMs usually use)
            if (projectId && !(
                (log.project_id && String(log.project_id).toLowerCase().includes(projectId.toLowerCase())) ||
                (log.projects?.title && log.projects.title.toLowerCase().includes(projectId.toLowerCase()))
            )) match = false;
            
            if (userId && !(log.respondent_uid && log.respondent_uid.toLowerCase().includes(userId.toLowerCase()))) match = false;
            if (encryptedId && !(log.encrypted_uid && log.encrypted_uid.toLowerCase().includes(encryptedId.toLowerCase()))) match = false;
            if (companyName && !(log.projects?.clients?.name && log.projects.clients.name.toLowerCase().includes(companyName.toLowerCase()))) match = false;
            if (cpi && !(log.projects?.cpi && String(log.projects.cpi).includes(cpi))) match = false;
            if (supplierFilter && !(log.suppliers?.name && log.suppliers.name === supplierFilter)) match = false;

            
            if (statusFilter !== 'All') {
                if (statusFilter === 'Pending' && log.status !== 'Started') match = false;
                if (statusFilter === 'Completed' && log.status !== 'Complete') match = false;
                if (statusFilter === 'Rejected' && log.status !== 'Terminate') match = false;
                if (statusFilter === 'Quota Full' && log.status !== 'OverQuota') match = false;
                if (statusFilter === 'Quality Check' && log.status !== 'SecurityFail') match = false;
                if (statusFilter === 'Unmatched' && log.status !== 'Unmatched') match = false;
            }

            return match;
        });
        setFilteredLogs(filtered);
    };

    const handleClear = () => {
        setProjectId('');
        setCompanyName('');
        setUserId('');
        setEncryptedId('');
        setCpi('');
        setStatusFilter('All');
        setSupplierFilter('');
        setFilteredLogs(logs);
    };

    const exportToCSV = () => {
        if (filteredLogs.length === 0) {
            alert('No records to export!');
            return;
        }

        const headers = ['S.No.', 'Project ID', 'Company', 'Supplier', 'CPI', 'User ID', 'Encrypted ID', 'IP Address', 'Completed At', 'Status'];
        
        const csvRows = [];
        csvRows.push(headers.join(','));

        filteredLogs.forEach((log, index) => {
            const time = log.completed_at ? new Date(log.completed_at).toLocaleString() : (log.started_at ? new Date(log.started_at).toLocaleString() : 'N/A');
            
            // Format to avoid CSV breaking on commas
            const row = [
                index + 1,
                `"${log.projects?.title || log.project_id || ''}"`,
                `"${log.projects?.clients?.name || ''}"`,
                `"${log.suppliers?.name || ''}"`,
                `"${log.projects?.cpi || ''}"`,
                `"${log.respondent_uid || ''}"`,
                `"${log.encrypted_uid || ''}"`,
                `"${log.ip_address || ''}"`,
                `"${time}"`,
                `"${log.status || ''}"`
            ];
            csvRows.push(row.join(','));
        });

        const csvString = csvRows.join('\n');
        const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `Final_IDs_${new Date().toISOString().slice(0,10)}.csv`);
        link.style.visibility = 'hidden';
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="row mt-3">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item">Support</li>
                            <li className="breadcrumb-item active">Redirect Status</li>
                        </ol>
                    </div>
                    <h4 className="page-title mt-1">Redirect Status (3rd Party Views)</h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        {/* Filters Section */}
                        <div className="row mb-3" style={{backgroundColor: '#f8f9fa', padding: '15px', borderRadius: '5px'}}>
                            <div className="col-md-4 col-lg-2 mb-2">
                                <label className="font-weight-bold" style={{fontSize: '13px'}}>Project ID</label>
                                <input type="text" className="form-control form-control-sm" value={projectId} onChange={e => setProjectId(e.target.value)} placeholder="Project ID" />
                            </div>
                            <div className="col-md-4 col-lg-2 mb-2">
                                <label className="font-weight-bold" style={{fontSize: '13px'}}>Company Name</label>
                                <input type="text" className="form-control form-control-sm" value={companyName} onChange={e => setCompanyName(e.target.value)} placeholder="Company Name" />
                            </div>
                            <div className="col-md-4 col-lg-2 mb-2">
                                <label className="font-weight-bold" style={{fontSize: '13px'}}>User ID</label>
                                <input type="text" className="form-control form-control-sm" value={userId} onChange={e => setUserId(e.target.value)} placeholder="User ID" />
                            </div>
                            <div className="col-md-4 col-lg-2 mb-2">
                                <label className="font-weight-bold" style={{fontSize: '13px'}}>Encrypted ID</label>
                                <input type="text" className="form-control form-control-sm" value={encryptedId} onChange={e => setEncryptedId(e.target.value)} placeholder="Encrypted ID" />
                            </div>
                            <div className="col-md-4 col-lg-2 mb-2">
                                <label className="font-weight-bold" style={{fontSize: '13px'}}>CPI</label>
                                <input type="text" className="form-control form-control-sm" value={cpi} onChange={e => setCpi(e.target.value)} placeholder="CPI" />
                            </div>
                            <div className="col-md-4 col-lg-2 mb-2">
                                <label className="font-weight-bold" style={{fontSize: '13px'}}>Status</label>
                                <select className="form-control form-control-sm" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
                                    <option value="All">All</option>
                                    <option value="Pending">Pending</option>
                                    <option value="Completed">Completed</option>
                                    <option value="Rejected">Rejected</option>
                                    <option value="Quota Full">Quota Full</option>
                                    <option value="Quality Check">Quality Check</option>
                                    <option value="Unmatched">Unmatched</option>
                                </select>
                            </div>
                            <div className="col-md-4 col-lg-2 mb-2">
                                <label className="font-weight-bold" style={{fontSize: '13px'}}>Supplier</label>
                                <select className="form-control form-control-sm" value={supplierFilter} onChange={e => setSupplierFilter(e.target.value)}>
                                    <option value="">All Suppliers</option>
                                    {suppliers.map(supplier => (
                                        <option key={supplier.id} value={supplier.name}>{supplier.name}</option>
                                    ))}
                                </select>
                            </div>
                        </div>
                        
                        <div className="row mb-4">
                            <div className="col-12 d-flex align-items-center">
                                <button className="btn btn-primary btn-sm mr-2" onClick={handleFilter} style={{minWidth: '80px'}}>Filter</button>
                                <button className="btn btn-secondary btn-sm mr-2" onClick={handleClear} style={{minWidth: '80px'}}>Clear</button>
                                <button className="btn btn-danger btn-sm mr-auto" style={{minWidth: '120px'}} onClick={() => alert('Delete function pending admin approval')}>Delete Selected</button>
                                
                                <button className="btn btn-success btn-sm" onClick={exportToCSV}>
                                    <i className="fas fa-file-excel mr-1"></i> Download CSV (Excel)
                                </button>
                            </div>
                        </div>

                        {/* Table Section */}
                        <div className="table-responsive rdrctStTbl">
                            <table className="table table-striped table-bordered table-sm" style={{fontSize: '13px'}}>
                                <thead className="thead-light">
                                    <tr>
                                        <th style={{textAlign: "center", width: "40px"}}>
                                            <input type="checkbox" disabled />
                                        </th>
                                        <th style={{textAlign: "center", minWidth: "50px"}}>ID</th>
                                        <th style={{minWidth: "140px"}}>Project ID</th>
                                        <th style={{minWidth: "120px"}}>Company</th>
                                        <th style={{minWidth: "120px"}}>Supplier</th>
                                        <th style={{minWidth: "60px"}}>CPI</th>
                                        <th style={{minWidth: "120px"}}>User ID</th>
                                        <th style={{minWidth: "220px"}}>Encrypted ID</th>
                                        <th style={{minWidth: "110px"}}>IP Address</th>
                                        <th style={{minWidth: "140px"}}>Completed At</th>
                                        <th style={{textAlign: "center", minWidth: "95px"}}>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {loading ? (
                                        <tr>
                                            <td colSpan="10" style={{textAlign: "center", padding: "30px"}}>
                                                Loading tracking logs...
                                            </td>
                                        </tr>
                                    ) : filteredLogs.length === 0 ? (
                                        <tr>
                                            <td colSpan="10" style={{textAlign: "center", padding: "30px"}}>
                                                No tracking logs found.
                                            </td>
                                        </tr>
                                    ) : (
                                        filteredLogs.map((log, index) => (
                                            <tr key={log.id} className="qlfy">
                                                <td style={{textAlign: "center"}}>
                                                    <input type="checkbox" />
                                                </td>
                                                <td style={{textAlign: "center"}}>{index + 1}</td>
                                                <td style={{fontWeight: 'bold', color: '#0056b3'}}>{log.projects?.title || log.project_id?.substring(0,8) || 'N/A'}</td>
                                                <td>{log.projects?.clients?.name || ''}</td>
                                                <td>{log.suppliers?.name || ''}</td>
                                                <td>{log.projects?.cpi ? `$${log.projects.cpi}` : ''}</td>
                                                <td>{log.respondent_uid || 'N/A'}</td>
                                                <td style={{wordBreak: "break-all"}}>
                                                    {log.encrypted_uid || 'N/A'}
                                                </td>
                                                <td>{log.ip_address || 'N/A'}</td>
                                                <td>
                                                    {log.completed_at
                                                        ? new Date(log.completed_at).toLocaleString()
                                                        : log.started_at
                                                            ? new Date(log.started_at).toLocaleString()
                                                            : 'N/A'
                                                    }
                                                </td>
                                                <td style={{textAlign: "center"}}>
                                                    <span title={log.status}>{getStatusIcon(log.status)} {log.status}</span>
                                                </td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                        {!loading && (
                            <div className="d-flex justify-content-between align-items-center mt-2 flex-wrap" style={{ gap: '10px' }}>
                                <div className="text-muted" style={{fontSize: "13px"}}>
                                    Showing {filteredLogs.length} of {logs.length} on this page — page {logPage} of {Math.max(1, Math.ceil(logTotal / logPageSize))} ({logTotal.toLocaleString()} total)
                                </div>
                                <div className="d-flex align-items-center" style={{ gap: '8px' }}>
                                    <select className="form-control form-control-sm" style={{ width: 'auto' }} value={logPageSize} onChange={e => { setLogPageSize(Number(e.target.value)); setLogPage(1); }}>
                                        <option value={100}>100 / page</option>
                                        <option value={250}>250 / page</option>
                                        <option value={500}>500 / page</option>
                                        <option value={1000}>1000 / page</option>
                                    </select>
                                    <button className="btn btn-sm btn-outline-secondary" disabled={logPage <= 1} onClick={() => setLogPage(p => p - 1)}>← Previous</button>
                                    <button className="btn btn-sm btn-outline-secondary" disabled={logPage * logPageSize >= logTotal} onClick={() => setLogPage(p => p + 1)}>Next →</button>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
