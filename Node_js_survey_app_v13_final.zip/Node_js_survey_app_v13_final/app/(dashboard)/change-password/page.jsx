"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { updatePassword, getMyProfile, updateMyProfile } from '@/app/login/actions';

export default function ChangePassword() {
    // ── My Profile state ──
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [profileSaving, setProfileSaving] = useState(false);
    const [profileMessage, setProfileMessage] = useState(null);
    const [profileLoading, setProfileLoading] = useState(true);

    // ── Change Password state ──
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [saving, setSaving] = useState(false);
    const [message, setMessage] = useState(null);

    useEffect(() => {
        async function loadProfile() {
            const result = await getMyProfile();
            if (result.success) {
                setName(result.data.name);
                setEmail(result.data.email);
            }
            setProfileLoading(false);
        }
        loadProfile();
    }, []);

    const handleProfileSubmit = async (e) => {
        e.preventDefault();
        setProfileMessage(null);
        setProfileSaving(true);
        const result = await updateMyProfile(name, email);
        setProfileSaving(false);

        if (result.error) {
            setProfileMessage({ type: 'danger', text: result.error });
        } else if (result.emailConfirmationSent) {
            setProfileMessage({ type: 'success', text: 'Name saved. A confirmation link was sent to your new email — the email change will apply once you click it.' });
        } else {
            setProfileMessage({ type: 'success', text: 'Profile updated successfully!' });
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage(null);

        if (newPassword.length < 6) {
            setMessage({ type: 'danger', text: 'Password must be at least 6 characters.' });
            return;
        }
        if (newPassword !== confirmPassword) {
            setMessage({ type: 'danger', text: 'Passwords do not match.' });
            return;
        }

        setSaving(true);
        const result = await updatePassword(newPassword);
        setSaving(false);

        if (result.error) {
            setMessage({ type: 'danger', text: result.error });
        } else {
            setMessage({ type: 'success', text: 'Password updated successfully!' });
            setNewPassword('');
            setConfirmPassword('');
        }
    };

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item active">My Account</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">My Account</h4>
                </div>
            </div>

            {/* My Profile */}
            <div className="col-sm-12 col-md-6">
                <div className="card">
                    <div className="card-body">
                        <h5 className="mb-3">👤 My Profile</h5>
                        {profileLoading ? (
                            <p className="text-muted">Loading...</p>
                        ) : (
                        <form onSubmit={handleProfileSubmit}>
                            <div className="form-group">
                                <label>Name</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Email (login username)</label>
                                <input
                                    type="email"
                                    className="form-control"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    required
                                />
                            </div>

                            {profileMessage && (
                                <div className={`alert alert-${profileMessage.type}`}>{profileMessage.text}</div>
                            )}

                            <button type="submit" className="btn btn-primary" disabled={profileSaving}>
                                {profileSaving ? 'Saving...' : 'Save Profile'}
                            </button>
                        </form>
                        )}
                    </div>
                </div>
            </div>

            {/* Change Password */}
            <div className="col-sm-12 col-md-6">
                <div className="card">
                    <div className="card-body">
                        <h5 className="mb-3">🔑 Change Password</h5>
                        <form onSubmit={handleSubmit}>
                            <div className="form-group">
                                <label>New Password</label>
                                <input
                                    type="password"
                                    className="form-control"
                                    value={newPassword}
                                    onChange={(e) => setNewPassword(e.target.value)}
                                    required
                                    minLength={6}
                                />
                            </div>
                            <div className="form-group">
                                <label>Confirm New Password</label>
                                <input
                                    type="password"
                                    className="form-control"
                                    value={confirmPassword}
                                    onChange={(e) => setConfirmPassword(e.target.value)}
                                    required
                                    minLength={6}
                                />
                            </div>

                            {message && (
                                <div className={`alert alert-${message.type}`}>{message.text}</div>
                            )}

                            <button type="submit" className="btn btn-primary" disabled={saving}>
                                {saving ? 'Updating...' : 'Update Password'}
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}
