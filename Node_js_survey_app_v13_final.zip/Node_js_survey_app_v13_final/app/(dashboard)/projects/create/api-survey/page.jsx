"use client";
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function APISurvey() {
    const router = useRouter();
    const [submitted, setSubmitted] = useState(false);

    // API Survey Integration (Lucid/Cint/Dynata) is DELIBERATELY deferred —
    // it requires a real business/partner-approval relationship with each
    // marketplace, not just code (see Master Reference Document, Section 8).
    // Previously this form's submit button did nothing at all when clicked
    // (silent no-op) — that's bad UX regardless of the backend being
    // deferred. This fix doesn't fake-build a real Lucid/Cint/Dynata
    // connector (which would need real API credentials this project
    // doesn't have) — it makes the form honestly explain its own status.
    function handleSubmit(e) {
        e.preventDefault();
        setSubmitted(true);
    }

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><a href="/">Home</a></li>
                            <li className="breadcrumb-item">Projects</li>
                            <li className="breadcrumb-item active">API Survey</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">API Survey Integration</h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <div className="alert alert-warning" role="alert">
                            <strong>Not yet connected.</strong> Real-time API integration with sample-marketplaces (Lucid, Cint, Dynata) requires becoming an approved supplier-partner with each one first — this is a business/partnership step, not something that can be wired up in code alone. This form is a placeholder until that partnership process is complete.
                        </div>
                        {submitted ? (
                            <div className="alert alert-info" role="alert">
                                Thanks — these details have been noted. Once partner-approval with the selected marketplace is in place, this integration can be properly built and connected. In the meantime, please use <Link href="/projects/create/single">Single Project</Link> for any live project.
                            </div>
                        ) : (
                        <form onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Supplier API Source<span className="text-danger">*</span></label>
                                    <select className="form-control" required>
                                        <option value="">-- Select API --</option>
                                        <option value="lucid">Lucid API</option>
                                        <option value="cint">Cint API</option>
                                        <option value="dynata">Dynata API</option>
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">API Project Name<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="text" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Project Manager<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="text" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Survey Link / Webhook URL<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="url" />
                                </div>
                            </div>
                            
                            <hr />
                            <div className="row mt-4">
                                <div className="col-12 text-right">
                                    <button type="submit" className="btn btn-primary mr-2">Note Interest (Not Yet Connected)</button>
                                    <button type="button" className="btn btn-secondary" onClick={() => router.push('/projects')}>Cancel</button>
                                </div>
                            </div>
                        </form>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
