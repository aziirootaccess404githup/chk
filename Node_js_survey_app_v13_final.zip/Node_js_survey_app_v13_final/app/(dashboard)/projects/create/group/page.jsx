"use client";
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { getClients } from '@/app/actions/clients';
import { createProject } from '@/app/actions/projects';
import { countries } from '@/utils/countries';

export default function GroupProject() {
    const [clients, setClients] = useState([]);
    const [loading, setLoading] = useState(false);
    
    // Auto-fill states for URLs
    const [completeUrl, setCompleteUrl] = useState('');
    const [terminateUrl, setTerminateUrl] = useState('');
    const [quotaUrl, setQuotaUrl] = useState('');
    const [qualityUrl, setQualityUrl] = useState('');

    const router = useRouter();

    useEffect(() => {
        async function fetchClients() {
            const res = await getClients();
            if (res.success) setClients(res.data);
        }
        fetchClients();

        // Initialize multiselect dropdown for countries if the script is loaded
        setTimeout(() => {
            if (typeof window !== 'undefined' && window.MultiselectDropdown) {
                window.MultiselectDropdown(window.MultiselectDropdownOptions);
            }
        }, 500);
    }, []);

    // ── Group Project = one PARENT (umbrella) project + one CHILD project
    // PER selected country, linked via parent_id — same mechanism already
    // used by Single→Child cloning (including automatic supplier-mapping
    // cloning onto each child). The schema only has a single `country`
    // string field per project row, so a "group spanning many countries"
    // is represented as several linked child-rows, each with its own
    // country — not one row with a country-array.
    async function handleSubmit(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const selectedCountries = formData.getAll('Countries'); // multi-select → array
        if (!selectedCountries || selectedCountries.length === 0) {
            alert('Please select at least one country.');
            return;
        }

        setLoading(true);
        try {
            const groupName = formData.get('ProjectName');
            const totalSample = parseInt(formData.get('SampleSize'), 10) || 0;
            // Split the total sample evenly across countries by default —
            // easy to adjust per-child afterward via Edit Project.
            const perCountrySample = Math.max(1, Math.round(totalSample / selectedCountries.length));

            const sharedFields = {
                client_id: formData.get('ClientId'),
                project_manager: formData.get('ProjectManager'),
                category: formData.get('CategoryId'),
                description: formData.get('ProjectDescription'),
                loi: formData.get('LOI'),
                ir: formData.get('IR'),
                cpi: formData.get('ProjectCPI'),
                currency: formData.get('Currency'),
                start_date: formData.get('StartDate'),
                end_date: formData.get('EndDate'),
                status: formData.get('Status'),
                client_link: formData.get('ClientLink'),
                client_complete_url: formData.get('ClientCompleteUrl'),
                client_terminate_url: formData.get('ClientTerminateUrl'),
                client_quota_url: formData.get('ClientQuotaUrl'),
                client_quality_url: formData.get('ClientQualityUrl'),
            };

            // 1) Create the parent/umbrella project (no single country —
            // represents the group as a whole; visible in Projects list,
            // its children shown via the existing parent/child linking UI).
            const parentData = new FormData();
            parentData.append('title', groupName);
            parentData.append('sample_size', String(totalSample));
            Object.entries(sharedFields).forEach(([k, v]) => { if (v) parentData.append(k, v); });
            const parentResult = await createProject(parentData);
            if (!parentResult.success) {
                alert('Error creating group (parent) project: ' + parentResult.error);
                setLoading(false);
                return;
            }
            const parentId = parentResult.data.id;

            // 2) Create one child project per selected country
            const countryNameByCode = Object.fromEntries(countries.map(c => [c.code, c.name]));
            let failedCountries = [];
            for (const countryCode of selectedCountries) {
                const childData = new FormData();
                const countryName = countryNameByCode[countryCode] || countryCode;
                childData.append('title', `${groupName} - ${countryName}`);
                childData.append('country', countryCode);
                childData.append('sample_size', String(perCountrySample));
                childData.append('parent_id', parentId);
                Object.entries(sharedFields).forEach(([k, v]) => { if (v) childData.append(k, v); });
                const childResult = await createProject(childData);
                if (!childResult.success) failedCountries.push(countryName);
            }

            if (failedCountries.length > 0) {
                alert(`Group project created, but these countries failed: ${failedCountries.join(', ')}. You can add them individually via "Child Project".`);
            } else {
                alert(`Group project created successfully with ${selectedCountries.length} country project(s)!`);
            }
            router.push(`/projects/${parentId}`);
        } catch (err) {
            alert('Error creating group project: ' + err.message);
        }
        setLoading(false);
    }
    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><a href="/">Home</a></li>
                            <li className="breadcrumb-item">Projects</li>
                            <li className="breadcrumb-item active">Group Project</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Group Project</h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <form onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Client<span className="text-danger">*</span></label>
                                    <select 
                                        className="form-control" 
                                        name="ClientId" 
                                        required
                                        onChange={(e) => {
                                            const selectedClient = clients.find(c => String(c.id) === String(e.target.value));
                                            if (selectedClient) {
                                                setCompleteUrl(selectedClient.complete_url || '');
                                                setTerminateUrl(selectedClient.terminate_url || '');
                                                setQuotaUrl(selectedClient.quotafull_url || '');
                                                setQualityUrl(selectedClient.quality_url || '');
                                            } else {
                                                setCompleteUrl('');
                                                setTerminateUrl('');
                                                setQuotaUrl('');
                                                setQualityUrl('');
                                            }
                                        }}
                                    >
                                        <option value="">-- Select Client --</option>
                                        {clients.map(c => (
                                            <option key={c.id} value={c.id}>{c.name}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Group Project Name<span className="text-danger">*</span></label>
                                    <input className="form-control" name="ProjectName" required type="text" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Project Manager<span className="text-danger">*</span></label>
                                    <input className="form-control" name="ProjectManager" required type="text" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Total Sample Size<span className="text-danger">*</span></label>
                                    <input className="form-control" name="SampleSize" required type="number" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Countries Included<span className="text-danger">*</span></label>
                                    <select className="form-control" name="Countries" multiple required multiselect-search="true" multiselect-select-all="true" style={{height: "100px"}}>
                                        {countries.map(c => (
                                            <option key={c.code} value={c.code}>{c.name}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Project Category<span className="text-danger">*</span></label>
                                    <select className="form-control" name="CategoryId" required>
                                        <option value="">-- Select Category --</option>
                                        <option value="B2B">B2B</option>
                                        <option value="B2C">B2C</option>
                                        <option value="Healthcare">Healthcare</option>
                                    </select>
                                </div>
                                <div className="col-sm-12 form-group">
                                    <label className="control-label">Project Description</label>
                                    <textarea className="form-control" name="ProjectDescription" rows="3"></textarea>
                                </div>
                                <div className="col-sm-6 col-md-3 form-group">
                                    <label className="control-label">LOI (Minute)<span className="text-danger">*</span></label>
                                    <input className="form-control" name="LOI" required type="number" min="1" />
                                </div>
                                <div className="col-sm-6 col-md-3 form-group">
                                    <label className="control-label">IR (%)<span className="text-danger">*</span></label>
                                    <input className="form-control" name="IR" required type="number" min="1" max="100" />
                                </div>
                                <div className="col-sm-6 col-md-3 form-group">
                                    <label className="control-label">Project CPI<span className="text-danger">*</span></label>
                                    <input className="form-control" name="ProjectCPI" required type="number" step="0.01" />
                                </div>
                                <div className="col-sm-6 col-md-3 form-group">
                                    <label className="control-label">Currency<span className="text-danger">*</span></label>
                                    <select className="form-control" name="Currency" required>
                                        <option value="USD">USD</option>
                                        <option value="EUR">EUR</option>
                                        <option value="GBP">GBP</option>
                                        <option value="INR">INR</option>
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Start Date<span className="text-danger">*</span></label>
                                    <input className="form-control" name="StartDate" required type="date" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">End Date<span className="text-danger">*</span></label>
                                    <input className="form-control" name="EndDate" required type="date" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Project Status<span className="text-danger">*</span></label>
                                    <select className="form-control" name="Status" required>
                                        <option value="Draft">Draft</option>
                                        <option value="Live">Live</option>
                                        <option value="Paused">Paused</option>
                                        <option value="Closed">Closed</option>
                                    </select>
                                </div>
                                <div className="col-sm-12 form-group">
                                    <label className="control-label">Client Survey Link (Destination)<span className="text-danger">*</span></label>
                                    <input className="form-control" name="ClientLink" required type="url" placeholder="https://..." />
                                </div>
                            </div>
                            
                            <h4 className="header-title mt-2 mb-3">Client Redirect URLs</h4>
                            <div className="row">
                                <div className="col-sm-6 form-group">
                                    <label className="control-label">Complete URL</label>
                                    <input className="form-control" name="ClientCompleteUrl" type="url" placeholder="https://..." value={completeUrl} onChange={e => setCompleteUrl(e.target.value)} />
                                </div>
                                <div className="col-sm-6 form-group">
                                    <label className="control-label">Terminate URL</label>
                                    <input className="form-control" name="ClientTerminateUrl" type="url" placeholder="https://..." value={terminateUrl} onChange={e => setTerminateUrl(e.target.value)} />
                                </div>
                                <div className="col-sm-6 form-group">
                                    <label className="control-label">Quota Full URL</label>
                                    <input className="form-control" name="ClientQuotaUrl" type="url" placeholder="https://..." value={quotaUrl} onChange={e => setQuotaUrl(e.target.value)} />
                                </div>
                                <div className="col-sm-6 form-group">
                                    <label className="control-label">Quality Check URL</label>
                                    <input className="form-control" name="ClientQualityUrl" type="url" placeholder="https://..." value={qualityUrl} onChange={e => setQualityUrl(e.target.value)} />
                                </div>
                            </div>
                            <hr />
                            <div className="row mt-4">
                                <div className="col-12 text-right">
                                    <button type="submit" className="btn btn-primary mr-2">Create Group Project</button>
                                    <button type="button" className="btn btn-secondary" onClick={() => router.push('/projects')}>Cancel</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}
