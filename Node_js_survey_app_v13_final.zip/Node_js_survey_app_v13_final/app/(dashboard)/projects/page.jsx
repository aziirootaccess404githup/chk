"use client";
import { useState, useEffect, useMemo } from 'react';
import { createPortal } from 'react-dom';
import Link from 'next/link';
import { getProjects } from '@/app/actions/projects';
import { deleteProject, cloneProject } from '@/app/actions/projects';
import { getSuppliers } from '@/app/actions/suppliers';
import { bulkImportProjects } from '@/app/actions/bulkImport';

export default function ProjectList() {
    const [searchTerm, setSearchTerm] = useState("");
    const [flag, setFlag] = useState("1"); // 1=Active, etc
    const [projects, setProjects] = useState([]);
    const [showBulkImportModal, setShowBulkImportModal] = useState(false);
    const [bulkCsvFile, setBulkCsvFile] = useState(null);
    const [bulkImporting, setBulkImporting] = useState(false);
    const [bulkImportResult, setBulkImportResult] = useState(null);
    const [bulkImportError, setBulkImportError] = useState('');

    async function handleBulkImport() {
        if (!bulkCsvFile) return;
        setBulkImporting(true);
        setBulkImportError('');
        try {
            const text = await bulkCsvFile.text();
            const res = await bulkImportProjects(text);
            if (res.success) {
                setBulkImportResult(res.results);
                setShowBulkImportModal(false);
                setBulkCsvFile(null);
                // Refresh the projects list so newly-imported rows show up immediately
                const projRes = await getProjects();
                if (projRes.success) setProjects(projRes.data);
            } else {
                setBulkImportError(res.error || 'Import failed.');
            }
        } catch (err) {
            setBulkImportError(err.message || 'Could not read the file.');
        } finally {
            setBulkImporting(false);
        }
    }
    const [expandedProjects, setExpandedProjects] = useState({});
    const [dropdownId, setDropdownId] = useState(null);
    const [dropdownPos, setDropdownPos] = useState({ top: 0, left: 0 });
    const [suppliers, setSuppliers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [linkModalProject, setLinkModalProject] = useState(null);
    const [selectedSupplierId, setSelectedSupplierId] = useState("");
    const [baseUrl, setBaseUrl] = useState("");
    const [clients, setClients] = useState([]);
    const [projectMappings, setProjectMappings] = useState([]);

    useEffect(() => {
        setBaseUrl(window.location.origin);
        async function fetchData() {
            const { getClients } = await import('@/app/actions/clients');
            const [projRes, suppRes, clientRes] = await Promise.all([
                getProjects(),
                getSuppliers(),
                getClients()
            ]);
            if (projRes.success) setProjects(projRes.data);
            if (suppRes.success) setSuppliers(suppRes.data);
            if (clientRes.success) setClients(clientRes.data);
            setLoading(false);
        }
        fetchData();
    }, []);

    useEffect(() => {
        if (linkModalProject) {
            async function fetchMappings() {
                const { getMappingsByProject } = await import('@/app/actions/mappings');
                const res = await getMappingsByProject(linkModalProject.id);
                if (res.success) {
                    setProjectMappings(res.data);
                }
            }
            fetchMappings();
        } else {
            setProjectMappings([]);
            setSelectedSupplierId("");
        }
    }, [linkModalProject]);

    const toggleExpand = (projectId) => {
        setExpandedProjects(prev => ({ ...prev, [projectId]: !prev[projectId] }));
    };

    const filteredProjects = useMemo(() => {
        let filtered = projects.filter(p => {
            if (searchTerm) return p.title.toLowerCase().includes(searchTerm.toLowerCase());
            
            const status = p.status || '';
            if (flag === "1") return status === 'Live' || status === 'Active';
            if (flag === "2") return status === 'Paused' || status === 'Draft' || status === 'Inactive';
            if (flag === "4") return status === 'Closed';
            if (flag === "5") return status === 'Invoiced';
            if (flag === "7") return status === 'Archive';
            return true; // default for others
        });

        // Group into main projects and sub-projects
        const mainProjects = filtered.filter(p => !p.parent_id);
        const subProjects = filtered.filter(p => p.parent_id);

        const rowData = [];
        let sNo = 1;

        mainProjects.forEach(mainProj => {
            const subs = subProjects.filter(sub => sub.parent_id === mainProj.id);
            rowData.push({ ...mainProj, isSub: false, displaySNo: sNo++, hasChild: subs.length > 0 });
            
            // If expanded, add its sub-projects right below it
            if (expandedProjects[mainProj.id]) {
                subs.forEach(sub => {
                    rowData.push({ ...sub, isSub: true });
                });
            }
        });

        return rowData;
    }, [projects, searchTerm, flag, expandedProjects]);



    async function handleDeleteProject(projectId) {
        if (!confirm('Are you sure you want to delete this project? This action cannot be undone.')) return;
        const result = await deleteProject(projectId);
        if (result.success) {
            setProjects(projects.filter(p => p.id !== projectId));
            alert('Project deleted successfully!');
        } else {
            alert('Error: ' + result.error);
        }
    }

    async function handleCloneProject(projectId) {
        if (!confirm('Clone this project?')) return;
        const result = await cloneProject(projectId);
        if (result.success) {
            setProjects([result.data, ...projects]);
            alert('Project cloned successfully!');
        } else {
            alert('Error: ' + result.error);
        }
    }

    return (
        <div className="tabPanelWraps">
            <div className="row mt-3 mb-2">
                <div className="col-md-8 col-sm-12 col-12">
                    <div className="row">
                        <div className="col-md-2 col-sm-12 col-12 pr-0">
                            <div className="justify-content-end prStatSelect">
                                <span>
                                    <span className="fa fa-square flagIcon" id="flagIcon"></span>
                                    <select 
                                        className="form-control" 
                                        id="projectFlag" 
                                        value={flag} 
                                        onChange={(e) => setFlag(e.target.value)}
                                    >
                                        <option value="1">Active</option>
                                        <option value="2">InActive</option>
                                        <option value="4">Closed</option>
                                        <option value="5">Invoiced</option>
                                        <option value="7">Archive</option>
                                    </select>
                                </span>
                            </div>
                        </div>
                        <div className="col-md-8 col-sm-12 col-12 pl-1">
                            <div className="page-title-box">
                                <h4 className="page-title mt-1">Projects-Data</h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4 col-sm-12 col-12 mb-1">
                    <div className="y-contSearch">
                        <form className="app-search" onSubmit={(e) => e.preventDefault()}>
                            <div className="app-search-box">
                                <div className="input-group">
                                    <input 
                                        id="SearchText" 
                                        type="text" 
                                        className="form-control" 
                                        placeholder="Search Project..." 
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                    />
                                    {searchTerm && (
                                        <a className="clearCrossIcon" onClick={() => setSearchTerm("")} style={{cursor: 'pointer'}}>
                                            <i className="fa fa-times-circle" aria-hidden="true"></i>
                                        </a>
                                    )}
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div className="row">
                <div className="col-sm-12 mb-2 d-flex justify-content-end">
                    <button type="button" className="btn btn-success" onClick={() => setShowBulkImportModal(true)}>
                        📥 Bulk Import Projects
                    </button>
                </div>
            </div>

            {bulkImportResult && (
                <div className="row">
                    <div className="col-sm-12">
                        <div className={`alert ${bulkImportResult.errors?.length ? 'alert-warning' : 'alert-success'} d-flex justify-content-between align-items-start`}>
                            <div>
                                <b>Import complete:</b> {bulkImportResult.created} created, {bulkImportResult.updated} updated
                                {bulkImportResult.mapped > 0 && `, ${bulkImportResult.mapped} vendor-link(s) created`}.
                                {bulkImportResult.errors?.length > 0 && (
                                    <ul className="mb-0 mt-1">
                                        {bulkImportResult.errors.map((err, i) => <li key={i}>{err}</li>)}
                                    </ul>
                                )}
                            </div>
                            <button type="button" className="close" onClick={() => setBulkImportResult(null)}>&times;</button>
                        </div>
                    </div>
                </div>
            )}

            {showBulkImportModal && (
                <div className="modal d-block" style={{ background: 'rgba(0,0,0,0.5)' }} tabIndex="-1">
                    <div className="modal-dialog modal-lg">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">📥 Bulk Import Projects (CSV)</h5>
                                <button type="button" className="close" onClick={() => setShowBulkImportModal(false)}>&times;</button>
                            </div>
                            <div className="modal-body">
                                <p className="text-muted" style={{ fontSize: '13px' }}>
                                    CSV columns: <b>title, client_name, client_link, cpi, quota, supplier_name</b> (only <b>title</b> is required).
                                    Adding a <b>supplier_name</b> also creates the vendor entry-link mapping immediately, matching{' '}
                                    <a href="data:text/csv;charset=utf-8,title%2Cclient_name%2Cclient_link%2Ccpi%2Cquota%2Csupplier_name%0ASample%20Project%2CSample%20Client%2Chttps%3A%2F%2Fexample.com%2Fs%3Fuid%3D%255BUID%255D%2C3.50%2C200%2CInternal%20Team"
                                       download="project_import_template.csv">this template</a>.
                                </p>
                                <input
                                    type="file"
                                    accept=".csv"
                                    className="form-control"
                                    onChange={(e) => setBulkCsvFile(e.target.files[0])}
                                />
                                {bulkImportError && <div className="text-danger mt-2" style={{ fontSize: '12px' }}>{bulkImportError}</div>}
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" onClick={() => setShowBulkImportModal(false)}>Cancel</button>
                                <button type="button" className="btn btn-primary" disabled={!bulkCsvFile || bulkImporting} onClick={handleBulkImport}>
                                    {bulkImporting ? 'Importing…' : 'Import'}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            <div className="row">
                <div className="col-sm-12">
                    <div className="card">
                        <div className="card-body">
                            <div className="responsive-table-plugin1" style={{ overflow: dropdownId ? 'visible' : 'auto' }}>
                                <div className="table-rep-plugin1" style={{ overflow: dropdownId ? 'visible' : 'auto' }}>
                                    <div className="table-responsive table-scroll-fixed tableTHfix" style={{ overflow: dropdownId ? 'visible' : 'auto' }}>
                                        <table className="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th style={{minWidth: "40px", textAlign: "center"}}>S.No.</th>
                                                    <th style={{minWidth: "150px", textAlign: "left"}}>Project</th>
                                                    <th style={{minWidth: "170px", textAlign: "left"}}>ProjectManager</th>
                                                    <th style={{minWidth: "110px", textAlign: "left"}}>ClientName</th>
                                                    <th style={{minWidth: "58px", textAlign: "center"}}>Country</th>
                                                    <th style={{minWidth: "57px", textAlign: "center"}} title="Starts">Starts</th>
                                                    <th style={{minWidth: "56px", textAlign: "center"}} title="Completes">C</th>
                                                    <th style={{minWidth: "56px", textAlign: "center"}} title="Terminates">T</th>
                                                    <th style={{minWidth: "56px", textAlign: "center"}} title="OverQuota">Q</th>
                                                    <th style={{minWidth: "56px", textAlign: "center"}} title="Dropouts">D</th>
                                                    <th style={{minWidth: "56px", textAlign: "center"}} title="QualityTerm">QC</th>
                                                    <th style={{minWidth: "130px", textAlign: "center"}}>RemainingSample</th>
                                                    <th style={{minWidth: "55px", textAlign: "center"}}>IR(%)</th>
                                                    <th style={{minWidth: "55px", textAlign: "center"}}>LOI</th>
                                                    <th style={{minWidth: "45px", textAlign: "center"}}>API</th>
                                                    <th style={{minWidth: "120px", textAlign: "center", whiteSpace: "nowrap"}}>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {loading ? (
                                                    <tr><td colSpan="16" className="text-center">Loading projects...</td></tr>
                                                ) : filteredProjects.length === 0 ? (
                                                    <tr><td colSpan="16" className="text-center">No projects found.</td></tr>
                                                ) : filteredProjects.map((item, index) => (
                                                    <tr key={item.id} style={{ backgroundColor: item.isSub ? '#f8f9fa' : 'transparent' }}>
                                                        <td style={{textAlign: "center"}}>
                                                            {!item.isSub ? item.displaySNo : ''}
                                                        </td>
                                                        <td>
                                                            <div className="d-flex align-items-start">
                                                                <div style={{ flex: 1 }}>
                                                                    <div className="dropdown" style={{display: 'inline-block'}}>
                                                                        <a href="#" className="dropdown-toggle text-primary font-weight-bold" style={{fontSize: '14px', textDecoration: 'underline', cursor: 'pointer'}} 
                                                                           onClick={(e) => { 
                                                                               e.preventDefault(); 
                                                                               if (dropdownId === item.id) {
                                                                                   setDropdownId(null);
                                                                               } else {
                                                                                   const rect = e.currentTarget.getBoundingClientRect();
                                                                                   setDropdownPos({ top: rect.bottom, left: rect.left });
                                                                                   setDropdownId(item.id);
                                                                               }
                                                                           }}>
                                                                            {item.isSub ? item.id.substring(0,6) : ("PRJ-" + item.id.substring(0,4))}
                                                                        </a>
                                                                        {dropdownId === item.id && typeof window !== 'undefined' && createPortal(
                                                                            <>
                                                                                <div style={{position: 'fixed', inset: 0, zIndex: 9998}} onClick={() => setDropdownId(null)}></div>
                                                                                <div style={{position: 'fixed', zIndex: 9999, backgroundColor: '#fff', border: '1px solid #ddd', borderRadius: '4px', minWidth: '180px', boxShadow: '0 2px 8px rgba(0,0,0,0.15)', left: dropdownPos.left, top: dropdownPos.top}}>
                                                                                    <Link href={`/projects/${item.id}`} className="dropdown-item" style={{display: 'block', padding: '8px 16px', color: '#333', textDecoration: 'none'}} onClick={() => setDropdownId(null)}>
                                                                                        <i className="fas fa-info-circle mr-2"></i>Project Detail
                                                                                    </Link>
                                                                                    <Link href={`/projects/${item.id}?tab=mapping`} className="dropdown-item" style={{display: 'block', padding: '8px 16px', color: '#333', textDecoration: 'none'}} onClick={() => setDropdownId(null)}>
                                                                                        <i className="fas fa-link mr-2"></i>Supplier Mapping
                                                                                    </Link>
                                                                                    <a href="#" className="dropdown-item" style={{display: 'block', padding: '8px 16px', color: '#333', textDecoration: 'none'}} onClick={(e) => { e.preventDefault(); setDropdownId(null); setLinkModalProject(item); }}>
                                                                                        <i className="fas fa-external-link-alt mr-2"></i>Get Link
                                                                                    </a>
                                                                                    <a href="#" className="dropdown-item" style={{display: 'block', padding: '8px 16px', color: '#333', textDecoration: 'none'}} onClick={(e) => { e.preventDefault(); setDropdownId(null); handleCloneProject(item.id); }}>
                                                                                        <i className="fas fa-copy mr-2"></i>Clone Project
                                                                                    </a>
                                                                                    <hr style={{margin: '4px 0'}} />
                                                                                    <a href="#" className="dropdown-item" style={{display: 'block', padding: '8px 16px', color: '#dc3545', textDecoration: 'none'}} onClick={(e) => { e.preventDefault(); setDropdownId(null); handleDeleteProject(item.id); }}>
                                                                                        <i className="fas fa-trash mr-2"></i>Delete Project
                                                                                    </a>
                                                                                </div>
                                                                            </>,
                                                                            document.body
                                                                        )}
                                                                    </div>
                                                                    <div className="text-dark mt-1" style={{fontSize: '13px', lineHeight: '1.3'}}>
                                                                        {item.isSub ? <span className="text-muted ml-2">↳ {item.title}</span> : item.title}
                                                                    </div>
                                                                </div>
                                                                {!item.isSub && (
                                                                    <button className="btn btn-link p-0 text-dark ml-2" title={item.hasChild ? "View Children" : "Expand"} onClick={() => toggleExpand(item.id)}>
                                                                        <i className={`fa ${
                                                                            item.hasChild 
                                                                                ? (expandedProjects[item.id] ? 'fa-angle-double-down' : 'fa-angle-double-right') 
                                                                                : (expandedProjects[item.id] ? 'fa-angle-down' : 'fa-angle-right')
                                                                        } fa-lg`}></i>
                                                                    </button>
                                                                )}
                                                            </div>
                                                        </td>
                                                        <td>{item.project_manager || 'N/A'}</td>
                                                        <td>{item.clients?.name || 'N/A'}</td>
                                                        <td style={{textAlign: "center"}}>{item.country || 'N/A'}</td>
                                                        <td style={{textAlign: "center"}}>{item.stats?.clicks || 0}</td>
                                                        <td style={{textAlign: "center"}}>{item.stats?.completes || 0}</td>
                                                        <td style={{textAlign: "center"}}>{item.stats?.terminates || 0}</td>
                                                        <td style={{textAlign: "center"}}>{item.stats?.overQuota || 0}</td>
                                                        <td style={{textAlign: "center"}}>{item.stats?.dropouts || 0}</td>
                                                        <td style={{textAlign: "center"}}>{item.stats?.securityFails || 0}</td>
                                                        <td style={{textAlign: "center"}}>{Math.max(0, (item.quota || 0) - (item.stats?.completes || 0))}</td>
                                                        <td style={{textAlign: "center"}}>{item.stats?.clicks ? Math.round(((item.stats?.completes || 0) / item.stats.clicks) * 100) : 0}</td>
                                                        <td style={{textAlign: "center"}}>{item.loi || '0'}</td>
                                                        <td style={{textAlign: "center"}}>
                                                            {item.api_survey ? <i className="fas fa-plug text-primary" title="API Project"></i> : <i className="fas fa-minus text-muted"></i>}
                                                        </td>
                                                        <td style={{textAlign: "center", whiteSpace: "nowrap"}}>
                                                            {!item.isSub && (
                                                                <Link href={`/projects/create/child?parent_id=${item.id}`} className="btn btn-sm btn-info mr-1 mb-1" title="Add Child">
                                                                    <i className="fa fa-plus"></i>
                                                                </Link>
                                                            )}
                                                            <Link
                                                                href={`/projects/${item.id}/edit`}
                                                                className="btn btn-sm btn-warning mr-1 mb-1"
                                                                title="Edit"
                                                            >
                                                                <i className="fa fa-edit"></i>
                                                            </Link>
                                                            <button 
                                                                className="btn btn-sm btn-danger"
                                                                title="Delete"
                                                                onClick={() => handleDeleteProject(item.id)}
                                                            >
                                                                <i className="fas fa-trash"></i>
                                                            </button>
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Tracking Link Modal */}
            {linkModalProject && (
                <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }} tabIndex="-1">
                    <div className="modal-dialog modal-lg modal-dialog-centered">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h4 className="modal-title">Tracking Links - {linkModalProject.title}</h4>
                                <button type="button" className="close" onClick={() => setLinkModalProject(null)}>
                                    <span>&times;</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <div className="form-group">
                                    <label>Select Mapped Supplier (Optional)</label>
                                    <select 
                                        className="form-control"
                                        value={selectedSupplierId}
                                        onChange={(e) => setSelectedSupplierId(e.target.value)}
                                    >
                                        <option value="">-- Generic Link (No Supplier) --</option>
                                        {projectMappings.map(m => (
                                            <option key={m.id} value={m.unique_code}>{m.suppliers?.name}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="form-group mt-3">
                                    <label>Live Survey URL (Send to Suppliers):</label>
                                    <div className="input-group">
                                        <input 
                                            type="text" 
                                            className="form-control" 
                                            readOnly 
                                            value={selectedSupplierId ? `${baseUrl}/r/${selectedSupplierId}?pid=[PID]` : `${baseUrl}/api/survey?project_id=${linkModalProject.id}&pid=[PID]`}
                                        />
                                        <div className="input-group-append">
                                            <button 
                                                className="btn btn-primary" 
                                                onClick={() => {
                                                    const url = selectedSupplierId ? `${baseUrl}/r/${selectedSupplierId}?pid=[PID]` : `${baseUrl}/api/survey?project_id=${linkModalProject.id}&pid=[PID]`;
                                                    navigator.clipboard.writeText(url);
                                                    alert("Copied to clipboard!");
                                                }}
                                            >
                                                Copy
                                            </button>
                                        </div>
                                    </div>
                                    <small className="text-muted mt-1 d-block">
                                        Note: Suppliers should replace <code>[PID]</code> with their actual Respondent ID macro.
                                    </small>
                                </div>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" onClick={() => setLinkModalProject(null)}>Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            )}


        </div>
    );
}
