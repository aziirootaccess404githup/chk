"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { getVendorProjectMatrix } from '@/app/actions/reports';

export default function VendorMatrix() {
    const [matrix, setMatrix] = useState({ suppliers: [], projects: [], cells: {} });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function load() {
            const res = await getVendorProjectMatrix();
            if (res.success) setMatrix(res.data);
            setLoading(false);
        }
        load();
    }, []);

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><a href="/">Home</a></li>
                            <li className="breadcrumb-item active">Vendor × Project Matrix</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">🔲 Vendor × Project Matrix</h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <p className="text-muted mb-3">Har-vendor-ne-har-project-pe-kitne-clicks/completes-diye — ek-nazar-mein. ⏸ badge-matlab-us-specific-vendor-project-mapping-pause-hai.</p>

                        {loading ? (
                            <p className="text-center text-muted">Loading...</p>
                        ) : matrix.suppliers.length === 0 || matrix.projects.length === 0 ? (
                            <p className="text-center text-muted">Abhi-tak-koi-vendor-ya-project-data-nahi-hai.</p>
                        ) : (
                        <div style={{ overflowX: 'auto', border: '1px solid #e2e8f0', borderRadius: '10px' }}>
                            <table style={{ borderCollapse: 'collapse', width: 'max-content' }}>
                                <thead>
                                    <tr>
                                        <th style={{ padding: '8px 12px', fontSize: '11px', background: '#f8faff', textAlign: 'left', position: 'sticky', left: 0, zIndex: 2, borderRight: '1px solid #e2e8f0' }}>Vendor</th>
                                        {matrix.projects.map(p => (
                                            <th key={p.id} style={{ padding: '8px 12px', fontSize: '11px', background: '#f8faff', textAlign: 'center', whiteSpace: 'nowrap' }}>{p.title}</th>
                                        ))}
                                    </tr>
                                </thead>
                                <tbody>
                                    {matrix.suppliers.map(v => (
                                        <tr key={v.id}>
                                            <td style={{ padding: '8px 12px', fontSize: '12px', fontWeight: 600, position: 'sticky', left: 0, background: '#fff', borderRight: '1px solid #e2e8f0', whiteSpace: 'nowrap' }}>
                                                <Link href={`/suppliers/${v.id}`}>{v.name}</Link>
                                            </td>
                                            {matrix.projects.map(p => {
                                                const cell = matrix.cells[`${v.id}_${p.id}`];
                                                return (
                                                    <td key={p.id} style={{ padding: '8px 12px', fontSize: '11px', textAlign: 'center', whiteSpace: 'nowrap' }}>
                                                        {cell ? (
                                                            <>
                                                            <Link href={`/support/redirect-status?sid=${p.id}&vendor=${encodeURIComponent(v.name)}`}>{cell.clicks} / {cell.completes}</Link>
                                                                {cell.paused && <span title="Paused" style={{ color: '#f59e0b', marginLeft: '4px' }}>⏸</span>}
                                                            </>
                                                        ) : (
                                                            <span style={{ color: '#cbd5e1' }}>—</span>
                                                        )}
                                                    </td>
                                                );
                                            })}
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
