"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { getClients, updateClient, deleteClient, generateClientCode } from '@/app/actions/clients';
import { countries } from '@/utils/countries';

export default function ClientList() {
    const [searchTerm, setSearchTerm] = useState("");
    const [filterStatus, setFilterStatus] = useState("Total");
    const [clients, setClients] = useState([]);
    const [loading, setLoading] = useState(true);

    const [editModalClient, setEditModalClient] = useState(null);
    const [editSaving, setEditSaving] = useState(false);

    function getCountryName(code) {
        const c = countries.find(x => x.code === code);
        return c ? c.name : (code || 'N/A');
    }

    async function fetchClients() {
        setLoading(true);
        const result = await getClients();
        if (result.success) {
            setClients(result.data);
        }
        setLoading(false);
    }

    useEffect(() => {
        fetchClients();
    }, []);

    const [redirectModalClient, setRedirectModalClient] = useState(null);
    const [redirectUrls, setRedirectUrls] = useState([]);

    const handleGetRedirectCode = async (client) => {
        const result = await generateClientCode(client.id);
        if (result.success) {
            const base = `${window.location.origin}/client-redirect`;
            const code = result.data;
            setRedirectUrls([
                { label: 'Complete', url: `${base}/complete?client=${code}&uid=[UID]` },
                { label: 'Terminate', url: `${base}/terminate?client=${code}&uid=[UID]` },
                { label: 'OverQuota', url: `${base}/quota-full?client=${code}&uid=[UID]` },
                { label: 'Quality Fail', url: `${base}/quality-check?client=${code}&uid=[UID]` },
            ]);
            setRedirectModalClient(client);
        } else {
            alert("Error: " + result.error);
        }
    };

    const handleCopyUrl = (url) => {
        navigator.clipboard.writeText(url);
        alert("Copied!");
    };

    const activeCount = clients.filter(c => c.status === 'Active').length;
    const inactiveCount = clients.filter(c => c.status === 'Inactive').length;
    const totalCount = clients.length;

    const filteredClients = clients.filter(c => {
        const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus = filterStatus === "Total" || c.status === filterStatus;
        return matchesSearch && matchesStatus;
    });

    return (
        <div className="tabPanelWraps">
            <div className="row">
                <div className="col-12">
                    <div className="page-title-box">
                        <div className="page-title-right">
                            <ol className="breadcrumb m-0">
                                <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                                <li className="breadcrumb-item active">Client</li>
                            </ol>
                        </div>
                        <h4 className="page-title">Client</h4>
                    </div>
                </div>
            </div>

            <div className="row">
                <div className="col-md-9 col-sm-12 col-12">
                    <ul className="numTabSM">
                        <li className={`totalNM ${filterStatus === 'Total' ? 'active' : ''}`} onClick={() => setFilterStatus('Total')} style={{cursor: 'pointer'}}>
                            <p className="m-0"> Total-<span>{totalCount}</span> </p>
                        </li>
                        <li className={`bgA ${filterStatus === 'Active' ? 'active' : ''}`} onClick={() => setFilterStatus('Active')} style={{cursor: 'pointer'}}>
                            <p className="m-0"> <i className="fa fa-square active" aria-hidden="true"></i> Active-<span>{activeCount}</span> </p>
                        </li>
                        <li className={`bgA ${filterStatus === 'Inactive' ? 'active' : ''}`} onClick={() => setFilterStatus('Inactive')} style={{cursor: 'pointer'}}>
                            <p className="m-0"> <i className="fa fa-square inActive" aria-hidden="true"></i> InActive-<span>{inactiveCount}</span> </p>
                        </li>
                    </ul>
                </div>
                <div className="col-md-3 col-sm-12 col-12">
                    <div className="row justify-content-end numTabSMSearch">
                        <form className="col-12 app-search" onSubmit={(e) => e.preventDefault()}>
                            <div className="app-search-box">
                                <div className="input-group">
                                    <input 
                                        type="text" 
                                        className="form-control" 
                                        placeholder="Search..." 
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                    />
                                    {searchTerm && (
                                        <a className="clearCrossIcon" onClick={() => setSearchTerm("")} style={{cursor: 'pointer'}}>
                                            <i className="fa fa-times-circle" aria-hidden="true"></i>
                                        </a>
                                    )}
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div className="row">
                <div className="col-12">
                    <div className="card">
                        <div className="card-body">
                            <div className="responsive-table-plugin">
                                <div className="table-rep-plugin">
                                    <div className="table-responsive">
                                        <table className="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>S.No.</th>
                                                    <th>Action</th>
                                                    <th style={{minWidth: "70px", maxWidth:"100px", textAlign: "center"}}>ClientCode</th>
                                                    <th style={{minWidth: "150px", maxWidth:"200px", textAlign: "left"}}>ClientName</th>
                                                    <th>Country</th>
                                                    <th>TotalProject</th>
                                                    <th>ActiveProject</th>
                                                    <th>InvoicedProject</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {loading ? (
                                                    <tr><td colSpan="8" className="text-center">Loading clients...</td></tr>
                                                ) : filteredClients.length === 0 ? (
                                                    <tr><td colSpan="8" className="text-center">No clients found.</td></tr>
                                                ) : filteredClients.map((client, index) => (
                                                    <tr key={client.id}>
                                                        <td>{index + 1}</td>
                                                        <td>
                                                            <div className="btn-group btn-group-sm" style={{gap: '5px'}}>
                                                                <button 
                                                                    className="btn btn-sm btn-primary tooltipBTNA" 
                                                                    title="Edit"
                                                                    onClick={() => setEditModalClient(client)}
                                                                >
                                                                    <i className="fas fa-edit"></i>
                                                                </button>
                                                                <button 
                                                                    className="btn btn-sm btn-danger tooltipBTNA" 
                                                                    title="Delete"
                                                                    onClick={async () => {
                                                                        if (confirm(`Are you sure you want to delete ${client.name}?`)) {
                                                                            const res = await deleteClient(client.id);
                                                                            if (res.success) {
                                                                                fetchClients();
                                                                            } else {
                                                                                alert("Error: " + res.error);
                                                                            }
                                                                        }
                                                                    }}
                                                                >
                                                                    <i className="fas fa-trash"></i>
                                                                </button>
                                                                <button
                                                                    className="btn btn-sm btn-info tooltipBTNA"
                                                                    title="Get Permanent Redirect Link"
                                                                    onClick={() => handleGetRedirectCode(client)}
                                                                >
                                                                    <i className="fas fa-link"></i>
                                                                </button>
                                                            </div>
                                                        </td>
                                                        <td style={{textAlign: "center"}}>{"C" + client.id.substring(0,4)}</td>
                                                        <td style={{textAlign: "left"}}>{client.name}</td>
                                                        <td>{getCountryName(client.country)}</td>
                                                        <td>0</td>
                                                        <td>0</td>
                                                        <td>0</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Edit Modal */}
            {editModalClient && (
                <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog modal-lg">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">Edit Client: {editModalClient.name}</h5>
                                <button type="button" className="close" onClick={() => setEditModalClient(null)}>
                                    <span>&times;</span>
                                </button>
                            </div>
                            <form onSubmit={async (e) => {
                                e.preventDefault();
                                setEditSaving(true);
                                const formData = new FormData(e.target);
                                const payload = {
                                    name: formData.get('name'),
                                    company: formData.get('company'),
                                    email: formData.get('email'),
                                    phone: formData.get('phone'),
                                    website: formData.get('website'),
                                    status: formData.get('status'),
                                    country: formData.get('country'),
                                    address: formData.get('address'),
                                    link_type: formData.get('link_type') || 'Dynamic',
                                    complete_url: formData.get('complete_url'),
                                    terminate_url: formData.get('terminate_url'),
                                    quotafull_url: formData.get('quotafull_url'),
                                    quality_url: formData.get('quality_url'),
                                    s2s_outbound_enabled: formData.get('s2s_outbound_enabled') === 'on',
                                    s2s_outbound_endpoint: formData.get('s2s_outbound_endpoint'),
                                    s2s_outbound_token: formData.get('s2s_outbound_token'),
                                };
                                const result = await updateClient(editModalClient.id, payload);
                                if (result.success) {
                                    alert('Client updated successfully');
                                    setEditModalClient(null);
                                    fetchClients();
                                } else {
                                    alert('Error: ' + result.error);
                                }
                                setEditSaving(false);
                            }}>
                                <div className="modal-body">
                                    <div className="row">
                                        <div className="col-sm-6 form-group">
                                            <label>Client Name</label>
                                            <input type="text" className="form-control" name="name" defaultValue={editModalClient.name} required />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Contact Person (Company)</label>
                                            <input type="text" className="form-control" name="company" defaultValue={editModalClient.company || ''} />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Email</label>
                                            <input type="email" className="form-control" name="email" defaultValue={editModalClient.email || ''} />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Phone</label>
                                            <input type="text" className="form-control" name="phone" defaultValue={editModalClient.phone || ''} />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Website</label>
                                            <input type="url" className="form-control" name="website" defaultValue={editModalClient.website || ''} />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Status</label>
                                            <select className="form-control" name="status" defaultValue={editModalClient.status || 'Active'}>
                                                <option value="Active">Active</option>
                                                <option value="Inactive">Inactive</option>
                                            </select>
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Country</label>
                                            <select className="form-control" name="country" defaultValue={editModalClient.country || ''}>
                                                <option value="">-- Select Country --</option>
                                                {countries.map(c => (
                                                    <option key={c.code} value={c.code}>{c.name}</option>
                                                ))}
                                            </select>
                                        </div>
                                        <div className="col-sm-12 form-group">
                                            <label>Address</label>
                                            <textarea className="form-control" name="address" defaultValue={editModalClient.address || ''} rows="2"></textarea>
                                        </div>
                                        <div className="col-sm-12 mt-2">
                                            <h6 className="header-title mb-2">Default Redirect URLs</h6>
                                        </div>
                                        <div className="col-sm-12 form-group">
                                            <label className="control-label">Link Type</label>
                                            <div className="d-flex" style={{gap: '15px'}}>
                                                <div className="custom-control custom-radio">
                                                    <input type="radio" id="editLinkStatic" name="link_type" value="Static" className="custom-control-input" defaultChecked={editModalClient.link_type === 'Static'} />
                                                    <label className="custom-control-label" htmlFor="editLinkStatic" style={{cursor: 'pointer'}}>Static</label>
                                                </div>
                                                <div className="custom-control custom-radio">
                                                    <input type="radio" id="editLinkDynamic" name="link_type" value="Dynamic" className="custom-control-input" defaultChecked={editModalClient.link_type !== 'Static'} />
                                                    <label className="custom-control-label" htmlFor="editLinkDynamic" style={{cursor: 'pointer'}}>Dynamic</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Complete URL</label>
                                            <input type="url" className="form-control" name="complete_url" defaultValue={editModalClient.complete_url || ''} />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Terminate URL</label>
                                            <input type="url" className="form-control" name="terminate_url" defaultValue={editModalClient.terminate_url || ''} />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Quota Full URL</label>
                                            <input type="url" className="form-control" name="quotafull_url" defaultValue={editModalClient.quotafull_url || ''} />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Quality Check URL</label>
                                            <input type="url" className="form-control" name="quality_url" defaultValue={editModalClient.quality_url || ''} />
                                        </div>
                                    </div>
                                    <hr />
                                    <h6>🔐 Server-to-Server (S2S) Outbound Reporting</h6>
                                    <p className="text-muted" style={{ fontSize: '12px' }}>
                                        If this client (e.g. a marketplace like Cint/Lucid) wants final respondent status reported via an authenticated API call instead of (or alongside) a browser redirect, configure it here. Fires automatically whenever a respondent completes on any project under this client.
                                    </p>
                                    <div className="row">
                                        <div className="col-sm-3 form-group">
                                            <label>Enable S2S</label>
                                            <div>
                                                <input type="checkbox" name="s2s_outbound_enabled" defaultChecked={editModalClient.s2s_outbound_enabled || false} /> Enabled
                                            </div>
                                        </div>
                                        <div className="col-sm-5 form-group">
                                            <label>S2S Endpoint URL</label>
                                            <input type="url" className="form-control" name="s2s_outbound_endpoint" placeholder="https://s2s.example.com/fulfillment/respondents" defaultValue={editModalClient.s2s_outbound_endpoint || ''} />
                                        </div>
                                        <div className="col-sm-4 form-group">
                                            <label>Bearer Token</label>
                                            <input type="text" className="form-control" name="s2s_outbound_token" placeholder="Token this client gave you" defaultValue={editModalClient.s2s_outbound_token || ''} />
                                        </div>
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" onClick={() => setEditModalClient(null)}>Close</button>
                                    <button type="submit" className="btn btn-primary" disabled={editSaving}>
                                        {editSaving ? "Saving..." : "Save changes"}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            )}

            {redirectModalClient && (
                <div className="modal show d-block" tabIndex="-1" style={{ background: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog modal-lg">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">Permanent Redirect Links — {redirectModalClient.name}</h5>
                                <button type="button" className="close" onClick={() => setRedirectModalClient(null)}>&times;</button>
                            </div>
                            <div className="modal-body">
                                <p className="text-muted" style={{fontSize: '12px'}}>
                                    Ye 4 URLs har naye project ke saath dobara nahi banane padenge — same URL har project ke liye kaam karega (bas [UID] ki jagah asli respondent-ID daalna hoga).
                                </p>
                                {redirectUrls.map((item) => (
                                    <div key={item.label} className="form-group">
                                        <label>{item.label}</label>
                                        <div className="input-group">
                                            <input type="text" className="form-control" readOnly value={item.url} />
                                            <div className="input-group-append">
                                                <button className="btn btn-outline-secondary" onClick={() => handleCopyUrl(item.url)}>Copy</button>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" onClick={() => setRedirectModalClient(null)}>Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
