<?php
// ============================================================
// PanelEngine Survey Panel — track.php
// Dynamic status tracker — called by static HTML pages OR directly
// URL: /panelengine/track.php?status=complete&sid=RP001&uid=UID&loi=120
// Add &ajax=1 to get a JSON response instead of a redirect (used by
// the static pages/*.html confirmation pages to display respondent info).
//
// IMPORTANT: The "sid" in the incoming URL is only a starting hint — see
// the matching note in end.php. The real/internal sid is always resolved
// from our own rp_leads record and is what gets used/displayed from here on.
// ============================================================
require_once __DIR__ . '/config.php';

date_default_timezone_set('Asia/Kolkata');

$status  = trim($_GET['status'] ?? '');
$url_sid = trim($_GET['sid']    ?? ''); // hint only
// Accept whichever parameter name the client's platform actually sends the
// respondent ID in — uid is our own standard, the rest are common alternates.
$enc_uid = trim($_GET['uid'] ?? $_GET['rid'] ?? $_GET['toid'] ?? $_GET['identifier'] ?? $_GET['tid'] ?? $_GET['pid'] ?? '');
$loi     = isset($_GET['loi']) && is_numeric($_GET['loi']) ? (int)$_GET['loi'] : null;
$is_ajax = isset($_GET['ajax']);

// Allowed statuses. IMPORTANT: if the incoming status is missing or doesn't
// match anything we recognize (a client sent a typo'd status name, only
// configured 3 of their 4 usual redirect URLs, or is sending a status we
// don't know), we do NOT guess and default to 'complete' — that would
// silently mark an unknown outcome as a genuine completion. Matches the
// same fix already present in end.php, applied here too since track.php
// does its own DB-write before ever handing off to end.php — by that
// point the damage from defaulting to 'complete' would already be done.
$valid = ['complete','terminate','overquota','quality_fail','qc','quotafull'];
$is_unmatched_status = !in_array($status, $valid);
if ($is_unmatched_status) {
    $status = 'unmatched';
} else {
    // Normalize
    if ($status === 'qc')        $status = 'quality_fail';
    if ($status === 'quotafull') $status = 'overquota';
}

$ip  = rp_get_ip();
$ua  = $_SERVER['HTTP_USER_AGENT'] ?? '';
$geo = rp_geo($ip);
$dev = rp_device();
$br  = rp_browser();
$db  = rp_db();
$sid = $url_sid; // may be corrected below once we find the real lead

// ── Resolve original UID (the incoming uid param may be encrypted) ───
$proj = null;
if ($sid) {
    $ps = $db->prepare("SELECT * FROM rp_projects WHERE sid = ? LIMIT 1");
    $ps->execute([$sid]);
    $proj = $ps->fetch();
}
$original_uid = $enc_uid;
if ($proj && !empty($proj['encrypt_uid'])) {
    $decrypted = rp_decrypt($enc_uid, $sid);
    if ($decrypted) {
        $original_uid = $decrypted;
    } else {
        $mr = $db->prepare("SELECT original_uid FROM rp_uid_mapping WHERE encrypted_uid = ? AND sid = ? LIMIT 1");
        $mr->execute([$enc_uid, $sid]);
        $mrow = $mr->fetch();
        if ($mrow) {
            $original_uid = $mrow['original_uid'];
        } else {
            // Mapping lookup without sid filter — covers a client sending a
            // different/wrong sid than what we used originally (encryption key
            // is sid-dependent, so a mismatched sid breaks decryption above).
            $mr2 = $db->prepare("SELECT original_uid, sid FROM rp_uid_mapping WHERE encrypted_uid = ? ORDER BY id DESC LIMIT 1");
            $mr2->execute([$enc_uid]);
            $mrow2 = $mr2->fetch();
            if ($mrow2) {
                $original_uid = $mrow2['original_uid'];
                $sid = $mrow2['sid']; // correct the sid to our real internal one
            }
        }
    }
}

// ── STATUS UPDATE ──────────────────────────────────────────────
$vendor_id = null;
try {
    // Try by original_uid + sid (normal case — client sent the correct sid)
    $lc = $db->prepare("SELECT id, sid, vendor_id FROM rp_leads WHERE original_uid = ? AND sid = ? ORDER BY id DESC LIMIT 1");
    $lc->execute([$original_uid, $sid]);
    $existing = $lc->fetch();

    if (!$existing) {
        $lc2 = $db->prepare("SELECT id, sid, vendor_id FROM rp_leads WHERE encrypted_uid = ? AND sid = ? ORDER BY id DESC LIMIT 1");
        $lc2->execute([$enc_uid, $sid]);
        $existing = $lc2->fetch();
    }

    if (!$existing) {
        // Further fallback: same UID, ANY project — our own stored sid
        // (from when the respondent first clicked in) always wins over
        // whatever sid the client's system sent back.
        $lc3 = $db->prepare("SELECT id, sid, vendor_id FROM rp_leads WHERE original_uid = ? OR encrypted_uid = ? ORDER BY id DESC LIMIT 1");
        $lc3->execute([$original_uid, $enc_uid]);
        $existing = $lc3->fetch();
    }

    // If found, its stored sid is the ONLY authoritative sid from here on.
    if ($existing) {
        $sid = $existing['sid'];
        if (!$proj || $proj['sid'] !== $sid) {
            $ps2 = $db->prepare("SELECT * FROM rp_projects WHERE sid = ? LIMIT 1");
            $ps2->execute([$sid]);
            $proj = $ps2->fetch();
        }
    }

    if ($existing) {
        // Update existing lead
        $db->prepare("UPDATE rp_leads SET status=?, end_time=NOW(), loi_seconds=? WHERE id=?")
           ->execute([$status, $loi, $existing['id']]);
        $vendor_id = $existing['vendor_id'] ?? null;
    } else {
        // No existing lead anywhere — genuinely new direct hit. No internal
        // record exists yet, so the URL's sid is the best information
        // available and becomes the internal sid going forward.
        $db->prepare("INSERT INTO rp_leads (sid, original_uid, encrypted_uid, status, ip, country, city, device, browser, user_agent, loi_seconds, is_duplicate, source, entry_time, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,0,'direct',NOW(),NOW())")
           ->execute([$sid, $original_uid, $enc_uid, $status, $ip, $geo['country'], $geo['city'], $dev, $br, substr($ua,0,500), $loi]);
    }
} catch (PDOException $e) {
    error_log("PanelEngine track.php error: " . $e->getMessage());
}

// ── VENDOR REDIRECT MODE (non-ajax only — a real page navigation) ────
// If this vendor wants respondents sent straight to their own end page,
// do that now instead of showing ours. The redirect itself is the
// vendor's notification, so we skip the separate background postback.
if (!$is_ajax) {
    $redirect_target = rp_vendor_redirect_target($db, $vendor_id, $status, $sid, $original_uid ?: $enc_uid, $loi);
    if ($redirect_target) {
        header("Location: $redirect_target");
        exit();
    }
}

// Otherwise, silently notify the vendor's tracking system in the background
// (used for both ajax calls from the static pages, and normal show_page mode)
rp_notify_vendor($db, $vendor_id, $status, $sid, $original_uid ?: $enc_uid, $loi);

// ── AJAX MODE: return JSON for static pages to render ─────────
if ($is_ajax) {
    header('Content-Type: application/json');
    echo json_encode([
        'sid'    => $sid,
        'uid'    => $original_uid ?: $enc_uid,
        'status' => $status,
        'ip'     => $ip,
        'time'   => date('d/m/Y, H:i:s'),
    ]);
    exit();
}

// ── REDIRECT TO END PAGE (default/legacy behavior) ────────────
// _via=track tells end.php that we already fired the vendor postback above,
// so it won't notify the vendor a second time when it loads.
header("Location: end.php?status=$status&sid=" . urlencode($sid) . "&uid=" . urlencode($enc_uid) . "&_via=track");
exit();
