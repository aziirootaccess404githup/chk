<?php
// ============================================================
// PanelEngine Survey Panel — end.php
// Status landing page: complete / terminate / overquota / quality_fail
// URL: /panelengine/end.php?status=complete&sid=RP001&uid=ENCRYPTED_UID
//
// IMPORTANT: The "sid" in the incoming URL is only a starting hint.
// The REAL/internal project SID is always resolved from OUR OWN
// database (via the lead created when the respondent first clicked
// in) and is what gets displayed, tracked, and used for vendor
// postback/redirect — never whatever text a client's system happens
// to send back in the sid parameter. This keeps our internal SID
// authoritative even if a client sets their own value there.
// ============================================================
require_once __DIR__ . '/config.php';

date_default_timezone_set('Asia/Kolkata');

$status  = trim($_GET['status'] ?? '');
$url_sid = trim($_GET['sid']    ?? ''); // hint only — see note above
// Accept whichever parameter name the client's platform actually sends the
// respondent ID in — uid is our own standard, the rest are common alternates.
$enc_uid = trim($_GET['uid'] ?? $_GET['rid'] ?? $_GET['toid'] ?? $_GET['identifier'] ?? $_GET['tid'] ?? $_GET['pid'] ?? '');
$already_notified = ($_GET['_via'] ?? '') === 'track'; // track.php already fired the vendor postback/redirect

// ── Status recognition ──────────────────────────────────────────
// Exact names we already support, plus common alternate spellings a
// client's platform might send instead (all map to the SAME 4 real
// outcomes - nothing new is introduced here, just recognized synonyms).
$status_aliases = [
    'complete'      => 'complete',      'success'   => 'complete',   'completed' => 'complete',
    'terminate'     => 'terminate',     'terminated'=> 'terminate',  'term'      => 'terminate',
    'overquota'     => 'overquota',     'quotafull' => 'overquota',  'quota_full'=> 'overquota', 'full' => 'overquota',
    'quality_fail'  => 'quality_fail',  'qc'        => 'quality_fail','quality'  => 'quality_fail',
    'screenout'     => 'quality_fail',  'screened_out' => 'quality_fail', 'disqualified' => 'quality_fail',
];
$status_key = strtolower($status);
$status = $status_aliases[$status_key] ?? null;

// IMPORTANT: if the incoming status is missing or doesn't match anything we
// recognize (e.g. a client only configured 3 of the 4 possible redirect
// URLs, or is sending a status name we don't know), we do NOT guess and
// default to 'complete' - that would silently mark an unknown outcome as
// a successful completion. Instead we treat it as unmatched below: no lead
// status gets changed, no vendor postback fires, and the respondent sees a
// neutral "under review" page instead of a false completion confirmation.
$is_unmatched_status = ($status === null);
if ($is_unmatched_status) $status = 'unmatched';

$db = rp_db();
$original_uid = '';
$project_name = '';
$sid = $url_sid; // may be corrected below once we find the real lead

// ── Fetch project (using the URL hint first, for decryption purposes) ──
$proj = null;
if ($sid) {
    $ps = $db->prepare("SELECT * FROM rp_projects WHERE sid = ? LIMIT 1");
    $ps->execute([$sid]);
    $proj = $ps->fetch();
    if ($proj) $project_name = $proj['project_name'];
}

// ── Decrypt UID ───────────────────────────────────────────────
if ($enc_uid && $sid) {
    if ($proj && empty($proj['encrypt_uid'])) {
        // Raw mode — uid is already original
        $original_uid = $enc_uid;
    } else {
        $original_uid = rp_decrypt($enc_uid, $sid) ?? '';
        // Fallback: check mapping table (sid-scoped first)
        if (!$original_uid) {
            $mr = $db->prepare("SELECT original_uid FROM rp_uid_mapping WHERE encrypted_uid = ? AND sid = ? LIMIT 1");
            $mr->execute([$enc_uid, $sid]);
            $mrow = $mr->fetch();
            if ($mrow) $original_uid = $mrow['original_uid'];
        }
        // Further fallback: mapping table WITHOUT sid filter — covers the case
        // where the client sent a different/wrong sid than what we used originally
        // (the encryption key is sid-dependent, so a mismatched sid breaks decryption above).
        if (!$original_uid) {
            $mr2 = $db->prepare("SELECT original_uid, sid FROM rp_uid_mapping WHERE encrypted_uid = ? ORDER BY id DESC LIMIT 1");
            $mr2->execute([$enc_uid]);
            $mrow2 = $mr2->fetch();
            if ($mrow2) {
                $original_uid = $mrow2['original_uid'];
                $sid = $mrow2['sid']; // correct the sid to our real internal one
            }
        }
    }
}

$ip   = rp_get_ip();
$time = date('d/m/Y, H:i:s');

// ── Update lead status (or create one if it doesn't exist yet) ────────
if ($enc_uid) {
    $lookup_uid = $original_uid ?: $enc_uid;

    // Try by original_uid + sid (normal case — client sent the correct sid)
    $lc = $db->prepare("SELECT id, sid, status, vendor_id FROM rp_leads WHERE original_uid = ? AND sid = ? ORDER BY id DESC LIMIT 1");
    $lc->execute([$lookup_uid, $sid]);
    $lead = $lc->fetch();

    if (!$lead) {
        // Fallback: try by encrypted_uid + sid
        $lc2 = $db->prepare("SELECT id, sid, status, vendor_id FROM rp_leads WHERE encrypted_uid = ? AND sid = ? ORDER BY id DESC LIMIT 1");
        $lc2->execute([$enc_uid, $sid]);
        $lead = $lc2->fetch();
    }

    if (!$lead) {
        // Further fallback: same UID, ANY project — covers a client sending a
        // sid that doesn't match what we have on file. Our own stored sid
        // (from when the respondent first clicked in) always wins.
        $lc3 = $db->prepare("SELECT id, sid, status, vendor_id FROM rp_leads WHERE original_uid = ? OR encrypted_uid = ? ORDER BY id DESC LIMIT 1");
        $lc3->execute([$lookup_uid, $enc_uid]);
        $lead = $lc3->fetch();
    }

    // If we found a lead, its stored sid is the ONLY authoritative sid from here on.
    if ($lead) {
        $sid = $lead['sid'];
        if (!$proj || $proj['sid'] !== $sid) {
            $ps2 = $db->prepare("SELECT * FROM rp_projects WHERE sid = ? LIMIT 1");
            $ps2->execute([$sid]);
            $proj = $ps2->fetch();
            $project_name = $proj ? $proj['project_name'] : $project_name;
        }
    }

    $vendor_id_for_notify = null;

    if ($lead) {
        if (!$is_unmatched_status) {
            // Known status - update normally, exactly as before.
            $db->prepare("UPDATE rp_leads SET status = ?, end_time = NOW(), loi_seconds = TIMESTAMPDIFF(SECOND, entry_time, NOW()) WHERE id = ?")
               ->execute([$status, $lead['id']]);
        }
        // Unmatched status on an EXISTING lead: leave it completely untouched
        // (whatever status it already had stays as-is) - we don't know the
        // real outcome, so we don't overwrite good data with a guess.
        $vendor_id_for_notify = $lead['vendor_id'] ?? null;
    } else {
        // No existing lead at all — this end URL was hit directly with no
        // prior click ever tracked (e.g. the client's platform doesn't use
        // our entry link, or this is a manual test). Create the lead now
        // so it still shows up on the dashboard instead of being silently lost.
        // There's genuinely no internal record yet, so the URL's sid is the
        // best information available and becomes the internal sid going forward.
        // If the status is unmatched, it's stored as 'unmatched' (not folded
        // into 'complete') so it never inflates real completion counts.
        $geo = rp_geo($ip);
        $dev = rp_device();
        $br  = rp_browser();
        $db->prepare("INSERT INTO rp_leads
            (sid, original_uid, encrypted_uid, status, ip, country, city, device, browser, is_duplicate, source, entry_time, end_time, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,0,'direct',NOW(),NOW(),NOW())")
           ->execute([$sid, $lookup_uid, $enc_uid, $status, $ip, $geo['country'], $geo['city'], $dev, $br]);
    }

    if (!$already_notified && !$is_unmatched_status) {
        // Vendor postback/redirect only fires for a status we actually
        // recognize - we don't want to tell a vendor's system "complete"
        // (or any other outcome) when we genuinely don't know what happened.
        $redirect_target = rp_vendor_redirect_target($db, $vendor_id_for_notify, $status, $sid, $lookup_uid);
        if ($redirect_target) {
            header("Location: $redirect_target");
            exit();
        }
        rp_notify_vendor($db, $vendor_id_for_notify, $status, $sid, $lookup_uid);
    }
}


// ── Status config ────────────────────────────────────────────
$config = [
    'complete' => [
        'badge'    => 'COMPLETE',
        'color'    => '#16a34a',
        'color_rgb'=> '22,163,74',
        'heading'  => 'Response Recorded!',
        'msg'      => 'Your response has been recorded and verified. Thank you for taking the time to complete this survey — your input is valuable to our research.',
        'icon'     => '<path d="M20 6L9 17l-5-5" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>',
        'label'    => 'COMPLETE',
    ],
    'terminate' => [
        'badge'    => 'TERMINATED',
        'color'    => '#d97706',
        'color_rgb'=> '217,119,6',
        'heading'  => 'Session Ended',
        'msg'      => 'We were unable to continue your participation based on the screening criteria for this study. Thank you for your time — this helps us maintain the quality of our research.',
        'icon'     => '<path d="M6 6l12 12M18 6L6 18" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>',
        'label'    => 'TERMINATE',
    ],
    'overquota' => [
        'badge'    => 'QUOTA FULL',
        'color'    => '#2563eb',
        'color_rgb'=> '37,99,235',
        'heading'  => 'This Survey Is Now Full',
        'msg'      => 'Thank you for your interest — this study has already reached the number of responses needed. Please check back for future opportunities to participate.',
        'icon'     => '<path d="M12 8v5M12 16h.01" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="12" cy="12" r="9" stroke="white" stroke-width="2"/>',
        'label'    => 'OVERQUOTA',
    ],
    'quality_fail' => [
        'badge'    => 'QUALITY CHECK',
        'color'    => '#dc2626',
        'color_rgb'=> '220,38,38',
        'heading'  => 'Thank You For Your Time',
        'msg'      => 'Unfortunately, your responses did not pass our quality validation checks for this study. Your participation is still appreciated.',
        'icon'     => '<path d="M12 9v4M12 17h.01" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" stroke="white" stroke-width="2" stroke-linejoin="round"/>',
        'label'    => 'QUALITY FAIL',
    ],
    'unmatched' => [
        // Shown when the incoming status is missing or not one we recognize.
        // Deliberately neutral - does not claim complete/terminate/etc, since
        // we genuinely don't know the real outcome in this case.
        'badge'    => 'UNDER REVIEW',
        'color'    => '#64748b',
        'color_rgb'=> '100,116,139',
        'heading'  => 'Thank You',
        'msg'      => 'Your response has been received and is currently under review. If you believe you did not qualify or would like to try again, please contact the panel provider.',
        'icon'     => '<circle cx="12" cy="12" r="9" stroke="white" stroke-width="2"/><path d="M12 7v6l4 2" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
        'label'    => 'UNDER REVIEW',
    ],
];
$c = $config[$status] ?? $config['complete'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="referrer" content="no-referrer">
<title><?= htmlspecialchars($c['badge']) ?> — Matrix World Research</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html{height:100%}
body{min-height:100vh;min-height:100dvh;width:100%;background:#f4f6fb;font-family:'Segoe UI',sans-serif;display:flex;align-items:center;justify-content:center;color:#0f172a;padding:24px}
.card{background:#ffffff;border:1px solid rgba(15,23,42,0.08);border-radius:20px;max-width:760px;width:100%;box-shadow:0 12px 40px rgba(15,23,42,0.08);margin:0 auto;overflow:hidden}
.top{display:flex;flex-direction:column;align-items:center;gap:18px;padding:36px 40px 0;text-align:center}
.logo{max-width:170px;width:100%;height:auto;display:block}
.badge{display:inline-flex;align-items:center;gap:9px;border-radius:8px;padding:11px 28px;font-size:15px;font-weight:700;letter-spacing:2px;color:<?= $c['color'] ?>;background:rgba(<?= $c['color_rgb'] ?>,0.1)}
.badge::before{content:'';width:9px;height:9px;border-radius:50%;background:<?= $c['color'] ?>}
.hero{padding:36px 40px 8px;display:flex;align-items:center;gap:28px}
.icon-wrap{flex-shrink:0;width:84px;height:84px;border-radius:50%;background:<?= $c['color'] ?>;display:flex;align-items:center;justify-content:center;box-shadow:0 8px 24px rgba(<?= $c['color_rgb'] ?>,0.3)}
.icon-wrap svg{width:38px;height:38px}
.hero-text h1{font-size:32px;font-weight:800;color:#0f172a;margin-bottom:10px;letter-spacing:-0.5px}
.hero-text p{color:#64748b;font-size:15px;line-height:1.7}
.record{margin:28px 40px 0;border:1px solid rgba(15,23,42,0.08);border-radius:12px;overflow:hidden}
.record-table{width:100%;border-collapse:collapse}
.record-table th{background:<?= $c['color'] ?>;padding:12px 16px;font-size:10px;letter-spacing:1.5px;color:#ffffff;font-weight:700;text-align:left}
.record-table td{padding:14px 16px;font-size:13px;color:#334155;background:#f8fafc;border-top:1px solid rgba(15,23,42,0.06)}
.uid-val{font-family:'Consolas',monospace;font-size:12px}
.sid-val{font-weight:700;color:<?= $c['color'] ?>}
.status-pill{display:inline-flex;align-items:center;gap:5px;border-radius:5px;padding:3px 10px;font-size:10px;font-weight:700;color:#ffffff;background:<?= $c['color'] ?>}
.footer{margin-top:28px;padding:20px 40px 28px;border-top:1px solid rgba(15,23,42,0.08);font-size:12px;color:#94a3b8;line-height:1.9;text-align:center}
.footer a{color:#2563eb;text-decoration:none;font-weight:600}
.footer a:hover{text-decoration:underline}
@media (max-width:520px){
  .hero{flex-direction:column;text-align:center;gap:16px}
}
</style>
</head>
<body>
<div class="card">

  <div class="top">
    <img src="data:image/webp;base64,UklGRjgkAABXRUJQVlA4ICwkAACQewCdASpoAZYAPjEWiUMiISEUul3gIAMEpu3V7xo/+i7HuY/KX6n+2+k/yL1xec/EfB81t5Y/lf63/rP6x/cf2Q+d3/E/4H9V93X9e/YD8//oH/ST/W/1Lry+YL+k/3j/wf5/3Uv9n+p3vL/Xn9h/8t8gH9D/yH/o9p7/ueyl6Bv7seml+1fwp/1T/c/tN7QH/51i3y//Wfx38KP65/Y/2Z/cr2J/F/nn6r+R37z9J3pv/nehv8Y+sX2T+7/tF/dv2Y+ZP8h+I/5Fe6fx8/fvUC/E/5B/b/7R+yX9Y/afkgNf8wX2J+gf4T/A/uF/a/TN/svQz64/5/7hvsA/jv9D/w35rf5j///W3/A8Gj7p/tf2F+AH+R/1T/T/3/++/sl9MH8t/y/8b+Vntc/Lv8B/yf8t/nv20+wn+Pf0j/Yf3H/K/9//Nf///6/dD7IPRG/Y//5n3z2Y/7aEzAA2RbsXdH/ZxuOpd4lEdNn//CCFNr+hrgR6p6NLgfzbHml+kjxL0/TYaYINZ9YN8GJu7QyuGdLUicNFGHzWPK781wI9R1aWjrpMPQgx12SBbTSPEJp0/zTAZBoElRIKfcRlgJ5wKuyBwCMfvnQBR9owumKbBAenoiaxGsstQg0+Q2tC3Z2NkRR4VVdXfF1kTDAaEFV7/hARJU8votWZTmz1S7+fmLIcpFdVH6QLdWtVfZSNR2LbK4SOTFHnaajXy/PIjklbcWyPn6uvd45vwWa+eqFzh7T3q2YkuWGhJ82fefSr2MoZCbSX2jxNdjPuS+hcO292fbjnUI3mJb3zbDEVn0y5xhIDqG7bCp5W6sy810ilMTfl8R/BTZBE5P3vuA9swCXKWRBJr5Ui2Xzq4b20c9dMk/bXa3Iz8nMiywjZZtP1PAPvJeIk2jfSAhboUua0VXMZ7s9bd71w/WgZ3NQBc95vZU+OHw1ohrqNhrVft+8BgFfkQqlq2d+z1phtAcVo1MH0JLup2ECb90BRbAMGPUU2haUNhzN3b67NAa7zBVkf9i38Tzp6K9YokZa6RiNY6ozPnEKfsb9QI+h64T74v7Gs9EdX8mym3eEZeJZ7fTTUix8idpBZ+HaGJ8VWp6RRVKbIAFjEB826S4LI9MP23FAHByR5l7IUP3sUNda1JzEammrJ/wJJt1H+3T3NmQMnaeNKJo1ekvDT5leSuAbMvhRy3fCnCQDfJSsSceONlfvxcaP/kcn522d00lGuj/ylYINzCB/OfAPJ2+cAyuETpaGNvQaNT3UaxXRI/1FT8ifW34Ivt34ddkoCZvYxlOSvr3ksgztKWY2seXbcqmpSsrvzXAj1T0UgAP7+3XoxAYBMjmU8lWHODUejfcRyFLqF6yY3xPaJEb9WNJsLuIRineoX3PE7cDnXnYgHQl5ygHf/zK2YRka/9OeAxpLIMyQNSa7LEk4ChWhdlhoNUMeX5r5Ln3Nu2+7UzhEnsfeWofB9Cz2EtppHJ63NPRbkwjFtJInA8Aj6fvvYKkkkdpf/86+rJWUt4Z80UOEMcGqU9bZIgA7E5H94kd6RGSKYZWXwOcikuvGDhsjMQID3io7/XjbMAAACTPJXteq/8f++EVTUTl7iNFRjP8+xh0DxCoUsc06X1xR+qFnMDD/rNa/535sc/2B4Ycr2lf5eroC7DTMRNBM11TOWzuD7gseoyUvb0aNTe0F2uodvaSQlL9Zm2Tkzm35wxey6sxm8c+QEEjjUkXIo6/gMAeAn4liSZmWISKbZE9lWamCmtg97h1u59wnf8oCcrXf3/8zlj/93lM5xTHnc/2gkc/cc/x66Ox8jdONsnQhV/M02SHGmUnONH+oiqej0nb/X8YK0hbsj/AjsfizuiIpKCgwVssWmxc3WfyMkbq81kbOn1CJZlttEHnbuunfy/TAApxfciSd6uaZg7cSGP2qAPif/2Uh+dNkg3occk/2OKYWPtpgbTN08ssrc3K0H6ERfGcZfa+CMAvn2KqMLNPnQwbxBYFDVCP8UgdCkQ/AAACYXgsJWf/5sATVg3L2zCP69WPfGnQYFgyAABxNDy/NppR8yDiKUV1sEPALMRNIxQ/tpkTzglz2HIf2SJo7psRtnpt5GoSQDym0Dy5n5TQF4o+xA2bYlbdc7++euhkNgzEqngZOni+LtJpE8Qd50GydZEpg01AYcGdT6mAIafoM9EsS7kn3ddtr8bFjFPZ/urtGysMO3/2JTMPlkCjDlLikLtSIKjy8t99QF66T5f+UAvDD0/qhpMiNEzlVGWIBLbA7oRZ3aGI/2/vrEw16LrJav2KHc45yP+Upyu8sRfAzPIGG7dI6J7csicLSlvumZNHIl5e7mIYwguf2Qg0OHjWJ5aSafEck2vN4fsbt/MDRyAhVSYdcoLLdWPfQiSR/1+uIUih0Kj45/n7daS42jIFUp5jzg3NIKH9phV97mjbJRzdj/Kk2rGBpQaiRUMMkVNkF1IikIT4uR76Iim4pNufanXvQ5lgHreQX3Pbp6wqqvQRFowjL9gkXpR6bIZj8ITvmZtvlb0hIxgzeP9+M8xwFUgy6Siuef/j/CHbZM40QABLokYCP8jHMZPZkYETSYQsuaIoNelG2+7TaKYUV9YF66/4Soqo5mBtZFic1XoB3FPebUiveJziOkXYPdOpT7MDHVtbKeUJMsJpnf5QWDCL3wEhEdq3fUPw8JPHnMMzPXCjUFQszDqh6SRXwFIWS8cXsRuSrYCJihpz7r1JpxWWtM0e06Ti+21aCDu+TQ45qL0N7kzYGLOPPCh8dcm1DsSIeaN3NHQ0QSu2CG7pbfNqB4DE8wv9E2hgHb9CvHLEtHeLOHO4Xllrj6wstGh4cxdfVsZjuDDauW2v5Hq3X8HO01XA5E0H9KSNpiLmckJoNPjExCStCR2pfy9AJiVDgfx4AcYSYjXNxCZJFbpBtYm6FB2W8BK30VI4bne4g36u9JNceGSwcxZ5kRhs++IpeFzLl/8BdEIYgaLyQNfxOlEjI4rtc7OINDH1M6ei7Of2Os1nRjTliFrEYXPGoxs3CTAton6bgezvPm8zuFU2n7ZQQLJlLriBF8Z2YiMwHmIjYUV90J9BrdVbDP8W1OGImXSwbHmO4w5d3cf2jp/Gm0I+vcJy6MGw/I8Cu1FBI5utnT8zzv3ugEAIDFoaESLAgP4FssIXhZAGLUTbSvPNBd5dlGXEN3HV2xAh4VIt8nVC7UENV4kYR/VSch410xmvSthnXpMQNG9YoiSksEKKgDiWuGWiNIJ6SUOOMzxyENe4yqwJHWZVEinRsfRV60sguCvf6QErdWeW2AxnSNTTI9alurrQkNbybrx6/7NTq2ZgSZgUGp8iNWA77R0O1ygCOd5W5F2CrMolaYlLTkV6tmGKRT40X6iay8smsmIfOL61Pf/QrIALYchLn2GSaf37AADeu+EfbnOCE42lZcpS5UXjkzdpgPhLJcnMNhOM4cZzgVWWTc5idHg5Rqlfu+VAHuSsDa+ZJD7L9U8Dr0OO/m1tI2/ducw6+bhdOvB3NCNmMLkRZCNBWTfkVvlb1Zkw75KdGld6UAp1mSyWXfD/zjS8n1n9lJkC/ZUgcf8k1LNIhrI5J3rU/PSDMF9FpadrpLfrcHp9IhsZVkfSW5dMXnw6/N/99zFrKaJanakwnEo4tivaUnXmNAf/xKDOGGVyzNkCfBGMdAzg6YhscK1uVk7pCn4dMzWuGeIaUv4lRC8CPJKCvKzpHFYQYLDZLrOf1K1JSo1jwT+V8tjflt3Y7K07NgvBo4eL137jVXVYTijXslCXbGgcOFUEoF6jLn+f3askte79y7hf40l3ss/Kt4DEYD/HNT61pDGxnpCBtm/SHI0i1UsyUEs8eYE4TsxhS4LUkcRctd1hBTrscqjMa1ryev+dV8BgIBh8CHJfXkCo+8chPxTMG8nPZfxQS8DKJ6+XNtK4q2eJA0DgyH4fKqUxgjDLO/VrsN4WVNVUdu5Ctn9NIojYJ9RoEZ6xcq+Sc6Y84NNhTib3nrI5C8c2W/FoV1fpTYFlaU15WfjC3mzqV2NRdfFknEobKwBhgIhT49B6f8T2BgO5nJDIzTAnBV/GDAmsuf/nSwPMaWAQcKES7meIzV9Zw6f4NpivTqEv5BM0UCc0CtQ3MU3ALP633RMAlnABo8Ot/QChZ6qQaawtxAsyM7GLcbzVdIFkKxqDfHjL+H9FBvaQwxJXPPllM8I+sfL9lMx1vTwK2bvSSGBEHk8Nnz3/xjQHuQ6X78s07ivlpMGiRg/A4R2eUDxBTeuwvErJhS0Do9qZARvsp7vCc09zzgkZzIQ3T+9ZE/QDgnl0lyuc8+AEwfF8TKgbwWUnD06D0PP+tkdpWkgORx7yC2OyYKcpc65A1VEkmrr/5hh5bb/OAtpx0WeywVDKcZmVR1cuqkez7ZdPJMMjtQTSeJ7Mh0+mTcCz4LoKaSxZTXKLdQLIOdGaVmVJi1olJFhmlDItkknlWDVJT3yoYls+sACwaJokbSVeD5VpDwgRHZolkkLWlhaJligt3YaaQkrEn9+V5TiriuxbsxmQsIlz2PtsaaI/JMSkBwRVrSMMffUR6iPxUAT52IUGktzVHcVAQGACJnnpKVOOV+4AwhMOvXmImPjuTvXzxDnJZqzSI3kR5BkKgGKarUM9nspfj/BUg63V6lpRcQaa2SYYMHR2XREbQ3v2WstBAFev79BI+R39cq6vsbN/ul4PvV/tkDD5zKXN0B74EXKUtf07n8u9QW4m2VVs+7VHoXn1XnvVU3sN7GFYZEUl9HfVQXspW8VidgkZRAnZNc2dx7lI+pQ3SCv0v3XzyqwrIv0bikfoFb+NqK3Zws9mesrpKTyatUMFZYwg5AqQKIT6cnSUhtQG/x/no6M6RB6c5FD+ceN2695B3aLpvCquF50kiqIXTbeDM5UNTa403K0rWJJZjJMjYbvLDwUER0EiEEtzZo6zZti4XgvZs/YR3fQDqWuvMzF7opqzepsGgnCdFH3zoCeGUqyb7RtbKtpBb1pIVKVIu2l7aFiE72J7gAzYa/5lJEfta44lCtdDLfI5Rfrw5cn/PnGWO63gw3GE8dQpQR5VsxXY6SxOaZY2Y41ecqhN1vThqERc56hTUdzMDs5epFialuChGW7qREptkAQfQIQkaTWqO2irIe1y3HEhSxVxFXhR3Xd7esXwuY+eHJoG54GHrad/ZJQu+ibEp0U8/WSjoiJ1sysRPLq7fJmzCOHsrkLGTwBNhXzbl8KfZ+Ov48yEWcR6hOWWzAFdxNF9fSzKw7nOjR7pWENq7JRdM6G2iOoXseUcNsnFLRVQYxGUucQROowRRJb1ECL5Zc48TjF9BNM55ABobF2NMz3ETWTFh3jc12yRK6h/VgibqQMQEeDMXaClW782fv6DvgTMEsgpSc5Mtm6PoSIVpaHPA9+idLKa6Q12SytVRTNqwSrT2W+N1oMfO0nxqORs/ceYD+X8ww/rGgq7I8ELtkfUDkoHcbkRDpKqHigI1glxrIALgVir7Na0MDexxGe3kEK4TSZbQi3e4gjaPW2OLhW1zOZixLltA4msAF1uoJn0dGRyvRnBoS2HB1Q1xTuYNpYi+y8ipuJcTD9UMaFheJoQNzkgh8jiHbuy5Eub+qtTGwN/NNLxqMxvYe7ccl6AsoGCRADwmhxOx23nFc22YxWvEkebjyQxboc6NoMFyCeqYZpS6zGgZGFzIOB4slts2g/sUdLybs2pRnzkzpzYktjhWqrCMeAm03hPa59u2ZvmDKEVJpgtB1jLQYT4IG8MWMZgLeXbb7SlD2s2sIjE+/UvMn88yBrgGOIKyM9PGCna9JeKmrutvlJzMxKID/Opfmiz3LVjg//BvBFqU/w0gm+iUoGfnHXi3ahzWvn6dBRSV/qsUl/kgSgDQmpI9Pj5A6gXQMBjezHzKZlFqxn22ng3GtEkNregpOOV8D8g/z4PZVrTDf1DKJg+w/oA3U572a19C0C5+Y5snjZCUAzowW1oQLTM+jpai3nzpWT3v4xEFhNCbZV2S69FZ02nMvs3ygudK99Em8QMtmZgdmWbSF5LzfBtHUtwha/6OK5oF6dgL5m5KD/yxxZ82NDViWoBgkmNFqlOtPAJc5Z1H9G0vHLGiEYWquOfan841B7Ddgjb50Odf139+ETYoewVW89kDC86EGgxz98AOZU1Aj8P3Dci+hipidq5Wqadjud+Pqe0/61WHz3bP61RNHwarlN5cdWZioDZeldQwXgmcz4RdZi1sW6/RrCDZUYFJZxaBAMe3j+zMgDrV3iVfNi30TjvQ1v5+KazwP8KBh2Som2cJWiw6HBMAJx0vZ1vnwZhqkN9xUXCx1S/ROmQ6feUeyzNAVMYnaIAr2jMAudRI2CouZFIm6I3fInuXwdbFS38cGQ0fRLyaWzF3bcyrnswh6rDKPF6g6kGllt5iuX09nEP5/CsUTxraDtG4nNPCzS5BkP6iqq+Zx6dkgUAzUVa0t4HQbnz8QOf5B0S+VpItZsQo4NhsuYUZMA+VskQwFLqipJqoRzudOgbVlvR+DTVGQlH0KWUKUG0ILfSiWPfI+f7EWY+Kk+SpGhu4ufQ8Xkn/ZDqc52A2uVEazlYWi0B0+IgfdRAwSfJOOwmcpiGpoBIrexDphqOQdDV4p2j0BfXPuO9RQl4DCscD1Mwln1Olp9Nr7mARM7buEY27sPonMdvPzqtBv1UAPVBIPa40YrSKyuinn5p8QKyVzSqSg3+Le0rrTwmZ4roKmrpiCiy7FymvxmnslR5V7mWySGEtyg6aABZGDUIjMjL0M4uePsOLItXXRZeOk7Sp2lAKRQDdJLJkYGgvN6Q8hexzGH95i/KmHB0oJEQyxK8zTUGTa9GKCDCmqac5+8G1VXlaq9AkR5dEOVqIkLj9xHshh0/uiPr/uflbNZGeskSEMZFymFO16bUfLegEWPWxrvHB7o/bb7l+HWJxyxXB8+c0CfEzRBowJVDdDuXB6pTlLvnXCGQbxlOMPWpvH17c8bz09x5Pnc2z1d73lBCP6ANYiAq6FVpKWj1+6ocaAoYTycu1aanw7xphRG14p/zGyUKWPGonel1rjUYbYuGBugNH8fACv5CEt9xxUDuWLcEab8MXR5EpeXom/oVFzkiUUW80zzYwWJEWkLpw4Dg99pLkkKX+RrvYNCjdGnyO6JnA7yHRDv4xzJQDpHhKN0XuOyT5/3EZSzm6XSjv72GO/zM7AAbjh9uevuzpZbnYo9ADMi8y2TYhEt7zHEc+z7YQq7T37ZU6V+tetYvIqeSOLSfw9VMLS/i38RCdWxwOiO4ZTBB8/uodcldf1sVGezLjIOQTTitn7BYHPBEq/EwU7VnwzENmTwsJdDTFDympB5r9+quV0VjR4UAK2AwpGUTrfJyW+Meu8KhBKudQsdqqbYRtF1iqJOCoRyjXUVMCgmsogDvbu+vcI1l0xzs9Ne9SUGQjcgB366yOhl+iwplk7tzOeA4zzsW3ttYoYixC275clnYP0NXMhSeEVnKggOzN25F3tZFYkxeOKk+MiMLMV0/OXPYuEbzo69zg0/birRldEJTaPoWf+mG97kckbt/TWsc01Uvc5Tw53wY6YCukai0G3OPJTz+leZgPfMjJ74Er4418BfuLs+XKOnz9YUv7KmbKpcZA0RONoFBlypj3i4QNcoEBs36aeAoFe9OAuroeQflrXa66VSDltawbJXXnwJ/SLDCBL4iCmEyj/rurac8PIWSN8qjgmxLjd8gRGT3p6UwSmjR5cmjW8aKVdck2O9ivBfAYXhyRxfffVK5CW6g56IagSaZe1oDY5moBntHZUIMZyc/ZehUFOY1OOAelTs3msl3vWzso/BMbvhNPgoEjnWxJXrxTHVxML9NHvgT2p4LBjwy9Q4CJH5KbnZndH8hNSfad0Y0ThyqQ90m3PO45uc2VZrod9yxdTDVef6cvzXtFEivf5lkVzw3ns7TbXfgpPSgfOxpUgW45f9v2aEqnYrlq0jFFlMcvdqCo3j8N8rVmJafwIHbxo7gyAIQuNKxXNaf0kNJv50y1AQ6j1pC6klnMmdSFoGIm8Yisp6Y1nq8MMNdlFONqU3SDDnqh662qJBOr7/TvE06Px4AUB1eieGnCoAgmIur65TFs8AAAAAFYK+pPadtpqlRzVi4MbSE+mj1/3iGIIRqF8TEPG1AsqG7cEiko63Nkp2nbWLMuN8cL1UZGj8jVlDG7+WRfPTas2eMtlfZUr2K7xXz41G+3Zbg/e6DtzQeUNpezFaOEIfZYmNbLGxMScsn6IDm8rQQwbyhNNgdcOVg1AS/qIgikSTFoqZ4M6/JI5gwfn+FeLNS/HHHJFcR3lNAeeOl33ToUkdNCDKsMzLk3ZJwXWEoGJg5qhotCAgigPrsPJfFDjZCs6cvm4QWyg6xBAYxEJxzVQpBW8DZ8OYzP8Qv3/RMTxmYQlh5vB/XmZCLz6azWw/PEjqC8vuJiN7kLjfiPhhEME6YnXOgwQVDPrU7VG79C85hygrhrLP1nqIx2jKK+xc8ZtDebPBkrEj9ki+eYtzPaJIP4oHGQSdFN7HP3PpqEQaCW/61lFxk/QGjobqKwJniCQPc5gqrm746K+9tSOZs5GuEf7JRaThgVjhSKPOZ1tKgXuRDtxZlESi4YkzCxYWkT+Nc2ur5y9qiJ6pUHRCi8aNZtlV10he9wkCDPg3wcwbnH3wJhbyBoFlKufce+xX0VXpVhVeFiX0cJc/gnok/3CcgN/WzVZ45fQ76iXIA8qGnnapyMeE3lz/elrGLxGvSkykIEZQDaz2pXTxYhMrkxMTFAIWU+nV3JC1UPfWZABl+hiby6VNavvBmzHfK74by4sTMbSib8q1ZIG1UwTd/8pa4J+5BBQaTeioh3oe488AjjQMLxB6qpj3Wykf3bLN4ZWJQfzXudKOcKV51reTVr5eWFagTNLPEuxwyp8Zh0OgTNRzm7/j0RuSna6H/2uVXbm7Nlu36gI7+j/diWJ/iNtZrJtzO/cO/pOTscnJt5NlBXX5/4RTFjwGZDEqioAMBm3Of8a8zuY8661GmcDlyEpG3Lnn3i77OkJPdHL34tDCKq7G+Ydrb+Idmk8dj9i0oLIW/AF7fIQZizNxHnscQY3QbXD7VVbjo63jY3AnY+FiKbMoBuLsIQWH3x9Atexl6ADGhY+2zZt+nGk1JBKj6n5JPAgxst7Rh59UWOW6s8MWY806D4ofzUwwDp3vCmUepEE/mL3nqi7pEXHT5h94904OuuLzNceijrCeCkIfR051JBo0AXxppqdZ0FWRlhxc9H11ojTIqccxpuc0tYSMCHjgYtsZImNb3gX9gJF3O381tyQvMPS8yRL7InjOXzEZ7DNsCCs57OL7/VdK4HFlWvXqnEZP2CNtdCVkovjxyD6hUlJAQqxPO/gaccYSwVQipU875nGC15B18DgGaVuDgYYFpdRcr0uRk98GRns50XbzHD+JAJO1yq8V5aUm1BpEpcYqJ9Q5xeuCyV51je/C41k2Q6vUUBf9jLd6mUt+JYHBJeTXfaPBmPzyoErUmuB4IhHCsc2qJAY9/fVo1Ovl6Da1aBLdrO2LKq8SdL6NOcgU2OQZ0N0ZOQyFcQlDN5UAiAk+gNcg3O8bdJsYxgylZdC4EscQ2SfzXlz0PLL+WcypAdH5Pc2a27NsHCrjVC8Wy8A9feMl6cq5HBV6xC/XKT8AwFy1mOGGhswNFNejKMPzItn8kuyOn1HZjd4f7sTotc+BSwsG+v44ELulRF+D5m3xsH8qDaI+YS6EkqGCBEgvRo0Dobb5t+QaME6nAqdLhKMgfpDWMbM4/jVAttaOUcBY10sJCnEShlzBLsI0cJmsetv1+Ru/UGfFqnk3UuYt72eVjzX1A45uWHED0wleDd4jkTLBPAAMhYrQKWncPfTupCI1SBX8PXFZj6KZJ31SED3cDrg/7FetntfPHOZJjhYH2DbpKmj//pgajKnORTd0HyxrvFd8YmQS+cIlqmSD/Nint6AbmrKT4CenBrwiokguXyt1B5ZKY9bg6YQt+dT76jNa2+gk2NlxeyExveY1j/PM+r+12aNLSr7j8bmJY1pXmEZF+7XiUCv5X+JeHG+6PaUyNv2dPsIgg8BE5BdiWopSraskpbz6M2MZQrMDYChxySZTVYHVSEuaIKf9GqAnVRVd3dOA8DN2Ob9pSkmiBzDkGhH4DUHlch215JZlOVEcaweWNzTyMc8PkCMfhkxQ1H0VMnRdYAcPSSILbWQRiBTqKuiKWWiEcf+MfJvHuB4HXV472RAe+1hGwKWZmkaPcAFFRAmHXtk7Wd1S1UseMf3C8VfSkfzZQGhOEDDfE2dOYFOrVDHk95NlXm8p1ik5MuuJLlVFCwTaW+eD6IfQxgnpfL4g1sYti9NmSR7Ckq6qD1JJ03t0z/nUEqKMYQKGECb1gFuSwOfPHNUkDcsRrLbVQv2EQPz7rDREvQ/pyt0TUL3SHjwyo2oc4fCBeFTNEjSd4+JZ87X5UXPXtgerXszLLh9X43GSXdpsSEKbas0+pt7Pbe4BSn/FI+bVnsrHE9RXU4MXDrWPqAqIi0YI0F3h3rdOC1Dx2BKz0wtUoPSNuM7CWIadk0WL1CNtC+FfJuP9miegiwO3VxetNPaYNWkP2ckZ1JA87GmdbI3WShRkmTk1EtMtPwWEpK8d08l+fW0W4BY6dZPId+1969FbnC2tDGAWI7PrZGFWclCMrs9pxlyoavInOaXLvb/3JbUC4YkPz1f5fnOompI5K0PtgNKL/xPbjq58aeUIxuyzsasAz2kvGUxPtwpFkYOR8lmpFeMOBy3bxVOutnNGz++XhdeLHaa8Rf1sFNHPnv+Uxt3qneEUR2bYozwBcHsdMsZacLR/KvzuV6s1ZzFJOSILoPzt3kJYzpWrrh3mrUDoLCUddg8c05jyAoMXOTjwfqHsQGTeH30dLiiDcx2QYy/2jlrQpGouBCq0O9l6rGn91ZaEdY+RJDnKvVme/DX93YuiDgggx9SGxwvgnBXqJ3CpAKKYn9HqnRxjqgDEjZzLUcfudUXgKMXcYDhH170FIx1t2CH495Ajm/XU5Y5Lk2UzkP7wkXqVOW5W6i0IIWy61E3J0wAip74n01kM48lxvQmwqVTS0cTHXYuBbep1lGjvnRBOUvmSslPEXiCc8K2V9Dbvd04+sbDcu82/jxep4Ad2H3Yp2fXOzz+piDP952GgkgjrLAc3tx+tixJn15574saBbYlmxbT0oY35L/b/6DRV7mshWbeqIb0PaQK8+TY1z1Sc0DbveLbGB42IxDddIFiax147bQrNSInT1ezLjrFKsV+Yvn8YEpED1Oj1Ci0WcGiCVOrivpFp4B9RploEByIxvePZDK2U4A3yIcPH8JwGC2mddTnKu23Ol13TKi4ZX4BQMOcbDdmRr5sqkTp/s5OjExgQ0YM/aYjFFGf4sGZoF0u1SWgL5j1+EpGFJZXQOWbElHw9JJp/5adX8v7kkudUheU9XfJNLl5N7loHCoHmdzpmYNjSbO3ofM+XaMkJqcFO3j5iiaL0B9ZjDSQ3FayZ2zFojhgaEw6I3wNWwgailNzUh8FCJHX1hSXhtTZ3cEPz8krqH7AUy7lP4Yh8hY/ShX+51JL/NiWOoEbuJ8NIn315HKtb1IcAIzJojS3bFJdMEGCHRYXf/uZnReKVs8o9UzVO5sJPTFXxbiC7B4R0i8Rn94NIot54HjPcfnB4nWphGQIZjFt+5L3uyj5MDVQbGzwUIBG0O27zlR08J4uh5GaBS5O1ivwQwfO4YZxQnX9a8ZnJUfoqve/Chluuo0wg2J8rDOY7ELecnN4Gi/rscbbHhYhF8nfQHfTb6LcfKuWFgCRFrDcPdzTK4ADPdF1maLeV0keDep+l5aA35dFrskmb/WtPu8xT7t2YSOIsT5t7rbVHP9Yv7byCSeSeUBTke5zGGm86SBAH461AjXieb9QD8UHI64I2HkpbFFa4NMvKHd5PAuAvnVy3vAQlfy0hmH3F4OfHNrcuottJAyZWw/ULR3hWhxGmMBAz6F4xiDDXLIQAz7UGQUPH6gaxfDya4nWdO0F4O8oCm8/d06FDX8qBrkGl4pLJMO6IfoCZAYftWWIlWmohE+QzUjkSeSsnXm9U9053b4KVXgYPeatuZK3Z5YZnSne+Mg4Sv7YB2RznqWJraJGYGf1KUbgHWSWX7thaxZPb/kYUE8E6w21n+FmMzS/ExQEbzPnKyHu6R62UQQB9A8Nrx6LnDNFxOS//bknkwigcGDUA/KnxM2w6NYXPgVzkoixwX1Io7Nw8OMtFzkGJTh8VBHhAXVFVIxqY1RkvK9hj0UN4RPuAAAAAAAAAAAAAA==" alt="Matrix World Research" class="logo">
    <div class="badge"><?= htmlspecialchars($c['badge']) ?></div>
  </div>

  <div class="hero">
    <div class="icon-wrap">
      <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><?= $c['icon'] ?></svg>
    </div>
    <div class="hero-text">
      <h1><?= htmlspecialchars($c['heading']) ?></h1>
      <p><?= htmlspecialchars($c['msg']) ?></p>
    </div>
  </div>

  <div class="record">
    <table class="record-table">
      <thead>
        <tr>
          <th>PROJECT ID</th>
          <th>RESPONDENT ID</th>
          <th>STATUS</th>
          <th>IP ADDRESS</th>
          <th>TIME</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td class="sid-val"><?= htmlspecialchars($sid ?: '—') ?></td>
          <td class="uid-val"><?= htmlspecialchars($original_uid ?: ($enc_uid ?: '—')) ?></td>
          <td><span class="status-pill"><?= htmlspecialchars($c['label']) ?></span></td>
          <td class="uid-val"><?= htmlspecialchars($ip) ?></td>
          <td class="uid-val"><?= htmlspecialchars($time) ?></td>
        </tr>
      </tbody>
    </table>
  </div>

  <div class="footer">
    Need help? Reach us at <a href="mailto:info@matrixworldresearch.com">info@matrixworldresearch.com</a><br>
    www.matrixworldresearch.com &nbsp;•&nbsp; © Matrix World Research. All rights reserved.
  </div>
</div>
</body>
</html>
