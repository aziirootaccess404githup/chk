<?php
// ============================================================
// PanelEngine Survey Panel — login.php
// ============================================================
require_once __DIR__ . '/config.php';

rp_session_start();

// Already logged in → redirect to dashboard
if (rp_is_logged_in()) {
    header('Location: admin.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($email) || empty($password)) {
        $error = 'Please enter both email and password.';
    } else {
        try {
            $db   = rp_db();
            $stmt = $db->prepare("SELECT * FROM rp_users WHERE email = ? AND status = 1 LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['rp_user_id']    = $user['id'];
                $_SESSION['rp_user_name']  = $user['name'];
                $_SESSION['rp_user_email'] = $user['email'];
                $_SESSION['rp_user_role']  = $user['role'];
                header('Location: admin.php');
                exit();
            } else {
                $error = 'Invalid email or password.';
            }
        } catch (Exception $e) {
            $error = 'Login failed. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — Matrix World Research</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Mono&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{
  min-height:100vh;
  background:#0d0f14;
  font-family:'DM Sans',sans-serif;
  display:flex;
  align-items:center;
  justify-content:center;
  color:#e2e8f0;
}

/* ── Background subtle grid ── */
body::before{
  content:'';
  position:fixed;
  inset:0;
  background-image:
    linear-gradient(rgba(99,102,241,0.03) 1px, transparent 1px),
    linear-gradient(90deg, rgba(99,102,241,0.03) 1px, transparent 1px);
  background-size:40px 40px;
  pointer-events:none;
}

.login-wrap{
  width:100%;
  max-width:420px;
  padding:20px;
  position:relative;
  z-index:1;
}

/* ── Logo ── */
.logo{
  text-align:center;
  margin-bottom:36px;
}
.logo-icon{
  width:56px;height:56px;
  background:linear-gradient(135deg,#6366f1,#8b5cf6);
  border-radius:14px;
  display:inline-flex;
  align-items:center;
  justify-content:center;
  font-size:24px;
  font-weight:700;
  color:#fff;
  letter-spacing:-1px;
  margin-bottom:12px;
  box-shadow:0 8px 24px rgba(99,102,241,0.3);
}
.logo-name{
  font-size:22px;
  font-weight:700;
  letter-spacing:2px;
  color:#e2e8f0;
}
.logo-sub{
  font-size:11px;
  letter-spacing:3px;
  color:#475569;
  margin-top:2px;
}

/* ── Card ── */
.card{
  background:#111318;
  border:1px solid rgba(255,255,255,0.07);
  border-radius:16px;
  padding:36px 32px;
  box-shadow:0 24px 48px rgba(0,0,0,0.4);
}

.card-title{
  font-size:18px;
  font-weight:600;
  color:#f1f5f9;
  margin-bottom:6px;
}
.card-sub{
  font-size:13px;
  color:#64748b;
  margin-bottom:28px;
}

/* ── Form ── */
.field{
  margin-bottom:18px;
}
.field label{
  display:block;
  font-size:12px;
  font-weight:600;
  letter-spacing:1px;
  color:#94a3b8;
  margin-bottom:8px;
  text-transform:uppercase;
}
.field input{
  width:100%;
  background:#0d0f14;
  border:1px solid rgba(255,255,255,0.08);
  border-radius:8px;
  padding:12px 14px;
  font-size:14px;
  color:#e2e8f0;
  font-family:'DM Sans',sans-serif;
  transition:border-color .2s;
  outline:none;
}
.field input:focus{
  border-color:#6366f1;
  box-shadow:0 0 0 3px rgba(99,102,241,0.1);
}
.field input::placeholder{color:#334155}

/* ── Error ── */
.error-msg{
  background:rgba(239,68,68,0.1);
  border:1px solid rgba(239,68,68,0.2);
  border-radius:8px;
  padding:10px 14px;
  font-size:13px;
  color:#f87171;
  margin-bottom:18px;
  display:flex;
  align-items:center;
  gap:8px;
}

/* ── Button ── */
.btn-login{
  width:100%;
  background:linear-gradient(135deg,#6366f1,#8b5cf6);
  border:none;
  border-radius:8px;
  padding:13px;
  font-size:14px;
  font-weight:600;
  color:#fff;
  cursor:pointer;
  letter-spacing:0.5px;
  transition:opacity .2s, transform .1s;
  margin-top:6px;
}
.btn-login:hover{opacity:0.9}
.btn-login:active{transform:scale(0.99)}

/* ── Footer ── */
.login-footer{
  text-align:center;
  margin-top:24px;
  font-size:11px;
  color:#1e293b;
  letter-spacing:1px;
}
</style>
</head>
<body>

<div class="login-wrap">

  <!-- Logo -->
  <div class="logo">
    <img src="data:image/webp;base64,UklGRjgkAABXRUJQVlA4ICwkAACQewCdASpoAZYAPjEWiUMiISEUul3gIAMEpu3V7xo/+i7HuY/KX6n+2+k/yL1xec/EfB81t5Y/lf63/rP6x/cf2Q+d3/E/4H9V93X9e/YD8//oH/ST/W/1Lry+YL+k/3j/wf5/3Uv9n+p3vL/Xn9h/8t8gH9D/yH/o9p7/ueyl6Bv7seml+1fwp/1T/c/tN7QH/51i3y//Wfx38KP65/Y/2Z/cr2J/F/nn6r+R37z9J3pv/nehv8Y+sX2T+7/tF/dv2Y+ZP8h+I/5Fe6fx8/fvUC/E/5B/b/7R+yX9Y/afkgNf8wX2J+gf4T/A/uF/a/TN/svQz64/5/7hvsA/jv9D/w35rf5j///W3/A8Gj7p/tf2F+AH+R/1T/T/3/++/sl9MH8t/y/8b+Vntc/Lv8B/yf8t/nv20+wn+Pf0j/Yf3H/K/9//Nf///6/dD7IPRG/Y//5n3z2Y/7aEzAA2RbsXdH/ZxuOpd4lEdNn//CCFNr+hrgR6p6NLgfzbHml+kjxL0/TYaYINZ9YN8GJu7QyuGdLUicNFGHzWPK781wI9R1aWjrpMPQgx12SBbTSPEJp0/zTAZBoElRIKfcRlgJ5wKuyBwCMfvnQBR9owumKbBAenoiaxGsstQg0+Q2tC3Z2NkRR4VVdXfF1kTDAaEFV7/hARJU8votWZTmz1S7+fmLIcpFdVH6QLdWtVfZSNR2LbK4SOTFHnaajXy/PIjklbcWyPn6uvd45vwWa+eqFzh7T3q2YkuWGhJ82fefSr2MoZCbSX2jxNdjPuS+hcO292fbjnUI3mJb3zbDEVn0y5xhIDqG7bCp5W6sy810ilMTfl8R/BTZBE5P3vuA9swCXKWRBJr5Ui2Xzq4b20c9dMk/bXa3Iz8nMiywjZZtP1PAPvJeIk2jfSAhboUua0VXMZ7s9bd71w/WgZ3NQBc95vZU+OHw1ohrqNhrVft+8BgFfkQqlq2d+z1phtAcVo1MH0JLup2ECb90BRbAMGPUU2haUNhzN3b67NAa7zBVkf9i38Tzp6K9YokZa6RiNY6ozPnEKfsb9QI+h64T74v7Gs9EdX8mym3eEZeJZ7fTTUix8idpBZ+HaGJ8VWp6RRVKbIAFjEB826S4LI9MP23FAHByR5l7IUP3sUNda1JzEammrJ/wJJt1H+3T3NmQMnaeNKJo1ekvDT5leSuAbMvhRy3fCnCQDfJSsSceONlfvxcaP/kcn522d00lGuj/ylYINzCB/OfAPJ2+cAyuETpaGNvQaNT3UaxXRI/1FT8ifW34Ivt34ddkoCZvYxlOSvr3ksgztKWY2seXbcqmpSsrvzXAj1T0UgAP7+3XoxAYBMjmU8lWHODUejfcRyFLqF6yY3xPaJEb9WNJsLuIRineoX3PE7cDnXnYgHQl5ygHf/zK2YRka/9OeAxpLIMyQNSa7LEk4ChWhdlhoNUMeX5r5Ln3Nu2+7UzhEnsfeWofB9Cz2EtppHJ63NPRbkwjFtJInA8Aj6fvvYKkkkdpf/86+rJWUt4Z80UOEMcGqU9bZIgA7E5H94kd6RGSKYZWXwOcikuvGDhsjMQID3io7/XjbMAAACTPJXteq/8f++EVTUTl7iNFRjP8+xh0DxCoUsc06X1xR+qFnMDD/rNa/535sc/2B4Ycr2lf5eroC7DTMRNBM11TOWzuD7gseoyUvb0aNTe0F2uodvaSQlL9Zm2Tkzm35wxey6sxm8c+QEEjjUkXIo6/gMAeAn4liSZmWISKbZE9lWamCmtg97h1u59wnf8oCcrXf3/8zlj/93lM5xTHnc/2gkc/cc/x66Ox8jdONsnQhV/M02SHGmUnONH+oiqej0nb/X8YK0hbsj/AjsfizuiIpKCgwVssWmxc3WfyMkbq81kbOn1CJZlttEHnbuunfy/TAApxfciSd6uaZg7cSGP2qAPif/2Uh+dNkg3occk/2OKYWPtpgbTN08ssrc3K0H6ERfGcZfa+CMAvn2KqMLNPnQwbxBYFDVCP8UgdCkQ/AAACYXgsJWf/5sATVg3L2zCP69WPfGnQYFgyAABxNDy/NppR8yDiKUV1sEPALMRNIxQ/tpkTzglz2HIf2SJo7psRtnpt5GoSQDym0Dy5n5TQF4o+xA2bYlbdc7++euhkNgzEqngZOni+LtJpE8Qd50GydZEpg01AYcGdT6mAIafoM9EsS7kn3ddtr8bFjFPZ/urtGysMO3/2JTMPlkCjDlLikLtSIKjy8t99QF66T5f+UAvDD0/qhpMiNEzlVGWIBLbA7oRZ3aGI/2/vrEw16LrJav2KHc45yP+Upyu8sRfAzPIGG7dI6J7csicLSlvumZNHIl5e7mIYwguf2Qg0OHjWJ5aSafEck2vN4fsbt/MDRyAhVSYdcoLLdWPfQiSR/1+uIUih0Kj45/n7daS42jIFUp5jzg3NIKH9phV97mjbJRzdj/Kk2rGBpQaiRUMMkVNkF1IikIT4uR76Iim4pNufanXvQ5lgHreQX3Pbp6wqqvQRFowjL9gkXpR6bIZj8ITvmZtvlb0hIxgzeP9+M8xwFUgy6Siuef/j/CHbZM40QABLokYCP8jHMZPZkYETSYQsuaIoNelG2+7TaKYUV9YF66/4Soqo5mBtZFic1XoB3FPebUiveJziOkXYPdOpT7MDHVtbKeUJMsJpnf5QWDCL3wEhEdq3fUPw8JPHnMMzPXCjUFQszDqh6SRXwFIWS8cXsRuSrYCJihpz7r1JpxWWtM0e06Ti+21aCDu+TQ45qL0N7kzYGLOPPCh8dcm1DsSIeaN3NHQ0QSu2CG7pbfNqB4DE8wv9E2hgHb9CvHLEtHeLOHO4Xllrj6wstGh4cxdfVsZjuDDauW2v5Hq3X8HO01XA5E0H9KSNpiLmckJoNPjExCStCR2pfy9AJiVDgfx4AcYSYjXNxCZJFbpBtYm6FB2W8BK30VI4bne4g36u9JNceGSwcxZ5kRhs++IpeFzLl/8BdEIYgaLyQNfxOlEjI4rtc7OINDH1M6ei7Of2Os1nRjTliFrEYXPGoxs3CTAton6bgezvPm8zuFU2n7ZQQLJlLriBF8Z2YiMwHmIjYUV90J9BrdVbDP8W1OGImXSwbHmO4w5d3cf2jp/Gm0I+vcJy6MGw/I8Cu1FBI5utnT8zzv3ugEAIDFoaESLAgP4FssIXhZAGLUTbSvPNBd5dlGXEN3HV2xAh4VIt8nVC7UENV4kYR/VSch410xmvSthnXpMQNG9YoiSksEKKgDiWuGWiNIJ6SUOOMzxyENe4yqwJHWZVEinRsfRV60sguCvf6QErdWeW2AxnSNTTI9alurrQkNbybrx6/7NTq2ZgSZgUGp8iNWA77R0O1ygCOd5W5F2CrMolaYlLTkV6tmGKRT40X6iay8smsmIfOL61Pf/QrIALYchLn2GSaf37AADeu+EfbnOCE42lZcpS5UXjkzdpgPhLJcnMNhOM4cZzgVWWTc5idHg5Rqlfu+VAHuSsDa+ZJD7L9U8Dr0OO/m1tI2/ducw6+bhdOvB3NCNmMLkRZCNBWTfkVvlb1Zkw75KdGld6UAp1mSyWXfD/zjS8n1n9lJkC/ZUgcf8k1LNIhrI5J3rU/PSDMF9FpadrpLfrcHp9IhsZVkfSW5dMXnw6/N/99zFrKaJanakwnEo4tivaUnXmNAf/xKDOGGVyzNkCfBGMdAzg6YhscK1uVk7pCn4dMzWuGeIaUv4lRC8CPJKCvKzpHFYQYLDZLrOf1K1JSo1jwT+V8tjflt3Y7K07NgvBo4eL137jVXVYTijXslCXbGgcOFUEoF6jLn+f3askte79y7hf40l3ss/Kt4DEYD/HNT61pDGxnpCBtm/SHI0i1UsyUEs8eYE4TsxhS4LUkcRctd1hBTrscqjMa1ryev+dV8BgIBh8CHJfXkCo+8chPxTMG8nPZfxQS8DKJ6+XNtK4q2eJA0DgyH4fKqUxgjDLO/VrsN4WVNVUdu5Ctn9NIojYJ9RoEZ6xcq+Sc6Y84NNhTib3nrI5C8c2W/FoV1fpTYFlaU15WfjC3mzqV2NRdfFknEobKwBhgIhT49B6f8T2BgO5nJDIzTAnBV/GDAmsuf/nSwPMaWAQcKES7meIzV9Zw6f4NpivTqEv5BM0UCc0CtQ3MU3ALP633RMAlnABo8Ot/QChZ6qQaawtxAsyM7GLcbzVdIFkKxqDfHjL+H9FBvaQwxJXPPllM8I+sfL9lMx1vTwK2bvSSGBEHk8Nnz3/xjQHuQ6X78s07ivlpMGiRg/A4R2eUDxBTeuwvErJhS0Do9qZARvsp7vCc09zzgkZzIQ3T+9ZE/QDgnl0lyuc8+AEwfF8TKgbwWUnD06D0PP+tkdpWkgORx7yC2OyYKcpc65A1VEkmrr/5hh5bb/OAtpx0WeywVDKcZmVR1cuqkez7ZdPJMMjtQTSeJ7Mh0+mTcCz4LoKaSxZTXKLdQLIOdGaVmVJi1olJFhmlDItkknlWDVJT3yoYls+sACwaJokbSVeD5VpDwgRHZolkkLWlhaJligt3YaaQkrEn9+V5TiriuxbsxmQsIlz2PtsaaI/JMSkBwRVrSMMffUR6iPxUAT52IUGktzVHcVAQGACJnnpKVOOV+4AwhMOvXmImPjuTvXzxDnJZqzSI3kR5BkKgGKarUM9nspfj/BUg63V6lpRcQaa2SYYMHR2XREbQ3v2WstBAFev79BI+R39cq6vsbN/ul4PvV/tkDD5zKXN0B74EXKUtf07n8u9QW4m2VVs+7VHoXn1XnvVU3sN7GFYZEUl9HfVQXspW8VidgkZRAnZNc2dx7lI+pQ3SCv0v3XzyqwrIv0bikfoFb+NqK3Zws9mesrpKTyatUMFZYwg5AqQKIT6cnSUhtQG/x/no6M6RB6c5FD+ceN2695B3aLpvCquF50kiqIXTbeDM5UNTa403K0rWJJZjJMjYbvLDwUER0EiEEtzZo6zZti4XgvZs/YR3fQDqWuvMzF7opqzepsGgnCdFH3zoCeGUqyb7RtbKtpBb1pIVKVIu2l7aFiE72J7gAzYa/5lJEfta44lCtdDLfI5Rfrw5cn/PnGWO63gw3GE8dQpQR5VsxXY6SxOaZY2Y41ecqhN1vThqERc56hTUdzMDs5epFialuChGW7qREptkAQfQIQkaTWqO2irIe1y3HEhSxVxFXhR3Xd7esXwuY+eHJoG54GHrad/ZJQu+ibEp0U8/WSjoiJ1sysRPLq7fJmzCOHsrkLGTwBNhXzbl8KfZ+Ov48yEWcR6hOWWzAFdxNF9fSzKw7nOjR7pWENq7JRdM6G2iOoXseUcNsnFLRVQYxGUucQROowRRJb1ECL5Zc48TjF9BNM55ABobF2NMz3ETWTFh3jc12yRK6h/VgibqQMQEeDMXaClW782fv6DvgTMEsgpSc5Mtm6PoSIVpaHPA9+idLKa6Q12SytVRTNqwSrT2W+N1oMfO0nxqORs/ceYD+X8ww/rGgq7I8ELtkfUDkoHcbkRDpKqHigI1glxrIALgVir7Na0MDexxGe3kEK4TSZbQi3e4gjaPW2OLhW1zOZixLltA4msAF1uoJn0dGRyvRnBoS2HB1Q1xTuYNpYi+y8ipuJcTD9UMaFheJoQNzkgh8jiHbuy5Eub+qtTGwN/NNLxqMxvYe7ccl6AsoGCRADwmhxOx23nFc22YxWvEkebjyQxboc6NoMFyCeqYZpS6zGgZGFzIOB4slts2g/sUdLybs2pRnzkzpzYktjhWqrCMeAm03hPa59u2ZvmDKEVJpgtB1jLQYT4IG8MWMZgLeXbb7SlD2s2sIjE+/UvMn88yBrgGOIKyM9PGCna9JeKmrutvlJzMxKID/Opfmiz3LVjg//BvBFqU/w0gm+iUoGfnHXi3ahzWvn6dBRSV/qsUl/kgSgDQmpI9Pj5A6gXQMBjezHzKZlFqxn22ng3GtEkNregpOOV8D8g/z4PZVrTDf1DKJg+w/oA3U572a19C0C5+Y5snjZCUAzowW1oQLTM+jpai3nzpWT3v4xEFhNCbZV2S69FZ02nMvs3ygudK99Em8QMtmZgdmWbSF5LzfBtHUtwha/6OK5oF6dgL5m5KD/yxxZ82NDViWoBgkmNFqlOtPAJc5Z1H9G0vHLGiEYWquOfan841B7Ddgjb50Odf139+ETYoewVW89kDC86EGgxz98AOZU1Aj8P3Dci+hipidq5Wqadjud+Pqe0/61WHz3bP61RNHwarlN5cdWZioDZeldQwXgmcz4RdZi1sW6/RrCDZUYFJZxaBAMe3j+zMgDrV3iVfNi30TjvQ1v5+KazwP8KBh2Som2cJWiw6HBMAJx0vZ1vnwZhqkN9xUXCx1S/ROmQ6feUeyzNAVMYnaIAr2jMAudRI2CouZFIm6I3fInuXwdbFS38cGQ0fRLyaWzF3bcyrnswh6rDKPF6g6kGllt5iuX09nEP5/CsUTxraDtG4nNPCzS5BkP6iqq+Zx6dkgUAzUVa0t4HQbnz8QOf5B0S+VpItZsQo4NhsuYUZMA+VskQwFLqipJqoRzudOgbVlvR+DTVGQlH0KWUKUG0ILfSiWPfI+f7EWY+Kk+SpGhu4ufQ8Xkn/ZDqc52A2uVEazlYWi0B0+IgfdRAwSfJOOwmcpiGpoBIrexDphqOQdDV4p2j0BfXPuO9RQl4DCscD1Mwln1Olp9Nr7mARM7buEY27sPonMdvPzqtBv1UAPVBIPa40YrSKyuinn5p8QKyVzSqSg3+Le0rrTwmZ4roKmrpiCiy7FymvxmnslR5V7mWySGEtyg6aABZGDUIjMjL0M4uePsOLItXXRZeOk7Sp2lAKRQDdJLJkYGgvN6Q8hexzGH95i/KmHB0oJEQyxK8zTUGTa9GKCDCmqac5+8G1VXlaq9AkR5dEOVqIkLj9xHshh0/uiPr/uflbNZGeskSEMZFymFO16bUfLegEWPWxrvHB7o/bb7l+HWJxyxXB8+c0CfEzRBowJVDdDuXB6pTlLvnXCGQbxlOMPWpvH17c8bz09x5Pnc2z1d73lBCP6ANYiAq6FVpKWj1+6ocaAoYTycu1aanw7xphRG14p/zGyUKWPGonel1rjUYbYuGBugNH8fACv5CEt9xxUDuWLcEab8MXR5EpeXom/oVFzkiUUW80zzYwWJEWkLpw4Dg99pLkkKX+RrvYNCjdGnyO6JnA7yHRDv4xzJQDpHhKN0XuOyT5/3EZSzm6XSjv72GO/zM7AAbjh9uevuzpZbnYo9ADMi8y2TYhEt7zHEc+z7YQq7T37ZU6V+tetYvIqeSOLSfw9VMLS/i38RCdWxwOiO4ZTBB8/uodcldf1sVGezLjIOQTTitn7BYHPBEq/EwU7VnwzENmTwsJdDTFDympB5r9+quV0VjR4UAK2AwpGUTrfJyW+Meu8KhBKudQsdqqbYRtF1iqJOCoRyjXUVMCgmsogDvbu+vcI1l0xzs9Ne9SUGQjcgB366yOhl+iwplk7tzOeA4zzsW3ttYoYixC275clnYP0NXMhSeEVnKggOzN25F3tZFYkxeOKk+MiMLMV0/OXPYuEbzo69zg0/birRldEJTaPoWf+mG97kckbt/TWsc01Uvc5Tw53wY6YCukai0G3OPJTz+leZgPfMjJ74Er4418BfuLs+XKOnz9YUv7KmbKpcZA0RONoFBlypj3i4QNcoEBs36aeAoFe9OAuroeQflrXa66VSDltawbJXXnwJ/SLDCBL4iCmEyj/rurac8PIWSN8qjgmxLjd8gRGT3p6UwSmjR5cmjW8aKVdck2O9ivBfAYXhyRxfffVK5CW6g56IagSaZe1oDY5moBntHZUIMZyc/ZehUFOY1OOAelTs3msl3vWzso/BMbvhNPgoEjnWxJXrxTHVxML9NHvgT2p4LBjwy9Q4CJH5KbnZndH8hNSfad0Y0ThyqQ90m3PO45uc2VZrod9yxdTDVef6cvzXtFEivf5lkVzw3ns7TbXfgpPSgfOxpUgW45f9v2aEqnYrlq0jFFlMcvdqCo3j8N8rVmJafwIHbxo7gyAIQuNKxXNaf0kNJv50y1AQ6j1pC6klnMmdSFoGIm8Yisp6Y1nq8MMNdlFONqU3SDDnqh662qJBOr7/TvE06Px4AUB1eieGnCoAgmIur65TFs8AAAAAFYK+pPadtpqlRzVi4MbSE+mj1/3iGIIRqF8TEPG1AsqG7cEiko63Nkp2nbWLMuN8cL1UZGj8jVlDG7+WRfPTas2eMtlfZUr2K7xXz41G+3Zbg/e6DtzQeUNpezFaOEIfZYmNbLGxMScsn6IDm8rQQwbyhNNgdcOVg1AS/qIgikSTFoqZ4M6/JI5gwfn+FeLNS/HHHJFcR3lNAeeOl33ToUkdNCDKsMzLk3ZJwXWEoGJg5qhotCAgigPrsPJfFDjZCs6cvm4QWyg6xBAYxEJxzVQpBW8DZ8OYzP8Qv3/RMTxmYQlh5vB/XmZCLz6azWw/PEjqC8vuJiN7kLjfiPhhEME6YnXOgwQVDPrU7VG79C85hygrhrLP1nqIx2jKK+xc8ZtDebPBkrEj9ki+eYtzPaJIP4oHGQSdFN7HP3PpqEQaCW/61lFxk/QGjobqKwJniCQPc5gqrm746K+9tSOZs5GuEf7JRaThgVjhSKPOZ1tKgXuRDtxZlESi4YkzCxYWkT+Nc2ur5y9qiJ6pUHRCi8aNZtlV10he9wkCDPg3wcwbnH3wJhbyBoFlKufce+xX0VXpVhVeFiX0cJc/gnok/3CcgN/WzVZ45fQ76iXIA8qGnnapyMeE3lz/elrGLxGvSkykIEZQDaz2pXTxYhMrkxMTFAIWU+nV3JC1UPfWZABl+hiby6VNavvBmzHfK74by4sTMbSib8q1ZIG1UwTd/8pa4J+5BBQaTeioh3oe488AjjQMLxB6qpj3Wykf3bLN4ZWJQfzXudKOcKV51reTVr5eWFagTNLPEuxwyp8Zh0OgTNRzm7/j0RuSna6H/2uVXbm7Nlu36gI7+j/diWJ/iNtZrJtzO/cO/pOTscnJt5NlBXX5/4RTFjwGZDEqioAMBm3Of8a8zuY8661GmcDlyEpG3Lnn3i77OkJPdHL34tDCKq7G+Ydrb+Idmk8dj9i0oLIW/AF7fIQZizNxHnscQY3QbXD7VVbjo63jY3AnY+FiKbMoBuLsIQWH3x9Atexl6ADGhY+2zZt+nGk1JBKj6n5JPAgxst7Rh59UWOW6s8MWY806D4ofzUwwDp3vCmUepEE/mL3nqi7pEXHT5h94904OuuLzNceijrCeCkIfR051JBo0AXxppqdZ0FWRlhxc9H11ojTIqccxpuc0tYSMCHjgYtsZImNb3gX9gJF3O381tyQvMPS8yRL7InjOXzEZ7DNsCCs57OL7/VdK4HFlWvXqnEZP2CNtdCVkovjxyD6hUlJAQqxPO/gaccYSwVQipU875nGC15B18DgGaVuDgYYFpdRcr0uRk98GRns50XbzHD+JAJO1yq8V5aUm1BpEpcYqJ9Q5xeuCyV51je/C41k2Q6vUUBf9jLd6mUt+JYHBJeTXfaPBmPzyoErUmuB4IhHCsc2qJAY9/fVo1Ovl6Da1aBLdrO2LKq8SdL6NOcgU2OQZ0N0ZOQyFcQlDN5UAiAk+gNcg3O8bdJsYxgylZdC4EscQ2SfzXlz0PLL+WcypAdH5Pc2a27NsHCrjVC8Wy8A9feMl6cq5HBV6xC/XKT8AwFy1mOGGhswNFNejKMPzItn8kuyOn1HZjd4f7sTotc+BSwsG+v44ELulRF+D5m3xsH8qDaI+YS6EkqGCBEgvRo0Dobb5t+QaME6nAqdLhKMgfpDWMbM4/jVAttaOUcBY10sJCnEShlzBLsI0cJmsetv1+Ru/UGfFqnk3UuYt72eVjzX1A45uWHED0wleDd4jkTLBPAAMhYrQKWncPfTupCI1SBX8PXFZj6KZJ31SED3cDrg/7FetntfPHOZJjhYH2DbpKmj//pgajKnORTd0HyxrvFd8YmQS+cIlqmSD/Nint6AbmrKT4CenBrwiokguXyt1B5ZKY9bg6YQt+dT76jNa2+gk2NlxeyExveY1j/PM+r+12aNLSr7j8bmJY1pXmEZF+7XiUCv5X+JeHG+6PaUyNv2dPsIgg8BE5BdiWopSraskpbz6M2MZQrMDYChxySZTVYHVSEuaIKf9GqAnVRVd3dOA8DN2Ob9pSkmiBzDkGhH4DUHlch215JZlOVEcaweWNzTyMc8PkCMfhkxQ1H0VMnRdYAcPSSILbWQRiBTqKuiKWWiEcf+MfJvHuB4HXV472RAe+1hGwKWZmkaPcAFFRAmHXtk7Wd1S1UseMf3C8VfSkfzZQGhOEDDfE2dOYFOrVDHk95NlXm8p1ik5MuuJLlVFCwTaW+eD6IfQxgnpfL4g1sYti9NmSR7Ckq6qD1JJ03t0z/nUEqKMYQKGECb1gFuSwOfPHNUkDcsRrLbVQv2EQPz7rDREvQ/pyt0TUL3SHjwyo2oc4fCBeFTNEjSd4+JZ87X5UXPXtgerXszLLh9X43GSXdpsSEKbas0+pt7Pbe4BSn/FI+bVnsrHE9RXU4MXDrWPqAqIi0YI0F3h3rdOC1Dx2BKz0wtUoPSNuM7CWIadk0WL1CNtC+FfJuP9miegiwO3VxetNPaYNWkP2ckZ1JA87GmdbI3WShRkmTk1EtMtPwWEpK8d08l+fW0W4BY6dZPId+1969FbnC2tDGAWI7PrZGFWclCMrs9pxlyoavInOaXLvb/3JbUC4YkPz1f5fnOompI5K0PtgNKL/xPbjq58aeUIxuyzsasAz2kvGUxPtwpFkYOR8lmpFeMOBy3bxVOutnNGz++XhdeLHaa8Rf1sFNHPnv+Uxt3qneEUR2bYozwBcHsdMsZacLR/KvzuV6s1ZzFJOSILoPzt3kJYzpWrrh3mrUDoLCUddg8c05jyAoMXOTjwfqHsQGTeH30dLiiDcx2QYy/2jlrQpGouBCq0O9l6rGn91ZaEdY+RJDnKvVme/DX93YuiDgggx9SGxwvgnBXqJ3CpAKKYn9HqnRxjqgDEjZzLUcfudUXgKMXcYDhH170FIx1t2CH495Ajm/XU5Y5Lk2UzkP7wkXqVOW5W6i0IIWy61E3J0wAip74n01kM48lxvQmwqVTS0cTHXYuBbep1lGjvnRBOUvmSslPEXiCc8K2V9Dbvd04+sbDcu82/jxep4Ad2H3Yp2fXOzz+piDP952GgkgjrLAc3tx+tixJn15574saBbYlmxbT0oY35L/b/6DRV7mshWbeqIb0PaQK8+TY1z1Sc0DbveLbGB42IxDddIFiax147bQrNSInT1ezLjrFKsV+Yvn8YEpED1Oj1Ci0WcGiCVOrivpFp4B9RploEByIxvePZDK2U4A3yIcPH8JwGC2mddTnKu23Ol13TKi4ZX4BQMOcbDdmRr5sqkTp/s5OjExgQ0YM/aYjFFGf4sGZoF0u1SWgL5j1+EpGFJZXQOWbElHw9JJp/5adX8v7kkudUheU9XfJNLl5N7loHCoHmdzpmYNjSbO3ofM+XaMkJqcFO3j5iiaL0B9ZjDSQ3FayZ2zFojhgaEw6I3wNWwgailNzUh8FCJHX1hSXhtTZ3cEPz8krqH7AUy7lP4Yh8hY/ShX+51JL/NiWOoEbuJ8NIn315HKtb1IcAIzJojS3bFJdMEGCHRYXf/uZnReKVs8o9UzVO5sJPTFXxbiC7B4R0i8Rn94NIot54HjPcfnB4nWphGQIZjFt+5L3uyj5MDVQbGzwUIBG0O27zlR08J4uh5GaBS5O1ivwQwfO4YZxQnX9a8ZnJUfoqve/Chluuo0wg2J8rDOY7ELecnN4Gi/rscbbHhYhF8nfQHfTb6LcfKuWFgCRFrDcPdzTK4ADPdF1maLeV0keDep+l5aA35dFrskmb/WtPu8xT7t2YSOIsT5t7rbVHP9Yv7byCSeSeUBTke5zGGm86SBAH461AjXieb9QD8UHI64I2HkpbFFa4NMvKHd5PAuAvnVy3vAQlfy0hmH3F4OfHNrcuottJAyZWw/ULR3hWhxGmMBAz6F4xiDDXLIQAz7UGQUPH6gaxfDya4nWdO0F4O8oCm8/d06FDX8qBrkGl4pLJMO6IfoCZAYftWWIlWmohE+QzUjkSeSsnXm9U9053b4KVXgYPeatuZK3Z5YZnSne+Mg4Sv7YB2RznqWJraJGYGf1KUbgHWSWX7thaxZPb/kYUE8E6w21n+FmMzS/ExQEbzPnKyHu6R62UQQB9A8Nrx6LnDNFxOS//bknkwigcGDUA/KnxM2w6NYXPgVzkoixwX1Io7Nw8OMtFzkGJTh8VBHhAXVFVIxqY1RkvK9hj0UN4RPuAAAAAAAAAAAAAA==" alt="Matrix World Research" style="width:100%;max-width:220px;height:auto;display:block;margin:0 auto">
  </div>

  <!-- Card -->
  <div class="card">
    <div class="card-title">Welcome back</div>
    <div class="card-sub">Sign in to your admin panel</div>

    <?php if ($error): ?>
    <div class="error-msg">
      <span>⚠</span> <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <form method="POST" action="">
      <div class="field">
        <label>Email Address</label>
        <input
          type="email"
          name="email"
          placeholder="admin@panelengine.in"
          value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
          autocomplete="email"
          required
        >
      </div>
      <div class="field">
        <label>Password</label>
        <input
          type="password"
          name="password"
          placeholder="••••••••"
          autocomplete="current-password"
          required
        >
      </div>
      <button type="submit" class="btn-login">Sign In →</button>
    </form>
  </div>

  <div class="login-footer">© <?= date('Y') ?> Matrix World Research. All rights reserved.</div>
</div>

</body>
</html>
