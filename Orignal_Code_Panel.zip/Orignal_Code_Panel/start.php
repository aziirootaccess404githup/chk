<?php
// ============================================================
// PanelEngine Survey Panel — start.php
// Entry point for pre-screener flow
// URL: /panelengine/start.php?sid=RP001&uid=[UID]
// ============================================================
require_once __DIR__ . '/config.php';

date_default_timezone_set('Asia/Kolkata');

$sid = trim($_GET['sid'] ?? '');
$uid = trim($_GET['uid'] ?? '');
$vid = (int)($_GET['vid'] ?? 0); // vendor id (optional)

if (empty($sid) || empty($uid)) {
    die('<h3 style="font-family:sans-serif;text-align:center;margin-top:40px;color:#ef4444">Invalid link. Missing SID or UID.</h3>');
}

$db  = rp_db();
$ip  = rp_get_ip();
$ua  = $_SERVER['HTTP_USER_AGENT'] ?? '';

// ── Fetch project ─────────────────────────────────────────────
$proj = $db->prepare("SELECT * FROM rp_projects WHERE sid=? AND status='active' LIMIT 1");
$proj->execute([$sid]);
$project = $proj->fetch();

if (!$project) {
    die('
    <!DOCTYPE html><html><head><meta charset="UTF-8"><title>Not Available</title>
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0d0f14;color:#e2e8f0;margin:0}
    .box{text-align:center;padding:40px;background:#111318;border-radius:12px;border:1px solid rgba(255,255,255,0.07)}
    h2{color:#f59e0b}p{color:#94a3b8;margin-top:8px}</style>
    </head><body><div class="box"><h2>⚠ Survey Not Available</h2><p>This survey is currently not active.</p></div></body></html>
    ');
}

// ── Start session + store data ────────────────────────────────
rp_session_start();
$_SESSION['rp_sid']     = $sid;
$_SESSION['rp_uid']     = $uid;
$_SESSION['rp_vid']     = $vid ?: null;
$_SESSION['rp_ip']      = $ip;
$_SESSION['rp_ua']      = $ua;
$_SESSION['rp_start']   = time();
$_SESSION['rp_project'] = $project;

// ── Redirect to prescreener ───────────────────────────────────
header('Location: prescreener.php');
exit();
