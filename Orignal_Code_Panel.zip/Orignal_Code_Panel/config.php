<?php
date_default_timezone_set('Asia/Kolkata');
define('RP_DB_HOST', '127.0.0.1');
define('RP_DB_NAME', 'u117568400_Matrix');
define('RP_DB_USER', 'u117568400_Matrix');
define('RP_DB_PASS', 'Krishna@MWR0522');
define('RP_DB_PORT', '3306');
define('RP_ENC_KEY', 'MatrixWorld@SecretKey2026#Unique!ABC7');
define('RP_SESSION_NAME', 'rp_admin_session');

function rp_db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=".RP_DB_HOST.";port=".RP_DB_PORT.";dbname=".RP_DB_NAME.";charset=utf8mb4";
            $pdo = new PDO($dsn, RP_DB_USER, RP_DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['error' => 'Database connection failed']));
        }
    }
    return $pdo;
}

function rp_encrypt(string $data, string $sid = ''): string {
    // Short opaque token (not reversible on its own) — the real UID is recovered
    // via the rp_uid_mapping table, which is already saved alongside every token.
    return bin2hex(random_bytes(5)); // 10-character hex token
}

function rp_decrypt(string $token, string $sid = ''): ?string {
    try {
        $raw = base64_decode(strtr($token . str_repeat('=', (4 - strlen($token) % 4) % 4), '-_', '+/'));
        if (strlen($raw) < 16) return null;
        $iv  = substr($raw, 0, 16);
        $enc = base64_encode(substr($raw, 16));
        $key = hash('sha256', RP_ENC_KEY . $sid, true);
        $dec = openssl_decrypt($enc, 'AES-256-CBC', $key, 0, $iv);
        return $dec === false ? null : $dec;
    } catch (Exception $e) { return null; }
}

function rp_session_start(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_name(RP_SESSION_NAME);
        session_start();
    }
}

function rp_is_logged_in(): bool {
    rp_session_start();
    return !empty($_SESSION['rp_user_id']);
}

function rp_require_login(): void {
    if (!rp_is_logged_in()) {
        header('Location: login.php');
        exit();
    }
}

function rp_current_user(): array {
    rp_session_start();
    return [
        'id'    => $_SESSION['rp_user_id']    ?? 0,
        'name'  => $_SESSION['rp_user_name']  ?? '',
        'email' => $_SESSION['rp_user_email'] ?? '',
        'role'  => $_SESSION['rp_user_role']  ?? 'viewer',
    ];
}

function rp_is_superadmin(): bool { return rp_current_user()['role'] === 'superadmin'; }
function rp_is_manager(): bool { return in_array(rp_current_user()['role'], ['superadmin','manager']); }

function rp_get_ip(): string {
    foreach (['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) return explode(',', $_SERVER[$k])[0];
    }
    return 'unknown';
}

function rp_geo(string $ip): array {
    if (empty($ip) || $ip === 'unknown') return ['country' => '', 'city' => ''];

    // Multi-provider fallback chain. Previously this only called ip-api.com,
    // which is generous (45 req/min) at low volume but silently starts
    // failing once lead traffic grows past that — the old code just returned
    // an empty country/city with no fallback, which is why Country started
    // showing "—" more and more as volume increased. Now if the first
    // provider is rate-limited or down, we try two more independent
    // providers (different rate-limit buckets) before giving up.
    $geo = rp_geo_try_ipapi($ip);
    if ($geo) return $geo;

    $geo = rp_geo_try_ipwhois($ip);
    if ($geo) return $geo;

    $geo = rp_geo_try_ipinfo($ip);
    if ($geo) return $geo;

    // All three providers failed — save the lead anyway, just without geo data.
    return ['country' => '', 'city' => ''];
}

// Shared HTTP GET helper — uses cURL when available (more reliable than
// file_get_contents, works even if allow_url_fopen is disabled on the
// server) and falls back to file_get_contents otherwise.
function rp_geo_http_get(string $url, int $timeout_seconds = 2): ?string {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $timeout_seconds,
            CURLOPT_CONNECTTIMEOUT => $timeout_seconds,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT      => 'PanelEngine-GeoLookup/1.0',
        ]);
        $body = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return ($body !== false && $http_code === 200) ? $body : null;
    }
    $ctx = stream_context_create(['http' => ['timeout' => $timeout_seconds]]);
    $body = @file_get_contents($url, false, $ctx);
    return $body !== false ? $body : null;
}

// Provider 1: ip-api.com — fast, HTTP only on the free tier, 45 req/min limit.
function rp_geo_try_ipapi(string $ip): ?array {
    $body = rp_geo_http_get("http://ip-api.com/json/{$ip}?fields=status,country,city");
    if (!$body) return null;
    $j = json_decode($body);
    if ($j && ($j->status ?? '') === 'success') {
        return ['country' => $j->country ?? '', 'city' => $j->city ?? ''];
    }
    return null;
}

// Provider 2: ipwho.is — separate provider/rate-limit bucket, HTTPS, no API key needed.
function rp_geo_try_ipwhois(string $ip): ?array {
    $body = rp_geo_http_get("https://ipwho.is/{$ip}");
    if (!$body) return null;
    $j = json_decode($body);
    if ($j && ($j->success ?? false) === true) {
        return ['country' => $j->country ?? '', 'city' => $j->city ?? ''];
    }
    return null;
}

// Provider 3: ipinfo.io — works without a token, third independent bucket.
// Only returns a 2-letter country code, so we map it to a full country name
// to stay consistent with what the panel already shows/filters on.
function rp_geo_try_ipinfo(string $ip): ?array {
    $body = rp_geo_http_get("https://ipinfo.io/{$ip}/json");
    if (!$body) return null;
    $j = json_decode($body);
    if ($j && !empty($j->country)) {
        $name = rp_country_code_to_name($j->country) ?: $j->country;
        return ['country' => $name, 'city' => $j->city ?? ''];
    }
    return null;
}

// ISO 3166-1 alpha-2 -> full country name, used only to normalize ipinfo.io's
// 2-letter codes to match the other two providers' full-name format.
function rp_country_code_to_name(string $code): ?string {
    static $map = [
    'AD' => 'Andorra',
        'AE' => 'United Arab Emirates',
        'AF' => 'Afghanistan',
        'AG' => 'Antigua and Barbuda',
        'AI' => 'Anguilla',
        'AL' => 'Albania',
        'AM' => 'Armenia',
        'AO' => 'Angola',
        'AQ' => 'Antarctica',
        'AR' => 'Argentina',
        'AS' => 'American Samoa',
        'AT' => 'Austria',
        'AU' => 'Australia',
        'AW' => 'Aruba',
        'AZ' => 'Azerbaijan',
        'BA' => 'Bosnia and Herzegovina',
        'BB' => 'Barbados',
        'BD' => 'Bangladesh',
        'BE' => 'Belgium',
        'BF' => 'Burkina Faso',
        'BG' => 'Bulgaria',
        'BH' => 'Bahrain',
        'BI' => 'Burundi',
        'BJ' => 'Benin',
        'BM' => 'Bermuda',
        'BN' => 'Brunei',
        'BO' => 'Bolivia',
        'BR' => 'Brazil',
        'BS' => 'Bahamas',
        'BT' => 'Bhutan',
        'BW' => 'Botswana',
        'BY' => 'Belarus',
        'BZ' => 'Belize',
        'CA' => 'Canada',
        'CD' => 'Congo (DRC)',
        'CF' => 'Central African Republic',
        'CG' => 'Congo',
        'CH' => 'Switzerland',
        'CI' => 'Ivory Coast',
        'CL' => 'Chile',
        'CM' => 'Cameroon',
        'CN' => 'China',
        'CO' => 'Colombia',
        'CR' => 'Costa Rica',
        'CU' => 'Cuba',
        'CV' => 'Cape Verde',
        'CW' => 'Curacao',
        'CY' => 'Cyprus',
        'CZ' => 'Czech Republic',
        'DE' => 'Germany',
        'DJ' => 'Djibouti',
        'DK' => 'Denmark',
        'DM' => 'Dominica',
        'DO' => 'Dominican Republic',
        'DZ' => 'Algeria',
        'EC' => 'Ecuador',
        'EE' => 'Estonia',
        'EG' => 'Egypt',
        'ER' => 'Eritrea',
        'ES' => 'Spain',
        'ET' => 'Ethiopia',
        'FI' => 'Finland',
        'FJ' => 'Fiji',
        'FM' => 'Micronesia',
        'FR' => 'France',
        'GA' => 'Gabon',
        'GB' => 'United Kingdom',
        'GD' => 'Grenada',
        'GE' => 'Georgia',
        'GF' => 'French Guiana',
        'GH' => 'Ghana',
        'GI' => 'Gibraltar',
        'GL' => 'Greenland',
        'GM' => 'Gambia',
        'GN' => 'Guinea',
        'GP' => 'Guadeloupe',
        'GQ' => 'Equatorial Guinea',
        'GR' => 'Greece',
        'GT' => 'Guatemala',
        'GU' => 'Guam',
        'GW' => 'Guinea-Bissau',
        'GY' => 'Guyana',
        'HK' => 'Hong Kong',
        'HN' => 'Honduras',
        'HR' => 'Croatia',
        'HT' => 'Haiti',
        'HU' => 'Hungary',
        'ID' => 'Indonesia',
        'IE' => 'Ireland',
        'IL' => 'Israel',
        'IM' => 'Isle of Man',
        'IN' => 'India',
        'IQ' => 'Iraq',
        'IR' => 'Iran',
        'IS' => 'Iceland',
        'IT' => 'Italy',
        'JE' => 'Jersey',
        'JM' => 'Jamaica',
        'JO' => 'Jordan',
        'JP' => 'Japan',
        'KE' => 'Kenya',
        'KG' => 'Kyrgyzstan',
        'KH' => 'Cambodia',
        'KI' => 'Kiribati',
        'KM' => 'Comoros',
        'KN' => 'Saint Kitts and Nevis',
        'KP' => 'North Korea',
        'KR' => 'South Korea',
        'KW' => 'Kuwait',
        'KY' => 'Cayman Islands',
        'KZ' => 'Kazakhstan',
        'LA' => 'Laos',
        'LB' => 'Lebanon',
        'LC' => 'Saint Lucia',
        'LI' => 'Liechtenstein',
        'LK' => 'Sri Lanka',
        'LR' => 'Liberia',
        'LS' => 'Lesotho',
        'LT' => 'Lithuania',
        'LU' => 'Luxembourg',
        'LV' => 'Latvia',
        'LY' => 'Libya',
        'MA' => 'Morocco',
        'MC' => 'Monaco',
        'MD' => 'Moldova',
        'ME' => 'Montenegro',
        'MG' => 'Madagascar',
        'MH' => 'Marshall Islands',
        'MK' => 'North Macedonia',
        'ML' => 'Mali',
        'MM' => 'Myanmar',
        'MN' => 'Mongolia',
        'MO' => 'Macau',
        'MQ' => 'Martinique',
        'MR' => 'Mauritania',
        'MS' => 'Montserrat',
        'MT' => 'Malta',
        'MU' => 'Mauritius',
        'MV' => 'Maldives',
        'MW' => 'Malawi',
        'MX' => 'Mexico',
        'MY' => 'Malaysia',
        'MZ' => 'Mozambique',
        'NA' => 'Namibia',
        'NC' => 'New Caledonia',
        'NE' => 'Niger',
        'NG' => 'Nigeria',
        'NI' => 'Nicaragua',
        'NL' => 'Netherlands',
        'NO' => 'Norway',
        'NP' => 'Nepal',
        'NR' => 'Nauru',
        'NZ' => 'New Zealand',
        'OM' => 'Oman',
        'PA' => 'Panama',
        'PE' => 'Peru',
        'PF' => 'French Polynesia',
        'PG' => 'Papua New Guinea',
        'PH' => 'Philippines',
        'PK' => 'Pakistan',
        'PL' => 'Poland',
        'PR' => 'Puerto Rico',
        'PS' => 'Palestine',
        'PT' => 'Portugal',
        'PW' => 'Palau',
        'PY' => 'Paraguay',
        'QA' => 'Qatar',
        'RE' => 'Reunion',
        'RO' => 'Romania',
        'RS' => 'Serbia',
        'RU' => 'Russia',
        'RW' => 'Rwanda',
        'SA' => 'Saudi Arabia',
        'SB' => 'Solomon Islands',
        'SC' => 'Seychelles',
        'SD' => 'Sudan',
        'SE' => 'Sweden',
        'SG' => 'Singapore',
        'SI' => 'Slovenia',
        'SK' => 'Slovakia',
        'SL' => 'Sierra Leone',
        'SM' => 'San Marino',
        'SN' => 'Senegal',
        'SO' => 'Somalia',
        'SR' => 'Suriname',
        'SS' => 'South Sudan',
        'ST' => 'Sao Tome and Principe',
        'SV' => 'El Salvador',
        'SX' => 'Sint Maarten',
        'SY' => 'Syria',
        'SZ' => 'Eswatini',
        'TC' => 'Turks and Caicos Islands',
        'TD' => 'Chad',
        'TG' => 'Togo',
        'TH' => 'Thailand',
        'TJ' => 'Tajikistan',
        'TL' => 'Timor-Leste',
        'TM' => 'Turkmenistan',
        'TN' => 'Tunisia',
        'TO' => 'Tonga',
        'TR' => 'Turkey',
        'TT' => 'Trinidad and Tobago',
        'TV' => 'Tuvalu',
        'TW' => 'Taiwan',
        'TZ' => 'Tanzania',
        'UA' => 'Ukraine',
        'UG' => 'Uganda',
        'US' => 'United States',
        'UY' => 'Uruguay',
        'UZ' => 'Uzbekistan',
        'VA' => 'Vatican City',
        'VC' => 'Saint Vincent and the Grenadines',
        'VE' => 'Venezuela',
        'VG' => 'British Virgin Islands',
        'VI' => 'U.S. Virgin Islands',
        'VN' => 'Vietnam',
        'VU' => 'Vanuatu',
        'WS' => 'Samoa',
        'YE' => 'Yemen',
        'ZA' => 'South Africa',
        'ZM' => 'Zambia',
        'ZW' => 'Zimbabwe'    ];
    return $map[strtoupper($code)] ?? null;
}

function rp_device(): string {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (preg_match('/tablet|ipad/i', $ua)) return 'tablet';
    if (preg_match('/mobile|android|iphone/i', $ua)) return 'mobile';
    return 'desktop';
}

function rp_browser(): string {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (str_contains($ua,'Chrome')) return 'Chrome';
    if (str_contains($ua,'Firefox')) return 'Firefox';
    if (str_contains($ua,'Safari')) return 'Safari';
    if (str_contains($ua,'Edge')) return 'Edge';
    return 'Other';
}

// ── VENDOR POSTBACK (fire-and-forget) ─────────────────────────
// Sends a GET request to a vendor's own tracking URL without waiting
// for a response, so the respondent's redirect is never delayed.
// ── FLEXIBLE URL TOKEN REPLACEMENT ──────────────────────────────
// Replaces placeholder tokens inside ANY URL - a client's survey Live URL
// (vendor.php/capture.php) or a vendor's postback URL (rp_notify_vendor /
// rp_vendor_redirect_target) - same engine, same behavior, both directions.
//
// Supports every bracket style seen across the industry (case-insensitive,
// whitespace-tolerant inside the brackets):
//   {{token}}   double-curly
//   [TOKEN]     square-bracket   (this system's own original style)
//   {token}     single-curly
//   %TOKEN%     percent-wrapped
//   <token>     angle-bracket
//   $token$     dollar-wrapped
//
// Anything not matching a known token is left completely untouched - this
// never guesses or invents a value for a token it wasn't given.
function rp_build_url(string $template, array $tokens): string {
    $url = $template;
    // Order matters: double-curly MUST be processed before single-curly,
    // otherwise the single-curly pattern would wrongly eat the inner half
    // of an unprocessed "{{token}}" (matching just "{token}" inside it).
    $wrapper_patterns = [
        '/\{\{\s*%s\s*\}\}/i',   // {{token}}
        '/\[\s*%s\s*\]/i',       // [TOKEN]
        '/\{\s*%s\s*\}/i',       // {token}
        '/%%\s*%s\s*%%/i',       // %TOKEN%
        '/<\s*%s\s*>/i',         // <token>
        '/\$\s*%s\s*\$/i',       // $token$
    ];
    foreach ($tokens as $key => $value) {
        if ($value === null) continue;
        $quoted_key = preg_quote((string)$key, '/');
        foreach ($wrapper_patterns as $pattern_template) {
            $pattern = sprintf($pattern_template, $quoted_key);
            $url = preg_replace($pattern, (string)$value, $url);
        }
    }
    return $url;
}

function rp_fire_postback(string $url): void {
    if (empty($url)) return;
    $parts = @parse_url($url);
    if (!$parts || empty($parts['host'])) return;
    $scheme = $parts['scheme'] ?? 'http';
    $port   = $parts['port'] ?? ($scheme === 'https' ? 443 : 80);
    $path   = ($parts['path'] ?? '/') . (!empty($parts['query']) ? '?' . $parts['query'] : '');
    $host   = $parts['host'];
    $transport = $scheme === 'https' ? 'ssl://' : '';
    $fp = @fsockopen($transport . $host, $port, $errno, $errstr, 2);
    if (!$fp) return;
    $out  = "GET $path HTTP/1.1\r\n";
    $out .= "Host: $host\r\n";
    $out .= "User-Agent: MatrixWorldResearch-Postback/1.0\r\n";
    $out .= "Connection: Close\r\n\r\n";
    @fwrite($fp, $out);
    @fclose($fp); // don't wait for the vendor's response
}

// Replace a vendor's placeholders with real values in their saved postback URL.
// Supports {{token}}, [TOKEN], {token}, %TOKEN%, <token>, and $token$ styles
// (case-insensitive). Existing vendor URLs using [SID]/[UID]/[LOI] keep
// working exactly as before (100% backward compatible).
function rp_build_postback_url(string $template, string $sid, string $uid, ?int $loi = null): string {
    $url = rp_build_url($template, [
        'sid' => $sid, 'uid' => $uid, 'pid' => $uid, 'identifier' => $uid,
        'loi' => (string)($loi ?? ''),
    ]);
    return html_entity_decode($url, ENT_QUOTES, 'UTF-8');
}

// Look up and fire the correct vendor postback URL for a given status.
function rp_notify_vendor(PDO $db, ?int $vendor_id, string $status, string $sid, string $uid, ?int $loi = null): void {
    if (empty($vendor_id)) return;
    $col_map = [
        'complete'     => 'complete_url',
        'terminate'    => 'terminate_url',
        'quality_fail' => 'screenout_url',
        'overquota'    => 'quotafull_url',
    ];
    $col = $col_map[$status] ?? null;
    if (!$col) return;
    $stmt = $db->prepare("SELECT $col FROM rp_vendors WHERE id = ? LIMIT 1");
    $stmt->execute([$vendor_id]);
    $template = $stmt->fetchColumn();
    if (empty($template)) return;
    $url = rp_build_postback_url($template, $sid, $uid, $loi);
    rp_fire_postback($url);
}

// Does this vendor want respondents shown our own page (default), or redirected
// straight to their own end page instead?
function rp_vendor_mode(PDO $db, ?int $vendor_id): string {
    if (empty($vendor_id)) return 'show_page';
    try {
        $stmt = $db->prepare("SELECT end_behavior FROM rp_vendors WHERE id = ? LIMIT 1");
        $stmt->execute([$vendor_id]);
        $mode = $stmt->fetchColumn();
        return $mode === 'redirect' ? 'redirect' : 'show_page';
    } catch (PDOException $e) {
        // end_behavior column not migrated yet — safely fall back to default
        return 'show_page';
    }
}

// If this vendor is in "redirect" mode, build the URL to send the respondent to.
// Returns null if the vendor is in normal "show_page" mode or has no URL saved.
function rp_vendor_redirect_target(PDO $db, ?int $vendor_id, string $status, string $sid, string $uid, ?int $loi = null): ?string {
    if (empty($vendor_id)) return null;
    if (rp_vendor_mode($db, $vendor_id) !== 'redirect') return null;
    $col_map = [
        'complete'     => 'complete_url',
        'terminate'    => 'terminate_url',
        'quality_fail' => 'screenout_url',
        'overquota'    => 'quotafull_url',
    ];
    $col = $col_map[$status] ?? null;
    if (!$col) return null;
    $stmt = $db->prepare("SELECT $col FROM rp_vendors WHERE id = ? LIMIT 1");
    $stmt->execute([$vendor_id]);
    $template = $stmt->fetchColumn();
    if (empty($template)) return null;
    return rp_build_postback_url($template, $sid, $uid, $loi);
}
