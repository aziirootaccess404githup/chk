<?php
// ============================================================
// PanelEngine Survey Panel — capture.php
// Saves prescreener answers, encrypts UID, redirects to survey
// ============================================================
require_once __DIR__ . '/config.php';

date_default_timezone_set('Asia/Kolkata');
rp_session_start();

// Validate session
if (empty($_SESSION['rp_sid']) || empty($_SESSION['rp_uid'])) {
    header('Location: end.php?status=quality_fail&sid=&uid=');
    exit();
}

$sid     = $_SESSION['rp_sid'];
$uid     = $_SESSION['rp_uid'];
$vid     = $_SESSION['rp_vid']  ?? null;
$ip      = $_SESSION['rp_ip']  ?? rp_get_ip();
$ua      = $_SESSION['rp_ua']  ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');
$answers = $_SESSION['rp_answers'] ?? [];
$project = $_SESSION['rp_project'] ?? [];

$db = rp_db();

// ── Encrypt UID ───────────────────────────────────────────────
$encrypted_uid = $uid;
if (!empty($project['encrypt_uid'])) {
    $mc = $db->prepare("SELECT encrypted_uid FROM rp_uid_mapping WHERE original_uid=? AND sid=? LIMIT 1");
    $mc->execute([$uid, $sid]);
    $existing_map = $mc->fetchColumn();
    if ($existing_map) {
        $encrypted_uid = $existing_map;
    } else {
        $encrypted_uid = rp_encrypt($uid, $sid);
        $db->prepare("INSERT INTO rp_uid_mapping (original_uid, encrypted_uid, sid, source) VALUES (?,?,?,'prescreener')")
           ->execute([$uid, $encrypted_uid, $sid]);
    }
}

// ── Duplicate check ───────────────────────────────────────────
$dc = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=? AND original_uid=?");
$dc->execute([$sid, $uid]);
$is_duplicate = $dc->fetchColumn() > 0 ? 1 : 0;

// ── Geo + Device ─────────────────────────────────────────────
$geo    = rp_geo($ip);
$device = rp_device();
$browser= rp_browser();

// ── Save lead (click) ─────────────────────────────────────────
try {
    $db->prepare("INSERT INTO rp_leads
        (sid, vendor_id, original_uid, encrypted_uid, status, ip, country, city, device, browser, user_agent, is_duplicate, status_locked, source, entry_time, created_at)
        VALUES (?,?,?,?,'click',?,?,?,?,?,?,?,0,'prescreener',NOW(),NOW())")
       ->execute([
           $sid, $vid, $uid, $encrypted_uid,
           $ip, $geo['country'], $geo['city'],
           $device, $browser, substr($ua,0,500),
           $is_duplicate
       ]);
} catch (PDOException $e) {
    error_log("PanelEngine capture.php lead insert error: " . $e->getMessage());
}

// ── Save prescreener answers ──────────────────────────────────
try {
    $db->prepare("INSERT INTO rp_prescreener_answers
        (sid, original_uid, encrypted_uid, gender, age_group, education, income, device_self, open_end, created_at)
        VALUES (?,?,?,?,?,?,?,?,?,NOW())")
       ->execute([
           $sid, $uid, $encrypted_uid,
           $answers['gender']    ?? '',
           $answers['age_group'] ?? '',
           $answers['education'] ?? '',
           $answers['income']    ?? '',
           $answers['device']    ?? '',
           $answers['open_end']  ?? '',
       ]);
} catch (PDOException $e) {
    error_log("PanelEngine capture.php screener insert error: " . $e->getMessage());
}

// ── Build survey URL ──────────────────────────────────────────
$survey_url = $project['live_url'] ?? '';

if (empty($survey_url)) {
    header("Location: end.php?status=quality_fail&sid=" . urlencode($sid) . "&uid=" . urlencode($encrypted_uid));
    exit();
}

// Replace standard placeholders - now supports {{token}}, [TOKEN], {token},
// %TOKEN%, <token>, and $token$ styles (case-insensitive), not just [TOKEN].
// Existing client Live URLs keep working exactly as before (100% backward
// compatible) - this only ADDS new bracket styles.
$survey_url = rp_build_url($survey_url, [
    'uid' => $encrypted_uid, 'pid' => $encrypted_uid, 'identifier' => $encrypted_uid,
    'sid' => $sid,
    'ip'  => $ip,
    'age' => urlencode($answers['age_group'] ?? ''),
    'gender' => urlencode($answers['gender'] ?? ''),
    'education' => urlencode($answers['education'] ?? ''),
    'income' => urlencode($answers['income'] ?? ''),
    'region' => '',
]);

// Legacy bare-word replacements (no brackets, InnovateMR-style) - kept
// exactly as before, separate from the bracket-style engine above.
$survey_url = str_replace('ageval',       urlencode($answers['age_group'] ?? ''), $survey_url);
$survey_url = str_replace('genderval',    urlencode($answers['gender']    ?? ''), $survey_url);
$survey_url = str_replace('regionval',    '',                                     $survey_url);

$survey_url = html_entity_decode($survey_url, ENT_QUOTES, 'UTF-8');

// ── Clear session answers (keep sid/uid for end.php) ─────────
unset($_SESSION['rp_answers']);

// ── Redirect to survey ────────────────────────────────────────
header("Location: $survey_url");
exit();
