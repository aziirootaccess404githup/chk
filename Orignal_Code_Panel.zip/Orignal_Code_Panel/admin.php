<?php
// ============================================================
// Matrix World Research — admin.php
// Full dashboard: Dashboard, Projects, Clients, Vendors, Leads
// ============================================================
require_once __DIR__ . '/config.php';
rp_require_login();

$db   = rp_db();
$user = rp_current_user();
$page = $_GET['page'] ?? 'dashboard';
$msg  = '';
$err  = '';

// ── AJAX / POST HANDLERS ─────────────────────────────────────

// ── DELETE HANDLERS ──────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    // Pause / Resume Project
    if ($action === 'toggle_project_status' && rp_is_manager()) {
        $id = (int)$_POST['id'];
        $cur = $db->prepare("SELECT status FROM rp_projects WHERE id=?");
        $cur->execute([$id]);
        $cur_status = $cur->fetchColumn();
        $new_status = $cur_status === 'active' ? 'paused' : 'active';
        $db->prepare("UPDATE rp_projects SET status=? WHERE id=?")->execute([$new_status, $id]);
        $ref = $_SERVER['HTTP_REFERER'] ?? '';
        if (strpos($ref, 'project_view') !== false) {
            header("Location: admin.php?page=project_view&id=$id&msg=Project+".ucfirst($new_status));
        } else {
            header("Location: admin.php?page=projects&msg=Project+".ucfirst($new_status));
        }
        exit();
    }

    // Delete Project
    if ($action === 'delete_project' && rp_is_superadmin()) {
        $id = (int)$_POST['id'];
        $db->prepare("DELETE FROM rp_projects WHERE id=?")->execute([$id]);
        // Note: existing leads for this project's SID are kept for historical
        // reporting — only the project record itself is removed.
        header("Location: admin.php?page=projects&msg=Project+deleted");
        exit();
    }

    // Save Notes
    if ($action === 'save_notes') {
        $content = trim($_POST['content'] ?? '');
        try {
            $exists = $db->query("SELECT COUNT(*) FROM rp_notes")->fetchColumn();
            if ($exists > 0) {
                $db->prepare("UPDATE rp_notes SET content=?, updated_at=NOW() WHERE id=1")->execute([$content]);
            } else {
                $db->prepare("INSERT INTO rp_notes (id, content, updated_at) VALUES (1, ?, NOW())")->execute([$content]);
            }
            header("Location: admin.php?page=notes&msg=Notes+saved");
        } catch (PDOException $e) {
            header("Location: admin.php?page=notes&err=Notes+table+not+set+up+yet");
        }
        exit();
    }

    // Password Change
    if ($action === 'change_password') {
        $current = trim($_POST['current_password'] ?? '');
        $new     = trim($_POST['new_password'] ?? '');
        $confirm = trim($_POST['confirm_password'] ?? '');
        $uid = $user['id'];
        $u = $db->prepare("SELECT password FROM rp_users WHERE id=?");
        $u->execute([$uid]); $u = $u->fetch();
        if (!password_verify($current, $u['password'])) {
            header("Location: admin.php?page=change_password&err=Current+password+incorrect");
        } elseif (strlen($new) < 6) {
            header("Location: admin.php?page=change_password&err=Password+must+be+6+chars+minimum");
        } elseif ($new !== $confirm) {
            header("Location: admin.php?page=change_password&err=Passwords+do+not+match");
        } else {
            $db->prepare("UPDATE rp_users SET password=? WHERE id=?")->execute([password_hash($new, PASSWORD_DEFAULT), $uid]);
            header("Location: admin.php?page=change_password&msg=Password+changed+successfully");
        }
        exit();
    }

    // Save Project
    if ($action === 'save_project' && rp_is_manager()) {
        $id = (int)($_POST['id'] ?? 0);
        $client_id = (int)($_POST['client_id'] ?? 0);
        $client_name = '';
        if ($client_id > 0) {
            $client_row = $db->prepare("SELECT client_name FROM rp_clients WHERE id=?");
            $client_row->execute([$client_id]);
            $client_name = $client_row->fetchColumn() ?: '';
            if ($client_name === '') $client_id = 0; // client_id didn't match any real client
        }
        $data = [
            ':sid'          => strtoupper(trim($_POST['sid'])),
            ':project_name' => trim($_POST['project_name']),
            ':client_id'    => $client_id > 0 ? $client_id : null,
            ':client_name'  => $client_name,
            ':cpi'          => (float)($_POST['cpi'] ?? 0),
            ':ir'           => (float)($_POST['ir'] ?? 0),
            ':loi'          => (int)($_POST['loi'] ?? 0),
            ':max_completes'=> (int)($_POST['max_completes'] ?? 0),
            ':live_url'     => trim($_POST['live_url'] ?? ''),
            ':test_url'     => trim($_POST['test_url'] ?? ''),
            ':status'       => $_POST['status'] ?? 'active',
            ':project_type' => $_POST['project_type'] ?? 'direct',
            ':encrypt_uid'  => isset($_POST['encrypt_uid']) ? 1 : 0,
            ':description'  => trim($_POST['description'] ?? ''),
        ];
        if ($id > 0) {
            $sql = "UPDATE rp_projects SET sid=:sid, project_name=:project_name, client_id=:client_id, client_name=:client_name, cpi=:cpi, ir=:ir, loi=:loi, max_completes=:max_completes, live_url=:live_url, test_url=:test_url, status=:status, project_type=:project_type, encrypt_uid=:encrypt_uid, description=:description WHERE id=$id";
        } else {
            $sql = "INSERT INTO rp_projects (sid, project_name, client_id, client_name, cpi, ir, loi, max_completes, live_url, test_url, status, project_type, encrypt_uid, description) VALUES (:sid,:project_name,:client_id,:client_name,:cpi,:ir,:loi,:max_completes,:live_url,:test_url,:status,:project_type,:encrypt_uid,:description)";
        }
        $db->prepare($sql)->execute($data);
        header("Location: admin.php?page=projects&msg=Project+saved");
        exit();
    }
    // Save Client
    if ($action === 'save_client' && rp_is_manager()) {
        $id = (int)($_POST['id'] ?? 0);
        $data = [
            ':client_name' => trim($_POST['client_name']),
            ':email'       => trim($_POST['email'] ?? ''),
            ':phone'       => trim($_POST['phone'] ?? ''),
            ':company'     => trim($_POST['company'] ?? ''),
            ':status'      => $_POST['status'] ?? 'active',
        ];
        if ($id > 0) {
            $db->prepare("UPDATE rp_clients SET client_name=:client_name, email=:email, phone=:phone, company=:company, status=:status WHERE id=$id")->execute($data);
        } else {
            $db->prepare("INSERT INTO rp_clients (client_name, email, phone, company, status) VALUES (:client_name,:email,:phone,:company,:status)")->execute($data);
        }
        header("Location: admin.php?page=clients&msg=Client+saved");
        exit();
    }
    // Save Vendor
    if ($action === 'save_vendor' && rp_is_manager()) {
        $id = (int)($_POST['id'] ?? 0);
        $data = [
            ':vendor_name'   => trim($_POST['vendor_name']),
            ':email'         => trim($_POST['email'] ?? ''),
            ':phone'         => trim($_POST['phone'] ?? ''),
            ':complete_url'  => trim($_POST['complete_url'] ?? ''),
            ':terminate_url' => trim($_POST['terminate_url'] ?? ''),
            ':screenout_url' => trim($_POST['screenout_url'] ?? ''),
            ':quotafull_url' => trim($_POST['quotafull_url'] ?? ''),
            ':end_behavior'  => in_array($_POST['end_behavior'] ?? '', ['show_page','redirect']) ? $_POST['end_behavior'] : 'show_page',
            ':status'        => $_POST['status'] ?? 'active',
        ];
        if ($id > 0) {
            $db->prepare("UPDATE rp_vendors SET vendor_name=:vendor_name, email=:email, phone=:phone, complete_url=:complete_url, terminate_url=:terminate_url, screenout_url=:screenout_url, quotafull_url=:quotafull_url, end_behavior=:end_behavior, status=:status WHERE id=$id")->execute($data);
        } else {
            $db->prepare("INSERT INTO rp_vendors (vendor_name, email, phone, complete_url, terminate_url, screenout_url, quotafull_url, end_behavior, status) VALUES (:vendor_name,:email,:phone,:complete_url,:terminate_url,:screenout_url,:quotafull_url,:end_behavior,:status)")->execute($data);
        }
        header("Location: admin.php?page=vendors&msg=Vendor+saved");
        exit();
    }
}

// ── LOGOUT ───────────────────────────────────────────────────
if ($page === 'logout') {
    rp_session_start();
    session_destroy();
    header('Location: login.php');
    exit();
}

// ── FETCH DATA FOR PAGES ─────────────────────────────────────

// Dashboard stats
$stats = [];
if ($page === 'dashboard') {
    $stats['total_clicks']    = $db->query("SELECT COUNT(*) FROM rp_leads")->fetchColumn();
    $stats['total_completes'] = $db->query("SELECT COUNT(*) FROM rp_leads WHERE status='complete'")->fetchColumn();
    $stats['total_terminates']= $db->query("SELECT COUNT(*) FROM rp_leads WHERE status='terminate'")->fetchColumn();
    $stats['active_projects'] = $db->query("SELECT COUNT(*) FROM rp_projects WHERE status='active'")->fetchColumn();
    $stats['active_vendors']  = $db->query("SELECT COUNT(*) FROM rp_vendors WHERE status='active'")->fetchColumn();
    $stats['total_clients']   = $db->query("SELECT COUNT(*) FROM rp_clients WHERE status='active'")->fetchColumn();
}

// Projects list
$projects = [];
if ($page === 'projects') {
    $proj_search = trim($_GET['psearch'] ?? '');
    if ($proj_search) {
        $pst = $db->prepare("SELECT p.*, c.client_name as cname FROM rp_projects p LEFT JOIN rp_clients c ON p.client_id=c.id
            WHERE p.project_name LIKE ? OR p.sid LIKE ? OR c.client_name LIKE ? ORDER BY p.id DESC");
        $like = "%$proj_search%";
        $pst->execute([$like, $like, $like]);
        $projects = $pst->fetchAll();
    } else {
        $projects = $db->query("SELECT p.*, c.client_name as cname FROM rp_projects p LEFT JOIN rp_clients c ON p.client_id=c.id ORDER BY p.id DESC")->fetchAll();
    }
}

// Project view
$project_view = null;
if ($page === 'project_view') {
    $pid = (int)($_GET['id'] ?? 0);
    $project_view = $db->prepare("SELECT * FROM rp_projects WHERE id=?");
    $project_view->execute([$pid]);
    $project_view = $project_view->fetch();
    if ($project_view) {
        // Leads for this project (with vendor name attached)
        $project_leads = $db->prepare("SELECT l.*, v.vendor_name FROM rp_leads l LEFT JOIN rp_vendors v ON l.vendor_id=v.id WHERE l.sid=? ORDER BY l.id DESC LIMIT 100");
        $project_leads->execute([$project_view['sid']]);
        $project_leads = $project_leads->fetchAll();

        // Per-vendor breakdown for this project — which vendors have sent
        // leads here, and how each of them is performing.
        $pv_stmt = $db->prepare("SELECT
                v.id AS vendor_id, COALESCE(v.vendor_name,'— No Vendor / Direct —') AS vendor_name,
                COUNT(*) AS clicks,
                SUM(l.status='complete')  AS completes,
                SUM(l.status='terminate') AS terminates,
                SUM(l.status='quality_fail') AS quality_fails,
                SUM(l.status='overquota') AS overquotas
            FROM rp_leads l
            LEFT JOIN rp_vendors v ON l.vendor_id = v.id
            WHERE l.sid = ?
            GROUP BY v.id, v.vendor_name
            ORDER BY clicks DESC");
        $pv_stmt->execute([$project_view['sid']]);
        $project_vendor_breakdown = $pv_stmt->fetchAll();
    }
}

// Clients
$clients = [];
if ($page === 'clients') {
    $clients = $db->query("SELECT * FROM rp_clients ORDER BY id DESC")->fetchAll();
}

// Vendors
$vendors = [];
if ($page === 'vendors') {
    $vsearch = trim($_GET['vsearch'] ?? '');
    if ($vsearch) {
        $vst = $db->prepare("SELECT * FROM rp_vendors WHERE vendor_name LIKE ? OR email LIKE ? ORDER BY id DESC");
        $like = "%$vsearch%";
        $vst->execute([$like, $like]);
        $vendors = $vst->fetchAll();
    } else {
        $vendors = $db->query("SELECT * FROM rp_vendors ORDER BY id DESC")->fetchAll();
    }

    // Excel/CSV export — honors the search box above, exports ALL matching vendors
    if (($_GET['export'] ?? '') === 'csv') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="vendors_export_' . date('Y-m-d_His') . '.csv"');
        $out = fopen('php://output', 'w');
        fputs($out, "\xEF\xBB\xBF");
        fputcsv($out, ['#', 'Vendor', 'Email', 'Phone', 'Clicks', 'Completes', 'Terminates', 'Conv %', 'Status']);
        foreach ($vendors as $i => $v) {
            $vc = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=?"); $vc->execute([$v['id']]); $vclk = $vc->fetchColumn();
            $vco = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=? AND status='complete'"); $vco->execute([$v['id']]); $vcomp = $vco->fetchColumn();
            $vt = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=? AND status='terminate'"); $vt->execute([$v['id']]); $vterm = $vt->fetchColumn();
            fputcsv($out, [
                $i + 1, $v['vendor_name'], $v['email'], $v['phone'],
                $vclk, $vcomp, $vterm,
                $vclk > 0 ? round(($vcomp / $vclk) * 100, 1) : 0,
                $v['status'],
            ]);
        }
        fclose($out);
        exit;
    }
}

// Vendor × Project Matrix — one-glance grid of who's running on what.
$matrix_vendors  = [];
$matrix_projects = [];
$matrix_cells    = []; // [vendor_id][project_id] => ['clicks'=>.., 'completes'=>.., 'paused'=>bool]
if ($page === 'matrix') {
    $matrix_vendors  = $db->query("SELECT id, vendor_name, status FROM rp_vendors ORDER BY vendor_name")->fetchAll();
    $matrix_projects = $db->query("SELECT id, sid, project_name, status FROM rp_projects ORDER BY project_name")->fetchAll();

    $mc_stmt = $db->query("SELECT l.vendor_id, p.id AS project_id,
            COUNT(*) AS clicks, SUM(l.status='complete') AS completes
        FROM rp_leads l
        JOIN rp_projects p ON l.sid = p.sid
        WHERE l.vendor_id IS NOT NULL
        GROUP BY l.vendor_id, p.id");
    foreach ($mc_stmt->fetchAll() as $row) {
        $matrix_cells[$row['vendor_id']][$row['project_id']] = [
            'clicks' => (int)$row['clicks'], 'completes' => (int)$row['completes'],
        ];
    }

    // Pause status per vendor/project pair (from rp_project_vendors, when set)
    $mp_stmt = $db->query("SELECT vendor_id, project_id, status FROM rp_project_vendors");
    $matrix_pause = [];
    foreach ($mp_stmt->fetchAll() as $row) {
        $matrix_pause[$row['vendor_id']][$row['project_id']] = $row['status'];
    }
}

// Vendor Detail View
$vendor_view = null;
$vendor_leads = [];
$vendor_projects = [];
if ($page === 'vendor_view') {
    $vid = (int)($_GET['id'] ?? 0);
    $vs = $db->prepare("SELECT * FROM rp_vendors WHERE id=?");
    $vs->execute([$vid]);
    $vendor_view = $vs->fetch();
    if ($vendor_view) {
        $vl = $db->prepare("SELECT l.*, p.project_name FROM rp_leads l LEFT JOIN rp_projects p ON l.sid=p.sid WHERE l.vendor_id=? ORDER BY l.id DESC LIMIT 200");
        $vl->execute([$vid]);
        $vendor_leads = $vl->fetchAll();
        $vp = $db->prepare("SELECT pv.*, p.project_name, p.sid FROM rp_project_vendors pv JOIN rp_projects p ON pv.project_id=p.id WHERE pv.vendor_id=?");
        $vp->execute([$vid]);
        $vendor_projects = $vp->fetchAll();
    }
}

// Leads
$leads = [];
$leads_total = 0;
if ($page === 'leads') {
    $search         = trim($_GET['search'] ?? '');
    $status_filter  = $_GET['status'] ?? '';
    $project_filter = $_GET['project'] ?? '';   // sid
    $device_filter  = $_GET['device'] ?? '';
    $source_filter  = $_GET['source'] ?? '';
    $client_filter  = (int) ($_GET['client'] ?? 0);
    $vendor_filter  = (int) ($_GET['vendor'] ?? 0);
    $country_filter = $_GET['country'] ?? '';
    $date_from      = $_GET['date_from'] ?? '';
    $date_to        = $_GET['date_to'] ?? '';

    $lpage  = max(1, (int)($_GET['lpage'] ?? 1));
    $limit  = 50;
    $offset = ($lpage - 1) * $limit;

    $joins  = "LEFT JOIN rp_projects p ON l.sid = p.sid LEFT JOIN rp_clients c ON p.client_id = c.id LEFT JOIN rp_vendors v ON l.vendor_id = v.id";
    $where  = '1=1';
    $params = [];

    if ($search)         { $where .= " AND (l.original_uid LIKE ? OR l.sid LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
    if ($status_filter)  { $where .= " AND l.status = ?";  $params[] = $status_filter; }
    if ($project_filter) { $where .= " AND l.sid = ?";     $params[] = $project_filter; }
    if ($device_filter)  { $where .= " AND l.device = ?";  $params[] = $device_filter; }
    if ($source_filter)  { $where .= " AND l.source = ?";  $params[] = $source_filter; }
    if ($client_filter)  { $where .= " AND c.id = ?";      $params[] = $client_filter; }
    if ($vendor_filter)  { $where .= " AND l.vendor_id = ?"; $params[] = $vendor_filter; }
    if ($country_filter) { $where .= " AND l.country = ?"; $params[] = $country_filter; }
    if ($date_from)      { $where .= " AND DATE(l.created_at) >= ?"; $params[] = $date_from; }
    if ($date_to)        { $where .= " AND DATE(l.created_at) <= ?"; $params[] = $date_to; }

    // ── Dropdown option lists for the filter row ──────────────────
    $filter_projects  = $db->query("SELECT sid, project_name FROM rp_projects ORDER BY project_name")->fetchAll();
    $filter_clients   = $db->query("SELECT id, client_name FROM rp_clients ORDER BY client_name")->fetchAll();
    $filter_vendors   = $db->query("SELECT id, vendor_name FROM rp_vendors ORDER BY vendor_name")->fetchAll();
    $filter_countries = $db->query("SELECT DISTINCT country FROM rp_leads WHERE country IS NOT NULL AND country <> '' ORDER BY country")->fetchAll(PDO::FETCH_COLUMN);
    $filter_devices   = ['desktop', 'mobile', 'tablet'];
    $filter_sources   = ['direct', 'prescreener'];

    // ── Excel/CSV export — honors every active filter above, but ──────
    // exports ALL matching rows (not just this page).
    if (($_GET['export'] ?? '') === 'csv') {
        $exp_stmt = $db->prepare("SELECT l.*, p.project_name, c.client_name, v.vendor_name FROM rp_leads l $joins WHERE $where ORDER BY l.id DESC");
        $exp_stmt->execute($params);
        $exp_rows = $exp_stmt->fetchAll();

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="leads_export_' . date('Y-m-d_His') . '.csv"');
        $out = fopen('php://output', 'w');
        fputs($out, "\xEF\xBB\xBF"); // UTF-8 BOM so Excel opens special characters correctly
        fputcsv($out, ['#', 'UID', 'Encrypted UID', 'SID', 'Project', 'Client', 'Vendor', 'Status', 'Country', 'City', 'Device', 'Browser', 'Source', 'LOI (min)', 'IP', 'Duplicate', 'Entry Time', 'End Time', 'Created At']);
        foreach ($exp_rows as $i => $r) {
            fputcsv($out, [
                $i + 1,
                $r['original_uid'],
                $r['encrypted_uid'],
                $r['sid'],
                $r['project_name'],
                $r['client_name'],
                $r['vendor_name'] ?: '—',
                $r['status'],
                $r['country'],
                $r['city'],
                $r['device'],
                $r['browser'],
                $r['source'],
                $r['loi_seconds'] ? round($r['loi_seconds'] / 60, 1) : '',
                $r['ip'],
                !empty($r['is_duplicate']) ? 'Yes' : 'No',
                $r['entry_time'],
                $r['end_time'],
                $r['created_at'],
            ]);
        }
        fclose($out);
        exit;
    }

    $count_stmt = $db->prepare("SELECT COUNT(*) FROM rp_leads l $joins WHERE $where");
    $count_stmt->execute($params);
    $leads_total = $count_stmt->fetchColumn();
    $stmt = $db->prepare("SELECT l.*, p.project_name, c.client_name, v.vendor_name FROM rp_leads l $joins WHERE $where ORDER BY l.id DESC LIMIT $limit OFFSET $offset");
    $stmt->execute($params);
    $leads = $stmt->fetchAll();
}

// Notes
$notes_content = '';
if ($page === 'notes') {
    try {
        $n = $db->query("SELECT content FROM rp_notes WHERE id=1")->fetchColumn();
        $notes_content = $n ?: '';
    } catch (PDOException $e) {
        $notes_content = '';
    }
}

// All clients for dropdowns
$all_clients = $db->query("SELECT id, client_name FROM rp_clients WHERE status='active' ORDER BY client_name")->fetchAll();
$all_vendors = $db->query("SELECT id, vendor_name FROM rp_vendors WHERE status='active' ORDER BY vendor_name")->fetchAll();

$msg = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Matrix World Research Panel</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Mono&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#f4f6fb;
  --surface:#ffffff;
  --surface2:#f1f3f9;
  --border:rgba(15,23,42,0.08);
  --text:#0f172a;
  --text2:#475569;
  --text3:#94a3b8;
  --accent:#6366f1;
  --accent2:#8b5cf6;
  --green:#16a34a;
  --amber:#d97706;
  --blue:#2563eb;
  --red:#dc2626;
  --pink:#db2777;
  --sidebar-w:220px;
}
body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;min-height:100vh;display:flex}

/* ── SIDEBAR ── */
.sidebar{
  width:var(--sidebar-w);
  background:var(--surface);
  border-right:1px solid var(--border);
  display:flex;flex-direction:column;
  position:fixed;top:0;left:0;bottom:0;
  z-index:100;overflow-y:auto;
}
.sidebar-logo{
  padding:20px 18px 16px;
  border-bottom:1px solid var(--border);
  display:flex;align-items:center;justify-content:center;
}
.logo-icon{
  width:36px;height:36px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  border-radius:9px;
  display:flex;align-items:center;justify-content:center;
  font-size:11px;font-weight:700;color:#fff;letter-spacing:-0.3px;
  flex-shrink:0;
}
.logo-text{font-size:15px;font-weight:700;letter-spacing:1.5px;color:var(--text)}
.logo-sub{font-size:9px;letter-spacing:2px;color:var(--text3);margin-top:1px}

.sidebar-user{
  padding:14px 18px;
  border-bottom:1px solid var(--border);
  font-size:12px;
}
.sidebar-user-name{font-weight:600;color:var(--text);margin-bottom:2px}
.sidebar-user-role{
  font-size:10px;letter-spacing:1px;
  color:var(--accent);font-weight:600;
  text-transform:uppercase;
}

.sidebar-nav{flex:1;padding:10px 0}
.nav-section{
  font-size:9px;letter-spacing:2px;
  color:var(--text3);font-weight:600;
  padding:14px 18px 6px;
  text-transform:uppercase;
}
.nav-link{
  display:flex;align-items:center;gap:10px;
  padding:9px 18px;
  font-size:13px;font-weight:500;
  color:var(--text2);
  text-decoration:none;
  transition:all .15s;
  border-left:3px solid transparent;
}
.nav-link:hover{color:var(--text);background:rgba(15,23,42,0.04)}
.nav-link.active{
  color:var(--accent);
  background:rgba(99,102,241,0.08);
  border-left-color:var(--accent);
}
.nav-link .icon{font-size:15px;width:18px;text-align:center}

.sidebar-footer{
  padding:14px 18px;
  border-top:1px solid var(--border);
  font-size:11px;color:var(--text3);
}

/* ── MAIN ── */
.main{margin-left:var(--sidebar-w);flex:1;min-width:0;min-height:100vh;display:flex;flex-direction:column}

/* ── TOPBAR ── */
.topbar{
  background:var(--surface);
  border-bottom:1px solid var(--border);
  padding:14px 28px;
  display:flex;align-items:center;justify-content:space-between;
  position:sticky;top:0;z-index:50;
}
.topbar-title{font-size:16px;font-weight:600;color:var(--text)}
.topbar-right{display:flex;align-items:center;gap:12px}
.live-badge{
  display:flex;align-items:center;gap:6px;
  background:rgba(34,197,94,0.1);
  border:1px solid rgba(34,197,94,0.25);
  border-radius:20px;padding:4px 10px;
  font-size:11px;color:var(--green);font-weight:600;
}
.live-dot{width:6px;height:6px;border-radius:50%;background:var(--green);animation:pulse 2s infinite}

/* ── CONTENT ── */
.content{padding:24px 28px;flex:1;min-width:0}

/* ── FLASH MSG ── */
.flash{
  background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.2);
  border-radius:8px;padding:10px 16px;
  font-size:13px;color:var(--green);margin-bottom:20px;
}

/* ── STAT CARDS ── */
.stats-grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
  gap:16px;margin-bottom:24px;
}
.stat-card{
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:12px;
  padding:20px;
  position:relative;overflow:hidden;
  transition:border-color .2s;
}
.stat-card:hover{border-color:rgba(15,23,42,0.16)}
.stat-card::before{
  content:'';position:absolute;
  top:0;left:0;right:0;height:3px;
  background:var(--card-color,var(--accent));
}
.stat-label{font-size:11px;letter-spacing:1.5px;color:var(--text3);font-weight:600;text-transform:uppercase;margin-bottom:10px}
.stat-value{font-size:28px;font-weight:700;color:var(--text);line-height:1}
.stat-sub{font-size:11px;color:var(--text3);margin-top:6px}

/* ── SECTION HEADER ── */
.section-header{
  display:flex;align-items:center;justify-content:space-between;
  margin-bottom:18px;
}
.section-title{font-size:15px;font-weight:600;color:var(--text)}

/* ── BUTTONS ── */
.btn{
  display:inline-flex;align-items:center;gap:6px;
  padding:8px 16px;border-radius:8px;
  font-size:13px;font-weight:600;
  cursor:pointer;border:none;
  text-decoration:none;transition:opacity .15s;
  font-family:'DM Sans',sans-serif;
}
.btn:hover{opacity:0.85}
.btn-primary{background:linear-gradient(135deg,var(--accent),var(--accent2));color:#fff}
.btn-sm{padding:5px 12px;font-size:12px;border-radius:6px}
.btn-danger{background:rgba(239,68,68,0.15);color:var(--red);border:1px solid rgba(239,68,68,0.2)}
.btn-ghost{background:rgba(15,23,42,0.04);color:var(--text2);border:1px solid var(--border)}
.btn-green{background:rgba(34,197,94,0.15);color:var(--green);border:1px solid rgba(34,197,94,0.2)}
.btn-blue{background:rgba(59,130,246,0.15);color:var(--blue);border:1px solid rgba(59,130,246,0.2)}
.btn-amber{background:rgba(245,158,11,0.15);color:var(--amber);border:1px solid rgba(245,158,11,0.2)}
.btn-red{background:rgba(239,68,68,0.1);color:#ef4444;border:1px solid rgba(239,68,68,0.2)}
.btn-red:hover{background:rgba(239,68,68,0.18)}

/* ── TABLE ── */
.table-wrap{
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:12px;overflow-x:auto;
}
.table-toolbar{
  padding:14px 18px;
  border-bottom:1px solid var(--border);
  display:flex;align-items:center;gap:12px;flex-wrap:wrap;
}
table{width:100%;border-collapse:collapse}
thead th{
  padding:11px 16px;
  font-size:10px;letter-spacing:1.5px;
  color:var(--text3);font-weight:600;
  text-align:left;text-transform:uppercase;
  border-bottom:1px solid var(--border);
  background:var(--surface2);
}
tbody td{
  padding:12px 16px;
  font-size:13px;color:var(--text2);
  border-bottom:1px solid var(--border);
  vertical-align:middle;
}
tbody tr:last-child td{border-bottom:none}
tbody tr:hover td{background:rgba(15,23,42,0.025)}
.td-main{color:var(--text);font-weight:500}
.mono{font-family:'DM Mono',monospace;font-size:12px}

/* ── PILLS ── */
.pill{
  display:inline-flex;align-items:center;gap:4px;
  padding:3px 10px;border-radius:20px;
  font-size:11px;font-weight:600;letter-spacing:0.5px;
}
.pill-green{background:rgba(34,197,94,0.1);color:var(--green);border:1px solid rgba(34,197,94,0.2)}
.pill-amber{background:rgba(245,158,11,0.1);color:var(--amber);border:1px solid rgba(245,158,11,0.2)}
.pill-red{background:rgba(239,68,68,0.1);color:var(--red);border:1px solid rgba(239,68,68,0.2)}
.pill-blue{background:rgba(59,130,246,0.1);color:var(--blue);border:1px solid rgba(59,130,246,0.2)}
.pill-purple{background:rgba(99,102,241,0.1);color:var(--accent);border:1px solid rgba(99,102,241,0.2)}
.pill-gray{background:rgba(15,23,42,0.05);color:var(--text2);border:1px solid var(--border)}

/* ── MODAL ── */
.modal-overlay{
  display:none;position:fixed;inset:0;
  background:rgba(0,0,0,0.7);z-index:200;
  align-items:center;justify-content:center;
}
.modal-overlay.open{display:flex}
.modal{
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:16px;
  padding:28px;width:100%;max-width:560px;
  max-height:90vh;overflow-y:auto;
  position:relative;
}
.modal-title{font-size:16px;font-weight:600;margin-bottom:20px;color:var(--text)}
.modal-close{
  position:absolute;top:20px;right:20px;
  background:none;border:none;color:var(--text3);
  font-size:20px;cursor:pointer;line-height:1;
}
.modal-close:hover{color:var(--text)}

/* ── FORM ── */
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.form-grid.full{grid-template-columns:1fr}
.field{display:flex;flex-direction:column;gap:6px}
.field.span2{grid-column:span 2}
.field label{font-size:11px;font-weight:600;letter-spacing:1px;color:var(--text3);text-transform:uppercase}
.field input,.field select,.field textarea{
  background:var(--bg);border:1px solid var(--border);
  border-radius:8px;padding:9px 12px;
  font-size:13px;color:var(--text);
  font-family:'DM Sans',sans-serif;
  outline:none;transition:border-color .15s;
  width:100%;
}
.field input:focus,.field select:focus,.field textarea:focus{border-color:var(--accent)}
.field textarea{resize:vertical;min-height:80px}
.field select option{background:var(--surface)}

/* ── SEARCH ── */
.search-input{
  background:var(--bg);border:1px solid var(--border);
  border-radius:8px;padding:8px 12px;
  font-size:13px;color:var(--text);
  font-family:'DM Sans',sans-serif;
  outline:none;min-width:200px;
}
.search-input:focus{border-color:var(--accent)}

/* ── URL BOX ── */
.url-box{
  background:var(--bg);border:1px solid var(--border);
  border-radius:8px;padding:10px 14px;
  display:flex;align-items:center;justify-content:space-between;gap:10px;
  margin-bottom:8px;
}
.url-label{font-size:10px;letter-spacing:1px;color:var(--text3);font-weight:600;text-transform:uppercase;margin-bottom:4px}
.url-val{font-family:'DM Mono',monospace;font-size:11px;color:var(--accent);word-break:break-all;flex:1}
.copy-btn{
  background:rgba(99,102,241,0.1);border:1px solid rgba(99,102,241,0.2);
  color:var(--accent);border-radius:6px;padding:4px 10px;
  font-size:11px;font-weight:600;cursor:pointer;white-space:nowrap;
  font-family:'DM Sans',sans-serif;
}
.copy-btn:hover{background:rgba(99,102,241,0.2)}

/* ── CARDS GRID ── */
.cards-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-bottom:24px}
.info-card{
  background:var(--surface);border:1px solid var(--border);
  border-radius:12px;padding:20px;
}
.info-card-title{font-size:11px;letter-spacing:1.5px;color:var(--text3);font-weight:600;text-transform:uppercase;margin-bottom:14px}
.info-row{display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border)}
.info-row:last-child{border-bottom:none}
.info-key{font-size:12px;color:var(--text3)}
.info-val{font-size:13px;color:var(--text);font-weight:500}

/* ── PAGINATION ── */
.pagination{display:flex;gap:6px;margin-top:16px;justify-content:center}
.page-btn{
  background:var(--surface);border:1px solid var(--border);
  border-radius:6px;padding:6px 12px;font-size:13px;color:var(--text2);
  text-decoration:none;transition:all .15s;
}
.page-btn:hover,.page-btn.active{background:var(--accent);color:#fff;border-color:var(--accent)}

@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}

/* ── RESPONSIVE ── */
@media(max-width:768px){
  .sidebar{width:100%;height:auto;position:relative;flex-direction:row;flex-wrap:wrap}
  .main{margin-left:0}
  .form-grid{grid-template-columns:1fr}
  .field.span2{grid-column:span 1}
}
</style>
</head>
<body>

<!-- SIDEBAR -->
<aside class="sidebar">
  <div class="sidebar-logo">
    <img src="data:image/webp;base64,UklGRjgkAABXRUJQVlA4ICwkAACQewCdASpoAZYAPjEWiUMiISEUul3gIAMEpu3V7xo/+i7HuY/KX6n+2+k/yL1xec/EfB81t5Y/lf63/rP6x/cf2Q+d3/E/4H9V93X9e/YD8//oH/ST/W/1Lry+YL+k/3j/wf5/3Uv9n+p3vL/Xn9h/8t8gH9D/yH/o9p7/ueyl6Bv7seml+1fwp/1T/c/tN7QH/51i3y//Wfx38KP65/Y/2Z/cr2J/F/nn6r+R37z9J3pv/nehv8Y+sX2T+7/tF/dv2Y+ZP8h+I/5Fe6fx8/fvUC/E/5B/b/7R+yX9Y/afkgNf8wX2J+gf4T/A/uF/a/TN/svQz64/5/7hvsA/jv9D/w35rf5j///W3/A8Gj7p/tf2F+AH+R/1T/T/3/++/sl9MH8t/y/8b+Vntc/Lv8B/yf8t/nv20+wn+Pf0j/Yf3H/K/9//Nf///6/dD7IPRG/Y//5n3z2Y/7aEzAA2RbsXdH/ZxuOpd4lEdNn//CCFNr+hrgR6p6NLgfzbHml+kjxL0/TYaYINZ9YN8GJu7QyuGdLUicNFGHzWPK781wI9R1aWjrpMPQgx12SBbTSPEJp0/zTAZBoElRIKfcRlgJ5wKuyBwCMfvnQBR9owumKbBAenoiaxGsstQg0+Q2tC3Z2NkRR4VVdXfF1kTDAaEFV7/hARJU8votWZTmz1S7+fmLIcpFdVH6QLdWtVfZSNR2LbK4SOTFHnaajXy/PIjklbcWyPn6uvd45vwWa+eqFzh7T3q2YkuWGhJ82fefSr2MoZCbSX2jxNdjPuS+hcO292fbjnUI3mJb3zbDEVn0y5xhIDqG7bCp5W6sy810ilMTfl8R/BTZBE5P3vuA9swCXKWRBJr5Ui2Xzq4b20c9dMk/bXa3Iz8nMiywjZZtP1PAPvJeIk2jfSAhboUua0VXMZ7s9bd71w/WgZ3NQBc95vZU+OHw1ohrqNhrVft+8BgFfkQqlq2d+z1phtAcVo1MH0JLup2ECb90BRbAMGPUU2haUNhzN3b67NAa7zBVkf9i38Tzp6K9YokZa6RiNY6ozPnEKfsb9QI+h64T74v7Gs9EdX8mym3eEZeJZ7fTTUix8idpBZ+HaGJ8VWp6RRVKbIAFjEB826S4LI9MP23FAHByR5l7IUP3sUNda1JzEammrJ/wJJt1H+3T3NmQMnaeNKJo1ekvDT5leSuAbMvhRy3fCnCQDfJSsSceONlfvxcaP/kcn522d00lGuj/ylYINzCB/OfAPJ2+cAyuETpaGNvQaNT3UaxXRI/1FT8ifW34Ivt34ddkoCZvYxlOSvr3ksgztKWY2seXbcqmpSsrvzXAj1T0UgAP7+3XoxAYBMjmU8lWHODUejfcRyFLqF6yY3xPaJEb9WNJsLuIRineoX3PE7cDnXnYgHQl5ygHf/zK2YRka/9OeAxpLIMyQNSa7LEk4ChWhdlhoNUMeX5r5Ln3Nu2+7UzhEnsfeWofB9Cz2EtppHJ63NPRbkwjFtJInA8Aj6fvvYKkkkdpf/86+rJWUt4Z80UOEMcGqU9bZIgA7E5H94kd6RGSKYZWXwOcikuvGDhsjMQID3io7/XjbMAAACTPJXteq/8f++EVTUTl7iNFRjP8+xh0DxCoUsc06X1xR+qFnMDD/rNa/535sc/2B4Ycr2lf5eroC7DTMRNBM11TOWzuD7gseoyUvb0aNTe0F2uodvaSQlL9Zm2Tkzm35wxey6sxm8c+QEEjjUkXIo6/gMAeAn4liSZmWISKbZE9lWamCmtg97h1u59wnf8oCcrXf3/8zlj/93lM5xTHnc/2gkc/cc/x66Ox8jdONsnQhV/M02SHGmUnONH+oiqej0nb/X8YK0hbsj/AjsfizuiIpKCgwVssWmxc3WfyMkbq81kbOn1CJZlttEHnbuunfy/TAApxfciSd6uaZg7cSGP2qAPif/2Uh+dNkg3occk/2OKYWPtpgbTN08ssrc3K0H6ERfGcZfa+CMAvn2KqMLNPnQwbxBYFDVCP8UgdCkQ/AAACYXgsJWf/5sATVg3L2zCP69WPfGnQYFgyAABxNDy/NppR8yDiKUV1sEPALMRNIxQ/tpkTzglz2HIf2SJo7psRtnpt5GoSQDym0Dy5n5TQF4o+xA2bYlbdc7++euhkNgzEqngZOni+LtJpE8Qd50GydZEpg01AYcGdT6mAIafoM9EsS7kn3ddtr8bFjFPZ/urtGysMO3/2JTMPlkCjDlLikLtSIKjy8t99QF66T5f+UAvDD0/qhpMiNEzlVGWIBLbA7oRZ3aGI/2/vrEw16LrJav2KHc45yP+Upyu8sRfAzPIGG7dI6J7csicLSlvumZNHIl5e7mIYwguf2Qg0OHjWJ5aSafEck2vN4fsbt/MDRyAhVSYdcoLLdWPfQiSR/1+uIUih0Kj45/n7daS42jIFUp5jzg3NIKH9phV97mjbJRzdj/Kk2rGBpQaiRUMMkVNkF1IikIT4uR76Iim4pNufanXvQ5lgHreQX3Pbp6wqqvQRFowjL9gkXpR6bIZj8ITvmZtvlb0hIxgzeP9+M8xwFUgy6Siuef/j/CHbZM40QABLokYCP8jHMZPZkYETSYQsuaIoNelG2+7TaKYUV9YF66/4Soqo5mBtZFic1XoB3FPebUiveJziOkXYPdOpT7MDHVtbKeUJMsJpnf5QWDCL3wEhEdq3fUPw8JPHnMMzPXCjUFQszDqh6SRXwFIWS8cXsRuSrYCJihpz7r1JpxWWtM0e06Ti+21aCDu+TQ45qL0N7kzYGLOPPCh8dcm1DsSIeaN3NHQ0QSu2CG7pbfNqB4DE8wv9E2hgHb9CvHLEtHeLOHO4Xllrj6wstGh4cxdfVsZjuDDauW2v5Hq3X8HO01XA5E0H9KSNpiLmckJoNPjExCStCR2pfy9AJiVDgfx4AcYSYjXNxCZJFbpBtYm6FB2W8BK30VI4bne4g36u9JNceGSwcxZ5kRhs++IpeFzLl/8BdEIYgaLyQNfxOlEjI4rtc7OINDH1M6ei7Of2Os1nRjTliFrEYXPGoxs3CTAton6bgezvPm8zuFU2n7ZQQLJlLriBF8Z2YiMwHmIjYUV90J9BrdVbDP8W1OGImXSwbHmO4w5d3cf2jp/Gm0I+vcJy6MGw/I8Cu1FBI5utnT8zzv3ugEAIDFoaESLAgP4FssIXhZAGLUTbSvPNBd5dlGXEN3HV2xAh4VIt8nVC7UENV4kYR/VSch410xmvSthnXpMQNG9YoiSksEKKgDiWuGWiNIJ6SUOOMzxyENe4yqwJHWZVEinRsfRV60sguCvf6QErdWeW2AxnSNTTI9alurrQkNbybrx6/7NTq2ZgSZgUGp8iNWA77R0O1ygCOd5W5F2CrMolaYlLTkV6tmGKRT40X6iay8smsmIfOL61Pf/QrIALYchLn2GSaf37AADeu+EfbnOCE42lZcpS5UXjkzdpgPhLJcnMNhOM4cZzgVWWTc5idHg5Rqlfu+VAHuSsDa+ZJD7L9U8Dr0OO/m1tI2/ducw6+bhdOvB3NCNmMLkRZCNBWTfkVvlb1Zkw75KdGld6UAp1mSyWXfD/zjS8n1n9lJkC/ZUgcf8k1LNIhrI5J3rU/PSDMF9FpadrpLfrcHp9IhsZVkfSW5dMXnw6/N/99zFrKaJanakwnEo4tivaUnXmNAf/xKDOGGVyzNkCfBGMdAzg6YhscK1uVk7pCn4dMzWuGeIaUv4lRC8CPJKCvKzpHFYQYLDZLrOf1K1JSo1jwT+V8tjflt3Y7K07NgvBo4eL137jVXVYTijXslCXbGgcOFUEoF6jLn+f3askte79y7hf40l3ss/Kt4DEYD/HNT61pDGxnpCBtm/SHI0i1UsyUEs8eYE4TsxhS4LUkcRctd1hBTrscqjMa1ryev+dV8BgIBh8CHJfXkCo+8chPxTMG8nPZfxQS8DKJ6+XNtK4q2eJA0DgyH4fKqUxgjDLO/VrsN4WVNVUdu5Ctn9NIojYJ9RoEZ6xcq+Sc6Y84NNhTib3nrI5C8c2W/FoV1fpTYFlaU15WfjC3mzqV2NRdfFknEobKwBhgIhT49B6f8T2BgO5nJDIzTAnBV/GDAmsuf/nSwPMaWAQcKES7meIzV9Zw6f4NpivTqEv5BM0UCc0CtQ3MU3ALP633RMAlnABo8Ot/QChZ6qQaawtxAsyM7GLcbzVdIFkKxqDfHjL+H9FBvaQwxJXPPllM8I+sfL9lMx1vTwK2bvSSGBEHk8Nnz3/xjQHuQ6X78s07ivlpMGiRg/A4R2eUDxBTeuwvErJhS0Do9qZARvsp7vCc09zzgkZzIQ3T+9ZE/QDgnl0lyuc8+AEwfF8TKgbwWUnD06D0PP+tkdpWkgORx7yC2OyYKcpc65A1VEkmrr/5hh5bb/OAtpx0WeywVDKcZmVR1cuqkez7ZdPJMMjtQTSeJ7Mh0+mTcCz4LoKaSxZTXKLdQLIOdGaVmVJi1olJFhmlDItkknlWDVJT3yoYls+sACwaJokbSVeD5VpDwgRHZolkkLWlhaJligt3YaaQkrEn9+V5TiriuxbsxmQsIlz2PtsaaI/JMSkBwRVrSMMffUR6iPxUAT52IUGktzVHcVAQGACJnnpKVOOV+4AwhMOvXmImPjuTvXzxDnJZqzSI3kR5BkKgGKarUM9nspfj/BUg63V6lpRcQaa2SYYMHR2XREbQ3v2WstBAFev79BI+R39cq6vsbN/ul4PvV/tkDD5zKXN0B74EXKUtf07n8u9QW4m2VVs+7VHoXn1XnvVU3sN7GFYZEUl9HfVQXspW8VidgkZRAnZNc2dx7lI+pQ3SCv0v3XzyqwrIv0bikfoFb+NqK3Zws9mesrpKTyatUMFZYwg5AqQKIT6cnSUhtQG/x/no6M6RB6c5FD+ceN2695B3aLpvCquF50kiqIXTbeDM5UNTa403K0rWJJZjJMjYbvLDwUER0EiEEtzZo6zZti4XgvZs/YR3fQDqWuvMzF7opqzepsGgnCdFH3zoCeGUqyb7RtbKtpBb1pIVKVIu2l7aFiE72J7gAzYa/5lJEfta44lCtdDLfI5Rfrw5cn/PnGWO63gw3GE8dQpQR5VsxXY6SxOaZY2Y41ecqhN1vThqERc56hTUdzMDs5epFialuChGW7qREptkAQfQIQkaTWqO2irIe1y3HEhSxVxFXhR3Xd7esXwuY+eHJoG54GHrad/ZJQu+ibEp0U8/WSjoiJ1sysRPLq7fJmzCOHsrkLGTwBNhXzbl8KfZ+Ov48yEWcR6hOWWzAFdxNF9fSzKw7nOjR7pWENq7JRdM6G2iOoXseUcNsnFLRVQYxGUucQROowRRJb1ECL5Zc48TjF9BNM55ABobF2NMz3ETWTFh3jc12yRK6h/VgibqQMQEeDMXaClW782fv6DvgTMEsgpSc5Mtm6PoSIVpaHPA9+idLKa6Q12SytVRTNqwSrT2W+N1oMfO0nxqORs/ceYD+X8ww/rGgq7I8ELtkfUDkoHcbkRDpKqHigI1glxrIALgVir7Na0MDexxGe3kEK4TSZbQi3e4gjaPW2OLhW1zOZixLltA4msAF1uoJn0dGRyvRnBoS2HB1Q1xTuYNpYi+y8ipuJcTD9UMaFheJoQNzkgh8jiHbuy5Eub+qtTGwN/NNLxqMxvYe7ccl6AsoGCRADwmhxOx23nFc22YxWvEkebjyQxboc6NoMFyCeqYZpS6zGgZGFzIOB4slts2g/sUdLybs2pRnzkzpzYktjhWqrCMeAm03hPa59u2ZvmDKEVJpgtB1jLQYT4IG8MWMZgLeXbb7SlD2s2sIjE+/UvMn88yBrgGOIKyM9PGCna9JeKmrutvlJzMxKID/Opfmiz3LVjg//BvBFqU/w0gm+iUoGfnHXi3ahzWvn6dBRSV/qsUl/kgSgDQmpI9Pj5A6gXQMBjezHzKZlFqxn22ng3GtEkNregpOOV8D8g/z4PZVrTDf1DKJg+w/oA3U572a19C0C5+Y5snjZCUAzowW1oQLTM+jpai3nzpWT3v4xEFhNCbZV2S69FZ02nMvs3ygudK99Em8QMtmZgdmWbSF5LzfBtHUtwha/6OK5oF6dgL5m5KD/yxxZ82NDViWoBgkmNFqlOtPAJc5Z1H9G0vHLGiEYWquOfan841B7Ddgjb50Odf139+ETYoewVW89kDC86EGgxz98AOZU1Aj8P3Dci+hipidq5Wqadjud+Pqe0/61WHz3bP61RNHwarlN5cdWZioDZeldQwXgmcz4RdZi1sW6/RrCDZUYFJZxaBAMe3j+zMgDrV3iVfNi30TjvQ1v5+KazwP8KBh2Som2cJWiw6HBMAJx0vZ1vnwZhqkN9xUXCx1S/ROmQ6feUeyzNAVMYnaIAr2jMAudRI2CouZFIm6I3fInuXwdbFS38cGQ0fRLyaWzF3bcyrnswh6rDKPF6g6kGllt5iuX09nEP5/CsUTxraDtG4nNPCzS5BkP6iqq+Zx6dkgUAzUVa0t4HQbnz8QOf5B0S+VpItZsQo4NhsuYUZMA+VskQwFLqipJqoRzudOgbVlvR+DTVGQlH0KWUKUG0ILfSiWPfI+f7EWY+Kk+SpGhu4ufQ8Xkn/ZDqc52A2uVEazlYWi0B0+IgfdRAwSfJOOwmcpiGpoBIrexDphqOQdDV4p2j0BfXPuO9RQl4DCscD1Mwln1Olp9Nr7mARM7buEY27sPonMdvPzqtBv1UAPVBIPa40YrSKyuinn5p8QKyVzSqSg3+Le0rrTwmZ4roKmrpiCiy7FymvxmnslR5V7mWySGEtyg6aABZGDUIjMjL0M4uePsOLItXXRZeOk7Sp2lAKRQDdJLJkYGgvN6Q8hexzGH95i/KmHB0oJEQyxK8zTUGTa9GKCDCmqac5+8G1VXlaq9AkR5dEOVqIkLj9xHshh0/uiPr/uflbNZGeskSEMZFymFO16bUfLegEWPWxrvHB7o/bb7l+HWJxyxXB8+c0CfEzRBowJVDdDuXB6pTlLvnXCGQbxlOMPWpvH17c8bz09x5Pnc2z1d73lBCP6ANYiAq6FVpKWj1+6ocaAoYTycu1aanw7xphRG14p/zGyUKWPGonel1rjUYbYuGBugNH8fACv5CEt9xxUDuWLcEab8MXR5EpeXom/oVFzkiUUW80zzYwWJEWkLpw4Dg99pLkkKX+RrvYNCjdGnyO6JnA7yHRDv4xzJQDpHhKN0XuOyT5/3EZSzm6XSjv72GO/zM7AAbjh9uevuzpZbnYo9ADMi8y2TYhEt7zHEc+z7YQq7T37ZU6V+tetYvIqeSOLSfw9VMLS/i38RCdWxwOiO4ZTBB8/uodcldf1sVGezLjIOQTTitn7BYHPBEq/EwU7VnwzENmTwsJdDTFDympB5r9+quV0VjR4UAK2AwpGUTrfJyW+Meu8KhBKudQsdqqbYRtF1iqJOCoRyjXUVMCgmsogDvbu+vcI1l0xzs9Ne9SUGQjcgB366yOhl+iwplk7tzOeA4zzsW3ttYoYixC275clnYP0NXMhSeEVnKggOzN25F3tZFYkxeOKk+MiMLMV0/OXPYuEbzo69zg0/birRldEJTaPoWf+mG97kckbt/TWsc01Uvc5Tw53wY6YCukai0G3OPJTz+leZgPfMjJ74Er4418BfuLs+XKOnz9YUv7KmbKpcZA0RONoFBlypj3i4QNcoEBs36aeAoFe9OAuroeQflrXa66VSDltawbJXXnwJ/SLDCBL4iCmEyj/rurac8PIWSN8qjgmxLjd8gRGT3p6UwSmjR5cmjW8aKVdck2O9ivBfAYXhyRxfffVK5CW6g56IagSaZe1oDY5moBntHZUIMZyc/ZehUFOY1OOAelTs3msl3vWzso/BMbvhNPgoEjnWxJXrxTHVxML9NHvgT2p4LBjwy9Q4CJH5KbnZndH8hNSfad0Y0ThyqQ90m3PO45uc2VZrod9yxdTDVef6cvzXtFEivf5lkVzw3ns7TbXfgpPSgfOxpUgW45f9v2aEqnYrlq0jFFlMcvdqCo3j8N8rVmJafwIHbxo7gyAIQuNKxXNaf0kNJv50y1AQ6j1pC6klnMmdSFoGIm8Yisp6Y1nq8MMNdlFONqU3SDDnqh662qJBOr7/TvE06Px4AUB1eieGnCoAgmIur65TFs8AAAAAFYK+pPadtpqlRzVi4MbSE+mj1/3iGIIRqF8TEPG1AsqG7cEiko63Nkp2nbWLMuN8cL1UZGj8jVlDG7+WRfPTas2eMtlfZUr2K7xXz41G+3Zbg/e6DtzQeUNpezFaOEIfZYmNbLGxMScsn6IDm8rQQwbyhNNgdcOVg1AS/qIgikSTFoqZ4M6/JI5gwfn+FeLNS/HHHJFcR3lNAeeOl33ToUkdNCDKsMzLk3ZJwXWEoGJg5qhotCAgigPrsPJfFDjZCs6cvm4QWyg6xBAYxEJxzVQpBW8DZ8OYzP8Qv3/RMTxmYQlh5vB/XmZCLz6azWw/PEjqC8vuJiN7kLjfiPhhEME6YnXOgwQVDPrU7VG79C85hygrhrLP1nqIx2jKK+xc8ZtDebPBkrEj9ki+eYtzPaJIP4oHGQSdFN7HP3PpqEQaCW/61lFxk/QGjobqKwJniCQPc5gqrm746K+9tSOZs5GuEf7JRaThgVjhSKPOZ1tKgXuRDtxZlESi4YkzCxYWkT+Nc2ur5y9qiJ6pUHRCi8aNZtlV10he9wkCDPg3wcwbnH3wJhbyBoFlKufce+xX0VXpVhVeFiX0cJc/gnok/3CcgN/WzVZ45fQ76iXIA8qGnnapyMeE3lz/elrGLxGvSkykIEZQDaz2pXTxYhMrkxMTFAIWU+nV3JC1UPfWZABl+hiby6VNavvBmzHfK74by4sTMbSib8q1ZIG1UwTd/8pa4J+5BBQaTeioh3oe488AjjQMLxB6qpj3Wykf3bLN4ZWJQfzXudKOcKV51reTVr5eWFagTNLPEuxwyp8Zh0OgTNRzm7/j0RuSna6H/2uVXbm7Nlu36gI7+j/diWJ/iNtZrJtzO/cO/pOTscnJt5NlBXX5/4RTFjwGZDEqioAMBm3Of8a8zuY8661GmcDlyEpG3Lnn3i77OkJPdHL34tDCKq7G+Ydrb+Idmk8dj9i0oLIW/AF7fIQZizNxHnscQY3QbXD7VVbjo63jY3AnY+FiKbMoBuLsIQWH3x9Atexl6ADGhY+2zZt+nGk1JBKj6n5JPAgxst7Rh59UWOW6s8MWY806D4ofzUwwDp3vCmUepEE/mL3nqi7pEXHT5h94904OuuLzNceijrCeCkIfR051JBo0AXxppqdZ0FWRlhxc9H11ojTIqccxpuc0tYSMCHjgYtsZImNb3gX9gJF3O381tyQvMPS8yRL7InjOXzEZ7DNsCCs57OL7/VdK4HFlWvXqnEZP2CNtdCVkovjxyD6hUlJAQqxPO/gaccYSwVQipU875nGC15B18DgGaVuDgYYFpdRcr0uRk98GRns50XbzHD+JAJO1yq8V5aUm1BpEpcYqJ9Q5xeuCyV51je/C41k2Q6vUUBf9jLd6mUt+JYHBJeTXfaPBmPzyoErUmuB4IhHCsc2qJAY9/fVo1Ovl6Da1aBLdrO2LKq8SdL6NOcgU2OQZ0N0ZOQyFcQlDN5UAiAk+gNcg3O8bdJsYxgylZdC4EscQ2SfzXlz0PLL+WcypAdH5Pc2a27NsHCrjVC8Wy8A9feMl6cq5HBV6xC/XKT8AwFy1mOGGhswNFNejKMPzItn8kuyOn1HZjd4f7sTotc+BSwsG+v44ELulRF+D5m3xsH8qDaI+YS6EkqGCBEgvRo0Dobb5t+QaME6nAqdLhKMgfpDWMbM4/jVAttaOUcBY10sJCnEShlzBLsI0cJmsetv1+Ru/UGfFqnk3UuYt72eVjzX1A45uWHED0wleDd4jkTLBPAAMhYrQKWncPfTupCI1SBX8PXFZj6KZJ31SED3cDrg/7FetntfPHOZJjhYH2DbpKmj//pgajKnORTd0HyxrvFd8YmQS+cIlqmSD/Nint6AbmrKT4CenBrwiokguXyt1B5ZKY9bg6YQt+dT76jNa2+gk2NlxeyExveY1j/PM+r+12aNLSr7j8bmJY1pXmEZF+7XiUCv5X+JeHG+6PaUyNv2dPsIgg8BE5BdiWopSraskpbz6M2MZQrMDYChxySZTVYHVSEuaIKf9GqAnVRVd3dOA8DN2Ob9pSkmiBzDkGhH4DUHlch215JZlOVEcaweWNzTyMc8PkCMfhkxQ1H0VMnRdYAcPSSILbWQRiBTqKuiKWWiEcf+MfJvHuB4HXV472RAe+1hGwKWZmkaPcAFFRAmHXtk7Wd1S1UseMf3C8VfSkfzZQGhOEDDfE2dOYFOrVDHk95NlXm8p1ik5MuuJLlVFCwTaW+eD6IfQxgnpfL4g1sYti9NmSR7Ckq6qD1JJ03t0z/nUEqKMYQKGECb1gFuSwOfPHNUkDcsRrLbVQv2EQPz7rDREvQ/pyt0TUL3SHjwyo2oc4fCBeFTNEjSd4+JZ87X5UXPXtgerXszLLh9X43GSXdpsSEKbas0+pt7Pbe4BSn/FI+bVnsrHE9RXU4MXDrWPqAqIi0YI0F3h3rdOC1Dx2BKz0wtUoPSNuM7CWIadk0WL1CNtC+FfJuP9miegiwO3VxetNPaYNWkP2ckZ1JA87GmdbI3WShRkmTk1EtMtPwWEpK8d08l+fW0W4BY6dZPId+1969FbnC2tDGAWI7PrZGFWclCMrs9pxlyoavInOaXLvb/3JbUC4YkPz1f5fnOompI5K0PtgNKL/xPbjq58aeUIxuyzsasAz2kvGUxPtwpFkYOR8lmpFeMOBy3bxVOutnNGz++XhdeLHaa8Rf1sFNHPnv+Uxt3qneEUR2bYozwBcHsdMsZacLR/KvzuV6s1ZzFJOSILoPzt3kJYzpWrrh3mrUDoLCUddg8c05jyAoMXOTjwfqHsQGTeH30dLiiDcx2QYy/2jlrQpGouBCq0O9l6rGn91ZaEdY+RJDnKvVme/DX93YuiDgggx9SGxwvgnBXqJ3CpAKKYn9HqnRxjqgDEjZzLUcfudUXgKMXcYDhH170FIx1t2CH495Ajm/XU5Y5Lk2UzkP7wkXqVOW5W6i0IIWy61E3J0wAip74n01kM48lxvQmwqVTS0cTHXYuBbep1lGjvnRBOUvmSslPEXiCc8K2V9Dbvd04+sbDcu82/jxep4Ad2H3Yp2fXOzz+piDP952GgkgjrLAc3tx+tixJn15574saBbYlmxbT0oY35L/b/6DRV7mshWbeqIb0PaQK8+TY1z1Sc0DbveLbGB42IxDddIFiax147bQrNSInT1ezLjrFKsV+Yvn8YEpED1Oj1Ci0WcGiCVOrivpFp4B9RploEByIxvePZDK2U4A3yIcPH8JwGC2mddTnKu23Ol13TKi4ZX4BQMOcbDdmRr5sqkTp/s5OjExgQ0YM/aYjFFGf4sGZoF0u1SWgL5j1+EpGFJZXQOWbElHw9JJp/5adX8v7kkudUheU9XfJNLl5N7loHCoHmdzpmYNjSbO3ofM+XaMkJqcFO3j5iiaL0B9ZjDSQ3FayZ2zFojhgaEw6I3wNWwgailNzUh8FCJHX1hSXhtTZ3cEPz8krqH7AUy7lP4Yh8hY/ShX+51JL/NiWOoEbuJ8NIn315HKtb1IcAIzJojS3bFJdMEGCHRYXf/uZnReKVs8o9UzVO5sJPTFXxbiC7B4R0i8Rn94NIot54HjPcfnB4nWphGQIZjFt+5L3uyj5MDVQbGzwUIBG0O27zlR08J4uh5GaBS5O1ivwQwfO4YZxQnX9a8ZnJUfoqve/Chluuo0wg2J8rDOY7ELecnN4Gi/rscbbHhYhF8nfQHfTb6LcfKuWFgCRFrDcPdzTK4ADPdF1maLeV0keDep+l5aA35dFrskmb/WtPu8xT7t2YSOIsT5t7rbVHP9Yv7byCSeSeUBTke5zGGm86SBAH461AjXieb9QD8UHI64I2HkpbFFa4NMvKHd5PAuAvnVy3vAQlfy0hmH3F4OfHNrcuottJAyZWw/ULR3hWhxGmMBAz6F4xiDDXLIQAz7UGQUPH6gaxfDya4nWdO0F4O8oCm8/d06FDX8qBrkGl4pLJMO6IfoCZAYftWWIlWmohE+QzUjkSeSsnXm9U9053b4KVXgYPeatuZK3Z5YZnSne+Mg4Sv7YB2RznqWJraJGYGf1KUbgHWSWX7thaxZPb/kYUE8E6w21n+FmMzS/ExQEbzPnKyHu6R62UQQB9A8Nrx6LnDNFxOS//bknkwigcGDUA/KnxM2w6NYXPgVzkoixwX1Io7Nw8OMtFzkGJTh8VBHhAXVFVIxqY1RkvK9hj0UN4RPuAAAAAAAAAAAAAA==" alt="Matrix World Research" style="width:100%;max-width:170px;height:auto;display:block">
  </div>
  <div class="sidebar-user">
    <div class="sidebar-user-name"><?= htmlspecialchars($user['name']) ?></div>
    <div class="sidebar-user-role"><?= htmlspecialchars($user['role']) ?></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section">Main</div>
    <a href="?page=dashboard" class="nav-link <?= $page==='dashboard'?'active':'' ?>">
      <span class="icon">📊</span> Dashboard
    </a>
    <a href="?page=projects" class="nav-link <?= in_array($page,['projects','project_view'])?'active':'' ?>">
      <span class="icon">📁</span> Projects
    </a>
    <a href="?page=leads" class="nav-link <?= $page==='leads'?'active':'' ?>">
      <span class="icon">📋</span> Leads
    </a>
    <div class="nav-section">Management</div>
    <a href="?page=clients" class="nav-link <?= $page==='clients'?'active':'' ?>">
      <span class="icon">🏢</span> Clients
    </a>
    <a href="?page=vendors" class="nav-link <?= in_array($page,['vendors','vendor_view'])?'active':'' ?>">
      <span class="icon">🤝</span> Vendors
    </a>
    <a href="?page=matrix" class="nav-link <?= $page==='matrix'?'active':'' ?>">
      <span class="icon">🔲</span> Vendor × Project
    </a>
    <div class="nav-section">Account</div>
    <a href="?page=notes" class="nav-link <?= $page==='notes'?'active':'' ?>">
      <span class="icon">📝</span> Notes
    </a>
    <a href="?page=change_password" class="nav-link <?= $page==='change_password'?'active':'' ?>">
      <span class="icon">🔑</span> Change Password
    </a>
  </nav>
  <div class="sidebar-footer">
    <a href="?page=logout" style="color:var(--red);text-decoration:none;font-size:12px">⏻ Logout</a>
  </div>
</aside>

<!-- MAIN -->
<div class="main">

  <!-- TOPBAR -->
  <div class="topbar">
    <div class="topbar-title">
      <?php
      $titles = ['dashboard'=>'Dashboard','projects'=>'Projects','project_view'=>'Project Details','clients'=>'Clients','vendors'=>'Vendors','vendor_view'=>'Vendor Details','leads'=>'Leads','matrix'=>'Vendor × Project Matrix','notes'=>'Notes','change_password'=>'Change Password'];
      echo $titles[$page] ?? 'Dashboard';
      ?>
    </div>
    <div class="topbar-right">
      <div class="live-badge"><div class="live-dot"></div> LIVE</div>
    </div>
  </div>

  <!-- CONTENT -->
  <div class="content">

  <?php if ($page === 'dashboard'): ?>
  <script>
  setTimeout(() => window.location.reload(), 60000);
  </script>
  <div style="font-size:11px;color:var(--text3);margin-bottom:16px;text-align:right">
    🔄 Auto-refresh: 60s &nbsp;|&nbsp; Updated: <?= date('H:i:s') ?> IST
  </div>
  <?php endif; ?>

  <?php if ($msg): ?>
  <div class="flash">✓ <?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>

  <?php

  // ════════════════════════════════════════════
  // DASHBOARD
  // ════════════════════════════════════════════
  if ($page === 'dashboard'):
  ?>
  <div class="stats-grid">
    <div class="stat-card" style="--card-color:#6366f1">
      <div class="stat-label">Total Clicks</div>
      <div class="stat-value"><?= number_format($stats['total_clicks']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#22c55e">
      <div class="stat-label">Completes</div>
      <div class="stat-value"><?= number_format($stats['total_completes']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#f59e0b">
      <div class="stat-label">Terminates</div>
      <div class="stat-value"><?= number_format($stats['total_terminates']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#3b82f6">
      <div class="stat-label">Active Projects</div>
      <div class="stat-value"><?= number_format($stats['active_projects']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#ec4899">
      <div class="stat-label">Active Vendors</div>
      <div class="stat-value"><?= number_format($stats['active_vendors']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#8b5cf6">
      <div class="stat-label">Clients</div>
      <div class="stat-value"><?= number_format($stats['total_clients']) ?></div>
    </div>
  </div>

  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // PROJECTS LIST
  // ════════════════════════════════════════════
  if ($page === 'projects'):
  ?>
  <div class="section-header">
    <div class="section-title">All Projects (<?= count($projects) ?>)</div>
    <?php if (rp_is_manager()): ?>
    <button class="btn btn-primary" onclick="openModal('modalProject',{})">+ Add Project</button>
    <?php endif; ?>
  </div>

  <form method="GET" style="display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap">
    <input type="hidden" name="page" value="projects">
    <input class="search-input" type="text" name="psearch" placeholder="Search project, SID or client..." value="<?= htmlspecialchars($_GET['psearch']??'') ?>">
    <button type="submit" class="btn btn-primary btn-sm">Search</button>
    <?php if (!empty($_GET['psearch'])): ?>
    <a href="?page=projects" class="btn btn-ghost btn-sm">Clear</a>
    <?php endif; ?>
  </form>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th><th>Project</th><th>Client</th><th>CPI</th><th>IR%</th><th>LOI</th><th>Completes</th><th>Vendors</th><th>Conv%</th><th>Status</th><th>Type</th><th>Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($projects as $i => $p):
        $completes = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=? AND status='complete'");
        $completes->execute([$p['sid']]); $comp = $completes->fetchColumn();
        $clicks = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=?");
        $clicks->execute([$p['sid']]); $clk = $clicks->fetchColumn();
        $pvend = $db->prepare("SELECT COUNT(DISTINCT vendor_id) FROM rp_leads WHERE sid=? AND vendor_id IS NOT NULL");
        $pvend->execute([$p['sid']]); $pvend_count = $pvend->fetchColumn();
      ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td>
            <div class="td-main"><?= htmlspecialchars($p['project_name']) ?></div>
            <div class="mono" style="color:var(--text3)"><?= htmlspecialchars($p['sid']) ?></div>
          </td>
          <td><?= htmlspecialchars($p['client_name'] ?: '—') ?></td>
          <td>$<?= number_format($p['cpi'],2) ?></td>
          <td><?= $p['ir'] ?>%</td>
          <td><?= $p['loi'] ?>m</td>
          <td><?= $comp ?> / <?= $clk ?></td>
          <td>
            <?php if ($pvend_count > 0): ?>
            <span class="pill pill-purple"><?= $pvend_count ?> vendor<?= $pvend_count>1?'s':'' ?></span>
            <?php else: ?>
            <span style="color:var(--text3)">—</span>
            <?php endif; ?>
          </td>
          <td style="color:<?= $clk>0&&($comp/$clk)>0.5?'var(--green)':'var(--amber)' ?>;font-weight:600">
            <?= $clk > 0 ? round(($comp/$clk)*100,1).'%' : '—' ?>
          </td>
          <td>
            <?php
            $pclass = ['active'=>'pill-green','paused'=>'pill-amber','closed'=>'pill-gray'];
            echo '<span class="pill '.($pclass[$p['status']]??'pill-gray').'">'.ucfirst($p['status']).'</span>';
            ?>
          </td>
          <td><span class="pill pill-blue"><?= ucfirst($p['project_type']) ?></span></td>
          <td>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              <a href="?page=project_view&id=<?= $p['id'] ?>" class="btn btn-sm btn-ghost">View</a>
              <?php if (rp_is_manager()): ?>
              <button class="btn btn-sm btn-ghost" onclick='openModal("modalProject",<?= json_encode($p) ?>)'>Edit</button>
              <form method="POST" style="display:inline">
                <input type="hidden" name="action" value="toggle_project_status">
                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                <button type="submit" class="btn btn-sm <?= $p['status']==='active' ? 'btn-amber' : 'btn-green' ?>">
                  <?= $p['status']==='active' ? '⏸ Pause' : '▶ Resume' ?>
                </button>
              </form>
              <?php endif; ?>
              <?php if (rp_is_superadmin()): ?>
              <form method="POST" style="display:inline" onsubmit="return confirm('Delete project \'<?= htmlspecialchars(addslashes($p['project_name'])) ?>\'? This cannot be undone. Existing leads will be kept for records, but the project itself will be removed.');">
                <input type="hidden" name="action" value="delete_project">
                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                <button type="submit" class="btn btn-sm btn-red">🗑 Delete</button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($projects)): ?>
      <tr><td colspan="11" style="text-align:center;color:var(--text3);padding:32px"><?= !empty($_GET['psearch']) ? 'No projects match your search.' : 'No projects yet. Add your first project!' ?></td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // PROJECT VIEW
  // ════════════════════════════════════════════
  if ($page === 'project_view' && $project_view):
    $base = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
    $folder = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/'); // auto-detects current folder (e.g. /panelengine or empty if at domain root)
    $base = $base . $folder;
    $sid = $project_view['sid'];
    $enc = $project_view['encrypt_uid'] ? '[ENCRYPTED_UID]' : '[UID]';
  ?>
  <div style="margin-bottom:16px;display:flex;align-items:center;gap:10px">
    <a href="?page=projects" class="btn btn-ghost btn-sm">← Back to Projects</a>
    <?php if (rp_is_manager()): ?>
    <form method="POST" style="display:inline">
      <input type="hidden" name="action" value="toggle_project_status">
      <input type="hidden" name="id" value="<?= $project_view['id'] ?>">
      <button type="submit" class="btn btn-sm <?= $project_view['status']==='active' ? 'btn-amber' : 'btn-green' ?>">
        <?= $project_view['status']==='active' ? '⏸ Pause Project' : '▶ Resume Project' ?>
      </button>
    </form>
    <button class="btn btn-sm btn-ghost" onclick='openModal("modalProject",<?= json_encode($project_view) ?>)'>✏ Edit Project</button>
    <?php endif; ?>
    <?php if (rp_is_superadmin()): ?>
    <form method="POST" style="display:inline" onsubmit="return confirm('Delete project \'<?= htmlspecialchars(addslashes($project_view['project_name'])) ?>\'? This cannot be undone. Existing leads will be kept for records, but the project itself will be removed.');">
      <input type="hidden" name="action" value="delete_project">
      <input type="hidden" name="id" value="<?= $project_view['id'] ?>">
      <button type="submit" class="btn btn-sm btn-red">🗑 Delete Project</button>
    </form>
    <?php endif; ?>
  </div>

  <!-- Stat cards -->
  <?php
    $p_clicks    = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=?"); $p_clicks->execute([$sid]); $p_clk = $p_clicks->fetchColumn();
    $p_completes = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=? AND status='complete'"); $p_completes->execute([$sid]); $p_comp = $p_completes->fetchColumn();
    $p_terminates= $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=? AND status='terminate'"); $p_terminates->execute([$sid]); $p_term = $p_terminates->fetchColumn();
    $quota = (int)$project_view['max_completes'];
    $quota_pct = ($quota > 0) ? min(100, round(($p_comp/$quota)*100)) : null;
  ?>
  <div class="stats-grid" style="grid-template-columns:repeat(<?= $quota?'4':'3' ?>,1fr);margin-bottom:20px">
    <div class="stat-card" style="--card-color:#6366f1"><div class="stat-label">Clicks</div><div class="stat-value"><?= $p_clk ?></div></div>
    <div class="stat-card" style="--card-color:#22c55e"><div class="stat-label">Completes</div><div class="stat-value"><?= $p_comp ?></div></div>
    <div class="stat-card" style="--card-color:#f59e0b"><div class="stat-label">Terminates</div><div class="stat-value"><?= $p_term ?></div></div>
    <?php if ($quota > 0): ?>
    <div class="stat-card" style="--card-color:#8b5cf6">
      <div class="stat-label">Quota</div>
      <div class="stat-value"><?= $quota_pct ?>%</div>
      <div style="margin-top:8px;background:rgba(15,23,42,0.08);border-radius:4px;height:4px;overflow:hidden">
        <div style="width:<?= $quota_pct ?>%;height:100%;background:<?= $quota_pct>=100?'var(--red)':($quota_pct>=80?'var(--amber)':'var(--accent)') ?>;border-radius:4px;transition:width .3s"></div>
      </div>
      <div class="stat-sub"><?= $p_comp ?> / <?= $quota ?></div>
    </div>
    <?php endif; ?>
  </div>

  <!-- Project Info -->
  <div class="cards-grid">
    <div class="info-card">
      <div class="info-card-title">Project Info</div>
      <div class="info-row"><span class="info-key">Project Name</span><span class="info-val"><?= htmlspecialchars($project_view['project_name']) ?></span></div>
      <div class="info-row"><span class="info-key">Project ID</span><span class="info-val mono"><?= htmlspecialchars($sid) ?></span></div>
      <div class="info-row"><span class="info-key">Client</span><span class="info-val"><?= htmlspecialchars($project_view['client_name'] ?: '—') ?></span></div>
      <div class="info-row"><span class="info-key">CPI</span><span class="info-val">$<?= number_format($project_view['cpi'],2) ?></span></div>
      <div class="info-row"><span class="info-key">IR%</span><span class="info-val"><?= $project_view['ir'] ?>%</span></div>
      <div class="info-row"><span class="info-key">LOI</span><span class="info-val"><?= $project_view['loi'] ?> min</span></div>
      <div class="info-row"><span class="info-key">Max Completes (Quota)</span><span class="info-val" style="color:var(--accent);font-weight:600"><?= $project_view['max_completes'] ? number_format($project_view['max_completes']) : 'Unlimited' ?></span></div>
      <div class="info-row"><span class="info-key">Status</span><span class="info-val"><?= ucfirst($project_view['status']) ?></span></div>
      <div class="info-row"><span class="info-key">Encryption</span><span class="info-val"><?= $project_view['encrypt_uid'] ? 'ON' : 'OFF' ?></span></div>
    </div>

    <?php if (!empty($project_view['description'])): ?>
    <!-- Description / Study Parameters -->
    <div class="info-card" style="margin-top:16px">
      <div class="info-card-title">Description / Study Parameters</div>
      <div style="padding:12px 0;font-size:13px;color:var(--text2);line-height:1.7">
        <?= $project_view['description'] ?>
      </div>
    </div>
    <?php endif; ?>

    <!-- Redirect URLs -->
    <div class="info-card">
      <div class="info-card-title">End Redirect URLs (Dynamic)</div>
      <?php
      $statuses = [
        'complete'  => ['Complete',  'pill-green'],
        'terminate' => ['Terminate', 'pill-amber'],
        'overquota' => ['Overquota', 'pill-blue'],
        'quality_fail' => ['Quality Fail','pill-red'],
      ];
      foreach ($statuses as $st => [$label, $cls]):
        $url = "$base/end.php?status=$st&sid=$sid&uid=$enc";
      ?>
      <div class="url-label"><span class="pill <?= $cls ?>"><?= $label ?></span></div>
      <div class="url-box">
        <div class="url-val"><?= htmlspecialchars($url) ?></div>
        <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($url) ?>')">Copy</button>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Static URLs -->
  <div class="info-card" style="margin-bottom:20px">
    <div class="info-card-title">Static Redirect URLs</div>
    <?php foreach ($statuses as $st => [$label, $cls]):
      $surl = "$base/pages/".str_replace('_','-',$st).".html?sid=$sid&uid=$enc";
    ?>
    <div class="url-label"><span class="pill <?= $cls ?>"><?= $label ?></span></div>
    <div class="url-box">
      <div class="url-val"><?= htmlspecialchars($surl) ?></div>
      <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($surl) ?>')">Copy</button>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Vendor Entry Links -->
  <div class="info-card" style="margin-bottom:20px">
    <div class="info-card-title">Vendor Entry Link Generator</div>
    <div style="font-size:12px;color:var(--text3);margin-bottom:12px">Pick a vendor to instantly generate their entry link for this project — copy and send it to them.</div>
    <div class="field" style="max-width:320px;margin-bottom:14px">
      <label>Vendor</label>
      <select id="velVendorSelect" onchange="rpUpdateVendorEntryLinks()">
        <option value="">— Select a vendor —</option>
        <?php foreach ($all_vendors as $av): ?>
        <option value="<?= $av['id'] ?>"><?= htmlspecialchars($av['vendor_name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div id="velLinksWrap" style="display:none">
      <div class="url-label"><span class="pill pill-blue">Without Prescreener</span></div>
      <div class="url-box">
        <div class="url-val" id="velNoScreener">—</div>
        <button class="copy-btn" onclick="copyText(document.getElementById('velNoScreener').textContent)">Copy</button>
      </div>
      <div class="url-label"><span class="pill pill-green">With Prescreener</span></div>
      <div class="url-box">
        <div class="url-val" id="velWithScreener">—</div>
        <button class="copy-btn" onclick="copyText(document.getElementById('velWithScreener').textContent)">Copy</button>
      </div>
    </div>
  </div>
  <script>
  function rpUpdateVendorEntryLinks() {
    const vid = document.getElementById('velVendorSelect').value;
    const wrap = document.getElementById('velLinksWrap');
    if (!vid) { wrap.style.display = 'none'; return; }
    const base = <?= json_encode($base) ?>;
    const sid  = <?= json_encode($sid) ?>;
    document.getElementById('velNoScreener').textContent   = `${base}/vendor.php?sid=${sid}&vid=${vid}&uid=[UID]`;
    document.getElementById('velWithScreener').textContent = `${base}/start.php?sid=${sid}&vid=${vid}&uid=[UID]`;
    wrap.style.display = 'block';
  }
  </script>

  <!-- Vendor Breakdown — which vendors this project's leads have come from -->
  <div class="section-header">
    <div class="section-title" style="margin-bottom:0">Vendor Breakdown</div>
  </div>
  <div class="table-wrap" style="margin-bottom:20px">
    <table>
      <thead><tr><th>Vendor</th><th>Clicks</th><th>Completes</th><th>Terminates</th><th>Quality Fail</th><th>Overquota</th><th>Conv %</th></tr></thead>
      <tbody>
      <?php foreach ($project_vendor_breakdown as $pv): ?>
        <tr>
          <td class="td-main">
            <?php if ($pv['vendor_id']): ?>
            <a href="?page=vendor_view&id=<?= (int)$pv['vendor_id'] ?>" style="color:var(--accent);text-decoration:none"><?= htmlspecialchars($pv['vendor_name']) ?></a>
            <?php else: ?>
            <span style="color:var(--text3)"><?= htmlspecialchars($pv['vendor_name']) ?></span>
            <?php endif; ?>
          </td>
          <td><?= $pv['clicks'] ?></td>
          <td><?= $pv['completes'] ?></td>
          <td><?= $pv['terminates'] ?></td>
          <td><?= $pv['quality_fails'] ?></td>
          <td><?= $pv['overquotas'] ?></td>
          <td><?= $pv['clicks']>0 ? round(($pv['completes']/$pv['clicks'])*100,1).'%' : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($project_vendor_breakdown)): ?>
      <tr><td colspan="7" style="text-align:center;color:var(--text3);padding:24px">No leads yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Recent Leads -->
  <div class="section-header">
    <div class="section-title" style="margin-bottom:0">Recent Leads (latest 100)</div>
    <div style="display:flex;gap:8px">
      <a href="?page=leads&project=<?= urlencode($sid) ?>" class="btn btn-ghost btn-sm">🔍 Search all leads for this project</a>
      <a href="?page=leads&project=<?= urlencode($sid) ?>&export=csv" class="btn btn-green btn-sm">⬇ Export to Excel</a>
    </div>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>UID</th><th>Vendor</th><th>Status</th><th>Country</th><th>Device</th><th>LOI</th><th>IP</th><th>Date</th></tr></thead>
      <tbody>
      <?php foreach ($project_leads as $l):
        $scls = ['complete'=>'pill-green','terminate'=>'pill-amber','overquota'=>'pill-blue','quality_fail'=>'pill-red','click'=>'pill-gray','pending'=>'pill-amber'];
      ?>
        <tr>
          <td class="mono">
            <?= htmlspecialchars($l['original_uid'] ?: '—') ?>
            <?php if (!empty($l['encrypted_uid']) && $l['encrypted_uid'] !== $l['original_uid']): ?>
            <div style="font-size:10px;color:var(--text3);margin-top:2px">🔒 <?= htmlspecialchars(substr($l['encrypted_uid'],0,24)) ?>...</div>
            <?php endif; ?>
          </td>
          <td>
            <?php if (!empty($l['vendor_name'])): ?>
            <a href="?page=vendor_view&id=<?= (int)$l['vendor_id'] ?>" style="color:var(--accent);text-decoration:none"><?= htmlspecialchars($l['vendor_name']) ?></a>
            <?php else: ?>
            <span style="color:var(--text3)">—</span>
            <?php endif; ?>
          </td>
          <td><span class="pill <?= $scls[$l['status']]??'pill-gray' ?>"><?= ucfirst(str_replace('_',' ',$l['status'])) ?></span></td>
          <td><?= htmlspecialchars($l['country'] ?: '—') ?></td>
          <td><?= htmlspecialchars($l['device'] ?: '—') ?></td>
          <td><?= $l['loi_seconds'] ? round($l['loi_seconds']/60,1).'m' : '—' ?></td>
          <td class="mono"><?= htmlspecialchars($l['ip'] ?: '—') ?></td>
          <td><?= $l['created_at'] ? date('d M H:i', strtotime($l['created_at'])) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($project_leads)): ?>
      <tr><td colspan="8" style="text-align:center;color:var(--text3);padding:24px">No leads yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // CLIENTS
  // ════════════════════════════════════════════
  if ($page === 'clients'):
  ?>
  <div class="section-header">
    <div class="section-title">Clients (<?= count($clients) ?>)</div>
    <?php if (rp_is_manager()): ?>
    <button class="btn btn-primary" onclick="openModal('modalClient',{})">+ Add Client</button>
    <?php endif; ?>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Client Name</th><th>Email</th><th>Company</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($clients as $i => $c): ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td class="td-main"><?= htmlspecialchars($c['client_name']) ?></td>
          <td><?= htmlspecialchars($c['email'] ?: '—') ?></td>
          <td><?= htmlspecialchars($c['company'] ?: '—') ?></td>
          <td><span class="pill <?= $c['status']==='active'?'pill-green':'pill-gray' ?>"><?= ucfirst($c['status']) ?></span></td>
          <td>
            <div style="display:flex;gap:6px">
              <?php if (rp_is_manager()): ?>
              <button class="btn btn-sm btn-ghost" onclick='openModal("modalClient",<?= json_encode($c) ?>)'>Edit</button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($clients)): ?>
      <tr><td colspan="6" style="text-align:center;color:var(--text3);padding:32px">No clients yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // VENDORS
  // ════════════════════════════════════════════
  if ($page === 'vendors'):
  ?>
  <div class="section-header">
    <div class="section-title">Vendors (<?= count($vendors) ?>)</div>
    <?php if (rp_is_manager()): ?>
    <button class="btn btn-primary" onclick="openModal('modalVendor',{})">+ Add Vendor</button>
    <?php endif; ?>
  </div>

  <form method="GET" style="display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap">
    <input type="hidden" name="page" value="vendors">
    <input class="search-input" type="text" name="vsearch" placeholder="Search vendor name or email..." value="<?= htmlspecialchars($_GET['vsearch']??'') ?>" style="min-width:260px">
    <button type="submit" class="btn btn-primary btn-sm">Search</button>
    <a href="?page=vendors" class="btn btn-ghost btn-sm">Clear</a>
    <a href="?page=vendors&export=csv&vsearch=<?= urlencode($_GET['vsearch']??'') ?>" class="btn btn-green btn-sm">⬇ Export to Excel</a>
  </form>

  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Vendor</th><th>Email</th><th>Clicks</th><th>Completes</th><th>Terminates</th><th>Projects</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($vendors as $i => $v):
        $vc = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=?"); $vc->execute([$v['id']]); $vclk=$vc->fetchColumn();
        $vco= $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=? AND status='complete'"); $vco->execute([$v['id']]); $vcomp=$vco->fetchColumn();
        $vt = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=? AND status='terminate'"); $vt->execute([$v['id']]); $vterm=$vt->fetchColumn();
        $vp = $db->prepare("SELECT COUNT(DISTINCT sid) FROM rp_leads WHERE vendor_id=?"); $vp->execute([$v['id']]); $vproj_count=$vp->fetchColumn();
      ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td class="td-main">
            <a href="?page=vendor_view&id=<?= $v['id'] ?>" style="color:var(--accent);text-decoration:none">
              <?= htmlspecialchars($v['vendor_name']) ?>
            </a>
          </td>
          <td><?= htmlspecialchars($v['email'] ?: '—') ?></td>
          <td><?= $vclk ?></td>
          <td><?= $vcomp ?></td>
          <td><?= $vterm ?></td>
          <td>
            <?php if ($vproj_count > 0): ?>
            <span class="pill pill-purple"><?= $vproj_count ?> project<?= $vproj_count>1?'s':'' ?></span>
            <?php else: ?>
            <span style="color:var(--text3)">—</span>
            <?php endif; ?>
          </td>
          <td><span class="pill <?= $v['status']==='active'?'pill-green':'pill-gray' ?>"><?= ucfirst($v['status']) ?></span></td>
          <td>
            <div style="display:flex;gap:6px">
              <?php if (rp_is_manager()): ?>
              <button class="btn btn-sm btn-ghost" onclick='openModal("modalVendor",<?= json_encode($v) ?>)'>Edit</button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($vendors)): ?>
      <tr><td colspan="9" style="text-align:center;color:var(--text3);padding:32px">No vendors yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // VENDOR × PROJECT MATRIX
  // ════════════════════════════════════════════
  if ($page === 'matrix'):
  ?>
  <div class="section-header">
    <div class="section-title">Vendor × Project Matrix</div>
  </div>
  <div style="font-size:12px;color:var(--text3);margin-bottom:16px">
    One-glance grid — clicks / completes per vendor per project. Click a number to open that vendor's leads for that project.
    <span class="pill pill-amber" style="margin-left:6px">⏸</span> = vendor is paused on that project.
  </div>
  <div class="table-wrap" style="overflow-x:auto">
    <table>
      <thead>
        <tr>
          <th style="position:sticky;left:0;background:var(--surface2);z-index:2">Vendor</th>
          <?php foreach ($matrix_projects as $mp): ?>
          <th>
            <?= htmlspecialchars($mp['project_name']) ?>
            <div class="mono" style="text-transform:none;color:var(--text3);font-weight:400"><?= htmlspecialchars($mp['sid']) ?></div>
          </th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($matrix_vendors as $mv): ?>
        <tr>
          <td class="td-main" style="position:sticky;left:0;background:var(--surface);white-space:nowrap">
            <a href="?page=vendor_view&id=<?= $mv['id'] ?>" style="color:var(--accent);text-decoration:none"><?= htmlspecialchars($mv['vendor_name']) ?></a>
            <?php if ($mv['status'] !== 'active'): ?><span class="pill pill-gray" style="margin-left:4px;font-size:9px">inactive</span><?php endif; ?>
          </td>
          <?php foreach ($matrix_projects as $mp):
            $cell = $matrix_cells[$mv['id']][$mp['id']] ?? null;
            $pause_status = $matrix_pause[$mv['id']][$mp['id']] ?? null;
          ?>
          <td style="text-align:center">
            <?php if ($cell): ?>
            <a href="?page=leads&vendor=<?= $mv['id'] ?>&project=<?= urlencode($mp['sid']) ?>" style="color:var(--text);text-decoration:none;font-weight:600">
              <?= $cell['clicks'] ?> / <span style="color:var(--green)"><?= $cell['completes'] ?></span>
            </a>
            <?php if ($pause_status === 'paused'): ?> <span class="pill pill-amber" style="font-size:9px;padding:1px 5px">⏸</span><?php endif; ?>
            <?php else: ?>
            <span style="color:var(--text3)">—</span>
            <?php endif; ?>
          </td>
          <?php endforeach; ?>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($matrix_vendors) || empty($matrix_projects)): ?>
      <tr><td colspan="<?= count($matrix_projects)+1 ?>" style="text-align:center;color:var(--text3);padding:32px">Need at least one vendor and one project to build the matrix.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // LEADS
  // ════════════════════════════════════════════
  if ($page === 'leads'):
    $total_pages = ceil($leads_total / 50);
  ?>
  <div class="section-header">
    <div class="section-title">Leads (<?= number_format($leads_total) ?> total)</div>
  </div>

  <form method="GET" style="display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap">
    <input type="hidden" name="page" value="leads">
    <input class="search-input" type="text" name="search" placeholder="Search UID or SID..." value="<?= htmlspecialchars($_GET['search']??'') ?>">
    <select class="search-input" name="status" style="min-width:140px">
      <option value="">All Statuses</option>
      <option value="complete" <?= ($_GET['status']??'')==='complete'?'selected':'' ?>>Complete</option>
      <option value="terminate" <?= ($_GET['status']??'')==='terminate'?'selected':'' ?>>Terminate</option>
      <option value="overquota" <?= ($_GET['status']??'')==='overquota'?'selected':'' ?>>Overquota</option>
      <option value="quality_fail" <?= ($_GET['status']??'')==='quality_fail'?'selected':'' ?>>Quality Fail</option>
      <option value="click" <?= ($_GET['status']??'')==='click'?'selected':'' ?>>Click Only</option>
      <option value="pending" <?= ($_GET['status']??'')==='pending'?'selected':'' ?>>Pending</option>
      <option value="unmatched" <?= ($_GET['status']??'')==='unmatched'?'selected':'' ?>>Unmatched</option>
    </select>
    <select class="search-input" name="project" style="min-width:160px">
      <option value="">All Projects</option>
      <?php foreach ($filter_projects as $fp): ?>
      <option value="<?= htmlspecialchars($fp['sid']) ?>" <?= ($_GET['project']??'')===$fp['sid']?'selected':'' ?>><?= htmlspecialchars($fp['project_name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="search-input" name="device" style="min-width:130px">
      <option value="">All Devices</option>
      <?php foreach ($filter_devices as $fd): ?>
      <option value="<?= $fd ?>" <?= ($_GET['device']??'')===$fd?'selected':'' ?>><?= ucfirst($fd) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="search-input" name="source" style="min-width:130px">
      <option value="">All Sources</option>
      <?php foreach ($filter_sources as $fs): ?>
      <option value="<?= $fs ?>" <?= ($_GET['source']??'')===$fs?'selected':'' ?>><?= ucfirst($fs) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="search-input" name="client" style="min-width:150px">
      <option value="">All Clients</option>
      <?php foreach ($filter_clients as $fc): ?>
      <option value="<?= $fc['id'] ?>" <?= ((int)($_GET['client']??0))===(int)$fc['id']?'selected':'' ?>><?= htmlspecialchars($fc['client_name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="search-input" name="vendor" style="min-width:150px">
      <option value="">All Vendors</option>
      <?php foreach ($filter_vendors as $fv): ?>
      <option value="<?= $fv['id'] ?>" <?= ((int)($_GET['vendor']??0))===(int)$fv['id']?'selected':'' ?>><?= htmlspecialchars($fv['vendor_name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="search-input" name="country" style="min-width:140px">
      <option value="">All Countries</option>
      <?php foreach ($filter_countries as $co): ?>
      <option value="<?= htmlspecialchars($co) ?>" <?= ($_GET['country']??'')===$co?'selected':'' ?>><?= htmlspecialchars($co) ?></option>
      <?php endforeach; ?>
    </select>
    <input class="search-input" type="date" name="date_from" value="<?= htmlspecialchars($_GET['date_from']??'') ?>" title="From date" style="min-width:150px">
    <input class="search-input" type="date" name="date_to" value="<?= htmlspecialchars($_GET['date_to']??'') ?>" title="To date" style="min-width:150px">
    <button type="submit" class="btn btn-primary btn-sm">Filter</button>
    <a href="?page=leads" class="btn btn-ghost btn-sm">Clear</a>
    <?php
      $exp_qs = http_build_query([
        'page'=>'leads','export'=>'csv',
        'search'=>$_GET['search']??'', 'status'=>$_GET['status']??'',
        'project'=>$_GET['project']??'', 'device'=>$_GET['device']??'',
        'source'=>$_GET['source']??'', 'client'=>$_GET['client']??'',
        'vendor'=>$_GET['vendor']??'',
        'country'=>$_GET['country']??'', 'date_from'=>$_GET['date_from']??'', 'date_to'=>$_GET['date_to']??'',
      ]);
    ?>
    <a href="?<?= $exp_qs ?>" class="btn btn-green btn-sm">⬇ Export to Excel</a>
  </form>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th><th>UID</th><th>Project</th><th>Client</th><th>Vendor</th><th>Status</th><th>Country</th><th>Device</th><th>Source</th><th>LOI</th><th>IP</th><th>Date</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($leads as $i => $l):
        $scls = ['complete'=>'pill-green','terminate'=>'pill-amber','overquota'=>'pill-blue','quality_fail'=>'pill-red','click'=>'pill-gray','pending'=>'pill-amber','unmatched'=>'pill-gray'];
        $is_dup = !empty($l['is_duplicate']);
      ?>
        <tr style="<?= $is_dup ? 'background:rgba(239,68,68,0.05)' : '' ?>">
          <td><?= ($lpage-1)*50 + $i + 1 ?></td>
          <td class="mono">
            <?= htmlspecialchars($l['original_uid'] ?: '—') ?>
            <?php if (!empty($l['encrypted_uid']) && $l['encrypted_uid'] !== $l['original_uid']): ?>
            <div style="font-size:10px;color:var(--text3);margin-top:2px">🔒 <?= htmlspecialchars(substr($l['encrypted_uid'],0,24)) ?>...</div>
            <?php endif; ?>
            <?php if ($is_dup): ?>
            <span class="pill pill-red" style="font-size:9px;padding:1px 6px;margin-left:4px">DUP</span>
            <?php endif; ?>
          </td>
          <td>
            <div style="font-size:12px;color:var(--text)"><?= htmlspecialchars($l['project_name'] ?: '—') ?></div>
            <div class="mono" style="color:var(--text3)"><?= htmlspecialchars($l['sid']) ?></div>
          </td>
          <td><?= htmlspecialchars($l['client_name'] ?: '—') ?></td>
          <td>
            <?php if (!empty($l['vendor_name'])): ?>
            <a href="?page=vendor_view&id=<?= (int)$l['vendor_id'] ?>" style="color:var(--accent);text-decoration:none"><?= htmlspecialchars($l['vendor_name']) ?></a>
            <?php else: ?>
            <span style="color:var(--text3)">—</span>
            <?php endif; ?>
          </td>
          <td><span class="pill <?= $scls[$l['status']]??'pill-gray' ?>"><?= ucfirst(str_replace('_',' ',$l['status'])) ?></span></td>
          <td><?= htmlspecialchars($l['country'] ?: '—') ?></td>
          <td><?= htmlspecialchars($l['device'] ?: '—') ?></td>
          <td><?= htmlspecialchars($l['source'] ?: '—') ?></td>
          <td><?= $l['loi_seconds'] ? round($l['loi_seconds']/60,1).'m' : '—' ?></td>
          <td class="mono"><?= htmlspecialchars(substr($l['ip']??'—',0,15)) ?></td>
          <td><?= $l['created_at'] ? date('d M H:i', strtotime($l['created_at'])) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($leads)): ?>
      <tr><td colspan="12" style="text-align:center;color:var(--text3);padding:32px">No leads found.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php if ($total_pages > 1): ?>
  <div class="pagination">
    <?php
      $base_qs = ['search'=>$_GET['search']??'', 'status'=>$_GET['status']??'',
        'project'=>$_GET['project']??'', 'device'=>$_GET['device']??'',
        'source'=>$_GET['source']??'', 'client'=>$_GET['client']??'',
        'vendor'=>$_GET['vendor']??'',
        'country'=>$_GET['country']??'', 'date_from'=>$_GET['date_from']??'', 'date_to'=>$_GET['date_to']??''];
    ?>
    <?php for ($p=1; $p<=$total_pages; $p++): ?>
    <a href="?page=leads&lpage=<?= $p ?>&<?= http_build_query($base_qs) ?>" class="page-btn <?= $p==$lpage?'active':'' ?>"><?= $p ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // VENDOR DETAIL VIEW
  // ════════════════════════════════════════════
  if ($page === 'vendor_view' && $vendor_view):
    $v_clicks    = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=?"); $v_clicks->execute([$vendor_view['id']]); $v_clk=$v_clicks->fetchColumn();
    $v_completes = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=? AND status='complete'"); $v_completes->execute([$vendor_view['id']]); $v_comp=$v_completes->fetchColumn();
    $v_terminates= $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=? AND status='terminate'"); $v_terminates->execute([$vendor_view['id']]); $v_term=$v_terminates->fetchColumn();
  ?>
  <div style="margin-bottom:16px">
    <a href="?page=vendors" class="btn btn-ghost btn-sm">← Back to Vendors</a>
  </div>

  <!-- Stat Cards -->
  <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:20px">
    <div class="stat-card" style="--card-color:#6366f1"><div class="stat-label">Clicks</div><div class="stat-value"><?= $v_clk ?></div></div>
    <div class="stat-card" style="--card-color:#22c55e"><div class="stat-label">Completes</div><div class="stat-value"><?= $v_comp ?></div></div>
    <div class="stat-card" style="--card-color:#f59e0b"><div class="stat-label">Terminates</div><div class="stat-value"><?= $v_term ?></div></div>
  </div>

  <!-- Vendor Info -->
  <div class="info-card" style="margin-bottom:20px">
    <div class="info-card-title">Vendor Info</div>
    <div class="info-row"><span class="info-key">Name</span><span class="info-val"><?= htmlspecialchars($vendor_view['vendor_name']) ?></span></div>
    <div class="info-row"><span class="info-key">Email</span><span class="info-val"><?= htmlspecialchars($vendor_view['email'] ?: '—') ?></span></div>
    <div class="info-row"><span class="info-key">Phone</span><span class="info-val"><?= htmlspecialchars($vendor_view['phone'] ?: '—') ?></span></div>
    <div class="info-row"><span class="info-key">Status</span><span class="info-val"><span class="pill <?= $vendor_view['status']==='active'?'pill-green':'pill-gray' ?>"><?= ucfirst($vendor_view['status']) ?></span></span></div>
    <div class="info-row"><span class="info-key">Conv%</span><span class="info-val" style="color:var(--green);font-weight:600"><?= $v_clk>0 ? round(($v_comp/$v_clk)*100,1).'%' : '—' ?></span></div>
  </div>

  <!-- Assigned Projects with Entry Links -->
  <?php if (!empty($vendor_projects)): ?>
  <div class="section-title" style="margin-bottom:12px">Assigned Projects & Entry Links</div>
  <div class="table-wrap" style="margin-bottom:20px">
    <table>
      <thead><tr><th>Project</th><th>SID</th><th>CPI</th><th>Limit</th><th>Status</th><th>Entry Link</th></tr></thead>
      <tbody>
      <?php foreach ($vendor_projects as $vp):
        $el_folder = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
        $el = (isset($_SERVER['HTTPS'])?'https':'http').'://'.$_SERVER['HTTP_HOST'].$el_folder."/vendor.php?sid={$vp['sid']}&vid={$vendor_view['id']}&uid=[UID]";
      ?>
        <tr>
          <td class="td-main"><?= htmlspecialchars($vp['project_name']) ?></td>
          <td class="mono"><?= htmlspecialchars($vp['sid']) ?></td>
          <td>$<?= number_format($vp['cpi'],2) ?></td>
          <td><?= $vp['max_limit'] ?: 'Unlimited' ?></td>
          <td><span class="pill pill-<?= $vp['status']==='active'?'green':'amber' ?>"><?= ucfirst($vp['status']) ?></span></td>
          <td>
            <button class="btn btn-sm btn-blue" onclick="showEntryLink('<?= htmlspecialchars($vendor_view['vendor_name']) ?>','<?= htmlspecialchars($vp['sid']) ?>','<?= htmlspecialchars($el) ?>')">🔗 Entry Link</button>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <!-- Vendor Leads -->
  <div class="section-header">
    <div class="section-title">Leads (<?= count($vendor_leads) ?> shown, latest 200)</div>
    <div style="display:flex;gap:8px">
      <a href="?page=leads&vendor=<?= (int)$vendor_view['id'] ?>" class="btn btn-ghost btn-sm">🔍 Search all leads for this vendor</a>
      <a href="?page=leads&vendor=<?= (int)$vendor_view['id'] ?>&export=csv" class="btn btn-green btn-sm">⬇ Export to Excel</a>
    </div>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>UID</th><th>Project</th><th>Status</th><th>Country</th><th>Device</th><th>LOI</th><th>IP</th><th>Date</th></tr></thead>
      <tbody>
      <?php foreach ($vendor_leads as $l):
        $scls = ['complete'=>'pill-green','terminate'=>'pill-amber','overquota'=>'pill-blue','quality_fail'=>'pill-red','click'=>'pill-gray','pending'=>'pill-amber'];
      ?>
        <tr>
          <td class="mono"><?= htmlspecialchars($l['original_uid'] ?: '—') ?></td>
          <td>
            <div style="font-size:12px"><?= htmlspecialchars($l['project_name'] ?: '—') ?></div>
            <div class="mono" style="color:var(--text3)"><?= htmlspecialchars($l['sid']) ?></div>
          </td>
          <td><span class="pill <?= $scls[$l['status']]??'pill-gray' ?>"><?= ucfirst(str_replace('_',' ',$l['status'])) ?></span></td>
          <td><?= htmlspecialchars($l['country'] ?: '—') ?></td>
          <td><?= htmlspecialchars($l['device'] ?: '—') ?></td>
          <td><?= $l['loi_seconds'] ? round($l['loi_seconds']/60,1).'m' : '—' ?></td>
          <td class="mono"><?= htmlspecialchars(substr($l['ip']??'—',0,15)) ?></td>
          <td><?= $l['created_at'] ? date('d M H:i', strtotime($l['created_at'])) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($vendor_leads)): ?>
      <tr><td colspan="8" style="text-align:center;color:var(--text3);padding:24px">No leads yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
  <?php
  // ════════════════════════════════════════════
  // NOTES
  // ════════════════════════════════════════════
  if ($page === 'notes'):
    $nt_err = $_GET['err'] ?? '';
    $nt_msg = $_GET['msg'] ?? '';
  ?>
  <div style="max-width:720px">
    <?php if ($nt_err): ?>
    <div style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);border-radius:8px;padding:10px 16px;font-size:13px;color:#f87171;margin-bottom:16px">⚠ <?= htmlspecialchars($nt_err) ?></div>
    <?php endif; ?>
    <?php if ($nt_msg): ?>
    <div class="flash">✓ <?= htmlspecialchars($nt_msg) ?></div>
    <?php endif; ?>

    <div class="info-card">
      <div class="info-card-title">Notes</div>
      <div style="font-size:12px;color:var(--text3);margin-bottom:14px">A shared notepad for anything important you want to keep track of — reminders, credentials references, to-dos, etc. Visible to anyone logged into this admin panel.</div>
      <form method="POST">
        <input type="hidden" name="action" value="save_notes">
        <textarea name="content" rows="16" style="width:100%;background:var(--bg2);border:1px solid var(--border);border-radius:8px;padding:14px;font-size:13px;color:var(--text1);font-family:'DM Mono',monospace;line-height:1.6;resize:vertical" placeholder="Write anything here..."><?= htmlspecialchars($notes_content) ?></textarea>
        <div style="margin-top:14px">
          <button type="submit" class="btn btn-primary">Save Notes</button>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>
  <?php
  // ════════════════════════════════════════════
  // CHANGE PASSWORD
  // ════════════════════════════════════════════
  if ($page === 'change_password'):
    $cp_err = $_GET['err'] ?? '';
    $cp_msg = $_GET['msg'] ?? '';
  ?>
  <div style="max-width:480px">
    <?php if ($cp_err): ?>
    <div style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);border-radius:8px;padding:10px 16px;font-size:13px;color:#f87171;margin-bottom:16px">⚠ <?= htmlspecialchars($cp_err) ?></div>
    <?php endif; ?>
    <?php if ($cp_msg): ?>
    <div class="flash">✓ <?= htmlspecialchars($cp_msg) ?></div>
    <?php endif; ?>

    <div class="info-card">
      <div class="info-card-title">Change Your Password</div>
      <form method="POST" style="margin-top:16px">
        <input type="hidden" name="action" value="change_password">
        <div class="form-grid full">
          <div class="field">
            <label>Current Password</label>
            <input type="password" name="current_password" required placeholder="••••••••">
          </div>
          <div class="field">
            <label>New Password</label>
            <input type="password" name="new_password" required placeholder="Min 6 characters">
          </div>
          <div class="field">
            <label>Confirm New Password</label>
            <input type="password" name="confirm_password" required placeholder="Repeat new password">
          </div>
        </div>
        <div style="margin-top:16px">
          <button type="submit" class="btn btn-primary">🔑 Update Password</button>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>

  </div><!-- /content -->
</div><!-- /main -->

<!-- Entry Link Modal -->
<div class="modal-overlay" id="entryLinkModal">
  <div class="modal" style="max-width:480px">
    <button class="modal-close" onclick="closeModal('entryLinkModal')">×</button>
    <div class="modal-title">Entry Link</div>
    <div id="entryLinkVendorName" style="font-size:12px;color:var(--text3);margin-bottom:4px"></div>
    <div id="entryLinkProject" style="font-size:12px;color:var(--text3);margin-bottom:16px"></div>
    <div class="url-box">
      <div class="url-val" id="entryLinkUrl"></div>
    </div>
    <button class="btn btn-primary" style="margin-top:12px;width:100%" onclick="copyText(document.getElementById('entryLinkUrl').textContent)">Copy Link</button>
  </div>
</div>

<!-- ── MODALS ── -->

<!-- Project Modal -->
<div class="modal-overlay" id="modalProject">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('modalProject')">×</button>
    <div class="modal-title" id="modalProjectTitle">Add Project</div>
    <form method="POST">
      <input type="hidden" name="action" value="save_project">
      <input type="hidden" name="id" id="proj_id" value="">
      <div class="form-grid">
        <div class="field"><label>Project ID (SID)</label><input type="text" name="sid" id="proj_sid" placeholder="e.g. RP001" required></div>
        <div class="field"><label>Project Name</label><input type="text" name="project_name" id="proj_name" required></div>
        <div class="field"><label>Client</label>
          <select name="client_id" id="proj_client">
            <option value="">-- Select Client --</option>
            <?php foreach ($all_clients as $c): ?>
            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['client_name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field"><label>Status</label>
          <select name="status" id="proj_status">
            <option value="active">Active</option>
            <option value="paused">Paused</option>
            <option value="closed">Closed</option>
          </select>
        </div>
        <div class="field"><label>CPI ($)</label><input type="number" name="cpi" id="proj_cpi" step="0.01" value="0"></div>
        <div class="field"><label>IR (%)</label><input type="number" name="ir" id="proj_ir" step="0.1" value="0"></div>
        <div class="field"><label>LOI (minutes)</label><input type="number" name="loi" id="proj_loi" value="0"></div>
        <div class="field"><label>Max Completes</label><input type="number" name="max_completes" id="proj_max" value="0"></div>
        <div class="field"><label>Project Type</label>
          <select name="project_type" id="proj_type">
            <option value="direct">Direct</option>
            <option value="thirdparty">Third Party</option>
          </select>
        </div>
        <div class="field" style="align-items:center;justify-content:center;flex-direction:row;gap:10px;padding-top:20px">
          <input type="checkbox" name="encrypt_uid" id="proj_enc" value="1" style="width:auto">
          <label for="proj_enc" style="text-transform:none;font-size:13px;color:var(--text2)">Encrypt UID</label>
        </div>
        <div class="field span2"><label>Live Survey URL</label><input type="text" name="live_url" id="proj_live" placeholder="https://..."></div>
        <div class="field span2"><label>Test Survey URL</label><input type="text" name="test_url" id="proj_test" placeholder="https://..."></div>
        <div class="field span2"><label>Description / Study Parameters</label><textarea name="description" id="proj_desc"></textarea></div>
      </div>
      <div style="margin-top:16px;display:flex;gap:10px">
        <button type="submit" class="btn btn-primary">Save Project</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('modalProject')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Client Modal -->
<div class="modal-overlay" id="modalClient">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('modalClient')">×</button>
    <div class="modal-title" id="modalClientTitle">Add Client</div>
    <form method="POST">
      <input type="hidden" name="action" value="save_client">
      <input type="hidden" name="id" id="cl_id" value="">
      <div class="form-grid">
        <div class="field span2"><label>Client Name</label><input type="text" name="client_name" id="cl_name" required></div>
        <div class="field"><label>Email</label><input type="email" name="email" id="cl_email"></div>
        <div class="field"><label>Phone</label><input type="text" name="phone" id="cl_phone"></div>
        <div class="field span2"><label>Company</label><input type="text" name="company" id="cl_company"></div>
        <div class="field"><label>Status</label>
          <select name="status" id="cl_status">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div style="margin-top:16px;display:flex;gap:10px">
        <button type="submit" class="btn btn-primary">Save Client</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('modalClient')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Vendor Modal -->
<div class="modal-overlay" id="modalVendor">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('modalVendor')">×</button>
    <div class="modal-title">Add / Edit Vendor</div>
    <form method="POST">
      <input type="hidden" name="action" value="save_vendor">
      <input type="hidden" name="id" id="vn_id" value="">
      <div class="form-grid">
        <div class="field span2"><label>Vendor Name</label><input type="text" name="vendor_name" id="vn_name" required></div>
        <div class="field"><label>Email</label><input type="email" name="email" id="vn_email"></div>
        <div class="field"><label>Phone</label><input type="text" name="phone" id="vn_phone"></div>
        <div class="field span2"><label>Complete URL</label><input type="text" name="complete_url" id="vn_complete"></div>
        <div class="field span2"><label>Terminate URL</label><input type="text" name="terminate_url" id="vn_terminate"></div>
        <div class="field span2"><label>Screenout URL</label><input type="text" name="screenout_url" id="vn_screenout"></div>
        <div class="field span2"><label>Quotafull URL</label><input type="text" name="quotafull_url" id="vn_quotafull"></div>
        <div class="field span2"><label>End Page Behavior <span style="font-weight:400;color:var(--text3)">(what a respondent sees after complete/terminate/etc.)</span></label>
          <select name="end_behavior" id="vn_end_behavior">
            <option value="show_page">Show our confirmation page (recommended) — vendor is notified silently in the background</option>
            <option value="redirect">Redirect respondent straight to the vendor's own page (uses the URLs above)</option>
          </select>
        </div>
        <div class="field"><label>Status</label>
          <select name="status" id="vn_status">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div style="margin-top:16px;display:flex;gap:10px">
        <button type="submit" class="btn btn-primary">Save Vendor</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('modalVendor')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>
// ── Modal helpers ──
function openModal(id, data) {
  document.getElementById(id).classList.add('open');
  if (id === 'modalProject') {
    document.getElementById('modalProjectTitle').textContent = data.id ? 'Edit Project' : 'Add Project';
    document.getElementById('proj_id').value    = data.id || '';
    document.getElementById('proj_sid').value   = data.sid || '';
    document.getElementById('proj_name').value  = data.project_name || '';
    document.getElementById('proj_cpi').value   = data.cpi || '0';
    document.getElementById('proj_ir').value    = data.ir || '0';
    document.getElementById('proj_loi').value   = data.loi || '0';
    document.getElementById('proj_max').value   = data.max_completes || '0';
    document.getElementById('proj_live').value  = data.live_url || '';
    document.getElementById('proj_test').value  = data.test_url || '';
    document.getElementById('proj_desc').value  = data.description || '';
    document.getElementById('proj_enc').checked = data.encrypt_uid == 1;
    if (data.status) document.getElementById('proj_status').value = data.status;
    if (data.project_type) document.getElementById('proj_type').value = data.project_type;
    if (data.client_id) document.getElementById('proj_client').value = data.client_id;
  }
  if (id === 'modalClient') {
    document.getElementById('modalClientTitle').textContent = data.id ? 'Edit Client' : 'Add Client';
    document.getElementById('cl_id').value      = data.id || '';
    document.getElementById('cl_name').value    = data.client_name || '';
    document.getElementById('cl_email').value   = data.email || '';
    document.getElementById('cl_phone').value   = data.phone || '';
    document.getElementById('cl_company').value = data.company || '';
    if (data.status) document.getElementById('cl_status').value = data.status;
  }
  if (id === 'modalVendor') {
    document.getElementById('vn_id').value        = data.id || '';
    document.getElementById('vn_name').value      = data.vendor_name || '';
    document.getElementById('vn_email').value     = data.email || '';
    document.getElementById('vn_phone').value     = data.phone || '';
    document.getElementById('vn_complete').value  = data.complete_url || '';
    document.getElementById('vn_terminate').value = data.terminate_url || '';
    document.getElementById('vn_screenout').value = data.screenout_url || '';
    document.getElementById('vn_quotafull').value = data.quotafull_url || '';
    document.getElementById('vn_end_behavior').value = data.end_behavior || 'show_page';
    if (data.status) document.getElementById('vn_status').value = data.status;
  }
}

function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

// Modals only close via the X button, Cancel button, or successful Save — accidental backdrop clicks no longer dismiss them.

// ── Entry Link Modal ──
function showEntryLink(vendor, sid, url) {
  document.getElementById('entryLinkVendorName').textContent = vendor;
  document.getElementById('entryLinkProject').textContent = 'Project: ' + sid;
  document.getElementById('entryLinkUrl').textContent = url;
  document.getElementById('entryLinkModal').classList.add('open');
}

// ── Copy helper ──
function copyText(text) {
  navigator.clipboard.writeText(text).then(() => {
    const btn = event.target;
    const orig = btn.textContent;
    btn.textContent = 'Copied!';
    btn.style.background = 'rgba(34,197,94,0.2)';
    btn.style.color = '#22c55e';
    setTimeout(() => { btn.textContent = orig; btn.style.background=''; btn.style.color=''; }, 1500);
  });
}
</script>

</body>
</html>
