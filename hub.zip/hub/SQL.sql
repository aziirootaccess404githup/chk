-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2026 at 03:58 AM
-- Server version: 11.8.8-MariaDB-log
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u994909610_hub`
--
CREATE DATABASE IF NOT EXISTS `u994909610_hub` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `u994909610_hub`;

-- --------------------------------------------------------

--
-- Table structure for table `rp_audit_log`
--

CREATE TABLE `rp_audit_log` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `details` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rp_clients`
--

CREATE TABLE `rp_clients` (
  `id` int(11) NOT NULL,
  `client_name` varchar(200) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `company` varchar(200) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rp_invoice_status`
--

CREATE TABLE `rp_invoice_status` (
  `project_id` int(11) NOT NULL,
  `status` enum('unpaid','invoiced','paid') NOT NULL DEFAULT 'unpaid',
  `notes` varchar(255) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rp_leads`
--

CREATE TABLE `rp_leads` (
  `id` int(11) NOT NULL,
  `sid` varchar(50) DEFAULT NULL,
  `project_name` varchar(200) DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `original_uid` varchar(255) DEFAULT NULL,
  `encrypted_uid` varchar(255) DEFAULT NULL,
  `status` varchar(30) DEFAULT 'click',
  `ip` varchar(60) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `device` varchar(30) DEFAULT NULL,
  `browser` varchar(50) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `loi_seconds` int(11) DEFAULT NULL,
  `is_duplicate` tinyint(1) NOT NULL DEFAULT 0,
  `status_locked` tinyint(1) NOT NULL DEFAULT 0,
  `source` varchar(100) DEFAULT 'direct',
  `entry_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rp_notes`
--

CREATE TABLE `rp_notes` (
  `id` int(11) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `rp_notes`
--

INSERT INTO `rp_notes` (`id`, `title`, `content`, `created_at`, `updated_at`) VALUES
(4, 'Links Azii@ai.com: hub@Azii8181', 'Dynamic Links (recommended)\nComplete:      https://hub.azilyticsinsights.com/track.php?status=complete&sid=YOUR_SID&uid=[UID]&loi=[LOI]\nTerminate:     https://hub.azilyticsinsights.com/track.php?status=terminate&sid=YOUR_SID&uid=[UID]\nOverquota:     https://hub.azilyticsinsights.com/track.php?status=overquota&sid=YOUR_SID&uid=[UID]\nQuality Fail:  https://hub.azilyticsinsights.com/track.php?status=quality_fail&sid=YOUR_SID&uid=[UID]\n\nStatic Links (Alternative)\nComplete:      https://hub.azilyticsinsights.com/pages/complete.html?sid=YOUR_SID&uid=[UID]\nTerminate:     https://hub.azilyticsinsights.com/pages/terminate.html?sid=YOUR_SID&uid=[UID]\nOverquota:     https://hub.azilyticsinsights.com/pages/overquota.html?sid=YOUR_SID&uid=[UID]\nQuality Fail:  https://hub.azilyticsinsights.com/pages/quality-fail.html?sid=YOUR_SID&uid=[UID]', '2026-07-18 02:55:10', '2026-07-18 03:27:42');

-- --------------------------------------------------------

--
-- Table structure for table `rp_prescreener_answers`
--

CREATE TABLE `rp_prescreener_answers` (
  `id` int(11) NOT NULL,
  `sid` varchar(50) DEFAULT NULL,
  `original_uid` varchar(255) DEFAULT NULL,
  `encrypted_uid` varchar(255) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `age_group` varchar(20) DEFAULT NULL,
  `education` varchar(50) DEFAULT NULL,
  `income` varchar(50) DEFAULT NULL,
  `device_self` varchar(30) DEFAULT NULL,
  `open_end` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rp_projects`
--

CREATE TABLE `rp_projects` (
  `id` int(11) NOT NULL,
  `sid` varchar(50) NOT NULL,
  `project_name` varchar(200) NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `client_name` varchar(200) DEFAULT NULL,
  `cpi` decimal(10,2) DEFAULT 0.00,
  `ir` decimal(5,2) DEFAULT 0.00,
  `loi` int(11) DEFAULT 0,
  `max_completes` int(11) DEFAULT 0,
  `live_url` text DEFAULT NULL,
  `test_url` text DEFAULT NULL,
  `status` enum('active','paused','closed') NOT NULL DEFAULT 'active',
  `project_type` enum('direct','thirdparty') NOT NULL DEFAULT 'direct',
  `encrypt_uid` tinyint(1) NOT NULL DEFAULT 1,
  `tp_url` varchar(500) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `supplier_cpi` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
  `color_tag` varchar(20) DEFAULT NULL,
  `internal_notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rp_project_vendors`
--

CREATE TABLE `rp_project_vendors` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `sid` varchar(50) DEFAULT NULL,
  `cpi` decimal(10,2) DEFAULT 0.00,
  `max_limit` int(11) DEFAULT 0,
  `status` enum('active','paused') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rp_settings`
--

CREATE TABLE `rp_settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `rp_settings`
--

INSERT INTO `rp_settings` (`setting_key`, `setting_value`) VALUES
('alert_email', '@exazonresearch.com'),
('telegram_bot_token', ''),
('telegram_chat_id', '');

-- --------------------------------------------------------

--
-- Table structure for table `rp_share_links`
--

CREATE TABLE `rp_share_links` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `token` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rp_uid_mapping`
--

CREATE TABLE `rp_uid_mapping` (
  `id` int(11) NOT NULL,
  `original_uid` varchar(255) NOT NULL,
  `encrypted_uid` varchar(255) NOT NULL,
  `sid` varchar(50) DEFAULT NULL,
  `source` varchar(50) DEFAULT 'vendor',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rp_users`
--

CREATE TABLE `rp_users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('superadmin','manager','viewer') NOT NULL DEFAULT 'viewer',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `rp_users`
--

INSERT INTO `rp_users` (`id`, `name`, `email`, `password`, `role`, `status`, `created_at`) VALUES
(1, 'Azhaan', 'Azii@azilyticsinsights.com', '$2y$10$ut/97O87JZSN6WJ86kVy5OB/I8Bw/l4vDzgDpCVjLs/y5dPzzC2Bm', 'superadmin', 1, '2026-07-09 21:04:48'),
(3, 'Azii', 'Azii@ai.com', '$2y$10$Dsx38r.AFZ5JD/LQ92Ro1etgRA/nwdZnqyA1GQVBeTf22/ZV8Dgsy', 'superadmin', 1, '2026-07-18 02:51:46');

-- --------------------------------------------------------

--
-- Table structure for table `rp_vendors`
--

CREATE TABLE `rp_vendors` (
  `id` int(11) NOT NULL,
  `vendor_name` varchar(200) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `complete_url` varchar(500) DEFAULT NULL,
  `terminate_url` varchar(500) DEFAULT NULL,
  `screenout_url` varchar(500) DEFAULT NULL,
  `quotafull_url` varchar(500) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `end_behavior` enum('show_page','redirect') NOT NULL DEFAULT 'show_page'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `rp_audit_log`
--
ALTER TABLE `rp_audit_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rp_clients`
--
ALTER TABLE `rp_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rp_invoice_status`
--
ALTER TABLE `rp_invoice_status`
  ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `rp_leads`
--
ALTER TABLE `rp_leads`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_sid` (`sid`),
  ADD KEY `idx_uid` (`original_uid`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `rp_notes`
--
ALTER TABLE `rp_notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rp_prescreener_answers`
--
ALTER TABLE `rp_prescreener_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_sid_uid` (`sid`,`original_uid`);

--
-- Indexes for table `rp_projects`
--
ALTER TABLE `rp_projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sid` (`sid`),
  ADD KEY `fk_project_client` (`client_id`);

--
-- Indexes for table `rp_project_vendors`
--
ALTER TABLE `rp_project_vendors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_project_vendor` (`project_id`,`vendor_id`),
  ADD KEY `fk_pv_project` (`project_id`),
  ADD KEY `fk_pv_vendor` (`vendor_id`);

--
-- Indexes for table `rp_settings`
--
ALTER TABLE `rp_settings`
  ADD PRIMARY KEY (`setting_key`);

--
-- Indexes for table `rp_share_links`
--
ALTER TABLE `rp_share_links`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_token` (`token`),
  ADD KEY `idx_project` (`project_id`);

--
-- Indexes for table `rp_uid_mapping`
--
ALTER TABLE `rp_uid_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_enc_uid` (`encrypted_uid`),
  ADD KEY `idx_orig_uid` (`original_uid`);

--
-- Indexes for table `rp_users`
--
ALTER TABLE `rp_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `rp_vendors`
--
ALTER TABLE `rp_vendors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `rp_audit_log`
--
ALTER TABLE `rp_audit_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `rp_clients`
--
ALTER TABLE `rp_clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `rp_leads`
--
ALTER TABLE `rp_leads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `rp_notes`
--
ALTER TABLE `rp_notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `rp_prescreener_answers`
--
ALTER TABLE `rp_prescreener_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `rp_projects`
--
ALTER TABLE `rp_projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `rp_project_vendors`
--
ALTER TABLE `rp_project_vendors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `rp_share_links`
--
ALTER TABLE `rp_share_links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `rp_uid_mapping`
--
ALTER TABLE `rp_uid_mapping`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `rp_users`
--
ALTER TABLE `rp_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `rp_vendors`
--
ALTER TABLE `rp_vendors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rp_projects`
--
ALTER TABLE `rp_projects`
  ADD CONSTRAINT `fk_project_client` FOREIGN KEY (`client_id`) REFERENCES `rp_clients` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `rp_project_vendors`
--
ALTER TABLE `rp_project_vendors`
  ADD CONSTRAINT `fk_pv_project` FOREIGN KEY (`project_id`) REFERENCES `rp_projects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_pv_vendor` FOREIGN KEY (`vendor_id`) REFERENCES `rp_vendors` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
