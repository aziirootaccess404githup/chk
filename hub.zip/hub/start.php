<?php
// ============================================================
// PanelEngine Survey Panel — start.php
// Entry point for pre-screener flow
// URL: /panelengine/start.php?sid=RP001&uid=[UID]
// ============================================================
require_once __DIR__ . '/config.php';

date_default_timezone_set('Asia/Kolkata');

$sid = trim($_GET['sid'] ?? '');
$uid = trim($_GET['uid'] ?? '');
$vid = trim($_GET['vid'] ?? '');

if (empty($sid) || empty($uid)) {
    die('<h3 style="font-family:sans-serif;text-align:center;margin-top:40px;color:#ef4444">Invalid link. Missing SID or UID.</h3>');
}

$db  = rp_db();
$ip  = rp_get_ip();
$ua  = $_SERVER['HTTP_USER_AGENT'] ?? '';

// ── Fetch project ─────────────────────────────────────────────
$proj = $db->prepare("SELECT * FROM rp_projects WHERE sid=? AND status='active' LIMIT 1");
$proj->execute([$sid]);
$project = $proj->fetch();

if (!$project) {
    die('
    <!DOCTYPE html><html><head><meta charset="UTF-8"><title>Not Available</title>
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0d0f14;color:#e2e8f0;margin:0}
    .box{text-align:center;padding:40px;background:#111318;border-radius:12px;border:1px solid rgba(255,255,255,0.07)}
    h2{color:#f59e0b}p{color:#94a3b8;margin-top:8px}</style>
    </head><body><div class="box"><h2>⚠ Survey Not Available</h2><p>This survey is currently not active.</p></div></body></html>
    ');
}

// ── Check vendor assignment status ────────────────────────────
// Closes a gap: prescreener can be hit as a direct entry link too, not
// only through vendor.php, so the pause check must be repeated here or
// a paused vendor's traffic still gets through via this route. Same
// pattern as vendor.php - checked before the session is even started.
if ($vid) {
    $vg = $db->prepare("SELECT status FROM rp_vendors WHERE id=? LIMIT 1");
    $vg->execute([$vid]);
    $vendor_global_status = $vg->fetchColumn();
    if ($vendor_global_status === 'inactive') {
        die('
        <!DOCTYPE html><html><head><meta charset="UTF-8">
        <title>Survey Not Available</title>
        <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0d0f14;color:#e2e8f0;margin:0}
        .box{text-align:center;padding:40px;background:#111318;border-radius:12px;border:1px solid rgba(255,255,255,0.07)}
        h2{color:#f59e0b;margin-bottom:10px}p{color:#94a3b8}</style>
        </head><body><div class="box"><h2>⏸ Survey Paused</h2><p>This survey link is currently paused. Please contact your panel manager.</p></div></body></html>
        ');
    }

    $va = $db->prepare("SELECT status FROM rp_project_vendors WHERE project_id=? AND vendor_id=? LIMIT 1");
    $va->execute([$project['id'], $vid]);
    $va_row = $va->fetch();
    if ($va_row && $va_row['status'] === 'paused') {
        die('
        <!DOCTYPE html><html><head><meta charset="UTF-8">
        <title>Survey Not Available</title>
        <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0d0f14;color:#e2e8f0;margin:0}
        .box{text-align:center;padding:40px;background:#111318;border-radius:12px;border:1px solid rgba(255,255,255,0.07)}
        h2{color:#f59e0b;margin-bottom:10px}p{color:#94a3b8}</style>
        </head><body><div class="box"><h2>⏸ Survey Paused</h2><p>This survey link is currently paused for this vendor. Please contact your panel manager.</p></div></body></html>
        ');
    }
}

// ── Start session + store data ────────────────────────────────
rp_session_start();
$_SESSION['rp_sid']     = $sid;
$_SESSION['rp_uid']     = $uid;
$_SESSION['rp_vid']     = $vid;
$_SESSION['rp_ip']      = $ip;
$_SESSION['rp_ua']      = $ua;
$_SESSION['rp_start']   = time();
$_SESSION['rp_project'] = $project;

// ── Redirect to prescreener ───────────────────────────────────
header('Location: prescreener.php');
exit();
