<?php
// ============================================================
// PanelEngine Survey Panel — client_redirect.php
// CLIENT-LEVEL status landing page: complete / terminate / overquota / quality_fail
// URL: /panelengine/client_redirect.php?client=CLT7f3a2b&type=complete&uid=[UID]
//
// Unlike end.php (which needs a project sid in the URL), this endpoint only
// needs a CLIENT code + the respondent uid. It looks across every project
// belonging to that client to find the matching lead, so the SAME 4 URLs
// keep working correctly no matter how many new projects get created for
// that client in the future — they never need to be regenerated or edited.
//
// Internally, once the lead is found, this uses the exact same status-lock,
// quota-check, and vendor-postback logic as end.php (nothing new invented).
// ============================================================
require_once __DIR__ . '/config.php';

date_default_timezone_set('Asia/Kolkata');

$db = rp_db();
rp_ensure_client_extra_columns($db);

// ── Flexible param-name fallback for status ─────────────────────
$status = trim($_GET['type'] ?? $_GET['status'] ?? $_GET['disposition'] ?? $_GET['outcome'] ?? $_GET['result'] ?? '');

// ── Flexible param-name fallback for the respondent identifier ──
$incoming_uid = trim($_GET['uid'] ?? $_GET['rid'] ?? $_GET['toid'] ?? $_GET['identifier'] ?? $_GET['tid'] ?? $_GET['pid'] ?? '');

$client_code = trim($_GET['client'] ?? '');

// ── Status recognition (same synonyms as end.php) ────────────────
$status_aliases = [
    'complete'      => 'complete',      'success'   => 'complete',   'completed' => 'complete',
    'terminate'     => 'terminate',     'terminated'=> 'terminate',  'term'      => 'terminate',
    'overquota'     => 'overquota',     'quotafull' => 'overquota',  'quota_full'=> 'overquota', 'full' => 'overquota',
    'quality_fail'  => 'quality_fail',  'qc'        => 'quality_fail','quality'  => 'quality_fail',
    'screenout'     => 'quality_fail',  'screened_out' => 'quality_fail', 'disqualified' => 'quality_fail',
];
$status_key = strtolower($status);
$status = $status_aliases[$status_key] ?? null;
$is_unmatched_status = ($status === null);
if ($is_unmatched_status) $status = 'unmatched';

$original_uid = '';
$project_name = '';
$sid = '';
$proj = null;
$lead = null;

// ── Find the client ───────────────────────────────────────────
$client = null;
if ($client_code) {
    $cs = $db->prepare("SELECT * FROM rp_clients WHERE client_uid = ? LIMIT 1");
    $cs->execute([$client_code]);
    $client = $cs->fetch();
}

if (!$client || !$incoming_uid) {
    die('
    <!DOCTYPE html><html><head><meta charset="UTF-8"><title>Not Available</title>
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0d0f14;color:#e2e8f0;margin:0}
    .box{text-align:center;padding:40px;background:#111318;border-radius:12px;border:1px solid rgba(255,255,255,0.07)}
    h2{color:#f59e0b}p{color:#94a3b8;margin-top:8px}</style>
    </head><body><div class="box"><h2>⚠ Link Not Valid</h2><p>This link is missing required information. Please contact your panel provider.</p></div></body></html>
    ');
}

// ── Find the lead: search across ALL of this client's projects ──
// Matches on either the raw/original uid OR the encrypted_uid, whichever
// this respondent's project actually sent onward — no decryption needed,
// this is a direct match against whatever value we already stored.
$deferred_vendor_id = null;
$deferred_actual_seconds = null;

$lc = $db->prepare("
    SELECT l.id, l.sid, l.status, l.status_locked, l.vendor_id, l.original_uid, l.encrypted_uid
    FROM rp_leads l
    JOIN rp_projects p ON p.sid = l.sid
    WHERE p.client_id = ? AND (l.original_uid = ? OR l.encrypted_uid = ?)
    ORDER BY l.id DESC LIMIT 1
");
$lc->execute([$client['id'], $incoming_uid, $incoming_uid]);
$lead = $lc->fetch();

if ($lead) {
    $sid = $lead['sid'];
    $original_uid = $lead['original_uid'];
    $ps = $db->prepare("SELECT * FROM rp_projects WHERE sid = ? LIMIT 1");
    $ps->execute([$sid]);
    $proj = $ps->fetch();
    $project_name = $proj ? $proj['project_name'] : '';

    $is_fresh_update = empty($lead['status_locked']);
    if (!$is_fresh_update) {
        // Status already locked — use locked status
        $status = $lead['status'];
    } elseif ($is_unmatched_status) {
        // Unmatched status on a fresh (not-yet-locked) lead: leave it
        // completely untouched, same behavior as end.php.
    } else {
        $db->prepare("UPDATE rp_leads SET status = ?, end_time = NOW(), loi_seconds = TIMESTAMPDIFF(SECOND, entry_time, NOW()), status_locked = 1 WHERE id = ?")
           ->execute([$status, $lead['id']]);
        if ($status === 'complete') {
            rp_check_quota($db, $sid);
        }
    }

    $lead_loi_seconds = null;
    if ($status === 'complete') {
        $lr = $db->prepare("SELECT loi_seconds FROM rp_leads WHERE id=?");
        $lr->execute([$lead['id']]);
        $lead_loi_seconds = $lr->fetchColumn();
    }

    if (!$is_unmatched_status) {
        $vendor_redirect_url = rp_build_vendor_redirect_url($db, $lead['vendor_id'], $status, $original_uid, $sid, $lead_loi_seconds);
        if ($vendor_redirect_url) {
            header("Location: $vendor_redirect_url");
            exit();
        }
        if ($is_fresh_update) {
            $deferred_vendor_id = $lead['vendor_id'];
            if ($status === 'complete') {
                $deferred_actual_seconds = $lead_loi_seconds;
            }
        }
    }
} else {
    // No matching lead found for this client+uid at all — genuinely unknown,
    // shown as the same neutral "under review" page (never guessed as complete).
    $is_unmatched_status = true;
    $status = 'unmatched';
    $original_uid = $incoming_uid;
}

$ip   = rp_get_ip();
$time = date('d/m/Y, H:i:s');

// ── Status config (identical to end.php) ──────────────────────
$config = [
    'complete' => [
        'badge' => 'SURVEY COMPLETED SUCCESSFULLY', 'badge_c' => '#22c55e', 'badge_bg' => 'rgba(34,197,94,0.12)',
        'icon' => '✓', 'title' => 'THANK YOU FOR YOUR<br>PARTICIPATION', 'title_c' => '#4ade80',
        'msg' => 'Your response has been recorded and verified. This record confirms your successful survey completion.',
        'label' => 'COMPLETE', 'label_c' => '#22c55e', 'label_bg' => 'rgba(34,197,94,0.12)', 'dot_c' => '#22c55e',
    ],
    'terminate' => [
        'badge' => 'SURVEY TERMINATED', 'badge_c' => '#f59e0b', 'badge_bg' => 'rgba(245,158,11,0.12)',
        'icon' => '⚠', 'title' => 'THANK YOU FOR<br>YOUR TIME', 'title_c' => '#fbbf24',
        'msg' => 'Unfortunately, you did not qualify for this survey. Your participation is appreciated.',
        'label' => 'TERMINATE', 'label_c' => '#f59e0b', 'label_bg' => 'rgba(245,158,11,0.12)', 'dot_c' => '#f59e0b',
    ],
    'overquota' => [
        'badge' => 'SURVEY QUOTA FULL', 'badge_c' => '#3b82f6', 'badge_bg' => 'rgba(59,130,246,0.12)',
        'icon' => '●', 'title' => 'THIS SURVEY IS<br>NOW FULL', 'title_c' => '#60a5fa',
        'msg' => 'We have reached our required number of responses. Thank you for your interest.',
        'label' => 'OVERQUOTA', 'label_c' => '#3b82f6', 'label_bg' => 'rgba(59,130,246,0.12)', 'dot_c' => '#3b82f6',
    ],
    'quality_fail' => [
        'badge' => 'QUALITY CHECK FAILED', 'badge_c' => '#ef4444', 'badge_bg' => 'rgba(239,68,68,0.12)',
        'icon' => '✕', 'title' => 'ACCESS DENIED', 'title_c' => '#f87171',
        'msg' => 'Your session did not pass our quality verification checks. Please ensure honest responses.',
        'label' => 'QUALITY FAIL', 'label_c' => '#ef4444', 'label_bg' => 'rgba(239,68,68,0.12)', 'dot_c' => '#ef4444',
    ],
    'unmatched' => [
        'badge' => 'RESPONSE RECEIVED', 'badge_c' => '#94a3b8', 'badge_bg' => 'rgba(148,163,184,0.12)',
        'icon' => '⏳', 'title' => 'THANK YOU', 'title_c' => '#cbd5e1',
        'msg' => 'Your response has been received and is currently under review. If you believe there was an issue, please contact the panel provider.',
        'label' => 'UNDER REVIEW', 'label_c' => '#94a3b8', 'label_bg' => 'rgba(148,163,184,0.12)', 'dot_c' => '#94a3b8',
    ],
];
$c = $config[$status] ?? $config['complete'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="referrer" content="no-referrer">
<title><?= htmlspecialchars($c['badge']) ?> — <?= htmlspecialchars(BRAND_NAME) ?></title>
<link rel="icon" type="image/webp" href="logo.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500,600;1,400&family=Outfit:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--cream:#f5f0e8;--cream2:#ede7d9;--ink:#1a1a1a;--ink2:#2c2c2c;--ink3:#555;--ink4:#888;--gold:#c9a84c;--gold2:#b8963e;--border:#d4c9b0}
body{min-height:100vh;background:var(--cream);font-family:'Outfit',sans-serif;color:var(--ink);display:flex;flex-direction:column}
nav{background:var(--ink);padding:14px 40px;display:flex;align-items:center;justify-content:space-between}
.nav-logo{display:flex;align-items:center;gap:14px;text-decoration:none}
.nav-logo img{height:38px;width:auto}
.nav-logo-text{font-family:'Cormorant Garamond',serif;font-size:20px;font-weight:600;color:var(--cream);letter-spacing:2px}
.nav-logo-sub{font-family:'Outfit',sans-serif;font-size:9px;letter-spacing:3px;color:var(--gold);margin-top:1px;text-transform:uppercase}
.nav-links{display:flex;gap:28px}
.nav-links a{color:rgba(245,240,232,0.65);text-decoration:none;font-size:12px;letter-spacing:1.5px;text-transform:uppercase;transition:.2s}
.nav-links a:hover{color:var(--gold)}
.nav-live{display:flex;align-items:center;gap:7px;font-size:10px;letter-spacing:2px;color:var(--gold);text-transform:uppercase}
.nav-dot{width:7px;height:7px;border-radius:50%;background:var(--gold);animation:pulse 2s infinite}
main{flex:1;display:flex;align-items:center;justify-content:center;padding:48px 20px}
.card{background:#fff;border:1px solid var(--border);border-radius:4px;padding:52px 44px;max-width:700px;width:100%;text-align:center;box-shadow:0 2px 24px rgba(26,26,26,0.06)}
.status-badge{display:inline-flex;align-items:center;gap:9px;border:1px solid;border-radius:2px;padding:7px 20px;font-size:10px;font-weight:600;letter-spacing:3px;margin-bottom:30px;text-transform:uppercase;border-color:<?= $c['badge_c'] ?>;color:<?= $c['badge_c'] ?>;background:<?= $c['badge_bg'] ?>}
.main-title{font-family:'Cormorant Garamond',serif;font-size:clamp(28px,5vw,44px);font-weight:500;letter-spacing:1px;line-height:1.25;color:var(--ink);margin-bottom:14px}
.main-msg{color:var(--ink4);font-size:14px;line-height:1.8;max-width:500px;margin:0 auto 36px;font-weight:300}
.divider{width:60px;height:1px;background:var(--gold);margin:0 auto 36px;opacity:.5}
.record{background:var(--cream);border:1px solid var(--border);border-radius:3px;overflow:hidden;text-align:left;margin-bottom:28px}
.record-head{display:flex;align-items:center;justify-content:space-between;padding:10px 20px;border-bottom:1px solid var(--border);background:var(--cream2)}
.record-title{display:flex;align-items:center;gap:8px;font-size:9px;font-weight:600;letter-spacing:3px;text-transform:uppercase;color:var(--gold2)}
.record-dot{width:6px;height:6px;border-radius:50%;background:var(--gold);animation:pulse 2s infinite}
.record-time{font-size:11px;color:var(--ink4);font-family:'Outfit',sans-serif}
.record-table{width:100%;border-collapse:collapse}
.record-table th{padding:10px 20px;font-size:9px;letter-spacing:2px;color:var(--ink4);font-weight:600;text-align:left;text-transform:uppercase;border-bottom:1px solid var(--border);background:rgba(197,175,130,0.08)}
.record-table td{padding:15px 20px;font-size:13px;border-bottom:1px solid rgba(212,201,176,0.4);color:var(--ink2)}
.record-table tr:last-child td{border-bottom:none}
.uid-val{font-family:'Outfit',monospace;font-size:12px;color:var(--ink);font-weight:500}
.status-pill{display:inline-flex;align-items:center;gap:5px;border:1px solid;border-radius:2px;padding:3px 12px;font-size:10px;font-weight:600;letter-spacing:2px;text-transform:uppercase;border-color:<?= $c['label_c'] ?>;color:<?= $c['label_c'] ?>;background:<?= $c['label_bg'] ?>}
.ip-val{font-family:'Outfit',monospace;font-size:11px;color:var(--ink4)}
.sid-val{font-size:12px;color:var(--gold2);font-weight:500;letter-spacing:1px}
.footnote{font-size:11px;color:var(--ink4);line-height:1.7;font-weight:300;letter-spacing:.3px}
footer{background:var(--ink);border-top:1px solid rgba(255,255,255,0.06);padding:28px 40px}
.footer-inner{max-width:1200px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px}
.footer-logo{display:flex;align-items:center;gap:10px}
.footer-logo img{height:26px;width:auto;opacity:.7}
.footer-logo-text{font-family:'Cormorant Garamond',serif;font-size:13px;letter-spacing:2px;color:rgba(245,240,232,0.45)}
.footer-tagline{font-size:9px;letter-spacing:2px;color:rgba(201,168,76,0.5);text-transform:uppercase;margin-top:2px}
.footer-links{display:flex;gap:20px}
.footer-links a{color:rgba(245,240,232,0.35);text-decoration:none;font-size:11px;letter-spacing:1px;transition:.2s}
.footer-links a:hover{color:var(--gold)}
.footer-brand{font-size:9px;color:rgba(255,255,255,0.15);letter-spacing:2px}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
@media(max-width:600px){nav{padding:12px 20px}.nav-links{display:none}.card{padding:36px 20px}.record-table th,.record-table td{padding:10px 14px}footer{padding:20px}.footer-inner{flex-direction:column;align-items:flex-start}}
</style>
</head>
<body>
<nav>
  <a href="<?= htmlspecialchars(BRAND_URL) ?>" class="nav-logo">
    <img src="logo.png" alt="<?= htmlspecialchars(BRAND_NAME) ?>">
    <div><div class="nav-logo-text"><?= htmlspecialchars(BRAND_UPPER) ?></div><div class="nav-logo-sub"><?= htmlspecialchars(BRAND_NAV_TAGLINE) ?></div></div>
  </a>
  <div class="nav-links">
    <a href="<?= htmlspecialchars(BRAND_URL) ?>">Home</a>
    <a href="<?= htmlspecialchars(BRAND_URL) ?>/faqs.html">FAQ</a>
    <a href="<?= htmlspecialchars(BRAND_URL) ?>/join-our-panel.html">Join Panel</a>
  </div>
  <div class="nav-live"><div class="nav-dot"></div>Live</div>
</nav>
<main>
  <div class="card">
    <div class="status-badge"><span><?= $c['icon'] ?></span> <?= htmlspecialchars($c['badge']) ?></div>
    <div class="main-title"><?= $c['title'] ?></div>
    <div class="divider"></div>
    <div class="main-msg"><?= htmlspecialchars($c['msg']) ?></div>
    <div class="record">
      <div class="record-head">
        <div class="record-title"><div class="record-dot"></div>Completion Record</div>
        <div class="record-time"><?= $time ?></div>
      </div>
      <table class="record-table">
        <thead><tr><th>Project ID</th><th>Respondent ID</th><th>Status</th><th>IP Address</th></tr></thead>
        <tbody>
          <tr>
            <td class="sid-val"><?= htmlspecialchars($sid ?: '—') ?></td>
            <td class="uid-val"><?= htmlspecialchars($original_uid ?: '—') ?></td>
            <td><span class="status-pill">● <?= htmlspecialchars(strtoupper(str_replace('_',' ',$status))) ?></span></td>
            <td class="ip-val"><?= htmlspecialchars($ip) ?></td>
          </tr>
        </tbody>
      </table>
    </div>
    <?php if ($status === 'complete'): ?>
    <p class="footnote">Your response has been verified and recorded in our system.<br>Thank you for contributing to <?= htmlspecialchars(BRAND_NAME) ?> research.</p>
    <?php endif; ?>
  </div>
</main>
<footer>
  <div class="footer-inner">
    <div>
      <div class="footer-logo"><img src="logo.png" alt="<?= htmlspecialchars(BRAND_NAME) ?>"><div class="footer-logo-text"><?= htmlspecialchars(BRAND_UPPER) ?></div></div>
      <div class="footer-tagline"><?= htmlspecialchars(BRAND_FOOTER_TAGLINE) ?></div>
    </div>
    <div class="footer-links">
      <a href="mailto:<?= htmlspecialchars(BRAND_EMAIL) ?>"><?= htmlspecialchars(BRAND_EMAIL) ?></a>
      <a href="<?= htmlspecialchars(BRAND_URL) ?>/privacy-policy.html">Privacy</a>
      <a href="<?= htmlspecialchars(BRAND_URL) ?>/terms-of-service.html">Terms</a>
    </div>
    <div class="footer-brand">© <?= date('Y') ?> <?= htmlspecialchars(BRAND_UPPER) ?></div>
  </div>
</footer>
</body>
</html>
<?php
// ── DEFERRED BACKGROUND TASKS (identical pattern to end.php) ────
if (function_exists('fastcgi_finish_request')) {
    fastcgi_finish_request();
} else {
    if (ob_get_level() > 0) { ob_end_flush(); }
    flush();
}
if (!empty($deferred_vendor_id)) {
    rp_fire_vendor_postback($db, $deferred_vendor_id, $status, $original_uid, $sid, $deferred_actual_seconds ?? null);
}
if (!empty($deferred_actual_seconds) && $proj) {
    rp_speeder_alert_check($proj, $sid, $original_uid, $deferred_actual_seconds);
}
