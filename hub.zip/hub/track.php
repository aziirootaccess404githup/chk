<?php
// ============================================================
// PanelEngine Survey Panel — track.php
// Dynamic status tracker — called by static HTML pages OR directly
// URL: /panelengine/track.php?status=complete&sid=RP001&uid=UID&loi=120
// Add &ajax=1 to get a JSON response instead of a redirect (used by
// the static pages/*.html confirmation pages to display respondent info).
//
// IMPORTANT: The "sid" in the incoming URL is only a starting hint — see
// the matching note in end.php. The real/internal sid is always resolved
// from our own rp_leads record and is what gets used/displayed from here on.
// ============================================================
require_once __DIR__ . '/config.php';

date_default_timezone_set('Asia/Kolkata');

// Flexible param-name fallback for ALL incoming identifiers - different client
// survey platforms (Qualtrics/Decipher/Confirmit/Toluna/etc) may fire the
// postback using different query param names on their end. This is purely
// additive - every name that worked before still works exactly the same;
// these are just extra accepted names layered on top.
$status  = trim($_GET['status'] ?? $_GET['disposition'] ?? $_GET['outcome'] ?? $_GET['result'] ?? 'complete');
$url_sid = trim($_GET['sid'] ?? $_GET['studyid'] ?? $_GET['surveyid'] ?? $_GET['project_id'] ?? $_GET['study_id'] ?? ''); // hint only
// Flexible param-name fallback — some clients' systems send the identifier
// back under a different name (rid, toid, identifier, tid) instead of uid.
// This is purely a safety-net; nothing else changes.
$enc_uid = trim($_GET['uid'] ?? $_GET['rid'] ?? $_GET['toid'] ?? $_GET['identifier'] ?? $_GET['tid'] ?? $_GET['pid']
              ?? $_GET['respondent_id'] ?? $_GET['panelist_id'] ?? $_GET['participant_id'] ?? $_GET['respid'] ?? $_GET['subject_id'] ?? '');
$loi_raw = $_GET['loi'] ?? $_GET['duration'] ?? $_GET['time_taken'] ?? $_GET['seconds'] ?? $_GET['elapsed'] ?? null;
$loi     = ($loi_raw !== null && is_numeric($loi_raw)) ? (int)$loi_raw : null;
$is_ajax = isset($_GET['ajax']);

// Allowed statuses
$valid = ['complete','terminate','overquota','quality_fail','qc','quotafull'];
if (!in_array($status, $valid)) $status = 'complete';
// Normalize
if ($status === 'qc')        $status = 'quality_fail';
if ($status === 'quotafull') $status = 'overquota';

$ip  = rp_get_ip();
$ua  = $_SERVER['HTTP_USER_AGENT'] ?? '';
$geo = rp_geo($ip);
$dev = rp_device();
$br  = rp_browser();
$db  = rp_db();
$sid = $url_sid; // may be corrected below once we find the real lead

// ── Resolve original UID (the incoming uid param may be encrypted) ───
$proj = null;
if ($sid) {
    $ps = $db->prepare("SELECT * FROM rp_projects WHERE sid = ? LIMIT 1");
    $ps->execute([$sid]);
    $proj = $ps->fetch();
}
$original_uid = $enc_uid;
if ($proj && !empty($proj['encrypt_uid'])) {
    $decrypted = rp_decrypt($enc_uid, $sid);
    if ($decrypted) {
        $original_uid = $decrypted;
    } else {
        $mr = $db->prepare("SELECT original_uid FROM rp_uid_mapping WHERE encrypted_uid = ? AND sid = ? LIMIT 1");
        $mr->execute([$enc_uid, $sid]);
        $mrow = $mr->fetch();
        if ($mrow) {
            $original_uid = $mrow['original_uid'];
        } else {
            // Mapping lookup without sid filter — covers a client sending a
            // different/wrong sid than what we used originally (encryption key
            // is sid-dependent, so a mismatched sid breaks decryption above).
            $mr2 = $db->prepare("SELECT original_uid, sid FROM rp_uid_mapping WHERE encrypted_uid = ? ORDER BY id DESC LIMIT 1");
            $mr2->execute([$enc_uid]);
            $mrow2 = $mr2->fetch();
            if ($mrow2) {
                $original_uid = $mrow2['original_uid'];
                $sid = $mrow2['sid']; // correct the sid to our real internal one
            }
        }
    }
}

// ── STATUS LOCK CHECK ─────────────────────────────────────────
$deferred_vendor_id = null;
$deferred_loi = null;
try {
    // Try by original_uid + sid (normal case — client sent the correct sid)
    $lc = $db->prepare("SELECT id, sid, status, status_locked, vendor_id FROM rp_leads WHERE original_uid = ? AND sid = ? ORDER BY id DESC LIMIT 1");
    $lc->execute([$original_uid, $sid]);
    $existing = $lc->fetch();

    if (!$existing) {
        $lc2 = $db->prepare("SELECT id, sid, status, status_locked, vendor_id FROM rp_leads WHERE encrypted_uid = ? AND sid = ? ORDER BY id DESC LIMIT 1");
        $lc2->execute([$enc_uid, $sid]);
        $existing = $lc2->fetch();
    }

    if (!$existing) {
        // Further fallback: same UID, ANY project — our own stored sid
        // (from when the respondent first clicked in) always wins over
        // whatever sid the client's system sent back.
        $lc3 = $db->prepare("SELECT id, sid, status, status_locked, vendor_id FROM rp_leads WHERE original_uid = ? OR encrypted_uid = ? ORDER BY id DESC LIMIT 1");
        $lc3->execute([$original_uid, $enc_uid]);
        $existing = $lc3->fetch();
    }

    // If found, its stored sid is the ONLY authoritative sid from here on.
    if ($existing) {
        $sid = $existing['sid'];
        if (!$proj || $proj['sid'] !== $sid) {
            $ps2 = $db->prepare("SELECT * FROM rp_projects WHERE sid = ? LIMIT 1");
            $ps2->execute([$sid]);
            $proj = $ps2->fetch();
        }
    }

    if ($existing && !empty($existing['status_locked'])) {
        // Already locked — use the locked status instead
        $status = $existing['status'];
    } elseif ($existing) {
        // Update existing lead
        $db->prepare("UPDATE rp_leads SET status=?, end_time=NOW(), loi_seconds=?, status_locked=1 WHERE id=?")
           ->execute([$status, $loi, $existing['id']]);
        $deferred_vendor_id = $existing['vendor_id'];
        if ($status === 'complete') {
            rp_check_quota($db, $sid);
            $deferred_loi = $loi;
        }
    } else {
        // No existing lead anywhere — genuinely new direct hit. No internal
        // record exists yet, so the URL's sid is the best information
        // available and becomes the internal sid going forward.
        $db->prepare("INSERT INTO rp_leads (sid, original_uid, encrypted_uid, status, ip, country, city, device, browser, user_agent, loi_seconds, is_duplicate, status_locked, source, entry_time, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,0,1,'direct',NOW(),NOW())")
           ->execute([$sid, $original_uid, $enc_uid, $status, $ip, $geo['country'], $geo['city'], $dev, $br, substr($ua,0,500), $loi]);
        if ($status === 'complete') {
            rp_check_quota($db, $sid);
            $deferred_loi = $loi;
        }
    }
} catch (PDOException $e) {
    error_log("PanelEngine track.php error: " . $e->getMessage());
}

// ── AJAX MODE: return JSON for static pages to render ─────────
// (Respondent's browser is already showing the static Thank You page —
// this is just a background info/tracking call, so no vendor redirect
// is possible here; postback still fires in the background as usual.)
if ($is_ajax) {
    header('Content-Type: application/json');
    echo json_encode([
        'sid'    => $sid,
        'uid'    => $original_uid ?: $enc_uid,
        'status' => $status,
        'ip'     => $ip,
        'time'   => date('d/m/Y, H:i:s'),
    ]);
    rp_flush_and_defer($db, $deferred_vendor_id, $status, $original_uid ?: $enc_uid, $sid, $proj, $deferred_loi);
    exit();
}

// ── REDIRECT-MODE VENDORS: send the respondent straight to the vendor's
// own page instead of ours (only possible on this full-navigation path).
$vendor_redirect_url = rp_build_vendor_redirect_url($db, $deferred_vendor_id, $status, $original_uid ?: $enc_uid, $sid, $deferred_loi);
if ($vendor_redirect_url) {
    header("Location: $vendor_redirect_url");
    exit();
}

// ── REDIRECT TO END PAGE (show_page mode / default behavior) ─────
// Fire the vendor postback now (in the background, after flushing this
// redirect response), and mark the forwarded request so end.php knows
// not to fire the same postback a second time.
header("Location: end.php?status=$status&sid=" . urlencode($sid) . "&uid=" . urlencode($enc_uid) . "&_notified=1");
rp_flush_and_defer($db, $deferred_vendor_id, $status, $original_uid ?: $enc_uid, $sid, $proj, $deferred_loi);
exit();
