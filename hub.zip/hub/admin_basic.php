<?php
// ============================================================
// Azilytics Insights — admin.php
// Full dashboard: Dashboard, Projects, Clients, Vendors, Leads
// ============================================================
require_once __DIR__ . '/config.php';
rp_require_login();

$db   = rp_db();
$user = rp_current_user();
$page = $_GET['page'] ?? 'dashboard';
$msg  = '';
$err  = '';

// ── AJAX / POST HANDLERS ─────────────────────────────────────

// ── DELETE HANDLERS ──────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    // Pause / Resume Project
    if ($action === 'toggle_project_status' && rp_is_manager()) {
        $id = (int)$_POST['id'];
        $cur = $db->prepare("SELECT status FROM rp_projects WHERE id=?");
        $cur->execute([$id]);
        $cur_status = $cur->fetchColumn();
        $new_status = $cur_status === 'active' ? 'paused' : 'active';
        $db->prepare("UPDATE rp_projects SET status=? WHERE id=?")->execute([$new_status, $id]);
        $ref = $_SERVER['HTTP_REFERER'] ?? '';
        if (strpos($ref, 'project_view') !== false) {
            header("Location: admin.php?page=project_view&id=$id&msg=Project+".ucfirst($new_status));
        } else {
            header("Location: admin.php?page=projects&msg=Project+".ucfirst($new_status));
        }
        exit();
    }

    // Password Change
    if ($action === 'change_password') {
        $current = trim($_POST['current_password'] ?? '');
        $new     = trim($_POST['new_password'] ?? '');
        $confirm = trim($_POST['confirm_password'] ?? '');
        $uid = $user['id'];
        $u = $db->prepare("SELECT password FROM rp_users WHERE id=?");
        $u->execute([$uid]); $u = $u->fetch();
        if (!password_verify($current, $u['password'])) {
            header("Location: admin.php?page=change_password&err=Current+password+incorrect");
        } elseif (strlen($new) < 6) {
            header("Location: admin.php?page=change_password&err=Password+must+be+6+chars+minimum");
        } elseif ($new !== $confirm) {
            header("Location: admin.php?page=change_password&err=Passwords+do+not+match");
        } else {
            $db->prepare("UPDATE rp_users SET password=? WHERE id=?")->execute([password_hash($new, PASSWORD_DEFAULT), $uid]);
            header("Location: admin.php?page=change_password&msg=Password+changed+successfully");
        }
        exit();
    }

    // Save Project
    if ($action === 'save_project' && rp_is_manager()) {
        $id = (int)($_POST['id'] ?? 0);
        $client_id = (int)($_POST['client_id'] ?? 0);
        $client_name = '';
        if ($client_id > 0) {
            $client_row = $db->prepare("SELECT client_name FROM rp_clients WHERE id=?");
            $client_row->execute([$client_id]);
            $client_name = $client_row->fetchColumn() ?: '';
            if ($client_name === '') $client_id = 0; // client_id didn't match any real client
        }
        $data = [
            ':sid'          => strtoupper(trim($_POST['sid'])),
            ':project_name' => trim($_POST['project_name']),
            ':client_id'    => $client_id > 0 ? $client_id : null,
            ':client_name'  => $client_name,
            ':cpi'          => (float)($_POST['cpi'] ?? 0),
            ':ir'           => (float)($_POST['ir'] ?? 0),
            ':loi'          => (int)($_POST['loi'] ?? 0),
            ':max_completes'=> (int)($_POST['max_completes'] ?? 0),
            ':live_url'     => trim($_POST['live_url'] ?? ''),
            ':test_url'     => trim($_POST['test_url'] ?? ''),
            ':status'       => $_POST['status'] ?? 'active',
            ':project_type' => $_POST['project_type'] ?? 'direct',
            ':encrypt_uid'  => isset($_POST['encrypt_uid']) ? 1 : 0,
            ':description'  => trim($_POST['description'] ?? ''),
        ];
        if ($id > 0) {
            $sql = "UPDATE rp_projects SET sid=:sid, project_name=:project_name, client_id=:client_id, client_name=:client_name, cpi=:cpi, ir=:ir, loi=:loi, max_completes=:max_completes, live_url=:live_url, test_url=:test_url, status=:status, project_type=:project_type, encrypt_uid=:encrypt_uid, description=:description WHERE id=$id";
        } else {
            $sql = "INSERT INTO rp_projects (sid, project_name, client_id, client_name, cpi, ir, loi, max_completes, live_url, test_url, status, project_type, encrypt_uid, description) VALUES (:sid,:project_name,:client_id,:client_name,:cpi,:ir,:loi,:max_completes,:live_url,:test_url,:status,:project_type,:encrypt_uid,:description)";
        }
        $db->prepare($sql)->execute($data);
        header("Location: admin.php?page=projects&msg=Project+saved");
        exit();
    }
    // Save Client
    if ($action === 'save_client' && rp_is_manager()) {
        $id = (int)($_POST['id'] ?? 0);
        $data = [
            ':client_name' => trim($_POST['client_name']),
            ':email'       => trim($_POST['email'] ?? ''),
            ':phone'       => trim($_POST['phone'] ?? ''),
            ':company'     => trim($_POST['company'] ?? ''),
            ':status'      => $_POST['status'] ?? 'active',
        ];
        if ($id > 0) {
            $db->prepare("UPDATE rp_clients SET client_name=:client_name, email=:email, phone=:phone, company=:company, status=:status WHERE id=$id")->execute($data);
        } else {
            $db->prepare("INSERT INTO rp_clients (client_name, email, phone, company, status) VALUES (:client_name,:email,:phone,:company,:status)")->execute($data);
        }
        header("Location: admin.php?page=clients&msg=Client+saved");
        exit();
    }
    // Save Vendor
    if ($action === 'save_vendor' && rp_is_manager()) {
        $id = (int)($_POST['id'] ?? 0);
        $data = [
            ':vendor_name'   => trim($_POST['vendor_name']),
            ':email'         => trim($_POST['email'] ?? ''),
            ':phone'         => trim($_POST['phone'] ?? ''),
            ':complete_url'  => trim($_POST['complete_url'] ?? ''),
            ':terminate_url' => trim($_POST['terminate_url'] ?? ''),
            ':screenout_url' => trim($_POST['screenout_url'] ?? ''),
            ':quotafull_url' => trim($_POST['quotafull_url'] ?? ''),
            ':status'        => $_POST['status'] ?? 'active',
        ];
        if ($id > 0) {
            $db->prepare("UPDATE rp_vendors SET vendor_name=:vendor_name, email=:email, phone=:phone, complete_url=:complete_url, terminate_url=:terminate_url, screenout_url=:screenout_url, quotafull_url=:quotafull_url, status=:status WHERE id=$id")->execute($data);
        } else {
            $db->prepare("INSERT INTO rp_vendors (vendor_name, email, phone, complete_url, terminate_url, screenout_url, quotafull_url, status) VALUES (:vendor_name,:email,:phone,:complete_url,:terminate_url,:screenout_url,:quotafull_url,:status)")->execute($data);
        }
        header("Location: admin.php?page=vendors&msg=Vendor+saved");
        exit();
    }
    // Assign Vendor to Project
    if ($action === 'assign_vendor' && rp_is_manager()) {
        $pid = (int)$_POST['project_id'];
        $vid = (int)$_POST['vendor_id'];
        $cpi = (float)($_POST['cpi'] ?? 0);
        $lim = (int)($_POST['max_limit'] ?? 0);
        $stmt = $db->prepare("INSERT IGNORE INTO rp_project_vendors (project_id, vendor_id, cpi, max_limit) VALUES (?,?,?,?)");
        $stmt->execute([$pid, $vid, $cpi, $lim]);
        header("Location: admin.php?page=project_view&id=$pid&msg=Vendor+assigned");
        exit();
    }
}

// ── LOGOUT ───────────────────────────────────────────────────
if ($page === 'logout') {
    rp_session_start();
    session_destroy();
    header('Location: login.php');
    exit();
}

// ── FETCH DATA FOR PAGES ─────────────────────────────────────

// Dashboard stats
$stats = [];
if ($page === 'dashboard') {
    $stats['total_clicks']    = $db->query("SELECT COUNT(*) FROM rp_leads")->fetchColumn();
    $stats['total_completes'] = $db->query("SELECT COUNT(*) FROM rp_leads WHERE status='complete'")->fetchColumn();
    $stats['total_terminates']= $db->query("SELECT COUNT(*) FROM rp_leads WHERE status='terminate'")->fetchColumn();
    $stats['active_projects'] = $db->query("SELECT COUNT(*) FROM rp_projects WHERE status='active'")->fetchColumn();
    $stats['active_vendors']  = $db->query("SELECT COUNT(*) FROM rp_vendors WHERE status='active'")->fetchColumn();
    $stats['total_clients']   = $db->query("SELECT COUNT(*) FROM rp_clients WHERE status='active'")->fetchColumn();
    // Last 7 days chart data
    $chart_data = [];
    for ($i = 6; $i >= 0; $i--) {
        $date  = date('Y-m-d', strtotime("-$i days"));
        $label = date('D', strtotime("-$i days"));
        $clicks    = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE DATE(created_at)=?");
        $clicks->execute([$date]); $c = $clicks->fetchColumn();
        $completes = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE DATE(created_at)=? AND status='complete'");
        $completes->execute([$date]); $co = $completes->fetchColumn();
        $chart_data[] = ['label'=>$label,'clicks'=>$c,'completes'=>$co];
    }
}

// Projects list
$projects = [];
if ($page === 'projects') {
    $projects = $db->query("SELECT p.*, c.client_name as cname FROM rp_projects p LEFT JOIN rp_clients c ON p.client_id=c.id ORDER BY p.id DESC")->fetchAll();
}

// Project view
$project_view = null;
$project_vendors = [];
$all_vendors_for_assign = [];
if ($page === 'project_view') {
    $pid = (int)($_GET['id'] ?? 0);
    $project_view = $db->prepare("SELECT * FROM rp_projects WHERE id=?");
    $project_view->execute([$pid]);
    $project_view = $project_view->fetch();
    if ($project_view) {
        $project_vendors = $db->prepare("SELECT pv.*, v.vendor_name, v.email FROM rp_project_vendors pv JOIN rp_vendors v ON pv.vendor_id=v.id WHERE pv.project_id=?");
        $project_vendors->execute([$pid]);
        $project_vendors = $project_vendors->fetchAll();
        $assigned_ids = array_column($project_vendors, 'vendor_id');
        $all_vendors_for_assign = $db->query("SELECT * FROM rp_vendors WHERE status='active' ORDER BY vendor_name")->fetchAll();
        $all_vendors_for_assign = array_filter($all_vendors_for_assign, fn($v) => !in_array($v['id'], $assigned_ids));
        // Leads for this project
        $project_leads = $db->prepare("SELECT * FROM rp_leads WHERE sid=? ORDER BY id DESC LIMIT 100");
        $project_leads->execute([$project_view['sid']]);
        $project_leads = $project_leads->fetchAll();
    }
}

// Clients
$clients = [];
if ($page === 'clients') {
    $clients = $db->query("SELECT * FROM rp_clients ORDER BY id DESC")->fetchAll();
}

// Vendors
$vendors = [];
if ($page === 'vendors') {
    $vendors = $db->query("SELECT * FROM rp_vendors ORDER BY id DESC")->fetchAll();
}

// Vendor Detail View
$vendor_view = null;
$vendor_leads = [];
$vendor_projects = [];
if ($page === 'vendor_view') {
    $vid = (int)($_GET['id'] ?? 0);
    $vs = $db->prepare("SELECT * FROM rp_vendors WHERE id=?");
    $vs->execute([$vid]);
    $vendor_view = $vs->fetch();
    if ($vendor_view) {
        $vl = $db->prepare("SELECT l.*, p.project_name FROM rp_leads l LEFT JOIN rp_projects p ON l.sid=p.sid WHERE l.vendor_id=? ORDER BY l.id DESC LIMIT 200");
        $vl->execute([$vid]);
        $vendor_leads = $vl->fetchAll();
        $vp = $db->prepare("SELECT pv.*, p.project_name, p.sid FROM rp_project_vendors pv JOIN rp_projects p ON pv.project_id=p.id WHERE pv.vendor_id=?");
        $vp->execute([$vid]);
        $vendor_projects = $vp->fetchAll();
    }
}

// Leads
$leads = [];
$leads_total = 0;
if ($page === 'leads') {
    $search = trim($_GET['search'] ?? '');
    $status_filter = $_GET['status'] ?? '';
    $lpage = max(1, (int)($_GET['lpage'] ?? 1));
    $limit = 50;
    $offset = ($lpage - 1) * $limit;
    $where = '1=1';
    $params = [];
    if ($search) { $where .= " AND (l.original_uid LIKE ? OR l.sid LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
    if ($status_filter) { $where .= " AND l.status=?"; $params[] = $status_filter; }
    $count_stmt = $db->prepare("SELECT COUNT(*) FROM rp_leads l WHERE $where");
    $count_stmt->execute($params);
    $leads_total = $count_stmt->fetchColumn();
    $stmt = $db->prepare("SELECT l.*, p.project_name FROM rp_leads l LEFT JOIN rp_projects p ON l.sid=p.sid WHERE $where ORDER BY l.id DESC LIMIT $limit OFFSET $offset");
    $stmt->execute($params);
    $leads = $stmt->fetchAll();
}

// All clients for dropdowns
$all_clients = $db->query("SELECT id, client_name FROM rp_clients WHERE status='active' ORDER BY client_name")->fetchAll();
$all_vendors = $db->query("SELECT id, vendor_name FROM rp_vendors WHERE status='active' ORDER BY vendor_name")->fetchAll();

$msg = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars(BRAND_NAME) ?> Panel</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Mono&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#f4f6fb;
  --surface:#ffffff;
  --surface2:#f1f3f9;
  --border:rgba(15,23,42,0.08);
  --text:#0f172a;
  --text2:#475569;
  --text3:#94a3b8;
  --accent:#6366f1;
  --accent2:#8b5cf6;
  --green:#16a34a;
  --amber:#d97706;
  --blue:#2563eb;
  --red:#dc2626;
  --pink:#db2777;
  --sidebar-w:220px;
}
body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;min-height:100vh;display:flex}

/* ── SIDEBAR ── */
.sidebar{
  width:var(--sidebar-w);
  background:var(--surface);
  border-right:1px solid var(--border);
  display:flex;flex-direction:column;
  position:fixed;top:0;left:0;bottom:0;
  z-index:100;overflow-y:auto;
}
.sidebar-logo{
  padding:20px 18px 16px;
  border-bottom:1px solid var(--border);
  display:flex;align-items:center;gap:10px;
}
.logo-icon{
  width:36px;height:36px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  border-radius:9px;
  display:flex;align-items:center;justify-content:center;
  font-size:11px;font-weight:700;color:#fff;letter-spacing:-0.3px;
  flex-shrink:0;
}
.logo-text{font-size:15px;font-weight:700;letter-spacing:1.5px;color:var(--text)}
.logo-sub{font-size:9px;letter-spacing:2px;color:var(--text3);margin-top:1px}

.sidebar-user{
  padding:14px 18px;
  border-bottom:1px solid var(--border);
  font-size:12px;
}
.sidebar-user-name{font-weight:600;color:var(--text);margin-bottom:2px}
.sidebar-user-role{
  font-size:10px;letter-spacing:1px;
  color:var(--accent);font-weight:600;
  text-transform:uppercase;
}

.sidebar-nav{flex:1;padding:10px 0}
.nav-section{
  font-size:9px;letter-spacing:2px;
  color:var(--text3);font-weight:600;
  padding:14px 18px 6px;
  text-transform:uppercase;
}
.nav-link{
  display:flex;align-items:center;gap:10px;
  padding:9px 18px;
  font-size:13px;font-weight:500;
  color:var(--text2);
  text-decoration:none;
  transition:all .15s;
  border-left:3px solid transparent;
}
.nav-link:hover{color:var(--text);background:rgba(15,23,42,0.04)}
.nav-link.active{
  color:var(--accent);
  background:rgba(99,102,241,0.08);
  border-left-color:var(--accent);
}
.nav-link .icon{font-size:15px;width:18px;text-align:center}

.sidebar-footer{
  padding:14px 18px;
  border-top:1px solid var(--border);
  font-size:11px;color:var(--text3);
}

/* ── MAIN ── */
.main{margin-left:var(--sidebar-w);flex:1;min-height:100vh;display:flex;flex-direction:column}

/* ── TOPBAR ── */
.topbar{
  background:var(--surface);
  border-bottom:1px solid var(--border);
  padding:14px 28px;
  display:flex;align-items:center;justify-content:space-between;
  position:sticky;top:0;z-index:50;
}
.topbar-title{font-size:16px;font-weight:600;color:var(--text)}
.topbar-right{display:flex;align-items:center;gap:12px}
.live-badge{
  display:flex;align-items:center;gap:6px;
  background:rgba(34,197,94,0.1);
  border:1px solid rgba(34,197,94,0.25);
  border-radius:20px;padding:4px 10px;
  font-size:11px;color:var(--green);font-weight:600;
}
.live-dot{width:6px;height:6px;border-radius:50%;background:var(--green);animation:pulse 2s infinite}

/* ── CONTENT ── */
.content{padding:24px 28px;flex:1}

/* ── FLASH MSG ── */
.flash{
  background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.2);
  border-radius:8px;padding:10px 16px;
  font-size:13px;color:var(--green);margin-bottom:20px;
}

/* ── STAT CARDS ── */
.stats-grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
  gap:16px;margin-bottom:24px;
}
.stat-card{
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:12px;
  padding:20px;
  position:relative;overflow:hidden;
  transition:border-color .2s;
}
.stat-card:hover{border-color:rgba(15,23,42,0.16)}
.stat-card::before{
  content:'';position:absolute;
  top:0;left:0;right:0;height:3px;
  background:var(--card-color,var(--accent));
}
.stat-label{font-size:11px;letter-spacing:1.5px;color:var(--text3);font-weight:600;text-transform:uppercase;margin-bottom:10px}
.stat-value{font-size:28px;font-weight:700;color:var(--text);line-height:1}
.stat-sub{font-size:11px;color:var(--text3);margin-top:6px}

/* ── SECTION HEADER ── */
.section-header{
  display:flex;align-items:center;justify-content:space-between;
  margin-bottom:18px;
}
.section-title{font-size:15px;font-weight:600;color:var(--text)}

/* ── BUTTONS ── */
.btn{
  display:inline-flex;align-items:center;gap:6px;
  padding:8px 16px;border-radius:8px;
  font-size:13px;font-weight:600;
  cursor:pointer;border:none;
  text-decoration:none;transition:opacity .15s;
  font-family:'DM Sans',sans-serif;
}
.btn:hover{opacity:0.85}
.btn-primary{background:linear-gradient(135deg,var(--accent),var(--accent2));color:#fff}
.btn-sm{padding:5px 12px;font-size:12px;border-radius:6px}
.btn-danger{background:rgba(239,68,68,0.15);color:var(--red);border:1px solid rgba(239,68,68,0.2)}
.btn-ghost{background:rgba(15,23,42,0.04);color:var(--text2);border:1px solid var(--border)}
.btn-green{background:rgba(34,197,94,0.15);color:var(--green);border:1px solid rgba(34,197,94,0.2)}
.btn-blue{background:rgba(59,130,246,0.15);color:var(--blue);border:1px solid rgba(59,130,246,0.2)}
.btn-amber{background:rgba(245,158,11,0.15);color:var(--amber);border:1px solid rgba(245,158,11,0.2)}

/* ── TABLE ── */
.table-wrap{
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:12px;overflow:hidden;
}
.table-toolbar{
  padding:14px 18px;
  border-bottom:1px solid var(--border);
  display:flex;align-items:center;gap:12px;flex-wrap:wrap;
}
table{width:100%;border-collapse:collapse}
thead th{
  padding:11px 16px;
  font-size:10px;letter-spacing:1.5px;
  color:var(--text3);font-weight:600;
  text-align:left;text-transform:uppercase;
  border-bottom:1px solid var(--border);
  background:var(--surface2);
}
tbody td{
  padding:12px 16px;
  font-size:13px;color:var(--text2);
  border-bottom:1px solid var(--border);
  vertical-align:middle;
}
tbody tr:last-child td{border-bottom:none}
tbody tr:hover td{background:rgba(15,23,42,0.025)}
.td-main{color:var(--text);font-weight:500}
.mono{font-family:'DM Mono',monospace;font-size:12px}

/* ── PILLS ── */
.pill{
  display:inline-flex;align-items:center;gap:4px;
  padding:3px 10px;border-radius:20px;
  font-size:11px;font-weight:600;letter-spacing:0.5px;
}
.pill-green{background:rgba(34,197,94,0.1);color:var(--green);border:1px solid rgba(34,197,94,0.2)}
.pill-amber{background:rgba(245,158,11,0.1);color:var(--amber);border:1px solid rgba(245,158,11,0.2)}
.pill-red{background:rgba(239,68,68,0.1);color:var(--red);border:1px solid rgba(239,68,68,0.2)}
.pill-blue{background:rgba(59,130,246,0.1);color:var(--blue);border:1px solid rgba(59,130,246,0.2)}
.pill-purple{background:rgba(99,102,241,0.1);color:var(--accent);border:1px solid rgba(99,102,241,0.2)}
.pill-gray{background:rgba(15,23,42,0.05);color:var(--text2);border:1px solid var(--border)}

/* ── MODAL ── */
.modal-overlay{
  display:none;position:fixed;inset:0;
  background:rgba(0,0,0,0.7);z-index:200;
  align-items:center;justify-content:center;
}
.modal-overlay.open{display:flex}
.modal{
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:16px;
  padding:28px;width:100%;max-width:560px;
  max-height:90vh;overflow-y:auto;
  position:relative;
}
.modal-title{font-size:16px;font-weight:600;margin-bottom:20px;color:var(--text)}
.modal-close{
  position:absolute;top:20px;right:20px;
  background:none;border:none;color:var(--text3);
  font-size:20px;cursor:pointer;line-height:1;
}
.modal-close:hover{color:var(--text)}

/* ── FORM ── */
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.form-grid.full{grid-template-columns:1fr}
.field{display:flex;flex-direction:column;gap:6px}
.field.span2{grid-column:span 2}
.field label{font-size:11px;font-weight:600;letter-spacing:1px;color:var(--text3);text-transform:uppercase}
.field input,.field select,.field textarea{
  background:var(--bg);border:1px solid var(--border);
  border-radius:8px;padding:9px 12px;
  font-size:13px;color:var(--text);
  font-family:'DM Sans',sans-serif;
  outline:none;transition:border-color .15s;
  width:100%;
}
.field input:focus,.field select:focus,.field textarea:focus{border-color:var(--accent)}
.field textarea{resize:vertical;min-height:80px}
.field select option{background:var(--surface)}

/* ── SEARCH ── */
.search-input{
  background:var(--bg);border:1px solid var(--border);
  border-radius:8px;padding:8px 12px;
  font-size:13px;color:var(--text);
  font-family:'DM Sans',sans-serif;
  outline:none;min-width:200px;
}
.search-input:focus{border-color:var(--accent)}

/* ── CHART ── */
.chart-wrap{
  background:var(--surface);border:1px solid var(--border);
  border-radius:12px;padding:20px;margin-bottom:20px;
}
.chart-title{font-size:12px;letter-spacing:1.5px;color:var(--text3);font-weight:600;text-transform:uppercase;margin-bottom:16px}
.chart-bars{display:flex;align-items:flex-end;gap:8px;height:100px}
.chart-bar-group{flex:1;display:flex;flex-direction:column;align-items:center;gap:4px}
.chart-bar{width:100%;border-radius:4px 4px 0 0;min-height:2px;transition:height .3s}
.chart-label{font-size:10px;color:var(--text3);margin-top:4px}
.chart-legend{display:flex;gap:16px;margin-top:10px}
.chart-legend-item{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--text3)}
.legend-dot{width:8px;height:8px;border-radius:50%}

/* ── URL BOX ── */
.url-box{
  background:var(--bg);border:1px solid var(--border);
  border-radius:8px;padding:10px 14px;
  display:flex;align-items:center;justify-content:space-between;gap:10px;
  margin-bottom:8px;
}
.url-label{font-size:10px;letter-spacing:1px;color:var(--text3);font-weight:600;text-transform:uppercase;margin-bottom:4px}
.url-val{font-family:'DM Mono',monospace;font-size:11px;color:var(--accent);word-break:break-all;flex:1}
.copy-btn{
  background:rgba(99,102,241,0.1);border:1px solid rgba(99,102,241,0.2);
  color:var(--accent);border-radius:6px;padding:4px 10px;
  font-size:11px;font-weight:600;cursor:pointer;white-space:nowrap;
  font-family:'DM Sans',sans-serif;
}
.copy-btn:hover{background:rgba(99,102,241,0.2)}

/* ── CARDS GRID ── */
.cards-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-bottom:24px}
.info-card{
  background:var(--surface);border:1px solid var(--border);
  border-radius:12px;padding:20px;
}
.info-card-title{font-size:11px;letter-spacing:1.5px;color:var(--text3);font-weight:600;text-transform:uppercase;margin-bottom:14px}
.info-row{display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border)}
.info-row:last-child{border-bottom:none}
.info-key{font-size:12px;color:var(--text3)}
.info-val{font-size:13px;color:var(--text);font-weight:500}

/* ── PAGINATION ── */
.pagination{display:flex;gap:6px;margin-top:16px;justify-content:center}
.page-btn{
  background:var(--surface);border:1px solid var(--border);
  border-radius:6px;padding:6px 12px;font-size:13px;color:var(--text2);
  text-decoration:none;transition:all .15s;
}
.page-btn:hover,.page-btn.active{background:var(--accent);color:#fff;border-color:var(--accent)}

@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}

/* ── RESPONSIVE ── */
@media(max-width:768px){
  .sidebar{width:100%;height:auto;position:relative;flex-direction:row;flex-wrap:wrap}
  .main{margin-left:0}
  .form-grid{grid-template-columns:1fr}
  .field.span2{grid-column:span 1}
}
</style>
</head>
<body>

<!-- SIDEBAR -->
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="logo-icon"><?= htmlspecialchars(BRAND_ICON) ?></div>
    <div>
      <div class="logo-text"><?= htmlspecialchars(BRAND_UPPER) ?></div>
      <div class="logo-sub"><?= htmlspecialchars(BRAND_TAGLINE) ?></div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="sidebar-user-name"><?= htmlspecialchars($user['name']) ?></div>
    <div class="sidebar-user-role"><?= htmlspecialchars($user['role']) ?></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section">Main</div>
    <a href="?page=dashboard" class="nav-link <?= $page==='dashboard'?'active':'' ?>">
      <span class="icon">📊</span> Dashboard
    </a>
    <a href="?page=projects" class="nav-link <?= in_array($page,['projects','project_view'])?'active':'' ?>">
      <span class="icon">📁</span> Projects
    </a>
    <a href="?page=leads" class="nav-link <?= $page==='leads'?'active':'' ?>">
      <span class="icon">📋</span> Leads
    </a>
    <div class="nav-section">Management</div>
    <a href="?page=clients" class="nav-link <?= $page==='clients'?'active':'' ?>">
      <span class="icon">🏢</span> Clients
    </a>
    <a href="?page=vendors" class="nav-link <?= in_array($page,['vendors','vendor_view'])?'active':'' ?>">
      <span class="icon">🤝</span> Vendors
    </a>
    <div class="nav-section">Account</div>
    <a href="?page=change_password" class="nav-link <?= $page==='change_password'?'active':'' ?>">
      <span class="icon">🔑</span> Change Password
    </a>
  </nav>
  <div class="sidebar-footer">
    <a href="?page=logout" style="color:var(--red);text-decoration:none;font-size:12px">⏻ Logout</a>
  </div>
</aside>

<!-- MAIN -->
<div class="main">

  <!-- TOPBAR -->
  <div class="topbar">
    <div class="topbar-title">
      <?php
      $titles = ['dashboard'=>'Dashboard','projects'=>'Projects','project_view'=>'Project Details','clients'=>'Clients','vendors'=>'Vendors','vendor_view'=>'Vendor Details','leads'=>'Leads','change_password'=>'Change Password'];
      echo $titles[$page] ?? 'Dashboard';
      ?>
    </div>
    <div class="topbar-right">
      <div class="live-badge"><div class="live-dot"></div> LIVE</div>
    </div>
  </div>

  <!-- CONTENT -->
  <div class="content">

  <?php if ($page === 'dashboard'): ?>
  <script>
  setTimeout(() => window.location.reload(), 60000);
  </script>
  <div style="font-size:11px;color:var(--text3);margin-bottom:16px;text-align:right">
    🔄 Auto-refresh: 60s &nbsp;|&nbsp; Updated: <?= date('H:i:s') ?> IST
  </div>
  <?php endif; ?>

  <?php if ($msg): ?>
  <div class="flash">✓ <?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>

  <?php

  // ════════════════════════════════════════════
  // DASHBOARD
  // ════════════════════════════════════════════
  if ($page === 'dashboard'):
    $max_clicks = max(1, max(array_column($chart_data, 'clicks')));
  ?>
  <div class="stats-grid">
    <div class="stat-card" style="--card-color:#6366f1">
      <div class="stat-label">Total Clicks</div>
      <div class="stat-value"><?= number_format($stats['total_clicks']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#22c55e">
      <div class="stat-label">Completes</div>
      <div class="stat-value"><?= number_format($stats['total_completes']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#f59e0b">
      <div class="stat-label">Terminates</div>
      <div class="stat-value"><?= number_format($stats['total_terminates']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#3b82f6">
      <div class="stat-label">Active Projects</div>
      <div class="stat-value"><?= number_format($stats['active_projects']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#ec4899">
      <div class="stat-label">Active Vendors</div>
      <div class="stat-value"><?= number_format($stats['active_vendors']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#8b5cf6">
      <div class="stat-label">Clients</div>
      <div class="stat-value"><?= number_format($stats['total_clients']) ?></div>
    </div>
  </div>

  <div class="chart-wrap">
    <div class="chart-title">Last 7 Days — Clicks & Completes</div>
    <div class="chart-bars">
      <?php
      $max_val = max(1, max(array_map(fn($d) => max($d['clicks'], $d['completes']), $chart_data)));
      foreach ($chart_data as $d):
        $ch = max(2, round(($d['clicks']/$max_val)*96));
        $co = max(2, round(($d['completes']/$max_val)*96));
      ?>
      <div class="chart-bar-group">
        <div style="display:flex;align-items:flex-end;gap:3px;height:100px">
          <div class="chart-bar" style="background:rgba(99,102,241,0.7);height:<?= $d['clicks']>0?$ch:2 ?>px;flex:1" title="Clicks: <?= $d['clicks'] ?>"></div>
          <div class="chart-bar" style="background:rgba(34,197,94,0.85);height:<?= $d['completes']>0?$co:2 ?>px;flex:1" title="Completes: <?= $d['completes'] ?>"></div>
        </div>
        <div class="chart-label"><?= $d['label'] ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="chart-legend">
      <div class="chart-legend-item"><div class="legend-dot" style="background:#6366f1"></div>Clicks</div>
      <div class="chart-legend-item"><div class="legend-dot" style="background:#22c55e"></div>Completes</div>
    </div>
  </div>

  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // PROJECTS LIST
  // ════════════════════════════════════════════
  if ($page === 'projects'):
  ?>
  <div class="section-header">
    <div class="section-title">All Projects (<?= count($projects) ?>)</div>
    <?php if (rp_is_manager()): ?>
    <button class="btn btn-primary" onclick="openModal('modalProject',{})">+ Add Project</button>
    <?php endif; ?>
  </div>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th><th>Project</th><th>Client</th><th>CPI</th><th>IR%</th><th>LOI</th><th>Completes</th><th>Conv%</th><th>Status</th><th>Type</th><th>Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($projects as $i => $p):
        $completes = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=? AND status='complete'");
        $completes->execute([$p['sid']]); $comp = $completes->fetchColumn();
        $clicks = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=?");
        $clicks->execute([$p['sid']]); $clk = $clicks->fetchColumn();
      ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td>
            <div class="td-main"><?= htmlspecialchars($p['project_name']) ?></div>
            <div class="mono" style="color:var(--text3)"><?= htmlspecialchars($p['sid']) ?></div>
          </td>
          <td><?= htmlspecialchars($p['client_name'] ?: '—') ?></td>
          <td>$<?= number_format($p['cpi'],2) ?></td>
          <td><?= $p['ir'] ?>%</td>
          <td><?= $p['loi'] ?>m</td>
          <td><?= $comp ?> / <?= $clk ?></td>
          <td style="color:<?= $clk>0&&($comp/$clk)>0.5?'var(--green)':'var(--amber)' ?>;font-weight:600">
            <?= $clk > 0 ? round(($comp/$clk)*100,1).'%' : '—' ?>
          </td>
          <td>
            <?php
            $pclass = ['active'=>'pill-green','paused'=>'pill-amber','closed'=>'pill-gray'];
            echo '<span class="pill '.($pclass[$p['status']]??'pill-gray').'">'.ucfirst($p['status']).'</span>';
            ?>
          </td>
          <td><span class="pill pill-blue"><?= ucfirst($p['project_type']) ?></span></td>
          <td>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              <a href="?page=project_view&id=<?= $p['id'] ?>" class="btn btn-sm btn-ghost">View</a>
              <?php if (rp_is_manager()): ?>
              <button class="btn btn-sm btn-ghost" onclick='openModal("modalProject",<?= json_encode($p) ?>)'>Edit</button>
              <form method="POST" style="display:inline">
                <input type="hidden" name="action" value="toggle_project_status">
                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                <button type="submit" class="btn btn-sm <?= $p['status']==='active' ? 'btn-amber' : 'btn-green' ?>">
                  <?= $p['status']==='active' ? '⏸ Pause' : '▶ Resume' ?>
                </button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($projects)): ?>
      <tr><td colspan="10" style="text-align:center;color:var(--text3);padding:32px">No projects yet. Add your first project!</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // PROJECT VIEW
  // ════════════════════════════════════════════
  if ($page === 'project_view' && $project_view):
    $base = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
    $folder = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/'); // auto-detects current folder (e.g. /panelengine or empty if at domain root)
    $base = $base . $folder;
    $sid = $project_view['sid'];
    $enc = $project_view['encrypt_uid'] ? '[ENCRYPTED_UID]' : '[UID]';
  ?>
  <div style="margin-bottom:16px;display:flex;align-items:center;gap:10px">
    <a href="?page=projects" class="btn btn-ghost btn-sm">← Back to Projects</a>
    <?php if (rp_is_manager()): ?>
    <form method="POST" style="display:inline">
      <input type="hidden" name="action" value="toggle_project_status">
      <input type="hidden" name="id" value="<?= $project_view['id'] ?>">
      <button type="submit" class="btn btn-sm <?= $project_view['status']==='active' ? 'btn-amber' : 'btn-green' ?>">
        <?= $project_view['status']==='active' ? '⏸ Pause Project' : '▶ Resume Project' ?>
      </button>
    </form>
    <button class="btn btn-sm btn-ghost" onclick='openModal("modalProject",<?= json_encode($project_view) ?>)'>✏ Edit Project</button>
    <?php endif; ?>
  </div>

  <!-- Stat cards -->
  <?php
    $p_clicks    = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=?"); $p_clicks->execute([$sid]); $p_clk = $p_clicks->fetchColumn();
    $p_completes = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=? AND status='complete'"); $p_completes->execute([$sid]); $p_comp = $p_completes->fetchColumn();
    $p_terminates= $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=? AND status='terminate'"); $p_terminates->execute([$sid]); $p_term = $p_terminates->fetchColumn();
    $quota = (int)$project_view['max_completes'];
    $quota_pct = ($quota > 0) ? min(100, round(($p_comp/$quota)*100)) : null;
  ?>
  <div class="stats-grid" style="grid-template-columns:repeat(<?= $quota?'4':'3' ?>,1fr);margin-bottom:20px">
    <div class="stat-card" style="--card-color:#6366f1"><div class="stat-label">Clicks</div><div class="stat-value"><?= $p_clk ?></div></div>
    <div class="stat-card" style="--card-color:#22c55e"><div class="stat-label">Completes</div><div class="stat-value"><?= $p_comp ?></div></div>
    <div class="stat-card" style="--card-color:#f59e0b"><div class="stat-label">Terminates</div><div class="stat-value"><?= $p_term ?></div></div>
    <?php if ($quota > 0): ?>
    <div class="stat-card" style="--card-color:#8b5cf6">
      <div class="stat-label">Quota</div>
      <div class="stat-value"><?= $quota_pct ?>%</div>
      <div style="margin-top:8px;background:rgba(15,23,42,0.08);border-radius:4px;height:4px;overflow:hidden">
        <div style="width:<?= $quota_pct ?>%;height:100%;background:<?= $quota_pct>=100?'var(--red)':($quota_pct>=80?'var(--amber)':'var(--accent)') ?>;border-radius:4px;transition:width .3s"></div>
      </div>
      <div class="stat-sub"><?= $p_comp ?> / <?= $quota ?></div>
    </div>
    <?php endif; ?>
  </div>

  <!-- Project Info -->
  <div class="cards-grid">
    <div class="info-card">
      <div class="info-card-title">Project Info</div>
      <div class="info-row"><span class="info-key">Project Name</span><span class="info-val"><?= htmlspecialchars($project_view['project_name']) ?></span></div>
      <div class="info-row"><span class="info-key">Project ID</span><span class="info-val mono"><?= htmlspecialchars($sid) ?></span></div>
      <div class="info-row"><span class="info-key">Client</span><span class="info-val"><?= htmlspecialchars($project_view['client_name'] ?: '—') ?></span></div>
      <div class="info-row"><span class="info-key">CPI</span><span class="info-val">$<?= number_format($project_view['cpi'],2) ?></span></div>
      <div class="info-row"><span class="info-key">IR%</span><span class="info-val"><?= $project_view['ir'] ?>%</span></div>
      <div class="info-row"><span class="info-key">LOI</span><span class="info-val"><?= $project_view['loi'] ?> min</span></div>
      <div class="info-row"><span class="info-key">Max Completes (Quota)</span><span class="info-val" style="color:var(--accent);font-weight:600"><?= $project_view['max_completes'] ? number_format($project_view['max_completes']) : 'Unlimited' ?></span></div>
      <div class="info-row"><span class="info-key">Status</span><span class="info-val"><?= ucfirst($project_view['status']) ?></span></div>
      <div class="info-row"><span class="info-key">Encryption</span><span class="info-val"><?= $project_view['encrypt_uid'] ? 'ON' : 'OFF' ?></span></div>
    </div>

    <?php if (!empty($project_view['description'])): ?>
    <!-- Description / Study Parameters -->
    <div class="info-card" style="margin-top:16px">
      <div class="info-card-title">Description / Study Parameters</div>
      <div style="padding:12px 0;font-size:13px;color:var(--text2);line-height:1.7">
        <?= $project_view['description'] ?>
      </div>
    </div>
    <?php endif; ?>

    <!-- Redirect URLs -->
    <div class="info-card">
      <div class="info-card-title">End Redirect URLs (Dynamic)</div>
      <?php
      $statuses = [
        'complete'  => ['Complete',  'pill-green'],
        'terminate' => ['Terminate', 'pill-amber'],
        'overquota' => ['Overquota', 'pill-blue'],
        'quality_fail' => ['Quality Fail','pill-red'],
      ];
      foreach ($statuses as $st => [$label, $cls]):
        $url = "$base/end.php?status=$st&sid=$sid&uid=$enc";
      ?>
      <div class="url-label"><span class="pill <?= $cls ?>"><?= $label ?></span></div>
      <div class="url-box">
        <div class="url-val"><?= htmlspecialchars($url) ?></div>
        <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($url) ?>')">Copy</button>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Static URLs -->
  <div class="info-card" style="margin-bottom:20px">
    <div class="info-card-title">Static Redirect URLs</div>
    <?php foreach ($statuses as $st => [$label, $cls]):
      $surl = "$base/pages/".str_replace('_','-',$st).".html?sid=$sid&uid=$enc";
    ?>
    <div class="url-label"><span class="pill <?= $cls ?>"><?= $label ?></span></div>
    <div class="url-box">
      <div class="url-val"><?= htmlspecialchars($surl) ?></div>
      <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($surl) ?>')">Copy</button>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Vendors -->
  <div class="section-header">
    <div class="section-title">Assigned Vendors (<?= count($project_vendors) ?>)</div>
    <div style="display:flex;gap:8px">
      <?php if (rp_is_manager() && !empty($all_vendors_for_assign)): ?>
      <button class="btn btn-primary btn-sm" onclick="document.getElementById('assignVendorModal').classList.add('open')">+ Assign Vendor</button>
      <?php endif; ?>
    </div>
  </div>
  <div class="table-wrap" style="margin-bottom:20px">
    <table>
      <thead><tr><th>Vendor</th><th>Email</th><th>CPI</th><th>Limit</th><th>Status</th><th>Entry Link</th></tr></thead>
      <tbody>
      <?php foreach ($project_vendors as $pv):
        $entry_link = "$base/vendor.php?sid=$sid&vid={$pv['vendor_id']}&uid=[UID]";
      ?>
        <tr>
          <td class="td-main"><?= htmlspecialchars($pv['vendor_name']) ?></td>
          <td><?= htmlspecialchars($pv['email']) ?></td>
          <td>$<?= number_format($pv['cpi'],2) ?></td>
          <td><?= $pv['max_limit'] ?: 'Unlimited' ?></td>
          <td><span class="pill pill-<?= $pv['status']==='active'?'green':'amber' ?>"><?= ucfirst($pv['status']) ?></span></td>
          <td>
            <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
              <button class="btn btn-sm btn-blue" onclick="showEntryLink('<?= htmlspecialchars($pv['vendor_name']) ?>','<?= htmlspecialchars($sid) ?>','<?= htmlspecialchars($entry_link) ?>')">🔗 Entry Link</button>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($project_vendors)): ?>
      <tr><td colspan="6" style="text-align:center;color:var(--text3);padding:24px">No vendors assigned yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Recent Leads -->
  <div class="section-header">
    <div class="section-title" style="margin-bottom:0">Recent Leads</div>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>UID</th><th>Status</th><th>Country</th><th>Device</th><th>LOI</th><th>IP</th><th>Date</th></tr></thead>
      <tbody>
      <?php foreach ($project_leads as $l):
        $scls = ['complete'=>'pill-green','terminate'=>'pill-amber','overquota'=>'pill-blue','quality_fail'=>'pill-red','click'=>'pill-gray','pending'=>'pill-amber'];
      ?>
        <tr>
          <td class="mono">
            <?= htmlspecialchars($l['original_uid'] ?: '—') ?>
            <?php if (!empty($l['encrypted_uid']) && $l['encrypted_uid'] !== $l['original_uid']): ?>
            <div style="font-size:10px;color:var(--text3);margin-top:2px">🔒 <?= htmlspecialchars(substr($l['encrypted_uid'],0,24)) ?>...</div>
            <?php endif; ?>
          </td>
          <td><span class="pill <?= $scls[$l['status']]??'pill-gray' ?>"><?= ucfirst(str_replace('_',' ',$l['status'])) ?></span></td>
          <td><?= htmlspecialchars($l['country'] ?: '—') ?></td>
          <td><?= htmlspecialchars($l['device'] ?: '—') ?></td>
          <td><?= $l['loi_seconds'] ? round($l['loi_seconds']/60,1).'m' : '—' ?></td>
          <td class="mono"><?= htmlspecialchars($l['ip'] ?: '—') ?></td>
          <td><?= $l['created_at'] ? date('d M H:i', strtotime($l['created_at'])) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($project_leads)): ?>
      <tr><td colspan="7" style="text-align:center;color:var(--text3);padding:24px">No leads yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Assign Vendor Modal -->
  <div class="modal-overlay" id="assignVendorModal">
    <div class="modal">
      <button class="modal-close" onclick="document.getElementById('assignVendorModal').classList.remove('open')">×</button>
      <div class="modal-title">Assign Vendor</div>
      <form method="POST">
        <input type="hidden" name="action" value="assign_vendor">
        <input type="hidden" name="project_id" value="<?= $project_view['id'] ?>">
        <div class="form-grid">
          <div class="field span2">
            <label>Select Vendor</label>
            <select name="vendor_id" required>
              <option value="">-- Select --</option>
              <?php foreach ($all_vendors_for_assign as $v): ?>
              <option value="<?= $v['id'] ?>"><?= htmlspecialchars($v['vendor_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field"><label>CPI ($)</label><input type="number" name="cpi" step="0.01" value="<?= $project_view['cpi'] ?>"></div>
          <div class="field"><label>Max Limit</label><input type="number" name="max_limit" value="<?= $project_view['max_completes'] ?>"></div>
        </div>
        <div style="margin-top:16px;display:flex;gap:10px">
          <button type="submit" class="btn btn-primary">Assign</button>
          <button type="button" class="btn btn-ghost" onclick="document.getElementById('assignVendorModal').classList.remove('open')">Cancel</button>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // CLIENTS
  // ════════════════════════════════════════════
  if ($page === 'clients'):
  ?>
  <div class="section-header">
    <div class="section-title">Clients (<?= count($clients) ?>)</div>
    <?php if (rp_is_manager()): ?>
    <button class="btn btn-primary" onclick="openModal('modalClient',{})">+ Add Client</button>
    <?php endif; ?>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Client Name</th><th>Email</th><th>Company</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($clients as $i => $c): ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td class="td-main"><?= htmlspecialchars($c['client_name']) ?></td>
          <td><?= htmlspecialchars($c['email'] ?: '—') ?></td>
          <td><?= htmlspecialchars($c['company'] ?: '—') ?></td>
          <td><span class="pill <?= $c['status']==='active'?'pill-green':'pill-gray' ?>"><?= ucfirst($c['status']) ?></span></td>
          <td>
            <div style="display:flex;gap:6px">
              <?php if (rp_is_manager()): ?>
              <button class="btn btn-sm btn-ghost" onclick='openModal("modalClient",<?= json_encode($c) ?>)'>Edit</button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($clients)): ?>
      <tr><td colspan="6" style="text-align:center;color:var(--text3);padding:32px">No clients yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // VENDORS
  // ════════════════════════════════════════════
  if ($page === 'vendors'):
  ?>
  <div class="section-header">
    <div class="section-title">Vendors (<?= count($vendors) ?>)</div>
    <?php if (rp_is_manager()): ?>
    <button class="btn btn-primary" onclick="openModal('modalVendor',{})">+ Add Vendor</button>
    <?php endif; ?>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Vendor</th><th>Email</th><th>Clicks</th><th>Completes</th><th>Terminates</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($vendors as $i => $v):
        $vc = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=?"); $vc->execute([$v['id']]); $vclk=$vc->fetchColumn();
        $vco= $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=? AND status='complete'"); $vco->execute([$v['id']]); $vcomp=$vco->fetchColumn();
        $vt = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=? AND status='terminate'"); $vt->execute([$v['id']]); $vterm=$vt->fetchColumn();
      ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td class="td-main">
            <a href="?page=vendor_view&id=<?= $v['id'] ?>" style="color:var(--accent);text-decoration:none">
              <?= htmlspecialchars($v['vendor_name']) ?>
            </a>
          </td>
          <td><?= htmlspecialchars($v['email'] ?: '—') ?></td>
          <td><?= $vclk ?></td>
          <td><?= $vcomp ?></td>
          <td><?= $vterm ?></td>
          <td><span class="pill <?= $v['status']==='active'?'pill-green':'pill-gray' ?>"><?= ucfirst($v['status']) ?></span></td>
          <td>
            <div style="display:flex;gap:6px">
              <?php if (rp_is_manager()): ?>
              <button class="btn btn-sm btn-ghost" onclick='openModal("modalVendor",<?= json_encode($v) ?>)'>Edit</button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($vendors)): ?>
      <tr><td colspan="8" style="text-align:center;color:var(--text3);padding:32px">No vendors yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // LEADS
  // ════════════════════════════════════════════
  if ($page === 'leads'):
    $total_pages = ceil($leads_total / 50);
  ?>
  <div class="section-header">
    <div class="section-title">Leads (<?= number_format($leads_total) ?> total)</div>
  </div>

  <form method="GET" style="display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap">
    <input type="hidden" name="page" value="leads">
    <input class="search-input" type="text" name="search" placeholder="Search UID or SID..." value="<?= htmlspecialchars($_GET['search']??'') ?>">
    <select class="search-input" name="status" style="min-width:140px">
      <option value="">All Statuses</option>
      <option value="complete" <?= ($_GET['status']??'')==='complete'?'selected':'' ?>>Complete</option>
      <option value="terminate" <?= ($_GET['status']??'')==='terminate'?'selected':'' ?>>Terminate</option>
      <option value="overquota" <?= ($_GET['status']??'')==='overquota'?'selected':'' ?>>Overquota</option>
      <option value="quality_fail" <?= ($_GET['status']??'')==='quality_fail'?'selected':'' ?>>Quality Fail</option>
      <option value="click" <?= ($_GET['status']??'')==='click'?'selected':'' ?>>Click Only</option>
      <option value="pending" <?= ($_GET['status']??'')==='pending'?'selected':'' ?>>Pending</option>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">Filter</button>
    <a href="?page=leads" class="btn btn-ghost btn-sm">Clear</a>
  </form>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th><th>UID</th><th>Project</th><th>Status</th><th>Country</th><th>Device</th><th>LOI</th><th>IP</th><th>Date</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($leads as $i => $l):
        $scls = ['complete'=>'pill-green','terminate'=>'pill-amber','overquota'=>'pill-blue','quality_fail'=>'pill-red','click'=>'pill-gray','pending'=>'pill-amber'];
        $is_dup = !empty($l['is_duplicate']);
      ?>
        <tr style="<?= $is_dup ? 'background:rgba(239,68,68,0.05)' : '' ?>">
          <td><?= ($lpage-1)*50 + $i + 1 ?></td>
          <td class="mono">
            <?= htmlspecialchars($l['original_uid'] ?: '—') ?>
            <?php if (!empty($l['encrypted_uid']) && $l['encrypted_uid'] !== $l['original_uid']): ?>
            <div style="font-size:10px;color:var(--text3);margin-top:2px">🔒 <?= htmlspecialchars(substr($l['encrypted_uid'],0,24)) ?>...</div>
            <?php endif; ?>
            <?php if ($is_dup): ?>
            <span class="pill pill-red" style="font-size:9px;padding:1px 6px;margin-left:4px">DUP</span>
            <?php endif; ?>
          </td>
          <td>
            <div style="font-size:12px;color:var(--text)"><?= htmlspecialchars($l['project_name'] ?: '—') ?></div>
            <div class="mono" style="color:var(--text3)"><?= htmlspecialchars($l['sid']) ?></div>
          </td>
          <td><span class="pill <?= $scls[$l['status']]??'pill-gray' ?>"><?= ucfirst(str_replace('_',' ',$l['status'])) ?></span></td>
          <td><?= htmlspecialchars($l['country'] ?: '—') ?></td>
          <td><?= htmlspecialchars($l['device'] ?: '—') ?></td>
          <td><?= $l['loi_seconds'] ? round($l['loi_seconds']/60,1).'m' : '—' ?></td>
          <td class="mono"><?= htmlspecialchars(substr($l['ip']??'—',0,15)) ?></td>
          <td><?= $l['created_at'] ? date('d M H:i', strtotime($l['created_at'])) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($leads)): ?>
      <tr><td colspan="9" style="text-align:center;color:var(--text3);padding:32px">No leads found.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php if ($total_pages > 1): ?>
  <div class="pagination">
    <?php for ($p=1; $p<=$total_pages; $p++): ?>
    <a href="?page=leads&lpage=<?= $p ?>&search=<?= urlencode($_GET['search']??'') ?>&status=<?= urlencode($_GET['status']??'') ?>" class="page-btn <?= $p==$lpage?'active':'' ?>"><?= $p ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // VENDOR DETAIL VIEW
  // ════════════════════════════════════════════
  if ($page === 'vendor_view' && $vendor_view):
    $v_clicks    = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=?"); $v_clicks->execute([$vendor_view['id']]); $v_clk=$v_clicks->fetchColumn();
    $v_completes = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=? AND status='complete'"); $v_completes->execute([$vendor_view['id']]); $v_comp=$v_completes->fetchColumn();
    $v_terminates= $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=? AND status='terminate'"); $v_terminates->execute([$vendor_view['id']]); $v_term=$v_terminates->fetchColumn();
  ?>
  <div style="margin-bottom:16px">
    <a href="?page=vendors" class="btn btn-ghost btn-sm">← Back to Vendors</a>
  </div>

  <!-- Stat Cards -->
  <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:20px">
    <div class="stat-card" style="--card-color:#6366f1"><div class="stat-label">Clicks</div><div class="stat-value"><?= $v_clk ?></div></div>
    <div class="stat-card" style="--card-color:#22c55e"><div class="stat-label">Completes</div><div class="stat-value"><?= $v_comp ?></div></div>
    <div class="stat-card" style="--card-color:#f59e0b"><div class="stat-label">Terminates</div><div class="stat-value"><?= $v_term ?></div></div>
  </div>

  <!-- Vendor Info -->
  <div class="info-card" style="margin-bottom:20px">
    <div class="info-card-title">Vendor Info</div>
    <div class="info-row"><span class="info-key">Name</span><span class="info-val"><?= htmlspecialchars($vendor_view['vendor_name']) ?></span></div>
    <div class="info-row"><span class="info-key">Email</span><span class="info-val"><?= htmlspecialchars($vendor_view['email'] ?: '—') ?></span></div>
    <div class="info-row"><span class="info-key">Phone</span><span class="info-val"><?= htmlspecialchars($vendor_view['phone'] ?: '—') ?></span></div>
    <div class="info-row"><span class="info-key">Status</span><span class="info-val"><span class="pill <?= $vendor_view['status']==='active'?'pill-green':'pill-gray' ?>"><?= ucfirst($vendor_view['status']) ?></span></span></div>
    <div class="info-row"><span class="info-key">Conv%</span><span class="info-val" style="color:var(--green);font-weight:600"><?= $v_clk>0 ? round(($v_comp/$v_clk)*100,1).'%' : '—' ?></span></div>
  </div>

  <!-- Assigned Projects with Entry Links -->
  <?php if (!empty($vendor_projects)): ?>
  <div class="section-title" style="margin-bottom:12px">Assigned Projects & Entry Links</div>
  <div class="table-wrap" style="margin-bottom:20px">
    <table>
      <thead><tr><th>Project</th><th>SID</th><th>CPI</th><th>Limit</th><th>Status</th><th>Entry Link</th></tr></thead>
      <tbody>
      <?php foreach ($vendor_projects as $vp):
        $el_folder = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
        $el = (isset($_SERVER['HTTPS'])?'https':'http').'://'.$_SERVER['HTTP_HOST'].$el_folder."/vendor.php?sid={$vp['sid']}&vid={$vendor_view['id']}&uid=[UID]";
      ?>
        <tr>
          <td class="td-main"><?= htmlspecialchars($vp['project_name']) ?></td>
          <td class="mono"><?= htmlspecialchars($vp['sid']) ?></td>
          <td>$<?= number_format($vp['cpi'],2) ?></td>
          <td><?= $vp['max_limit'] ?: 'Unlimited' ?></td>
          <td><span class="pill pill-<?= $vp['status']==='active'?'green':'amber' ?>"><?= ucfirst($vp['status']) ?></span></td>
          <td>
            <button class="btn btn-sm btn-blue" onclick="showEntryLink('<?= htmlspecialchars($vendor_view['vendor_name']) ?>','<?= htmlspecialchars($vp['sid']) ?>','<?= htmlspecialchars($el) ?>')">🔗 Entry Link</button>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <!-- Vendor Leads -->
  <div class="section-header">
    <div class="section-title">Leads (<?= count($vendor_leads) ?>)</div>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>UID</th><th>Project</th><th>Status</th><th>Country</th><th>Device</th><th>LOI</th><th>IP</th><th>Date</th></tr></thead>
      <tbody>
      <?php foreach ($vendor_leads as $l):
        $scls = ['complete'=>'pill-green','terminate'=>'pill-amber','overquota'=>'pill-blue','quality_fail'=>'pill-red','click'=>'pill-gray','pending'=>'pill-amber'];
      ?>
        <tr>
          <td class="mono"><?= htmlspecialchars($l['original_uid'] ?: '—') ?></td>
          <td>
            <div style="font-size:12px"><?= htmlspecialchars($l['project_name'] ?: '—') ?></div>
            <div class="mono" style="color:var(--text3)"><?= htmlspecialchars($l['sid']) ?></div>
          </td>
          <td><span class="pill <?= $scls[$l['status']]??'pill-gray' ?>"><?= ucfirst(str_replace('_',' ',$l['status'])) ?></span></td>
          <td><?= htmlspecialchars($l['country'] ?: '—') ?></td>
          <td><?= htmlspecialchars($l['device'] ?: '—') ?></td>
          <td><?= $l['loi_seconds'] ? round($l['loi_seconds']/60,1).'m' : '—' ?></td>
          <td class="mono"><?= htmlspecialchars(substr($l['ip']??'—',0,15)) ?></td>
          <td><?= $l['created_at'] ? date('d M H:i', strtotime($l['created_at'])) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($vendor_leads)): ?>
      <tr><td colspan="8" style="text-align:center;color:var(--text3);padding:24px">No leads yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
  <?php
  // ════════════════════════════════════════════
  // CHANGE PASSWORD
  // ════════════════════════════════════════════
  if ($page === 'change_password'):
    $cp_err = $_GET['err'] ?? '';
    $cp_msg = $_GET['msg'] ?? '';
  ?>
  <div style="max-width:480px">
    <?php if ($cp_err): ?>
    <div style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);border-radius:8px;padding:10px 16px;font-size:13px;color:#f87171;margin-bottom:16px">⚠ <?= htmlspecialchars($cp_err) ?></div>
    <?php endif; ?>
    <?php if ($cp_msg): ?>
    <div class="flash">✓ <?= htmlspecialchars($cp_msg) ?></div>
    <?php endif; ?>

    <div class="info-card">
      <div class="info-card-title">Change Your Password</div>
      <form method="POST" style="margin-top:16px">
        <input type="hidden" name="action" value="change_password">
        <div class="form-grid full">
          <div class="field">
            <label>Current Password</label>
            <input type="password" name="current_password" required placeholder="••••••••">
          </div>
          <div class="field">
            <label>New Password</label>
            <input type="password" name="new_password" required placeholder="Min 6 characters">
          </div>
          <div class="field">
            <label>Confirm New Password</label>
            <input type="password" name="confirm_password" required placeholder="Repeat new password">
          </div>
        </div>
        <div style="margin-top:16px">
          <button type="submit" class="btn btn-primary">🔑 Update Password</button>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>

  </div><!-- /content -->
</div><!-- /main -->

<!-- Entry Link Modal -->
<div class="modal-overlay" id="entryLinkModal">
  <div class="modal" style="max-width:480px">
    <button class="modal-close" onclick="closeModal('entryLinkModal')">×</button>
    <div class="modal-title">Entry Link</div>
    <div id="entryLinkVendorName" style="font-size:12px;color:var(--text3);margin-bottom:4px"></div>
    <div id="entryLinkProject" style="font-size:12px;color:var(--text3);margin-bottom:16px"></div>
    <div class="url-box">
      <div class="url-val" id="entryLinkUrl"></div>
    </div>
    <button class="btn btn-primary" style="margin-top:12px;width:100%" onclick="copyText(document.getElementById('entryLinkUrl').textContent)">Copy Link</button>
  </div>
</div>

<!-- ── MODALS ── -->

<!-- Project Modal -->
<div class="modal-overlay" id="modalProject">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('modalProject')">×</button>
    <div class="modal-title" id="modalProjectTitle">Add Project</div>
    <form method="POST">
      <input type="hidden" name="action" value="save_project">
      <input type="hidden" name="id" id="proj_id" value="">
      <div class="form-grid">
        <div class="field"><label>Project ID (SID)</label><input type="text" name="sid" id="proj_sid" placeholder="e.g. RP001" required></div>
        <div class="field"><label>Project Name</label><input type="text" name="project_name" id="proj_name" required></div>
        <div class="field"><label>Client</label>
          <select name="client_id" id="proj_client">
            <option value="">-- Select Client --</option>
            <?php foreach ($all_clients as $c): ?>
            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['client_name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field"><label>Status</label>
          <select name="status" id="proj_status">
            <option value="active">Active</option>
            <option value="paused">Paused</option>
            <option value="closed">Closed</option>
          </select>
        </div>
        <div class="field"><label>CPI ($)</label><input type="number" name="cpi" id="proj_cpi" step="0.01" value="0"></div>
        <div class="field"><label>IR (%)</label><input type="number" name="ir" id="proj_ir" step="0.1" value="0"></div>
        <div class="field"><label>LOI (minutes)</label><input type="number" name="loi" id="proj_loi" value="0"></div>
        <div class="field"><label>Max Completes</label><input type="number" name="max_completes" id="proj_max" value="0"></div>
        <div class="field"><label>Project Type</label>
          <select name="project_type" id="proj_type">
            <option value="direct">Direct</option>
            <option value="thirdparty">Third Party</option>
          </select>
        </div>
        <div class="field" style="align-items:center;justify-content:center;flex-direction:row;gap:10px;padding-top:20px">
          <input type="checkbox" name="encrypt_uid" id="proj_enc" value="1" style="width:auto">
          <label for="proj_enc" style="text-transform:none;font-size:13px;color:var(--text2)">Encrypt UID</label>
        </div>
        <div class="field span2"><label>Live Survey URL</label><input type="text" name="live_url" id="proj_live" placeholder="https://..."></div>
        <div class="field span2"><label>Test Survey URL</label><input type="text" name="test_url" id="proj_test" placeholder="https://..."></div>
        <div class="field span2"><label>Description / Study Parameters</label><textarea name="description" id="proj_desc"></textarea></div>
      </div>
      <div style="margin-top:16px;display:flex;gap:10px">
        <button type="submit" class="btn btn-primary">Save Project</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('modalProject')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Client Modal -->
<div class="modal-overlay" id="modalClient">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('modalClient')">×</button>
    <div class="modal-title" id="modalClientTitle">Add Client</div>
    <form method="POST">
      <input type="hidden" name="action" value="save_client">
      <input type="hidden" name="id" id="cl_id" value="">
      <div class="form-grid">
        <div class="field span2"><label>Client Name</label><input type="text" name="client_name" id="cl_name" required></div>
        <div class="field"><label>Email</label><input type="email" name="email" id="cl_email"></div>
        <div class="field"><label>Phone</label><input type="text" name="phone" id="cl_phone"></div>
        <div class="field span2"><label>Company</label><input type="text" name="company" id="cl_company"></div>
        <div class="field"><label>Status</label>
          <select name="status" id="cl_status">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div style="margin-top:16px;display:flex;gap:10px">
        <button type="submit" class="btn btn-primary">Save Client</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('modalClient')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Vendor Modal -->
<div class="modal-overlay" id="modalVendor">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('modalVendor')">×</button>
    <div class="modal-title">Add / Edit Vendor</div>
    <form method="POST">
      <input type="hidden" name="action" value="save_vendor">
      <input type="hidden" name="id" id="vn_id" value="">
      <div class="form-grid">
        <div class="field span2"><label>Vendor Name</label><input type="text" name="vendor_name" id="vn_name" required></div>
        <div class="field"><label>Email</label><input type="email" name="email" id="vn_email"></div>
        <div class="field"><label>Phone</label><input type="text" name="phone" id="vn_phone"></div>
        <div class="field span2"><label>Complete URL</label><input type="text" name="complete_url" id="vn_complete"></div>
        <div class="field span2"><label>Terminate URL</label><input type="text" name="terminate_url" id="vn_terminate"></div>
        <div class="field span2"><label>Screenout URL</label><input type="text" name="screenout_url" id="vn_screenout"></div>
        <div class="field span2"><label>Quotafull URL</label><input type="text" name="quotafull_url" id="vn_quotafull"></div>
        <div class="field"><label>Status</label>
          <select name="status" id="vn_status">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div style="margin-top:16px;display:flex;gap:10px">
        <button type="submit" class="btn btn-primary">Save Vendor</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('modalVendor')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>
// ── Modal helpers ──
function openModal(id, data) {
  document.getElementById(id).classList.add('open');
  if (id === 'modalProject') {
    document.getElementById('modalProjectTitle').textContent = data.id ? 'Edit Project' : 'Add Project';
    document.getElementById('proj_id').value    = data.id || '';
    document.getElementById('proj_sid').value   = data.sid || '';
    document.getElementById('proj_name').value  = data.project_name || '';
    document.getElementById('proj_cpi').value   = data.cpi || '0';
    document.getElementById('proj_ir').value    = data.ir || '0';
    document.getElementById('proj_loi').value   = data.loi || '0';
    document.getElementById('proj_max').value   = data.max_completes || '0';
    document.getElementById('proj_live').value  = data.live_url || '';
    document.getElementById('proj_test').value  = data.test_url || '';
    document.getElementById('proj_desc').value  = data.description || '';
    document.getElementById('proj_enc').checked = data.encrypt_uid == 1;
    if (data.status) document.getElementById('proj_status').value = data.status;
    if (data.project_type) document.getElementById('proj_type').value = data.project_type;
    if (data.client_id) document.getElementById('proj_client').value = data.client_id;
  }
  if (id === 'modalClient') {
    document.getElementById('modalClientTitle').textContent = data.id ? 'Edit Client' : 'Add Client';
    document.getElementById('cl_id').value      = data.id || '';
    document.getElementById('cl_name').value    = data.client_name || '';
    document.getElementById('cl_email').value   = data.email || '';
    document.getElementById('cl_phone').value   = data.phone || '';
    document.getElementById('cl_company').value = data.company || '';
    if (data.status) document.getElementById('cl_status').value = data.status;
  }
  if (id === 'modalVendor') {
    document.getElementById('vn_id').value        = data.id || '';
    document.getElementById('vn_name').value      = data.vendor_name || '';
    document.getElementById('vn_email').value     = data.email || '';
    document.getElementById('vn_phone').value     = data.phone || '';
    document.getElementById('vn_complete').value  = data.complete_url || '';
    document.getElementById('vn_terminate').value = data.terminate_url || '';
    document.getElementById('vn_screenout').value = data.screenout_url || '';
    document.getElementById('vn_quotafull').value = data.quotafull_url || '';
    if (data.status) document.getElementById('vn_status').value = data.status;
  }
}

function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

// Close on overlay click
document.querySelectorAll('.modal-overlay').forEach(el => {
  el.addEventListener('click', e => { if (e.target === el) el.classList.remove('open'); });
});

// ── Entry Link Modal ──
function showEntryLink(vendor, sid, url) {
  document.getElementById('entryLinkVendorName').textContent = vendor;
  document.getElementById('entryLinkProject').textContent = 'Project: ' + sid;
  document.getElementById('entryLinkUrl').textContent = url;
  document.getElementById('entryLinkModal').classList.add('open');
}

// ── Copy helper ──
function copyText(text) {
  navigator.clipboard.writeText(text).then(() => {
    const btn = event.target;
    const orig = btn.textContent;
    btn.textContent = 'Copied!';
    btn.style.background = 'rgba(34,197,94,0.2)';
    btn.style.color = '#22c55e';
    setTimeout(() => { btn.textContent = orig; btn.style.background=''; btn.style.color=''; }, 1500);
  });
}
</script>

</body>
</html>
