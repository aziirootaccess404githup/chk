-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 16, 2026 at 07:41 PM
-- Server version: 11.8.8-MariaDB-log
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u994909610_hub`
--

-- --------------------------------------------------------

--
-- Table structure for table `rp_audit_log`
--

CREATE TABLE `rp_audit_log` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `details` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `rp_audit_log`
--

INSERT INTO `rp_audit_log` (`id`, `user_name`, `action`, `details`, `created_at`) VALUES
(1, 'Super Admin', 'delete_vendor', 'Vendor ID: 4', '2026-07-14 22:22:47'),
(2, 'Super Admin', 'delete_lead', 'Lead ID 22', '2026-07-16 04:54:05'),
(3, 'Super Admin', 'bulk_delete_leads', '1 lead(s): 21', '2026-07-16 04:54:13'),
(4, 'Super Admin', 'delete_project', 'Project ID: 3', '2026-07-16 19:27:07'),
(5, 'Super Admin', 'bulk_delete_leads', '14 lead(s): 33,32,31,30,29,28,27,26,25,24,23,20,19,18', '2026-07-16 19:27:16'),
(6, 'Super Admin', 'delete_client', 'Client ID: 2', '2026-07-16 19:28:04'),
(7, 'Super Admin', 'delete_vendor', 'Vendor ID: 5', '2026-07-16 19:28:11'),
(8, 'Super Admin', 'delete_vendor', 'Vendor ID: 3', '2026-07-16 19:28:14');

-- --------------------------------------------------------

--
-- Table structure for table `rp_clients`
--

CREATE TABLE `rp_clients` (
  `id` int(11) NOT NULL,
  `client_name` varchar(200) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `company` varchar(200) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rp_invoice_status`
--

CREATE TABLE `rp_invoice_status` (
  `project_id` int(11) NOT NULL,
  `status` enum('unpaid','invoiced','paid') NOT NULL DEFAULT 'unpaid',
  `notes` varchar(255) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `rp_invoice_status`
--

INSERT INTO `rp_invoice_status` (`project_id`, `status`, `notes`, `updated_at`) VALUES
(3, 'paid', '', '2026-07-14 22:37:37');

-- --------------------------------------------------------

--
-- Table structure for table `rp_leads`
--

CREATE TABLE `rp_leads` (
  `id` int(11) NOT NULL,
  `sid` varchar(50) DEFAULT NULL,
  `project_name` varchar(200) DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `original_uid` varchar(255) DEFAULT NULL,
  `encrypted_uid` varchar(255) DEFAULT NULL,
  `status` varchar(30) DEFAULT 'click',
  `ip` varchar(60) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `device` varchar(30) DEFAULT NULL,
  `browser` varchar(50) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `loi_seconds` int(11) DEFAULT NULL,
  `is_duplicate` tinyint(1) NOT NULL DEFAULT 0,
  `status_locked` tinyint(1) NOT NULL DEFAULT 0,
  `source` varchar(100) DEFAULT 'direct',
  `entry_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rp_notes`
--

CREATE TABLE `rp_notes` (
  `id` int(11) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `rp_notes`
--

INSERT INTO `rp_notes` (`id`, `title`, `content`, `created_at`, `updated_at`) VALUES
(3, 'REDIRECTs', '1️⃣ Dynamic Redirect URLs (Recommended — Primary)\r\nComplete:     https://panel.azilyticsinsights.com/end.php?status=complete&sid=[SID]&uid=[UID]\r\nTerminate:    https://panel.azilyticsinsights.com/end.php?status=terminate&sid=[SID]&uid=[UID]\r\nOverquota:    https://panel.azilyticsinsights.com/end.php?status=overquota&sid=[SID]&uid=[UID]\r\nQuality Fail: https://panel.azilyticsinsights.com/end.php?status=quality_fail&sid=[SID]&uid=[UID]\r\n\r\n2️⃣ Static Redirect URLs (Backup — agar .html chahiye ho)\r\nComplete:     https://panel.azilyticsinsights.com/pages/complete.html?sid=[SID]&uid=[UID]\r\nTerminate:    https://panel.azilyticsinsights.com/pages/terminate.html?sid=[SID]&uid=[UID]\r\nOverquota:    https://panel.azilyticsinsights.com/pages/overquota.html?sid=[SID]&uid=[UID]\r\nQuality Fail: https://panel.azilyticsinsights.com/pages/quality-fail.html?sid=[SID]&uid=[UID]\r\n(alias quota-full.html bhi available hai agar koi platform us naam se expect kare, overquota jaisa hi content)\r\n\r\n📝 Client Ko Note (Ye Bhi Saath Mein Bhej Do)\r\nNote: [SID] ki jagah apna assigned project code daaliye jo humne confirm \r\nkiya hai. [UID] ki jagah apna respondent-identifier variable daaliye \r\n(jo bhi aapka platform support kare — uid, rid, toid, identifier, ya tid \r\nsab automatically kaam karenge).', '2026-07-16 14:30:29', '2026-07-16 14:30:29');

-- --------------------------------------------------------

--
-- Table structure for table `rp_prescreener_answers`
--

CREATE TABLE `rp_prescreener_answers` (
  `id` int(11) NOT NULL,
  `sid` varchar(50) DEFAULT NULL,
  `original_uid` varchar(255) DEFAULT NULL,
  `encrypted_uid` varchar(255) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `age_group` varchar(20) DEFAULT NULL,
  `education` varchar(50) DEFAULT NULL,
  `income` varchar(50) DEFAULT NULL,
  `device_self` varchar(30) DEFAULT NULL,
  `open_end` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `rp_prescreener_answers`
--

INSERT INTO `rp_prescreener_answers` (`id`, `sid`, `original_uid`, `encrypted_uid`, `gender`, `age_group`, `education`, `income`, `device_self`, `open_end`, `created_at`) VALUES
(1, 'DUMMY01', 'test002', 'test002', 'Female', '45-54', 'Some College', '$25K-$50K', 'Desktop/Laptop', '', '2026-07-09 22:06:34'),
(2, 'DUMMY01', 'test003', 'test003', 'Male', '18-24', 'Some College', '$25K-$50K', 'Desktop/Laptop', 'Hi Adam', '2026-07-09 22:12:29'),
(3, 'SG072608', 'JOhniiee', '39ada9b355', 'Male', '35-44', 'Some College', '$25K-$50K', 'Desktop/Laptop', 'All Good', '2026-07-10 00:03:52'),
(4, 'AZII', 'johnieeps', 'de4087fe78', 'Male', '35-44', 'Some College', '$25K-$50K', 'Desktop/Laptop', 'hi', '2026-07-11 23:44:31');

-- --------------------------------------------------------

--
-- Table structure for table `rp_projects`
--

CREATE TABLE `rp_projects` (
  `id` int(11) NOT NULL,
  `sid` varchar(50) NOT NULL,
  `project_name` varchar(200) NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `client_name` varchar(200) DEFAULT NULL,
  `cpi` decimal(10,2) DEFAULT 0.00,
  `ir` decimal(5,2) DEFAULT 0.00,
  `loi` int(11) DEFAULT 0,
  `max_completes` int(11) DEFAULT 0,
  `live_url` text DEFAULT NULL,
  `test_url` text DEFAULT NULL,
  `status` enum('active','paused','closed') NOT NULL DEFAULT 'active',
  `project_type` enum('direct','thirdparty') NOT NULL DEFAULT 'direct',
  `encrypt_uid` tinyint(1) NOT NULL DEFAULT 1,
  `tp_url` varchar(500) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `supplier_cpi` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
  `color_tag` varchar(20) DEFAULT NULL,
  `internal_notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `rp_projects`
--

INSERT INTO `rp_projects` (`id`, `sid`, `project_name`, `client_id`, `client_name`, `cpi`, `ir`, `loi`, `max_completes`, `live_url`, `test_url`, `status`, `project_type`, `encrypt_uid`, `tp_url`, `description`, `created_at`, `supplier_cpi`, `is_pinned`, `color_tag`, `internal_notes`) VALUES
(4, 'DSSDSA', 'fsfs', NULL, '', 0.00, 0.00, 0, 0, '', '', 'active', 'direct', 0, NULL, '', '2026-07-16 19:29:19', 0.00, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `rp_project_vendors`
--

CREATE TABLE `rp_project_vendors` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `sid` varchar(50) DEFAULT NULL,
  `cpi` decimal(10,2) DEFAULT 0.00,
  `max_limit` int(11) DEFAULT 0,
  `status` enum('active','paused') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rp_settings`
--

CREATE TABLE `rp_settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `rp_settings`
--

INSERT INTO `rp_settings` (`setting_key`, `setting_value`) VALUES
('alert_email', 'shavaz@exazonresearch.com'),
('telegram_bot_token', ''),
('telegram_chat_id', '');

-- --------------------------------------------------------

--
-- Table structure for table `rp_share_links`
--

CREATE TABLE `rp_share_links` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `token` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `rp_share_links`
--

INSERT INTO `rp_share_links` (`id`, `project_id`, `token`, `created_at`) VALUES
(5, 3, 'f4a67e954d283c36ca1da9a0f9dbc1c7', '2026-07-14 22:19:40');

-- --------------------------------------------------------

--
-- Table structure for table `rp_uid_mapping`
--

CREATE TABLE `rp_uid_mapping` (
  `id` int(11) NOT NULL,
  `original_uid` varchar(255) NOT NULL,
  `encrypted_uid` varchar(255) NOT NULL,
  `sid` varchar(50) DEFAULT NULL,
  `source` varchar(50) DEFAULT 'vendor',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `rp_uid_mapping`
--

INSERT INTO `rp_uid_mapping` (`id`, `original_uid`, `encrypted_uid`, `sid`, `source`, `created_at`) VALUES
(1, 'JohnD', '71b797a5fb', 'SG072608', 'vendor', '2026-07-09 23:30:50'),
(2, 'Johndee', 'dace7105d1', 'SG072608', 'vendor', '2026-07-09 23:35:33'),
(3, 'SGDAbc11', '5f33877a3a', 'SG072608', 'vendor', '2026-07-09 23:42:46'),
(4, 'JOhniiee', '39ada9b355', 'SG072608', 'prescreener', '2026-07-10 00:03:52'),
(5, 'Johnathan', 'c9f99b537e', 'AZII', 'vendor', '2026-07-11 23:43:43'),
(6, 'johnieeps', 'de4087fe78', 'AZII', 'prescreener', '2026-07-11 23:44:31'),
(7, 'dsadaas', 'a45fce5ac4', 'AZII', 'vendor', '2026-07-15 17:45:25'),
(8, 'ewertrhfd', '1e9e2e031a', 'AZII', 'vendor', '2026-07-15 17:45:37'),
(9, '444444', '233652b627', 'AZII', 'vendor', '2026-07-15 23:09:34');

-- --------------------------------------------------------

--
-- Table structure for table `rp_users`
--

CREATE TABLE `rp_users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('superadmin','manager','viewer') NOT NULL DEFAULT 'viewer',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `rp_users`
--

INSERT INTO `rp_users` (`id`, `name`, `email`, `password`, `role`, `status`, `created_at`) VALUES
(1, 'Super Admin', 'adam@matrixworldresearch.com', '$2y$10$00pXRqrkv.wCP3DKlBQ0JeYMSKS/4PuG0PBd0x1bAA2BtJnHcJ2dO', 'superadmin', 1, '2026-07-09 21:04:48');

-- --------------------------------------------------------

--
-- Table structure for table `rp_vendors`
--

CREATE TABLE `rp_vendors` (
  `id` int(11) NOT NULL,
  `vendor_name` varchar(200) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `complete_url` varchar(500) DEFAULT NULL,
  `terminate_url` varchar(500) DEFAULT NULL,
  `screenout_url` varchar(500) DEFAULT NULL,
  `quotafull_url` varchar(500) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `end_behavior` enum('show_page','redirect') NOT NULL DEFAULT 'show_page'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `rp_audit_log`
--
ALTER TABLE `rp_audit_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rp_clients`
--
ALTER TABLE `rp_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rp_invoice_status`
--
ALTER TABLE `rp_invoice_status`
  ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `rp_leads`
--
ALTER TABLE `rp_leads`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_sid` (`sid`),
  ADD KEY `idx_uid` (`original_uid`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `rp_notes`
--
ALTER TABLE `rp_notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rp_prescreener_answers`
--
ALTER TABLE `rp_prescreener_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_sid_uid` (`sid`,`original_uid`);

--
-- Indexes for table `rp_projects`
--
ALTER TABLE `rp_projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sid` (`sid`),
  ADD KEY `fk_project_client` (`client_id`);

--
-- Indexes for table `rp_project_vendors`
--
ALTER TABLE `rp_project_vendors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_project_vendor` (`project_id`,`vendor_id`),
  ADD KEY `fk_pv_project` (`project_id`),
  ADD KEY `fk_pv_vendor` (`vendor_id`);

--
-- Indexes for table `rp_settings`
--
ALTER TABLE `rp_settings`
  ADD PRIMARY KEY (`setting_key`);

--
-- Indexes for table `rp_share_links`
--
ALTER TABLE `rp_share_links`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_token` (`token`),
  ADD KEY `idx_project` (`project_id`);

--
-- Indexes for table `rp_uid_mapping`
--
ALTER TABLE `rp_uid_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_enc_uid` (`encrypted_uid`),
  ADD KEY `idx_orig_uid` (`original_uid`);

--
-- Indexes for table `rp_users`
--
ALTER TABLE `rp_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `rp_vendors`
--
ALTER TABLE `rp_vendors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `rp_audit_log`
--
ALTER TABLE `rp_audit_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `rp_clients`
--
ALTER TABLE `rp_clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `rp_leads`
--
ALTER TABLE `rp_leads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `rp_notes`
--
ALTER TABLE `rp_notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `rp_prescreener_answers`
--
ALTER TABLE `rp_prescreener_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `rp_projects`
--
ALTER TABLE `rp_projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `rp_project_vendors`
--
ALTER TABLE `rp_project_vendors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `rp_share_links`
--
ALTER TABLE `rp_share_links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `rp_uid_mapping`
--
ALTER TABLE `rp_uid_mapping`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `rp_users`
--
ALTER TABLE `rp_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `rp_vendors`
--
ALTER TABLE `rp_vendors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rp_projects`
--
ALTER TABLE `rp_projects`
  ADD CONSTRAINT `fk_project_client` FOREIGN KEY (`client_id`) REFERENCES `rp_clients` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `rp_project_vendors`
--
ALTER TABLE `rp_project_vendors`
  ADD CONSTRAINT `fk_pv_project` FOREIGN KEY (`project_id`) REFERENCES `rp_projects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_pv_vendor` FOREIGN KEY (`vendor_id`) REFERENCES `rp_vendors` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
