<?php
// ============================================================
// PanelEngine Survey Panel — vendor.php
// Respondent entry point — tracks click, encrypts UID, redirects to client survey
// URL: /panelengine/vendor.php?sid=RP001&vid=1&uid=[UID]
// ============================================================
require_once __DIR__ . '/config.php';

date_default_timezone_set('Asia/Kolkata');

// ── PARAMETERS ───────────────────────────────────────────────
$sid = trim($_GET['sid'] ?? '');
$uid = trim($_GET['uid'] ?? '');
$vid = (int)($_GET['vid'] ?? 0); // vendor id (optional)

// Basic validation
if (empty($sid) || empty($uid)) {
    die('<h3>Invalid link. Please contact support.</h3>');
}

$db  = rp_db();
$ip  = rp_get_ip();
$ua  = $_SERVER['HTTP_USER_AGENT'] ?? '';
$ref = $_SERVER['HTTP_REFERER']    ?? '';

// ── FETCH PROJECT ─────────────────────────────────────────────
$proj_stmt = $db->prepare("SELECT * FROM rp_projects WHERE sid = ? AND status = 'active' LIMIT 1");
$proj_stmt->execute([$sid]);
$project = $proj_stmt->fetch();

if (!$project) {
    die('
    <!DOCTYPE html><html><head><meta charset="UTF-8">
    <title>Survey Not Available</title>
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0d0f14;color:#e2e8f0;margin:0}
    .box{text-align:center;padding:40px;background:#111318;border-radius:12px;border:1px solid rgba(255,255,255,0.07)}
    h2{color:#f59e0b;margin-bottom:10px}p{color:#94a3b8}</style>
    </head><body><div class="box"><h2>⚠ Survey Not Available</h2><p>This survey is currently not active. Please try again later.</p></div></body></html>
    ');
}

// ── Check vendor assignment status ────────────────────────────
if ($vid) {
    // Global vendor status - pausing a vendor here blocks them across
    // EVERY project at once, without needing to pause each assignment
    // individually. This is separate from (and checked before) the
    // per-project-assignment pause below.
    $vg = $db->prepare("SELECT status FROM rp_vendors WHERE id=? LIMIT 1");
    $vg->execute([$vid]);
    $vendor_global_status = $vg->fetchColumn();
    if ($vendor_global_status === 'inactive') {
        die('
        <!DOCTYPE html><html><head><meta charset="UTF-8">
        <title>Survey Not Available</title>
        <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0d0f14;color:#e2e8f0;margin:0}
        .box{text-align:center;padding:40px;background:#111318;border-radius:12px;border:1px solid rgba(255,255,255,0.07)}
        h2{color:#f59e0b;margin-bottom:10px}p{color:#94a3b8}</style>
        </head><body><div class="box"><h2>⏸ Survey Paused</h2><p>This survey link is currently paused. Please contact your panel manager.</p></div></body></html>
        ');
    }

    $va = $db->prepare("SELECT status FROM rp_project_vendors WHERE project_id=? AND vendor_id=? LIMIT 1");
    $va->execute([$project['id'], $vid]);
    $va_row = $va->fetch();
    if ($va_row && $va_row['status'] === 'paused') {
        die('
        <!DOCTYPE html><html><head><meta charset="UTF-8">
        <title>Survey Not Available</title>
        <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#0d0f14;color:#e2e8f0;margin:0}
        .box{text-align:center;padding:40px;background:#111318;border-radius:12px;border:1px solid rgba(255,255,255,0.07)}
        h2{color:#f59e0b;margin-bottom:10px}p{color:#94a3b8}</style>
        </head><body><div class="box"><h2>⏸ Survey Paused</h2><p>This survey link is currently paused. Please contact your panel manager.</p></div></body></html>
        ');
    }
}

// ── GEO + DEVICE ─────────────────────────────────────────────
$geo    = rp_geo($ip);
$device = rp_device();
$browser= rp_browser();

// ── DUPLICATE CHECK ───────────────────────────────────────────
$dup_stmt = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid = ? AND original_uid = ?");
$dup_stmt->execute([$sid, $uid]);
$is_duplicate = $dup_stmt->fetchColumn() > 0 ? 1 : 0;

// ── ENCRYPT UID ───────────────────────────────────────────────
$encrypted_uid = $uid; // default (raw mode)
if ($project['encrypt_uid']) {
    // Reuse existing token if this UID was already mapped for this project
    $map_check = $db->prepare("SELECT encrypted_uid FROM rp_uid_mapping WHERE original_uid = ? AND sid = ? LIMIT 1");
    $map_check->execute([$uid, $sid]);
    $existing_map = $map_check->fetchColumn();
    if ($existing_map) {
        $encrypted_uid = $existing_map;
    } else {
        $encrypted_uid = rp_encrypt($uid, $sid);
        $db->prepare("INSERT INTO rp_uid_mapping (original_uid, encrypted_uid, sid, source) VALUES (?,?,?,'vendor')")
           ->execute([$uid, $encrypted_uid, $sid]);
    }
}

// ── SAVE LEAD (click) ─────────────────────────────────────────
try {
    $db->prepare("INSERT INTO rp_leads
        (sid, vendor_id, original_uid, encrypted_uid, status, ip, country, city, device, browser, user_agent, is_duplicate, source, entry_time, created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'vendor', NOW(), NOW())")
       ->execute([
           $sid,
           $vid ?: null,
           $uid,
           $encrypted_uid,
           'click',
           $ip,
           $geo['country'],
           $geo['city'],
           $device,
           $browser,
           substr($ua, 0, 500),
           $is_duplicate,
       ]);
    $lead_id = $db->lastInsertId();
} catch (PDOException $e) {
    error_log("PanelEngine vendor.php DB error: " . $e->getMessage());
    $lead_id = 0;
}

// ── BUILD SURVEY URL ─────────────────────────────────────────
$survey_url = $project['live_url'] ?? '';

if (empty($survey_url)) {
    die('<h3>Survey URL not configured. Please contact support.</h3>');
}

// Replace standard placeholders - now supports {{token}}, [TOKEN], {token},
// %TOKEN%, <token>, and $token$ styles (case-insensitive), not just [TOKEN].
// Existing client Live URLs using [UID]/[PID]/[SID]/[VID]/etc keep working
// exactly as before (100% backward compatible) - this only ADDS new bracket
// styles and a few extra real-data tokens (country/city/device/browser)
// that were already being tracked but never offered as placeholders.
$survey_url = rp_build_url($survey_url, [
    'uid' => $encrypted_uid, 'pid' => $encrypted_uid, 'identifier' => $encrypted_uid,
    'rid' => $encrypted_uid, 'tid' => $encrypted_uid, 'toid' => $encrypted_uid,
    'userid' => $encrypted_uid, 'user_id' => $encrypted_uid,
    'respid' => $encrypted_uid, 'resp_id' => $encrypted_uid,
    'respondentid' => $encrypted_uid, 'respondent_id' => $encrypted_uid,
    'panelistid' => $encrypted_uid, 'panelist_id' => $encrypted_uid,
    'participantid' => $encrypted_uid, 'participant_id' => $encrypted_uid,
    'memberid' => $encrypted_uid, 'member_id' => $encrypted_uid,
    'entryid' => $encrypted_uid, 'entry_id' => $encrypted_uid,
    'clickid' => $encrypted_uid, 'subid' => $encrypted_uid,
    'transactionid' => $encrypted_uid, 'transaction_id' => $encrypted_uid,
    'qparm' => $encrypted_uid, 'subject_id' => $encrypted_uid,
    'ext_ref' => $encrypted_uid, 'external_id' => $encrypted_uid,
    'id' => $encrypted_uid, 'ticket' => $encrypted_uid,
    'sid' => $sid, 'studyid' => $sid, 'surveyid' => $sid, 'survey_id' => $sid,
    'projectid' => $sid, 'project_id' => $sid, 'gid' => $sid,
    'vid' => (string)$vid,
    'ip'  => $ip,
    'country' => $geo['country'] ?? '',
    'city'    => $geo['city'] ?? '',
    'device'  => $device,
    'browser' => $browser,
]);

// Decode HTML entities (safety net)
$survey_url = html_entity_decode($survey_url, ENT_QUOTES, 'UTF-8');

// ── REDIRECT ─────────────────────────────────────────────────
header("Location: $survey_url");
exit();
?>
