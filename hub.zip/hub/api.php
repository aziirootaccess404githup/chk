<?php
// ============================================================
// PanelEngine Survey Panel — api.php
// Public JSON API — read-only, token-based (same token as the
// "Client Report Link" feature — one link works for both the
// human-readable report page AND programmatic API access).
//
// Usage:
//   /api.php?token=xxxx                     → project summary
//   /api.php?token=xxxx&action=leads&page=1  → paginated leads list
// ============================================================
require_once __DIR__ . '/config.php';

date_default_timezone_set('Asia/Kolkata');
header('Content-Type: application/json');

$token  = trim($_GET['token']  ?? '');
$action = trim($_GET['action'] ?? 'summary');

$db = rp_db();
rp_ensure_share_table($db);

if (!$token) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing token']);
    exit();
}

$st = $db->prepare("SELECT p.* FROM rp_share_links s JOIN rp_projects p ON s.project_id = p.id WHERE s.token = ? LIMIT 1");
$st->execute([$token]);
$project = $st->fetch();

if (!$project) {
    http_response_code(404);
    echo json_encode(['error' => 'Invalid or revoked token']);
    exit();
}

$sid = $project['sid'];

// ── ACTION: summary (default) ──────────────────────────────────
if ($action === 'summary') {
    $clicks    = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=?"); $clicks->execute([$sid]); $clicks = (int)$clicks->fetchColumn();
    $completes = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=? AND status='complete'"); $completes->execute([$sid]); $completes = (int)$completes->fetchColumn();
    $terminates= $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=? AND status='terminate'"); $terminates->execute([$sid]); $terminates = (int)$terminates->fetchColumn();
    $quota = (int)$project['max_completes'];

    echo json_encode([
        'project_id'    => $sid,
        'project_name'  => $project['project_name'],
        'status'        => $project['status'],
        'clicks'        => $clicks,
        'completes'     => $completes,
        'terminates'    => $terminates,
        'conversion_pct'=> $clicks > 0 ? round(($completes/$clicks)*100, 1) : 0,
        'quota'         => $quota,
        'quota_pct'     => $quota > 0 ? min(100, round(($completes/$quota)*100)) : null,
        'generated_at'  => date('c'),
    ]);
    exit();
}

// ── ACTION: leads (paginated list) ─────────────────────────────
if ($action === 'leads') {
    $page     = max(1, (int)($_GET['page'] ?? 1));
    $per_page = 100; // fixed page size, kept small to avoid heavy exports via API
    $offset   = ($page - 1) * $per_page;

    $total = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=?");
    $total->execute([$sid]);
    $total = (int)$total->fetchColumn();

    $rows = $db->prepare("SELECT status, country, device, loi_seconds, created_at, end_time
                           FROM rp_leads WHERE sid=? ORDER BY id DESC LIMIT $per_page OFFSET $offset");
    $rows->execute([$sid]);
    $rows = $rows->fetchAll();

    // Note: UID and IP are intentionally excluded from the API response for respondent privacy.
    echo json_encode([
        'project_id' => $sid,
        'page'       => $page,
        'per_page'   => $per_page,
        'total'      => $total,
        'total_pages'=> (int)ceil($total / $per_page),
        'leads'      => $rows,
    ]);
    exit();
}

// ── Unknown action ──────────────────────────────────────────────
http_response_code(400);
echo json_encode(['error' => 'Unknown action. Use action=summary or action=leads']);
