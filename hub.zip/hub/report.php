<?php
// ============================================================
// PanelEngine Survey Panel — report.php
// Public, read-only client report — no login required.
// Access via a token generated from Project View → "Client Report Link"
// URL: /report.php?token=xxxxxxxxxxxx
// ============================================================
require_once __DIR__ . '/config.php';

date_default_timezone_set('Asia/Kolkata');

$token = trim($_GET['token'] ?? '');
$db = rp_db();
rp_ensure_share_table($db);

$project = null;
if ($token) {
    $st = $db->prepare("SELECT p.* FROM rp_share_links s JOIN rp_projects p ON s.project_id = p.id WHERE s.token = ? LIMIT 1");
    $st->execute([$token]);
    $project = $st->fetch();
}

if (!$project) {
    http_response_code(404);
    die('
    <!DOCTYPE html><html><head><meta charset="UTF-8"><title>Report Not Found</title>
    <style>body{font-family:"Segoe UI",sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#f4f6fb;color:#0f172a;margin:0}
    .box{text-align:center;padding:40px;background:#fff;border-radius:16px;border:1px solid rgba(15,23,42,0.08);box-shadow:0 4px 24px rgba(15,23,42,0.06)}
    h2{color:#dc2626;margin-bottom:10px}p{color:#64748b}</style>
    </head><body><div class="box"><h2>⚠ Report Not Found</h2><p>This link is invalid or has expired. Please contact your account manager.</p></div></body></html>
    ');
}

$sid = $project['sid'];

// ── Stats (read-only) ──────────────────────────────────────────
$p_clicks    = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=?"); $p_clicks->execute([$sid]); $clicks = $p_clicks->fetchColumn();
$p_completes = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=? AND status='complete'"); $p_completes->execute([$sid]); $completes = $p_completes->fetchColumn();
$p_terminates= $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=? AND status='terminate'"); $p_terminates->execute([$sid]); $terminates = $p_terminates->fetchColumn();
$quota = (int)$project['max_completes'];
$quota_pct = $quota > 0 ? min(100, round(($completes/$quota)*100)) : null;
$conv_pct = $clicks > 0 ? round(($completes/$clicks)*100, 1) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Project Report — <?= htmlspecialchars($project['project_name']) ?></title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{min-height:100vh;background:#f4f6fb;font-family:'Segoe UI',sans-serif;color:#0f172a;padding:32px 20px}
.wrap{max-width:760px;margin:0 auto}
.card{background:#ffffff;border:1px solid rgba(15,23,42,0.08);border-radius:16px;padding:36px 32px;box-shadow:0 4px 24px rgba(15,23,42,0.06);margin-bottom:20px}
h1{font-size:22px;font-weight:700;margin-bottom:4px}
.sub{font-size:13px;color:#64748b;margin-bottom:24px}
.badge{display:inline-flex;align-items:center;gap:6px;border:1px solid;border-radius:6px;padding:4px 12px;font-size:11px;font-weight:600;letter-spacing:1px}
.badge.active{color:#16a34a;border-color:#16a34a;background:rgba(22,163,74,0.1)}
.badge.paused{color:#d97706;border-color:#d97706;background:rgba(217,119,6,0.1)}
.badge.closed{color:#64748b;border-color:#64748b;background:rgba(100,116,139,0.1)}
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:14px;margin-top:20px}
.stat{background:#f8fafc;border:1px solid rgba(15,23,42,0.06);border-radius:10px;padding:16px}
.stat-label{font-size:11px;letter-spacing:1px;color:#94a3b8;text-transform:uppercase;margin-bottom:6px}
.stat-value{font-size:24px;font-weight:700}
.quota-bar{margin-top:8px;background:rgba(15,23,42,0.08);border-radius:4px;height:6px;overflow:hidden}
.quota-fill{height:100%;border-radius:4px}
.footer{text-align:center;font-size:12px;color:#94a3b8;margin-top:8px}
.footer a{color:#2563eb;text-decoration:none}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <span class="badge <?= htmlspecialchars($project['status']) ?>"><?= strtoupper($project['status']) ?></span>
    <h1 style="margin-top:12px"><?= htmlspecialchars($project['project_name']) ?></h1>
    <div class="sub">Project ID: <?= htmlspecialchars($sid) ?></div>

    <div class="stats-grid">
      <div class="stat">
        <div class="stat-label">Total Clicks</div>
        <div class="stat-value"><?= number_format($clicks) ?></div>
      </div>
      <div class="stat">
        <div class="stat-label">Completes</div>
        <div class="stat-value" style="color:#16a34a"><?= number_format($completes) ?></div>
      </div>
      <div class="stat">
        <div class="stat-label">Terminates</div>
        <div class="stat-value" style="color:#d97706"><?= number_format($terminates) ?></div>
      </div>
      <div class="stat">
        <div class="stat-label">Conversion Rate</div>
        <div class="stat-value" style="color:#2563eb"><?= $conv_pct ?>%</div>
      </div>
      <?php if ($quota > 0): ?>
      <div class="stat" style="grid-column:span 2">
        <div class="stat-label">Quota Progress</div>
        <div class="stat-value"><?= $quota_pct ?>%</div>
        <div class="quota-bar"><div class="quota-fill" style="width:<?= $quota_pct ?>%;background:<?= $quota_pct>=100?'#dc2626':($quota_pct>=80?'#d97706':'#2563eb') ?>"></div></div>
        <div style="font-size:11px;color:#94a3b8;margin-top:6px"><?= number_format($completes) ?> / <?= number_format($quota) ?></div>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="footer">
    This is a live, read-only report. Data updates automatically as responses come in.
  </div>
</div>
</body>
</html>
