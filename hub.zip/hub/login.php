<?php
// ============================================================
// PanelEngine Survey Panel — login.php
// ============================================================
require_once __DIR__ . '/config.php';

rp_session_start();

// Already logged in → redirect to dashboard
if (rp_is_logged_in()) {
    header('Location: admin.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($email) || empty($password)) {
        $error = 'Please enter both email and password.';
    } else {
        try {
            $db   = rp_db();
            $stmt = $db->prepare("SELECT * FROM rp_users WHERE email = ? AND status = 1 LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['rp_user_id']    = $user['id'];
                $_SESSION['rp_user_name']  = $user['name'];
                $_SESSION['rp_user_email'] = $user['email'];
                $_SESSION['rp_user_role']  = $user['role'];
                header('Location: admin.php');
                exit();
            } else {
                $error = 'Invalid email or password.';
            }
        } catch (Exception $e) {
            $error = 'Login failed. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — <?= htmlspecialchars(BRAND_NAME) ?> Panel</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Mono&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{
  min-height:100vh;
  background:#0d0f14;
  font-family:'DM Sans',sans-serif;
  display:flex;
  align-items:center;
  justify-content:center;
  color:#e2e8f0;
}

/* ── Background subtle grid ── */
body::before{
  content:'';
  position:fixed;
  inset:0;
  background-image:
    linear-gradient(rgba(99,102,241,0.03) 1px, transparent 1px),
    linear-gradient(90deg, rgba(99,102,241,0.03) 1px, transparent 1px);
  background-size:40px 40px;
  pointer-events:none;
}

.login-wrap{
  width:100%;
  max-width:420px;
  padding:20px;
  position:relative;
  z-index:1;
}

/* ── Logo ── */
.logo{
  text-align:center;
  margin-bottom:36px;
}
.logo-icon{
  width:56px;height:56px;
  background:linear-gradient(135deg,#6366f1,#8b5cf6);
  border-radius:14px;
  display:inline-flex;
  align-items:center;
  justify-content:center;
  font-size:24px;
  font-weight:700;
  color:#fff;
  letter-spacing:-1px;
  margin-bottom:12px;
  box-shadow:0 8px 24px rgba(99,102,241,0.3);
}
.logo-name{
  font-size:22px;
  font-weight:700;
  letter-spacing:2px;
  color:#e2e8f0;
}
.logo-sub{
  font-size:11px;
  letter-spacing:3px;
  color:#475569;
  margin-top:2px;
}

/* ── Card ── */
.card{
  background:#111318;
  border:1px solid rgba(255,255,255,0.07);
  border-radius:16px;
  padding:36px 32px;
  box-shadow:0 24px 48px rgba(0,0,0,0.4);
}

.card-title{
  font-size:18px;
  font-weight:600;
  color:#f1f5f9;
  margin-bottom:6px;
}
.card-sub{
  font-size:13px;
  color:#64748b;
  margin-bottom:28px;
}

/* ── Form ── */
.field{
  margin-bottom:18px;
}
.field label{
  display:block;
  font-size:12px;
  font-weight:600;
  letter-spacing:1px;
  color:#94a3b8;
  margin-bottom:8px;
  text-transform:uppercase;
}
.field input{
  width:100%;
  background:#0d0f14;
  border:1px solid rgba(255,255,255,0.08);
  border-radius:8px;
  padding:12px 14px;
  font-size:14px;
  color:#e2e8f0;
  font-family:'DM Sans',sans-serif;
  transition:border-color .2s;
  outline:none;
}
.field input:focus{
  border-color:#6366f1;
  box-shadow:0 0 0 3px rgba(99,102,241,0.1);
}
.field input::placeholder{color:#334155}

/* ── Error ── */
.error-msg{
  background:rgba(239,68,68,0.1);
  border:1px solid rgba(239,68,68,0.2);
  border-radius:8px;
  padding:10px 14px;
  font-size:13px;
  color:#f87171;
  margin-bottom:18px;
  display:flex;
  align-items:center;
  gap:8px;
}

/* ── Button ── */
.btn-login{
  width:100%;
  background:linear-gradient(135deg,#6366f1,#8b5cf6);
  border:none;
  border-radius:8px;
  padding:13px;
  font-size:14px;
  font-weight:600;
  color:#fff;
  cursor:pointer;
  letter-spacing:0.5px;
  transition:opacity .2s, transform .1s;
  margin-top:6px;
}
.btn-login:hover{opacity:0.9}
.btn-login:active{transform:scale(0.99)}

/* ── Footer ── */
.login-footer{
  text-align:center;
  margin-top:24px;
  font-size:11px;
  color:#1e293b;
  letter-spacing:1px;
}
</style>
</head>
<body>

<div class="login-wrap">

  <!-- Logo -->
  <div class="logo">
    <div class="logo-icon"><?= htmlspecialchars(BRAND_ICON) ?></div>
    <div class="logo-name"><?= htmlspecialchars(BRAND_UPPER) ?></div>
    <div class="logo-sub"><?= htmlspecialchars(BRAND_TAGLINE) ?></div>
  </div>

  <!-- Card -->
  <div class="card">
    <div class="card-title">Welcome back</div>
    <div class="card-sub">Sign in to your admin panel</div>

    <?php if ($error): ?>
    <div class="error-msg">
      <span>⚠</span> <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <form method="POST" action="">
      <div class="field">
        <label>Email Address</label>
        <input
          type="email"
          name="email"
          placeholder="admin@<?= htmlspecialchars(BRAND_DOMAIN) ?>"
          value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
          autocomplete="email"
          required
        >
      </div>
      <div class="field">
        <label>Password</label>
        <input
          type="password"
          name="password"
          placeholder="••••••••"
          autocomplete="current-password"
          required
        >
      </div>
      <button type="submit" class="btn-login">Sign In →</button>
    </form>
  </div>

  <div class="login-footer">© <?= date('Y') ?> <?= htmlspecialchars(BRAND_UPPER) ?> <?= htmlspecialchars(BRAND_TAGLINE) ?></div>
</div>

</body>
</html>
