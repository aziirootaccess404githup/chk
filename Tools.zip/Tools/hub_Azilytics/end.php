<?php
// ============================================================
// PanelEngine Survey Panel — end.php
// Status landing page: complete / terminate / overquota / quality_fail
// URL: /panelengine/end.php?status=complete&sid=RP001&uid=ENCRYPTED_UID
//
// IMPORTANT: The "sid" in the incoming URL is only a starting hint.
// The REAL/internal project SID is always resolved from OUR OWN
// database (via the lead that was created when the respondent first
// clicked in) and is what gets displayed, tracked, and used for
// quota/postback/alerts — never whatever text a client's system
// happens to send back. This keeps our internal SID authoritative
// even if a client sets their own value in the sid parameter.
// ============================================================
require_once __DIR__ . '/config.php';

date_default_timezone_set('Asia/Kolkata');

// ── OPTIONAL SIGNATURE CHECK (informational only) ──────────────
// Same as track.php — logs a mismatch for review, never blocks.
if (!empty($_GET['sig'])) {
    $rp_sig_secret = 'exazon-panelengine-signature-secret';
    $rp_expected_sig = hash_hmac('sha256', ($_GET['status'] ?? '') . '|' . ($_GET['sid'] ?? '') . '|' . ($_GET['uid'] ?? ''), $rp_sig_secret);
    if (!hash_equals($rp_expected_sig, $_GET['sig'])) {
        error_log("PanelEngine end.php: signature mismatch — sid=" . ($_GET['sid'] ?? '') . " uid=" . ($_GET['uid'] ?? ''));
    }
}

// Flexible param-name fallback for status - different client survey platforms
// may send this back under a different name. Purely additive; "status" still
// works exactly as before for every existing client already using it.
$status      = trim($_GET['status'] ?? $_GET['disposition'] ?? $_GET['outcome'] ?? $_GET['result'] ?? '');

// ── Flexible incoming project-id parameter detection ────────────────
// Different client survey platforms send their project reference under
// different parameter names - priority-order fallback, first non-empty wins.
$incoming_project_id = trim(
    $_GET['sid'] ?? $_GET['pid'] ?? $_GET['gid'] ?? $_GET['cid']
    ?? $_GET['projectid'] ?? $_GET['project_id'] ?? $_GET['surveyid'] ?? $_GET['survey_id'] ?? ''
);

$db = rp_db();
// Ensure genuinely NEW columns exist regardless of which branch below
// runs — the ghost-insert branch has its own ensure too (belt-and-
// braces), but Overview-stats, Vendor-Scorecard, and other pages
// genuinely query these columns assuming they exist, so this can't
// only be lazily created deep inside one specific code-path.
try {
    $db->exec("ALTER TABLE rp_leads ADD COLUMN no_entry_record TINYINT(1) DEFAULT 0");
    $db->exec("ALTER TABLE rp_leads ADD COLUMN is_duplicate TINYINT(1) DEFAULT 0");
} catch (PDOException $e) {}

// Resolve the client's own reference into our internal sid (via mapping
// table) if needed - see rp_resolve_project_id() in config.php. This is
// only a starting hint; see note below, the rest of this file's existing
// uid-authority logic is completely unaffected by this change.
$url_sid = $incoming_project_id !== '' ? rp_resolve_project_id($db, $incoming_project_id) : '';

// IMPORTANT: The "sid" resolved above (from whichever parameter name the
// client used, translated through the mapping table if needed) is still
// only a starting hint. The REAL/internal project SID is always resolved
// from OUR OWN database (via the lead that was created when the respondent
// first clicked in) and is what gets displayed, tracked, and used for
// quota/postback/alerts — never whatever a client's system sends back.
// This keeps our internal SID authoritative even if a client sets their
// own value, under whatever parameter name, or no mapping exists yet.

// Flexible param-name fallback — some clients' systems send the identifier
// back under a different name (rid, toid, identifier, tid) instead of uid.
// This is purely a safety-net; nothing else changes.
$enc_uid = trim($_GET['uid'] ?? $_GET['rid'] ?? $_GET['toid'] ?? $_GET['identifier'] ?? $_GET['tid'] ?? $_GET['pid'] ?? '');

// ── Status recognition ──────────────────────────────────────────
// Exact names we already support, plus common alternate spellings a
// client's platform might send instead (all map to the SAME 4 real
// outcomes - nothing new is introduced here, just recognized synonyms).
$status_aliases = [
    'complete'      => 'complete',      'success'   => 'complete',   'completed' => 'complete',
    'terminate'     => 'terminate',     'terminated'=> 'terminate',  'term'      => 'terminate',
    'overquota'     => 'overquota',     'quotafull' => 'overquota',  'quota_full'=> 'overquota', 'full' => 'overquota',
    'quality_fail'  => 'quality_fail',  'qc'        => 'quality_fail','quality'  => 'quality_fail',
    'screenout'     => 'quality_fail',  'screened_out' => 'quality_fail', 'disqualified' => 'quality_fail',
];
$status_key = strtolower($status);
$status = $status_aliases[$status_key] ?? null;

// ── STATUS SYNONYM MAPPING FALLBACK ─────────────────────────────
// Same fallback as track.php — check the configurable synonym table
// (per-project overrides + seeded industry-common defaults) before
// giving up and calling it unmatched.
if ($status === null) {
    $synonym_map = ['complete' => 'complete', 'terminate' => 'terminate', 'overquota' => 'overquota', 'quality_fail' => 'quality_fail'];
    $syn_result = rp_resolve_status_synonym($db, $status_key, $url_sid ?: null);
    if ($syn_result !== null && isset($synonym_map[$syn_result])) {
        $status = $synonym_map[$syn_result];
    }
}

// IMPORTANT: if the incoming status is missing or doesn't match anything we
// recognize (e.g. a client only configured 3 of the 4 possible redirect
// URLs, or is sending a status name we don't know), we do NOT guess and
// default to 'complete' - that would silently mark an unknown outcome as
// a successful completion. Instead we treat it as unmatched below: no lead
// status gets changed, no vendor postback fires, and the respondent sees a
// neutral "under review" page instead of a false completion confirmation.
$is_unmatched_status = ($status === null);
if ($is_unmatched_status) $status = 'unmatched';

$original_uid = '';
$project_name = '';
$sid = $url_sid; // may be corrected below once we find the real lead

// ── Fetch project (using the URL hint first, for decryption purposes) ──
$proj = null;
if ($sid) {
    $ps = $db->prepare("SELECT * FROM rp_projects WHERE sid = ? LIMIT 1");
    $ps->execute([$sid]);
    $proj = $ps->fetch();
    if ($proj) $project_name = $proj['project_name'];
}

// ── Decrypt UID ───────────────────────────────────────────────
if ($enc_uid && $sid) {
    if ($proj && empty($proj['encrypt_uid'])) {
        // Raw mode — uid is already original
        $original_uid = $enc_uid;
    } else {
        $original_uid = rp_decrypt($enc_uid, $sid) ?? '';
        // Fallback: check mapping table (sid-scoped first)
        if (!$original_uid) {
            $mr = $db->prepare("SELECT original_uid FROM rp_uid_mapping WHERE encrypted_uid = ? AND sid = ? LIMIT 1");
            $mr->execute([$enc_uid, $sid]);
            $mrow = $mr->fetch();
            if ($mrow) $original_uid = $mrow['original_uid'];
        }
        // Further fallback: mapping table WITHOUT sid filter — covers the case
        // where the client sent a different/wrong sid than what we used originally
        // (encryption key is sid-dependent, so a mismatched sid breaks decryption above).
        if (!$original_uid) {
            $mr2 = $db->prepare("SELECT original_uid, sid FROM rp_uid_mapping WHERE encrypted_uid = ? ORDER BY id DESC LIMIT 1");
            $mr2->execute([$enc_uid]);
            $mrow2 = $mr2->fetch();
            if ($mrow2) {
                $original_uid = $mrow2['original_uid'];
                $sid = $mrow2['sid']; // correct the sid to our real internal one
            }
        }
    }
}

// ── Update lead status (with status-lock) ────────────────────
$deferred_vendor_id = null;
$is_ghost_entry = false;
$deferred_actual_seconds = null;
if ($enc_uid) {
    $lookup_uid = $original_uid ?: $enc_uid;

    // Try by original_uid + sid (normal case — client sent the correct sid)
    $lc = $db->prepare("SELECT id, sid, status, status_locked, vendor_id FROM rp_leads WHERE original_uid = ? AND sid = ? ORDER BY id DESC LIMIT 1");
    $lc->execute([$lookup_uid, $sid]);
    $lead = $lc->fetch();

    if (!$lead) {
        // Fallback: try by encrypted_uid + sid
        $lc2 = $db->prepare("SELECT id, sid, status, status_locked, vendor_id FROM rp_leads WHERE encrypted_uid = ? AND sid = ? ORDER BY id DESC LIMIT 1");
        $lc2->execute([$enc_uid, $sid]);
        $lead = $lc2->fetch();
    }

    if (!$lead) {
        // Further fallback: same UID, ANY project — covers a client sending a
        // sid that doesn't match what we have on file. Our own stored sid
        // (from when the respondent first clicked in) always wins.
        $lc3 = $db->prepare("SELECT id, sid, status, status_locked, vendor_id FROM rp_leads WHERE original_uid = ? OR encrypted_uid = ? ORDER BY id DESC LIMIT 1");
        $lc3->execute([$lookup_uid, $enc_uid]);
        $lead = $lc3->fetch();
    }

    // If we found a lead, its stored sid is the ONLY authoritative sid from here on.
    if ($lead) {
        $sid = $lead['sid'];
        if (!$proj || $proj['sid'] !== $sid) {
            $ps2 = $db->prepare("SELECT * FROM rp_projects WHERE sid = ? LIMIT 1");
            $ps2->execute([$sid]);
            $proj = $ps2->fetch();
            $project_name = $proj ? $proj['project_name'] : $project_name;
        }
    }

    // ── GHOST-ENTRY CHECK (ported from ExaVerify's pages/track.php) ──
    // No existing lead was found at all for this respondent — meaning
    // they never genuinely went through vendor.php's own entry-link
    // first (a copied/replayed completion-URL, manual test, a client's
    // own system redirecting straight here without ever hitting a real
    // entry-step). Still SAVE it (fully auditable — nothing silently
    // lost), but flag it via no_entry_record so it never gets silently
    // counted as a genuine, trustworthy completion — excluded from
    // quota-counts and never fires a vendor postback, same principle
    // as the unmatched-status handling just above.
    if (!$lead) {
        try { $db->exec("ALTER TABLE rp_leads ADD COLUMN no_entry_record TINYINT(1) DEFAULT 0"); } catch (PDOException $e) {}

        $ip_new  = rp_get_ip();
        $ua_new  = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $geo_new = rp_geo($ip_new);
        $dev_new = rp_device();
        $br_new  = rp_browser();

        // Unmatched status: insert but leave UNLOCKED (status_locked=0) so a
        // later genuine status hit for this same respondent can still update
        // it normally - we don't want an unrecognized first hit to permanently
        // block a real outcome from ever being recorded.
        $lock_new = $is_unmatched_status ? 0 : 1;
        $ins = $db->prepare("INSERT INTO rp_leads (sid, original_uid, encrypted_uid, status, ip, country, city, device, browser, user_agent, loi_seconds, is_duplicate, status_locked, no_entry_record, source, entry_time, end_time, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,NULL,0,?,1,'direct',NOW(),NOW(),NOW())");
        $ins->execute([$sid, $lookup_uid, $enc_uid, $status, $ip_new, $geo_new['country'], $geo_new['city'], $dev_new, $br_new, substr($ua_new, 0, 500), $lock_new]);
        $new_lead_id = (int)$db->lastInsertId();

        // Genuinely no quota-check and no vendor postback for a ghost entry
        // — never counted as a real completion.
        rp_send_telegram_alert("👻 Ghost Entry Detected!\nProject: $sid\nUID: $lookup_uid\nStatus: $status | IP: $ip_new\nThis completion has NO matching entry-click on record — recorded but excluded from stats/postback/quota.");

        // Re-fetch as $lead so the rest of the existing logic below (redirect-mode
        // vendor check, etc.) keeps working exactly as it does for updates —
        // is_ghost_entry additionally guards those against firing for this lead.
        $lead = ['id' => $new_lead_id, 'sid' => $sid, 'status' => $status, 'status_locked' => $lock_new, 'vendor_id' => null];
        $is_ghost_entry = true;
    }

    if ($lead) {
        $is_fresh_update = empty($lead['status_locked']);
        if (!$is_fresh_update && empty($is_ghost_entry)) {
            // Status already locked — use locked status
            $status = $lead['status'];

            // ── DUPLICATE-ON-LOCKED-LEAD DETECTION ──────────────────
            // A repeat hit here is genuinely useful fraud signal (a
            // vendor/bot resubmitting, or a respondent trying again) —
            // must not be silently invisible just because the lead is
            // locked and no further status-write happens. Flag
            // is_duplicate and fire an alert, but only the FIRST time a
            // repeat is seen for this lead (checked via is_duplicate not
            // already being true) — so a client/vendor repeatedly hitting
            // the same completion URL doesn't spam one alert per hit.
            // Explicitly excludes a freshly-created ghost-entry lead from
            // THIS SAME request (which is also "locked" from the moment
            // it's inserted, but is genuinely the FIRST time this UID has
            // ever been seen — not a real repeat).
            try {
                $db->exec("ALTER TABLE rp_leads ADD COLUMN is_duplicate TINYINT(1) DEFAULT 0");
            } catch (PDOException $e) {}
            $dupChk = $db->prepare("SELECT is_duplicate FROM rp_leads WHERE id=?");
            $dupChk->execute([$lead['id']]);
            if (!$dupChk->fetchColumn()) {
                $db->prepare("UPDATE rp_leads SET is_duplicate=1 WHERE id=?")->execute([$lead['id']]);
                rp_send_telegram_alert("⚠️ Duplicate UID! (repeat hit on an already-locked lead)\nProject: $sid\nUID: " . ($original_uid ?: $enc_uid) . "\nStatus: $status\nThe same respondent attempted again after their result was already locked in!");
            }
        } elseif (!$is_fresh_update) {
            // Already-locked, but genuinely just from THIS request's own
            // ghost-insert — use its status, no duplicate-alert (see above).
            $status = $lead['status'];
        } elseif ($is_unmatched_status) {
            // Unmatched status on a fresh (not-yet-locked) lead: leave it
            // completely untouched - don't overwrite its current status and
            // don't lock it, so a later genuine status hit can still finalize
            // it correctly. We just don't know the real outcome right now.
        } else {
            // Update status + lock it
            $db->prepare("UPDATE rp_leads SET status = ?, end_time = NOW(), loi_seconds = TIMESTAMPDIFF(SECOND, entry_time, NOW()), status_locked = 1 WHERE id = ?")
               ->execute([$status, $lead['id']]);
            if ($status === 'complete' || $status === 'terminate') {
                rp_check_ir_drift($db, $sid);
            }
            if ($status === 'complete') {
                rp_check_quota($db, $sid);
            }
        }

        // Actual time-taken, needed for [LOI] placeholder / speeder check
        $lead_loi_seconds = null;
        if ($status === 'complete') {
            $lr = $db->prepare("SELECT loi_seconds FROM rp_leads WHERE id=?");
            $lr->execute([$lead['id']]);
            $lead_loi_seconds = $lr->fetchColumn();
        }

        // Vendor postback/redirect only fires for a status we actually
        // recognize - we don't want to tell a vendor's system any outcome
        // when we genuinely don't know what happened.
        if (!$is_unmatched_status) {
            // Redirect-mode vendors: send the respondent straight to the vendor's
            // own page instead of ours (works whether this is a fresh update or a re-visit).
            $vendor_redirect_url = rp_build_vendor_redirect_url($db, $lead['vendor_id'], $status, $original_uid ?: $enc_uid, $sid, $lead_loi_seconds);
            if ($vendor_redirect_url) {
                header("Location: $vendor_redirect_url");
                exit();
            }

            // Defer slow network calls (vendor postback, Telegram alert) until
            // AFTER the respondent's page has been sent — so a slow/down vendor
            // server never delays what the respondent sees. Skip if track.php
            // already notified the vendor for this same request (avoids a duplicate ping).
            if ($is_fresh_update && empty($_GET['_notified'])) {
                $deferred_vendor_id = $lead['vendor_id'];
                if ($status === 'complete') {
                    $deferred_actual_seconds = $lead_loi_seconds;
                }
            }
        }
    }
}

$ip   = rp_get_ip();
$time = date('d/m/Y, H:i:s');

// ── Status config ────────────────────────────────────────────
$config = [
    'complete' => [
        'badge'    => 'SURVEY COMPLETED SUCCESSFULLY',
        'badge_c'  => '#22c55e',
        'badge_bg' => 'rgba(34,197,94,0.12)',
        'icon'     => '✓',
        'title'    => 'THANK YOU FOR YOUR<br>PARTICIPATION',
        'title_c'  => '#4ade80',
        'msg'      => 'Your response has been recorded and verified. This record confirms your successful survey completion.',
        'label'    => 'COMPLETE',
        'label_c'  => '#22c55e',
        'label_bg' => 'rgba(34,197,94,0.12)',
        'dot_c'    => '#22c55e',
    ],
    'terminate' => [
        'badge'    => 'SURVEY TERMINATED',
        'badge_c'  => '#f59e0b',
        'badge_bg' => 'rgba(245,158,11,0.12)',
        'icon'     => '⚠',
        'title'    => 'THANK YOU FOR<br>YOUR TIME',
        'title_c'  => '#fbbf24',
        'msg'      => 'Unfortunately, you did not qualify for this survey. Your participation is appreciated.',
        'label'    => 'TERMINATE',
        'label_c'  => '#f59e0b',
        'label_bg' => 'rgba(245,158,11,0.12)',
        'dot_c'    => '#f59e0b',
    ],
    'overquota' => [
        'badge'    => 'SURVEY QUOTA FULL',
        'badge_c'  => '#3b82f6',
        'badge_bg' => 'rgba(59,130,246,0.12)',
        'icon'     => '●',
        'title'    => 'THIS SURVEY IS<br>NOW FULL',
        'title_c'  => '#60a5fa',
        'msg'      => 'We have reached our required number of responses. Thank you for your interest.',
        'label'    => 'OVERQUOTA',
        'label_c'  => '#3b82f6',
        'label_bg' => 'rgba(59,130,246,0.12)',
        'dot_c'    => '#3b82f6',
    ],
    'quality_fail' => [
        'badge'    => 'QUALITY CHECK FAILED',
        'badge_c'  => '#ef4444',
        'badge_bg' => 'rgba(239,68,68,0.12)',
        'icon'     => '✕',
        'title'    => 'ACCESS DENIED',
        'title_c'  => '#f87171',
        'msg'      => 'Your session did not pass our quality verification checks. Please ensure honest responses.',
        'label'    => 'QUALITY FAIL',
        'label_c'  => '#ef4444',
        'label_bg' => 'rgba(239,68,68,0.12)',
        'dot_c'    => '#ef4444',
    ],
    'unmatched' => [
        // Shown when the incoming status is missing or not one we recognize.
        // Deliberately neutral - does not claim complete/terminate/etc, since
        // we genuinely don't know the real outcome in this case.
        'badge'    => 'RESPONSE RECEIVED',
        'badge_c'  => '#94a3b8',
        'badge_bg' => 'rgba(148,163,184,0.12)',
        'icon'     => '⏳',
        'title'    => 'THANK YOU',
        'title_c'  => '#cbd5e1',
        'msg'      => 'Your response has been received and is currently under review. If you believe there was an issue, please contact the panel provider.',
        'label'    => 'UNDER REVIEW',
        'label_c'  => '#94a3b8',
        'label_bg' => 'rgba(148,163,184,0.12)',
        'dot_c'    => '#94a3b8',
    ],
];
$c = $config[$status] ?? $config['complete'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="referrer" content="no-referrer">
<title><?= htmlspecialchars($c['badge']) ?> — <?= htmlspecialchars(BRAND_NAME) ?></title>
<link rel="icon" type="image/webp" href="logo.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500,600;1,400&family=Outfit:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --cream:#f5f0e8;
  --cream2:#ede7d9;
  --ink:#1a1a1a;
  --ink2:#2c2c2c;
  --ink3:#555;
  --ink4:#888;
  --gold:#c9a84c;
  --gold2:#b8963e;
  --border:#d4c9b0;
}
body{
  min-height:100vh;
  background:var(--cream);
  font-family:'Outfit',sans-serif;
  color:var(--ink);
  display:flex;
  flex-direction:column;
}

/* NAV */
nav{
  background:var(--ink);
  padding:14px 40px;
  display:flex;
  align-items:center;
  justify-content:space-between;
}
.nav-logo{display:flex;align-items:center;gap:14px;text-decoration:none}
.nav-logo img{height:38px;width:auto}
.nav-logo-text{
  font-family:'Cormorant Garamond',serif;
  font-size:20px;
  font-weight:600;
  color:var(--cream);
  letter-spacing:2px;
}
.nav-logo-sub{
  font-family:'Outfit',sans-serif;
  font-size:9px;
  letter-spacing:3px;
  color:var(--gold);
  margin-top:1px;
  text-transform:uppercase;
}
.nav-links{display:flex;gap:28px}
.nav-links a{
  color:rgba(245,240,232,0.65);
  text-decoration:none;
  font-size:12px;
  letter-spacing:1.5px;
  text-transform:uppercase;
  transition:.2s;
}
.nav-links a:hover{color:var(--gold)}
.nav-live{
  display:flex;align-items:center;gap:7px;
  font-size:10px;letter-spacing:2px;
  color:var(--gold);
  text-transform:uppercase;
}
.nav-dot{
  width:7px;height:7px;border-radius:50%;
  background:var(--gold);
  animation:pulse 2s infinite;
}

/* MAIN */
main{flex:1;display:flex;align-items:center;justify-content:center;padding:48px 20px}
.card{
  background:#fff;
  border:1px solid var(--border);
  border-radius:4px;
  padding:52px 44px;
  max-width:700px;width:100%;
  text-align:center;
  box-shadow:0 2px 24px rgba(26,26,26,0.06);
}

/* Status badge */
.status-badge{
  display:inline-flex;align-items:center;gap:9px;
  border:1px solid;border-radius:2px;
  padding:7px 20px;
  font-size:10px;font-weight:600;
  letter-spacing:3px;
  margin-bottom:30px;
  text-transform:uppercase;
  border-color:<?= $c['badge_c'] ?>;
  color:<?= $c['badge_c'] ?>;
  background:<?= $c['badge_bg'] ?>;
}

.main-title{
  font-family:'Cormorant Garamond',serif;
  font-size:clamp(28px,5vw,44px);
  font-weight:500;
  letter-spacing:1px;
  line-height:1.25;
  color:var(--ink);
  margin-bottom:14px;
}
.main-msg{
  color:var(--ink4);
  font-size:14px;
  line-height:1.8;
  max-width:500px;
  margin:0 auto 36px;
  font-weight:300;
}

/* Divider */
.divider{
  width:60px;height:1px;
  background:var(--gold);
  margin:0 auto 36px;
  opacity:.5;
}

/* Record card */
.record{
  background:var(--cream);
  border:1px solid var(--border);
  border-radius:3px;
  overflow:hidden;
  text-align:left;
  margin-bottom:28px;
}
.record-head{
  display:flex;align-items:center;justify-content:space-between;
  padding:10px 20px;
  border-bottom:1px solid var(--border);
  background:var(--cream2);
}
.record-title{
  display:flex;align-items:center;gap:8px;
  font-size:9px;font-weight:600;
  letter-spacing:3px;
  text-transform:uppercase;
  color:var(--gold2);
}
.record-dot{
  width:6px;height:6px;border-radius:50%;
  background:var(--gold);
  animation:pulse 2s infinite;
}
.record-time{font-size:11px;color:var(--ink4);font-family:'Outfit',sans-serif}

.record-table{width:100%;border-collapse:collapse}
.record-table th{
  padding:10px 20px;
  font-size:9px;letter-spacing:2px;
  color:var(--ink4);font-weight:600;
  text-align:left;
  text-transform:uppercase;
  border-bottom:1px solid var(--border);
  background:rgba(197,175,130,0.08);
}
.record-table td{
  padding:15px 20px;font-size:13px;
  border-bottom:1px solid rgba(212,201,176,0.4);
  color:var(--ink2);
}
.record-table tr:last-child td{border-bottom:none}
.uid-val{font-family:'Outfit',monospace;font-size:12px;color:var(--ink);font-weight:500}
.status-pill{
  display:inline-flex;align-items:center;gap:5px;
  border:1px solid;border-radius:2px;
  padding:3px 12px;
  font-size:10px;font-weight:600;
  letter-spacing:2px;
  text-transform:uppercase;
  border-color:<?= $c['label_c'] ?>;
  color:<?= $c['label_c'] ?>;
  background:<?= $c['label_bg'] ?>;
}
.ip-val{font-family:'Outfit',monospace;font-size:11px;color:var(--ink4)}
.sid-val{font-size:12px;color:var(--gold2);font-weight:500;letter-spacing:1px}

.footnote{
  font-size:11px;
  color:var(--ink4);
  line-height:1.7;
  font-weight:300;
  letter-spacing:.3px;
}

/* FOOTER */
footer{
  background:var(--ink);
  border-top:1px solid rgba(255,255,255,0.06);
  padding:28px 40px;
}
.footer-inner{
  max-width:1200px;margin:0 auto;
  display:flex;align-items:center;justify-content:space-between;
  flex-wrap:wrap;gap:16px;
}
.footer-logo{display:flex;align-items:center;gap:10px}
.footer-logo img{height:26px;width:auto;opacity:.7}
.footer-logo-text{
  font-family:'Cormorant Garamond',serif;
  font-size:13px;letter-spacing:2px;
  color:rgba(245,240,232,0.45);
}
.footer-tagline{
  font-size:9px;letter-spacing:2px;
  color:rgba(201,168,76,0.5);
  text-transform:uppercase;
  margin-top:2px;
}
.footer-links{display:flex;gap:20px}
.footer-links a{
  color:rgba(245,240,232,0.35);
  text-decoration:none;
  font-size:11px;letter-spacing:1px;
  transition:.2s;
}
.footer-links a:hover{color:var(--gold)}
.footer-brand{font-size:9px;color:rgba(255,255,255,0.15);letter-spacing:2px}

@keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}

@media(max-width:600px){
  nav{padding:12px 20px}
  .nav-links{display:none}
  .card{padding:36px 20px}
  .record-table th,.record-table td{padding:10px 14px}
  footer{padding:20px}
  .footer-inner{flex-direction:column;align-items:flex-start}
}
</style>
</head>
<body>

<!-- NAV -->
<nav>
  <a href="<?= htmlspecialchars(BRAND_URL) ?>" class="nav-logo">
    <img src="logo.png" alt="<?= htmlspecialchars(BRAND_NAME) ?>">
    <div>
      <div class="nav-logo-text"><?= htmlspecialchars(BRAND_UPPER) ?></div>
      <div class="nav-logo-sub"><?= htmlspecialchars(BRAND_NAV_TAGLINE) ?></div>
    </div>
  </a>
  <div class="nav-links">
    <a href="<?= htmlspecialchars(BRAND_URL) ?>">Home</a>
    <a href="<?= htmlspecialchars(BRAND_URL) ?>/faqs.html">FAQ</a>
    <a href="<?= htmlspecialchars(BRAND_URL) ?>/join-our-panel.html">Join Panel</a>
  </div>
  <div class="nav-live">
    <div class="nav-dot"></div>
    Live
  </div>
</nav>

<!-- MAIN -->
<main>
  <div class="card">

    <div class="status-badge">
      <span><?= $c['icon'] ?></span>
      <?= htmlspecialchars($c['badge']) ?>
    </div>

    <div class="main-title"><?= $c['title'] ?></div>
    <div class="divider"></div>
    <div class="main-msg"><?= htmlspecialchars($c['msg']) ?></div>

    <div class="record">
      <div class="record-head">
        <div class="record-title">
          <div class="record-dot"></div>
          Completion Record
        </div>
        <div class="record-time"><?= $time ?></div>
      </div>
      <table class="record-table">
        <thead>
          <tr>
            <th>Project ID</th>
            <th>Respondent ID</th>
            <th>Status</th>
            <th>IP Address</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="sid-val"><?= htmlspecialchars($sid ?: '—') ?></td>
            <td class="uid-val"><?= htmlspecialchars($original_uid ?: ($enc_uid ?: '—')) ?></td>
            <td>
              <span class="status-pill">
                ● <?= htmlspecialchars(strtoupper(str_replace('_',' ',$status))) ?>
              </span>
            </td>
            <td class="ip-val"><?= htmlspecialchars($ip) ?></td>
          </tr>
        </tbody>
      </table>
    </div>

    <?php if ($status === 'complete'): ?>
    <p class="footnote">
      Your response has been verified and recorded in our system.<br>
      Thank you for contributing to <?= htmlspecialchars(BRAND_NAME) ?> research.
    </p>
    <?php endif; ?>

  </div>
</main>

<!-- FOOTER -->
<footer>
  <div class="footer-inner">
    <div>
      <div class="footer-logo">
        <img src="logo.png" alt="<?= htmlspecialchars(BRAND_NAME) ?>">
        <div class="footer-logo-text"><?= htmlspecialchars(BRAND_UPPER) ?></div>
      </div>
      <div class="footer-tagline"><?= htmlspecialchars(BRAND_FOOTER_TAGLINE) ?></div>
    </div>
    <div class="footer-links">
      <a href="mailto:<?= htmlspecialchars(BRAND_EMAIL) ?>"><?= htmlspecialchars(BRAND_EMAIL) ?></a>
      <a href="<?= htmlspecialchars(BRAND_URL) ?>/privacy-policy.html">Privacy</a>
      <a href="<?= htmlspecialchars(BRAND_URL) ?>/terms-of-service.html">Terms</a>
    </div>
    <div class="footer-brand">© <?= date('Y') ?> <?= htmlspecialchars(BRAND_UPPER) ?></div>
  </div>
</footer>

</body>
</html>
<?php
// ── DEFERRED BACKGROUND TASKS ────────────────────────────────
// Everything below runs AFTER the respondent's browser has already
// received the full page — a slow or unreachable vendor/Telegram
// server can never delay what the respondent sees.
if (function_exists('fastcgi_finish_request')) {
    fastcgi_finish_request();
} else {
    // Fallback for non-FPM environments: flush what we can
    if (ob_get_level() > 0) { ob_end_flush(); }
    flush();
}

if (!empty($deferred_vendor_id)) {
    rp_fire_vendor_postback($db, $deferred_vendor_id, $status, $original_uid ?: $enc_uid, $sid, $deferred_actual_seconds ?? null);
}
if (!empty($deferred_actual_seconds)) {
    rp_speeder_alert_check($proj, $sid, $original_uid ?: $enc_uid, $deferred_actual_seconds);
}
// Outbound S2S — same principle as track.php: never fires for an
// unmatched status, and never for a ghost entry (no genuine entry-click
// on record) — we don't report an outcome we can't actually vouch for.
if (!empty($proj['client_id']) && $status !== 'unmatched' && empty($is_ghost_entry)) {
    rp_fire_client_s2s($db, (int)$proj['client_id'], $status, $original_uid ?: $enc_uid);
}
