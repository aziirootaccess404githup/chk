# Azilytics — Bug Fixes (2 files)

These are updates to your **existing** `config.php` and `admin.php` on
hub.azilyticsinsights.com — found during a separate cross-check session
while comparing Azilytics against Kishan's panel. Nothing here was
built from scratch; these are fixes to features that already existed
in your own code but had a genuine bug or a missing piece.

## Deployment
1. Back up your live database (phpMyAdmin → Export) — standard practice
   before any code change.
2. Upload these 2 files to your server root, overwriting the existing
   `config.php` and `admin.php`.
3. No manual SQL needed — the new table (`rp_project_id_map`) and the
   new `rp_blocked_ips`/`rp_country_links` UI work with tables that
   either already existed or self-create on first use.

## What Was Fixed (all tested locally against a real-schema sandbox before delivery)

### 1. `rp_project_id_map` table was never created (`config.php`)
`rp_resolve_project_id()` queried this table without it ever being
created anywhere — a genuinely different client-reference (one that
doesn't match an existing SID directly) would throw a fatal database
error. Added `rp_ensure_project_id_map_table()` and wrapped the lookup
so it now safely creates the table on first use.

### 2. Status-synonym seeding was never wired in (`config.php`)
`rp_seed_default_status_synonyms()` existed with 21 default synonyms
("success"→complete, "flagged"→quality_fail, etc.) but was never
actually called from anywhere — the table was always empty. Now called
from inside `rp_resolve_status_synonym()`, with a guard so it only
seeds once instead of re-running on every lookup.

### 3. IP-Blocking had no admin UI (`admin.php`)
`rp_is_ip_blocked()` / `rp_ensure_blocked_ips_table()` already existed
and were already checked in `vendor.php`, but there was no way to
actually add an IP to the block-list anywhere in the UI. Added:
- New **Blocked IPs** page (sidebar link under Fraud Detection)
- `block_ip` / `unblock_ip` actions, with audit-log entries

### 4. Country-Links had no admin UI (`admin.php`)
`rp_get_country_link()` / `rp_ensure_country_links_table()` already
existed and were already checked in `vendor.php`, but there was no way
to actually add a per-country override anywhere in the UI. Added:
- New **Per-Country Links** card inside Project View
- `save_country_link` / `delete_country_link` actions

## Testing
All 4 fixes were verified against a local sandbox loaded from your own
`SQL.sql` schema — real HTTP requests, not just a syntax check:
- Blocking an IP → entry correctly denied (403)
- Unblocking → entry correctly works again
- A country override → correctly saved and shown in Project View
- A status word only in the synonym table (not the hardcoded list,
  e.g. "flagged") → correctly resolved to quality_fail, and the table
  auto-seeded with all 21 defaults on first use

No live data was touched during testing — everything ran against an
isolated local copy.
