<?php
// ============================================================
// Azilytics Insights — client_portal_login.php
// Client Portal — full login-account access (separate from the
// read-only, token-based Client Report Link). A client logs in once
// and can keep coming back to see their own projects' data over time.
// ============================================================
require_once __DIR__ . '/config.php';
$db = rp_db();
rp_ensure_portal_clients_table($db);

session_name('rp_client_portal_session');
if (session_status() === PHP_SESSION_NONE) session_start();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $stmt = $db->prepare("SELECT * FROM rp_portal_clients WHERE username=? AND is_active=1");
    $stmt->execute([$username]);
    $client = $stmt->fetch();
    if ($client && password_verify($password, $client['password_hash'])) {
        $_SESSION['rp_portal_client_id'] = $client['id'];
        $_SESSION['rp_portal_client_name'] = $client['client_name'];
        $_SESSION['rp_portal_client_ref_id'] = $client['client_id'];
        $db->prepare("UPDATE rp_portal_clients SET last_login=NOW() WHERE id=?")->execute([$client['id']]);
        header('Location: client_portal.php');
        exit();
    } else {
        $error = 'Invalid username or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Client Portal Login — Azilytics Insights</title>
<style>
body { font-family: 'DM Sans', sans-serif; background: #0d0f14; color: #e2e8f0; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
.box { background: #111318; padding: 40px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.07); width: 100%; max-width: 360px; }
h2 { margin: 0 0 20px; text-align: center; }
input { width: 100%; padding: 10px 12px; margin-bottom: 14px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.1); background: #0d0f14; color: #e2e8f0; box-sizing: border-box; }
button { width: 100%; padding: 10px; background: #2563eb; color: #fff; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; }
.err { color: #ef4444; font-size: 13px; margin-bottom: 14px; text-align: center; }
</style>
</head>
<body>
<div class="box">
  <h2>Client Portal</h2>
  <?php if ($error): ?><div class="err"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <form method="POST">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Log In</button>
  </form>
</div>
</body>
</html>
