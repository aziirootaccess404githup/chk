<?php
// ============================================================
// PanelEngine Survey Panel — track.php
// Dynamic status tracker — called by static HTML pages OR directly
// URL: /panelengine/track.php?status=complete&sid=RP001&uid=UID&loi=120
// Add &ajax=1 to get a JSON response instead of a redirect (used by
// the static pages/*.html confirmation pages to display respondent info).
//
// IMPORTANT: The "sid" in the incoming URL is only a starting hint — see
// the matching note in end.php. The real/internal sid is always resolved
// from our own rp_leads record and is what gets used/displayed from here on.
// ============================================================
require_once __DIR__ . '/config.php';

date_default_timezone_set('Asia/Kolkata');

// ── OPTIONAL SIGNATURE CHECK (informational only) ──────────────
// Purely informational, same principle as ExaVerify — logs a mismatch
// for later review, never blocks the respondent's own redirect/status
// page. Only relevant if a client's platform genuinely sends a &sig=
// param at all — most don't, and that's fine, this simply does nothing
// when sig is absent.
if (!empty($_GET['sig'])) {
    $rp_sig_secret = 'exazon-panelengine-signature-secret';
    $rp_expected_sig = hash_hmac('sha256', ($_GET['status'] ?? '') . '|' . ($_GET['sid'] ?? '') . '|' . ($_GET['uid'] ?? ''), $rp_sig_secret);
    if (!hash_equals($rp_expected_sig, $_GET['sig'])) {
        error_log("PanelEngine track.php: signature mismatch — sid=" . ($_GET['sid'] ?? '') . " uid=" . ($_GET['uid'] ?? ''));
    }
}

// Flexible param-name fallback for ALL incoming identifiers - different client
// survey platforms (Qualtrics/Decipher/Confirmit/Toluna/etc) may fire the
// postback using different query param names on their end. This is purely
// additive - every name that worked before still works exactly the same;
// these are just extra accepted names layered on top.
$status  = trim($_GET['status'] ?? $_GET['disposition'] ?? $_GET['outcome'] ?? $_GET['result'] ?? '');
$url_sid = trim($_GET['sid'] ?? $_GET['studyid'] ?? $_GET['surveyid'] ?? $_GET['project_id'] ?? $_GET['study_id'] ?? ''); // hint only
// Flexible param-name fallback — some clients' systems send the identifier
// back under a different name (rid, toid, identifier, tid) instead of uid.
// This is purely a safety-net; nothing else changes.
$enc_uid = trim($_GET['uid'] ?? $_GET['rid'] ?? $_GET['toid'] ?? $_GET['identifier'] ?? $_GET['tid'] ?? $_GET['pid']
              ?? $_GET['respondent_id'] ?? $_GET['panelist_id'] ?? $_GET['participant_id'] ?? $_GET['respid'] ?? $_GET['subject_id'] ?? '');
$loi_raw = $_GET['loi'] ?? $_GET['duration'] ?? $_GET['time_taken'] ?? $_GET['seconds'] ?? $_GET['elapsed'] ?? null;
$loi     = ($loi_raw !== null && is_numeric($loi_raw)) ? (int)$loi_raw : null;
$is_ajax = isset($_GET['ajax']);
$db  = rp_db();
// Ensure genuinely NEW columns exist regardless of which branch below
// runs — Vendor-Scorecard, Overview-stats, and other pages genuinely
// query these columns assuming they exist. track.php itself never sets
// no_entry_record (it uses a different, simpler unmatched-handling
// approach than end.php's ghost-tracking), but the column must still
// genuinely exist with its safe DEFAULT 0 for those other pages'
// queries to work at all.
try {
    $db->exec("ALTER TABLE rp_leads ADD COLUMN no_entry_record TINYINT(1) DEFAULT 0");
    $db->exec("ALTER TABLE rp_leads ADD COLUMN is_duplicate TINYINT(1) DEFAULT 0");
} catch (PDOException $e) {}


// ── Status recognition (same status_aliases table as end.php) ────
// IMPORTANT: if the incoming status is missing or doesn't match anything
// we recognize (e.g. a client only configured 3 of the 4 possible redirect
// URLs, or is sending a status name we don't know), we do NOT guess and
// default to 'complete' — that would silently mark an unknown outcome as
// a successful completion. Instead it becomes 'unmatched': no vendor
// postback fires for it, and it's shown a neutral "under review" page.
$status_aliases = [
    'complete'      => 'complete',      'success'   => 'complete',   'completed' => 'complete',
    'terminate'     => 'terminate',     'terminated'=> 'terminate',  'term'      => 'terminate',
    'overquota'     => 'overquota',     'quotafull' => 'overquota',  'quota_full'=> 'overquota', 'full' => 'overquota',
    'quality_fail'  => 'quality_fail',  'qc'        => 'quality_fail','quality'  => 'quality_fail',
    'screenout'     => 'quality_fail',  'screened_out' => 'quality_fail', 'disqualified' => 'quality_fail',
];
$status_key = strtolower($status);
$resolved_status = $status_aliases[$status_key] ?? null;

// ── STATUS SYNONYM MAPPING FALLBACK ─────────────────────────────
// If the word genuinely isn't one of our built-in aliases, check the
// configurable synonym table before giving up and calling it unmatched
// — this project may have a custom mapping configured (or one of the
// seeded industry-common defaults might match).
if ($resolved_status === null) {
    $synonym_map = ['complete' => 'complete', 'terminate' => 'terminate', 'overquota' => 'overquota', 'quality_fail' => 'quality_fail'];
    $syn_result = rp_resolve_status_synonym($db, $status, $url_sid ?: null);
    if ($syn_result !== null && isset($synonym_map[$syn_result])) {
        $resolved_status = $synonym_map[$syn_result];
    }
}

$is_unmatched = ($resolved_status === null);
$status = $is_unmatched ? 'unmatched' : $resolved_status;
// Normalize
if ($status === 'qc')        $status = 'quality_fail';
if ($status === 'quotafull') $status = 'overquota';

$ip  = rp_get_ip();
$ua  = $_SERVER['HTTP_USER_AGENT'] ?? '';
$geo = rp_geo($ip);
$dev = rp_device();
$br  = rp_browser();
$sid = $url_sid; // may be corrected below once we find the real lead

// ── Resolve original UID (the incoming uid param may be encrypted) ───
$proj = null;
if ($sid) {
    $ps = $db->prepare("SELECT * FROM rp_projects WHERE sid = ? LIMIT 1");
    $ps->execute([$sid]);
    $proj = $ps->fetch();
}
$original_uid = $enc_uid;
if ($proj && !empty($proj['encrypt_uid'])) {
    $decrypted = rp_decrypt($enc_uid, $sid);
    if ($decrypted) {
        $original_uid = $decrypted;
    } else {
        $mr = $db->prepare("SELECT original_uid FROM rp_uid_mapping WHERE encrypted_uid = ? AND sid = ? LIMIT 1");
        $mr->execute([$enc_uid, $sid]);
        $mrow = $mr->fetch();
        if ($mrow) {
            $original_uid = $mrow['original_uid'];
        } else {
            // Mapping lookup without sid filter — covers a client sending a
            // different/wrong sid than what we used originally (encryption key
            // is sid-dependent, so a mismatched sid breaks decryption above).
            $mr2 = $db->prepare("SELECT original_uid, sid FROM rp_uid_mapping WHERE encrypted_uid = ? ORDER BY id DESC LIMIT 1");
            $mr2->execute([$enc_uid]);
            $mrow2 = $mr2->fetch();
            if ($mrow2) {
                $original_uid = $mrow2['original_uid'];
                $sid = $mrow2['sid']; // correct the sid to our real internal one
            }
        }
    }
}

// ── STATUS LOCK CHECK ─────────────────────────────────────────
$deferred_vendor_id = null;
$deferred_loi = null;
try {
    // Try by original_uid + sid (normal case — client sent the correct sid)
    $lc = $db->prepare("SELECT id, sid, status, status_locked, vendor_id FROM rp_leads WHERE original_uid = ? AND sid = ? ORDER BY id DESC LIMIT 1");
    $lc->execute([$original_uid, $sid]);
    $existing = $lc->fetch();

    if (!$existing) {
        $lc2 = $db->prepare("SELECT id, sid, status, status_locked, vendor_id FROM rp_leads WHERE encrypted_uid = ? AND sid = ? ORDER BY id DESC LIMIT 1");
        $lc2->execute([$enc_uid, $sid]);
        $existing = $lc2->fetch();
    }

    if (!$existing) {
        // Further fallback: same UID, ANY project — our own stored sid
        // (from when the respondent first clicked in) always wins over
        // whatever sid the client's system sent back.
        $lc3 = $db->prepare("SELECT id, sid, status, status_locked, vendor_id FROM rp_leads WHERE original_uid = ? OR encrypted_uid = ? ORDER BY id DESC LIMIT 1");
        $lc3->execute([$original_uid, $enc_uid]);
        $existing = $lc3->fetch();
    }

    // If found, its stored sid is the ONLY authoritative sid from here on.
    if ($existing) {
        $sid = $existing['sid'];
        if (!$proj || $proj['sid'] !== $sid) {
            $ps2 = $db->prepare("SELECT * FROM rp_projects WHERE sid = ? LIMIT 1");
            $ps2->execute([$sid]);
            $proj = $ps2->fetch();
        }
    }

    if ($existing && !empty($existing['status_locked'])) {
        // Already locked — use the locked status instead
        $status = $existing['status'];

        // ── DUPLICATE-ON-LOCKED-LEAD DETECTION (same as end.php) ──
        try {
            $db->exec("ALTER TABLE rp_leads ADD COLUMN is_duplicate TINYINT(1) DEFAULT 0");
        } catch (PDOException $e) {}
        $dupChk = $db->prepare("SELECT is_duplicate FROM rp_leads WHERE id=?");
        $dupChk->execute([$existing['id']]);
        if (!$dupChk->fetchColumn()) {
            $db->prepare("UPDATE rp_leads SET is_duplicate=1 WHERE id=?")->execute([$existing['id']]);
            rp_send_telegram_alert("⚠️ Duplicate UID! (repeat hit on an already-locked lead)\nProject: $sid\nUID: " . ($original_uid ?: $enc_uid) . "\nStatus: $status\nThe same respondent attempted again after their result was already locked in!");
        }
    } elseif ($existing) {
        // Update existing lead. LOI is calculated SERVER-SIDE via
        // TIMESTAMPDIFF against the genuine entry_time already on record
        // (same as end.php) — never trusted from the client's own &loi=
        // parameter, which is client-supplied and both timezone-fragile
        // and trivially spoofable. Unmatched stays UNLOCKED
        // (status_locked=0) so a real status arriving later for the same
        // respondent can still correctly overwrite it — same as end.php's
        // pattern.
        $lock_value = $is_unmatched ? 0 : 1;
        $db->prepare("UPDATE rp_leads SET status=?, end_time=NOW(), loi_seconds=TIMESTAMPDIFF(SECOND, entry_time, NOW()), status_locked=? WHERE id=?")
           ->execute([$status, $lock_value, $existing['id']]);
        $deferred_vendor_id = $existing['vendor_id'];
        if ($status === 'complete' || $status === 'terminate') {
            rp_check_ir_drift($db, $sid);
        }
        if ($status === 'complete') {
            rp_check_quota($db, $sid);
            $loi_row = $db->prepare("SELECT loi_seconds FROM rp_leads WHERE id=?");
            $loi_row->execute([$existing['id']]);
            $deferred_loi = $loi_row->fetchColumn();
        }
    } else {
        // No existing lead anywhere — genuinely new direct hit. No internal
        // record exists yet, so there's genuinely no entry_time to measure
        // a real LOI against (same reasoning as end.php's own insert-branch,
        // which also has no LOI here) — left NULL rather than trusting the
        // client's own &loi= value. The URL's sid is the best information
        // available and becomes the internal sid going forward. Same
        // unlocked-if-unmatched rule applies here too.
        $lock_value = $is_unmatched ? 0 : 1;
        $db->prepare("INSERT INTO rp_leads (sid, original_uid, encrypted_uid, status, ip, country, city, device, browser, user_agent, loi_seconds, is_duplicate, status_locked, source, entry_time, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,NULL,0,?,'direct',NOW(),NOW())")
           ->execute([$sid, $original_uid, $enc_uid, $status, $ip, $geo['country'], $geo['city'], $dev, $br, substr($ua,0,500), $lock_value]);
        if ($status === 'complete') {
            rp_check_quota($db, $sid);
            $deferred_loi = null;
        }
    }
} catch (PDOException $e) {
    error_log("PanelEngine track.php error: " . $e->getMessage());
}

// ── AJAX MODE: return JSON for static pages to render ─────────
// (Respondent's browser is already showing the static Thank You page —
// this is just a background info/tracking call, so no vendor redirect
// is possible here; postback still fires in the background as usual.)
if ($is_ajax) {
    header('Content-Type: application/json');
    echo json_encode([
        'sid'    => $sid,
        'uid'    => $original_uid ?: $enc_uid,
        'status' => $status,
        'ip'     => $ip,
        'time'   => date('d/m/Y, H:i:s'),
    ]);
    rp_flush_and_defer($db, $is_unmatched ? null : $deferred_vendor_id, $status, $original_uid ?: $enc_uid, $sid, $proj, $deferred_loi);
    exit();
}

// ── REDIRECT-MODE VENDORS: send the respondent straight to the vendor's
// own page instead of ours (only possible on this full-navigation path).
// Never fires for an unmatched status — we don't want to tell a vendor's
// system any outcome for a status we genuinely don't recognize.
$vendor_redirect_url = $is_unmatched ? null : rp_build_vendor_redirect_url($db, $deferred_vendor_id, $status, $original_uid ?: $enc_uid, $sid, $deferred_loi);
if ($vendor_redirect_url) {
    header("Location: $vendor_redirect_url");
    exit();
}

// ── REDIRECT TO END PAGE (show_page mode / default behavior) ─────
// Fire the vendor postback now (in the background, after flushing this
// redirect response), and mark the forwarded request so end.php knows
// not to fire the same postback a second time.
header("Location: end.php?status=$status&sid=" . urlencode($sid) . "&uid=" . urlencode($enc_uid) . "&_notified=1");
rp_flush_and_defer($db, $is_unmatched ? null : $deferred_vendor_id, $status, $original_uid ?: $enc_uid, $sid, $proj, $deferred_loi);
exit();
