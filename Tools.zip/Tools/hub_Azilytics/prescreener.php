<?php
// ============================================================
// AZILYTICS INSIGHTS — prescreener.php
// Demographic pre-screener form
// ============================================================
require_once __DIR__ . '/config.php';

date_default_timezone_set('Asia/Kolkata');
rp_session_start();

// Validate session
if (empty($_SESSION['rp_sid']) || empty($_SESSION['rp_uid'])) {
    header('Location: end.php?status=quality_fail&sid=&uid=');
    exit();
}

$sid     = $_SESSION['rp_sid'];
$uid     = $_SESSION['rp_uid'];
$vid     = $_SESSION['rp_vid'] ?? '';
$project = $_SESSION['rp_project'];

// ── PRESCREEN TEMPLATE (Question Library) ───────────────────────
// If this project has a template linked, its questions are rendered
// DYNAMICALLY instead of the hardcoded Gender/Age/Country/etc set
// below — existing projects with no template keep working exactly
// as before, unaffected.
$rp_db_conn = rp_db();
rp_ensure_question_library_tables($rp_db_conn);
rp_ensure_project_template_column($rp_db_conn);
$ps_template_questions = [];
if (!empty($project['prescreen_template_id'])) {
    $tpl_q = $rp_db_conn->prepare("SELECT q.* FROM rp_prescreen_template_questions tq JOIN rp_question_library q ON tq.question_id=q.id WHERE tq.template_id=? ORDER BY tq.sort_order");
    $tpl_q->execute([$project['prescreen_template_id']]);
    $ps_template_questions = $tpl_q->fetchAll();
}

// Auto-detect respondent's country (for the Country-question + its
// local-currency income display) — reuses the same 3-provider geo-lookup
// used for tracking, so this stays free and doesn't need a separate call.
$detected_country = '';
try {
    $rp_ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
    if (strpos($rp_ip, ',') !== false) $rp_ip = trim(explode(',', $rp_ip)[0]);
    $detected_country = rp_geo($rp_ip)['country'] ?? '';
} catch (Exception $e) {}

$error = '';

// ── Handle form submission ────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($ps_template_questions)) {
    // Dynamic, template-driven questions
    $ps_answers = [];
    $ps_error = false;
    foreach ($ps_template_questions as $q) {
        $val = trim($_POST['q_' . $q['id']] ?? '');
        if (!empty($q['is_required']) && $val === '') { $ps_error = true; }
        $ps_answers[$q['question_text']] = $val;
    }
    if ($ps_error) {
        $error = 'Please answer all required questions.';
    } else {
        $_SESSION['rp_answers'] = $ps_answers;
        header('Location: capture.php');
        exit();
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $gender    = trim($_POST['gender']    ?? '');
    $age_group = trim($_POST['age_group'] ?? '');
    $education = trim($_POST['education'] ?? '');
    $income    = trim($_POST['income']    ?? '');
    $device    = trim($_POST['device']    ?? '');
    $open_end  = trim($_POST['open_end']  ?? '');

    if (empty($gender) || empty($age_group)) {
        $error = 'Please answer all required questions.';
    } else {
        // Save to session for capture.php
        $_SESSION['rp_answers'] = [
            'gender'    => $gender,
            'age_group' => $age_group,
            'education' => $education,
            'income'    => $income,
            'device'    => $device,
            'open_end'  => $open_end,
        ];
        header('Location: capture.php');
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="referrer" content="unsafe-url">
<title>Profile Questions — <?= htmlspecialchars(BRAND_NAME) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
:root{
  --cream:#faf7f0;
  --cream2:#f4efe4;
  --ink:#15171c;
  --ink2:#2a2d35;
  --gold:#b08d3f;
  --gold-deep:#8a6c28;
  --muted:#6b6f76;
  --line:rgba(21,23,28,0.1);
  --line2:rgba(21,23,28,0.06);
}
html,body{height:100%;min-height:100vh;}
body{font-family:'DM Sans',sans-serif;background:var(--cream);color:var(--ink);overflow-x:hidden;}

.page{min-height:100vh;display:flex;flex-direction:column;}

.topbar{padding:18px 40px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--line);background:#fff;}
.brand{display:flex;align-items:center;gap:12px;}
.brand-logo{width:42px;height:42px;flex-shrink:0;}
.brand-logo img{width:100%;height:100%;object-fit:contain;}
.brand-name{font-family:'Cormorant Garamond',serif;font-size:19px;font-weight:600;letter-spacing:0.5px;color:var(--ink);line-height:1.1;}
.brand-tag{font-size:9px;letter-spacing:2.5px;text-transform:uppercase;color:var(--gold-deep);margin-top:1px;}
.topbar-right{display:flex;align-items:center;gap:12px;}
.badge-live{display:flex;align-items:center;gap:6px;font-size:10px;color:var(--muted);letter-spacing:1px;text-transform:uppercase;}
.dot-live{width:6px;height:6px;border-radius:50%;background:#3a8f5c;}

.statbar{background:var(--ink);padding:18px 40px;display:flex;justify-content:center;gap:64px;flex-wrap:wrap;}
.statbar-item{text-align:center;}
.statbar-num{font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:600;color:var(--gold);}
.statbar-label{font-size:9px;letter-spacing:2px;text-transform:uppercase;color:rgba(255,255,255,0.5);margin-top:2px;}

.body{display:grid;grid-template-columns:380px 1fr;flex:1;}
@media(max-width:900px){.body{grid-template-columns:1fr;}}

.left{padding:48px 40px;border-right:1px solid var(--line);display:flex;flex-direction:column;gap:30px;background:#fff;}
@media(max-width:900px){.left{display:none;}}
.left-step-tag{font-size:10px;letter-spacing:3px;text-transform:uppercase;color:var(--gold-deep);margin-bottom:8px;font-weight:600;}
.left-title{font-family:'Cormorant Garamond',serif;font-size:34px;font-weight:600;color:var(--ink);line-height:1.22;margin-bottom:12px;}
.left-title em{color:var(--gold-deep);font-style:italic;font-weight:500;}
.left-desc{font-size:13.5px;color:var(--muted);line-height:1.85;}

.steps-list{display:flex;flex-direction:column;gap:0;}
.step-item{display:flex;align-items:flex-start;gap:14px;padding-bottom:22px;position:relative;}
.step-item:not(:last-child)::after{content:'';position:absolute;left:14px;top:30px;width:1px;bottom:0;background:var(--line);}
.step-circle{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;flex-shrink:0;}
.step-circle.done{background:#eaf3ee;border:1px solid #3a8f5c;color:#3a8f5c;}
.step-circle.active{background:#f6efdd;border:1px solid var(--gold);color:var(--gold-deep);}
.step-circle.todo{background:var(--cream2);border:1px solid var(--line);color:var(--muted);}
.step-title{font-size:13.5px;font-weight:600;color:var(--ink);line-height:1.3;}
.step-title.muted{color:var(--muted);font-weight:400;}
.step-sub{font-size:11.5px;color:var(--muted);margin-top:2px;}

.stats-row{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.stat-box{background:var(--cream2);border:1px solid var(--line2);border-radius:10px;padding:14px 16px;}
.stat-num{font-family:'Cormorant Garamond',serif;font-size:24px;font-weight:600;color:var(--gold-deep);}
.stat-label{font-size:9px;letter-spacing:2px;text-transform:uppercase;color:var(--muted);margin-top:2px;}

.trust-list{display:flex;flex-direction:column;gap:8px;}
.trust-item{display:flex;align-items:flex-start;gap:12px;padding:13px 14px;background:var(--cream2);border:1px solid var(--line2);border-radius:10px;}
.trust-icon{font-size:16px;margin-top:1px;}
.trust-title{font-size:12.5px;font-weight:600;color:var(--ink);margin-bottom:2px;}
.trust-sub{font-size:11.5px;color:var(--muted);line-height:1.55;}

.contact-block{margin-top:auto;padding-top:24px;border-top:1px solid var(--line);}
.contact-label{font-size:9px;letter-spacing:3px;text-transform:uppercase;color:var(--muted);margin-bottom:12px;}
.contact-row{display:flex;align-items:center;gap:10px;margin-bottom:8px;}
.contact-icon{width:22px;height:22px;border-radius:5px;background:var(--cream2);display:flex;align-items:center;justify-content:center;font-size:10px;flex-shrink:0;}
.contact-text{font-size:11.5px;color:var(--muted);}
.contact-text a{color:var(--ink2);text-decoration:none;}

.right{padding:48px 52px;overflow-y:auto;}
@media(max-width:900px){.right{padding:32px 24px;}}

.uid-badge{display:inline-flex;align-items:center;gap:8px;background:#fff;border:1px solid var(--line);border-radius:50px;padding:7px 18px;font-size:11.5px;color:var(--muted);margin-bottom:22px;letter-spacing:0.3px;}
.uid-badge strong{color:var(--ink);font-weight:600;}

.form-title{font-family:'Cormorant Garamond',serif;font-size:30px;font-weight:600;color:var(--ink);margin-bottom:5px;}
.form-sub{font-size:13.5px;color:var(--muted);margin-bottom:28px;line-height:1.7;}

.prog-wrap{margin-bottom:28px;}
.prog-meta{display:flex;justify-content:space-between;font-size:10.5px;color:var(--muted);margin-bottom:8px;letter-spacing:0.5px;}
.prog-bar{height:3px;background:var(--line2);border-radius:3px;overflow:hidden;}
.prog-fill{height:100%;width:0%;background:var(--gold);border-radius:3px;transition:width 0.4s ease;}

.q-block{margin-bottom:22px;}
.q-label{display:block;font-size:10.5px;font-weight:700;color:var(--ink2);letter-spacing:1.5px;text-transform:uppercase;margin-bottom:10px;}
.radio-group{display:flex;flex-wrap:wrap;gap:8px;}
.radio-row{display:flex;align-items:center;gap:10px;padding:11px 16px;background:#fff;border:1px solid var(--line);border-radius:10px;cursor:pointer;font-size:13px;color:var(--ink2);transition:all 0.2s;user-select:none;}
.radio-row:hover{border-color:var(--gold);background:#fdfbf6;}
.radio-row.selected{background:#f6efdd;border-color:var(--gold);color:var(--ink);font-weight:600;}
.radio-dot{width:14px;height:14px;border-radius:50%;border:1.5px solid var(--line);flex-shrink:0;transition:all 0.2s;display:flex;align-items:center;justify-content:center;}
.radio-dot.filled{border-color:var(--gold-deep);background:var(--gold-deep);}
.radio-dot.filled::after{content:'';width:5px;height:5px;border-radius:50%;background:#fff;}

.err-msg{background:#fbeaea;border:1px solid #e3a3a3;border-radius:8px;padding:11px 16px;color:#a13a3a;font-size:12.5px;margin-bottom:18px;}

.btn-continue{width:100%;padding:15px;margin-top:10px;background:var(--ink);color:#fff;border:none;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:13px;font-weight:600;letter-spacing:1.5px;text-transform:uppercase;cursor:pointer;transition:all 0.2s;}
.btn-continue:hover{background:var(--gold-deep);}
.btn-continue:active{transform:scale(0.99);}

.az-textarea{width:100%;padding:12px 16px;background:#fff;border:1px solid var(--line);border-radius:10px;font-family:'DM Sans',sans-serif;font-size:13.5px;color:var(--ink2);outline:none;resize:none;height:90px;line-height:1.7;transition:border-color 0.2s;}
.az-textarea:focus{border-color:var(--gold);}

.footer{padding:16px 40px;border-top:1px solid var(--line);display:flex;justify-content:space-between;align-items:center;background:#fff;}
.footer-left{font-size:9.5px;letter-spacing:1.5px;color:var(--muted);text-transform:uppercase;}
.footer-right{font-size:9.5px;letter-spacing:2.5px;color:var(--gold-deep);text-transform:uppercase;}

@media(max-width:768px){
  .topbar{padding:14px 20px;}
  .statbar{padding:16px 20px;gap:32px;}
  .footer{padding:14px 20px;flex-wrap:wrap;gap:8px;}
}
</style>
</head>
<body>

<div class="page">

  <div class="topbar">
    <div class="brand">
      <div class="brand-logo"><img src="logo.png" alt="<?= htmlspecialchars(BRAND_NAME) ?>"></div>
      <div>
        <div class="brand-name"><?= htmlspecialchars(BRAND_NAME) ?></div>
        <div class="brand-tag">Decipher the Future</div>
      </div>
    </div>
    <div class="topbar-right">
      <div class="badge-live"><div class="dot-live"></div>Live Survey</div>
    </div>
  </div>

  <div class="statbar">
    <div class="statbar-item"><div class="statbar-num">700+</div><div class="statbar-label">Survey Respondents</div></div>
    <div class="statbar-item"><div class="statbar-num">32+</div><div class="statbar-label">Industries Served</div></div>
    <div class="statbar-item"><div class="statbar-num">45+</div><div class="statbar-label">Countries Reached</div></div>
    <div class="statbar-item"><div class="statbar-num">24/7</div><div class="statbar-label">Research Support</div></div>
  </div>

  <div class="body">

    <div class="left">
      <div>
        <div class="left-step-tag">Survey Pre-Screening</div>
        <div class="left-title">Before We <em>Begin</em></div>
        <p class="left-desc">A few quick questions help us match you to the right survey and ensure data integrity.</p>
      </div>

      <div class="steps-list">
        <div class="step-item">
          <div class="step-circle done">&check;</div>
          <div>
            <div class="step-title">Identity Verified</div>
            <div class="step-sub">Participant ID confirmed</div>
          </div>
        </div>
        <div class="step-item">
          <div class="step-circle active">2</div>
          <div>
            <div class="step-title">Profile Questions</div>
            <div class="step-sub">Quick questions &middot; &lt;60 seconds</div>
          </div>
        </div>
        <div class="step-item">
          <div class="step-circle todo">3</div>
          <div>
            <div class="step-title muted">Enter Survey</div>
            <div class="step-sub">Redirected automatically</div>
          </div>
        </div>
      </div>

      <div class="stats-row">
        <div class="stat-box"><div class="stat-num">&lt;60s</div><div class="stat-label">Completion Time</div></div>
        <div class="stat-box"><div class="stat-num">6</div><div class="stat-label">Questions Total</div></div>
      </div>

      <div class="trust-list">
        <div class="trust-item">
          <div class="trust-icon">&#128274;</div>
          <div><div class="trust-title">AES-256 Encrypted</div><div class="trust-sub">Your identity is anonymized before reaching the client.</div></div>
        </div>
        <div class="trust-item">
          <div class="trust-icon">&#127919;</div>
          <div><div class="trust-title">Better Survey Match</div><div class="trust-sub">Profile data ensures you receive the most relevant surveys.</div></div>
        </div>
        <div class="trust-item">
          <div class="trust-icon">&#9989;</div>
          <div><div class="trust-title">ISO-Compliant Panel</div><div class="trust-sub"><?= htmlspecialchars(BRAND_NAME) ?> follows global research ethics standards.</div></div>
        </div>
      </div>

      <div class="contact-block">
        <div class="contact-label">Support</div>
        <div class="contact-row"><div class="contact-icon">&#9993;</div><div class="contact-text"><a href="mailto:<?= htmlspecialchars(BRAND_EMAIL) ?>"><?= htmlspecialchars(BRAND_EMAIL) ?></a></div></div>
        <div class="contact-row"><div class="contact-icon">&#127760;</div><div class="contact-text"><a href="<?= htmlspecialchars(BRAND_URL) ?>" target="_blank"><?= htmlspecialchars(BRAND_DOMAIN) ?></a></div></div>
      </div>
    </div>

    <div class="right">
      <div class="uid-badge">Participant ID: <strong><?= htmlspecialchars($uid) ?></strong></div>
      <div class="form-title">Profile Questions</div>
      <p class="form-sub">Please complete the required fields before continuing to your survey.</p>

      <div class="prog-wrap">
        <div class="prog-meta"><span>Progress</span><span id="progText">0 of 6</span></div>
        <div class="prog-bar"><div class="prog-fill" id="progFill"></div></div>
      </div>

      <?php if ($error): ?>
      <div class="err-msg"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="POST" id="screenerForm">

      <?php if (!empty($ps_template_questions)): ?>
        <!-- DYNAMIC, TEMPLATE-DRIVEN QUESTIONS -->
        <?php foreach ($ps_template_questions as $q):
          $opts = array_filter(array_map('trim', explode(',', $q['options'] ?? '')));
        ?>
        <div class="q-block">
          <label class="q-label"><?= htmlspecialchars($q['question_text']) ?> <?php if ($q['is_required']): ?><span style="color:var(--gold-deep);font-size:9.5px;">REQUIRED</span><?php endif; ?></label>
          <?php if ($q['question_type'] === 'text'): ?>
          <input type="text" name="q_<?= $q['id'] ?>" style="width:100%;padding:12px;border-radius:8px;border:1px solid #d1d5db;font-size:14px" <?= $q['is_required'] ? 'required' : '' ?>>
          <?php elseif ($q['question_type'] === 'select'): ?>
          <select name="q_<?= $q['id'] ?>" style="width:100%;padding:12px;border-radius:8px;border:1px solid #d1d5db;font-size:14px" <?= $q['is_required'] ? 'required' : '' ?>>
            <option value="">— Select —</option>
            <?php foreach ($opts as $o): ?>
            <option value="<?= htmlspecialchars($o) ?>"><?= htmlspecialchars($o) ?></option>
            <?php endforeach; ?>
          </select>
          <?php else: // radio ?>
          <div class="radio-group">
            <?php foreach ($opts as $o): ?>
            <label class="radio-row" style="display:flex;align-items:center;gap:8px;cursor:pointer">
              <input type="radio" name="q_<?= $q['id'] ?>" value="<?= htmlspecialchars($o) ?>" <?= $q['is_required'] ? 'required' : '' ?>>
              <?= htmlspecialchars($o) ?>
            </label>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
        <button class="btn-continue" type="submit" id="submitBtn">Continue to Survey &rarr;</button>

      <?php else: ?>
        <!-- EXISTING HARDCODED QUESTIONS (no template linked to this project) -->
        <input type="hidden" name="gender"    id="val_gender">
        <input type="hidden" name="age_group" id="val_age_group">
        <input type="hidden" name="education" id="val_education">
        <input type="hidden" name="income"    id="val_income">
        <input type="hidden" name="device"    id="val_device">

        <div class="q-block">
          <label class="q-label">Gender <span style="color:var(--gold-deep);font-size:9.5px;">REQUIRED</span></label>
          <div class="radio-group" id="grp-gender">
            <div class="radio-row" onclick="selectOpt('gender','Male',this)"><div class="radio-dot"></div>Male</div>
            <div class="radio-row" onclick="selectOpt('gender','Female',this)"><div class="radio-dot"></div>Female</div>
            <div class="radio-row" onclick="selectOpt('gender','Non-binary',this)"><div class="radio-dot"></div>Non-binary</div>
            <div class="radio-row" onclick="selectOpt('gender','Prefer not to say',this)"><div class="radio-dot"></div>Prefer not to say</div>
          </div>
        </div>

        <div class="q-block">
          <label class="q-label">Age Group <span style="color:var(--gold-deep);font-size:9.5px;">REQUIRED</span></label>
          <div class="radio-group" id="grp-age_group">
            <div class="radio-row" onclick="selectOpt('age_group','18-24',this)"><div class="radio-dot"></div>18&ndash;24</div>
            <div class="radio-row" onclick="selectOpt('age_group','25-34',this)"><div class="radio-dot"></div>25&ndash;34</div>
            <div class="radio-row" onclick="selectOpt('age_group','35-44',this)"><div class="radio-dot"></div>35&ndash;44</div>
            <div class="radio-row" onclick="selectOpt('age_group','45-54',this)"><div class="radio-dot"></div>45&ndash;54</div>
            <div class="radio-row" onclick="selectOpt('age_group','55-64',this)"><div class="radio-dot"></div>55&ndash;64</div>
            <div class="radio-row" onclick="selectOpt('age_group','65+',this)"><div class="radio-dot"></div>65+</div>
          </div>
        </div>

        <div class="q-block">
          <label class="q-label">Highest Education</label>
          <div class="radio-group" id="grp-education">
            <div class="radio-row" onclick="selectOpt('education','High School',this)"><div class="radio-dot"></div>High School</div>
            <div class="radio-row" onclick="selectOpt('education','Some College',this)"><div class="radio-dot"></div>Some College</div>
            <div class="radio-row" onclick="selectOpt('education',&quot;Bachelor's&quot;,this)"><div class="radio-dot"></div>Bachelor's</div>
            <div class="radio-row" onclick="selectOpt('education',&quot;Master's&quot;,this)"><div class="radio-dot"></div>Master's</div>
            <div class="radio-row" onclick="selectOpt('education','Doctorate',this)"><div class="radio-dot"></div>Doctorate</div>
          </div>
        </div>

        <div class="q-block">
          <label class="q-label">Which Country Are You In?</label>
          <select id="prescreen_country" onchange="updateIncomeCurrency()" style="width:100%;padding:12px;border-radius:8px;border:1px solid #d1d5db;font-size:14px">
            <option value="">— Select —</option>
          </select>
        </div>

        <div class="q-block">
          <label class="q-label">Annual Household Income</label>
          <div class="radio-group" id="grp-income">
            <div class="radio-row" data-usd-label="Under $25K" onclick="selectOpt('income','Under $25K',this)"><div class="radio-dot"></div><span class="opt-text">Under $25K</span></div>
            <div class="radio-row" data-usd-label="$25K-$50K" onclick="selectOpt('income','$25K-$50K',this)"><div class="radio-dot"></div><span class="opt-text">$25K&ndash;$50K</span></div>
            <div class="radio-row" data-usd-label="$50K-$75K" onclick="selectOpt('income','$50K-$75K',this)"><div class="radio-dot"></div><span class="opt-text">$50K&ndash;$75K</span></div>
            <div class="radio-row" data-usd-label="$75K-$100K" onclick="selectOpt('income','$75K-$100K',this)"><div class="radio-dot"></div><span class="opt-text">$75K&ndash;$100K</span></div>
            <div class="radio-row" data-usd-label="Over $100K" onclick="selectOpt('income','Over $100K',this)"><div class="radio-dot"></div><span class="opt-text">Over $100K</span></div>
          </div>
        </div>

        <div class="q-block">
          <label class="q-label">Device You Are Using</label>
          <div class="radio-group" id="grp-device">
            <div class="radio-row" onclick="selectOpt('device','Desktop/Laptop',this)"><div class="radio-dot"></div>Desktop / Laptop</div>
            <div class="radio-row" onclick="selectOpt('device','Mobile',this)"><div class="radio-dot"></div>Mobile</div>
            <div class="radio-row" onclick="selectOpt('device','Tablet',this)"><div class="radio-dot"></div>Tablet</div>
          </div>
        </div>

        <div class="q-block">
          <label class="q-label">Anything Else You'd Like to Share? <span style="color:var(--muted);font-size:9.5px;letter-spacing:1px;">OPTIONAL</span></label>
          <textarea class="az-textarea" name="open_end" maxlength="500" placeholder="Your answer here..."></textarea>
        </div>

        <button class="btn-continue" type="submit" id="submitBtn">Continue to Survey &rarr;</button>
      <?php endif; ?>
      </form>
    </div>

  </div>

  <div class="footer">
    <div class="footer-left">&copy; <?= date('Y') ?> <?= htmlspecialchars(BRAND_NAME) ?> &mdash; All Rights Reserved</div>
    <div class="footer-right">Decipher the Future</div>
  </div>

</div>

<script>
const required = <?= !empty($ps_template_questions) ? '[]' : "['gender','age_group']" ?>;
const selected = {};

// ── Country dropdown + local-currency income display ──────────
// Matches the same fix ported to ExaVerify/Kishan's panel/Node.js
// tool: respondent SEES income options converted to local currency,
// but the SUBMITTED value (selectOpt's 2nd argument, hardcoded in each
// onclick=) never changes — only the visible .opt-text does. Keeps
// analytics/reports/exports consistent across every country.
const DETECTED_COUNTRY = <?= json_encode($detected_country ?? '') ?>;
const COUNTRY_CURRENCY = {
  'India': {symbol:'₹', rate:83}, 'United States': {symbol:'$', rate:1},
  'United Kingdom': {symbol:'£', rate:0.79}, 'Canada': {symbol:'C$', rate:1.36},
  'Australia': {symbol:'A$', rate:1.52}, 'Germany': {symbol:'€', rate:0.92},
  'France': {symbol:'€', rate:0.92}, 'Philippines': {symbol:'₱', rate:56},
  'United Arab Emirates': {symbol:'AED', rate:3.67}, 'Singapore': {symbol:'S$', rate:1.35},
  'South Africa': {symbol:'R', rate:18.5}, 'Pakistan': {symbol:'Rs', rate:278},
  'Bangladesh': {symbol:'Tk', rate:110}, 'Indonesia': {symbol:'Rp', rate:15600},
  'Malaysia': {symbol:'RM', rate:4.7}, 'Brazil': {symbol:'R$', rate:5.0},
  'Mexico': {symbol:'Mex$', rate:17}, 'Japan': {symbol:'¥', rate:150},
};
function populateCountryDropdown() {
  const sel = document.getElementById('prescreen_country');
  if (!sel) return;
  Object.keys(COUNTRY_CURRENCY).sort().forEach(name => {
    const opt = document.createElement('option');
    opt.value = name; opt.textContent = name;
    sel.appendChild(opt);
  });
  const other = document.createElement('option');
  other.value = 'Other'; other.textContent = 'Other / Not listed (USD)';
  sel.appendChild(other);
  if (DETECTED_COUNTRY && COUNTRY_CURRENCY[DETECTED_COUNTRY]) {
    sel.value = DETECTED_COUNTRY;
    updateIncomeCurrency();
  }
}
function updateIncomeCurrency() {
  const country = document.getElementById('prescreen_country').value;
  const info = COUNTRY_CURRENCY[country];
  document.querySelectorAll('#grp-income .radio-row').forEach(row => {
    const usdLabel = row.getAttribute('data-usd-label');
    const textEl = row.querySelector('.opt-text');
    if (!info) { textEl.textContent = usdLabel.replace('$25K-$50K','$25K–$50K').replace('$50K-$75K','$50K–$75K').replace('$75K-$100K','$75K–$100K'); return; }
    // Parse every $NNNK in the USD label and convert to local currency
    textEl.textContent = usdLabel.replace(/\$(\d+)K/g, (m, numStr) => {
      const usd = parseInt(numStr, 10) * 1000;
      const converted = Math.round(usd * info.rate);
      return info.symbol + converted.toLocaleString('en-US');
    }).replace('-', ' – ');
  });
}
document.addEventListener('DOMContentLoaded', populateCountryDropdown);

function selectOpt(field, value, el) {
    selected[field] = value;
    document.getElementById('val_' + field).value = value;
    document.querySelectorAll('#grp-' + field + ' .radio-row').forEach(r => {
        r.classList.remove('selected');
        r.querySelector('.radio-dot').classList.remove('filled');
    });
    el.classList.add('selected');
    el.querySelector('.radio-dot').classList.add('filled');
    updateProgress();
}

function updateProgress() {
    const fields = ['gender','age_group','education','income','device'];
    let filled = fields.filter(f => selected[f]).length;
    const openEnd = document.querySelector('textarea[name="open_end"]').value.trim().length > 0 ? 1 : 0;
    const total = filled + openEnd;
    document.getElementById('progFill').style.width = (total / 6 * 100) + '%';
    document.getElementById('progText').textContent = total + ' of 6';
}

document.querySelector('textarea[name="open_end"]').addEventListener('input', updateProgress);

document.getElementById('screenerForm').addEventListener('submit', function(e) {
    let valid = true;
    required.forEach(f => { if (!selected[f]) valid = false; });
    if (!valid) {
        e.preventDefault();
        const btn = document.getElementById('submitBtn');
        btn.textContent = '⚠ Please answer required questions first';
        setTimeout(() => btn.textContent = 'Continue to Survey →', 2000);
    }
});
</script>

</body>
</html>
