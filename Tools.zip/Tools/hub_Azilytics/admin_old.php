<?php
// ============================================================
// Azilytics Insights — admin.php
// Full dashboard: Dashboard, Projects, Clients, Vendors, Leads, Team
// ============================================================
require_once __DIR__ . '/config.php';
rp_require_login();

$db   = rp_db();
$user = rp_current_user();
$page = $_GET['page'] ?? 'dashboard';
$msg  = '';
$err  = '';

// ── AJAX / POST HANDLERS ─────────────────────────────────────

// ── EXCEL EXPORT ─────────────────────────────────────────────
// ── FULL DATABASE BACKUP (on-demand only — no automatic/scheduled deletion
// of any kind; this is purely a manual "download a copy right now" tool.
// Data is never removed from the server by this feature — it stays until
// manually deleted via SQL if/when needed.) ──────────────────────────────
if (isset($_GET['backup']) && $_GET['backup'] === 'download' && rp_is_superadmin()) {
    $backup_tables = ['rp_leads', 'rp_projects', 'rp_vendors', 'rp_clients', 'rp_project_vendors', 'rp_uid_mapping', 'rp_notes', 'rp_prescreener_answers'];
    header('Content-Type: application/sql');
    header('Content-Disposition: attachment; filename="azilytics_backup_'.date('Y-m-d_His').'.sql"');
    echo "-- Azilytics Insights — Full Data Backup\n";
    echo "-- Generated: " . date('Y-m-d H:i:s') . " IST\n";
    echo "-- Tables included: " . implode(', ', $backup_tables) . "\n\n";
    echo "SET FOREIGN_KEY_CHECKS=0;\n\n";
    foreach ($backup_tables as $t) {
        try {
            $rows = $db->query("SELECT * FROM $t")->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            continue; // table doesn't exist on this install — skip silently
        }
        echo "-- --------------------------------------------------\n";
        echo "-- Table: $t (" . count($rows) . " rows)\n";
        echo "-- --------------------------------------------------\n";
        foreach ($rows as $row) {
            $cols = array_keys($row);
            $vals = array_map(function($v) use ($db) {
                if ($v === null) return 'NULL';
                return $db->quote($v);
            }, array_values($row));
            echo "INSERT INTO `$t` (`" . implode('`,`', $cols) . "`) VALUES (" . implode(',', $vals) . ");\n";
        }
        echo "\n";
    }
    echo "SET FOREIGN_KEY_CHECKS=1;\n";
    exit();
}

if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    // Screener export
    if ($page === 'screener') {
        $sc_sid = trim($_GET['sc_sid'] ?? '');
        $where = '1=1'; $params = [];
        if ($sc_sid) { $where .= " AND sid=?"; $params[] = $sc_sid; }
        $rows = $db->prepare("SELECT * FROM rp_prescreener_answers WHERE $where ORDER BY id DESC");
        $rows->execute($params);
        $data = $rows->fetchAll();
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="panel_screener_'.date('Ymd').'.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['ID','SID','UID','Gender','Age','Education','Income','Device','Date']);
        foreach ($data as $r) {
            fputcsv($out, [$r['id'],$r['sid'],$r['original_uid'],$r['gender'],$r['age_group'],$r['education'],$r['income'],$r['device_self'],$r['created_at']]);
        }
        fclose($out); exit();
    }
    // Vendors export — full vendor-list with performance summary
    // (clicks/completes/terminates/conv%), matching Kishan's panel's
    // "Export to Excel" button on the Vendors-list page.
    if ($page === 'vendors') {
        $vex_rows = $db->query("SELECT * FROM rp_vendors ORDER BY id DESC")->fetchAll();
        $vex_perf_rows = $db->query("SELECT vendor_id, COUNT(*) AS clicks, SUM(CASE WHEN status='complete' THEN 1 ELSE 0 END) AS completes, SUM(CASE WHEN status='terminate' THEN 1 ELSE 0 END) AS terminates FROM rp_leads WHERE vendor_id IS NOT NULL GROUP BY vendor_id")->fetchAll();
        $vex_perf = [];
        foreach ($vex_perf_rows as $r) { $vex_perf[$r['vendor_id']] = $r; }
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="panel_vendors_'.date('Ymd').'.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['ID','Vendor Name','Email','Clicks','Completes','Terminates','Conv%','Status']);
        foreach ($vex_rows as $r) {
            $p = $vex_perf[$r['id']] ?? ['clicks'=>0,'completes'=>0,'terminates'=>0];
            $conv = $p['clicks'] > 0 ? round(($p['completes'] / $p['clicks']) * 100, 1) : 0;
            fputcsv($out, [$r['id'], $r['vendor_name'], $r['email'], $p['clicks'], $p['completes'], $p['terminates'], $conv, $r['status']]);
        }
        fclose($out); exit();
    }
    // Leads export
    $sid_filter = trim($_GET['sid'] ?? '');
    $vid_filter = (int)($_GET['vendor_id'] ?? $_GET['vid'] ?? 0);
    $status_filter = trim($_GET['status'] ?? '');
    $device_filter = trim($_GET['device'] ?? '');
    $search_filter = trim($_GET['search'] ?? '');
    $client_filter = (int)($_GET['client_id'] ?? 0);
    $country_filter = trim($_GET['country'] ?? '');
    $date_from_filter = trim($_GET['date_from'] ?? '');
    $date_to_filter = trim($_GET['date_to'] ?? '');
    $where = '1=1'; $params = [];
    if ($sid_filter) { $where .= " AND l.sid=?"; $params[] = $sid_filter; }
    if ($vid_filter) { $where .= " AND l.vendor_id=?"; $params[] = $vid_filter; }
    if ($status_filter) { $where .= " AND l.status=?"; $params[] = $status_filter; }
    if ($device_filter) { $where .= " AND l.device=?"; $params[] = $device_filter; }
    if ($search_filter) { $where .= " AND (l.original_uid LIKE ? OR l.sid LIKE ?)"; $params[] = "%$search_filter%"; $params[] = "%$search_filter%"; }
    if ($client_filter) { $where .= " AND p.client_id=?"; $params[] = $client_filter; }
    if ($country_filter) { $where .= " AND l.country=?"; $params[] = $country_filter; }
    if ($date_from_filter) { $where .= " AND DATE(l.created_at) >= ?"; $params[] = $date_from_filter; }
    if ($date_to_filter) { $where .= " AND DATE(l.created_at) <= ?"; $params[] = $date_to_filter; }
    $rows = $db->prepare("SELECT l.*, p.project_name, p.client_name FROM rp_leads l LEFT JOIN rp_projects p ON l.sid=p.sid WHERE $where ORDER BY l.id DESC");
    $rows->execute($params);
    $data = $rows->fetchAll();
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="panel_leads_'.date('Ymd').'.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['ID','SID','Project','Client','UID','Status','Country','City','Device','Browser','LOI(sec)','IP','Date']);
    foreach ($data as $r) {
        fputcsv($out, [$r['id'],$r['sid'],$r['project_name'],$r['client_name'],$r['original_uid'],$r['status'],$r['country'],$r['city'],$r['device'],$r['browser'],$r['loi_seconds'],$r['ip'],$r['created_at']]);
    }
    fclose($out); exit();
}

// ── DELETE HANDLERS ──────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    // Update Invoice/Billing Status
    if ($action === 'update_invoice_status' && rp_is_manager()) {
        rp_ensure_invoice_table($db);
        $pid    = (int)$_POST['project_id'];
        $status = in_array($_POST['status'] ?? '', ['unpaid','invoiced','paid']) ? $_POST['status'] : 'unpaid';
        $notes  = trim($_POST['notes'] ?? '');
        $db->prepare("INSERT INTO rp_invoice_status (project_id, status, notes) VALUES (?,?,?)
                      ON DUPLICATE KEY UPDATE status=VALUES(status), notes=VALUES(notes)")
           ->execute([$pid, $status, $notes]);
        header("Location: admin.php?page=billing&msg=Updated");
        exit();
    }

    // Save Note (add or edit)
    if ($action === 'save_note') {
        rp_ensure_notes_table($db);
        $note_id = (int)($_POST['note_id'] ?? 0);
        $title   = trim($_POST['title']   ?? '');
        $content = trim($_POST['content'] ?? '');
        if ($note_id > 0) {
            $db->prepare("UPDATE rp_notes SET title=?, content=? WHERE id=?")->execute([$title, $content, $note_id]);
        } else {
            $db->prepare("INSERT INTO rp_notes (title, content) VALUES (?,?)")->execute([$title, $content]);
        }
        header("Location: admin.php?page=notes&msg=Note+saved");
        exit();
    }

    // Delete Note
    if ($action === 'delete_note') {
        rp_ensure_notes_table($db);
        $db->prepare("DELETE FROM rp_notes WHERE id=?")->execute([(int)($_POST['note_id'] ?? 0)]);
        header("Location: admin.php?page=notes&msg=Note+deleted");
        exit();
    }

    // Generate Client Report Share Link
    if ($action === 'generate_share_link' && rp_is_manager()) {
        rp_ensure_share_table($db);
        $pid = (int)$_POST['project_id'];
        $token = bin2hex(random_bytes(16));
        $db->prepare("INSERT INTO rp_share_links (project_id, token) VALUES (?,?)")->execute([$pid, $token]);
        header("Location: admin.php?page=project_view&id=$pid&msg=Report+link+generated");
        exit();
    }

    // Delete/Revoke Client Report Share Link
    if ($action === 'delete_share_link' && rp_is_manager()) {
        rp_ensure_share_table($db);
        $link_id = (int)$_POST['link_id'];
        $pid     = (int)$_POST['project_id'];
        $db->prepare("DELETE FROM rp_share_links WHERE id=?")->execute([$link_id]);
        header("Location: admin.php?page=project_view&id=$pid&msg=Report+link+revoked");
        exit();
    }

    // Delete Single Audit Log Entry
    if ($action === 'delete_audit_entry' && rp_is_superadmin()) {
        rp_ensure_audit_table($db);
        $db->prepare("DELETE FROM rp_audit_log WHERE id=?")->execute([$_POST['id'] ?? 0]);
        header("Location: admin.php?page=audit_log&msg=Entry+deleted");
        exit();
    }
    // Clear All Audit Log Entries
    if ($action === 'clear_audit_log' && rp_is_superadmin()) {
        rp_ensure_audit_table($db);
        $db->exec("DELETE FROM rp_audit_log");
        // Log the clear action itself, so the trail isn't left completely blank
        rp_log_audit($db, 'clear_audit_log', 'All previous audit entries cleared');
        header("Location: admin.php?page=audit_log&msg=Audit+log+cleared");
        exit();
    }

    // Save Alert Settings (superadmin only)
    if ($action === 'save_alert_settings' && rp_is_superadmin()) {
        rp_set_setting($db, 'telegram_bot_token', trim($_POST['telegram_bot_token'] ?? ''));
        rp_set_setting($db, 'telegram_chat_id',   trim($_POST['telegram_chat_id']   ?? ''));
        rp_set_setting($db, 'alert_email',        trim($_POST['alert_email']        ?? ''));
        header("Location: admin.php?page=alert_settings&msg=Settings+saved");
        exit();
    }

    // Pause / Resume Project
    if ($action === 'toggle_project_status' && rp_is_manager()) {
        $id = (int)$_POST['id'];
        $cur = $db->prepare("SELECT status FROM rp_projects WHERE id=?");
        $cur->execute([$id]);
        $cur_status = $cur->fetchColumn();
        $new_status = $cur_status === 'active' ? 'paused' : 'active';
        $db->prepare("UPDATE rp_projects SET status=? WHERE id=?")->execute([$new_status, $id]);
        $ref = $_SERVER['HTTP_REFERER'] ?? '';
        if (strpos($ref, 'project_view') !== false) {
            header("Location: admin.php?page=project_view&id=$id&msg=Project+".ucfirst($new_status));
        } else {
            header("Location: admin.php?page=projects&msg=Project+".ucfirst($new_status));
        }
        exit();
    }

    // Pause / Resume Vendor (global — blocks this vendor across every project at once)
    if ($action === 'toggle_vendor_status' && rp_is_manager()) {
        $id = (int)$_POST['id'];
        $cur = $db->prepare("SELECT status FROM rp_vendors WHERE id=?");
        $cur->execute([$id]);
        $cur_status = $cur->fetchColumn();
        $new_status = $cur_status === 'active' ? 'inactive' : 'active';
        $db->prepare("UPDATE rp_vendors SET status=? WHERE id=?")->execute([$new_status, $id]);
        $ref = $_SERVER['HTTP_REFERER'] ?? '';
        $label = $new_status === 'active' ? 'Active' : 'Paused';
        if (strpos($ref, 'vendor_view') !== false) {
            header("Location: admin.php?page=vendor_view&id=$id&msg=Vendor+$label");
        } else {
            header("Location: admin.php?page=vendors&msg=Vendor+$label");
        }
        exit();
    }

    // Toggle Pin (Projects list)
    if ($action === 'toggle_pin_project' && rp_is_manager()) {
        rp_ensure_project_extra_columns($db);
        $id = (int)$_POST['id'];
        $cur = $db->prepare("SELECT is_pinned FROM rp_projects WHERE id=?");
        $cur->execute([$id]);
        $new_val = $cur->fetchColumn() ? 0 : 1;
        $db->prepare("UPDATE rp_projects SET is_pinned=? WHERE id=?")->execute([$new_val, $id]);
        header("Location: admin.php?page=projects");
        exit();
    }

    // Set Color Tag (Projects list)
    if ($action === 'set_project_color' && rp_is_manager()) {
        rp_ensure_project_extra_columns($db);
        $id = (int)$_POST['id'];
        $color = preg_replace('/[^a-z]/', '', $_POST['color_tag'] ?? '');
        $db->prepare("UPDATE rp_projects SET color_tag=? WHERE id=?")->execute([$color ?: null, $id]);
        header("Location: admin.php?page=projects");
        exit();
    }

    // Save Per-Project Notes
    if ($action === 'save_project_notes') {
        rp_ensure_project_extra_columns($db);
        $id = (int)$_POST['id'];
        $db->prepare("UPDATE rp_projects SET internal_notes=? WHERE id=?")->execute([trim($_POST['internal_notes'] ?? ''), $id]);
        header("Location: admin.php?page=project_view&id=$id&msg=Notes+saved");
        exit();
    }

    // Quick-Edit CPI / Supplier CPI / Quota (inline, from Projects list)
    if ($action === 'quick_edit_project' && rp_is_manager()) {
        rp_ensure_project_extra_columns($db);
        $id  = (int)$_POST['id'];
        $cpi = (float)($_POST['cpi'] ?? 0);
        $supplier_cpi = (float)($_POST['supplier_cpi'] ?? 0);
        $quota = (int)($_POST['max_completes'] ?? 0);
        $db->prepare("UPDATE rp_projects SET cpi=?, supplier_cpi=?, max_completes=? WHERE id=?")
           ->execute([$cpi, $supplier_cpi, $quota, $id]);
        header("Location: admin.php?page=projects&msg=Updated");
        exit();
    }

    // Duplicate Project
    if ($action === 'duplicate_project' && rp_is_manager()) {
        $id = (int)$_POST['id'];
        $src = $db->prepare("SELECT * FROM rp_projects WHERE id=?");
        $src->execute([$id]);
        $src = $src->fetch();
        if ($src) {
            $new_sid = $src['sid'].'_COPY';
            $db->prepare("INSERT INTO rp_projects (sid, project_name, client_id, client_name, cpi, ir, loi, max_completes, live_url, test_url, status, project_type, encrypt_uid, description)
                VALUES (?,?,?,?,?,?,?,?,?,?,'paused',?,?,?)")
               ->execute([$new_sid, $src['project_name'].' (Copy)', $src['client_id'], $src['client_name'], $src['cpi'], $src['ir'], $src['loi'], $src['max_completes'], $src['live_url'], $src['test_url'], $src['project_type'], $src['encrypt_uid'], $src['description']]);
        }
        header("Location: admin.php?page=projects&msg=Project+duplicated");
        exit();
    }

    // Delete Single Lead
    if ($action === 'delete_lead' && rp_is_superadmin()) {
        rp_log_audit($db, 'delete_lead', 'Lead ID ' . ($_POST['id'] ?? '?'));
        $db->prepare("DELETE FROM rp_leads WHERE id=?")->execute([$_POST['id']]);
        $ref = $_SERVER['HTTP_REFERER'] ?? 'admin.php?page=leads';
        header("Location: $ref&msg=Lead+deleted");
        exit();
    }
    // Bulk Delete Leads
    if ($action === 'bulk_delete_leads' && rp_is_superadmin()) {
        $ids = array_filter(array_map('intval', explode(',', $_POST['lead_ids'] ?? '')));
        if (!empty($ids)) {
            rp_log_audit($db, 'bulk_delete_leads', count($ids) . ' lead(s): ' . implode(',', $ids));
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $db->prepare("DELETE FROM rp_leads WHERE id IN ($placeholders)")->execute($ids);
        }
        $ref = $_SERVER['HTTP_REFERER'] ?? 'admin.php?page=leads';
        header("Location: $ref&msg=".count($ids)."+leads+deleted");
        exit();
    }
    // Delete Single Screener Entry
    if ($action === 'delete_screener' && rp_is_superadmin()) {
        rp_log_audit($db, 'delete_screener', 'Screener ID ' . ($_POST['id'] ?? '?'));
        $db->prepare("DELETE FROM rp_prescreener_answers WHERE id=?")->execute([$_POST['id']]);
        header("Location: admin.php?page=screener&msg=Screener+entry+deleted");
        exit();
    }
    // Bulk Delete Screener Entries
    if ($action === 'bulk_delete_screener' && rp_is_superadmin()) {
        $ids = array_filter(array_map('intval', explode(',', $_POST['screener_ids'] ?? '')));
        if (!empty($ids)) {
            rp_log_audit($db, 'bulk_delete_screener', count($ids) . ' screener entr(y/ies): ' . implode(',', $ids));
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $db->prepare("DELETE FROM rp_prescreener_answers WHERE id IN ($placeholders)")->execute($ids);
        }
        header("Location: admin.php?page=screener&msg=".count($ids)."+entries+deleted");
        exit();
    }
    // Delete All Leads by Project
    if ($action === 'delete_project_leads' && rp_is_superadmin()) {
        rp_log_audit($db, 'delete_project_leads', 'Project SID: ' . ($_POST['sid'] ?? '?'));
        $db->prepare("DELETE FROM rp_leads WHERE sid=?")->execute([$_POST['sid']]);
        header("Location: admin.php?page=project_view&id={$_POST['project_id']}&msg=All+leads+deleted");
        exit();
    }
    // Delete All Leads by Vendor
    if ($action === 'delete_vendor_leads' && rp_is_superadmin()) {
        rp_log_audit($db, 'delete_vendor_leads', 'Vendor ID: ' . ($_POST['vendor_id'] ?? '?'));
        $db->prepare("DELETE FROM rp_leads WHERE vendor_id=?")->execute([$_POST['vendor_id']]);
        header("Location: admin.php?page=vendor_view&id={$_POST['vendor_id']}&msg=All+leads+deleted");
        exit();
    }

    // Password Change
    if ($action === 'change_password') {
        $current = trim($_POST['current_password'] ?? '');
        $new     = trim($_POST['new_password'] ?? '');
        $confirm = trim($_POST['confirm_password'] ?? '');
        $uid = $user['id'];
        $u = $db->prepare("SELECT password FROM rp_users WHERE id=?");
        $u->execute([$uid]); $u = $u->fetch();
        if (!password_verify($current, $u['password'])) {
            header("Location: admin.php?page=change_password&err=Current+password+incorrect");
        } elseif (strlen($new) < 6) {
            header("Location: admin.php?page=change_password&err=Password+must+be+6+chars+minimum");
        } elseif ($new !== $confirm) {
            header("Location: admin.php?page=change_password&err=Passwords+do+not+match");
        } else {
            $db->prepare("UPDATE rp_users SET password=? WHERE id=?")->execute([password_hash($new, PASSWORD_DEFAULT), $uid]);
            header("Location: admin.php?page=change_password&msg=Password+changed+successfully");
        }
        exit();
    }

    // Unassign Vendor from Project
    if ($action === 'unassign_vendor' && rp_is_manager()) {
        $db->prepare("DELETE FROM rp_project_vendors WHERE id=?")->execute([$_POST['pv_id']]);
        header("Location: admin.php?page=project_view&id={$_POST['project_id']}&msg=Vendor+removed");
        exit();
    }
    // Edit Vendor Assignment (CPI/Limit)
    if ($action === 'edit_assignment' && rp_is_manager()) {
        $db->prepare("UPDATE rp_project_vendors SET cpi=?, max_limit=? WHERE id=?")
           ->execute([$_POST['cpi'], $_POST['max_limit'], $_POST['pv_id']]);
        header("Location: admin.php?page=project_view&id={$_POST['project_id']}&msg=Assignment+updated");
        exit();
    }

    // Toggle Vendor Assignment Status
    if ($action === 'toggle_vendor_assignment' && rp_is_manager()) {
        $id = (int)$_POST['pv_id'];
        $cur = $db->prepare("SELECT status FROM rp_project_vendors WHERE id=?");
        $cur->execute([$id]); $cur_status = $cur->fetchColumn();
        $new_status = $cur_status === 'active' ? 'paused' : 'active';
        $db->prepare("UPDATE rp_project_vendors SET status=? WHERE id=?")->execute([$new_status, $id]);
        header("Location: admin.php?page=project_view&id={$_POST['project_id']}&msg=Vendor+".ucfirst($new_status));
        exit();
    }

    // Delete Project
    if ($action === 'delete_project' && rp_is_superadmin()) {
        rp_log_audit($db, 'delete_project', 'Project ID: ' . ($_POST['id'] ?? '?'));
        $db->prepare("DELETE FROM rp_projects WHERE id=?")->execute([$_POST['id']]);
        header("Location: admin.php?page=projects&msg=Project+deleted");
        exit();
    }
    // Bulk Delete Projects
    if ($action === 'bulk_delete_projects' && rp_is_superadmin()) {
        $ids = array_filter(array_map('intval', explode(',', $_POST['project_ids'] ?? '')));
        if (!empty($ids)) {
            rp_log_audit($db, 'bulk_delete_projects', count($ids) . ' project(s): ' . implode(',', $ids));
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $db->prepare("DELETE FROM rp_projects WHERE id IN ($placeholders)")->execute($ids);
        }
        header("Location: admin.php?page=projects&msg=".count($ids)."+projects+deleted");
        exit();
    }
    // Delete Client
    if ($action === 'delete_client' && rp_is_superadmin()) {
        rp_log_audit($db, 'delete_client', 'Client ID: ' . ($_POST['id'] ?? '?'));
        $db->prepare("DELETE FROM rp_clients WHERE id=?")->execute([$_POST['id']]);
        header("Location: admin.php?page=clients&msg=Client+deleted");
        exit();
    }
    // Delete Vendor
    if ($action === 'delete_vendor' && rp_is_superadmin()) {
        rp_log_audit($db, 'delete_vendor', 'Vendor ID: ' . ($_POST['id'] ?? '?'));
        $db->prepare("DELETE FROM rp_vendors WHERE id=?")->execute([$_POST['id']]);
        header("Location: admin.php?page=vendors&msg=Vendor+deleted");
        exit();
    }
    // Delete User
    if ($action === 'delete_user' && rp_is_superadmin()) {
        if ($_POST['id'] != $user['id']) {
            rp_log_audit($db, 'delete_user', 'User ID: ' . ($_POST['id'] ?? '?'));
            $db->prepare("DELETE FROM rp_users WHERE id=?")->execute([$_POST['id']]);
        }
        header("Location: admin.php?page=team&msg=User+deleted");
        exit();
    }
    // Save Project
    if ($action === 'save_project' && rp_is_manager()) {
        rp_ensure_project_extra_columns($db);
        $id = (int)($_POST['id'] ?? 0);
        $client_id = (int)($_POST['client_id'] ?? 0);
        $client_name = '';
        if ($client_id > 0) {
            $client_row = $db->prepare("SELECT client_name FROM rp_clients WHERE id=?");
            $client_row->execute([$client_id]);
            $client_name = $client_row->fetchColumn() ?: '';
            if ($client_name === '') $client_id = 0; // client_id didn't match any real client
        }
        // Sanitize SID — only letters, numbers, underscore, hyphen allowed.
        // Anything else (spaces, &, =, ?, /, #, etc.) would break the redirect
        // URLs that get built with this SID embedded in a query string.
        $clean_sid = preg_replace('/[^A-Za-z0-9_\-]/', '', trim($_POST['sid'] ?? ''));
        $data = [
            ':sid'          => strtoupper($clean_sid),
            ':project_name' => trim($_POST['project_name']),
            ':client_id'    => $client_id > 0 ? $client_id : null,
            ':client_name'  => $client_name,
            ':cpi'          => (float)($_POST['cpi'] ?? 0),
            ':supplier_cpi' => (float)($_POST['supplier_cpi'] ?? 0),
            ':ir'           => (float)($_POST['ir'] ?? 0),
            ':loi'          => (int)($_POST['loi'] ?? 0),
            ':max_completes'=> (int)($_POST['max_completes'] ?? 0),
            ':live_url'     => trim($_POST['live_url'] ?? ''),
            ':test_url'     => trim($_POST['test_url'] ?? ''),
            ':status'       => $_POST['status'] ?? 'active',
            ':project_type' => $_POST['project_type'] ?? 'direct',
            ':encrypt_uid'  => isset($_POST['encrypt_uid']) ? 1 : 0,
            ':description'  => trim($_POST['description'] ?? ''),
            ':target_countries' => trim($_POST['target_countries'] ?? ''),
        ];
        if (empty($data[':sid'])) {
            header("Location: admin.php?page=projects&msg=Error:+Project+ID+(SID)+is+invalid+or+empty+after+removing+special+characters");
            exit();
        }
        if ($id > 0) {
            $sql = "UPDATE rp_projects SET sid=:sid, project_name=:project_name, client_id=:client_id, client_name=:client_name, cpi=:cpi, supplier_cpi=:supplier_cpi, ir=:ir, loi=:loi, max_completes=:max_completes, live_url=:live_url, test_url=:test_url, status=:status, project_type=:project_type, encrypt_uid=:encrypt_uid, description=:description, target_countries=:target_countries WHERE id=$id";
        } else {
            $sql = "INSERT INTO rp_projects (sid, project_name, client_id, client_name, cpi, supplier_cpi, ir, loi, max_completes, live_url, test_url, status, project_type, encrypt_uid, description, target_countries) VALUES (:sid,:project_name,:client_id,:client_name,:cpi,:supplier_cpi,:ir,:loi,:max_completes,:live_url,:test_url,:status,:project_type,:encrypt_uid,:description,:target_countries)";
        }
        try {
            $db->prepare($sql)->execute($data);
        } catch (PDOException $e) {
            // Likely a duplicate SID (UNIQUE constraint) — show a friendly message instead of a raw DB error
            header("Location: admin.php?page=projects&msg=Error:+A+project+with+this+SID+already+exists");
            exit();
        }
        header("Location: admin.php?page=projects&msg=Project+saved");
        exit();
    }

    // ── BULK PROJECT IMPORT (CSV) ──────────────────────────────
    // Lets a manager create many projects in one go instead of filling the
    // Add Project form individually for each one — genuinely useful when a
    // client sends a batch of surveys at once. Matches the SAME sid-cleaning
    // (uppercase, strip special chars) and update-vs-insert logic as the
    // single-project form above, so behavior stays fully consistent.
    if ($action === 'bulk_import_projects' && rp_is_manager()) {
        $results = ['created' => 0, 'updated' => 0, 'errors' => []];
        if (!empty($_FILES['bulk_csv']['tmp_name']) && is_uploaded_file($_FILES['bulk_csv']['tmp_name'])) {
            $fh = fopen($_FILES['bulk_csv']['tmp_name'], 'r');
            if ($fh) {
                $header = fgetcsv($fh);
                $header = array_map(fn($h) => strtolower(trim($h ?? '')), $header ?: []);
                $col = array_flip($header);
                $row_num = 1;
                while (($row = fgetcsv($fh)) !== false) {
                    $row_num++;
                    $get = fn($key) => isset($col[$key], $row[$col[$key]]) ? trim($row[$col[$key]]) : '';
                    $raw_sid = $get('sid');
                    if (!$raw_sid) { continue; } // skip genuinely blank rows
                    $clean_sid = strtoupper(preg_replace('/[^A-Za-z0-9_\-]/', '', $raw_sid));
                    if (!$clean_sid) {
                        $results['errors'][] = "Row $row_num (SID: $raw_sid): invalid SID after cleaning — became empty.";
                        continue;
                    }
                    $project_name = $get('project_name') ?: $clean_sid;
                    $cpi = $get('cpi') !== '' ? (float)$get('cpi') : 0;
                    $max_completes = $get('max_completes') !== '' ? (int)$get('max_completes') : 0;
                    $live_url = $get('live_url');
                    $client_name = $get('client_name');
                    $client_id = null;
                    if ($client_name) {
                        $cc = $db->prepare("SELECT id FROM rp_clients WHERE client_name = ? LIMIT 1");
                        $cc->execute([$client_name]);
                        $client_id = $cc->fetchColumn();
                        if (!$client_id) {
                            // Genuinely new client name — create it rather than silently
                            // dropping the association.
                            $db->prepare("INSERT INTO rp_clients (client_name, status) VALUES (?, 'active')")->execute([$client_name]);
                            $client_id = $db->lastInsertId();
                        }
                    }
                    try {
                        $existing = $db->prepare("SELECT id FROM rp_projects WHERE sid = ?");
                        $existing->execute([$clean_sid]);
                        $existing_id = $existing->fetchColumn();

                        if ($existing_id) {
                            $db->prepare("UPDATE rp_projects SET project_name=?, client_id=?, client_name=?, cpi=?, max_completes=?, live_url=? WHERE id=?")
                               ->execute([$project_name, $client_id, $client_name, $cpi, $max_completes, $live_url, $existing_id]);
                            $results['updated']++;
                        } else {
                            $db->prepare("INSERT INTO rp_projects (sid, project_name, client_id, client_name, cpi, max_completes, live_url, status, project_type, encrypt_uid) VALUES (?,?,?,?,?,?,?,'active','direct',1)")
                               ->execute([$clean_sid, $project_name, $client_id, $client_name, $cpi, $max_completes, $live_url]);
                            $results['created']++;
                        }
                    } catch (PDOException $e) {
                        $results['errors'][] = "Row $row_num (SID: $clean_sid): " . $e->getMessage();
                    }
                }
                fclose($fh);
            }
        }
        $_SESSION['bulk_import_results'] = $results;
        header("Location: admin.php?page=projects&bulk_import_done=1");
        exit();
    }
    // Save Client
    if ($action === 'save_client' && rp_is_manager()) {
        rp_ensure_client_extra_columns($db);
        $id = (int)($_POST['id'] ?? 0);
        $data = [
            ':client_name' => trim($_POST['client_name']),
            ':email'       => trim($_POST['email'] ?? ''),
            ':phone'       => trim($_POST['phone'] ?? ''),
            ':company'     => trim($_POST['company'] ?? ''),
            ':status'      => $_POST['status'] ?? 'active',
        ];
        if ($id > 0) {
            $db->prepare("UPDATE rp_clients SET client_name=:client_name, email=:email, phone=:phone, company=:company, status=:status WHERE id=$id")->execute($data);
        } else {
            // New client - also generate a unique client_uid for client-level redirect URLs
            $data[':client_uid'] = rp_generate_client_uid($db);
            $db->prepare("INSERT INTO rp_clients (client_name, email, phone, company, status, client_uid) VALUES (:client_name,:email,:phone,:company,:status,:client_uid)")->execute($data);
        }
        header("Location: admin.php?page=clients&msg=Client+saved");
        exit();
    }
    // Save Vendor
    if ($action === 'save_vendor' && rp_is_manager()) {
        rp_ensure_vendor_end_behavior_column($db);
        $id = (int)($_POST['id'] ?? 0);
        $data = [
            ':vendor_name'   => trim($_POST['vendor_name']),
            ':email'         => trim($_POST['email'] ?? ''),
            ':phone'         => trim($_POST['phone'] ?? ''),
            ':complete_url'  => trim($_POST['complete_url'] ?? ''),
            ':terminate_url' => trim($_POST['terminate_url'] ?? ''),
            ':screenout_url' => trim($_POST['screenout_url'] ?? ''),
            ':quotafull_url' => trim($_POST['quotafull_url'] ?? ''),
            ':end_behavior'  => in_array($_POST['end_behavior'] ?? '', ['show_page','redirect']) ? $_POST['end_behavior'] : 'show_page',
            ':status'        => $_POST['status'] ?? 'active',
        ];
        if ($id > 0) {
            $db->prepare("UPDATE rp_vendors SET vendor_name=:vendor_name, email=:email, phone=:phone, complete_url=:complete_url, terminate_url=:terminate_url, screenout_url=:screenout_url, quotafull_url=:quotafull_url, end_behavior=:end_behavior, status=:status WHERE id=$id")->execute($data);
        } else {
            $db->prepare("INSERT INTO rp_vendors (vendor_name, email, phone, complete_url, terminate_url, screenout_url, quotafull_url, end_behavior, status) VALUES (:vendor_name,:email,:phone,:complete_url,:terminate_url,:screenout_url,:quotafull_url,:end_behavior,:status)")->execute($data);
        }
        header("Location: admin.php?page=vendors&msg=Vendor+saved");
        exit();
    }
    // Save User
    if ($action === 'save_user' && rp_is_superadmin()) {
        $id = (int)($_POST['id'] ?? 0);
        $name  = trim($_POST['name']);
        $email = trim($_POST['email']);
        $role  = $_POST['role'] ?? 'viewer';
        $pass  = trim($_POST['password'] ?? '');
        if ($id > 0) {
            if (!empty($pass)) {
                $db->prepare("UPDATE rp_users SET name=?, email=?, role=?, password=? WHERE id=?")->execute([$name, $email, $role, password_hash($pass, PASSWORD_DEFAULT), $id]);
            } else {
                $db->prepare("UPDATE rp_users SET name=?, email=?, role=? WHERE id=?")->execute([$name, $email, $role, $id]);
            }
        } else {
            $db->prepare("INSERT INTO rp_users (name, email, role, password) VALUES (?,?,?,?)")->execute([$name, $email, $role, password_hash($pass, PASSWORD_DEFAULT)]);
        }
        header("Location: admin.php?page=team&msg=User+saved");
        exit();
    }
    // Assign Vendor to Project
    if ($action === 'assign_vendor' && rp_is_manager()) {
        rp_ensure_short_code_column($db);
        $pid = (int)$_POST['project_id'];
        $vid = (int)$_POST['vendor_id'];
        $cpi = (float)($_POST['cpi'] ?? 0);
        $lim = (int)($_POST['max_limit'] ?? 0);
        $short_code = rp_generate_short_code($db);
        $stmt = $db->prepare("INSERT IGNORE INTO rp_project_vendors (project_id, vendor_id, cpi, max_limit, short_code) VALUES (?,?,?,?,?)");
        $stmt->execute([$pid, $vid, $cpi, $lim, $short_code]);
        header("Location: admin.php?page=project_view&id=$pid&msg=Vendor+assigned");
        exit();
    }
}

// ── LOGOUT ───────────────────────────────────────────────────
if ($page === 'logout') {
    rp_session_start();
    session_destroy();
    header('Location: login.php');
    exit();
}

// ── FETCH DATA FOR PAGES ─────────────────────────────────────

// Dashboard stats
$stats = [];
if ($page === 'dashboard') {
    $stats['total_clicks']    = $db->query("SELECT COUNT(*) FROM rp_leads")->fetchColumn();
    $stats['total_completes'] = $db->query("SELECT COUNT(*) FROM rp_leads WHERE status='complete'")->fetchColumn();
    $stats['total_terminates']= $db->query("SELECT COUNT(*) FROM rp_leads WHERE status='terminate'")->fetchColumn();
    $stats['total_overquota'] = $db->query("SELECT COUNT(*) FROM rp_leads WHERE status='overquota'")->fetchColumn();
    $stats['total_quality_fail'] = $db->query("SELECT COUNT(*) FROM rp_leads WHERE status='quality_fail'")->fetchColumn();
    $stats['active_projects'] = $db->query("SELECT COUNT(*) FROM rp_projects WHERE status='active'")->fetchColumn();
    $stats['active_vendors']  = $db->query("SELECT COUNT(*) FROM rp_vendors WHERE status='active'")->fetchColumn();
    $stats['total_clients']   = $db->query("SELECT COUNT(*) FROM rp_clients WHERE status='active'")->fetchColumn();
    $stats['avg_loi_seconds'] = (float)$db->query("SELECT AVG(loi_seconds) FROM rp_leads WHERE status='complete' AND loi_seconds IS NOT NULL")->fetchColumn();
    $stats['conversion_rate'] = $stats['total_clicks'] > 0 ? round(($stats['total_completes'] / $stats['total_clicks']) * 100, 1) : 0;

    // Custom date-range for the trend chart (default: last 7 days)
    $range_to   = trim($_GET['date_to']   ?? '') ?: date('Y-m-d');
    $range_from = trim($_GET['date_from'] ?? '') ?: date('Y-m-d', strtotime('-6 days'));
    if (strtotime($range_from) > strtotime($range_to)) {
        [$range_from, $range_to] = [$range_to, $range_from]; // swap if reversed
    }
    // Safety cap: max 90 days in one view
    if ((strtotime($range_to) - strtotime($range_from)) / 86400 > 90) {
        $range_from = date('Y-m-d', strtotime($range_to . ' -90 days'));
    }

    $chart_data = [];
    $cursor = $range_from;
    while (strtotime($cursor) <= strtotime($range_to)) {
        $label = date('d M', strtotime($cursor));
        $clicks    = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE DATE(created_at)=?");
        $clicks->execute([$cursor]); $c = $clicks->fetchColumn();
        $completes = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE DATE(created_at)=? AND status='complete'");
        $completes->execute([$cursor]); $co = $completes->fetchColumn();
        $chart_data[] = ['label'=>$label,'clicks'=>$c,'completes'=>$co];
        $cursor = date('Y-m-d', strtotime($cursor . ' +1 day'));
    }

    // Status breakdown (for donut chart)
    $status_labels_map = ['complete'=>'Complete','terminate'=>'Terminate','overquota'=>'Quota Full','quality_fail'=>'Quality Fail','click'=>'Click','pending'=>'Pending'];
    $status_rows = $db->query("SELECT status, COUNT(*) AS c FROM rp_leads GROUP BY status")->fetchAll();
    $status_breakdown = [];
    foreach ($status_rows as $sr) {
        $key = $sr['status'] ?: 'click';
        $status_breakdown[$status_labels_map[$key] ?? ucfirst($key)] = (int)$sr['c'];
    }

    // Device split (for donut chart)
    $device_rows = $db->query("SELECT COALESCE(NULLIF(device,''),'unknown') AS device, COUNT(*) AS c FROM rp_leads GROUP BY device")->fetchAll();
    $device_breakdown = [];
    foreach ($device_rows as $dr) {
        $device_breakdown[ucfirst($dr['device'])] = (int)$dr['c'];
    }

    // Hourly trend for today
    $hourly_data = [];
    for ($h = 0; $h < 24; $h++) {
        $hcount = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE DATE(created_at)=CURDATE() AND HOUR(created_at)=?");
        $hcount->execute([$h]);
        $hourly_data[] = (int)$hcount->fetchColumn();
    }
}

// Projects list
$projects = [];
if ($page === 'projects') {
    rp_ensure_project_extra_columns($db);
    $proj_search = trim($_GET['psearch'] ?? '');
    if ($proj_search) {
        $like = "%$proj_search%";
        $projects = $db->prepare("SELECT p.*, c.client_name as cname FROM rp_projects p LEFT JOIN rp_clients c ON p.client_id=c.id
                                   WHERE p.project_name LIKE ? OR p.sid LIKE ? OR c.client_name LIKE ?
                                   ORDER BY p.is_pinned DESC, p.id DESC");
        $projects->execute([$like, $like, $like]);
        $projects = $projects->fetchAll();
    } else {
        $projects = $db->query("SELECT p.*, c.client_name as cname FROM rp_projects p LEFT JOIN rp_clients c ON p.client_id=c.id ORDER BY p.is_pinned DESC, p.id DESC")->fetchAll();
    }

    // ── Distinct-vendor-count per project ──────────────────────
    // Matches Kishan's panel's "Vendors" column — how many distinct
    // vendors are sending traffic to each project, at a glance.
    $proj_vendor_counts = [];
    $pvc = $db->query("SELECT project_id, COUNT(DISTINCT vendor_id) AS vendor_count FROM rp_project_vendors WHERE status='active' GROUP BY project_id");
    while ($row = $pvc->fetch()) { $proj_vendor_counts[$row['project_id']] = $row['vendor_count']; }
}

// Project view
$project_view = null;
$project_vendors = [];
$all_vendors_for_assign = [];
if ($page === 'project_view') {
    rp_ensure_project_extra_columns($db);
    rp_ensure_short_code_column($db);
    $pid = (int)($_GET['id'] ?? 0);
    $project_view = $db->prepare("SELECT * FROM rp_projects WHERE id=?");
    $project_view->execute([$pid]);
    $project_view = $project_view->fetch();
    if ($project_view) {
        // Backfill short_code for any existing assignments that don't have one yet
        $missing_codes = $db->prepare("SELECT id FROM rp_project_vendors WHERE project_id=? AND (short_code IS NULL OR short_code='')");
        $missing_codes->execute([$pid]);
        foreach ($missing_codes->fetchAll() as $mrow) {
            $newCode = rp_generate_short_code($db);
            $db->prepare("UPDATE rp_project_vendors SET short_code=? WHERE id=?")->execute([$newCode, $mrow['id']]);
        }
        $project_vendors = $db->prepare("SELECT pv.*, v.vendor_name, v.email FROM rp_project_vendors pv JOIN rp_vendors v ON pv.vendor_id=v.id WHERE pv.project_id=?");
        $project_vendors->execute([$pid]);
        $project_vendors = $project_vendors->fetchAll();
        $assigned_ids = array_column($project_vendors, 'vendor_id');
        $all_vendors_for_assign = $db->query("SELECT * FROM rp_vendors WHERE status='active' ORDER BY vendor_name")->fetchAll();
        $all_vendors_for_assign = array_filter($all_vendors_for_assign, fn($v) => !in_array($v['id'], $assigned_ids));
        // Leads for this project
        $project_leads = $db->prepare("SELECT * FROM rp_leads WHERE sid=? ORDER BY id DESC LIMIT 100");
        $project_leads->execute([$project_view['sid']]);
        $project_leads = $project_leads->fetchAll();
        // Client share links
        rp_ensure_share_table($db);
        $pv_share_links = $db->prepare("SELECT * FROM rp_share_links WHERE project_id=? ORDER BY id DESC");
        $pv_share_links->execute([$pid]);
        $pv_share_links = $pv_share_links->fetchAll();

        // ── VENDOR BREAKDOWN (per-vendor stats for THIS project) ──
        // Matches Kishan's panel's "Vendor Breakdown" — same fix ported
        // to ExaVerify and the Node.js tool this round — every vendor
        // working on this project, with clicks/completes/terminates/
        // quality-fail/overquota counts + conversion%, in one place.
        $vendor_breakdown = $db->prepare("SELECT
                COALESCE(v.vendor_name, 'No Vendor / Direct') AS vendor_name,
                v.id AS vendor_id,
                COUNT(*) AS clicks,
                SUM(CASE WHEN l.status='complete' THEN 1 ELSE 0 END) AS completes,
                SUM(CASE WHEN l.status='terminate' THEN 1 ELSE 0 END) AS terminates,
                SUM(CASE WHEN l.status='quality_fail' THEN 1 ELSE 0 END) AS quality_fail,
                SUM(CASE WHEN l.status='overquota' THEN 1 ELSE 0 END) AS overquota
            FROM rp_leads l
            LEFT JOIN rp_vendors v ON v.id = l.vendor_id
            WHERE l.sid = ?
            GROUP BY v.id, v.vendor_name
            ORDER BY clicks DESC");
        $vendor_breakdown->execute([$project_view['sid']]);
        $vendor_breakdown = $vendor_breakdown->fetchAll();
    }
}

// Clients
$clients = [];
if ($page === 'clients') {
    rp_ensure_client_extra_columns($db);
    // Backfill client_uid for any existing clients that don't have one yet
    // (e.g. clients created before this feature existed)
    $missing = $db->query("SELECT id FROM rp_clients WHERE client_uid IS NULL OR client_uid=''")->fetchAll();
    foreach ($missing as $mrow) {
        $newUid = rp_generate_client_uid($db);
        $db->prepare("UPDATE rp_clients SET client_uid=? WHERE id=?")->execute([$newUid, $mrow['id']]);
    }
    $clients = $db->query("SELECT * FROM rp_clients ORDER BY id DESC")->fetchAll();
}

// Vendors
$vendors = [];
if ($page === 'vendors') {
    rp_ensure_vendor_end_behavior_column($db);
    $vendors = $db->query("SELECT * FROM rp_vendors ORDER BY id DESC")->fetchAll();

    // ── VENDOR PERFORMANCE SUMMARY ────────────────────────────
    // Single aggregate query instead of per-row queries (efficient)
    $vperf_rows = $db->query("
        SELECT vendor_id,
               COUNT(*) AS clicks,
               SUM(CASE WHEN status='complete'  THEN 1 ELSE 0 END) AS completes,
               SUM(CASE WHEN status='terminate' THEN 1 ELSE 0 END) AS terminates
        FROM rp_leads
        WHERE vendor_id IS NOT NULL
        GROUP BY vendor_id
    ")->fetchAll();
    $vendor_perf = [];
    foreach ($vperf_rows as $row) {
        $conv = $row['clicks'] > 0 ? round(($row['completes'] / $row['clicks']) * 100, 1) : 0;
        $vendor_perf[$row['vendor_id']] = [
            'clicks'     => (int)$row['clicks'],
            'completes'  => (int)$row['completes'],
            'terminates' => (int)$row['terminates'],
            'conv'       => $conv,
        ];
    }

    // ── Distinct-projects-count per vendor ─────────────────────
    // Matches Kishan's panel's "Projects" column — how many distinct
    // projects each vendor is currently active on, without opening
    // vendor_view individually.
    $vendor_proj_counts = [];
    $vpc = $db->query("SELECT vendor_id, COUNT(DISTINCT project_id) AS proj_count FROM rp_project_vendors WHERE status='active' GROUP BY vendor_id");
    while ($row = $vpc->fetch()) { $vendor_proj_counts[$row['vendor_id']] = $row['proj_count']; }

    // Overall summary across all vendors
    $vsum_clicks    = array_sum(array_column($vendor_perf, 'clicks'));
    $vsum_completes = array_sum(array_column($vendor_perf, 'completes'));
    $vsum_conv      = $vsum_clicks > 0 ? round(($vsum_completes / $vsum_clicks) * 100, 1) : 0;

    // Top performing vendor (highest conversion %, minimum 1 click)
    $vtop_vendor = null;
    $vtop_conv   = -1;
    foreach ($vendor_perf as $vid_key => $perf) {
        if ($perf['clicks'] > 0 && $perf['conv'] > $vtop_conv) {
            $vtop_conv = $perf['conv'];
            $vtop_vendor = $vid_key;
        }
    }
    $vtop_vendor_name = '—';
    if ($vtop_vendor) {
        foreach ($vendors as $v) {
            if ($v['id'] == $vtop_vendor) { $vtop_vendor_name = $v['vendor_name']; break; }
        }
    }
}

// Vendor Detail View
$vendor_view = null;
$vendor_leads = [];
$vendor_projects = [];
if ($page === 'vendor_view') {
    $vid = (int)($_GET['id'] ?? 0);
    $vs = $db->prepare("SELECT * FROM rp_vendors WHERE id=?");
    $vs->execute([$vid]);
    $vendor_view = $vs->fetch();
    if ($vendor_view) {
        // Per-vendor search/filter - by status (Complete/Terminate/Quotafull/etc)
        // and/or by respondent UID, scoped to just this vendor's own leads.
        $vv_status = $_GET['vstatus'] ?? '';
        $vv_search = trim($_GET['vsearch'] ?? '');
        $vv_where = 'l.vendor_id=?';
        $vv_params = [$vid];
        if ($vv_status) { $vv_where .= ' AND l.status=?'; $vv_params[] = $vv_status; }
        if ($vv_search) { $vv_where .= ' AND l.original_uid LIKE ?'; $vv_params[] = "%$vv_search%"; }
        $vl = $db->prepare("SELECT l.*, p.project_name FROM rp_leads l LEFT JOIN rp_projects p ON l.sid=p.sid WHERE $vv_where ORDER BY l.id DESC LIMIT 200");
        $vl->execute($vv_params);
        $vendor_leads = $vl->fetchAll();
        $vp = $db->prepare("SELECT pv.*, p.project_name, p.sid FROM rp_project_vendors pv JOIN rp_projects p ON pv.project_id=p.id WHERE pv.vendor_id=?");
        $vp->execute([$vid]);
        $vendor_projects = $vp->fetchAll();
    }
}

// Leads
$leads = [];
$leads_total = 0;
if ($page === 'leads') {
    $search = trim($_GET['search'] ?? '');
    $status_filter = $_GET['status'] ?? '';
    $project_filter = $_GET['sid'] ?? '';
    $device_filter = $_GET['device'] ?? '';
    $vendor_filter = $_GET['vendor_id'] ?? '';
    $client_filter = (int)($_GET['client_id'] ?? 0);
    $country_filter = trim($_GET['country'] ?? '');
    $date_from = trim($_GET['date_from'] ?? '');
    $date_to = trim($_GET['date_to'] ?? '');
    $lpage = max(1, (int)($_GET['lpage'] ?? 1));
    $limit = 50;
    $offset = ($lpage - 1) * $limit;
    $where = '1=1';
    $params = [];
    if ($search) { $where .= " AND (l.original_uid LIKE ? OR l.sid LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
    if ($status_filter) { $where .= " AND l.status=?"; $params[] = $status_filter; }
    if ($project_filter) { $where .= " AND l.sid=?"; $params[] = $project_filter; }
    if ($device_filter) { $where .= " AND l.device=?"; $params[] = $device_filter; }
    if ($vendor_filter) { $where .= " AND l.vendor_id=?"; $params[] = $vendor_filter; }
    if ($client_filter) { $where .= " AND p.client_id=?"; $params[] = $client_filter; }
    if ($country_filter) { $where .= " AND l.country=?"; $params[] = $country_filter; }
    if ($date_from) { $where .= " AND DATE(l.created_at) >= ?"; $params[] = $date_from; }
    if ($date_to) { $where .= " AND DATE(l.created_at) <= ?"; $params[] = $date_to; }
    $count_stmt = $db->prepare("SELECT COUNT(*) FROM rp_leads l LEFT JOIN rp_projects p ON l.sid=p.sid WHERE $where");
    $count_stmt->execute($params);
    $leads_total = $count_stmt->fetchColumn();
    $stmt = $db->prepare("SELECT l.*, p.project_name, p.client_name, v.vendor_name FROM rp_leads l LEFT JOIN rp_projects p ON l.sid=p.sid LEFT JOIN rp_vendors v ON v.id=l.vendor_id WHERE $where ORDER BY l.id DESC LIMIT $limit OFFSET $offset");
    $stmt->execute($params);
    $leads = $stmt->fetchAll();
    // For filter dropdowns
    $leads_all_projects = $db->query("SELECT sid, project_name FROM rp_projects ORDER BY project_name")->fetchAll();
    $leads_all_vendors = $db->query("SELECT id, vendor_name FROM rp_vendors ORDER BY vendor_name")->fetchAll();
    $leads_all_countries = $db->query("SELECT DISTINCT country FROM rp_leads WHERE country IS NOT NULL AND country != '' ORDER BY country")->fetchAll(PDO::FETCH_COLUMN);
}

// Team
$team_users = [];
if ($page === 'team') {
    $team_users = $db->query("SELECT * FROM rp_users ORDER BY id ASC")->fetchAll();
}

// All clients for dropdowns
$all_clients = $db->query("SELECT id, client_name FROM rp_clients WHERE status='active' ORDER BY client_name")->fetchAll();
$all_vendors = $db->query("SELECT id, vendor_name FROM rp_vendors WHERE status='active' ORDER BY vendor_name")->fetchAll();

// Global Search
$search_results = [];
$search_query = '';
if ($page === 'global_search' && isset($_GET['q'])) {
    $search_query = trim($_GET['q']);
    if ($search_query) {
        $sr = $db->prepare("SELECT l.*, p.project_name FROM rp_leads l LEFT JOIN rp_projects p ON l.sid=p.sid WHERE l.original_uid LIKE ? OR l.sid LIKE ? OR l.country LIKE ? OR l.ip LIKE ? ORDER BY l.id DESC LIMIT 100");
        $sr->execute(["%$search_query%", "%$search_query%", "%$search_query%", "%$search_query%"]);
        $search_results = $sr->fetchAll();
    }
}

// Screener Data
$screener_data = [];
$screener_total = 0;
if ($page === 'screener') {
    $sc_sid = trim($_GET['sc_sid'] ?? '');
    $sc_page = max(1, (int)($_GET['sc_page'] ?? 1));
    $sc_limit = 50;
    $sc_offset = ($sc_page - 1) * $sc_limit;
    $where = '1=1';
    $params = [];
    if ($sc_sid) { $where .= " AND sid=?"; $params[] = $sc_sid; }
    $cnt = $db->prepare("SELECT COUNT(*) FROM rp_prescreener_answers WHERE $where");
    $cnt->execute($params);
    $screener_total = $cnt->fetchColumn();
    $sc = $db->prepare("SELECT * FROM rp_prescreener_answers WHERE $where ORDER BY id DESC LIMIT $sc_limit OFFSET $sc_offset");
    $sc->execute($params);
    $screener_data = $sc->fetchAll();
}

// ── QUALITY FLAGS (Speeder + Duplicate Detection) ─────────────
if ($page === 'quality_flags') {
    // Duplicates — same UID clicked more than once for a project
    $qf_dupes = $db->query("
        SELECT l.*, p.project_name
        FROM rp_leads l
        LEFT JOIN rp_projects p ON l.sid = p.sid
        WHERE l.is_duplicate = 1
        ORDER BY l.id DESC
        LIMIT 200
    ")->fetchAll();

    // Speeders — completed in under 30% of the project's expected LOI
    $qf_speeders = $db->query("
        SELECT l.*, p.project_name, p.loi AS expected_loi
        FROM rp_leads l
        LEFT JOIN rp_projects p ON l.sid = p.sid
        WHERE l.status = 'complete'
          AND l.loi_seconds IS NOT NULL
          AND p.loi > 0
          AND l.loi_seconds < (p.loi * 60 * 0.3)
        ORDER BY l.id DESC
        LIMIT 200
    ")->fetchAll();

    $qf_dupe_count    = count($qf_dupes);
    $qf_speeder_count = count($qf_speeders);
}

// ── ALERT SETTINGS ─────────────────────────────────────────────
if ($page === 'alert_settings' && rp_is_superadmin()) {
    $alert_telegram_token = rp_get_setting($db, 'telegram_bot_token');
    $alert_telegram_chat  = rp_get_setting($db, 'telegram_chat_id');
    $alert_email_addr     = rp_get_setting($db, 'alert_email');
}

// ── AUDIT LOG ────────────────────────────────────────────────────
if ($page === 'audit_log' && rp_is_superadmin()) {
    rp_ensure_audit_table($db);
    $audit_rows = $db->query("SELECT * FROM rp_audit_log ORDER BY id DESC LIMIT 300")->fetchAll();
}

// ── NOTES ─────────────────────────────────────────────────────────
if ($page === 'notes') {
    rp_ensure_notes_table($db);
    $all_notes = $db->query("SELECT * FROM rp_notes ORDER BY updated_at DESC")->fetchAll();
}

// ── BILLING / INVOICE TRACKER ──────────────────────────────────
if ($page === 'billing') {
    rp_ensure_invoice_table($db);
    rp_ensure_project_extra_columns($db);
    $billing_rows = $db->query("
        SELECT p.id, p.sid, p.project_name, p.client_name, p.cpi, p.supplier_cpi,
               COALESCE(SUM(CASE WHEN l.status='complete' THEN 1 ELSE 0 END), 0) AS completes,
               COALESCE(inv.status, 'unpaid') AS invoice_status,
               inv.notes AS invoice_notes
        FROM rp_projects p
        LEFT JOIN rp_leads l ON l.sid = p.sid
        LEFT JOIN rp_invoice_status inv ON inv.project_id = p.id
        GROUP BY p.id
        ORDER BY p.id DESC
    ")->fetchAll();

    $billing_grand_total = 0;   // Revenue (client-facing) — kept for backward compatibility
    $billing_grand_revenue = 0;
    $billing_grand_cost = 0;
    $billing_grand_margin = 0;
    foreach ($billing_rows as &$br) {
        $br['revenue'] = round($br['completes'] * $br['cpi'], 2);
        $br['cost']    = round($br['completes'] * $br['supplier_cpi'], 2);
        $br['margin']  = round($br['revenue'] - $br['cost'], 2);
        $br['total']   = $br['revenue']; // legacy alias, still used elsewhere
        $billing_grand_total    += $br['revenue'];
        $billing_grand_revenue  += $br['revenue'];
        $billing_grand_cost     += $br['cost'];
        $billing_grand_margin   += $br['margin'];
    }
    unset($br);
}

// ── QUALITY SCORE MODULE ────────────────────────────────────────
if ($page === 'quality_score') {
    $qs_leads = $db->query("
        SELECT l.*, p.project_name, p.loi AS expected_loi, v.vendor_name,
               pa.open_end
        FROM rp_leads l
        LEFT JOIN rp_projects p ON l.sid = p.sid
        LEFT JOIN rp_vendors v ON l.vendor_id = v.id
        LEFT JOIN rp_prescreener_answers pa ON pa.sid = l.sid AND pa.original_uid = l.original_uid
        WHERE l.status = 'complete'
        ORDER BY l.id DESC
        LIMIT 500
    ")->fetchAll();

    // Score each completed lead (100 = perfect, deduct for red flags)
    foreach ($qs_leads as &$ql) {
        $score = 100;
        $reasons = [];
        if (!empty($ql['is_duplicate'])) { $score -= 40; $reasons[] = 'Duplicate'; }
        if (!empty($ql['expected_loi']) && !empty($ql['loi_seconds'])) {
            $expected_sec = (int)$ql['expected_loi'] * 60;
            if ($expected_sec > 0 && $ql['loi_seconds'] < ($expected_sec * 0.3)) {
                $score -= 40; $reasons[] = 'Speeder';
            }
        }
        if (array_key_exists('open_end', $ql) && strlen(trim((string)$ql['open_end'])) < 10) {
            $score -= 20; $reasons[] = 'Weak open-end answer';
        }
        $ql['quality_score']   = max(0, $score);
        $ql['quality_reasons'] = $reasons ?: ['Clean'];
    }
    unset($ql);

    // Per-vendor average quality score
    $qs_vendor_scores = [];
    foreach ($qs_leads as $ql) {
        $vkey = $ql['vendor_name'] ?: 'Direct / No Vendor';
        if (!isset($qs_vendor_scores[$vkey])) $qs_vendor_scores[$vkey] = ['total'=>0,'count'=>0];
        $qs_vendor_scores[$vkey]['total'] += $ql['quality_score'];
        $qs_vendor_scores[$vkey]['count']++;
    }
    foreach ($qs_vendor_scores as &$vs) {
        $vs['avg'] = $vs['count'] > 0 ? round($vs['total'] / $vs['count'], 1) : 0;
    }
    unset($vs);
    uasort($qs_vendor_scores, fn($a,$b) => $b['avg'] <=> $a['avg']);

    $qs_overall_avg = count($qs_leads) > 0 ? round(array_sum(array_column($qs_leads, 'quality_score')) / count($qs_leads), 1) : 0;
}

// ── RECONCILE MODULE ────────────────────────────────────────────
$reconcile_results = null;
$reconcile_summary = null;
if ($page === 'reconcile') {
    $all_projects_list = $db->query("SELECT id, sid, project_name FROM rp_projects ORDER BY project_name")->fetchAll();

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reconcile_upload'
        && !empty($_FILES['reconcile_file']['tmp_name'])) {

        $rc_sid = trim($_POST['reconcile_sid'] ?? '');
        $fh = fopen($_FILES['reconcile_file']['tmp_name'], 'r');
        $rows = [];
        if ($fh) {
            $header = fgetcsv($fh);
            $header = array_map(fn($h) => strtolower(trim($h)), $header ?: []);
            $uid_idx    = array_search('uid', $header);
            $status_idx = array_search('status', $header);
            if ($uid_idx === false) $uid_idx = 0;
            if ($status_idx === false) $status_idx = 1;

            while (($row = fgetcsv($fh)) !== false) {
                if (empty($row[$uid_idx])) continue;
                $rows[] = ['uid' => trim($row[$uid_idx]), 'file_status' => trim($row[$status_idx] ?? '')];
            }
            fclose($fh);
        }

        // Fetch our system's leads for this project into a lookup map
        $sys_leads = [];
        if ($rc_sid) {
            $sl = $db->prepare("SELECT original_uid, status FROM rp_leads WHERE sid = ?");
            $sl->execute([$rc_sid]);
            foreach ($sl->fetchAll() as $row) {
                $sys_leads[$row['original_uid']] = $row['status'];
            }
        }

        $matched = 0; $mismatched = 0; $missing_in_system = 0;
        $reconcile_results = [];
        foreach ($rows as $r) {
            $sys_status = $sys_leads[$r['uid']] ?? null;
            if ($sys_status === null) {
                $status = 'missing_in_system'; $missing_in_system++;
            } elseif (strtolower($sys_status) === strtolower($r['file_status'])) {
                $status = 'match'; $matched++;
            } else {
                $status = 'mismatch'; $mismatched++;
            }
            $reconcile_results[] = [
                'uid' => $r['uid'], 'file_status' => $r['file_status'],
                'system_status' => $sys_status, 'result' => $status,
            ];
            unset($sys_leads[$r['uid']]);
        }
        // Anything left in $sys_leads exists in our system but wasn't in the uploaded file
        $missing_in_file = count($sys_leads);
        foreach ($sys_leads as $uid => $sstatus) {
            $reconcile_results[] = [
                'uid' => $uid, 'file_status' => '—', 'system_status' => $sstatus, 'result' => 'missing_in_file',
            ];
        }

        $reconcile_summary = [
            'total_file_rows'    => count($rows),
            'matched'            => $matched,
            'mismatched'         => $mismatched,
            'missing_in_system'  => $missing_in_system,
            'missing_in_file'    => $missing_in_file,
        ];
    }

}

// ── FRAUD DETECTION MODULE ──────────────────────────────────────
// ── VENDOR × PROJECT MATRIX (grid: every vendor's clicks/completes per project) ──
// Matches Kishan's panel's new Matrix page — instead of opening each
// Vendor or Project page separately to see "who's assigned to what",
// shows every vendor-project combination with real traffic in one grid.
if ($page === 'matrix') {
    $matrix_vendors = $db->query("SELECT id, vendor_name FROM rp_vendors ORDER BY vendor_name ASC LIMIT 50")->fetchAll();
    $matrix_projects = $db->query("SELECT id, sid, project_name FROM rp_projects ORDER BY created_at DESC LIMIT 30")->fetchAll();

    $matrix_cells = [];
    $mc = $db->query("SELECT l.vendor_id, l.sid,
            COUNT(*) AS clicks,
            SUM(CASE WHEN l.status='complete' THEN 1 ELSE 0 END) AS completes
        FROM rp_leads l
        WHERE l.vendor_id IS NOT NULL
        GROUP BY l.vendor_id, l.sid");
    while ($row = $mc->fetch()) {
        $matrix_cells[$row['vendor_id'] . '_' . $row['sid']] = ['clicks' => $row['clicks'], 'completes' => $row['completes']];
    }

    $mp = $db->query("SELECT vendor_id, project_id, status FROM rp_project_vendors");
    $matrix_project_sid = [];
    foreach ($matrix_projects as $mpp) { $matrix_project_sid[$mpp['id']] = $mpp['sid']; }
    while ($row = $mp->fetch()) {
        $sid = $matrix_project_sid[$row['project_id']] ?? null;
        if (!$sid) continue;
        $key = $row['vendor_id'] . '_' . $sid;
        if (isset($matrix_cells[$key])) $matrix_cells[$key]['paused'] = ($row['status'] === 'inactive' || $row['status'] === 'paused');
    }
}

if ($page === 'fraud') {
    // Signal 1: Same IP with multiple DIFFERENT UIDs completing the SAME project
    // (possible bot farm / same person completing repeatedly with fake UIDs)
    $fraud_same_project = $db->query("
        SELECT ip, sid,
               COUNT(DISTINCT original_uid) AS uid_count,
               SUM(CASE WHEN status='complete' THEN 1 ELSE 0 END) AS completes,
               MAX(project_name) AS pname
        FROM (
            SELECT l.ip, l.sid, l.original_uid, l.status, p.project_name
            FROM rp_leads l LEFT JOIN rp_projects p ON l.sid = p.sid
        ) t
        WHERE ip IS NOT NULL AND ip != ''
        GROUP BY ip, sid
        HAVING uid_count > 1 AND completes > 1
        ORDER BY completes DESC
        LIMIT 100
    ")->fetchAll();

    // Signal 2: Same IP active across many DIFFERENT projects (possible professional/fraud panelist)
    $fraud_cross_project = $db->query("
        SELECT ip,
               COUNT(DISTINCT sid) AS project_count,
               COUNT(*) AS total_leads,
               SUM(CASE WHEN status='complete' THEN 1 ELSE 0 END) AS total_completes
        FROM rp_leads
        WHERE ip IS NOT NULL AND ip != ''
        GROUP BY ip
        HAVING project_count > 2
        ORDER BY project_count DESC
        LIMIT 100
    ")->fetchAll();

    $fraud_flag_count = count($fraud_same_project) + count($fraud_cross_project);
}

// UID Lookup
$uid_lookup_result = null;
$uid_lookup_query  = '';
if ($page === 'uid_lookup' && isset($_GET['q'])) {
    $uid_lookup_query = trim($_GET['q']);
    if ($uid_lookup_query) {
        // Search by original_uid OR encrypted_uid in leads + mapping table
        $lr = $db->prepare("SELECT l.*, p.project_name FROM rp_leads l LEFT JOIN rp_projects p ON l.sid=p.sid WHERE l.original_uid=? OR l.encrypted_uid=? ORDER BY l.id DESC LIMIT 50");
        $lr->execute([$uid_lookup_query, $uid_lookup_query]);
        $uid_lookup_result = $lr->fetchAll();
        // Also check mapping table
        $mr = $db->prepare("SELECT * FROM rp_uid_mapping WHERE original_uid=? OR encrypted_uid=? LIMIT 1");
        $mr->execute([$uid_lookup_query, $uid_lookup_query]);
        $uid_map = $mr->fetch();
    }
}

$msg = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars(BRAND_NAME) ?> Panel</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Mono&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#f4f6fb;
  --surface:#ffffff;
  --surface2:#f1f3f9;
  --border:rgba(15,23,42,0.08);
  --text:#0f172a;
  --text2:#475569;
  --text3:#94a3b8;
  --accent:#6366f1;
  --accent2:#8b5cf6;
  --green:#16a34a;
  --amber:#d97706;
  --blue:#2563eb;
  --red:#dc2626;
  --pink:#db2777;
  --sidebar-w:220px;
}
body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;min-height:100vh;display:flex}

/* ── SIDEBAR ── */
.sidebar{
  width:var(--sidebar-w);
  background:var(--surface);
  border-right:1px solid var(--border);
  display:flex;flex-direction:column;
  position:fixed;top:0;left:0;bottom:0;
  z-index:100;overflow-y:auto;
}
.sidebar-logo{
  padding:20px 18px 16px;
  border-bottom:1px solid var(--border);
  display:flex;align-items:center;gap:10px;
}
.logo-icon{
  width:36px;height:36px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  border-radius:9px;
  display:flex;align-items:center;justify-content:center;
  font-size:11px;font-weight:700;color:#fff;letter-spacing:-0.3px;
  flex-shrink:0;
}
.logo-text{font-size:15px;font-weight:700;letter-spacing:1.5px;color:var(--text)}
.logo-sub{font-size:9px;letter-spacing:2px;color:var(--text3);margin-top:1px}

.sidebar-user{
  padding:14px 18px;
  border-bottom:1px solid var(--border);
  font-size:12px;
}
.sidebar-user-name{font-weight:600;color:var(--text);margin-bottom:2px}
.sidebar-user-role{
  font-size:10px;letter-spacing:1px;
  color:var(--accent);font-weight:600;
  text-transform:uppercase;
}

.sidebar-nav{flex:1;padding:10px 0}
.nav-section{
  font-size:9px;letter-spacing:2px;
  color:var(--text3);font-weight:600;
  padding:14px 18px 6px;
  text-transform:uppercase;
}
.nav-link{
  display:flex;align-items:center;gap:10px;
  padding:9px 18px;
  font-size:13px;font-weight:500;
  color:var(--text2);
  text-decoration:none;
  transition:all .15s;
  border-left:3px solid transparent;
}
.nav-link:hover{color:var(--text);background:rgba(15,23,42,0.04)}
.nav-link.active{
  color:var(--accent);
  background:rgba(99,102,241,0.08);
  border-left-color:var(--accent);
}
.nav-link .icon{font-size:15px;width:18px;text-align:center}

.sidebar-footer{
  padding:14px 18px;
  border-top:1px solid var(--border);
  font-size:11px;color:var(--text3);
}

/* ── MAIN ── */
.main{margin-left:var(--sidebar-w);flex:1;min-height:100vh;display:flex;flex-direction:column}

/* ── TOPBAR ── */
.topbar{
  background:var(--surface);
  border-bottom:1px solid var(--border);
  padding:14px 28px;
  display:flex;align-items:center;justify-content:space-between;
  position:sticky;top:0;z-index:50;
}
.topbar-title{font-size:16px;font-weight:600;color:var(--text)}
.topbar-right{display:flex;align-items:center;gap:12px}
.live-badge{
  display:flex;align-items:center;gap:6px;
  background:rgba(34,197,94,0.1);
  border:1px solid rgba(34,197,94,0.25);
  border-radius:20px;padding:4px 10px;
  font-size:11px;color:var(--green);font-weight:600;
}
.live-dot{width:6px;height:6px;border-radius:50%;background:var(--green);animation:pulse 2s infinite}

/* ── CONTENT ── */
.content{padding:24px 28px;flex:1}

/* ── FLASH MSG ── */
.flash{
  background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.2);
  border-radius:8px;padding:10px 16px;
  font-size:13px;color:var(--green);margin-bottom:20px;
}

/* ── STAT CARDS ── */
.stats-grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
  gap:16px;margin-bottom:24px;
}
.stat-card{
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:12px;
  padding:20px;
  position:relative;overflow:hidden;
  transition:border-color .2s;
}
.stat-card:hover{border-color:rgba(15,23,42,0.16)}
.stat-card::before{
  content:'';position:absolute;
  top:0;left:0;right:0;height:3px;
  background:var(--card-color,var(--accent));
}
.stat-label{font-size:11px;letter-spacing:1.5px;color:var(--text3);font-weight:600;text-transform:uppercase;margin-bottom:10px}
.stat-value{font-size:28px;font-weight:700;color:var(--text);line-height:1}
.stat-sub{font-size:11px;color:var(--text3);margin-top:6px}

/* ── SECTION HEADER ── */
.section-header{
  display:flex;align-items:center;justify-content:space-between;
  margin-bottom:18px;
}
.section-title{font-size:15px;font-weight:600;color:var(--text)}

/* ── BUTTONS ── */
.btn{
  display:inline-flex;align-items:center;gap:6px;
  padding:8px 16px;border-radius:8px;
  font-size:13px;font-weight:600;
  cursor:pointer;border:none;
  text-decoration:none;transition:opacity .15s;
  font-family:'DM Sans',sans-serif;
}
.btn:hover{opacity:0.85}
.btn-primary{background:linear-gradient(135deg,var(--accent),var(--accent2));color:#fff}
.btn-sm{padding:5px 12px;font-size:12px;border-radius:6px}
.btn-danger{background:rgba(239,68,68,0.15);color:var(--red);border:1px solid rgba(239,68,68,0.2)}
.btn-ghost{background:rgba(15,23,42,0.04);color:var(--text2);border:1px solid var(--border)}
.btn-green{background:rgba(34,197,94,0.15);color:var(--green);border:1px solid rgba(34,197,94,0.2)}
.btn-blue{background:rgba(59,130,246,0.15);color:var(--blue);border:1px solid rgba(59,130,246,0.2)}
.btn-amber{background:rgba(245,158,11,0.15);color:var(--amber);border:1px solid rgba(245,158,11,0.2)}

/* ── TABLE ── */
.table-wrap{
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:12px;overflow:hidden;
}
.table-toolbar{
  padding:14px 18px;
  border-bottom:1px solid var(--border);
  display:flex;align-items:center;gap:12px;flex-wrap:wrap;
}
table{width:100%;border-collapse:collapse}
thead th{
  padding:11px 16px;
  font-size:10px;letter-spacing:1.5px;
  color:var(--text3);font-weight:600;
  text-align:left;text-transform:uppercase;
  border-bottom:1px solid var(--border);
  background:var(--surface2);
}
tbody td{
  padding:12px 16px;
  font-size:13px;color:var(--text2);
  border-bottom:1px solid var(--border);
  vertical-align:middle;
}
tbody tr:last-child td{border-bottom:none}
tbody tr:hover td{background:rgba(15,23,42,0.025)}
.td-main{color:var(--text);font-weight:500}
.mono{font-family:'DM Mono',monospace;font-size:12px}

/* ── PILLS ── */
.pill{
  display:inline-flex;align-items:center;gap:4px;
  padding:3px 10px;border-radius:20px;
  font-size:11px;font-weight:600;letter-spacing:0.5px;
}
.pill-green{background:rgba(34,197,94,0.1);color:var(--green);border:1px solid rgba(34,197,94,0.2)}
.pill-amber{background:rgba(245,158,11,0.1);color:var(--amber);border:1px solid rgba(245,158,11,0.2)}
.pill-red{background:rgba(239,68,68,0.1);color:var(--red);border:1px solid rgba(239,68,68,0.2)}
.pill-blue{background:rgba(59,130,246,0.1);color:var(--blue);border:1px solid rgba(59,130,246,0.2)}
.pill-purple{background:rgba(99,102,241,0.1);color:var(--accent);border:1px solid rgba(99,102,241,0.2)}
.pill-gray{background:rgba(15,23,42,0.05);color:var(--text2);border:1px solid var(--border)}

/* ── MODAL ── */
.modal-overlay{
  display:none;position:fixed;inset:0;
  background:rgba(0,0,0,0.7);z-index:200;
  align-items:center;justify-content:center;
}
.modal-overlay.open{display:flex}
.modal{
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:16px;
  padding:28px;width:100%;max-width:560px;
  max-height:90vh;overflow-y:auto;
  position:relative;
}
.modal-title{font-size:16px;font-weight:600;margin-bottom:20px;color:var(--text)}
.modal-close{
  position:absolute;top:20px;right:20px;
  background:none;border:none;color:var(--text3);
  font-size:20px;cursor:pointer;line-height:1;
}
.modal-close:hover{color:var(--text)}

/* ── FORM ── */
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.form-grid.full{grid-template-columns:1fr}
.field{display:flex;flex-direction:column;gap:6px}
.field.span2{grid-column:span 2}
.field label{font-size:11px;font-weight:600;letter-spacing:1px;color:var(--text3);text-transform:uppercase}
.field input,.field select,.field textarea{
  background:var(--bg);border:1px solid var(--border);
  border-radius:8px;padding:9px 12px;
  font-size:13px;color:var(--text);
  font-family:'DM Sans',sans-serif;
  outline:none;transition:border-color .15s;
  width:100%;
}
.field input:focus,.field select:focus,.field textarea:focus{border-color:var(--accent)}
.field textarea{resize:vertical;min-height:80px}
.field select option{background:var(--surface)}

/* ── SEARCH ── */
.search-input{
  background:var(--bg);border:1px solid var(--border);
  border-radius:8px;padding:8px 12px;
  font-size:13px;color:var(--text);
  font-family:'DM Sans',sans-serif;
  outline:none;min-width:200px;
}
.search-input:focus{border-color:var(--accent)}

/* ── CHART ── */
.chart-wrap{
  background:var(--surface);border:1px solid var(--border);
  border-radius:12px;padding:20px;margin-bottom:20px;
}
.chart-title{font-size:12px;letter-spacing:1.5px;color:var(--text3);font-weight:600;text-transform:uppercase;margin-bottom:16px}
.chart-bars{display:flex;align-items:flex-end;gap:8px;height:100px}
.chart-bar-group{flex:1;display:flex;flex-direction:column;align-items:center;gap:4px}
.chart-bar{width:100%;border-radius:4px 4px 0 0;min-height:2px;transition:height .3s}
.chart-label{font-size:10px;color:var(--text3);margin-top:4px}
.chart-legend{display:flex;gap:16px;margin-top:10px}
.chart-legend-item{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--text3)}
.legend-dot{width:8px;height:8px;border-radius:50%}

/* ── URL BOX ── */
.url-box{
  background:var(--bg);border:1px solid var(--border);
  border-radius:8px;padding:10px 14px;
  display:flex;align-items:center;justify-content:space-between;gap:10px;
  margin-bottom:8px;
}
.url-label{font-size:10px;letter-spacing:1px;color:var(--text3);font-weight:600;text-transform:uppercase;margin-bottom:4px}
.url-val{font-family:'DM Mono',monospace;font-size:11px;color:var(--accent);word-break:break-all;flex:1}
.copy-btn{
  background:rgba(99,102,241,0.1);border:1px solid rgba(99,102,241,0.2);
  color:var(--accent);border-radius:6px;padding:4px 10px;
  font-size:11px;font-weight:600;cursor:pointer;white-space:nowrap;
  font-family:'DM Sans',sans-serif;
}
.copy-btn:hover{background:rgba(99,102,241,0.2)}

/* ── CARDS GRID ── */
.cards-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-bottom:24px}
.info-card{
  background:var(--surface);border:1px solid var(--border);
  border-radius:12px;padding:20px;
}
.info-card-title{font-size:11px;letter-spacing:1.5px;color:var(--text3);font-weight:600;text-transform:uppercase;margin-bottom:14px}
.info-row{display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border)}
.info-row:last-child{border-bottom:none}
.info-key{font-size:12px;color:var(--text3)}
.info-val{font-size:13px;color:var(--text);font-weight:500}

/* ── PAGINATION ── */
.pagination{display:flex;gap:6px;margin-top:16px;justify-content:center}
.page-btn{
  background:var(--surface);border:1px solid var(--border);
  border-radius:6px;padding:6px 12px;font-size:13px;color:var(--text2);
  text-decoration:none;transition:all .15s;
}
.page-btn:hover,.page-btn.active{background:var(--accent);color:#fff;border-color:var(--accent)}

@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}

/* ── RESPONSIVE ── */
@media(max-width:768px){
  .sidebar{width:100%;height:auto;position:relative;flex-direction:row;flex-wrap:wrap}
  .main{margin-left:0}
  .form-grid{grid-template-columns:1fr}
  .field.span2{grid-column:span 1}
}
</style>
</head>
<body>

<!-- SIDEBAR -->
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="logo-icon"><?= htmlspecialchars(BRAND_ICON) ?></div>
    <div>
      <div class="logo-text"><?= htmlspecialchars(BRAND_UPPER) ?></div>
      <div class="logo-sub"><?= htmlspecialchars(BRAND_TAGLINE) ?></div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="sidebar-user-name"><?= htmlspecialchars($user['name']) ?></div>
    <div class="sidebar-user-role"><?= htmlspecialchars($user['role']) ?></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section">Main</div>
    <a href="?page=dashboard" class="nav-link <?= $page==='dashboard'?'active':'' ?>">
      <span class="icon">📊</span> Dashboard
    </a>
    <a href="?page=projects" class="nav-link <?= in_array($page,['projects','project_view'])?'active':'' ?>">
      <span class="icon">📁</span> Projects
    </a>
    <a href="?page=leads" class="nav-link <?= $page==='leads'?'active':'' ?>">
      <span class="icon">📋</span> Leads
    </a>
    <a href="?page=uid_lookup" class="nav-link <?= $page==='uid_lookup'?'active':'' ?>">
      <span class="icon">🔍</span> UID Lookup
    </a>
    <a href="?page=global_search" class="nav-link <?= $page==='global_search'?'active':'' ?>">
      <span class="icon">🌐</span> Global Search
    </a>
    <a href="?page=screener" class="nav-link <?= $page==='screener'?'active':'' ?>">
      <span class="icon">📝</span> Screener Data
    </a>
    <a href="?page=notes" class="nav-link <?= $page==='notes'?'active':'' ?>">
      <span class="icon">🗒️</span> Notes
    </a>
    <a href="?page=quality_flags" class="nav-link <?= $page==='quality_flags'?'active':'' ?>">
      <span class="icon">⚠️</span> Quality Flags
    </a>
    <a href="?page=billing" class="nav-link <?= $page==='billing'?'active':'' ?>">
      <span class="icon">💰</span> Billing
    </a>
    <a href="?page=quality_score" class="nav-link <?= $page==='quality_score'?'active':'' ?>">
      <span class="icon">⭐</span> Quality Score
    </a>
    <a href="?page=reconcile" class="nav-link <?= $page==='reconcile'?'active':'' ?>">
      <span class="icon">🔄</span> Reconcile
    </a>
    <a href="?page=fraud" class="nav-link <?= $page==='fraud'?'active':'' ?>">
      <span class="icon">🕵️</span> Fraud Detection
    </a>
    <div class="nav-section">Management</div>
    <a href="?page=clients" class="nav-link <?= $page==='clients'?'active':'' ?>">
      <span class="icon">🏢</span> Clients
    </a>
    <a href="?page=vendors" class="nav-link <?= in_array($page,['vendors','vendor_view'])?'active':'' ?>">
      <span class="icon">🤝</span> Vendors
    </a>
    <a href="?page=matrix" class="nav-link <?= $page==='matrix'?'active':'' ?>">
      <span class="icon">🔲</span> Vendor × Project
    </a>
    <?php if (rp_is_superadmin()): ?>
    <div class="nav-section">Admin</div>
    <a href="?page=team" class="nav-link <?= $page==='team'?'active':'' ?>">
      <span class="icon">👥</span> Team
    </a>
    <a href="?page=backup" class="nav-link <?= $page==='backup'?'active':'' ?>">
      <span class="icon">💾</span> Backup
    </a>
    <a href="?page=alert_settings" class="nav-link <?= $page==='alert_settings'?'active':'' ?>">
      <span class="icon">🔔</span> Alert Settings
    </a>
    <a href="?page=audit_log" class="nav-link <?= $page==='audit_log'?'active':'' ?>">
      <span class="icon">📜</span> Audit Log
    </a>
    <?php endif; ?>
    <div class="nav-section">Account</div>
    <a href="?page=change_password" class="nav-link <?= $page==='change_password'?'active':'' ?>">
      <span class="icon">🔑</span> Change Password
    </a>
  </nav>
  <div class="sidebar-footer">
    <a href="?page=logout" style="color:var(--red);text-decoration:none;font-size:12px">⏻ Logout</a>
  </div>
</aside>

<!-- MAIN -->
<div class="main">

  <!-- TOPBAR -->
  <div class="topbar">
    <div class="topbar-title">
      <?php
      $titles = ['dashboard'=>'Dashboard','projects'=>'Projects','project_view'=>'Project Details','clients'=>'Clients','vendors'=>'Vendors','vendor_view'=>'Vendor Details','leads'=>'Leads','uid_lookup'=>'UID Lookup','global_search'=>'Global Search','screener'=>'Screener Data','change_password'=>'Change Password','team'=>'Team Management','backup'=>'Backup'];
      echo $titles[$page] ?? 'Dashboard';
      ?>
    </div>
    <div class="topbar-right">
      <div class="live-badge"><div class="live-dot"></div> LIVE</div>
    </div>
  </div>

  <!-- CONTENT -->
  <div class="content">

  <?php if ($page === 'dashboard'): ?>
  <script>
  setTimeout(() => window.location.reload(), 60000);
  </script>
  <div style="font-size:11px;color:var(--text3);margin-bottom:16px;text-align:right">
    🔄 Auto-refresh: 60s &nbsp;|&nbsp; Updated: <?= date('H:i:s') ?> IST
  </div>
  <?php endif; ?>

  <?php if ($msg): ?>
  <div class="flash">✓ <?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>

  <?php

  // ════════════════════════════════════════════
  // DASHBOARD
  // ════════════════════════════════════════════
  if ($page === 'dashboard'):
    $max_clicks = max(1, max(array_column($chart_data, 'clicks')));
    $avg_loi_display = $stats['avg_loi_seconds'] > 0 ? round($stats['avg_loi_seconds']/60,1).'m' : '—';
  ?>
  <div class="stats-grid">
    <div class="stat-card" style="--card-color:#6366f1">
      <div class="stat-label">Total Clicks</div>
      <div class="stat-value"><?= number_format($stats['total_clicks']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#22c55e">
      <div class="stat-label">Completes</div>
      <div class="stat-value"><?= number_format($stats['total_completes']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#f59e0b">
      <div class="stat-label">Terminates</div>
      <div class="stat-value"><?= number_format($stats['total_terminates']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#dc2626">
      <div class="stat-label">Quota Full</div>
      <div class="stat-value"><?= number_format($stats['total_overquota']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#8b5cf6">
      <div class="stat-label">Quality Fail</div>
      <div class="stat-value"><?= number_format($stats['total_quality_fail']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#3b82f6">
      <div class="stat-label">Active Projects</div>
      <div class="stat-value"><?= number_format($stats['active_projects']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#ec4899">
      <div class="stat-label">Active Vendors</div>
      <div class="stat-value"><?= number_format($stats['active_vendors']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#8b5cf6">
      <div class="stat-label">Clients</div>
      <div class="stat-value"><?= number_format($stats['total_clients']) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#16a34a">
      <div class="stat-label">Avg LOI</div>
      <div class="stat-value"><?= $avg_loi_display ?></div>
      <div class="stat-sub">Completes only</div>
    </div>
    <div class="stat-card" style="--card-color:#2563eb">
      <div class="stat-label">Conversion Rate</div>
      <div class="stat-value"><?= $stats['conversion_rate'] ?>%</div>
      <div class="stat-sub">Completes / Clicks</div>
    </div>
  </div>

  <div style="display:grid;grid-template-columns:1.4fr 1fr 1fr;gap:16px;margin-top:16px">
    <div class="chart-wrap">
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px">
        <div class="chart-title" style="margin-bottom:0">Daily Trend</div>
        <form method="GET" style="display:flex;gap:6px;align-items:center">
          <input type="hidden" name="page" value="dashboard">
          <input type="date" name="date_from" value="<?= htmlspecialchars($range_from) ?>" class="search-input" style="min-width:auto;padding:5px 8px;font-size:12px">
          <span style="color:var(--text3);font-size:12px">to</span>
          <input type="date" name="date_to" value="<?= htmlspecialchars($range_to) ?>" class="search-input" style="min-width:auto;padding:5px 8px;font-size:12px">
          <button type="submit" class="btn btn-primary btn-sm">Go</button>
          <a href="?page=dashboard" class="btn btn-ghost btn-sm">Reset</a>
        </form>
      </div>
      <canvas id="dailyTrendChart" height="180"></canvas>
    </div>
    <div class="chart-wrap">
      <div class="chart-title">Status Breakdown</div>
      <canvas id="statusDonutChart" height="180"></canvas>
    </div>
    <div class="chart-wrap">
      <div class="chart-title">Device Split</div>
      <canvas id="deviceDonutChart" height="180"></canvas>
    </div>
  </div>

  <div class="chart-wrap" style="margin-top:16px">
    <div class="chart-title">Hourly — Today</div>
    <canvas id="hourlyChart" height="90"></canvas>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
  <script>
  (function(){
    var textColor = '#475569';
    var gridColor = 'rgba(15,23,42,0.06)';
    Chart.defaults.color = textColor;
    Chart.defaults.font.family = "'DM Sans', sans-serif";

    // Daily trend (bar+line combo)
    new Chart(document.getElementById('dailyTrendChart'), {
      type: 'bar',
      data: {
        labels: <?= json_encode(array_column($chart_data,'label')) ?>,
        datasets: [
          {
            label: 'Clicks',
            data: <?= json_encode(array_column($chart_data,'clicks')) ?>,
            backgroundColor: 'rgba(99,102,241,0.65)',
            borderRadius: 4,
            order: 2
          },
          {
            label: 'Completes',
            type: 'line',
            data: <?= json_encode(array_column($chart_data,'completes')) ?>,
            borderColor: '#22c55e',
            backgroundColor: '#22c55e',
            tension: 0.35,
            pointRadius: 3,
            order: 1
          }
        ]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, padding: 14 } } },
        scales: {
          x: { grid: { display: false } },
          y: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: gridColor } }
        }
      }
    });

    // Status breakdown donut
    new Chart(document.getElementById('statusDonutChart'), {
      type: 'doughnut',
      data: {
        labels: <?= json_encode(array_keys($status_breakdown)) ?>,
        datasets: [{
          data: <?= json_encode(array_values($status_breakdown)) ?>,
          backgroundColor: ['#22c55e','#dc2626','#f59e0b','#8b5cf6','#94a3b8','#2563eb'],
          borderWidth: 2,
          borderColor: '#ffffff'
        }]
      },
      options: {
        responsive: true,
        cutout: '65%',
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, padding: 12, font: { size: 11 } } } }
      }
    });

    // Device split donut
    new Chart(document.getElementById('deviceDonutChart'), {
      type: 'doughnut',
      data: {
        labels: <?= json_encode(array_keys($device_breakdown)) ?>,
        datasets: [{
          data: <?= json_encode(array_values($device_breakdown)) ?>,
          backgroundColor: ['#2563eb','#6366f1','#ec4899','#94a3b8'],
          borderWidth: 2,
          borderColor: '#ffffff'
        }]
      },
      options: {
        responsive: true,
        cutout: '65%',
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, padding: 12, font: { size: 11 } } } }
      }
    });

    // Hourly today
    new Chart(document.getElementById('hourlyChart'), {
      type: 'bar',
      data: {
        labels: Array.from({length:24}, (_,h) => (h%3===0 ? h+':00' : '')),
        datasets: [{
          label: 'Leads',
          data: <?= json_encode($hourly_data) ?>,
          backgroundColor: 'rgba(99,102,241,0.55)',
          borderRadius: 3
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { display: false }, ticks: { autoSkip: false, font: { size: 10 } } },
          y: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: gridColor } }
        }
      }
    });
  })();
  </script>

  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // PROJECTS LIST
  // ════════════════════════════════════════════
  if ($page === 'projects'):
  ?>
  <div class="section-header">
    <div class="section-title">All Projects (<?= count($projects) ?>)</div>
    <div style="display:flex;gap:8px">
      <?php if (rp_is_superadmin()): ?>
      <button type="button" class="btn btn-sm btn-danger" onclick="bulkDeleteProjects()">Delete Selected</button>
      <?php endif; ?>
      <?php if (rp_is_manager()): ?>
      <button type="button" class="btn btn-sm" style="background:rgba(22,163,74,.1);color:#16a34a" onclick="openModal('modalBulkImport',{})">📥 Bulk Import</button>
      <button class="btn btn-primary" onclick="openModal('modalProject',{})">+ Add Project</button>
      <?php endif; ?>
    </div>
  </div>

  <?php if (isset($_GET['bulk_import_done']) && isset($_SESSION['bulk_import_results'])):
      $bir = $_SESSION['bulk_import_results']; unset($_SESSION['bulk_import_results']); ?>
  <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:12px 16px;margin-bottom:14px;font-size:13px">
    <b style="color:#16a34a">Import complete:</b> <?= $bir['created'] ?> created, <?= $bir['updated'] ?> updated<?= count($bir['errors']) ? ', <span style="color:#dc2626">'.count($bir['errors']).' error(s)</span>' : '' ?>.
    <?php if (count($bir['errors'])): ?>
    <ul style="margin:8px 0 0 18px;color:#dc2626">
      <?php foreach ($bir['errors'] as $err): ?>
      <li><?= htmlspecialchars($err) ?></li>
      <?php endforeach; ?>
    </ul>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <form method="GET" style="display:flex;gap:10px;margin-bottom:16px">
    <input type="hidden" name="page" value="projects">
    <input type="text" name="psearch" class="search-input" placeholder="Project name, SID, or client se search karo..." value="<?= htmlspecialchars($proj_search) ?>" style="min-width:280px">
    <button type="submit" class="btn btn-primary btn-sm">Search</button>
    <?php if ($proj_search): ?><a href="?page=projects" class="btn btn-ghost btn-sm">Clear</a><?php endif; ?>
  </form>

  <form id="projectsBulkForm" method="POST">
    <input type="hidden" name="action" value="bulk_delete_projects">
    <input type="hidden" name="project_ids" id="projectIdsInput">
  </form>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <?php if (rp_is_superadmin()): ?><th><input type="checkbox" onclick="toggleAllProjects(this)"></th><?php endif; ?>
          <th>📌</th><th>#</th><th>Project</th><th>Client</th><th>Vendors</th><th>CPI</th><th>Quota</th><th>IR%</th><th>LOI</th><th>Completes</th><th>Conv%</th><th>Status</th><th>Type</th><th>Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php
      $color_options = ['' => 'None', 'red' => '🔴 Red', 'orange' => '🟠 Orange', 'yellow' => '🟡 Yellow', 'green' => '🟢 Green', 'blue' => '🔵 Blue', 'purple' => '🟣 Purple'];
      foreach ($projects as $i => $p):
        $completes = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=? AND status='complete'");
        $completes->execute([$p['sid']]); $comp = $completes->fetchColumn();
        $clicks = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=?");
        $clicks->execute([$p['sid']]); $clk = $clicks->fetchColumn();
        $row_border = !empty($p['color_tag']) ? "border-left:4px solid {$p['color_tag']}" : '';
      ?>
        <tr style="<?= $row_border ?>">
          <?php if (rp_is_superadmin()): ?>
          <td><input type="checkbox" class="project-check" value="<?= $p['id'] ?>"></td>
          <?php endif; ?>
          <td>
            <form method="POST" style="display:inline">
              <input type="hidden" name="action" value="toggle_pin_project">
              <input type="hidden" name="id" value="<?= $p['id'] ?>">
              <button type="submit" class="btn btn-sm btn-ghost" title="Pin/Unpin" style="padding:2px 6px">
                <?= !empty($p['is_pinned']) ? '📌' : '📍' ?>
              </button>
            </form>
          </td>
          <td><?= $i+1 ?></td>
          <td>
            <div class="td-main"><?= htmlspecialchars($p['project_name']) ?></div>
            <div class="mono" style="color:var(--text3)"><?= htmlspecialchars($p['sid']) ?></div>
            <?php if (rp_is_manager()): ?>
            <form method="POST" style="margin-top:4px">
              <input type="hidden" name="action" value="set_project_color">
              <input type="hidden" name="id" value="<?= $p['id'] ?>">
              <select name="color_tag" onchange="this.form.submit()" style="font-size:10px;padding:2px">
                <?php foreach ($color_options as $val => $label): ?>
                <option value="<?= $val ?>" <?= ($p['color_tag'] ?? '')===$val?'selected':'' ?>><?= $label ?></option>
                <?php endforeach; ?>
              </select>
            </form>
            <?php endif; ?>
          </td>
          <td><?= htmlspecialchars($p['client_name'] ?: '—') ?></td>
          <td><?php $vc = $proj_vendor_counts[$p['id']] ?? 0; ?><span class="pill <?= $vc>0?'pill-blue':'pill-gray' ?>"><?= $vc ?> vendor<?= $vc==1?'':'s' ?></span></td>
          <td>
            <?php if (rp_is_manager()): ?>
            <form method="POST" style="display:flex;gap:3px;align-items:center">
              <input type="hidden" name="action" value="quick_edit_project">
              <input type="hidden" name="id" value="<?= $p['id'] ?>">
              <input type="hidden" name="supplier_cpi" value="<?= $p['supplier_cpi'] ?? 0 ?>">
              <input type="number" name="cpi" step="0.01" value="<?= $p['cpi'] ?>" style="width:60px;font-size:12px;padding:3px">
              <input type="hidden" name="max_completes" value="<?= $p['max_completes'] ?>">
              <button type="submit" class="btn btn-sm btn-ghost" style="padding:2px 6px">💾</button>
            </form>
            <?php else: ?>
            $<?= number_format($p['cpi'],2) ?>
            <?php endif; ?>
          </td>
          <td>
            <?php if (rp_is_manager()): ?>
            <form method="POST" style="display:flex;gap:3px;align-items:center">
              <input type="hidden" name="action" value="quick_edit_project">
              <input type="hidden" name="id" value="<?= $p['id'] ?>">
              <input type="hidden" name="cpi" value="<?= $p['cpi'] ?>">
              <input type="hidden" name="supplier_cpi" value="<?= $p['supplier_cpi'] ?? 0 ?>">
              <input type="number" name="max_completes" value="<?= $p['max_completes'] ?>" style="width:60px;font-size:12px;padding:3px">
              <button type="submit" class="btn btn-sm btn-ghost" style="padding:2px 6px">💾</button>
            </form>
            <?php else: ?>
            <?= number_format($p['max_completes']) ?>
            <?php endif; ?>
          </td>
          <td><?= $p['ir'] ?>%</td>
          <td><?= $p['loi'] ?>m</td>
          <td><?= $comp ?> / <?= $clk ?></td>
          <td style="color:<?= $clk>0&&($comp/$clk)>0.5?'var(--green)':'var(--amber)' ?>;font-weight:600">
            <?= $clk > 0 ? round(($comp/$clk)*100,1).'%' : '—' ?>
          </td>
          <td>
            <?php
            $pclass = ['active'=>'pill-green','paused'=>'pill-amber','closed'=>'pill-gray'];
            echo '<span class="pill '.($pclass[$p['status']]??'pill-gray').'">'.ucfirst($p['status']).'</span>';
            ?>
          </td>
          <td><span class="pill pill-blue"><?= ucfirst($p['project_type']) ?></span></td>
          <td>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              <a href="?page=project_view&id=<?= $p['id'] ?>" class="btn btn-sm btn-ghost">View</a>
              <?php if (rp_is_manager()): ?>
              <button class="btn btn-sm btn-ghost" onclick='openModal("modalProject",<?= json_encode($p) ?>)'>Edit</button>
              <form method="POST" style="display:inline">
                <input type="hidden" name="action" value="toggle_project_status">
                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                <button type="submit" class="btn btn-sm <?= $p['status']==='active' ? 'btn-amber' : 'btn-green' ?>">
                  <?= $p['status']==='active' ? '⏸ Pause' : '▶ Resume' ?>
                </button>
              </form>
              <form method="POST" style="display:inline" onsubmit="return confirm('Duplicate this project?')">
                <input type="hidden" name="action" value="duplicate_project">
                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                <button type="submit" class="btn btn-sm btn-blue">⧉ Copy</button>
              </form>
              <form method="POST" style="display:inline" onsubmit="return confirm('Delete this project?')">
                <input type="hidden" name="action" value="delete_project">
                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                <button type="submit" class="btn btn-sm btn-danger">Del</button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($projects)): ?>
      <tr><td colspan="<?= rp_is_superadmin() ? 14 : 13 ?>" style="text-align:center;color:var(--text3);padding:32px">No projects yet. Add your first project!</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // PROJECT VIEW
  // ════════════════════════════════════════════
  if ($page === 'project_view' && $project_view):
    $base = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
    $folder = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/'); // auto-detects current folder (e.g. /panelengine or empty if at domain root)
    $base = $base . $folder;
    $sid = $project_view['sid'];
    $enc = $project_view['encrypt_uid'] ? '[ENCRYPTED_UID]' : '[UID]';
  ?>
  <div style="margin-bottom:16px;display:flex;align-items:center;gap:10px">
    <a href="?page=projects" class="btn btn-ghost btn-sm">← Back to Projects</a>
    <?php if (rp_is_manager()): ?>
    <form method="POST" style="display:inline">
      <input type="hidden" name="action" value="toggle_project_status">
      <input type="hidden" name="id" value="<?= $project_view['id'] ?>">
      <button type="submit" class="btn btn-sm <?= $project_view['status']==='active' ? 'btn-amber' : 'btn-green' ?>">
        <?= $project_view['status']==='active' ? '⏸ Pause Project' : '▶ Resume Project' ?>
      </button>
    </form>
    <button class="btn btn-sm btn-ghost" onclick='openModal("modalProject",<?= json_encode($project_view) ?>)'>✏ Edit Project</button>
    <?php endif; ?>
  </div>

  <!-- Stat cards -->
  <?php
    $p_clicks    = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=?"); $p_clicks->execute([$sid]); $p_clk = $p_clicks->fetchColumn();
    $p_completes = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=? AND status='complete'"); $p_completes->execute([$sid]); $p_comp = $p_completes->fetchColumn();
    $p_terminates= $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=? AND status='terminate'"); $p_terminates->execute([$sid]); $p_term = $p_terminates->fetchColumn();
    $quota = (int)$project_view['max_completes'];
    $quota_pct = ($quota > 0) ? min(100, round(($p_comp/$quota)*100)) : null;
  ?>
  <div class="stats-grid" style="grid-template-columns:repeat(<?= $quota?'4':'3' ?>,1fr);margin-bottom:20px">
    <div class="stat-card" style="--card-color:#6366f1"><div class="stat-label">Clicks</div><div class="stat-value"><?= $p_clk ?></div></div>
    <div class="stat-card" style="--card-color:#22c55e"><div class="stat-label">Completes</div><div class="stat-value"><?= $p_comp ?></div></div>
    <div class="stat-card" style="--card-color:#f59e0b"><div class="stat-label">Terminates</div><div class="stat-value"><?= $p_term ?></div></div>
    <?php if ($quota > 0): ?>
    <div class="stat-card" style="--card-color:#8b5cf6">
      <div class="stat-label">Quota</div>
      <div class="stat-value"><?= $quota_pct ?>%</div>
      <div style="margin-top:8px;background:rgba(15,23,42,0.08);border-radius:4px;height:4px;overflow:hidden">
        <div style="width:<?= $quota_pct ?>%;height:100%;background:<?= $quota_pct>=100?'var(--red)':($quota_pct>=80?'var(--amber)':'var(--accent)') ?>;border-radius:4px;transition:width .3s"></div>
      </div>
      <div class="stat-sub"><?= $p_comp ?> / <?= $quota ?></div>
    </div>
    <?php endif; ?>
  </div>

  <!-- Project Info -->
  <div class="cards-grid">
    <div class="info-card">
      <div class="info-card-title">Project Info</div>
      <div class="info-row"><span class="info-key">Project Name</span><span class="info-val"><?= htmlspecialchars($project_view['project_name']) ?></span></div>
      <div class="info-row"><span class="info-key">Project ID</span><span class="info-val mono"><?= htmlspecialchars($sid) ?></span></div>
      <div class="info-row"><span class="info-key">Client</span><span class="info-val"><?= htmlspecialchars($project_view['client_name'] ?: '—') ?></span></div>
      <div class="info-row"><span class="info-key">CPI</span><span class="info-val">$<?= number_format($project_view['cpi'],2) ?></span></div>
      <div class="info-row"><span class="info-key">IR%</span><span class="info-val"><?= $project_view['ir'] ?>%</span></div>
      <div class="info-row"><span class="info-key">LOI</span><span class="info-val"><?= $project_view['loi'] ?> min</span></div>
      <div class="info-row"><span class="info-key">Max Completes (Quota)</span><span class="info-val" style="color:var(--accent);font-weight:600"><?= $project_view['max_completes'] ? number_format($project_view['max_completes']) : 'Unlimited' ?></span></div>
      <div class="info-row"><span class="info-key">Status</span><span class="info-val"><?= ucfirst($project_view['status']) ?></span></div>
      <div class="info-row"><span class="info-key">Encryption</span><span class="info-val"><?= $project_view['encrypt_uid'] ? 'ON' : 'OFF' ?></span></div>
      <div class="info-row"><span class="info-key">Target Countries</span><span class="info-val"><?= !empty($project_view['target_countries']) ? htmlspecialchars($project_view['target_countries']) : '— (all / not specified)' ?></span></div>
    </div>

    <?php if (!empty($project_view['description'])): ?>
    <!-- Description / Study Parameters -->
    <div class="info-card" style="margin-top:16px">
      <div class="info-card-title">Description / Study Parameters</div>
      <div style="padding:12px 0;font-size:13px;color:var(--text2);line-height:1.7">
        <?= $project_view['description'] ?>
      </div>
    </div>
    <?php endif; ?>

    <!-- Redirect URLs -->
    <div class="info-card">
      <div class="info-card-title">End Redirect URLs (Dynamic)</div>
      <?php
      $statuses = [
        'complete'  => ['Complete',  'pill-green'],
        'terminate' => ['Terminate', 'pill-amber'],
        'overquota' => ['Overquota', 'pill-blue'],
        'quality_fail' => ['Quality Fail','pill-red'],
      ];
      foreach ($statuses as $st => [$label, $cls]):
        $url = "$base/end.php?status=$st&sid=$sid&uid=$enc";
      ?>
      <div class="url-label"><span class="pill <?= $cls ?>"><?= $label ?></span></div>
      <div class="url-box">
        <div class="url-val"><?= htmlspecialchars($url) ?></div>
        <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($url) ?>')">Copy</button>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Static URLs -->
  <div class="info-card" style="margin-bottom:20px">
    <div class="info-card-title">Static Redirect URLs</div>
    <?php foreach ($statuses as $st => [$label, $cls]):
      $surl = "$base/pages/".str_replace('_','-',$st).".html?sid=$sid&uid=$enc";
    ?>
    <div class="url-label"><span class="pill <?= $cls ?>"><?= $label ?></span></div>
    <div class="url-box">
      <div class="url-val"><?= htmlspecialchars($surl) ?></div>
      <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($surl) ?>')">Copy</button>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Per-Project Notes -->
  <div class="info-card" style="margin-bottom:20px">
    <div class="info-card-title">Project Notes</div>
    <form method="POST">
      <input type="hidden" name="action" value="save_project_notes">
      <input type="hidden" name="id" value="<?= $project_view['id'] ?>">
      <textarea name="internal_notes" placeholder="Add internal notes, client instructions, important dates..." rows="4" style="width:100%;font-family:inherit;padding:10px;border-radius:6px;border:1px solid var(--border);background:var(--surface);color:var(--text);margin-bottom:10px"><?= htmlspecialchars($project_view['internal_notes'] ?? '') ?></textarea>
      <button type="submit" class="btn btn-primary btn-sm">Save Note</button>
    </form>
  </div>

  <!-- Client Report Link (read-only, no login needed) -->
  <div class="info-card" style="margin-bottom:20px">
    <div class="info-card-title" style="display:flex;align-items:center;justify-content:space-between">
      <span>Client Report Link (Read-only)</span>
      <?php if (rp_is_manager()): ?>
      <form method="POST" style="display:inline">
        <input type="hidden" name="action" value="generate_share_link">
        <input type="hidden" name="project_id" value="<?= $project_view['id'] ?>">
        <button type="submit" class="btn btn-sm btn-primary">+ Generate New Link</button>
      </form>
      <?php endif; ?>
    </div>
    <?php if (empty($pv_share_links)): ?>
    <p style="font-size:12px;color:var(--text3);padding:8px 0">Client ko share karne ke liye ek read-only link generate karo — koi login nahi chahiye, sirf project progress dikhega.</p>
    <?php else: ?>
      <?php foreach ($pv_share_links as $sl):
        $share_url = "$base/report.php?token=" . $sl['token'];
      ?>
      <div class="url-label" style="display:flex;align-items:center;justify-content:space-between">
        <span class="pill pill-blue">Generated <?= date('d M Y', strtotime($sl['created_at'].' UTC')) ?></span>
        <?php if (rp_is_manager()): ?>
        <form method="POST" style="display:inline" onsubmit="return confirm('Ye link revoke ho jayega, client ab isse access nahi kar payega. Confirm?')">
          <input type="hidden" name="action" value="delete_share_link">
          <input type="hidden" name="link_id" value="<?= $sl['id'] ?>">
          <input type="hidden" name="project_id" value="<?= $project_view['id'] ?>">
          <button type="submit" class="btn btn-sm btn-danger">Revoke</button>
        </form>
        <?php endif; ?>
      </div>
      <div class="url-box">
        <div class="url-val"><?= htmlspecialchars($share_url) ?></div>
        <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($share_url) ?>')">Copy</button>
      </div>
      <?php
        $api_summary_url = "$base/api.php?token=" . $sl['token'];
        $api_leads_url   = "$base/api.php?token=" . $sl['token'] . "&action=leads&page=1";
      ?>
      <div style="font-size:11px;color:var(--text3);margin:4px 0 2px">API — Summary (stats as JSON):</div>
      <div class="url-box" style="margin-bottom:8px">
        <div class="url-val" style="font-size:11px"><?= htmlspecialchars($api_summary_url) ?></div>
        <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($api_summary_url) ?>')">Copy</button>
      </div>
      <div style="font-size:11px;color:var(--text3);margin:4px 0 2px">API — Leads list (paginated JSON):</div>
      <div class="url-box" style="margin-bottom:12px">
        <div class="url-val" style="font-size:11px"><?= htmlspecialchars($api_leads_url) ?></div>
        <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($api_leads_url) ?>')">Copy</button>
      </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- Vendors -->
  <div class="section-header">
    <div class="section-title">Assigned Vendors (<?= count($project_vendors) ?>)</div>
    <div style="display:flex;gap:8px">
      <a href="?export=csv&sid=<?= urlencode($sid) ?>" class="btn btn-ghost btn-sm">↓ Excel</a>
      <?php if (rp_is_manager() && !empty($all_vendors_for_assign)): ?>
      <button class="btn btn-primary btn-sm" onclick="document.getElementById('assignVendorModal').classList.add('open')">+ Assign Vendor</button>
      <?php endif; ?>
    </div>
  </div>
  <div class="table-wrap" style="margin-bottom:20px">
    <table>
      <thead><tr><th>Vendor</th><th>Email</th><th>CPI</th><th>Limit</th><th>Status</th><th>Entry Link</th></tr></thead>
      <tbody>
      <?php foreach ($project_vendors as $pv):
        $entry_link = "$base/vendor.php?sid=$sid&vid={$pv['vendor_id']}&uid=[UID]";
        $prescreener_link = "$base/start.php?sid=$sid&vid={$pv['vendor_id']}&uid=[UID]";
        $short_link = "$base/azii.php?c={$pv['short_code']}&pid=[UID]";
      ?>
        <tr>
          <td class="td-main"><?= htmlspecialchars($pv['vendor_name']) ?></td>
          <td><?= htmlspecialchars($pv['email']) ?></td>
          <td>$<?= number_format($pv['cpi'],2) ?></td>
          <td><?= $pv['max_limit'] ?: 'Unlimited' ?></td>
          <td><span class="pill pill-<?= $pv['status']==='active'?'green':'amber' ?>"><?= ucfirst($pv['status']) ?></span></td>
          <td>
            <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
              <button class="btn btn-sm btn-blue" onclick="showEntryLink('<?= htmlspecialchars($pv['vendor_name']) ?>','<?= htmlspecialchars($sid) ?>','<?= htmlspecialchars($entry_link) ?>')">🔗 Entry Link</button>
              <button class="btn btn-sm" style="background:rgba(168,85,247,.15);color:#a855f7" onclick="showEntryLink('<?= htmlspecialchars($pv['vendor_name']) ?> (Short Link)','<?= htmlspecialchars($sid) ?>','<?= htmlspecialchars($short_link) ?>')">✂️ Short Link</button>
              <button class="btn btn-sm btn-green" onclick="showEntryLink('<?= htmlspecialchars($pv['vendor_name']) ?> (Pre-screener)','<?= htmlspecialchars($sid) ?>','<?= htmlspecialchars($prescreener_link) ?>')">📋 Pre-screener</button>
              <?php if (rp_is_manager()): ?>
              <form method="POST" style="display:inline">
                <input type="hidden" name="action" value="toggle_vendor_assignment">
                <input type="hidden" name="pv_id" value="<?= $pv['id'] ?>">
                <input type="hidden" name="project_id" value="<?= $project_view['id'] ?>">
                <button type="submit" class="btn btn-sm <?= $pv['status']==='active'?'btn-amber':'btn-green' ?>">
                  <?= $pv['status']==='active' ? '⏸' : '▶' ?>
                </button>
              </form>
              <button class="btn btn-sm btn-ghost" onclick="openEditAssignment(<?= $pv['id'] ?>,<?= $project_view['id'] ?>,<?= $pv['cpi'] ?>,<?= $pv['max_limit'] ?>,'<?= htmlspecialchars($pv['vendor_name']) ?>')">✏</button>
              <form method="POST" style="display:inline" onsubmit="return confirm('Remove <?= htmlspecialchars($pv['vendor_name']) ?> from this project?')">
                <input type="hidden" name="action" value="unassign_vendor">
                <input type="hidden" name="pv_id" value="<?= $pv['id'] ?>">
                <input type="hidden" name="project_id" value="<?= $project_view['id'] ?>">
                <button type="submit" class="btn btn-sm btn-danger">✕</button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($project_vendors)): ?>
      <tr><td colspan="6" style="text-align:center;color:var(--text3);padding:24px">No vendors assigned yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Vendor Breakdown -->
  <div class="section-header">
    <div class="section-title" style="margin-bottom:0">Vendor Breakdown</div>
    <div style="display:flex;gap:8px">
      <a href="?page=leads&sid=<?= urlencode($project_view['sid']) ?>" class="btn btn-ghost btn-sm">🔍 Search All Leads For This Project</a>
      <a href="?page=leads&export=csv&sid=<?= urlencode($project_view['sid']) ?>" class="btn btn-ghost btn-sm">↓ Export to Excel</a>
    </div>
  </div>
  <div style="font-size:12px;color:var(--text3);margin-bottom:10px">Is-project-pe-kaam-kar-rahe-har-vendor-ka-performance — bina-Vendors-list-khole.</div>
  <div class="table-wrap" style="margin-bottom:24px">
    <table>
      <thead><tr><th>Vendor</th><th>Clicks</th><th>Completes</th><th>Terminates</th><th>Quality-Fail</th><th>OverQuota</th><th>Conv%</th></tr></thead>
      <tbody>
      <?php if (empty($vendor_breakdown)): ?>
      <tr><td colspan="7" style="text-align:center;color:var(--text3);padding:24px">Abhi-tak-koi-entry-nahi-hui.</td></tr>
      <?php else: foreach ($vendor_breakdown as $vb):
          $conv = $vb['clicks'] > 0 ? round(($vb['completes'] / $vb['clicks']) * 100, 1) : 0;
      ?>
      <tr>
        <td>
          <?php if ($vb['vendor_id']): ?>
          <a href="?page=vendor_view&id=<?= $vb['vendor_id'] ?>" style="color:var(--accent);font-weight:600;text-decoration:none"><?= htmlspecialchars($vb['vendor_name']) ?></a>
          <?php else: ?>
          <span style="color:var(--text3)"><?= htmlspecialchars($vb['vendor_name']) ?></span>
          <?php endif; ?>
        </td>
        <td><?= number_format($vb['clicks']) ?></td>
        <td style="color:#16a34a;font-weight:600"><?= number_format($vb['completes']) ?></td>
        <td style="color:#dc2626"><?= number_format($vb['terminates']) ?></td>
        <td style="color:#f59e0b"><?= number_format($vb['quality_fail']) ?></td>
        <td><?= number_format($vb['overquota']) ?></td>
        <td><?= $conv ?>%</td>
      </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Recent Leads -->
  <div class="section-header">
    <div class="section-title" style="margin-bottom:0">Recent Leads</div>
    <?php if (rp_is_superadmin()): ?>
    <form method="POST" onsubmit="return confirm('Delete ALL leads for this project?')">
      <input type="hidden" name="action" value="delete_project_leads">
      <input type="hidden" name="sid" value="<?= htmlspecialchars($sid) ?>">
      <input type="hidden" name="project_id" value="<?= $project_view['id'] ?>">
      <button type="submit" class="btn btn-sm btn-danger">🗑 Delete All Leads</button>
    </form>
    <?php endif; ?>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>UID</th><th>Encrypted ID</th><th>Status</th><th>Country</th><th>Device</th><th>LOI</th><th>IP</th><th>Date</th></tr></thead>
      <tbody>
      <?php foreach ($project_leads as $l):
        $scls = ['complete'=>'pill-green','terminate'=>'pill-amber','overquota'=>'pill-blue','quality_fail'=>'pill-red','click'=>'pill-gray','pending'=>'pill-amber'];
      ?>
        <tr>
          <td class="mono"><?= htmlspecialchars($l['original_uid'] ?: '—') ?></td>
          <td class="mono" style="font-size:11px;color:var(--text3)">
            <?php if (!empty($l['encrypted_uid']) && $l['encrypted_uid'] !== $l['original_uid']): ?>
            🔒 <?= htmlspecialchars($l['encrypted_uid']) ?>
            <?php else: ?>
            —
            <?php endif; ?>
          </td>
          <td><span class="pill <?= $scls[$l['status']]??'pill-gray' ?>"><?= ucfirst(str_replace('_',' ',$l['status'])) ?></span></td>
          <td><?= htmlspecialchars($l['country'] ?: '—') ?></td>
          <td><?= htmlspecialchars($l['device'] ?: '—') ?></td>
          <td><?= $l['loi_seconds'] ? round($l['loi_seconds']/60,1).'m' : '—' ?></td>
          <td class="mono"><?= htmlspecialchars($l['ip'] ?: '—') ?></td>
          <td><?= $l['created_at'] ? date('d M H:i', strtotime($l['created_at'].' UTC')) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($project_leads)): ?>
      <tr><td colspan="8" style="text-align:center;color:var(--text3);padding:24px">No leads yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Assign Vendor Modal -->
  <div class="modal-overlay" id="assignVendorModal">
    <div class="modal">
      <button class="modal-close" onclick="document.getElementById('assignVendorModal').classList.remove('open')">×</button>
      <div class="modal-title">Assign Vendor</div>
      <form method="POST">
        <input type="hidden" name="action" value="assign_vendor">
        <input type="hidden" name="project_id" value="<?= $project_view['id'] ?>">
        <div class="form-grid">
          <div class="field span2">
            <label>Select Vendor</label>
            <select name="vendor_id" required>
              <option value="">-- Select --</option>
              <?php foreach ($all_vendors_for_assign as $v): ?>
              <option value="<?= $v['id'] ?>"><?= htmlspecialchars($v['vendor_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field"><label>CPI ($)</label><input type="number" name="cpi" step="0.01" value="<?= $project_view['cpi'] ?>"></div>
          <div class="field"><label>Max Limit</label><input type="number" name="max_limit" value="<?= $project_view['max_completes'] ?>"></div>
        </div>
        <div style="margin-top:16px;display:flex;gap:10px">
          <button type="submit" class="btn btn-primary">Assign</button>
          <button type="button" class="btn btn-ghost" onclick="document.getElementById('assignVendorModal').classList.remove('open')">Cancel</button>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // CLIENTS
  // ════════════════════════════════════════════
  if ($page === 'clients'):
  ?>
  <div class="section-header">
    <div class="section-title">Clients (<?= count($clients) ?>)</div>
    <?php if (rp_is_manager()): ?>
    <button class="btn btn-primary" onclick="openModal('modalClient',{})">+ Add Client</button>
    <?php endif; ?>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Client Name</th><th>Email</th><th>Company</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($clients as $i => $c): ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td class="td-main"><?= htmlspecialchars($c['client_name']) ?></td>
          <td><?= htmlspecialchars($c['email'] ?: '—') ?></td>
          <td><?= htmlspecialchars($c['company'] ?: '—') ?></td>
          <td><span class="pill <?= $c['status']==='active'?'pill-green':'pill-gray' ?>"><?= ucfirst($c['status']) ?></span></td>
          <td>
            <div style="display:flex;gap:6px">
              <button class="btn btn-sm btn-blue" onclick="showClientRedirectUrls('<?= htmlspecialchars(addslashes($c['client_name'])) ?>','<?= htmlspecialchars($c['client_uid'] ?? '') ?>')">🔗 Redirect URLs</button>
              <?php if (rp_is_manager()): ?>
              <button class="btn btn-sm btn-ghost" onclick='openModal("modalClient",<?= json_encode($c) ?>)'>Edit</button>
              <form method="POST" style="display:inline" onsubmit="return confirm('Delete client?')">
                <input type="hidden" name="action" value="delete_client">
                <input type="hidden" name="id" value="<?= $c['id'] ?>">
                <button type="submit" class="btn btn-sm btn-danger">Del</button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($clients)): ?>
      <tr><td colspan="6" style="text-align:center;color:var(--text3);padding:32px">No clients yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // VENDORS
  // ════════════════════════════════════════════
  if ($page === 'vendors'):
  ?>
  <div class="section-header">
    <div class="section-title">Vendors (<?= count($vendors) ?>)</div>
    <div style="display:flex;gap:8px">
      <a href="?page=vendors&export=csv" class="btn btn-ghost btn-sm">↓ Export to Excel</a>
      <?php if (rp_is_manager()): ?>
      <button class="btn btn-primary" onclick="openModal('modalVendor',{})">+ Add Vendor</button>
      <?php endif; ?>
    </div>
  </div>

  <input type="text" id="vendorSearchBox" placeholder="🔍 Search vendors by name or email..." oninput="filterVendorTable(this.value)" style="width:100%;padding:10px;border-radius:8px;border:1px solid var(--border);margin-bottom:16px;font-size:14px">

  <!-- Vendor Performance Summary -->
  <div class="stats-grid" style="margin-bottom:20px">
    <div class="stat-card" style="--card-color:#6366f1">
      <div class="stat-label">Total Clicks (All Vendors)</div>
      <div class="stat-value"><?= number_format($vsum_clicks) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#22c55e">
      <div class="stat-label">Total Completes</div>
      <div class="stat-value"><?= number_format($vsum_completes) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#3b82f6">
      <div class="stat-label">Overall Conversion</div>
      <div class="stat-value"><?= $vsum_conv ?>%</div>
    </div>
    <div class="stat-card" style="--card-color:#f59e0b">
      <div class="stat-label">Top Vendor (by Conv%)</div>
      <div class="stat-value" style="font-size:16px"><?= htmlspecialchars($vtop_vendor_name) ?><?= $vtop_conv >= 0 ? " ({$vtop_conv}%)" : '' ?></div>
    </div>
  </div>

  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Vendor</th><th>Email</th><th>Clicks</th><th>Completes</th><th>Terminates</th><th>Conv%</th><th>Projects</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($vendors as $i => $v):
        $perf  = $vendor_perf[$v['id']] ?? ['clicks'=>0,'completes'=>0,'terminates'=>0,'conv'=>0];
        $vclk  = $perf['clicks'];
        $vcomp = $perf['completes'];
        $vterm = $perf['terminates'];
        $vconv = $perf['conv'];
      ?>
        <tr data-search="<?= strtolower(htmlspecialchars($v['vendor_name'].' '.($v['email']??''))) ?>">
          <td><?= $i+1 ?></td>
          <td class="td-main">
            <a href="?page=vendor_view&id=<?= $v['id'] ?>" style="color:var(--accent);text-decoration:none">
              <?= htmlspecialchars($v['vendor_name']) ?>
            </a>
          </td>
          <td><?= htmlspecialchars($v['email'] ?: '—') ?></td>
          <td><?= $vclk ?></td>
          <td><?= $vcomp ?></td>
          <td><?= $vterm ?></td>
          <td><?= $vclk > 0 ? $vconv.'%' : '—' ?></td>
          <td><?php $pc = $vendor_proj_counts[$v['id']] ?? 0; ?><span class="pill <?= $pc>0?'pill-blue':'pill-gray' ?>"><?= $pc ?> project<?= $pc==1?'':'s' ?></span></td>
          <td><span class="pill <?= $v['status']==='active'?'pill-green':'pill-gray' ?>"><?= ucfirst($v['status']) ?></span></td>
          <td>
            <div style="display:flex;gap:6px">
              <?php if (rp_is_manager()): ?>
              <button class="btn btn-sm btn-ghost" onclick='openModal("modalVendor",<?= json_encode($v) ?>)'>Edit</button>
              <form method="POST" style="display:inline">
                <input type="hidden" name="action" value="toggle_vendor_status">
                <input type="hidden" name="id" value="<?= $v['id'] ?>">
                <button type="submit" class="btn btn-sm <?= $v['status']==='active' ? 'btn-amber' : 'btn-green' ?>">
                  <?= $v['status']==='active' ? '⏸ Pause' : '▶ Resume' ?>
                </button>
              </form>
              <form method="POST" style="display:inline" onsubmit="return confirm('Delete vendor?')">
                <input type="hidden" name="action" value="delete_vendor">
                <input type="hidden" name="id" value="<?= $v['id'] ?>">
                <button type="submit" class="btn btn-sm btn-danger">Del</button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($vendors)): ?>
      <tr><td colspan="9" style="text-align:center;color:var(--text3);padding:32px">No vendors yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // LEADS
  // ════════════════════════════════════════════
  if ($page === 'leads'):
    $total_pages = ceil($leads_total / 50);
  ?>
  <div class="section-header">
    <div class="section-title">Leads (<?= number_format($leads_total) ?> total)</div>
    <div style="display:flex;gap:8px">
      <?php if (rp_is_superadmin()): ?>
      <button class="btn btn-danger btn-sm" onclick="bulkDeleteLeads()" id="bulkDelBtn" style="display:none">🗑 Delete Selected</button>
      <?php endif; ?>
      <a href="?page=leads&export=csv&search=<?= urlencode($_GET['search']??'') ?>&status=<?= urlencode($_GET['status']??'') ?>&sid=<?= urlencode($_GET['sid']??'') ?>&device=<?= urlencode($_GET['device']??'') ?>&vendor_id=<?= urlencode($_GET['vendor_id']??'') ?>&client_id=<?= urlencode($_GET['client_id']??'') ?>&country=<?= urlencode($_GET['country']??'') ?>&date_from=<?= urlencode($_GET['date_from']??'') ?>&date_to=<?= urlencode($_GET['date_to']??'') ?>" class="btn btn-ghost btn-sm">↓ Export CSV</a>
    </div>
  </div>

  <form method="GET" style="display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap">
    <input type="hidden" name="page" value="leads">
    <input class="search-input" type="text" name="search" placeholder="Search UID or SID..." value="<?= htmlspecialchars($_GET['search']??'') ?>">
    <select class="search-input" name="status" style="min-width:140px">
      <option value="">All Statuses</option>
      <option value="complete" <?= ($_GET['status']??'')==='complete'?'selected':'' ?>>Complete</option>
      <option value="terminate" <?= ($_GET['status']??'')==='terminate'?'selected':'' ?>>Terminate</option>
      <option value="overquota" <?= ($_GET['status']??'')==='overquota'?'selected':'' ?>>Overquota</option>
      <option value="quality_fail" <?= ($_GET['status']??'')==='quality_fail'?'selected':'' ?>>Quality Fail</option>
      <option value="unmatched" <?= ($_GET['status']??'')==='unmatched'?'selected':'' ?>>Unmatched</option>
      <option value="click" <?= ($_GET['status']??'')==='click'?'selected':'' ?>>Click Only</option>
      <option value="pending" <?= ($_GET['status']??'')==='pending'?'selected':'' ?>>Pending</option>
    </select>
    <select class="search-input" name="sid" style="min-width:160px">
      <option value="">All Projects</option>
      <?php foreach ($leads_all_projects as $lp): ?>
      <option value="<?= htmlspecialchars($lp['sid']) ?>" <?= ($_GET['sid']??'')===$lp['sid']?'selected':'' ?>><?= htmlspecialchars($lp['project_name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="search-input" name="device" style="min-width:130px">
      <option value="">All Devices</option>
      <option value="desktop" <?= ($_GET['device']??'')==='desktop'?'selected':'' ?>>Desktop</option>
      <option value="mobile" <?= ($_GET['device']??'')==='mobile'?'selected':'' ?>>Mobile</option>
      <option value="tablet" <?= ($_GET['device']??'')==='tablet'?'selected':'' ?>>Tablet</option>
    </select>
    <select class="search-input" name="vendor_id" style="min-width:150px">
      <option value="">All Sources</option>
      <?php foreach ($leads_all_vendors as $lv): ?>
      <option value="<?= $lv['id'] ?>" <?= ($_GET['vendor_id']??'')==$lv['id']?'selected':'' ?>><?= htmlspecialchars($lv['vendor_name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="search-input" name="client_id" style="min-width:150px">
      <option value="">All Clients</option>
      <?php foreach ($all_clients as $ac): ?>
      <option value="<?= $ac['id'] ?>" <?= ($_GET['client_id']??'')==$ac['id']?'selected':'' ?>><?= htmlspecialchars($ac['client_name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="search-input" name="country" style="min-width:150px">
      <option value="">All Countries</option>
      <?php foreach ($leads_all_countries as $lc): ?>
      <option value="<?= htmlspecialchars($lc) ?>" <?= ($_GET['country']??'')===$lc?'selected':'' ?>><?= htmlspecialchars($lc) ?></option>
      <?php endforeach; ?>
    </select>
    <input class="search-input" type="date" name="date_from" value="<?= htmlspecialchars($_GET['date_from']??'') ?>" style="min-width:auto" title="From date">
    <input class="search-input" type="date" name="date_to" value="<?= htmlspecialchars($_GET['date_to']??'') ?>" style="min-width:auto" title="To date">
    <button type="submit" class="btn btn-primary btn-sm">Filter</button>
    <a href="?page=leads" class="btn btn-ghost btn-sm">Clear</a>
  </form>

  <form method="POST" id="leadsForm">
  <input type="hidden" name="action" value="bulk_delete_leads">
  <input type="hidden" name="lead_ids" id="bulkLeadIds">
  </form>

  <div class="table-wrap" style="overflow-x:auto">
    <table>
      <thead>
        <tr>
          <?php if (rp_is_superadmin()): ?>
          <th><input type="checkbox" id="selectAll" onchange="toggleAll(this)"></th>
          <?php endif; ?>
          <th>#</th><th>UID</th><th>Encrypted ID</th><th>Project</th><th>Vendor</th><th>Client</th><th>Status</th><th>Country</th><th>Device</th><th>LOI</th><th>IP</th><th>Date</th>
          <?php if (rp_is_superadmin()): ?><th>Del</th><?php endif; ?>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($leads as $i => $l):
        $scls = ['complete'=>'pill-green','terminate'=>'pill-amber','overquota'=>'pill-blue','quality_fail'=>'pill-red','click'=>'pill-gray','pending'=>'pill-amber'];
        $is_dup = !empty($l['is_duplicate']);
      ?>
        <tr style="<?= $is_dup ? 'background:rgba(239,68,68,0.05)' : '' ?>">
          <?php if (rp_is_superadmin()): ?>
          <td><input type="checkbox" class="lead-chk" value="<?= $l['id'] ?>" onchange="updateBulk()"></td>
          <?php endif; ?>
          <td><?= ($lpage-1)*50 + $i + 1 ?></td>
          <td class="mono">
            <?= htmlspecialchars($l['original_uid'] ?: '—') ?>
            <?php if ($is_dup): ?>
            <span class="pill pill-red" style="font-size:9px;padding:1px 6px;margin-left:4px">DUP</span>
            <?php endif; ?>
          </td>
          <td class="mono" style="font-size:11px;color:var(--text3)">
            <?php if (!empty($l['encrypted_uid']) && $l['encrypted_uid'] !== $l['original_uid']): ?>
            🔒 <?= htmlspecialchars($l['encrypted_uid']) ?>
            <?php else: ?>
            —
            <?php endif; ?>
          </td>
          <td>
            <div style="font-size:12px;color:var(--text)"><?= htmlspecialchars($l['project_name'] ?: '—') ?></div>
            <div class="mono" style="color:var(--text3)"><?= htmlspecialchars($l['sid']) ?></div>
          </td>
          <td><?php if (!empty($l['vendor_name'])): ?><a href="?page=vendor_view&id=<?= intval($l['vendor_id']) ?>" style="color:var(--accent);text-decoration:none"><?= htmlspecialchars($l['vendor_name']) ?></a><?php else: ?><span style="color:var(--text3)">Direct</span><?php endif; ?></td>
          <td><?= htmlspecialchars($l['client_name'] ?: '—') ?></td>
          <td><span class="pill <?= $scls[$l['status']]??'pill-gray' ?>"><?= ucfirst(str_replace('_',' ',$l['status'])) ?></span></td>
          <td><?= htmlspecialchars($l['country'] ?: '—') ?></td>
          <td><?= htmlspecialchars($l['device'] ?: '—') ?></td>
          <td><?= $l['loi_seconds'] ? round($l['loi_seconds']/60,1).'m' : '—' ?></td>
          <td class="mono"><?= htmlspecialchars(substr($l['ip']??'—',0,15)) ?></td>
          <td><?= $l['created_at'] ? date('d M H:i', strtotime($l['created_at'].' UTC')) : '—' ?></td>
          <?php if (rp_is_superadmin()): ?>
          <td>
            <form method="POST" style="display:inline" onsubmit="return confirm('Delete this lead?')">
              <input type="hidden" name="action" value="delete_lead">
              <input type="hidden" name="id" value="<?= $l['id'] ?>">
              <button type="submit" class="btn btn-sm btn-danger" style="padding:3px 8px">✕</button>
            </form>
          </td>
          <?php endif; ?>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($leads)): ?>
      <tr><td colspan="<?= rp_is_superadmin()?'13':'11' ?>" style="text-align:center;color:var(--text3);padding:32px">No leads found.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php if ($total_pages > 1): ?>
  <div class="pagination">
    <?php for ($p=1; $p<=$total_pages; $p++): ?>
    <a href="?page=leads&lpage=<?= $p ?>&search=<?= urlencode($_GET['search']??'') ?>&status=<?= urlencode($_GET['status']??'') ?>" class="page-btn <?= $p==$lpage?'active':'' ?>"><?= $p ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // VENDOR × PROJECT MATRIX
  // ════════════════════════════════════════════
  if ($page === 'matrix'):
  ?>
  <div class="section-header">
    <div class="section-title" style="margin-bottom:0">🔲 Vendor × Project Matrix</div>
  </div>
  <div style="font-size:12px;color:var(--text3);margin-bottom:14px">Har-vendor-ne-har-project-pe-kitne-clicks/completes-diye — ek-nazar-mein. ⏸ badge-matlab-us-specific-vendor-project-mapping-pause-hai. <em>(Sabse-naye-30-projects, sabse-pehले-50-vendors-alphabetically.)</em></div>
  <?php if (empty($matrix_vendors) || empty($matrix_projects)): ?>
  <div style="text-align:center;padding:32px;color:var(--text3)">Abhi-tak-koi-vendor-ya-project-data-nahi-hai.</div>
  <?php else: ?>
  <div style="overflow-x:auto;border:1px solid var(--border);border-radius:10px">
  <table style="border-collapse:collapse;width:max-content">
    <thead>
      <tr>
        <th style="padding:8px 12px;font-size:11px;text-align:left;position:sticky;left:0;z-index:2;border-right:1px solid var(--border);background:var(--surface)">Vendor</th>
        <?php foreach ($matrix_projects as $mp_col): ?>
        <th style="padding:8px 12px;font-size:11px;text-align:center;white-space:nowrap"><?= htmlspecialchars($mp_col['project_name'] ?: $mp_col['sid']) ?></th>
        <?php endforeach; ?>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($matrix_vendors as $mv_row): ?>
      <tr>
        <td style="padding:8px 12px;font-size:12px;font-weight:600;position:sticky;left:0;background:var(--surface);border-right:1px solid var(--border);white-space:nowrap"><?= htmlspecialchars($mv_row['vendor_name']) ?></td>
        <?php foreach ($matrix_projects as $mp_col):
            $cell_key = $mv_row['id'] . '_' . $mp_col['sid'];
            $cell = $matrix_cells[$cell_key] ?? null;
        ?>
        <td style="padding:8px 12px;font-size:11px;text-align:center;white-space:nowrap">
          <?php if ($cell): ?>
          <a href="?page=leads&vendor_id=<?= $mv_row['id'] ?>&sid=<?= urlencode($mp_col['sid']) ?>" style="color:var(--accent);text-decoration:none">
            <?= number_format($cell['clicks']) ?> / <?= number_format($cell['completes']) ?>
          </a>
          <?php if (!empty($cell['paused'])): ?> <span title="Paused" style="color:#f59e0b">⏸</span><?php endif; ?>
          <?php else: ?>
          <span style="color:var(--text3)">—</span>
          <?php endif; ?>
        </td>
        <?php endforeach; ?>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // VENDOR DETAIL VIEW
  // ════════════════════════════════════════════
  if ($page === 'vendor_view' && $vendor_view):
    $v_clicks    = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=?"); $v_clicks->execute([$vendor_view['id']]); $v_clk=$v_clicks->fetchColumn();
    $v_completes = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=? AND status='complete'"); $v_completes->execute([$vendor_view['id']]); $v_comp=$v_completes->fetchColumn();
    $v_terminates= $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE vendor_id=? AND status='terminate'"); $v_terminates->execute([$vendor_view['id']]); $v_term=$v_terminates->fetchColumn();
  ?>
  <div style="margin-bottom:16px;display:flex;justify-content:space-between;align-items:center">
    <a href="?page=vendors" class="btn btn-ghost btn-sm">← Back to Vendors</a>
    <?php if (rp_is_manager()): ?>
    <form method="POST" style="display:inline">
      <input type="hidden" name="action" value="toggle_vendor_status">
      <input type="hidden" name="id" value="<?= $vendor_view['id'] ?>">
      <button type="submit" class="btn btn-sm <?= $vendor_view['status']==='active' ? 'btn-amber' : 'btn-green' ?>">
        <?= $vendor_view['status']==='active' ? '⏸ Pause This Vendor' : '▶ Resume This Vendor' ?>
      </button>
    </form>
    <?php endif; ?>
  </div>

  <!-- Stat Cards -->
  <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:20px">
    <div class="stat-card" style="--card-color:#6366f1"><div class="stat-label">Clicks</div><div class="stat-value"><?= $v_clk ?></div></div>
    <div class="stat-card" style="--card-color:#22c55e"><div class="stat-label">Completes</div><div class="stat-value"><?= $v_comp ?></div></div>
    <div class="stat-card" style="--card-color:#f59e0b"><div class="stat-label">Terminates</div><div class="stat-value"><?= $v_term ?></div></div>
  </div>

  <!-- Vendor Info -->
  <div class="info-card" style="margin-bottom:20px">
    <div class="info-card-title">Vendor Info</div>
    <div class="info-row"><span class="info-key">Name</span><span class="info-val"><?= htmlspecialchars($vendor_view['vendor_name']) ?></span></div>
    <div class="info-row"><span class="info-key">Email</span><span class="info-val"><?= htmlspecialchars($vendor_view['email'] ?: '—') ?></span></div>
    <div class="info-row"><span class="info-key">Phone</span><span class="info-val"><?= htmlspecialchars($vendor_view['phone'] ?: '—') ?></span></div>
    <div class="info-row"><span class="info-key">Status</span><span class="info-val"><span class="pill <?= $vendor_view['status']==='active'?'pill-green':'pill-gray' ?>"><?= ucfirst($vendor_view['status']) ?></span></span></div>
    <div class="info-row"><span class="info-key">Conv%</span><span class="info-val" style="color:var(--green);font-weight:600"><?= $v_clk>0 ? round(($v_comp/$v_clk)*100,1).'%' : '—' ?></span></div>
  </div>

  <!-- Assigned Projects with Entry Links -->
  <?php if (!empty($vendor_projects)): ?>
  <div class="section-title" style="margin-bottom:12px">Assigned Projects & Entry Links</div>
  <div class="table-wrap" style="margin-bottom:20px">
    <table>
      <thead><tr><th>Project</th><th>SID</th><th>CPI</th><th>Limit</th><th>Status</th><th>Entry Link</th></tr></thead>
      <tbody>
      <?php foreach ($vendor_projects as $vp):
        $el_folder = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
        $el = (isset($_SERVER['HTTPS'])?'https':'http').'://'.$_SERVER['HTTP_HOST'].$el_folder."/vendor.php?sid={$vp['sid']}&vid={$vendor_view['id']}&uid=[UID]";
      ?>
        <tr>
          <td class="td-main"><?= htmlspecialchars($vp['project_name']) ?></td>
          <td class="mono"><?= htmlspecialchars($vp['sid']) ?></td>
          <td>$<?= number_format($vp['cpi'],2) ?></td>
          <td><?= $vp['max_limit'] ?: 'Unlimited' ?></td>
          <td><span class="pill pill-<?= $vp['status']==='active'?'green':'amber' ?>"><?= ucfirst($vp['status']) ?></span></td>
          <td>
            <button class="btn btn-sm btn-blue" onclick="showEntryLink('<?= htmlspecialchars($vendor_view['vendor_name']) ?>','<?= htmlspecialchars($vp['sid']) ?>','<?= htmlspecialchars($el) ?>')">🔗 Entry Link</button>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <!-- Vendor Leads -->
  <div class="section-header">
    <div class="section-title">Leads (<?= count($vendor_leads) ?>)</div>
    <div style="display:flex;gap:8px">
      <?php if (rp_is_superadmin()): ?>
      <form method="POST" onsubmit="return confirm('Delete ALL leads for this vendor?')">
        <input type="hidden" name="action" value="delete_vendor_leads">
        <input type="hidden" name="vendor_id" value="<?= $vendor_view['id'] ?>">
        <button type="submit" class="btn btn-sm btn-danger">🗑 Delete All</button>
      </form>
      <?php endif; ?>
      <a href="?page=leads&vendor_id=<?= $vendor_view['id'] ?>" class="btn btn-ghost btn-sm">🔍 Search All Leads For This Vendor</a>
      <a href="?export=csv&vid=<?= $vendor_view['id'] ?>" class="btn btn-ghost btn-sm">↓ Excel</a>
    </div>
  </div>

  <!-- Per-vendor search/filter - status (Complete/Terminate/Screenout/Quotafull) and UID -->
  <form method="GET" style="display:flex;gap:10px;margin-bottom:14px;flex-wrap:wrap">
    <input type="hidden" name="page" value="vendor_view">
    <input type="hidden" name="id" value="<?= $vendor_view['id'] ?>">
    <input type="text" name="vsearch" class="search-input" placeholder="Search by UID..." value="<?= htmlspecialchars($vv_search) ?>" style="min-width:220px">
    <select name="vstatus" class="search-input" style="min-width:180px">
      <option value="">All Statuses</option>
      <option value="complete" <?= $vv_status==='complete'?'selected':'' ?>>Complete</option>
      <option value="terminate" <?= $vv_status==='terminate'?'selected':'' ?>>Terminate</option>
      <option value="overquota" <?= $vv_status==='overquota'?'selected':'' ?>>Quotafull</option>
      <option value="quality_fail" <?= $vv_status==='quality_fail'?'selected':'' ?>>Quality Fail</option>
      <option value="click" <?= $vv_status==='click'?'selected':'' ?>>Click</option>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">Filter</button>
    <?php if ($vv_status || $vv_search): ?><a href="?page=vendor_view&id=<?= $vendor_view['id'] ?>" class="btn btn-ghost btn-sm">Clear</a><?php endif; ?>
  </form>

  <div class="table-wrap">
    <table>
      <thead><tr><th>UID</th><th>Encrypted ID</th><th>Project</th><th>Status</th><th>Country</th><th>Device</th><th>LOI</th><th>IP</th><th>Date</th></tr></thead>
      <tbody>
      <?php foreach ($vendor_leads as $l):
        $scls = ['complete'=>'pill-green','terminate'=>'pill-amber','overquota'=>'pill-blue','quality_fail'=>'pill-red','click'=>'pill-gray','pending'=>'pill-amber'];
      ?>
        <tr>
          <td class="mono"><?= htmlspecialchars($l['original_uid'] ?: '—') ?></td>
          <td class="mono" style="font-size:11px;color:var(--text3)">
            <?php if (!empty($l['encrypted_uid']) && $l['encrypted_uid'] !== $l['original_uid']): ?>
            🔒 <?= htmlspecialchars($l['encrypted_uid']) ?>
            <?php else: ?>
            —
            <?php endif; ?>
          </td>
          <td>
            <div style="font-size:12px"><?= htmlspecialchars($l['project_name'] ?: '—') ?></div>
            <div class="mono" style="color:var(--text3)"><?= htmlspecialchars($l['sid']) ?></div>
          </td>
          <td><span class="pill <?= $scls[$l['status']]??'pill-gray' ?>"><?= ucfirst(str_replace('_',' ',$l['status'])) ?></span></td>
          <td><?= htmlspecialchars($l['country'] ?: '—') ?></td>
          <td><?= htmlspecialchars($l['device'] ?: '—') ?></td>
          <td><?= $l['loi_seconds'] ? round($l['loi_seconds']/60,1).'m' : '—' ?></td>
          <td class="mono"><?= htmlspecialchars(substr($l['ip']??'—',0,15)) ?></td>
          <td><?= $l['created_at'] ? date('d M H:i', strtotime($l['created_at'].' UTC')) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($vendor_leads)): ?>
      <tr><td colspan="8" style="text-align:center;color:var(--text3);padding:24px">No leads yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // GLOBAL SEARCH
  // ════════════════════════════════════════════
  if ($page === 'global_search'):
  ?>
  <form method="GET" style="display:flex;gap:10px;margin-bottom:24px">
    <input type="hidden" name="page" value="global_search">
    <input class="search-input" type="text" name="q"
      placeholder="Search UID, SID, Country, IP..."
      value="<?= htmlspecialchars($search_query) ?>"
      style="flex:1;min-width:0" autofocus>
    <button type="submit" class="btn btn-primary">🌐 Search</button>
    <?php if ($search_query): ?>
    <a href="?page=global_search" class="btn btn-ghost">Clear</a>
    <?php endif; ?>
  </form>

  <?php if ($search_query): ?>
  <div class="section-title" style="margin-bottom:12px">Results (<?= count($search_results) ?>)</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>UID</th><th>Project</th><th>Status</th><th>Country</th><th>Device</th><th>IP</th><th>Date</th></tr></thead>
      <tbody>
      <?php if (empty($search_results)): ?>
      <tr><td colspan="8" style="text-align:center;color:var(--text3);padding:32px">No results for "<?= htmlspecialchars($search_query) ?>"</td></tr>
      <?php endif; ?>
      <?php foreach ($search_results as $i => $l):
        $scls = ['complete'=>'pill-green','terminate'=>'pill-amber','overquota'=>'pill-blue','quality_fail'=>'pill-red','click'=>'pill-gray','pending'=>'pill-amber'];
      ?>
        <tr <?= !empty($l['is_duplicate']) ? 'style="background:rgba(239,68,68,0.05)"' : '' ?>>
          <td><?= $i+1 ?></td>
          <td>
            <div class="mono"><?= htmlspecialchars($l['original_uid'] ?: '—') ?></div>
            <?php if (!empty($l['is_duplicate'])): ?><span class="pill pill-red" style="font-size:9px;padding:1px 6px">DUP</span><?php endif; ?>
          </td>
          <td>
            <div style="font-size:12px"><?= htmlspecialchars($l['project_name'] ?: '—') ?></div>
            <div class="mono" style="color:var(--text3)"><?= htmlspecialchars($l['sid']) ?></div>
          </td>
          <td><span class="pill <?= $scls[$l['status']]??'pill-gray' ?>"><?= ucfirst(str_replace('_',' ',$l['status'])) ?></span></td>
          <td><?= htmlspecialchars($l['country'] ?: '—') ?></td>
          <td><?= htmlspecialchars($l['device'] ?: '—') ?></td>
          <td class="mono"><?= htmlspecialchars(substr($l['ip']??'—',0,15)) ?></td>
          <td><?= $l['created_at'] ? date('d M H:i', strtotime($l['created_at'].' UTC')) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php else: ?>
  <div class="table-wrap">
    <div style="text-align:center;padding:48px;color:var(--text3)">
      <div style="font-size:32px;margin-bottom:12px">🌐</div>
      <div>Search across all projects, leads, countries and IPs</div>
    </div>
  </div>
  <?php endif; ?>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // SCREENER DATA
  // ════════════════════════════════════════════
  if ($page === 'screener'):
    $sc_total_pages = ceil($screener_total / 50);
  ?>
  <div class="section-header">
    <div class="section-title">Screener Data (<?= number_format($screener_total) ?> total)</div>
    <div style="display:flex;gap:8px">
      <?php if (rp_is_superadmin()): ?>
      <button type="button" class="btn btn-sm btn-danger" onclick="bulkDeleteScreener()">Delete Selected</button>
      <?php endif; ?>
      <a href="?page=screener&export=csv&sc_sid=<?= urlencode($_GET['sc_sid']??'') ?>" class="btn btn-ghost btn-sm">↓ Export CSV</a>
    </div>
  </div>

  <form method="GET" style="display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap">
    <input type="hidden" name="page" value="screener">
    <select class="search-input" name="sc_sid" style="min-width:200px">
      <option value="">All Projects</option>
      <?php foreach ($all_clients as $c): ?>
      <?php endforeach; ?>
      <?php
      $all_sids = $db->query("SELECT DISTINCT sid FROM rp_prescreener_answers ORDER BY sid")->fetchAll();
      foreach ($all_sids as $s):
      ?>
      <option value="<?= htmlspecialchars($s['sid']) ?>" <?= ($_GET['sc_sid']??'')===$s['sid']?'selected':'' ?>>
        <?= htmlspecialchars($s['sid']) ?>
      </option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">Filter</button>
    <a href="?page=screener" class="btn btn-ghost btn-sm">Clear</a>
  </form>

  <form id="screenerBulkForm" method="POST">
    <input type="hidden" name="action" value="bulk_delete_screener">
    <input type="hidden" name="screener_ids" id="screenerIdsInput">
  </form>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <?php if (rp_is_superadmin()): ?><th><input type="checkbox" onclick="toggleAllScreener(this)"></th><?php endif; ?>
          <th>#</th><th>UID</th><th>SID</th><th>Gender</th><th>Age</th><th>Education</th><th>Income</th><th>Device</th><th>Date</th>
          <?php if (rp_is_superadmin()): ?><th>Action</th><?php endif; ?>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($screener_data as $i => $s): ?>
        <tr>
          <?php if (rp_is_superadmin()): ?>
          <td><input type="checkbox" class="screener-check" value="<?= $s['id'] ?>"></td>
          <?php endif; ?>
          <td><?= ($sc_page-1)*50 + $i + 1 ?></td>
          <td class="mono"><?= htmlspecialchars($s['original_uid'] ?: '—') ?></td>
          <td class="mono" style="color:var(--accent)"><?= htmlspecialchars($s['sid'] ?: '—') ?></td>
          <td><?= htmlspecialchars($s['gender'] ?: '—') ?></td>
          <td><?= htmlspecialchars($s['age_group'] ?: '—') ?></td>
          <td><?= htmlspecialchars($s['education'] ?: '—') ?></td>
          <td><?= htmlspecialchars($s['income'] ?: '—') ?></td>
          <td><?= htmlspecialchars($s['device_self'] ?: '—') ?></td>
          <td><?= $s['created_at'] ? date('d M H:i', strtotime($s['created_at'].' UTC')) : '—' ?></td>
          <?php if (rp_is_superadmin()): ?>
          <td>
            <form method="POST" style="display:inline" onsubmit="return confirm('Delete this screener entry?')">
              <input type="hidden" name="action" value="delete_screener">
              <input type="hidden" name="id" value="<?= $s['id'] ?>">
              <button type="submit" class="btn btn-sm btn-danger">Del</button>
            </form>
          </td>
          <?php endif; ?>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($screener_data)): ?>
      <tr><td colspan="<?= rp_is_superadmin() ? 11 : 9 ?>" style="text-align:center;color:var(--text3);padding:32px">
        No screener data yet. Pre-screener flow setup karo pehle.
      </td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php if ($sc_total_pages > 1): ?>
  <div class="pagination">
    <?php for ($p=1; $p<=$sc_total_pages; $p++): ?>
    <a href="?page=screener&sc_page=<?= $p ?>&sc_sid=<?= urlencode($_GET['sc_sid']??'') ?>" class="page-btn <?= $p==$sc_page?'active':'' ?>"><?= $p ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // ALERT SETTINGS
  // ════════════════════════════════════════════
  if ($page === 'alert_settings' && rp_is_superadmin()):
  ?>
  <div class="section-header">
    <div class="section-title">Alert Settings</div>
  </div>
  <div class="table-wrap" style="padding:24px;max-width:560px">
    <form method="POST">
      <input type="hidden" name="action" value="save_alert_settings">
      <div class="form-grid">
        <div class="field span2">
          <label>Telegram Bot Token</label>
          <input type="text" name="telegram_bot_token" value="<?= htmlspecialchars($alert_telegram_token) ?>" placeholder="123456789:ABC-DEF...">
        </div>
        <div class="field span2">
          <label>Telegram Chat ID</label>
          <input type="text" name="telegram_chat_id" value="<?= htmlspecialchars($alert_telegram_chat) ?>" placeholder="-1001234567890 or your user ID">
        </div>
        <div class="field span2">
          <label>Alert Email Address</label>
          <input type="email" name="alert_email" value="<?= htmlspecialchars($alert_email_addr) ?>" placeholder="you@example.com">
        </div>
      </div>
      <p style="font-size:12px;color:var(--text3);margin:12px 0 16px;line-height:1.6">
        Ye settings alerts ke liye use hongi — quota reach hone pe aur speeder detect hone pe automatic notification bhejegi.
        Telegram ke liye <a href="https://core.telegram.org/bots#how-do-i-create-a-bot" target="_blank" style="color:var(--accent)">Bot banake</a> token yahan daalo, aur apna Chat ID <a href="https://t.me/userinfobot" target="_blank" style="color:var(--accent)">@userinfobot</a> se le lo.
      </p>
      <button type="submit" class="btn btn-primary">Save Settings</button>
    </form>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // AUDIT LOG
  // ════════════════════════════════════════════
  if ($page === 'audit_log' && rp_is_superadmin()):
  ?>
  <div class="section-header">
    <div class="section-title">Audit Log</div>
    <?php if (!empty($audit_rows)): ?>
    <form method="POST" onsubmit="return confirm('Poora audit log clear kar do? Ye action bhi khud ek entry ke roop mein log hoga.')">
      <input type="hidden" name="action" value="clear_audit_log">
      <button type="submit" class="btn btn-sm btn-danger">Clear All</button>
    </form>
    <?php endif; ?>
  </div>
  <p style="font-size:12px;color:var(--text3);margin-bottom:16px">Har destructive action (delete) yahan track hota hai — kisne, kya, kab delete kiya. Latest 300 entries.</p>
  <div class="table-wrap">
    <table>
      <thead><tr><th>User</th><th>Action</th><th>Details</th><th>Date/Time</th><th>Action</th></tr></thead>
      <tbody>
      <?php foreach ($audit_rows as $al): ?>
        <tr>
          <td class="td-main"><?= htmlspecialchars($al['user_name'] ?: '—') ?></td>
          <td><span class="pill pill-red"><?= htmlspecialchars($al['action']) ?></span></td>
          <td style="font-size:12px;color:var(--text3)"><?= htmlspecialchars($al['details'] ?: '—') ?></td>
          <td><?= date('d M Y, H:i:s', strtotime($al['created_at'].' UTC')) ?></td>
          <td>
            <form method="POST" style="display:inline" onsubmit="return confirm('Delete this audit entry?')">
              <input type="hidden" name="action" value="delete_audit_entry">
              <input type="hidden" name="id" value="<?= $al['id'] ?>">
              <button type="submit" class="btn btn-sm btn-danger">Del</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($audit_rows)): ?>
      <tr><td colspan="5" style="text-align:center;color:var(--text3);padding:24px">No deletions logged yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>


  <?php
  // ════════════════════════════════════════════
  // NOTES
  // ════════════════════════════════════════════
  if ($page === 'notes'):
  ?>
  <div class="section-header">
    <div class="section-title">Notes (<?= count($all_notes) ?>)</div>
    <button class="btn btn-primary" onclick="openModal('modalNote',{})">+ Add Note</button>
  </div>

  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px">
    <?php foreach ($all_notes as $n): ?>
    <div class="table-wrap" style="padding:16px">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">
        <div style="font-weight:600;font-size:14px"><?= htmlspecialchars($n['title'] ?: '(No title)') ?></div>
        <div style="display:flex;gap:6px;flex-shrink:0">
          <button class="btn btn-sm btn-ghost" onclick='openModal("modalNote",<?= json_encode($n) ?>)'>Edit</button>
          <form method="POST" style="display:inline" onsubmit="return confirm('Delete this note?')">
            <input type="hidden" name="action" value="delete_note">
            <input type="hidden" name="note_id" value="<?= $n['id'] ?>">
            <button type="submit" class="btn btn-sm btn-danger">Del</button>
          </form>
        </div>
      </div>
      <div style="font-size:13px;color:var(--text2);white-space:pre-wrap;line-height:1.5;max-height:160px;overflow-y:auto"><?= htmlspecialchars($n['content']) ?></div>
      <div style="font-size:10px;color:var(--text3);margin-top:10px">Updated <?= date('d M Y, H:i', strtotime($n['updated_at'].' UTC')) ?></div>
    </div>
    <?php endforeach; ?>
    <?php if (empty($all_notes)): ?>
    <p style="color:var(--text3);grid-column:1/-1;text-align:center;padding:32px">Koi note nahi hai abhi. "+ Add Note" pe click karke pehla note banao.</p>
    <?php endif; ?>
  </div>

  <!-- Note Modal -->
  <div class="modal-overlay" id="modalNote">
    <div class="modal">
      <button class="modal-close" onclick="closeModal('modalNote')">×</button>
      <div class="modal-title" id="modalNoteTitle">Add Note</div>
      <form method="POST">
        <input type="hidden" name="action" value="save_note">
        <input type="hidden" name="note_id" id="note_id" value="">
        <div class="form-grid">
          <div class="field span2"><label>Title</label><input type="text" name="title" id="note_title" placeholder="e.g. Client callback reminder"></div>
          <div class="field span2"><label>Content</label><textarea name="content" id="note_content" rows="8" style="width:100%;font-family:inherit;padding:10px;border-radius:6px;border:1px solid var(--border);background:var(--surface);color:var(--text)"></textarea></div>
        </div>
        <div style="margin-top:16px;display:flex;gap:10px">
          <button type="submit" class="btn btn-primary">Save</button>
          <button type="button" class="btn btn-ghost" onclick="closeModal('modalNote')">Cancel</button>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // BILLING / INVOICE TRACKER
  // ════════════════════════════════════════════
  if ($page === 'billing'):
  ?>
  <div class="section-header">
    <div class="section-title">Billing Tracker</div>
  </div>

  <div class="stats-grid" style="margin-bottom:20px">
    <div class="stat-card" style="--card-color:#16a34a">
      <div class="stat-label">Revenue (Client CPI × Completes)</div>
      <div class="stat-value">$<?= number_format($billing_grand_revenue, 2) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#dc2626">
      <div class="stat-label">Cost (Supplier CPI × Completes)</div>
      <div class="stat-value">$<?= number_format($billing_grand_cost, 2) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#2563eb">
      <div class="stat-label">Margin (Profit)</div>
      <div class="stat-value">$<?= number_format($billing_grand_margin, 2) ?></div>
    </div>
  </div>

  <div class="table-wrap">
    <table>
      <thead><tr><th>Project</th><th>Client</th><th>Client CPI</th><th>Supplier CPI</th><th>Completes</th><th>Revenue</th><th>Cost</th><th>Margin</th><th>Status</th><th>Notes</th><?php if (rp_is_manager()): ?><th>Action</th><?php endif; ?></tr></thead>
      <tbody>
      <?php foreach ($billing_rows as $br):
        $st_cls = ['unpaid'=>'pill-red','invoiced'=>'pill-amber','paid'=>'pill-green'];
      ?>
        <tr>
          <td class="td-main"><?= htmlspecialchars($br['project_name']) ?><div style="font-size:11px;color:var(--text3)"><?= htmlspecialchars($br['sid']) ?></div></td>
          <td><?= htmlspecialchars($br['client_name'] ?: '—') ?></td>
          <td>$<?= number_format($br['cpi'],2) ?></td>
          <td>$<?= number_format($br['supplier_cpi'],2) ?></td>
          <td><?= number_format($br['completes']) ?></td>
          <td style="font-weight:600;color:#16a34a">$<?= number_format($br['revenue'],2) ?></td>
          <td style="color:#dc2626">$<?= number_format($br['cost'],2) ?></td>
          <td style="font-weight:600;color:<?= $br['margin']>=0?'#2563eb':'#dc2626' ?>">$<?= number_format($br['margin'],2) ?></td>
          <td><span class="pill <?= $st_cls[$br['invoice_status']] ?>"><?= ucfirst($br['invoice_status']) ?></span></td>
          <td style="font-size:12px;color:var(--text3)"><?= htmlspecialchars($br['invoice_notes'] ?: '—') ?></td>
          <?php if (rp_is_manager()): ?>
          <td>
            <form method="POST" style="display:flex;gap:4px;align-items:center">
              <input type="hidden" name="action" value="update_invoice_status">
              <input type="hidden" name="project_id" value="<?= $br['id'] ?>">
              <select name="status" style="font-size:12px;padding:4px">
                <option value="unpaid" <?= $br['invoice_status']==='unpaid'?'selected':'' ?>>Unpaid</option>
                <option value="invoiced" <?= $br['invoice_status']==='invoiced'?'selected':'' ?>>Invoiced</option>
                <option value="paid" <?= $br['invoice_status']==='paid'?'selected':'' ?>>Paid</option>
              </select>
              <button type="submit" class="btn btn-sm btn-ghost">Save</button>
            </form>
          </td>
          <?php endif; ?>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($billing_rows)): ?>
      <tr><td colspan="<?= rp_is_manager() ? 11 : 10 ?>" style="text-align:center;color:var(--text3);padding:24px">No projects yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // QUALITY SCORE MODULE
  // ════════════════════════════════════════════
  if ($page === 'quality_score'):
  ?>
  <div class="section-header">
    <div class="section-title">Quality Score</div>
  </div>

  <div class="stats-grid" style="margin-bottom:20px">
    <div class="stat-card" style="--card-color:#8b5cf6">
      <div class="stat-label">Overall Avg Quality Score</div>
      <div class="stat-value"><?= $qs_overall_avg ?>/100</div>
    </div>
    <div class="stat-card" style="--card-color:#6366f1">
      <div class="stat-label">Completes Scored</div>
      <div class="stat-value"><?= count($qs_leads) ?></div>
    </div>
  </div>

  <div class="section-header" style="margin-top:8px">
    <div class="section-title" style="margin-bottom:0;font-size:14px">Average Quality Score by Vendor</div>
  </div>
  <div class="table-wrap" style="margin-bottom:24px">
    <table>
      <thead><tr><th>Vendor</th><th>Completes Scored</th><th>Avg Quality Score</th></tr></thead>
      <tbody>
      <?php foreach ($qs_vendor_scores as $vname => $vs): ?>
        <tr>
          <td class="td-main"><?= htmlspecialchars($vname) ?></td>
          <td><?= $vs['count'] ?></td>
          <td>
            <span class="pill <?= $vs['avg']>=80?'pill-green':($vs['avg']>=50?'pill-amber':'pill-red') ?>"><?= $vs['avg'] ?>/100</span>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($qs_vendor_scores)): ?>
      <tr><td colspan="3" style="text-align:center;color:var(--text3);padding:24px">No completed leads yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <div class="section-header">
    <div class="section-title" style="margin-bottom:0;font-size:14px">Individual Lead Scores (Latest 500 Completes)</div>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>UID</th><th>Project</th><th>Vendor</th><th>Score</th><th>Flags</th></tr></thead>
      <tbody>
      <?php foreach ($qs_leads as $ql): ?>
        <tr>
          <td class="mono"><?= htmlspecialchars($ql['original_uid'] ?: '—') ?></td>
          <td><?= htmlspecialchars($ql['project_name'] ?: $ql['sid']) ?></td>
          <td><?= htmlspecialchars($ql['vendor_name'] ?: 'Direct') ?></td>
          <td><span class="pill <?= $ql['quality_score']>=80?'pill-green':($ql['quality_score']>=50?'pill-amber':'pill-red') ?>"><?= $ql['quality_score'] ?>/100</span></td>
          <td style="font-size:12px;color:var(--text3)"><?= htmlspecialchars(implode(', ', $ql['quality_reasons'])) ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($qs_leads)): ?>
      <tr><td colspan="5" style="text-align:center;color:var(--text3);padding:24px">No completed leads yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // RECONCILE MODULE
  // ════════════════════════════════════════════
  if ($page === 'reconcile'):
  ?>
  <div class="section-header">
    <div class="section-title">Reconcile</div>
  </div>

  <div class="info-card" style="margin-bottom:20px;max-width:640px">
    <div class="info-card-title">Upload External Report (CSV)</div>
    <p style="font-size:12px;color:var(--text3);padding:8px 0;line-height:1.6">
      CSV mein 2 columns hone chahiye: <b>uid</b> aur <b>status</b> (pehli row header). Hum ye compare karenge apne system ke data se — matches, mismatches, aur missing entries dikhenge.
    </p>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="action" value="reconcile_upload">
      <div class="form-grid">
        <div class="field span2">
          <label>Project</label>
          <select name="reconcile_sid" required>
            <option value="">-- Select Project --</option>
            <?php foreach ($all_projects_list as $ap): ?>
            <option value="<?= htmlspecialchars($ap['sid']) ?>"><?= htmlspecialchars($ap['project_name']) ?> (<?= htmlspecialchars($ap['sid']) ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field span2">
          <label>CSV File</label>
          <input type="file" name="reconcile_file" accept=".csv" required>
        </div>
      </div>
      <button type="submit" class="btn btn-primary" style="margin-top:12px">Upload & Compare</button>
    </form>
  </div>


  <?php if ($reconcile_summary): ?>
  <div class="stats-grid" style="margin-bottom:20px">
    <div class="stat-card" style="--card-color:#22c55e"><div class="stat-label">Matched</div><div class="stat-value"><?= $reconcile_summary['matched'] ?></div></div>
    <div class="stat-card" style="--card-color:#ef4444"><div class="stat-label">Mismatched</div><div class="stat-value"><?= $reconcile_summary['mismatched'] ?></div></div>
    <div class="stat-card" style="--card-color:#f59e0b"><div class="stat-label">Missing in System</div><div class="stat-value"><?= $reconcile_summary['missing_in_system'] ?></div></div>
    <div class="stat-card" style="--card-color:#3b82f6"><div class="stat-label">Missing in File</div><div class="stat-value"><?= $reconcile_summary['missing_in_file'] ?></div></div>
  </div>

  <div class="table-wrap">
    <table>
      <thead><tr><th>UID</th><th>File Status</th><th>System Status</th><th>Result</th></tr></thead>
      <tbody>
      <?php
        $rc_cls = ['match'=>'pill-green','mismatch'=>'pill-red','missing_in_system'=>'pill-amber','missing_in_file'=>'pill-blue'];
        $rc_lbl = ['match'=>'Match','mismatch'=>'Mismatch','missing_in_system'=>'Missing in System','missing_in_file'=>'Missing in File'];
      ?>
      <?php foreach ($reconcile_results as $rr): ?>
        <tr>
          <td class="mono"><?= htmlspecialchars($rr['uid']) ?></td>
          <td><?= htmlspecialchars($rr['file_status'] ?: '—') ?></td>
          <td><?= htmlspecialchars($rr['system_status'] ?: '—') ?></td>
          <td><span class="pill <?= $rc_cls[$rr['result']] ?>"><?= $rc_lbl[$rr['result']] ?></span></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // FRAUD DETECTION MODULE
  // ════════════════════════════════════════════
  if ($page === 'fraud'):
  ?>
  <div class="section-header">
    <div class="section-title">Fraud Detection</div>
  </div>

  <div class="stats-grid" style="margin-bottom:20px">
    <div class="stat-card" style="--card-color:#ef4444">
      <div class="stat-label">Total Flags Raised</div>
      <div class="stat-value"><?= number_format($fraud_flag_count) ?></div>
    </div>
  </div>

  <div class="section-header" style="margin-top:8px">
    <div class="section-title" style="margin-bottom:0;font-size:14px">🎭 Same IP — Multiple Fake UIDs on Same Project</div>
  </div>
  <div class="table-wrap" style="margin-bottom:24px">
    <table>
      <thead><tr><th>IP Address</th><th>Project</th><th>Distinct UIDs</th><th>Completes</th></tr></thead>
      <tbody>
      <?php foreach ($fraud_same_project as $fp): ?>
        <tr>
          <td class="mono"><?= htmlspecialchars($fp['ip']) ?></td>
          <td><?= htmlspecialchars($fp['pname'] ?: $fp['sid']) ?></td>
          <td><span class="pill pill-red"><?= $fp['uid_count'] ?> UIDs</span></td>
          <td><?= $fp['completes'] ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($fraud_same_project)): ?>
      <tr><td colspan="4" style="text-align:center;color:var(--text3);padding:24px">No suspicious IP patterns found.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <div class="section-header">
    <div class="section-title" style="margin-bottom:0;font-size:14px">🌐 Same IP Active Across Multiple Projects</div>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>IP Address</th><th>Distinct Projects</th><th>Total Leads</th><th>Total Completes</th></tr></thead>
      <tbody>
      <?php foreach ($fraud_cross_project as $fc): ?>
        <tr>
          <td class="mono"><?= htmlspecialchars($fc['ip']) ?></td>
          <td><span class="pill pill-amber"><?= $fc['project_count'] ?> projects</span></td>
          <td><?= $fc['total_leads'] ?></td>
          <td><?= $fc['total_completes'] ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($fraud_cross_project)): ?>
      <tr><td colspan="4" style="text-align:center;color:var(--text3);padding:24px">No cross-project IP patterns found.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // QUALITY FLAGS (Speeder + Duplicate Detection)
  // ════════════════════════════════════════════
  if ($page === 'quality_flags'):
  ?>
  <div class="section-header">
    <div class="section-title">Quality Flags</div>
  </div>

  <div class="stats-grid" style="margin-bottom:20px">
    <div class="stat-card" style="--card-color:#ef4444">
      <div class="stat-label">Duplicate Clicks</div>
      <div class="stat-value"><?= number_format($qf_dupe_count) ?></div>
    </div>
    <div class="stat-card" style="--card-color:#f59e0b">
      <div class="stat-label">Speeders (&lt;30% of expected LOI)</div>
      <div class="stat-value"><?= number_format($qf_speeder_count) ?></div>
    </div>
  </div>

  <div class="section-header" style="margin-top:8px">
    <div class="section-title" style="margin-bottom:0;font-size:14px">🔁 Duplicate Leads</div>
  </div>
  <div class="table-wrap" style="margin-bottom:24px">
    <table>
      <thead><tr><th>UID</th><th>Project</th><th>Status</th><th>IP</th><th>Date</th></tr></thead>
      <tbody>
      <?php foreach ($qf_dupes as $d): ?>
        <tr>
          <td class="mono"><?= htmlspecialchars($d['original_uid'] ?: '—') ?></td>
          <td><?= htmlspecialchars($d['project_name'] ?: $d['sid']) ?></td>
          <td><span class="pill pill-amber">DUP</span></td>
          <td class="mono"><?= htmlspecialchars($d['ip'] ?: '—') ?></td>
          <td><?= $d['created_at'] ? date('d M H:i', strtotime($d['created_at'].' UTC')) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($qf_dupes)): ?>
      <tr><td colspan="5" style="text-align:center;color:var(--text3);padding:24px">No duplicate leads found.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <div class="section-header">
    <div class="section-title" style="margin-bottom:0;font-size:14px">⚡ Speeders</div>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>UID</th><th>Project</th><th>Expected LOI</th><th>Actual Time</th><th>Date</th></tr></thead>
      <tbody>
      <?php foreach ($qf_speeders as $s): ?>
        <tr>
          <td class="mono"><?= htmlspecialchars($s['original_uid'] ?: '—') ?></td>
          <td><?= htmlspecialchars($s['project_name'] ?: $s['sid']) ?></td>
          <td><?= $s['expected_loi'] ?> min</td>
          <td style="color:#ef4444;font-weight:600"><?= round($s['loi_seconds']/60, 1) ?> min</td>
          <td><?= $s['end_time'] ? date('d M H:i', strtotime($s['end_time'])) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($qf_speeders)): ?>
      <tr><td colspan="5" style="text-align:center;color:var(--text3);padding:24px">No speeders detected.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // UID LOOKUP
  // ════════════════════════════════════════════
  if ($page === 'uid_lookup'):
  $bulk_mode = isset($_POST['bulk_uids']);
  $bulk_results = [];
  if ($bulk_mode) {
      $raw = trim($_POST['bulk_uids'] ?? '');
      $uids = array_unique(array_filter(array_map('trim', preg_split('/[\n,]+/', $raw))));
      foreach ($uids as $u) {
          $lr = $db->prepare("SELECT l.*, p.project_name FROM rp_leads l LEFT JOIN rp_projects p ON l.sid=p.sid WHERE l.original_uid=? OR l.encrypted_uid=? ORDER BY l.id DESC LIMIT 5");
          $lr->execute([$u, $u]);
          $rows = $lr->fetchAll();
          $bulk_results[$u] = $rows;
      }
  }
  ?>
  <div class="section-header">
    <div class="section-title">UID Lookup</div>
  </div>

  <!-- Tab switcher -->
  <div style="display:flex;gap:8px;margin-bottom:20px">
    <button onclick="switchTab('single')" id="tab_single" class="btn btn-primary btn-sm">Single UID</button>
    <button onclick="switchTab('bulk')" id="tab_bulk" class="btn btn-ghost btn-sm">Bulk UIDs</button>
  </div>

  <!-- Single UID Search -->
  <div id="panel_single" <?= $bulk_mode ? 'style="display:none"' : '' ?>>
    <form method="GET" style="display:flex;gap:10px;margin-bottom:24px">
      <input type="hidden" name="page" value="uid_lookup">
      <input class="search-input" type="text" name="q"
        placeholder="Enter Original UID or Encrypted UID..."
        value="<?= htmlspecialchars($uid_lookup_query) ?>"
        style="flex:1;min-width:0" autofocus>
      <button type="submit" class="btn btn-primary">🔍 Search</button>
      <?php if ($uid_lookup_query): ?>
      <a href="?page=uid_lookup" class="btn btn-ghost">Clear</a>
      <?php endif; ?>
    </form>

    <?php if ($uid_lookup_query && $uid_lookup_result !== null): ?>
      <?php if (!empty($uid_map)): ?>
      <div class="info-card" style="margin-bottom:20px">
        <div class="info-card-title">UID Mapping Found</div>
        <div class="info-row"><span class="info-key">Original UID</span><span class="info-val mono"><?= htmlspecialchars($uid_map['original_uid']) ?></span></div>
        <div class="info-row"><span class="info-key">Encrypted UID</span><span class="info-val mono" style="font-size:11px;color:var(--accent)"><?= htmlspecialchars($uid_map['encrypted_uid']) ?></span></div>
        <div class="info-row"><span class="info-key">SID</span><span class="info-val mono"><?= htmlspecialchars($uid_map['sid']) ?></span></div>
        <div class="info-row"><span class="info-key">Source</span><span class="info-val"><?= htmlspecialchars($uid_map['source']) ?></span></div>
      </div>
      <?php endif; ?>

      <div class="section-title" style="margin-bottom:12px">Leads Found (<?= count($uid_lookup_result) ?>)</div>
      <?php if (empty($uid_lookup_result)): ?>
      <div class="table-wrap"><div style="text-align:center;padding:40px;color:var(--text3)">No leads found for "<strong><?= htmlspecialchars($uid_lookup_query) ?></strong>"</div></div>
      <?php else: ?>
      <div class="table-wrap">
        <table>
          <thead><tr><th>#</th><th>UID</th><th>Encrypted ID</th><th>Project</th><th>Status</th><th>Country</th><th>Device</th><th>LOI</th><th>IP</th><th>Date</th></tr></thead>
          <tbody>
          <?php foreach ($uid_lookup_result as $i => $l):
            $scls = ['complete'=>'pill-green','terminate'=>'pill-amber','overquota'=>'pill-blue','quality_fail'=>'pill-red','click'=>'pill-gray','pending'=>'pill-amber'];
          ?>
            <tr <?= !empty($l['is_duplicate']) ? 'style="background:rgba(239,68,68,0.05)"' : '' ?>>
              <td><?= $i+1 ?></td>
              <td>
                <div class="mono"><?= htmlspecialchars($l['original_uid'] ?: '—') ?></div>
                <?php if (!empty($l['is_duplicate'])): ?><span class="pill pill-red" style="font-size:9px;padding:1px 6px">DUP</span><?php endif; ?>
              </td>
              <td class="mono" style="font-size:10px;color:var(--text3)">
                <?php if ($l['encrypted_uid'] && $l['encrypted_uid'] !== $l['original_uid']): ?>
                <?= htmlspecialchars($l['encrypted_uid']) ?>
                <?php else: ?>
                —
                <?php endif; ?>
              </td>
              <td>
                <div style="font-size:12px"><?= htmlspecialchars($l['project_name'] ?: '—') ?></div>
                <div class="mono" style="color:var(--text3)"><?= htmlspecialchars($l['sid']) ?></div>
              </td>
              <td><span class="pill <?= $scls[$l['status']]??'pill-gray' ?>"><?= ucfirst(str_replace('_',' ',$l['status'])) ?></span></td>
              <td><?= htmlspecialchars($l['country'] ?: '—') ?></td>
              <td><?= htmlspecialchars($l['device'] ?: '—') ?></td>
              <td><?= $l['loi_seconds'] ? round($l['loi_seconds']/60,1).'m' : '—' ?></td>
              <td class="mono"><?= htmlspecialchars(substr($l['ip']??'—',0,15)) ?></td>
              <td><?= $l['created_at'] ? date('d M H:i', strtotime($l['created_at'].' UTC')) : '—' ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    <?php else: ?>
    <div class="table-wrap">
      <div style="text-align:center;padding:48px;color:var(--text3)">
        <div style="font-size:32px;margin-bottom:12px">🔍</div>
        <div>Enter a UID above to search across all projects</div>
        <div style="font-size:12px;margin-top:6px">Works with both original and encrypted UIDs</div>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <!-- Bulk UID Search -->
  <div id="panel_bulk" <?= $bulk_mode ? '' : 'style="display:none"' ?>>
    <form method="POST" action="?page=uid_lookup">
      <div class="field" style="margin-bottom:16px">
        <label>Paste UIDs (one per line, or comma separated)</label>
        <textarea name="bulk_uids" rows="6" style="background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:12px;font-size:13px;color:var(--text);font-family:'DM Mono',monospace;width:100%;resize:vertical"
          placeholder="uid001&#10;uid002&#10;uid003"><?= htmlspecialchars($_POST['bulk_uids'] ?? '') ?></textarea>
      </div>
      <button type="submit" class="btn btn-primary">🔍 Search All</button>
    </form>

    <?php if ($bulk_mode && !empty($bulk_results)): ?>
    <div style="margin-top:24px">
      <div class="section-title" style="margin-bottom:12px">Results (<?= count($bulk_results) ?> UIDs)</div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Input UID</th><th>Found</th><th>Project</th><th>Status</th><th>Country</th><th>Device</th><th>Date</th></tr></thead>
          <tbody>
          <?php foreach ($bulk_results as $u => $rows):
            $scls = ['complete'=>'pill-green','terminate'=>'pill-amber','overquota'=>'pill-blue','quality_fail'=>'pill-red','click'=>'pill-gray','pending'=>'pill-amber'];
            if (empty($rows)):
          ?>
            <tr style="opacity:0.5">
              <td class="mono"><?= htmlspecialchars($u) ?></td>
              <td><span class="pill pill-gray">Not Found</span></td>
              <td colspan="5" style="color:var(--text3)">—</td>
            </tr>
          <?php else: foreach ($rows as $l): ?>
            <tr <?= !empty($l['is_duplicate']) ? 'style="background:rgba(239,68,68,0.05)"' : '' ?>>
              <td class="mono">
                <?= htmlspecialchars($u) ?>
                <?php if (!empty($l['is_duplicate'])): ?><span class="pill pill-red" style="font-size:9px;padding:1px 6px">DUP</span><?php endif; ?>
              </td>
              <td><span class="pill pill-green" style="font-size:10px">✓ Found</span></td>
              <td>
                <div style="font-size:12px"><?= htmlspecialchars($l['project_name'] ?: '—') ?></div>
                <div class="mono" style="color:var(--text3);font-size:11px"><?= htmlspecialchars($l['sid']) ?></div>
              </td>
              <td><span class="pill <?= $scls[$l['status']]??'pill-gray' ?>"><?= ucfirst(str_replace('_',' ',$l['status'])) ?></span></td>
              <td><?= htmlspecialchars($l['country'] ?: '—') ?></td>
              <td><?= htmlspecialchars($l['device'] ?: '—') ?></td>
              <td><?= $l['created_at'] ? date('d M H:i', strtotime($l['created_at'].' UTC')) : '—' ?></td>
            </tr>
          <?php endforeach; endif; endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php elseif ($bulk_mode && empty($bulk_results)): ?>
    <div style="text-align:center;padding:32px;color:var(--text3);margin-top:16px">No results found.</div>
    <?php endif; ?>
  </div>

  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // TEAM
  // ════════════════════════════════════════════
  if ($page === 'team' && rp_is_superadmin()):
  ?>
  <div class="section-header">
    <div class="section-title">Team Members (<?= count($team_users) ?>)</div>
    <button class="btn btn-primary" onclick="openModal('modalUser',{})">+ Add Member</button>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Role</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($team_users as $i => $u): ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td class="td-main"><?= htmlspecialchars($u['name']) ?></td>
          <td><?= htmlspecialchars($u['email']) ?></td>
          <td>
            <?php
            $rcls = ['superadmin'=>'pill-purple','manager'=>'pill-blue','viewer'=>'pill-gray'];
            echo '<span class="pill '.($rcls[$u['role']]??'pill-gray').'">'.ucfirst($u['role']).'</span>';
            ?>
          </td>
          <td>
            <div style="display:flex;gap:6px">
              <button class="btn btn-sm btn-ghost" onclick='openModal("modalUser",<?= json_encode(['id'=>$u['id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role']]) ?>)'>Edit</button>
              <?php if ($u['id'] != $user['id']): ?>
              <form method="POST" style="display:inline" onsubmit="return confirm('Delete this user?')">
                <input type="hidden" name="action" value="delete_user">
                <input type="hidden" name="id" value="<?= $u['id'] ?>">
                <button type="submit" class="btn btn-sm btn-danger">Del</button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // BACKUP (manual, on-demand — no scheduled deletion of any kind)
  // ════════════════════════════════════════════
  if ($page === 'backup' && rp_is_superadmin()):
  ?>
  <div class="section-header">
    <div class="section-title">Backup</div>
  </div>
  <div class="info-card" style="max-width:640px">
    <div class="info-card-title">Download Full Backup</div>
    <p style="font-size:13px;color:var(--text2);padding:10px 0;line-height:1.7">
      Ek click mein poori tarah leads, projects, vendors, clients aur baaki core data ka <b>.sql</b> file download ho jayega — aapke computer pe.
    </p>
    <p style="font-size:12px;color:var(--text3);padding:0 0 14px 0;line-height:1.7">
      ⚠️ Ye sirf ek <b>on-demand download</b> hai — koi automatic schedule nahi hai, aur is se <b>kabhi bhi kuch delete nahi hota</b>. Sara data hamesha server pe hi rehta hai jab tak aap khud, manually, phpMyAdmin se delete na karo.
    </p>
    <a href="?backup=download" class="btn btn-primary">⬇ Download Full Backup (.sql)</a>
  </div>
  <?php endif; ?>

  <?php
  // ════════════════════════════════════════════
  // CHANGE PASSWORD
  // ════════════════════════════════════════════
  if ($page === 'change_password'):
    $cp_err = $_GET['err'] ?? '';
    $cp_msg = $_GET['msg'] ?? '';
  ?>
  <div style="max-width:480px">
    <?php if ($cp_err): ?>
    <div style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);border-radius:8px;padding:10px 16px;font-size:13px;color:#f87171;margin-bottom:16px">⚠ <?= htmlspecialchars($cp_err) ?></div>
    <?php endif; ?>
    <?php if ($cp_msg): ?>
    <div class="flash">✓ <?= htmlspecialchars($cp_msg) ?></div>
    <?php endif; ?>

    <div class="info-card">
      <div class="info-card-title">Change Your Password</div>
      <form method="POST" style="margin-top:16px">
        <input type="hidden" name="action" value="change_password">
        <div class="form-grid full">
          <div class="field">
            <label>Current Password</label>
            <input type="password" name="current_password" required placeholder="••••••••">
          </div>
          <div class="field">
            <label>New Password</label>
            <input type="password" name="new_password" required placeholder="Min 6 characters">
          </div>
          <div class="field">
            <label>Confirm New Password</label>
            <input type="password" name="confirm_password" required placeholder="Repeat new password">
          </div>
        </div>
        <div style="margin-top:16px">
          <button type="submit" class="btn btn-primary">🔑 Update Password</button>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>

  </div><!-- /content -->
</div><!-- /main -->

<!-- Edit Assignment Modal -->
<div class="modal-overlay" id="editAssignmentModal">
  <div class="modal" style="max-width:400px">
    <button class="modal-close" onclick="closeModal('editAssignmentModal')">×</button>
    <div class="modal-title" id="editAssignmentTitle">Edit Vendor Assignment</div>
    <form method="POST">
      <input type="hidden" name="action" value="edit_assignment">
      <input type="hidden" name="pv_id" id="ea_pv_id">
      <input type="hidden" name="project_id" id="ea_project_id">
      <div class="form-grid">
        <div class="field"><label>CPI ($)</label><input type="number" name="cpi" id="ea_cpi" step="0.01" value="0"></div>
        <div class="field"><label>Max Limit</label><input type="number" name="max_limit" id="ea_limit" value="0" placeholder="0 = Unlimited"></div>
      </div>
      <div style="margin-top:16px;display:flex;gap:10px">
        <button type="submit" class="btn btn-primary">Save</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('editAssignmentModal')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Entry Link Modal -->
<div class="modal-overlay" id="entryLinkModal">
  <div class="modal" style="max-width:480px">
    <button class="modal-close" onclick="closeModal('entryLinkModal')">×</button>
    <div class="modal-title">Entry Link</div>
    <div id="entryLinkVendorName" style="font-size:12px;color:var(--text3);margin-bottom:4px"></div>
    <div id="entryLinkProject" style="font-size:12px;color:var(--text3);margin-bottom:16px"></div>
    <div class="url-box">
      <div class="url-val" id="entryLinkUrl"></div>
    </div>
    <button class="btn btn-primary" style="margin-top:12px;width:100%" onclick="copyText(document.getElementById('entryLinkUrl').textContent)">Copy Link</button>
  </div>
</div>

<!-- Client Redirect URLs Modal -->
<div class="modal-overlay" id="clientRedirectModal">
  <div class="modal" style="max-width:600px">
    <button class="modal-close" onclick="closeModal('clientRedirectModal')">×</button>
    <div class="modal-title">Client Redirect URLs</div>
    <div id="clientRedirectName" style="font-size:12px;color:var(--text3);margin-bottom:4px"></div>
    <div style="font-size:12px;color:var(--text3);margin-bottom:16px">
      Give these 4 URLs to this client ONCE — they'll keep working correctly for every future project you assign this client to, with no per-project edits ever needed.
    </div>
    <?php foreach (['Complete','Terminate','Overquota','Quality Fail'] as $label): ?>
    <div style="margin-bottom:12px">
      <div style="font-size:11px;font-weight:600;color:var(--text2);margin-bottom:4px"><?= $label ?></div>
      <div class="url-box">
        <div class="url-val" id="clientRedirectUrl_<?= strtolower(str_replace(' ','',$label)) ?>"></div>
      </div>
      <button class="btn btn-ghost btn-sm" style="margin-top:4px" onclick="copyText(document.getElementById('clientRedirectUrl_<?= strtolower(str_replace(' ','',$label)) ?>').textContent)">Copy</button>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- ── MODALS ── -->

<!-- Bulk Import Projects Modal -->
<div class="modal-overlay" id="modalBulkImport">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('modalBulkImport')">×</button>
    <div class="modal-title">📥 Bulk Import Projects (CSV)</div>
    <div style="font-size:12px;color:var(--text3);margin-bottom:14px">
      Upload a CSV with columns: <b>sid, project_name, client_name, cpi, max_completes, live_url</b> (only <b>sid</b> is required; existing SIDs get updated, same as Add-Project above).
      <a href="data:text/csv;charset=utf-8,sid%2Cproject_name%2Cclient_name%2Ccpi%2Cmax_completes%2Clive_url%0ARP001%2CSample%20Project%2CSample%20Client%2C3.50%2C200%2Chttps%3A%2F%2Fexample.com%2Fs%3Fuid%3D%255BUID%255D" download="project_import_template.csv" style="color:var(--accent)">⬇ Download template</a>
    </div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="action" value="bulk_import_projects">
      <div class="field" style="margin-bottom:16px">
        <input type="file" name="bulk_csv" accept=".csv" required>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%">Import Projects</button>
    </form>
  </div>
</div>

<!-- Project Modal -->
<div class="modal-overlay" id="modalProject">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('modalProject')">×</button>
    <div class="modal-title" id="modalProjectTitle">Add Project</div>
    <form method="POST">
      <input type="hidden" name="action" value="save_project">
      <input type="hidden" name="id" id="proj_id" value="">
      <div class="form-grid">
        <div class="field"><label>Project ID (SID)</label><input type="text" name="sid" id="proj_sid" placeholder="e.g. RP001" required></div>
        <div class="field"><label>Project Name</label><input type="text" name="project_name" id="proj_name" required></div>
        <div class="field"><label>Client</label>
          <select name="client_id" id="proj_client">
            <option value="">-- Select Client --</option>
            <?php foreach ($all_clients as $c): ?>
            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['client_name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field"><label>Status</label>
          <select name="status" id="proj_status">
            <option value="active">Active</option>
            <option value="paused">Paused</option>
            <option value="closed">Closed</option>
          </select>
        </div>
        <div class="field"><label>Client CPI ($)</label><input type="number" name="cpi" id="proj_cpi" step="0.01" value="0"></div>
        <div class="field"><label>Supplier CPI ($)</label><input type="number" name="supplier_cpi" id="proj_supplier_cpi" step="0.01" value="0"></div>
        <div class="field"><label>IR (%)</label><input type="number" name="ir" id="proj_ir" step="0.1" value="0"></div>
        <div class="field"><label>LOI (minutes)</label><input type="number" name="loi" id="proj_loi" value="0"></div>
        <div class="field"><label>Max Completes</label><input type="number" name="max_completes" id="proj_max" value="0"></div>
        <div class="field"><label>Project Type</label>
          <select name="project_type" id="proj_type">
            <option value="direct">Direct</option>
            <option value="thirdparty">Third Party</option>
          </select>
        </div>
        <div class="field" style="align-items:center;justify-content:center;flex-direction:row;gap:10px;padding-top:20px">
          <input type="checkbox" name="encrypt_uid" id="proj_enc" value="1" style="width:auto">
          <label for="proj_enc" style="text-transform:none;font-size:13px;color:var(--text2)">Encrypt UID</label>
        </div>
        <div class="field span2"><label>Target Countries (comma-separated, e.g. India, USA, UK)</label><input type="text" name="target_countries" id="proj_countries" placeholder="e.g. India, United States, United Kingdom"></div>
        <div class="field span2"><label>Live Survey URL</label><input type="text" name="live_url" id="proj_live" placeholder="https://..."></div>
        <div class="field span2"><label>Test Survey URL</label><input type="text" name="test_url" id="proj_test" placeholder="https://..."></div>
        <div class="field span2"><label>Description / Study Parameters</label><textarea name="description" id="proj_desc"></textarea></div>
      </div>
      <div style="margin-top:16px;display:flex;gap:10px">
        <button type="submit" class="btn btn-primary">Save Project</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('modalProject')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Client Modal -->
<div class="modal-overlay" id="modalClient">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('modalClient')">×</button>
    <div class="modal-title" id="modalClientTitle">Add Client</div>
    <form method="POST">
      <input type="hidden" name="action" value="save_client">
      <input type="hidden" name="id" id="cl_id" value="">
      <div class="form-grid">
        <div class="field span2"><label>Client Name</label><input type="text" name="client_name" id="cl_name" required></div>
        <div class="field"><label>Email</label><input type="email" name="email" id="cl_email"></div>
        <div class="field"><label>Phone</label><input type="text" name="phone" id="cl_phone"></div>
        <div class="field span2"><label>Company</label><input type="text" name="company" id="cl_company"></div>
        <div class="field"><label>Status</label>
          <select name="status" id="cl_status">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div style="margin-top:16px;display:flex;gap:10px">
        <button type="submit" class="btn btn-primary">Save Client</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('modalClient')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Vendor Modal -->
<div class="modal-overlay" id="modalVendor">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('modalVendor')">×</button>
    <div class="modal-title">Add / Edit Vendor</div>
    <form method="POST">
      <input type="hidden" name="action" value="save_vendor">
      <input type="hidden" name="id" id="vn_id" value="">
      <div class="form-grid">
        <div class="field span2"><label>Vendor Name</label><input type="text" name="vendor_name" id="vn_name" required></div>
        <div class="field"><label>Email</label><input type="email" name="email" id="vn_email"></div>
        <div class="field"><label>Phone</label><input type="text" name="phone" id="vn_phone"></div>
        <div class="field span2">
          <label>Complete URL (Postback)</label>
          <input type="text" name="complete_url" id="vn_complete" placeholder="https://vendor.com/postback?status=complete&username=[UID]">
        </div>
        <div class="field span2">
          <label>Terminate URL (Postback)</label>
          <input type="text" name="terminate_url" id="vn_terminate" placeholder="https://vendor.com/postback?status=terminate&username=[UID]">
        </div>
        <div class="field span2">
          <label>Screenout URL (Postback)</label>
          <input type="text" name="screenout_url" id="vn_screenout" placeholder="https://vendor.com/postback?status=screenout&username=[UID]">
        </div>
        <div class="field span2">
          <label>Quotafull URL (Postback)</label>
          <input type="text" name="quotafull_url" id="vn_quotafull" placeholder="https://vendor.com/postback?status=quotafull&username=[UID]">
        </div>
        <div class="field span2" style="margin-top:-8px">
          <p style="font-size:11px;color:var(--text3);line-height:1.6">
            Available placeholders: <span class="mono">[UID]</span> (vendor's own respondent ID), <span class="mono">[SID]</span> (project ID), <span class="mono">[LOI]</span> (time taken in seconds, complete only).
            Khaali chhodo agar vendor ko postback/redirect nahi chahiye.
          </p>
        </div>
        <div class="field span2">
          <label>End Page Behavior</label>
          <select name="end_behavior" id="vn_end_behavior">
            <option value="show_page">Show our page (postback sent in background) — recommended</option>
            <option value="redirect">Redirect respondent directly to vendor's own URL</option>
          </select>
          <p style="font-size:11px;color:var(--text3);margin-top:6px;line-height:1.6">
            "Show our page" = respondent dekhta hai humara Thank You page, vendor ko sirf background mein data milta hai.<br>
            "Redirect" = respondent seedha vendor ke URL (upar wale fields mein se, status ke hisaab se) pe bhej diya jaata hai — humara page kabhi nahi dikhta.
          </p>
        </div>
        <div class="field"><label>Status</label>
          <select name="status" id="vn_status">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div style="margin-top:16px;display:flex;gap:10px">
        <button type="submit" class="btn btn-primary">Save Vendor</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('modalVendor')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- User Modal -->
<div class="modal-overlay" id="modalUser">
  <div class="modal">
    <button class="modal-close" onclick="closeModal('modalUser')">×</button>
    <div class="modal-title">Add / Edit User</div>
    <form method="POST">
      <input type="hidden" name="action" value="save_user">
      <input type="hidden" name="id" id="usr_id" value="">
      <div class="form-grid">
        <div class="field span2"><label>Full Name</label><input type="text" name="name" id="usr_name" required></div>
        <div class="field span2"><label>Email</label><input type="email" name="email" id="usr_email" required></div>
        <div class="field"><label>Role</label>
          <select name="role" id="usr_role">
            <option value="viewer">Viewer</option>
            <option value="manager">Manager</option>
            <option value="superadmin">Super Admin</option>
          </select>
        </div>
        <div class="field"><label>Password <span style="color:var(--text3);font-size:10px">(leave blank to keep)</span></label><input type="password" name="password" id="usr_pass"></div>
      </div>
      <div style="margin-top:16px;display:flex;gap:10px">
        <button type="submit" class="btn btn-primary">Save User</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('modalUser')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>
// ── Vendors-list search filter — matches by name/email against each
// row's data-search attribute, client-side (list is small enough that
// a server round-trip isn't needed here).
function filterVendorTable(query) {
  const q = query.toLowerCase().trim();
  document.querySelectorAll('tr[data-search]').forEach(row => {
    const hay = row.getAttribute('data-search') || '';
    row.style.display = (!q || hay.includes(q)) ? '' : 'none';
  });
}

// ── Modal helpers ──
function openModal(id, data) {
  document.getElementById(id).classList.add('open');
  if (id === 'modalProject') {
    document.getElementById('modalProjectTitle').textContent = data.id ? 'Edit Project' : 'Add Project';
    document.getElementById('proj_id').value    = data.id || '';
    document.getElementById('proj_sid').value   = data.sid || '';
    document.getElementById('proj_name').value  = data.project_name || '';
    document.getElementById('proj_cpi').value   = data.cpi || '0';
    document.getElementById('proj_supplier_cpi').value = data.supplier_cpi || '0';
    document.getElementById('proj_ir').value    = data.ir || '0';
    document.getElementById('proj_loi').value   = data.loi || '0';
    document.getElementById('proj_max').value   = data.max_completes || '0';
    document.getElementById('proj_live').value  = data.live_url || '';
    document.getElementById('proj_countries').value = data.target_countries || '';
    document.getElementById('proj_test').value  = data.test_url || '';
    document.getElementById('proj_desc').value  = data.description || '';
    document.getElementById('proj_enc').checked = data.encrypt_uid == 1;
    if (data.status) document.getElementById('proj_status').value = data.status;
    if (data.project_type) document.getElementById('proj_type').value = data.project_type;
    if (data.client_id) document.getElementById('proj_client').value = data.client_id;
  }
  if (id === 'modalClient') {
    document.getElementById('modalClientTitle').textContent = data.id ? 'Edit Client' : 'Add Client';
    document.getElementById('cl_id').value      = data.id || '';
    document.getElementById('cl_name').value    = data.client_name || '';
    document.getElementById('cl_email').value   = data.email || '';
    document.getElementById('cl_phone').value   = data.phone || '';
    document.getElementById('cl_company').value = data.company || '';
    if (data.status) document.getElementById('cl_status').value = data.status;
  }
  if (id === 'modalVendor') {
    document.getElementById('vn_id').value        = data.id || '';
    document.getElementById('vn_name').value      = data.vendor_name || '';
    document.getElementById('vn_email').value     = data.email || '';
    document.getElementById('vn_phone').value     = data.phone || '';
    document.getElementById('vn_complete').value  = data.complete_url || '';
    document.getElementById('vn_terminate').value = data.terminate_url || '';
    document.getElementById('vn_screenout').value = data.screenout_url || '';
    document.getElementById('vn_quotafull').value = data.quotafull_url || '';
    if (data.end_behavior) document.getElementById('vn_end_behavior').value = data.end_behavior;
    if (data.status) document.getElementById('vn_status').value = data.status;
  }
  if (id === 'modalUser') {
    document.getElementById('usr_id').value    = data.id || '';
    document.getElementById('usr_name').value  = data.name || '';
    document.getElementById('usr_email').value = data.email || '';
    document.getElementById('usr_pass').value  = '';
    if (data.role) document.getElementById('usr_role').value = data.role;
  }
  if (id === 'modalNote') {
    document.getElementById('modalNoteTitle').textContent = data.id ? 'Edit Note' : 'Add Note';
    document.getElementById('note_id').value      = data.id || '';
    document.getElementById('note_title').value   = data.title || '';
    document.getElementById('note_content').value = data.content || '';
  }
}

function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

// Modals now only close via X / Save / Cancel — accidental backdrop
// clicks no longer discard in-progress form data.

// ── Bulk Delete Leads ──
function toggleAll(cb) {
  document.querySelectorAll('.lead-chk').forEach(c => c.checked = cb.checked);
  updateBulk();
}
function updateBulk() {
  const checked = [...document.querySelectorAll('.lead-chk:checked')];
  const btn = document.getElementById('bulkDelBtn');
  if (btn) {
    btn.style.display = checked.length > 0 ? '' : 'none';
    btn.textContent = '🗑 Delete Selected (' + checked.length + ')';
  }
}
function bulkDeleteLeads() {
  const ids = [...document.querySelectorAll('.lead-chk:checked')].map(c => c.value);
  if (ids.length === 0) return;
  if (!confirm('Delete ' + ids.length + ' selected leads?')) return;
  document.getElementById('bulkLeadIds').value = ids.join(',');
  document.getElementById('leadsForm').submit();
}

// ── Screener bulk delete ──
function toggleAllScreener(cb) {
  document.querySelectorAll('.screener-check').forEach(c => c.checked = cb.checked);
}
function bulkDeleteScreener() {
  const ids = [...document.querySelectorAll('.screener-check:checked')].map(c => c.value);
  if (ids.length === 0) { alert('Koi entry select nahi ki.'); return; }
  if (!confirm('Delete ' + ids.length + ' selected screener entries?')) return;
  document.getElementById('screenerIdsInput').value = ids.join(',');
  document.getElementById('screenerBulkForm').submit();
}

// ── Projects bulk delete ──
function toggleAllProjects(cb) {
  document.querySelectorAll('.project-check').forEach(c => c.checked = cb.checked);
}
function bulkDeleteProjects() {
  const ids = [...document.querySelectorAll('.project-check:checked')].map(c => c.value);
  if (ids.length === 0) { alert('Koi project select nahi kiya.'); return; }
  if (!confirm('Delete ' + ids.length + ' selected projects? Unke leads bhi delete nahi honge, sirf project entry delete hogi.')) return;
  document.getElementById('projectIdsInput').value = ids.join(',');
  document.getElementById('projectsBulkForm').submit();
}

// ── UID Lookup Tab Switch ──
function switchTab(tab) {
  document.getElementById('panel_single').style.display = tab === 'single' ? '' : 'none';
  document.getElementById('panel_bulk').style.display   = tab === 'bulk'   ? '' : 'none';
  document.getElementById('tab_single').className = 'btn btn-sm ' + (tab === 'single' ? 'btn-primary' : 'btn-ghost');
  document.getElementById('tab_bulk').className   = 'btn btn-sm ' + (tab === 'bulk'   ? 'btn-primary' : 'btn-ghost');
}

// ── Edit Assignment Modal ──
function openEditAssignment(pvId, projectId, cpi, limit, vendorName) {
  document.getElementById('ea_pv_id').value     = pvId;
  document.getElementById('ea_project_id').value = projectId;
  document.getElementById('ea_cpi').value        = cpi;
  document.getElementById('ea_limit').value      = limit;
  document.getElementById('editAssignmentTitle').textContent = 'Edit: ' + vendorName;
  document.getElementById('editAssignmentModal').classList.add('open');
}

// ── Entry Link Modal ──
function showEntryLink(vendor, sid, url) {
  document.getElementById('entryLinkVendorName').textContent = vendor;
  document.getElementById('entryLinkProject').textContent = 'Project: ' + sid;
  document.getElementById('entryLinkUrl').textContent = url;
  document.getElementById('entryLinkModal').classList.add('open');
}

function showClientRedirectUrls(clientName, clientUid) {
  document.getElementById('clientRedirectName').textContent = clientName + ' — Client Code: ' + clientUid;
  const base = window.location.origin + '/client_redirect.php';
  const types = {complete:'complete', terminate:'terminate', overquota:'overquota', qualityfail:'qc'};
  for (const key in types) {
    const url = base + '?client=' + encodeURIComponent(clientUid) + '&type=' + types[key] + '&uid=[UID]';
    document.getElementById('clientRedirectUrl_' + key).textContent = url;
  }
  document.getElementById('clientRedirectModal').classList.add('open');
}

// ── Copy helper ──
function copyText(text) {
  navigator.clipboard.writeText(text).then(() => {
    const btn = event.target;
    const orig = btn.textContent;
    btn.textContent = 'Copied!';
    btn.style.background = 'rgba(34,197,94,0.2)';
    btn.style.color = '#22c55e';
    setTimeout(() => { btn.textContent = orig; btn.style.background=''; btn.style.color=''; }, 1500);
  });
}
</script>

</body>
</html>
