<?php
// ============================================================
// Azilytics Insights — client_portal.php
// Client Portal dashboard — shows ONLY this logged-in client's own
// projects' data (Complete/Terminate counts, IR%, recent activity).
// ============================================================
require_once __DIR__ . '/config.php';
$db = rp_db();
rp_ensure_portal_clients_table($db);

session_name('rp_client_portal_session');
if (session_status() === PHP_SESSION_NONE) session_start();

if (empty($_SESSION['rp_portal_client_id'])) {
    header('Location: client_portal_login.php');
    exit();
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: client_portal_login.php');
    exit();
}

$client_name = $_SESSION['rp_portal_client_name'];
$client_ref_id = $_SESSION['rp_portal_client_ref_id'];

// Only projects genuinely belonging to this client — a portal-client
// account can NEVER see another client's data, regardless of what's
// requested, since this is the only WHERE-condition used throughout.
$projects = [];
if ($client_ref_id) {
    $pq = $db->prepare("SELECT * FROM rp_projects WHERE client_id = ? ORDER BY id DESC");
    $pq->execute([$client_ref_id]);
    $projects = $pq->fetchAll();
}

$total_completes = 0; $total_clicks = 0;
foreach ($projects as &$p) {
    $c = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=? AND status='complete'");
    $c->execute([$p['sid']]);
    $p['completes'] = (int)$c->fetchColumn();
    $cl = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=?");
    $cl->execute([$p['sid']]);
    $p['clicks'] = (int)$cl->fetchColumn();
    $total_completes += $p['completes'];
    $total_clicks += $p['clicks'];
}
unset($p);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Client Portal — Azilytics Insights</title>
<style>
body { font-family: 'DM Sans', sans-serif; background: #f8fafc; color: #1e293b; margin: 0; }
.header { background: #0d0f14; color: #fff; padding: 16px 30px; display: flex; justify-content: space-between; align-items: center; }
.container { max-width: 1000px; margin: 30px auto; padding: 0 20px; }
.stats { display: flex; gap: 16px; margin-bottom: 24px; }
.stat-card { flex: 1; background: #fff; border-radius: 10px; padding: 18px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
.stat-label { font-size: 11px; color: #64748b; text-transform: uppercase; }
.stat-value { font-size: 24px; font-weight: 700; margin-top: 4px; }
table { width: 100%; background: #fff; border-radius: 10px; overflow: hidden; border-collapse: collapse; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
th { text-align: left; padding: 12px 16px; font-size: 11px; color: #64748b; text-transform: uppercase; background: #f1f5f9; }
td { padding: 12px 16px; font-size: 13px; border-top: 1px solid #f1f5f9; }
a.logout { color: #94a3b8; text-decoration: none; font-size: 13px; }
</style>
</head>
<body>
<div class="header">
  <div><strong><?= htmlspecialchars($client_name) ?></strong> — Client Portal</div>
  <a class="logout" href="?logout=1">Log Out</a>
</div>
<div class="container">
  <div class="stats">
    <div class="stat-card"><div class="stat-label">Total Projects</div><div class="stat-value"><?= count($projects) ?></div></div>
    <div class="stat-card"><div class="stat-label">Total Clicks</div><div class="stat-value"><?= number_format($total_clicks) ?></div></div>
    <div class="stat-card"><div class="stat-label">Total Completes</div><div class="stat-value"><?= number_format($total_completes) ?></div></div>
  </div>
  <table>
    <thead><tr><th>Project</th><th>Status</th><th>Clicks</th><th>Completes</th><th>IR%</th></tr></thead>
    <tbody>
      <?php if (empty($projects)): ?>
      <tr><td colspan="5" style="text-align:center;color:#94a3b8;padding:30px">No projects yet.</td></tr>
      <?php else: foreach ($projects as $p): ?>
      <tr>
        <td><?= htmlspecialchars($p['project_name']) ?><div style="font-size:11px;color:#94a3b8"><?= htmlspecialchars($p['sid']) ?></div></td>
        <td><?= ucfirst($p['status']) ?></td>
        <td><?= number_format($p['clicks']) ?></td>
        <td><?= number_format($p['completes']) ?></td>
        <td><?= $p['clicks'] > 0 ? round(($p['completes']/$p['clicks'])*100,1) : 0 ?>%</td>
      </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>
</body>
</html>
