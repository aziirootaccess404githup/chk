<?php
// ============================================================
// Azilytics Insights — invoice_preview.php
// Auto-Invoice preview/printable page (ported from ExaVerify's
// Exazon_Invoice_Template.html) — Billing tab's "Generate Invoice
// From Selected" button opens this with client + items in the URL.
// Genuinely printable via the browser's own Print → Save as PDF, so
// no separate PDF-library dependency is needed.
// ============================================================
$client = trim($_GET['client'] ?? 'Client');
$items = [];
if (!empty($_GET['items'])) {
    $decoded = json_decode($_GET['items'], true);
    if (is_array($decoded)) $items = $decoded;
}

$invoice_no = 'INV-' . date('Ym') . '-' . rand(1000, 9999);
$invoice_date = date('F j, Y');
$total = 0;
foreach ($items as $it) {
    $total += (float)($it['qty'] ?? 0) * (float)($it['rate'] ?? 0);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Invoice — <?= htmlspecialchars($client) ?></title>
<style>
@media print { .no-print { display: none !important; } body { background: #fff !important; } }
body { max-width: 800px; margin: 0 auto; padding: 40px; background: #fff; color: #1e293b; font-family: sans-serif; }
table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
th { padding: 10px 8px; font-size: 12px; text-align: left; border-bottom: 2px solid #e2e8f0; }
td { padding: 10px 8px; font-size: 13px; border-bottom: 1px solid #f1f5f9; }
.right { text-align: right; }
</style>
</head>
<body>
<div class="no-print" style="margin-bottom:20px;text-align:right">
  <button onclick="window.print()" style="padding:8px 16px;background:#2563eb;color:#fff;border:none;border-radius:6px;cursor:pointer">🖨 Print / Save as PDF</button>
</div>

<div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #2563eb;padding-bottom:20px;margin-bottom:30px">
  <div>
    <h2 style="margin:0;color:#2563eb">Azilytics Insights</h2>
    <div style="font-size:12px;color:#64748b">info@azilyticsinsights.com</div>
  </div>
  <div style="text-align:right">
    <h3 style="margin:0">INVOICE</h3>
    <div style="font-size:12px;color:#64748b"><?= htmlspecialchars($invoice_no) ?></div>
    <div style="font-size:12px;color:#64748b"><?= htmlspecialchars($invoice_date) ?></div>
  </div>
</div>

<div style="margin-bottom:30px">
  <div style="font-size:11px;color:#94a3b8;text-transform:uppercase;font-weight:600">Bill To</div>
  <div style="font-size:16px;font-weight:600"><?= htmlspecialchars($client) ?></div>
</div>

<table>
  <thead><tr><th>Project</th><th class="right">Completes</th><th class="right">CPI</th><th class="right">Amount</th></tr></thead>
  <tbody>
    <?php if (empty($items)): ?>
    <tr><td colspan="4" style="text-align:center;color:#94a3b8;padding:16px">No items selected.</td></tr>
    <?php else: foreach ($items as $it):
        $qty = (float)($it['qty'] ?? 0); $rate = (float)($it['rate'] ?? 0);
    ?>
    <tr>
      <td><?= htmlspecialchars($it['desc'] ?? '') ?></td>
      <td class="right"><?= number_format($qty) ?></td>
      <td class="right">$<?= number_format($rate, 2) ?></td>
      <td class="right" style="font-weight:600">$<?= number_format($qty * $rate, 2) ?></td>
    </tr>
    <?php endforeach; endif; ?>
  </tbody>
</table>

<div style="display:flex;justify-content:flex-end">
  <div style="width:250px">
    <div style="display:flex;justify-content:space-between;padding:10px 0;border-top:2px solid #1e293b;font-size:16px;font-weight:700">
      <span>Total Due</span><span>$<?= number_format($total, 2) ?></span>
    </div>
  </div>
</div>

<div style="margin-top:50px;font-size:11px;color:#94a3b8;text-align:center">
  Thank you for your business. Please contact info@azilyticsinsights.com with any billing questions.
</div>
</body>
</html>
