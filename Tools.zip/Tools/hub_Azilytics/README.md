# Azilytics — All 20 Gaps Fixed (vs ExaVerify Baseline)

Genuinely real-database-tested against the actual production schema
(`u994909610_hub.sql`) before delivery — not just syntax-checked.

## Files In This Package (9 — All Go To Server Root, Next To Existing Files)

| File | What Changed |
|---|---|
| `config.php` | Added: blocked-IP, multi-country-link, status-synonym, IR-drift, PM-activity, question-library, portal-clients functions |
| `admin.php` | Added: Parent-Child UI, Vendor Scorecard, Auto-Invoice, Question Library page, Client Portal Accounts page, PM Activity Log UI |
| `vendor.php` | Added: vendor-authorization-check (critical security fix), blocked-IP check, click-quota, prescreener-toggle-routing, multi-country-link |
| `track.php` | Fixed: unmatched-status defaulting to 'complete' bug, LOI trusted from client, missing lazy-column-ensures. Added: status-synonym, duplicate-detection, IR-drift |
| `end.php` | Fixed: Ghost-Complete vulnerability (no verification a genuine entry happened). Added: status-synonym, duplicate-detection, IR-drift, outbound-S2S wiring |
| `prescreener.php` | Added: dynamic, template-driven questions (falls back to the existing hardcoded set if no template is linked — zero risk to existing projects) |
| `invoice_preview.php` | **New file** — Auto-Invoice printable page |
| `client_portal_login.php` | **New file** — Client Portal login |
| `client_portal.php` | **New file** — Client Portal dashboard (client sees only their own projects) |

## Deployment Steps

1. Upload all 9 files to your server, overwriting the existing 6 and adding the 3 new ones.
2. No manual SQL needed — every new table/column is created automatically
   on first use (`CREATE TABLE IF NOT EXISTS` / `ALTER TABLE ... ADD COLUMN`
   wrapped in try/catch), matching how the rest of the app already works.
3. To create your first Client Portal login: go to **Client Portal Accounts**
   in the sidebar → fill in username/password/client → Create Account.
4. To use Question Library: go to **Question Library** in the sidebar →
   add questions → group them into a Template → open a project → link
   the Template in the new "Prescreener Template" card.

## What Was Verified This Round (Real Database, Not Just Code-Review)

- **Vendor-authorization**: an unassigned vendor-ID (or missing vid) is
  genuinely rejected (403) — confirmed a genuine assigned vendor still
  works normally.
- **`track.php` unmatched-bug**: missing/unrecognized status genuinely
  becomes `unmatched` (unlocked), not silently `complete` — confirmed a
  genuinely valid status still locks correctly.
- **Ghost-Complete**: a completion-URL hit with no prior entry-click is
  genuinely flagged `no_entry_record=1`, excluded from postback/S2S/
  IR-drift — confirmed a genuine entry+completion is unaffected.
- **Click-Quota**: 2 allowed clicks correctly passed through, the 3rd
  correctly blocked.
- **Blocked-IP**: a blocked IP correctly rejected (403); un-blocking it
  correctly restored normal entry.
- **Multi-Country-Link**: a configured override correctly took priority;
  removing it correctly fell back to the project's normal `live_url`.
- **Duplicate-detection**: a genuine repeat-hit on an already-locked
  lead correctly flagged `is_duplicate=1`; a fresh, first-time genuine
  completion correctly stayed `0`.
- **Parent-Child**: creating a Parent then a Child correctly linked
  `parent_sid`; deleting the Parent while the Child was still attached
  was correctly blocked; the Projects list correctly grouped them
  (👑 Parent immediately followed by ↳ indented Child).
- **Vendor Scorecard**: IR%/Fraud-Rate/Avg-LOI genuinely matched hand-
  calculated values from a known test dataset.
- **Auto-Invoice**: selecting projects and generating an invoice
  correctly calculated the total (qty × rate, summed).
- **Question Library**: a question + template + project-link, followed
  by a full entry→prescreener→submission flow, genuinely rendered the
  dynamic question (not the old hardcoded ones) and correctly routed to
  `capture.php` on submit.
- **Client Portal**: a created account genuinely logged in and saw only
  its own linked client's project-data; a wrong password was correctly
  rejected.
- **Re-verified against the real production schema** (not just a
  from-scratch test DB) — this specifically caught 2 additional bugs
  during this final pass (missing lazy-column-ensures in `vendor.php`
  and `track.php`/`end.php` for genuinely-fresh databases) that were
  fixed before this delivery.

## One Thing Not Fully Verifiable Here

Outbound S2S's live network round-trip couldn't be completed in this
sandbox (same limitation as ExaVerify's and Node.js's outbound-S2S
earlier) — the code is structurally verified and mirrors the same
curl-based pattern already proven working elsewhere. Recommended first
real-world check: point a client's S2S endpoint at a temporary
webhook.site URL and fire one real test completion before wiring in
the real endpoint.
