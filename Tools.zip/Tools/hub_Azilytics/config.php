<?php
date_default_timezone_set('Asia/Kolkata');

// ── BRAND CONFIG (edit these to re-skin the whole panel for a new client) ──
// Every UI file pulls its logo text, title, footer, and contact links from
// these constants — nothing brand-related should be hardcoded elsewhere.
define('BRAND_NAME',    'Azilytics Insights');           // Full brand name
define('BRAND_UPPER',   'AZILYTICS INSIGHTS');            // Uppercase version (sidebar logo, footers)
define('BRAND_ICON',    'AI');                            // 2-3 letter sidebar icon initials
define('BRAND_TAGLINE', 'SURVEY PANEL');                  // Sidebar/login subtitle
define('BRAND_DOMAIN',  'azilyticsinsights.com');         // Public domain (no https://)
define('BRAND_URL',     'https://azilyticsinsights.com'); // Full public URL
define('BRAND_EMAIL',   'info@azilyticsinsights.com');    // Contact email
define('BRAND_NAV_TAGLINE',    'Quality Intelligence System'); // end.php nav subtitle
define('BRAND_FOOTER_TAGLINE', 'Decipher the Future');         // end.php footer tagline

define('RP_DB_HOST', '127.0.0.1');
define('RP_DB_NAME', 'u994909610_hub');   // ← matches hub.azilyticsinsights.com subdomain
define('RP_DB_USER', 'u994909610_hub');   // ← matches hub.azilyticsinsights.com subdomain
define('RP_DB_PASS', 'hub@Azii8181'); // ← set this to the password you create in Hostinger for u994909610_hub
define('RP_DB_PORT', '3306');
define('RP_ENC_KEY', 'nKylS7!jGN!wh%CkkykOxNU$$cuJ0jILv1B@LMyu'); // ← fresh key (old data was dummy/testing, safe to rotate)
define('RP_SESSION_NAME', 'rp_admin_session');

function rp_db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=".RP_DB_HOST.";port=".RP_DB_PORT.";dbname=".RP_DB_NAME.";charset=utf8mb4";
            $pdo = new PDO($dsn, RP_DB_USER, RP_DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['error' => 'Database connection failed']));
        }
    }
    return $pdo;
}

function rp_encrypt(string $data, string $sid = ''): string {
    // Short opaque token (not reversible on its own) — the real UID is recovered
    // via the rp_uid_mapping table, which is already saved alongside every token.
    return bin2hex(random_bytes(5)); // 10-character hex token
}

function rp_decrypt(string $token, string $sid = ''): ?string {
    try {
        $raw = base64_decode(strtr($token . str_repeat('=', (4 - strlen($token) % 4) % 4), '-_', '+/'));
        if (strlen($raw) < 16) return null;
        $iv  = substr($raw, 0, 16);
        $enc = base64_encode(substr($raw, 16));
        $key = hash('sha256', RP_ENC_KEY . $sid, true);
        $dec = openssl_decrypt($enc, 'AES-256-CBC', $key, 0, $iv);
        return $dec === false ? null : $dec;
    } catch (Exception $e) { return null; }
}

function rp_session_start(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_name(RP_SESSION_NAME);
        session_start();
    }
}

function rp_is_logged_in(): bool {
    rp_session_start();
    return !empty($_SESSION['rp_user_id']);
}

function rp_require_login(): void {
    if (!rp_is_logged_in()) {
        header('Location: login.php');
        exit();
    }
}

function rp_current_user(): array {
    rp_session_start();
    return [
        'id'    => $_SESSION['rp_user_id']    ?? 0,
        'name'  => $_SESSION['rp_user_name']  ?? '',
        'email' => $_SESSION['rp_user_email'] ?? '',
        'role'  => $_SESSION['rp_user_role']  ?? 'viewer',
    ];
}

function rp_is_superadmin(): bool { return rp_current_user()['role'] === 'superadmin'; }
function rp_is_manager(): bool { return in_array(rp_current_user()['role'], ['superadmin','manager']); }

function rp_get_ip(): string {
    foreach (['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) return explode(',', $_SERVER[$k])[0];
    }
    return 'unknown';
}

// cURL-based HTTP GET, used for all 3 geo-providers below. Switched from
// file_get_contents (requires the server's allow_url_fopen setting to be
// enabled — not guaranteed on every hosting environment) to cURL, which
// is more universally reliable and doesn't depend on that PHP setting.
function rp_geo_http_get(string $url, float $timeout_seconds = 1.5): ?string {
    if (!function_exists('curl_init')) {
        $ctx = stream_context_create(['http' => ['timeout' => $timeout_seconds]]);
        $result = @file_get_contents($url, false, $ctx);
        return $result !== false ? $result : null;
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => $timeout_seconds,
        CURLOPT_CONNECTTIMEOUT => $timeout_seconds,
        CURLOPT_USERAGENT      => 'AzilyticsInsights/1.0',
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result !== false ? $result : null;
}

function rp_geo(string $ip): array {
    // Primary provider - ip-api.com (free, no key needed)
    // Timeouts reduced from 4s to 1.5s each (was 8s worst-case for 2
    // providers, blocking the respondent's own entry-flow) — same fix
    // applied to ExaVerify and the Node.js tool this round.
    $geo = @json_decode(rp_geo_http_get("http://ip-api.com/json/{$ip}"));
    if ($geo && $geo->status === 'success' && !empty($geo->country)) {
        return ['country' => $geo->country, 'city' => $geo->city ?? ''];
    }

    // Fallback provider - ipapi.co (used only if the primary fails or is
    // rate-limited, e.g. under bursty traffic) - keeps country detection
    // working even when one provider is temporarily unavailable.
    $geo2 = @json_decode(rp_geo_http_get("https://ipapi.co/{$ip}/json/"));
    if ($geo2 && empty($geo2->error) && !empty($geo2->country_name)) {
        return ['country' => $geo2->country_name, 'city' => $geo2->city ?? ''];
    }

    // Third, independent fallback provider (own separate rate-limit bucket) —
    // matches the depth added to Kishan's panel/ExaVerify/Node.js tool: under
    // high-volume traffic, two providers can occasionally both be
    // rate-limited/down at once. ipinfo.io only returns a 2-letter country
    // code, so it's normalized to a full name to stay consistent.
    $geo3 = @json_decode(rp_geo_http_get("https://ipinfo.io/{$ip}/json"));
    if ($geo3 && !empty($geo3->country)) {
        $country_names = ['US'=>'United States','GB'=>'United Kingdom','IN'=>'India','CA'=>'Canada','AU'=>'Australia','DE'=>'Germany','FR'=>'France','ES'=>'Spain','IT'=>'Italy','NL'=>'Netherlands','BR'=>'Brazil','MX'=>'Mexico','JP'=>'Japan','CN'=>'China','PH'=>'Philippines','AE'=>'United Arab Emirates','SG'=>'Singapore','ZA'=>'South Africa','NZ'=>'New Zealand','IE'=>'Ireland','PK'=>'Pakistan','BD'=>'Bangladesh','ID'=>'Indonesia','MY'=>'Malaysia','TH'=>'Thailand','VN'=>'Vietnam','KR'=>'South Korea','SA'=>'Saudi Arabia','EG'=>'Egypt','NG'=>'Nigeria','KE'=>'Kenya','AR'=>'Argentina','CL'=>'Chile','CO'=>'Colombia','PE'=>'Peru','PL'=>'Poland','SE'=>'Sweden','NO'=>'Norway','DK'=>'Denmark','FI'=>'Finland','CH'=>'Switzerland','AT'=>'Austria','BE'=>'Belgium','PT'=>'Portugal','GR'=>'Greece','TR'=>'Turkey','IL'=>'Israel','RU'=>'Russia','UA'=>'Ukraine'];
        $name = $country_names[$geo3->country] ?? $geo3->country;
        return ['country' => $name, 'city' => $geo3->city ?? ''];
    }

    // All three providers failed - return an explicit 'Unknown' rather than a
    // blank string, so the dashboard can distinguish "lookup attempted but
    // failed" from "never attempted", instead of just showing an empty cell.
    return ['country' => 'Unknown', 'city' => ''];
}

function rp_device(): string {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (preg_match('/tablet|ipad/i', $ua)) return 'tablet';
    if (preg_match('/mobile|android|iphone/i', $ua)) return 'mobile';
    return 'desktop';
}

// ── QUOTA AUTO-PAUSE ─────────────────────────────────────────
// Call this after every complete status is saved
function rp_check_quota(PDO $db, string $sid): void {
    $proj = $db->prepare("SELECT id, project_name, max_completes, status FROM rp_projects WHERE sid=? LIMIT 1");
    $proj->execute([$sid]);
    $p = $proj->fetch();
    if (!$p || $p['status'] !== 'active' || empty($p['max_completes'])) return;
    $comp = $db->prepare("SELECT COUNT(*) FROM rp_leads WHERE sid=? AND status='complete'");
    $comp->execute([$sid]);
    if ((int)$comp->fetchColumn() >= (int)$p['max_completes']) {
        $db->prepare("UPDATE rp_projects SET status='paused' WHERE id=?")->execute([$p['id']]);
        // Alert — quota just reached, project auto-paused
        $msg = "🚨 Quota Reached\nProject: {$p['project_name']} ({$sid})\nCompletes: {$p['max_completes']}/{$p['max_completes']}\nStatus: Auto-paused";
        rp_send_telegram_alert($msg);
        rp_send_email_alert("PanelEngine Alert: Quota Reached — $sid", $msg);
    }
}

function rp_browser(): string {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (str_contains($ua,'Chrome')) return 'Chrome';
    if (str_contains($ua,'Firefox')) return 'Firefox';
    if (str_contains($ua,'Safari')) return 'Safari';
    if (str_contains($ua,'Edge')) return 'Edge';
    return 'Other';
}

// ── INVOICE / BILLING STATUS TRACKING ─────────────────────────
function rp_ensure_invoice_table(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS rp_invoice_status (
        project_id INT(11) NOT NULL PRIMARY KEY,
        status ENUM('unpaid','invoiced','paid') NOT NULL DEFAULT 'unpaid',
        notes VARCHAR(255) DEFAULT NULL,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}
function rp_ensure_share_table(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS rp_share_links (
        id INT(11) NOT NULL AUTO_INCREMENT,
        project_id INT(11) NOT NULL,
        token VARCHAR(40) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uniq_token (token),
        KEY idx_project (project_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}
function rp_ensure_settings_table(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS rp_settings (
        setting_key VARCHAR(100) NOT NULL PRIMARY KEY,
        setting_value TEXT DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function rp_get_setting(PDO $db, string $key, string $default = ''): string {
    rp_ensure_settings_table($db);
    $s = $db->prepare("SELECT setting_value FROM rp_settings WHERE setting_key=?");
    $s->execute([$key]);
    $val = $s->fetchColumn();
    return $val !== false ? $val : $default;
}

function rp_set_setting(PDO $db, string $key, string $value): void {
    rp_ensure_settings_table($db);
    $db->prepare("INSERT INTO rp_settings (setting_key, setting_value) VALUES (?,?)
                  ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)")
       ->execute([$key, $value]);
}

// ── TELEGRAM ALERT ─────────────────────────────────────────────
function rp_send_telegram_alert(string $message): bool {
    try {
        $db    = rp_db();
        $token = rp_get_setting($db, 'telegram_bot_token');
        $chat  = rp_get_setting($db, 'telegram_chat_id');
        if (!$token || !$chat) return false; // not configured

        $url = "https://api.telegram.org/bot{$token}/sendMessage";
        $ctx = stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
                'content' => http_build_query(['chat_id' => $chat, 'text' => $message]),
                'timeout' => 5,
            ]
        ]);
        @file_get_contents($url, false, $ctx);
        return true;
    } catch (Exception $e) {
        error_log("rp_send_telegram_alert error: " . $e->getMessage());
        return false;
    }
}

// ── PROJECT EXTRA COLUMNS (Revenue Tracker, Pin/Tag, Per-Project Notes) ─
function rp_ensure_project_extra_columns(PDO $db): void {
    $cols = [
        "supplier_cpi"     => "DECIMAL(10,2) NOT NULL DEFAULT 0.00",
        "is_pinned"        => "TINYINT(1) NOT NULL DEFAULT 0",
        "color_tag"        => "VARCHAR(20) DEFAULT NULL",
        "internal_notes"   => "TEXT DEFAULT NULL",
        "target_countries" => "VARCHAR(500) DEFAULT NULL",
    ];
    foreach ($cols as $col => $def) {
        try {
            $db->exec("ALTER TABLE rp_projects ADD COLUMN $col $def");
        } catch (PDOException $e) {
            // Column already exists — ignore (error 1060 = duplicate column)
        }
    }
}

// ── CLIENT-LEVEL REDIRECT UID (used by client_redirect.php's client=
// lookup, and the Clients-page's per-client redirect-link generator) ──
function rp_ensure_client_extra_columns(PDO $db): void {
    try {
        $db->exec("ALTER TABLE rp_clients ADD COLUMN client_uid VARCHAR(20) DEFAULT NULL");
    } catch (PDOException $e) {
        // Column already exists — ignore (error 1060 = duplicate column)
    }
}

function rp_generate_client_uid(PDO $db): string {
    // 8-char, URL-safe, collision-checked against rp_clients.client_uid
    do {
        $code = 'CLT' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
        $chk = $db->prepare("SELECT COUNT(*) FROM rp_clients WHERE client_uid = ?");
        $chk->execute([$code]);
    } while ($chk->fetchColumn() > 0);
    return $code;
}

// ── PROJECT-VENDOR SHORT-LINK CODE (used by azii.php's short-link
// redirect handler, and the Projects-page's per-vendor short-link
// generator/backfill) ───────────────────────────────────────────
function rp_ensure_short_code_column(PDO $db): void {
    try {
        $db->exec("ALTER TABLE rp_project_vendors ADD COLUMN short_code VARCHAR(20) DEFAULT NULL");
    } catch (PDOException $e) {
        // Column already exists — ignore (error 1060 = duplicate column)
    }
}

function rp_generate_short_code(PDO $db): string {
    // 6-char, URL-safe, collision-checked against rp_project_vendors.short_code
    do {
        $code = strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
        $chk = $db->prepare("SELECT COUNT(*) FROM rp_project_vendors WHERE short_code = ?");
        $chk->execute([$code]);
    } while ($chk->fetchColumn() > 0);
    return $code;
}

// ── VENDOR END-PAGE BEHAVIOR (show our page vs redirect to vendor) ─
function rp_ensure_vendor_end_behavior_column(PDO $db): void {
    try {
        $db->exec("ALTER TABLE rp_vendors ADD COLUMN end_behavior ENUM('show_page','redirect') NOT NULL DEFAULT 'show_page'");
    } catch (PDOException $e) {
        // Column already exists — ignore (error 1060 = duplicate column)
    }
}

// ── NOTES (multi-entry notepad) ────────────────────────────────
function rp_ensure_notes_table(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS rp_notes (
        id INT(11) NOT NULL AUTO_INCREMENT,
        title VARCHAR(200) DEFAULT NULL,
        content TEXT DEFAULT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

// ── AUDIT LOG (tracks who deleted what, for dispute resolution) ─
function rp_ensure_audit_table(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS rp_audit_log (
        id INT(11) NOT NULL AUTO_INCREMENT,
        user_name VARCHAR(100) DEFAULT NULL,
        action VARCHAR(100) NOT NULL,
        details VARCHAR(500) DEFAULT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function rp_log_audit(PDO $db, string $action, string $details = ''): void {
    rp_ensure_audit_table($db);
    $user = rp_current_user();
    $db->prepare("INSERT INTO rp_audit_log (user_name, action, details) VALUES (?,?,?)")
       ->execute([$user['name'] ?: $user['email'] ?: 'Unknown', $action, $details]);
}

// ── DEFER NETWORK CALLS UNTIL AFTER RESPONSE IS SENT ───────────
function rp_flush_and_defer(PDO $db, ?int $vendor_id, string $status, string $uid, string $sid, ?array $proj, $loi_seconds): void {
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    } else {
        if (ob_get_level() > 0) { ob_end_flush(); }
        flush();
    }
    if ($vendor_id) {
        rp_fire_vendor_postback($db, $vendor_id, $status, $uid, $sid);
    }
    if ($loi_seconds !== null) {
        rp_speeder_alert_check($proj, $sid, $uid, $loi_seconds);
    }
    // Outbound S2S — genuinely fires from HERE too now (previously only
    // wired into client_redirect.php), so a completion coming through the
    // normal project-level track.php/end.php flow (which is how MOST
    // completions genuinely arrive) also correctly reports out to the
    // client if they have S2S configured, not just the client-code-URL path.
    // Never fires for an unmatched status — same principle as skipping
    // vendor postback for one: we don't report an outcome we don't
    // genuinely recognize.
    if (!empty($proj['client_id']) && $status !== 'unmatched') {
        rp_fire_client_s2s($db, (int)$proj['client_id'], $status, $uid);
    }
}

// ── BLOCKED IP LIST ──────────────────────────────────────────────
function rp_ensure_blocked_ips_table(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS rp_blocked_ips (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        ip_address VARCHAR(45) NOT NULL,
        reason VARCHAR(255) DEFAULT NULL,
        blocked_by VARCHAR(100) DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_ip (ip_address)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

// Fail-open by design: if the blocked_ips table genuinely can't be
// queried for any reason (e.g. a fresh install where it hasn't been
// created yet), a real respondent must never be blocked from taking a
// genuine survey because of an internal error on our side — this
// check only ever ADDS a restriction, it should never itself become
// the reason a legitimate entry breaks.
function rp_is_ip_blocked(PDO $db, string $ip): bool {
    if ($ip === '') return false;
    try {
        rp_ensure_blocked_ips_table($db);
        $q = $db->prepare("SELECT 1 FROM rp_blocked_ips WHERE ip_address = ? LIMIT 1");
        $q->execute([$ip]);
        return (bool)$q->fetchColumn();
    } catch (Exception $e) {
        return false;
    }
}

// ── CLIENT PORTAL (Full Login Account) ────────────────────────────
// Unlike the read-only Client Report Link, this is a genuine
// username/password login for a client to see their own project data
// on an ongoing basis, without needing a new link every time.
function rp_ensure_portal_clients_table(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS rp_portal_clients (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(60) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        client_id INT UNSIGNED DEFAULT NULL,
        client_name VARCHAR(150) NOT NULL,
        is_active TINYINT(1) DEFAULT 1,
        last_login DATETIME DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}


// A reusable bank of demographic/screening questions, grouped into
// named templates that can be linked to any project — instead of
// prescreener.php's questions being permanently hardcoded, a project
// can use a different template (or the default hardcoded set, for
// backward compatibility if no template is linked).
function rp_ensure_question_library_tables(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS rp_question_library (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        question_text VARCHAR(255) NOT NULL,
        question_type ENUM('select','radio','text') DEFAULT 'select',
        options TEXT DEFAULT NULL,
        is_required TINYINT(1) DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $db->exec("CREATE TABLE IF NOT EXISTS rp_prescreen_templates (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        template_name VARCHAR(150) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $db->exec("CREATE TABLE IF NOT EXISTS rp_prescreen_template_questions (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        template_id INT UNSIGNED NOT NULL,
        question_id INT UNSIGNED NOT NULL,
        sort_order INT UNSIGNED DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function rp_ensure_project_template_column(PDO $db): void {
    try { $db->exec("ALTER TABLE rp_projects ADD COLUMN prescreen_template_id INT UNSIGNED DEFAULT NULL"); } catch (PDOException $e) {}
}


// Simple time/task tracking per project, per team-member — lets a
// project manager log what they worked on and how long it took, so
// there's a record of hands-on effort spent, separate from the
// automated respondent-tracking data.
function rp_ensure_pm_activity_table(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS rp_pm_activity (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        project_id INT NOT NULL,
        user_name VARCHAR(100) NOT NULL,
        task TEXT NOT NULL,
        minutes_spent INT UNSIGNED DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

// ── IR DRIFT ALERT ─────────────────────────────────────────────
// Looks at the last 50 real terminal responses (complete/terminate,
// genuine entries only) on a project and fires once if the
// completion-rate has quietly dropped below 20% — usually means a
// client's survey link broke, a quota filled unexpectedly, or fraud
// traffic is flooding in.
function rp_check_ir_drift(PDO $db, string $sid): void {
    try {
        $rows = $db->prepare("SELECT status FROM rp_leads WHERE sid = ? AND status IN ('complete','terminate') ORDER BY id DESC LIMIT 50");
        $rows->execute([$sid]);
        $last50 = $rows->fetchAll(PDO::FETCH_COLUMN);
        if (count($last50) < 10) return;
        $completes = count(array_filter($last50, fn($s) => $s === 'complete'));
        $ir = round(($completes / count($last50)) * 1000) / 10;
        if ($ir < 20) {
            rp_send_telegram_alert("🚨 IR Drift Alert!\nProject: $sid\nLast " . count($last50) . " responses IR: {$ir}%\nBelow 20% threshold — check immediately!");
        }
    } catch (Exception $e) {}
}


// A single project's live_url is usually one fixed URL, but some
// clients run genuinely different survey-links per country (different
// language/currency version of the same study). This lets a project
// have per-country URL overrides — the respondent's detected country
// picks a different destination automatically, falling back to the
// project's normal live_url if no override matches.
function rp_ensure_country_links_table(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS rp_country_links (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        project_id INT NOT NULL,
        country VARCHAR(80) NOT NULL,
        url TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_project_country (project_id, country)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function rp_get_country_link(PDO $db, int $project_id, string $country): ?string {
    if ($country === '') return null;
    try {
        rp_ensure_country_links_table($db);
        $q = $db->prepare("SELECT url FROM rp_country_links WHERE project_id = ? AND country = ? LIMIT 1");
        $q->execute([$project_id, $country]);
        $url = $q->fetchColumn();
        return $url ?: null;
    } catch (Exception $e) {
        return null;
    }
}


// Different client platforms send different words for the same
// outcome (e.g. "success" instead of "complete"). Rather than these
// silently becoming "unmatched" every single time, a synonym can be
// mapped to one of the 4 canonical statuses — either globally
// (sid IS NULL, applies to every project) or per-project (overrides
// the global list for that one project specifically).
function rp_ensure_status_synonyms_table(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS rp_status_synonyms (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        sid VARCHAR(50) DEFAULT NULL,
        synonym VARCHAR(60) NOT NULL,
        maps_to VARCHAR(20) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_sid_synonym (sid, synonym)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function rp_seed_default_status_synonyms(PDO $db): void {
    // Bug fix: this function was defined but never actually called
    // anywhere, so the table was always empty on a fresh install. Guard
    // added so it only seeds once (skips if any row already exists),
    // rather than re-running 20 INSERT IGNOREs on every lookup.
    $count = $db->query("SELECT COUNT(*) FROM rp_status_synonyms")->fetchColumn();
    if ($count > 0) return;
    $defaults = [
        ['success', 'complete'], ['ok', 'complete'], ['done', 'complete'],
        ['finish', 'complete'], ['finished', 'complete'], ['completed', 'complete'],
        ['screenout', 'terminate'], ['screen-out', 'terminate'], ['screen_out', 'terminate'],
        ['disqualified', 'terminate'], ['disqualify', 'terminate'], ['ineligible', 'terminate'],
        ['reject', 'terminate'], ['rejected', 'terminate'], ['fail', 'terminate'], ['failed', 'terminate'],
        ['over-quota', 'overquota'], ['over_quota', 'overquota'], ['full', 'overquota'],
        ['flagged', 'quality_fail'], ['screened', 'quality_fail'],
    ];
    $ins = $db->prepare("INSERT IGNORE INTO rp_status_synonyms (sid, synonym, maps_to) VALUES (NULL, ?, ?)");
    foreach ($defaults as [$syn, $maps]) {
        $ins->execute([$syn, $maps]);
    }
}

// Resolves an incoming raw status word to one of the 5 canonical
// statuses (complete/terminate/overquota/quality_fail), or null if
// genuinely unrecognized even after synonym lookup. A per-project
// (sid-specific) entry always wins over a global (sid IS NULL) one.
function rp_resolve_status_synonym(PDO $db, string $raw_status, ?string $sid): ?string {
    $raw = strtolower(trim($raw_status));
    if ($raw === '') return null;
    try {
        rp_ensure_status_synonyms_table($db);
        // Bug fix: the seed function existed but was never wired in, so
        // the table was always empty even after this ensure-call.
        rp_seed_default_status_synonyms($db);
        $q = $db->prepare("SELECT sid, maps_to FROM rp_status_synonyms WHERE synonym = ? AND (sid = ? OR sid IS NULL)");
        $q->execute([$raw, $sid]);
        $rows = $q->fetchAll();
        if (!$rows) return null;
        foreach ($rows as $r) {
            if ($r['sid'] === $sid) return $r['maps_to'];
        }
        return $rows[0]['maps_to'];
    } catch (Exception $e) {
        return null;
    }
}


function rp_build_url(string $template, array $tokens): string {
    $url = $template;
    $wrapper_patterns = [
        '/\{\{\s*%s\s*\}\}/i',   // {{token}}
        '/\[\s*%s\s*\]/i',       // [TOKEN]
        '/\[#\s*%s\s*#\]/i',     // [#token#]  (e.g. OpinionSpark-style)
        '/\{\s*%s\s*\}/i',       // {token}
        '/%%\s*%s\s*%%/i',       // %TOKEN%
        '/<\s*%s\s*>/i',         // <token>
        '/\$\s*%s\s*\$/i',       // $token$
    ];
    foreach ($tokens as $key => $value) {
        if ($value === null) continue;
        $quoted_key = preg_quote((string)$key, '/');
        foreach ($wrapper_patterns as $pattern_template) {
            $pattern = sprintf($pattern_template, $quoted_key);
            $url = preg_replace($pattern, (string)$value, $url);
        }
    }
    return $url;
}

function rp_build_token_set(string $uid, string $sid, array $extra = []): array {
    $base = [
        // 'pid' = Panelist ID (the respondent) — confirmed industry-standard
        // meaning per Medallia/SoSciSurvey/Qualtrics panel-integration docs.
        // NOT the project/study ID (that's sid/studyid/surveyid below).
        'uid' => $uid, 'rid' => $uid, 'toid' => $uid, 'identifier' => $uid, 'tid' => $uid, 'pid' => $uid,
        'userid' => $uid, 'user_id' => $uid, 'respid' => $uid, 'resp_id' => $uid,
        'respondentid' => $uid, 'respondent_id' => $uid, 'panelistid' => $uid, 'panelist_id' => $uid,
        'participantid' => $uid, 'participant_id' => $uid, 'memberid' => $uid, 'member_id' => $uid,
        'entryid' => $uid, 'entry_id' => $uid, 'clickid' => $uid, 'subid' => $uid,
        'transactionid' => $uid, 'transaction_id' => $uid, 'qparm' => $uid, 'subject_id' => $uid,
        'ext_ref' => $uid, 'external_id' => $uid, 'id' => $uid, 'ticket' => $uid,
        'sid' => $sid, 'studyid' => $sid, 'surveyid' => $sid,
        'survey_id' => $sid, 'projectid' => $sid, 'project_id' => $sid, 'gid' => $sid,
        'date' => date('Y-m-d'),
        'timestamp' => (string)time(),
    ];
    return array_merge($base, $extra);
}

function rp_send_vendor_postback(?string $url_template, string $original_uid, string $sid, $loi_seconds = null): bool {
    if (!$url_template) return false;
    $tokens = rp_build_token_set(urlencode($original_uid), urlencode($sid), [
        'loi' => urlencode((string)($loi_seconds ?? '')),
    ]);
    $url = rp_build_url($url_template, $tokens);
    try {
        $ctx = stream_context_create(['http' => ['timeout' => 4, 'method' => 'GET']]);
        @file_get_contents($url, false, $ctx);
        return true;
    } catch (Exception $e) {
        error_log("rp_send_vendor_postback error: " . $e->getMessage());
        return false;
    }
}

function rp_vendor_status_column(string $status): ?string {
    $col_map = [
        'complete'     => 'complete_url',
        'terminate'    => 'terminate_url',
        'quality_fail' => 'screenout_url',
        'overquota'    => 'quotafull_url',
    ];
    return $col_map[$status] ?? null;
}

function rp_get_vendor_url_template(PDO $db, ?int $vendor_id, string $status): ?string {
    if (!$vendor_id) return null;
    $col = rp_vendor_status_column($status);
    if (!$col) return null;
    $v = $db->prepare("SELECT $col FROM rp_vendors WHERE id = ? LIMIT 1");
    $v->execute([$vendor_id]);
    $url = $v->fetchColumn();
    return $url ?: null;
}

function rp_get_vendor_end_behavior(PDO $db, ?int $vendor_id): string {
    if (!$vendor_id) return 'show_page';
    rp_ensure_vendor_end_behavior_column($db);
    $v = $db->prepare("SELECT end_behavior FROM rp_vendors WHERE id = ? LIMIT 1");
    $v->execute([$vendor_id]);
    $behavior = $v->fetchColumn();
    return $behavior === 'redirect' ? 'redirect' : 'show_page';
}

function rp_fire_vendor_postback(PDO $db, ?int $vendor_id, string $status, string $original_uid, string $sid, $loi_seconds = null): void {
    $url = rp_get_vendor_url_template($db, $vendor_id, $status);
    if ($url) {
        rp_send_vendor_postback($url, $original_uid, $sid, $loi_seconds);
    }
}

// ── OUTBOUND S2S (report to a CLIENT like Cint/Lucid) ────────────
// Mirror of rp_fire_vendor_postback above, but reports to the
// project's CLIENT rather than to our own vendor — fires when we are
// acting as the vendor/supplier to a bigger marketplace, and that
// client has server-to-server reporting configured. Fire-and-forget:
// a failed outbound call must never break the respondent's own
// redirect/status page.
function rp_fire_client_s2s(PDO $db, int $client_id, string $status, string $uid): void {
    try {
        $db->exec("ALTER TABLE rp_clients ADD COLUMN s2s_outbound_enabled TINYINT(1) DEFAULT 0");
        $db->exec("ALTER TABLE rp_clients ADD COLUMN s2s_outbound_endpoint VARCHAR(500) DEFAULT NULL");
        $db->exec("ALTER TABLE rp_clients ADD COLUMN s2s_outbound_token VARCHAR(200) DEFAULT NULL");
    } catch (PDOException $e) {}

    $cs = $db->prepare("SELECT s2s_outbound_enabled, s2s_outbound_endpoint, s2s_outbound_token FROM rp_clients WHERE id=? LIMIT 1");
    $cs->execute([$client_id]);
    $client = $cs->fetch();
    if (!$client || !$client['s2s_outbound_enabled'] || empty($client['s2s_outbound_endpoint'])) return;

    $ch = curl_init($client['s2s_outbound_endpoint']);
    $headers = ['Content-Type: application/json'];
    if (!empty($client['s2s_outbound_token'])) {
        $headers[] = 'Authorization: Bearer ' . $client['s2s_outbound_token'];
    }
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode(['respondent_id' => $uid, 'status' => $status]),
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => 4,
        CURLOPT_RETURNTRANSFER => true,
    ]);
    @curl_exec($ch);
    curl_close($ch);
}

function rp_build_vendor_redirect_url(PDO $db, ?int $vendor_id, string $status, string $original_uid, string $sid, $loi_seconds = null): ?string {
    if (rp_get_vendor_end_behavior($db, $vendor_id) !== 'redirect') return null;
    $url_template = rp_get_vendor_url_template($db, $vendor_id, $status);
    if (!$url_template) return null;
    $tokens = rp_build_token_set(urlencode($original_uid), urlencode($sid), [
        'loi' => urlencode((string)($loi_seconds ?? '')),
    ]);
    return rp_build_url($url_template, $tokens);
}

function rp_speeder_alert_check(?array $proj, string $sid, string $uid, $actual_seconds): void {
    if (!$proj || empty($proj['loi']) || !is_numeric($actual_seconds)) return;
    $expected_seconds = (int)$proj['loi'] * 60;
    if ($expected_seconds <= 0) return;
    if ((int)$actual_seconds < ($expected_seconds * 0.3)) {
        $pname = $proj['project_name'] ?? $sid;
        $msg = "⚡ Speeder Detected\nProject: {$pname} ({$sid})\nUID: {$uid}\nCompleted in " . round($actual_seconds/60,1) . " min (expected {$proj['loi']} min)";
        rp_send_telegram_alert($msg);
    }
}

// ── EMAIL ALERT ──────────────────────────────────────────────
function rp_send_email_alert(string $subject, string $message): bool {
    try {
        $db    = rp_db();
        $email = rp_get_setting($db, 'alert_email');
        if (!$email) return false;
        $headers = "Content-Type: text/plain; charset=UTF-8\r\nFrom: no-reply@" . ($_SERVER['HTTP_HOST'] ?? 'panel.local');
        return @mail($email, $subject, $message, $headers);
    } catch (Exception $e) {
        error_log("rp_send_email_alert error: " . $e->getMessage());
        return false;
    }
}

// ── PROJECT-ID RESOLUTION (client's own reference -> our internal sid) ──
function rp_ensure_project_id_map_table(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS rp_project_id_map (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        client_pid VARCHAR(100) NOT NULL,
        sid VARCHAR(50) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_client_pid (client_pid)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function rp_resolve_project_id(PDO $db, string $incoming_project_id): string {
    if ($incoming_project_id === '') return '';

    $ps = $db->prepare("SELECT sid FROM rp_projects WHERE sid = ? LIMIT 1");
    $ps->execute([$incoming_project_id]);
    if ($ps->fetchColumn()) {
        return $incoming_project_id;
    }

    // Bug fix: this table was queried without ever being created, which
    // threw a fatal DB error the first time a client's reference
    // genuinely didn't match an existing sid. Now created on demand.
    try {
        rp_ensure_project_id_map_table($db);
        $ms = $db->prepare("SELECT sid FROM rp_project_id_map WHERE client_pid = ? LIMIT 1");
        $ms->execute([$incoming_project_id]);
        $mapped = $ms->fetchColumn();
        if ($mapped) {
            return $mapped;
        }
    } catch (Exception $e) {}

    return $incoming_project_id;
}
