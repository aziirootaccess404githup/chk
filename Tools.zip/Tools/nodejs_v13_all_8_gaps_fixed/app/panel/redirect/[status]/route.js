import { NextResponse } from 'next/server';
import crypto from 'crypto';
import { supabaseAdmin } from '@/utils/supabase';
import { decryptUID } from '@/utils/encryption';
import { runFraudChecks, TERMINAL_STATUSES, DEFAULT_SPEEDER_THRESHOLD_SECONDS } from '@/utils/fraudDetection';
import { buildUrl, buildTokenSet } from '@/utils/universalTokens';
import { sendTelegramAlert } from '@/utils/telegramAlert';
import { resolveStatusSynonym } from '@/utils/statusSynonyms';

const REDIRECT_SIGNATURE_SECRET = process.env.REDIRECT_SIGNATURE_SECRET || 'exazon-redirect-signature-secret';

export async function GET(request, { params }) {
    const { status } = await params;
    
    const url = new URL(request.url);
    const pid = url.searchParams.get('pid');   // project_id (UUID) — baked into our redirect URLs
    const sid = url.searchParams.get('sid');   // supplier_id (UUID) — baked into our redirect URLs
    const originalUid = url.searchParams.get('uid') || 'unknown';
    const redirected = url.searchParams.get('redirected');
    const sig = url.searchParams.get('sig');

    // ─────────────────────────────────────────────────────────────
    // OPTIONAL SIGNATURE CHECK (ported from ExaVerify's pages/track.php
    // SHA-256 verification) — purely informational, same as ExaVerify:
    // logs a mismatch for later review, never blocks the respondent's
    // own redirect/status page. Only relevant if a client's platform
    // genuinely sends a &sig= param at all — most don't, and that's
    // fine, this simply does nothing when sig is absent.
    // ─────────────────────────────────────────────────────────────
    if (sig) {
        const expected = crypto.createHmac('sha256', REDIRECT_SIGNATURE_SECRET)
            .update(`${status}|${pid || ''}|${originalUid}`)
            .digest('hex');
        if (expected !== sig) {
            console.warn(`Signature mismatch on /panel/redirect/${status} — pid=${pid} uid=${originalUid}`);
        }
    }

    // Always try to decrypt the UID (in case it's our encrypted token)
    let uid = originalUid;
    let decodedOriginalUid = originalUid;
    try {
        let toDecrypt = originalUid;
        if (originalUid.includes('%')) {
            try { toDecrypt = decodeURIComponent(originalUid); } catch(e) {}
        }
        decodedOriginalUid = toDecrypt;
        const decrypted = decryptUID(toDecrypt);
        // Only use decrypted value if decryption actually changed it
        if (decrypted && decrypted !== toDecrypt) {
            uid = decrypted;
        }
    } catch (e) {
        // uid stays as originalUid
    }

    // Get IP address
    const forwarded = request.headers.get('x-forwarded-for');
    const ip = forwarded ? forwarded.split(',')[0].trim() : request.headers.get('x-real-ip') || '0.0.0.0';

    // Map URL status to internal DB status
    let internalStatus = 'Started';
    let supplierUrlField = '';
    
    switch (status) {
        case 'complete':
            internalStatus = 'Complete';
            supplierUrlField = 'complete_url';
            break;
        case 'terminate':
            internalStatus = 'Terminate';
            supplierUrlField = 'terminate_url';
            break;
        case 'quota-full':
            internalStatus = 'OverQuota';
            supplierUrlField = 'quotafull_url';
            break;
        case 'quality-check':
            internalStatus = 'SecurityFail';
            supplierUrlField = 'quality_url';
            break;
        default:
            // Previously this returned a hard 400 error — meaning an
            // unrecognized status (client sent something we don't
            // literally match, or only configured 3 of the 4 usual
            // redirect-URLs) meant NOTHING got saved at all, and the
            // respondent saw a raw JSON error page. Ported from
            // ExaVerify's "unmatched status" fix: any unrecognized value
            // now becomes its own distinct 'Unmatched' status — genuinely
            // saved (so there's a record/proof), left UNLOCKED (so a
            // correct status arriving later for the same respondent can
            // still overwrite it), shown a neutral "Under Review" page
            // instead of an error, and does not fire any vendor postback.
            internalStatus = 'Unmatched';
            supplierUrlField = '';
            break;
    }

    // Helper: build the supplier redirect URL with proper UID + PROJECT_CODE + LOI substitution
    function buildSupplierRedirect(supplier, respondentUid, projectTitle, loiSeconds) {
        if (!supplier || !supplier[supplierUrlField]) return null;

        // Universal 41-token x 7-bracket-style substitution (ported from
        // ExaVerify's exz_build_url/exz_build_token_set) — works with
        // [UID], {{uid}}, %UID%, <uid>, $uid$, [#uid#], {uid}, and every
        // common alias vendors use (pid, respondentid, subid, clickid, etc),
        // same for the project-code family (sid, studyid, projectcode, etc).
        const tokens = buildTokenSet(respondentUid, projectTitle || '', {
            loi: loiSeconds !== null && loiSeconds !== undefined ? loiSeconds : '',
            vid: finalSupplierId || '',
            ip: ip || '',
        });
        let finalUrl = buildUrl(supplier[supplierUrlField], tokens);

        // For Dynamic suppliers — if UID still not in URL (template had no
        // recognized token at all), append it as a fallback.
        if (supplier.supplier_type === 'Dynamic' && !finalUrl.includes(encodeURIComponent(respondentUid))) {
            const separator = finalUrl.includes('?') ? '&' : '?';
            finalUrl += `${separator}uid=${encodeURIComponent(respondentUid)}`;
        }

        // Prevent infinite redirect loop
        if (finalUrl.includes('/panel/redirect/') && redirected === '1') {
            return null;
        }
        if (finalUrl.includes('/panel/redirect/')) {
            const separator = finalUrl.includes('?') ? '&' : '?';
            finalUrl += `${separator}redirected=1`;
        }
        
        return finalUrl;
    }

    const isValidUUID = (uuid) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(uuid);
    const isPidUUID = pid && isValidUUID(pid);
    const isSidUUID = sid && isValidUUID(sid);

    // All UID variants to try when searching the DB
    const uidsToTry = [...new Set([uid, originalUid, decodedOriginalUid])].filter(Boolean);

    try {
        let matchedLog = null;

        // ─────────────────────────────────────────────────────────────
        // STRATEGY 1: We have project_id + supplier_id (from our baked-in URLs)
        // Search the tracking log scoped to this project + supplier
        // ─────────────────────────────────────────────────────────────
        if (isPidUUID && isSidUUID) {
            for (const uidToTry of uidsToTry) {
                const { data: logs } = await supabaseAdmin
                    .from('tracking_logs')
                    .select('id, project_id, supplier_id, respondent_uid, status, status_locked, started_at, loi_seconds, is_duplicate')
                    .eq('project_id', pid)
                    .eq('supplier_id', sid)
                    .eq('respondent_uid', uidToTry)
                    .order('started_at', { ascending: false })
                    .limit(1);
                if (logs && logs.length > 0) { matchedLog = logs[0]; break; }
            }
            // Also try encrypted_uid column
            if (!matchedLog) {
                const { data: encLogs } = await supabaseAdmin
                    .from('tracking_logs')
                    .select('id, project_id, supplier_id, respondent_uid, status, status_locked, started_at, loi_seconds, is_duplicate')
                    .eq('project_id', pid)
                    .eq('supplier_id', sid)
                    .in('encrypted_uid', uidsToTry)
                    .order('started_at', { ascending: false })
                    .limit(1);
                if (encLogs && encLogs.length > 0) matchedLog = encLogs[0];
            }
        }

        // ─────────────────────────────────────────────────────────────
        // STRATEGY 2: Only project_id known (no supplier)
        // ─────────────────────────────────────────────────────────────
        if (!matchedLog && isPidUUID) {
            for (const uidToTry of uidsToTry) {
                const { data: logs } = await supabaseAdmin
                    .from('tracking_logs')
                    .select('id, project_id, supplier_id, respondent_uid, status, status_locked, started_at, loi_seconds, is_duplicate')
                    .eq('project_id', pid)
                    .eq('respondent_uid', uidToTry)
                    .order('started_at', { ascending: false })
                    .limit(1);
                if (logs && logs.length > 0) { matchedLog = logs[0]; break; }
            }
        }

        // ─────────────────────────────────────────────────────────────
        // STRATEGY 3: No project info — search by UID alone across all projects
        // ─────────────────────────────────────────────────────────────
        if (!matchedLog) {
            for (const uidToTry of uidsToTry) {
                const { data: logs } = await supabaseAdmin
                    .from('tracking_logs')
                    .select('id, project_id, supplier_id, respondent_uid, status, status_locked, started_at, loi_seconds, is_duplicate')
                    .eq('respondent_uid', uidToTry)
                    .order('started_at', { ascending: false })
                    .limit(1);
                if (logs && logs.length > 0) { matchedLog = logs[0]; break; }
            }
            // Try encrypted_uid column
            if (!matchedLog) {
                const { data: encLogs } = await supabaseAdmin
                    .from('tracking_logs')
                    .select('id, project_id, supplier_id, respondent_uid, status, status_locked, started_at, loi_seconds, is_duplicate')
                    .in('encrypted_uid', uidsToTry)
                    .order('started_at', { ascending: false })
                    .limit(1);
                if (encLogs && encLogs.length > 0) matchedLog = encLogs[0];
            }
        }

        // ─────────────────────────────────────────────────────────────
        // STRATEGY 4: Short-code — pid/sid are not UUIDs
        // Try unique_code or project title lookup
        // ─────────────────────────────────────────────────────────────
        let resolvedProjectId = null;
        let resolvedSupplierId = null;

        if (!matchedLog && pid && pid !== 'XXXX' && !isPidUUID) {
            // Try matching sid as our unique_code (e.g. "6P426")
            if (sid && sid !== 'XXXX') {
                const { data: mappingBySid } = await supabaseAdmin
                    .from('project_supplier_mappings')
                    .select('project_id, supplier_id')
                    .eq('unique_code', sid)
                    .maybeSingle();
                if (mappingBySid) {
                    resolvedProjectId = mappingBySid.project_id;
                    resolvedSupplierId = mappingBySid.supplier_id;
                }
            }

            // Try project title lookup
            if (!resolvedProjectId) {
                const { data: projByTitle } = await supabaseAdmin
                    .from('projects')
                    .select('id')
                    .eq('title', pid)
                    .maybeSingle();
                
                if (projByTitle) {
                    resolvedProjectId = projByTitle.id;
                    const { data: firstMapping } = await supabaseAdmin
                        .from('project_supplier_mappings')
                        .select('supplier_id')
                        .eq('project_id', resolvedProjectId)
                        .eq('allow_traffic', true)
                        .order('created_at', { ascending: true })
                        .limit(1)
                        .maybeSingle();
                    if (firstMapping) resolvedSupplierId = firstMapping.supplier_id;
                }
            }

            if (resolvedProjectId) {
                for (const uidToTry of uidsToTry) {
                    const { data: logs } = await supabaseAdmin
                        .from('tracking_logs')
                        .select('id, project_id, supplier_id, respondent_uid, status, status_locked, started_at, loi_seconds, is_duplicate')
                        .eq('project_id', resolvedProjectId)
                        .eq('respondent_uid', uidToTry)
                        .order('started_at', { ascending: false })
                        .limit(1);
                    if (logs && logs.length > 0) { matchedLog = logs[0]; break; }
                }
            }
        }

        // ─────────────────────────────────────────────────────────────
        // Determine final project_id and supplier_id for DB operations
        // ─────────────────────────────────────────────────────────────
        const finalProjectId = matchedLog?.project_id || resolvedProjectId || (isPidUUID ? pid : null);
        const finalSupplierId = matchedLog?.supplier_id || resolvedSupplierId || (isSidUUID ? sid : null);
        const finalUid = uid; // decrypted if possible, else raw

        // ─────────────────────────────────────────────────────────────
        // STATUS SYNONYM MAPPING (ported from ExaVerify's
        // exz_resolve_status_synonym) — only relevant when the URL's
        // status-segment didn't exactly match one of our 4 known values
        // (internalStatus is still 'Unmatched' at this point). Checks
        // this project's own overrides first, then the global defaults,
        // for a word this client's platform commonly sends instead
        // (e.g. "success" for complete, "disqualified" for terminate).
        // ─────────────────────────────────────────────────────────────
        if (internalStatus === 'Unmatched') {
            const resolvedSynonym = await resolveStatusSynonym(supabaseAdmin, status, finalProjectId);
            if (resolvedSynonym) {
                const synonymMap = {
                    'complete': ['Complete', 'complete_url'],
                    'terminate': ['Terminate', 'terminate_url'],
                    'quota-full': ['OverQuota', 'quotafull_url'],
                    'quality-check': ['SecurityFail', 'quality_url'],
                };
                const [mappedStatus, mappedUrlField] = synonymMap[resolvedSynonym] || [];
                if (mappedStatus) {
                    internalStatus = mappedStatus;
                    supplierUrlField = mappedUrlField;
                }
            }
        }

        // ─────────────────────────────────────────────────────────────
        // STATUS-LOCK CHECK (ported from ExaVerify's pages/track.php)
        // If this lead already has a genuine terminal result locked in,
        // a second hit (respondent refresh, vendor double-postback,
        // survey-platform retry) must NEVER overwrite it or get scored
        // twice. We show/return the ORIGINAL locked status instead.
        // ─────────────────────────────────────────────────────────────
        const isAlreadyLocked = !!(matchedLog && matchedLog.status_locked && TERMINAL_STATUSES.includes(matchedLog.status));
        if (isAlreadyLocked) {
            internalStatus = matchedLog.status;
            const reverseUrlField = { Complete: 'complete_url', Terminate: 'terminate_url', OverQuota: 'quotafull_url', SecurityFail: 'quality_url' };
            supplierUrlField = reverseUrlField[internalStatus] || supplierUrlField;

            // ─────────────────────────────────────────────────────────
            // DUPLICATE-ON-LOCKED-LEAD DETECTION (ported from ExaVerify's
            // pages/track.php). A repeat hit here is genuinely useful
            // fraud signal (a vendor/bot resubmitting, or a respondent
            // trying again) — must not be silently invisible to Fraud
            // Detection just because the lead is locked and no further
            // status-write happens. Flag is_duplicate and fire the alert,
            // but only the FIRST time a repeat is seen for this lead
            // (checked via is_duplicate not already being true) — so a
            // client/vendor repeatedly hitting the same completion URL
            // doesn't spam one alert per hit.
            // ─────────────────────────────────────────────────────────
            if (matchedLog.id && !matchedLog.is_duplicate) {
                await supabaseAdmin
                    .from('tracking_logs')
                    .update({ is_duplicate: true })
                    .eq('id', matchedLog.id);
                sendTelegramAlert(
                    `⚠️ Duplicate UID! (repeat hit on an already-locked lead)\nProject: ${finalProjectId}\nUID: ${finalUid}\nStatus: ${internalStatus} | IP: ${ip}\nThe same respondent attempted again after their result was already locked in!`
                );
            }
        }

        // Fetch project once (title for [PROJECT_CODE], speeder threshold) — reused below
        let projectTitle = null;
        let speederThresholdSeconds = DEFAULT_SPEEDER_THRESHOLD_SECONDS;
        if (finalProjectId) {
            try {
                const { data: projData } = await supabaseAdmin
                    .from('projects')
                    .select('title, speeder_threshold_seconds')
                    .eq('id', finalProjectId)
                    .single();
                projectTitle = projData?.title || null;
                if (projData?.speeder_threshold_seconds) speederThresholdSeconds = projData.speeder_threshold_seconds;
            } catch (e) {}
        }

        // ─────────────────────────────────────────────────────────────
        // UPDATE or INSERT tracking log — fraud-detection runs only on a
        // FRESH write (never on an already-locked repeat hit).
        // ─────────────────────────────────────────────────────────────
        let loiSeconds = matchedLog?.loi_seconds ?? null; // reused for [LOI] substitution further down

        let currentLogId = matchedLog?.id || null;
        let isGhostEntry = false;

        if (!isAlreadyLocked) {
            const fraudResult = await runFraudChecks(supabaseAdmin, {
                projectId: finalProjectId,
                uid: finalUid,
                ip,
                startedAt: matchedLog?.started_at || null,
                speederThresholdSeconds,
                excludeLogId: matchedLog?.id,
            });
            loiSeconds = fraudResult.loi_seconds;

            // Real-time Speeder alert (ported from ExaVerify's exz_speeder_check)
            if (fraudResult.is_speeder) {
                sendTelegramAlert(
                    `⚡ Speeder Detected\nProject: ${projectTitle || finalProjectId}\nUID: ${finalUid}\nCompleted in ${Math.round((loiSeconds || 0) / 60 * 10) / 10} min (under threshold)`
                );
            }

            if (matchedLog) {
                // Update existing log status + fraud-detection results, lock it
                // (only for genuine terminal statuses — Unmatched stays
                // unlocked so a real status arriving later can overwrite it)
                await supabaseAdmin
                    .from('tracking_logs')
                    .update({
                        status: internalStatus,
                        completed_at: new Date().toISOString(),
                        ip_address: ip,
                        status_locked: TERMINAL_STATUSES.includes(internalStatus),
                        ...fraudResult,
                    })
                    .eq('id', matchedLog.id);

                // ─────────────────────────────────────────────────────────
                // IR-DRIFT ALERT (ported from ExaVerify's Overview-tab IR
                // Drift check). Only meaningful for a genuine Complete/
                // Terminate write (not Ghost/Unmatched) — looks at the
                // last 50 real terminal responses on THIS project and
                // fires once if the completion-rate has quietly dropped
                // below 20%, which usually means a client's survey link
                // broke, a quota filled unexpectedly, or fraud traffic is
                // flooding in.
                // ─────────────────────────────────────────────────────────
                if ((internalStatus === 'Complete' || internalStatus === 'Terminate') && finalProjectId) {
                    const { data: last50 } = await supabaseAdmin
                        .from('tracking_logs')
                        .select('status')
                        .eq('project_id', finalProjectId)
                        .in('status', ['Complete', 'Terminate'])
                        .eq('no_entry_record', false)
                        .order('completed_at', { ascending: false })
                        .limit(50);
                    if (last50 && last50.length >= 10) {
                        const completeCount = last50.filter(r => r.status === 'Complete').length;
                        const irDrift = Math.round((completeCount / last50.length) * 1000) / 10;
                        if (irDrift < 20) {
                            sendTelegramAlert(
                                `🚨 IR Drift Alert!\nProject: ${projectTitle || finalProjectId}\nLast ${last50.length} responses IR: ${irDrift}%\nBelow 20% threshold — check immediately!`
                            );
                        }
                    }
                }
            } else if (finalProjectId) {
                // ─────────────────────────────────────────────────────────
                // GHOST-ENTRY CHECK (ported from ExaVerify's pages/track.php)
                // No existing tracking_logs row was found at all for this
                // respondent — meaning they never genuinely went through
                // /r/[unique_code] (which always creates a 'Started' row
                // first). This completion-URL was hit directly (copied/
                // replayed URL, manual test, etc). Still SAVE it (fully
                // auditable — nothing silently lost), but flag it via
                // no_entry_record so it never gets silently counted as a
                // genuine, trustworthy completion.
                // ─────────────────────────────────────────────────────────
                const { data: insertedLog } = await supabaseAdmin
                    .from('tracking_logs')
                    .insert([{
                        project_id: finalProjectId,
                        supplier_id: finalSupplierId || null,
                        respondent_uid: finalUid,
                        status: internalStatus,
                        completed_at: new Date().toISOString(),
                        ip_address: ip,
                        status_locked: TERMINAL_STATUSES.includes(internalStatus),
                        no_entry_record: true,
                        ...fraudResult,
                    }])
                    .select('id')
                    .single();
                currentLogId = insertedLog?.id || null;
                isGhostEntry = true;

                sendTelegramAlert(
                    `👻 Ghost Entry Detected!\nProject: ${projectTitle || finalProjectId}\nUID: ${finalUid}\nStatus: ${internalStatus} | IP: ${ip}\nThis completion has NO matching entry-click on record — recorded but excluded from stats/postback/quota.`
                );
            }
        }

        // ─────────────────────────────────────────────────────────────
        // POSTBACK: fire-and-forget background notification for suppliers
        // configured with end_behavior='show_page'. Never blocks the
        // response to the respondent — postback_status is updated
        // asynchronously once the background call resolves.
        // (Ported from ExaVerify's exz_fire_vendor_postback.)
        // ─────────────────────────────────────────────────────────────
        async function firePostbackIfNeeded(supplier) {
            if (!currentLogId) return;
            if (!supplier || supplier.end_behavior !== 'show_page') return;

            const templateUrl = supplier[supplierUrlField];
            if (!templateUrl) {
                await supabaseAdmin
                    .from('tracking_logs')
                    .update({ postback_status: 'not_applicable', postback_at: new Date().toISOString() })
                    .eq('id', currentLogId);
                return;
            }

            const tokens = buildTokenSet(finalUid, projectTitle || '', {
                loi: loiSeconds !== null && loiSeconds !== undefined ? loiSeconds : '',
            });
            const postbackUrl = buildUrl(templateUrl, tokens);

            // Fire-and-forget: don't await the network call itself, but do
            // chain the DB status-update onto its result so it's recorded
            // once the background request settles.
            fetch(postbackUrl, { method: 'GET', signal: AbortSignal.timeout(4000) })
                .then(() => supabaseAdmin
                    .from('tracking_logs')
                    .update({ postback_status: 'sent', postback_at: new Date().toISOString() })
                    .eq('id', currentLogId))
                .catch(() => supabaseAdmin
                    .from('tracking_logs')
                    .update({ postback_status: 'failed', postback_at: new Date().toISOString() })
                    .eq('id', currentLogId));
        }

        // ─────────────────────────────────────────────────────────────
        // REDIRECT respondent to supplier's configured URL (if any)
        // ─────────────────────────────────────────────────────────────
        if (finalSupplierId) {
            const { data: supplier } = await supabaseAdmin
                .from('suppliers')
                .select(`supplier_type, end_behavior, ${supplierUrlField}`)
                .eq('id', finalSupplierId)
                .single();

        // ─────────────────────────────────────────────────────────────
        // OUTBOUND S2S: report final status to the PROJECT'S CLIENT, if
        // that client has server-to-server reporting configured — the
        // "we are the vendor/supplier reporting up to a marketplace like
        // Cint" direction. Deliberately separate from firePostbackIfNeeded
        // above, which reports to OUR OWN supplier (who sent us this
        // respondent) — this one reports to the CLIENT whose survey it is.
        // Fires regardless of the supplier's end_behavior, since it's an
        // independent reporting relationship, not tied to how the
        // respondent's own browser gets redirected.
        // ─────────────────────────────────────────────────────────────
        async function fireClientS2SIfNeeded() {
            if (!finalProjectId) return;
            const { data: project } = await supabaseAdmin
                .from('projects')
                .select('client_id')
                .eq('id', finalProjectId)
                .single();
            if (!project?.client_id) return;

            const { data: client } = await supabaseAdmin
                .from('clients')
                .select('s2s_outbound_enabled, s2s_outbound_endpoint, s2s_outbound_token')
                .eq('id', project.client_id)
                .single();
            if (!client?.s2s_outbound_enabled || !client.s2s_outbound_endpoint) return;

            try {
                await fetch(client.s2s_outbound_endpoint, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        ...(client.s2s_outbound_token ? { 'Authorization': `Bearer ${client.s2s_outbound_token}` } : {}),
                    },
                    body: JSON.stringify({ respondent_id: finalUid, status: internalStatus }),
                    signal: AbortSignal.timeout(4000),
                });
            } catch (e) {
                // Fire-and-forget — a failed outbound S2S report must never
                // block or break the respondent's own redirect/status page.
                console.error('Outbound client S2S report failed:', e.message);
            }
        }

        if (supplier?.end_behavior === 'show_page') {
                // Never redirect this respondent's browser — fire a background
                // postback to notify the vendor instead, and fall through to
                // show the status page below. Only fires once (not on repeat
                // locked hits, and never for a ghost entry — we never want to
                // tell a vendor's system any outcome for a completion that
                // didn't actually originate from their own entry link),
                // same semantics as fraud-detection.
                if (!isAlreadyLocked && !isGhostEntry) {
                    firePostbackIfNeeded(supplier);
                }
            } else {
                // projectTitle + loiSeconds already resolved above (status-lock /
                // fraud-detection block) — reused here for URL substitution.
                // Ghost entries never redirect to the supplier's own URL either
                // — same reasoning as the postback skip above.
                const redirectUrl = isGhostEntry ? null : buildSupplierRedirect(supplier, finalUid, projectTitle, loiSeconds);
                if (redirectUrl) {
                    if (!isAlreadyLocked) fireClientS2SIfNeeded();
                    return NextResponse.redirect(redirectUrl);
                }
            }
            if (!isAlreadyLocked && !isGhostEntry) fireClientS2SIfNeeded();
        } else if (currentLogId) {
            // Direct traffic, no vendor to notify — nothing was due to be sent
            await supabaseAdmin
                .from('tracking_logs')
                .update({ postback_status: 'not_applicable', postback_at: new Date().toISOString() })
                .eq('id', currentLogId);
        }

        // ─────────────────────────────────────────────────────────────
        // ─────────────────────────────────────────────────────────────
        // EXAZON RESEARCH branded status page (matches exazonresearch.com)
        // ─────────────────────────────────────────────────────────────
        const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
        let displayProjectId = 'N/A';
        if (finalProjectId) {
            try {
                const { data: projectData } = await supabaseAdmin
                    .from('projects')
                    .select('title')
                    .eq('id', finalProjectId)
                    .single();
                displayProjectId = projectData?.title || finalProjectId;
            } catch (e) {
                displayProjectId = finalProjectId;
            }
        }
        const displayUserId = finalUid !== originalUid ? finalUid : (finalUid.length > 20 ? finalUid.substring(0, 12) + '...' : finalUid);

        const statusConfig = {
            Unmatched: {
                label: 'Response Under Review', title: 'Thank You For Your Participation',
                sub: 'Your response has been recorded and is currently being reviewed. There is nothing further you need to do.',
                color: '#c8a84b', colorDark: '#a68a3d', colorLight: '#e0cd8f', badgeText: '#e0cd8f',
                icon: '<circle cx="5" cy="4" r="2.2" stroke="#fff" stroke-width="1.2" fill="none"/><line x1="6.6" y1="5.6" x2="8" y2="7" stroke="#fff" stroke-width="1.2" stroke-linecap="round"/>',
                statusLabel: 'Under Review',
            },
            Complete: {
                label: 'Survey Completed Successfully', title: 'Thank You For Your Participation',
                sub: 'Your response has been recorded and verified. This record confirms your successful survey completion.',
                color: '#22c55e', colorDark: '#16a34a', colorLight: '#86efac', badgeText: '#4ade80',
                icon: '<polyline points="1.5,5 4,7.5 8.5,2.5" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>',
                statusLabel: 'Complete',
            },
            Terminate: {
                label: 'Survey Not Applicable', title: 'Thank You For Your Time',
                sub: 'Based on your responses, this survey is not applicable to your profile at this time.',
                color: '#c8a84b', colorDark: '#a68a3d', colorLight: '#e0cd8f', badgeText: '#e0cd8f',
                icon: '<line x1="2" y1="2" x2="8" y2="8" stroke="#fff" stroke-width="1.6" stroke-linecap="round"/><line x1="8" y1="2" x2="2" y2="8" stroke="#fff" stroke-width="1.6" stroke-linecap="round"/>',
                statusLabel: 'Terminated',
            },
            OverQuota: {
                label: 'Survey Quota Reached', title: 'Survey Quota Full',
                sub: 'Thank you for your interest — the quota for respondents matching your profile has already been reached.',
                color: '#f97316', colorDark: '#ea580c', colorLight: '#fdba74', badgeText: '#fb923c',
                icon: '<line x1="5" y1="2" x2="5" y2="6" stroke="#fff" stroke-width="1.6" stroke-linecap="round"/><circle cx="5" cy="8" r="0.8" fill="#fff"/>',
                statusLabel: 'Quota Full',
            },
            SecurityFail: {
                label: 'Quality Check Failed', title: 'Response Quality Issue',
                sub: 'Our automated quality checks flagged this response. If you believe this is an error, please contact support.',
                color: '#ef4444', colorDark: '#dc2626', colorLight: '#fca5a5', badgeText: '#f87171',
                icon: '<line x1="2" y1="2" x2="8" y2="8" stroke="#fff" stroke-width="1.6" stroke-linecap="round"/><line x1="8" y1="2" x2="2" y2="8" stroke="#fff" stroke-width="1.6" stroke-linecap="round"/>',
                statusLabel: 'Quality Fail',
            },
        };
        const cfg = statusConfig[internalStatus] || statusConfig.Terminate;

        const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${cfg.statusLabel} – Exazon Research</title>
<link rel="icon" href="/images/exazon-logo.jpg" type="image/jpeg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Cormorant+Garamond:ital,wght@0,300;1,300&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
  :root { --navy:#0a1628; --blue-brand:#1b4fd8; --blue-electric:#3b82f6; --blue-light:#60a5fa;
    --white:#ffffff; --text-muted:#94a3b8; --text-body:#cbd5e1; --card-bg:rgba(255,255,255,0.04); }
  *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
  body{font-family:"DM Sans",sans-serif;background:var(--navy);color:var(--white);min-height:100vh;display:flex;flex-direction:column;}
  nav{position:sticky;top:0;z-index:100;display:flex;align-items:center;justify-content:space-between;padding:0.9rem 2.5rem;background:rgba(10,22,40,0.9);border-bottom:1px solid rgba(59,130,246,0.12);}
  .nav-logo{display:flex;align-items:center;gap:0.7rem;text-decoration:none;}
  .nav-logo img{height:38px;width:auto;border-radius:4px;}
  .nav-logo-name{font-family:"Bebas Neue",sans-serif;font-size:1.2rem;letter-spacing:0.05em;color:var(--white);}
  .nav-links{display:flex;align-items:center;gap:2rem;list-style:none;}
  .nav-links a{color:var(--text-body);text-decoration:none;font-size:0.78rem;font-weight:500;letter-spacing:0.05em;text-transform:uppercase;}
  .nav-links a:hover{color:var(--white);}
  .nav-cta{padding:0.5rem 1.2rem;background:linear-gradient(135deg,var(--blue-brand),var(--blue-electric));color:#fff;text-decoration:none;border-radius:4px;font-size:0.75rem;font-weight:600;letter-spacing:0.06em;text-transform:uppercase;}
  main{flex:1;display:flex;align-items:center;justify-content:center;padding:48px 20px;}
  .container{width:100%;max-width:820px;}
  .badge-wrap{display:flex;justify-content:center;margin-bottom:24px;}
  .badge{display:inline-flex;align-items:center;gap:10px;border-radius:2px;padding:0.35rem 1rem;border:1px solid ${cfg.color}55;background:${cfg.color}15;}
  .badge-icon{width:18px;height:18px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,${cfg.colorDark},${cfg.color});}
  .badge-text{font-size:0.66rem;font-weight:600;letter-spacing:0.18em;text-transform:uppercase;color:${cfg.badgeText};}
  .heading{text-align:center;margin-bottom:36px;}
  .heading h1{font-family:"Bebas Neue",sans-serif;font-size:clamp(1.8rem,5vw,3rem);letter-spacing:0.03em;line-height:1;margin-bottom:10px;
    background:linear-gradient(135deg,#fff 0%,${cfg.colorLight} 60%,${cfg.color} 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;}
  .heading p{font-family:"Cormorant Garamond",serif;font-size:0.95rem;font-style:italic;color:var(--text-body);max-width:500px;margin:0 auto;}
  .card{background:var(--card-bg);border:1px solid ${cfg.color}30;border-radius:6px;overflow:hidden;}
  .card-header{display:flex;align-items:center;justify-content:space-between;padding:12px 20px;background:${cfg.color}0f;border-bottom:1px solid ${cfg.color}30;}
  .card-header-left{display:flex;align-items:center;gap:10px;}
  .card-dot{width:8px;height:8px;border-radius:50%;background:linear-gradient(135deg,${cfg.colorDark},${cfg.color});}
  .card-title{font-size:0.64rem;font-weight:700;letter-spacing:0.14em;text-transform:uppercase;color:${cfg.badgeText};}
  .card-date{font-size:0.7rem;color:var(--text-muted);}
  table{width:100%;border-collapse:collapse;font-size:0.8rem;}
  thead th{padding:10px 20px;text-align:left;font-size:0.6rem;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:var(--text-muted);border-bottom:1px solid ${cfg.color}25;white-space:nowrap;}
  tbody td{padding:14px 20px;color:var(--text-body);}
  .status-pill{display:inline-flex;align-items:center;gap:6px;border-radius:3px;padding:3px 10px;font-size:0.68rem;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;background:${cfg.color}15;border:1px solid ${cfg.color}40;color:${cfg.badgeText};}
  footer{background:#060e1a;border-top:1px solid rgba(59,130,246,0.12);padding:2rem 2.5rem 1.2rem;}
  .footer-inner{max-width:1200px;margin:0 auto;}
  .footer-top{display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:2rem;margin-bottom:1.5rem;}
  .footer-brand{display:flex;align-items:center;gap:0.7rem;text-decoration:none;}
  .footer-brand img{height:32px;width:auto;border-radius:4px;}
  .footer-brand-name{font-family:"Bebas Neue",sans-serif;font-size:1.1rem;letter-spacing:0.05em;color:var(--white);}
  .footer-tagline{font-family:"Cormorant Garamond",serif;font-style:italic;font-size:0.8rem;color:var(--text-muted);margin-top:0.4rem;}
  .social-links{display:flex;gap:0.5rem;margin-top:0.7rem;}
  .social-link{width:28px;height:28px;border-radius:50%;border:1px solid rgba(59,130,246,0.3);display:flex;align-items:center;justify-content:center;color:var(--text-muted);text-decoration:none;font-size:0.75rem;}
  .footer-links-group{display:flex;gap:2.5rem;flex-wrap:wrap;}
  .footer-col h5{font-size:0.66rem;font-weight:700;letter-spacing:0.14em;text-transform:uppercase;color:var(--blue-light);margin-bottom:0.6rem;}
  .footer-col ul{list-style:none;}
  .footer-col ul li{margin-bottom:0.4rem;}
  .footer-col ul li a{color:var(--text-muted);text-decoration:none;font-size:0.75rem;}
  .footer-col ul li a:hover{color:var(--white);}
  .footer-bottom{padding-top:1rem;border-top:1px solid rgba(255,255,255,0.06);text-align:center;}
  footer p{font-size:0.72rem;color:var(--text-muted);}
  @media(max-width:640px){nav{padding:0.7rem 1rem;}.nav-links{display:none;}thead th,tbody td{padding:8px 10px;}.footer-top{flex-direction:column;}}
</style>
</head>
<body>
<nav>
  <a href="https://exazonresearch.com" class="nav-logo">
    <img src="/images/exazon-logo.jpg" alt="Exazon Research">
    <span class="nav-logo-name">EXAZON RESEARCH</span>
  </a>
  <ul class="nav-links">
    <li><a href="https://exazonresearch.com#home">Home</a></li>
    <li><a href="https://exazonresearch.com#about">About Us</a></li>
    <li><a href="https://exazonresearch.com#services-detail">Services</a></li>
    <li><a href="https://exazonresearch.com#shield">Quality Shield</a></li>
    <li><a href="https://exazonresearch.com#contact">Contact Us</a></li>
  </ul>
  <a href="https://exazonresearch.com#contact" class="nav-cta">Speak with Us</a>
</nav>
<main>
  <div class="container">
    <div class="badge-wrap">
      <div class="badge">
        <div class="badge-icon"><svg viewBox="0 0 10 10" fill="none">${cfg.icon}</svg></div>
        <span class="badge-text">${cfg.label}</span>
      </div>
    </div>
    <div class="heading">
      <h1>${cfg.title}</h1>
      <p>${cfg.sub}</p>
    </div>
    <div class="card">
      <div class="card-header">
        <div class="card-header-left">
          <div class="card-dot"></div>
          <span class="card-title">Session Record</span>
        </div>
        <span class="card-date">${now} UTC</span>
      </div>
      <div style="overflow-x:auto;">
        <table>
          <thead>
            <tr><th>Project</th><th>Respondent ID</th><th>Status</th><th>IP Address</th><th>Timestamp</th></tr>
          </thead>
          <tbody>
            <tr>
              <td>${displayProjectId}</td>
              <td>${displayUserId}</td>
              <td><span class="status-pill">${cfg.statusLabel}</span></td>
              <td>${ip}</td>
              <td>${now}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</main>
<footer>
  <div class="footer-inner">
    <div class="footer-top">
      <div>
        <a href="https://exazonresearch.com" class="footer-brand">
          <img src="/images/exazon-logo.jpg" alt="Exazon Research">
          <span class="footer-brand-name">EXAZON RESEARCH</span>
        </a>
        <p class="footer-tagline">Insight. Innovation. Impact.</p>
        <div class="social-links">
          <a href="https://www.linkedin.com/company/exazon-research" class="social-link" target="_blank" rel="noopener" title="LinkedIn">in</a>
          <a href="https://twitter.com/exazonresearch" class="social-link" target="_blank" rel="noopener" title="X">𝕏</a>
          <a href="https://wa.me/918181838615" class="social-link" target="_blank" rel="noopener" title="WhatsApp">💬</a>
        </div>
      </div>
      <div class="footer-links-group">
        <div class="footer-col">
          <h5>Company</h5>
          <ul>
            <li><a href="https://exazonresearch.com#about">About Us</a></li>
            <li><a href="https://exazonresearch.com#shield">Quality Shield</a></li>
            <li><a href="https://exazonresearch.com#global-reach">Global Reach</a></li>
            <li><a href="https://exazonresearch.com#contact">Contact Us</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h5>Services</h5>
          <ul>
            <li><a href="https://exazonresearch.com#services-detail">Panel Management</a></li>
            <li><a href="https://exazonresearch.com#services-detail">Global Data Collection</a></li>
            <li><a href="https://exazonresearch.com#services-detail">Advanced Analytics</a></li>
            <li><a href="https://exazonresearch.com#services-detail">Strategic Consulting</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h5>Contact</h5>
          <ul>
            <li><a href="mailto:info@exazonresearch.com">info@exazonresearch.com</a></li>
            <li><a href="tel:+918181838615">+91 8181 838 615</a></li>
            <li><a href="https://exazonresearch.com">exazonresearch.com</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <p>&copy; ${new Date().getFullYear()} Exazon Research LLP. All rights reserved.</p>
    </div>
  </div>
</footer>
</body>
</html>`;

        return new NextResponse(html, { headers: { 'Content-Type': 'text/html' } });

    } catch (error) {
        console.error('Callback routing error:', error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}
