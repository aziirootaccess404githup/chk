"use server";

import { supabaseAdmin } from "@/utils/supabase";

export async function getVendorDetail(supplierId) {
    try {
        const { data: supplier, error: supErr } = await supabaseAdmin
            .from('suppliers')
            .select('*')
            .eq('id', supplierId)
            .single();
        if (supErr) throw supErr;

        // Aggregate stats across ALL projects this vendor is on
        const { data: allLogs, error: logsErr } = await supabaseAdmin
            .from('tracking_logs')
            .select('status')
            .eq('supplier_id', supplierId);
        if (logsErr) throw logsErr;

        const total = (allLogs || []).length;
        const completes = (allLogs || []).filter(l => l.status === 'Complete').length;
        const terminates = (allLogs || []).filter(l => l.status === 'Terminate').length;
        const conversion = total > 0 ? Math.round((completes / total) * 1000) / 10 : 0;

        // ─────────────────────────────────────────────────────────────
        // VENDOR SCORECARD (ported from ExaVerify's vendor_view.php) —
        // aggregates existing Fraud/Quality/Reconcile data, grouped by
        // this vendor instead of by project. No new data collection —
        // just re-running the same logic already used elsewhere,
        // scoped to supplier_id.
        // ─────────────────────────────────────────────────────────────
        const SC_SPEEDER_LIMIT = 180;
        const { data: scRows } = await supabaseAdmin
            .from('tracking_logs')
            .select('status, is_duplicate, loi_seconds, device, country, ip_address, project_id, no_entry_record')
            .eq('supplier_id', supplierId);
        const scoreableRows = (scRows || []).filter(r => !r.no_entry_record);

        let scCompletes = 0, scDupes = 0, scLoiSum = 0, scLoiN = 0, scQualitySum = 0;
        for (const r of scoreableRows) {
            if (r.status === 'Complete') scCompletes++;
            if (r.is_duplicate) scDupes++;
            if (r.loi_seconds && r.loi_seconds > 0) { scLoiSum += r.loi_seconds; scLoiN++; }
            // Same score formula used across the app (fraudDetection.js's calcScore intent)
            let score = 100;
            const loi = r.loi_seconds || 0;
            if (loi > 0 && loi < SC_SPEEDER_LIMIT) score -= 40;
            else if (loi === 0) score -= 10;
            if (r.is_duplicate) score -= 30;
            if (!r.device) score -= 5;
            if (!r.country) score -= 5;
            if (r.status === 'SecurityFail') score -= 15;
            scQualitySum += Math.max(0, Math.min(100, score));
        }
        const scTotal = scoreableRows.length;
        const scIR = scTotal > 0 ? Math.round((scCompletes / scTotal) * 1000) / 10 : 0;
        const scAvgQuality = scTotal > 0 ? Math.round((scQualitySum / scTotal) * 10) / 10 : 0;
        const scAvgLoi = scLoiN > 0 ? Math.round(scLoiSum / scLoiN) : null;

        // Fraud flag rate — duplicates + same-IP-with-different-UID hits
        const { data: ipRows } = await supabaseAdmin
            .from('tracking_logs')
            .select('ip_address, project_id, respondent_uid')
            .eq('supplier_id', supplierId)
            .not('ip_address', 'is', null);
        const ipGroups = {};
        for (const r of (ipRows || [])) {
            const key = `${r.ip_address}|${r.project_id}`;
            if (!ipGroups[key]) ipGroups[key] = new Set();
            ipGroups[key].add(r.respondent_uid);
        }
        const sameIpFlaggedIps = Object.values(ipGroups).filter(uidSet => uidSet.size > 1).length;
        const scFraudFlagged = scDupes + sameIpFlaggedIps;
        const scFraudRate = scTotal > 0 ? Math.round((scFraudFlagged / scTotal) * 1000) / 10 : 0;

        // Reconcile mismatch — reconcile_records is PROJECT-level, so on a
        // multi-vendor project this can only ESTIMATE this vendor's share,
        // proportional to their share of that project's completes.
        let scReconcileEstTotal = 0;
        try {
            const projectCompletesByVendor = {};
            for (const r of scoreableRows) {
                if (r.status === 'Complete' && r.project_id) {
                    projectCompletesByVendor[r.project_id] = (projectCompletesByVendor[r.project_id] || 0) + 1;
                }
            }
            const projIds = Object.keys(projectCompletesByVendor);
            if (projIds.length > 0) {
                const { data: recRows } = await supabaseAdmin
                    .from('reconcile_records')
                    .select('project_id, difference, our_completes')
                    .in('project_id', projIds);
                for (const rec of (recRows || [])) {
                    const vendorShare = projectCompletesByVendor[rec.project_id] || 0;
                    const projectTotal = rec.our_completes || 0;
                    if (projectTotal > 0) {
                        scReconcileEstTotal += Math.round((rec.difference || 0) * (vendorShare / projectTotal));
                    }
                }
            }
        } catch (e) {}

        const scorecard = {
            total: scTotal, completes: scCompletes, ir: scIR,
            avgQuality: scAvgQuality, avgLoi: scAvgLoi,
            fraudFlagged: scFraudFlagged, fraudRate: scFraudRate,
            reconcileEstimate: scReconcileEstTotal,
        };

        // Assigned projects
        const { data: mappings, error: mapErr } = await supabaseAdmin
            .from('project_supplier_mappings')
            .select('project_id, cpi, allocation, click_quota, allow_traffic, created_at, projects ( title, status, country )')
            .eq('supplier_id', supplierId)
            .order('created_at', { ascending: false });
        if (mapErr) throw mapErr;

        // Recent leads (last 100, across all projects)
        const { data: recentLeads, error: leadsErr } = await supabaseAdmin
            .from('tracking_logs')
            .select('respondent_uid, status, country, device, loi_seconds, ip_address, started_at, project_id, projects ( title )')
            .eq('supplier_id', supplierId)
            .order('started_at', { ascending: false })
            .limit(100);
        if (leadsErr) throw leadsErr;

        return {
            success: true,
            data: {
                supplier,
                stats: { total, completes, terminates, conversion },
                scorecard,
                assignedProjects: mappings || [],
                recentLeads: recentLeads || [],
            },
        };
    } catch (error) {
        console.error("Error fetching vendor detail:", error);
        return { success: false, error: error.message };
    }
}
