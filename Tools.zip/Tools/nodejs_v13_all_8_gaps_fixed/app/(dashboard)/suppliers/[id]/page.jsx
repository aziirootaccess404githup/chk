"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { getVendorDetail } from '@/app/actions/vendorDetail';
import { updateSupplier, generateS2SKey } from '@/app/actions/suppliers';

export default function VendorDetailPage() {
    const { id } = useParams();
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [leadSearch, setLeadSearch] = useState('');
    const [s2sGenerating, setS2sGenerating] = useState(false);
    const [baseUrl, setBaseUrl] = useState('');

    useEffect(() => {
        setBaseUrl(window.location.origin);
    }, []);

    async function fetchData() {
        setLoading(true);
        const result = await getVendorDetail(id);
        if (result.success) setData(result.data);
        setLoading(false);
    }

    useEffect(() => { fetchData(); }, [id]);

    const handleToggleStatus = async () => {
        const newStatus = data.supplier.status === 'Active' ? 'Inactive' : 'Active';
        const result = await updateSupplier(id, { status: newStatus });
        if (result.success) fetchData();
        else alert("Error: " + result.error);
    };

    if (loading) return <div className="row"><div className="col-12"><p>Loading...</p></div></div>;
    if (!data) return <div className="row"><div className="col-12"><p>Vendor not found.</p></div></div>;

    const { supplier, stats, scorecard, assignedProjects, recentLeads } = data;

    const filteredLeads = recentLeads.filter(l =>
        !leadSearch ||
        l.respondent_uid?.toLowerCase().includes(leadSearch.toLowerCase()) ||
        l.status?.toLowerCase().includes(leadSearch.toLowerCase())
    );

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item"><Link href="/suppliers">Suppliers</Link></li>
                            <li className="breadcrumb-item active">{supplier.name}</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">
                        {supplier.name}
                        <span className={`badge ml-2 ${supplier.status === 'Active' ? 'badge-success' : 'badge-secondary'}`} style={{marginLeft: '10px'}}>
                            {supplier.status}
                        </span>
                    </h4>
                </div>
            </div>

            {/* Stats */}
            <div className="col-md-3 mb-3">
                <div className="card"><div className="card-body">
                    <div className="text-muted" style={{fontSize: '11px'}}>Total Leads</div>
                    <h3>{stats.total}</h3>
                </div></div>
            </div>
            <div className="col-md-3 mb-3">
                <div className="card"><div className="card-body">
                    <div className="text-muted" style={{fontSize: '11px'}}>Completes</div>
                    <h3 style={{color: '#28a745'}}>{stats.completes}</h3>
                </div></div>
            </div>
            <div className="col-md-3 mb-3">
                <div className="card"><div className="card-body">
                    <div className="text-muted" style={{fontSize: '11px'}}>Terminates</div>
                    <h3 style={{color: '#dc3545'}}>{stats.terminates}</h3>
                </div></div>
            </div>
            <div className="col-md-3 mb-3">
                <div className="card"><div className="card-body">
                    <div className="text-muted" style={{fontSize: '11px'}}>Conversion Rate</div>
                    <h3>{stats.conversion}%</h3>
                </div></div>
            </div>

            {/* Vendor Scorecard — ported from ExaVerify's vendor_view.php */}
            <div className="col-sm-12 mb-3">
                <div className="card">
                    <div className="card-body">
                        <h5 className="card-title mb-3">📊 Vendor Scorecard</h5>
                        <p className="text-muted" style={{ fontSize: '12px' }}>
                            Fraud/Quality/Reconcile picture for this vendor, across every project they're on. Ghost entries (no matching entry-click) are excluded, same as everywhere else in the dashboard.
                        </p>
                        <div className="row">
                            <div className="col-md-2 col-6 mb-2">
                                <div className="text-muted" style={{ fontSize: '10px' }}>IR%</div>
                                <div style={{ fontSize: '18px', fontWeight: 600 }}>{scorecard.ir}%</div>
                            </div>
                            <div className="col-md-2 col-6 mb-2">
                                <div className="text-muted" style={{ fontSize: '10px' }}>Avg Quality Score</div>
                                <div style={{ fontSize: '18px', fontWeight: 600, color: scorecard.avgQuality >= 70 ? '#28a745' : scorecard.avgQuality >= 40 ? '#ffc107' : '#dc3545' }}>{scorecard.avgQuality}</div>
                            </div>
                            <div className="col-md-2 col-6 mb-2">
                                <div className="text-muted" style={{ fontSize: '10px' }}>Fraud Flag Rate</div>
                                <div style={{ fontSize: '18px', fontWeight: 600, color: scorecard.fraudRate > 15 ? '#dc3545' : '#1e293b' }}>{scorecard.fraudRate}%</div>
                            </div>
                            <div className="col-md-2 col-6 mb-2">
                                <div className="text-muted" style={{ fontSize: '10px' }}>Avg LOI</div>
                                <div style={{ fontSize: '18px', fontWeight: 600 }}>{scorecard.avgLoi !== null ? `${Math.round(scorecard.avgLoi / 60 * 10) / 10}m` : '—'}</div>
                            </div>
                            <div className="col-md-2 col-6 mb-2">
                                <div className="text-muted" style={{ fontSize: '10px' }}>Reconcile Mismatch (Est.)</div>
                                <div style={{ fontSize: '18px', fontWeight: 600, color: scorecard.reconcileEstimate > 0 ? '#dc3545' : '#1e293b' }}>{scorecard.reconcileEstimate}</div>
                            </div>
                            <div className="col-md-2 col-6 mb-2">
                                <div className="text-muted" style={{ fontSize: '10px' }}>Scoreable Responses</div>
                                <div style={{ fontSize: '18px', fontWeight: 600 }}>{scorecard.total}</div>
                            </div>
                        </div>
                        <div className="text-muted" style={{ fontSize: '10px', marginTop: '8px' }}>
                            Reconcile Mismatch is an estimate — reconcile disputes are tracked per-project, so on a multi-vendor project this is this vendor's proportional share of completes, not an exact per-vendor figure.
                        </div>
                    </div>
                </div>
            </div>

            {/* Details + Actions */}
            <div className="col-sm-12 mb-3">
                <div className="card">
                    <div className="card-body">
                        <div className="d-flex justify-content-between align-items-center mb-3">
                            <h5 className="mb-0">Vendor Details</h5>
                            <div>
                                <button className="btn btn-sm btn-warning mr-2" onClick={handleToggleStatus}>
                                    {supplier.status === 'Active' ? 'Deactivate' : 'Activate'}
                                </button>
                                <Link href="/suppliers" className="btn btn-sm btn-secondary">Back to List</Link>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-3"><strong>Contact:</strong> {supplier.contact_person || '-'}</div>
                            <div className="col-md-3"><strong>Email:</strong> {supplier.contact_email || '-'}</div>
                            <div className="col-md-3"><strong>Phone:</strong> {supplier.phone || '-'}</div>
                            <div className="col-md-3"><strong>Country:</strong> {supplier.country || '-'}</div>
                            <div className="col-md-3 mt-2"><strong>Supplier Type:</strong> {supplier.supplier_type || '-'}</div>
                            <div className="col-md-3 mt-2"><strong>End Behavior:</strong> {supplier.end_behavior || 'redirect'}</div>
                            <div className="col-md-3 mt-2"><strong>CPI Rate:</strong> {supplier.cpi_rate || '-'}</div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Server-to-Server (S2S) API Key */}
            <div className="col-sm-12 mb-3">
                <div className="card">
                    <div className="card-body">
                        <h5 className="card-title">🔐 Server-to-Server (S2S) Status API</h5>
                        <p className="text-muted" style={{ fontSize: '13px' }}>
                            If this vendor's own system reports respondent status via a server-to-server call instead of a browser redirect, generate an API key below and share it with them along with the endpoint and format.
                        </p>
                        {supplier.s2s_inbound_api_key ? (
                            <div className="mb-2">
                                <code style={{ background: '#f1f3f9', padding: '6px 10px', borderRadius: '4px', fontSize: '12px' }}>
                                    {supplier.s2s_inbound_api_key}
                                </code>
                                <button
                                    type="button"
                                    className="btn btn-sm btn-outline-secondary ml-2"
                                    onClick={() => { navigator.clipboard.writeText(supplier.s2s_inbound_api_key); alert('Copied to clipboard'); }}
                                >
                                    Copy
                                </button>
                            </div>
                        ) : (
                            <p className="text-muted" style={{ fontSize: '12px' }}>No key generated yet.</p>
                        )}
                        <button
                            type="button"
                            className="btn btn-sm btn-primary"
                            disabled={s2sGenerating}
                            onClick={async () => {
                                if (supplier.s2s_inbound_api_key && !confirm('This vendor is already using a key. Generating a new one will immediately stop the old one from working. Continue?')) return;
                                setS2sGenerating(true);
                                const res = await generateS2SKey(supplier.id);
                                if (res.success) {
                                    setData(prev => ({ ...prev, supplier: { ...prev.supplier, s2s_inbound_api_key: res.key } }));
                                } else {
                                    alert(res.error || 'Failed to generate key.');
                                }
                                setS2sGenerating(false);
                            }}
                        >
                            {s2sGenerating ? 'Generating…' : (supplier.s2s_inbound_api_key ? '🔄 Regenerate Key' : '＋ Generate Key')}
                        </button>
                        {supplier.s2s_inbound_api_key && (
                            <div className="mt-3" style={{ fontSize: '12px', color: '#64748b' }}>
                                <b>What to send this vendor:</b> POST to <code>{baseUrl}/api/s2s/status</code> with header{' '}
                                <code>Authorization: Bearer {'<key above>'}</code> and JSON body{' '}
                                <code>{'{ "respondent_id": "...", "status": "complete" }'}</code> (status: complete / terminate / overquota / security_fail).
                                The respondent_id must match one your entry-link already tracked — S2S reports a final status, it doesn't create a new entry by itself.
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Assigned Projects */}
            <div className="col-sm-12 mb-3">
                <div className="card">
                    <div className="card-body">
                        <h5 className="mb-3">Assigned Projects ({assignedProjects.length})</h5>
                        <div className="table-responsive">
                            <table className="table table-sm table-striped">
                                <thead><tr><th>Project</th><th>Status</th><th>CPI</th><th>Allocation</th><th>Click Quota</th><th>Traffic</th></tr></thead>
                                <tbody>
                                    {assignedProjects.length > 0 ? assignedProjects.map((m, i) => (
                                        <tr key={i}>
                                            <td>{m.projects?.title || '-'}</td>
                                            <td>{m.projects?.status || '-'}</td>
                                            <td>{m.cpi || '-'}</td>
                                            <td>{m.allocation}</td>
                                            <td>{m.click_quota || 'Unlimited'}</td>
                                            <td>{m.allow_traffic ? <span className="badge badge-success">On</span> : <span className="badge badge-danger">Off</span>}</td>
                                        </tr>
                                    )) : <tr><td colSpan="6" className="text-center">No projects assigned.</td></tr>}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            {/* Recent Leads */}
            <div className="col-sm-12">
                <div className="card">
                    <div className="card-body">
                        <div className="d-flex justify-content-between align-items-center mb-3 flex-wrap" style={{ gap: '8px' }}>
                            <h5 className="mb-0">Recent Leads (last 100)</h5>
                            <Link href={`/support/redirect-status?vendor=${encodeURIComponent(supplier.name)}`} className="btn btn-sm btn-outline-secondary">
                                🔍 Search All Leads For This Vendor
                            </Link>
                            <input
                                type="text"
                                className="form-control"
                                style={{maxWidth: '250px'}}
                                placeholder="Search UID or status..."
                                value={leadSearch}
                                onChange={(e) => setLeadSearch(e.target.value)}
                            />
                        </div>
                        <div className="table-responsive" style={{maxHeight: '400px', overflowY: 'auto'}}>
                            <table className="table table-sm table-striped">
                                <thead><tr><th>UID</th><th>Project</th><th>Status</th><th>Country</th><th>Device</th><th>LOI</th><th>Date</th></tr></thead>
                                <tbody>
                                    {filteredLeads.length > 0 ? filteredLeads.map((l, i) => (
                                        <tr key={i}>
                                            <td>
                                                <Link href={`/respondent?uid=${encodeURIComponent(l.respondent_uid)}&pid=${l.project_id}`}>
                                                    {l.respondent_uid}
                                                </Link>
                                            </td>
                                            <td>{l.projects?.title || '-'}</td>
                                            <td><span className={`badge ${l.status === 'Complete' ? 'badge-success' : 'badge-secondary'}`}>{l.status}</span></td>
                                            <td>{l.country || '-'}</td>
                                            <td>{l.device || '-'}</td>
                                            <td>{l.loi_seconds ? `${Math.floor(l.loi_seconds/60)}m ${l.loi_seconds%60}s` : '-'}</td>
                                            <td>{l.started_at ? new Date(l.started_at).toLocaleString() : '-'}</td>
                                        </tr>
                                    )) : <tr><td colSpan="7" className="text-center">No leads found.</td></tr>}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
