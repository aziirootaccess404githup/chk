"use client";
import React, { Suspense } from 'react';
import { useSearchParams } from 'next/navigation';

// ─────────────────────────────────────────────────────────────
// AUTO-INVOICE PREVIEW (ported from ExaVerify's
// Exazon_Invoice_Template.html, which the Billing tab's "Generate
// Invoice From Selected" button opens with client + items in the URL).
// Same idea here, as a proper Next.js page rather than a static HTML
// file — genuinely printable/exportable via the browser's own
// Print → Save as PDF, so no separate PDF-library dependency is needed.
// ─────────────────────────────────────────────────────────────
function InvoicePreviewInner() {
    const searchParams = useSearchParams();
    const client = searchParams.get('client') || 'Client';
    let items = [];
    try {
        items = JSON.parse(searchParams.get('items') || '[]');
    } catch (e) {
        items = [];
    }

    const invoiceNo = `INV-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}-${Math.floor(1000 + Math.random() * 9000)}`;
    const invoiceDate = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    const currency = items[0]?.currency || 'USD';
    const total = items.reduce((sum, it) => sum + (it.qty || 0) * (it.rate || 0), 0);

    return (
        <div style={{ maxWidth: '800px', margin: '0 auto', padding: '40px', background: '#fff', color: '#1e293b', fontFamily: 'sans-serif' }}>
            <style>{`
                @media print {
                    .no-print { display: none !important; }
                    body { background: #fff !important; }
                }
            `}</style>
            <div className="no-print" style={{ marginBottom: '20px', textAlign: 'right' }}>
                <button className="btn btn-primary" onClick={() => window.print()}>🖨 Print / Save as PDF</button>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '3px solid #1b4fd8', paddingBottom: '20px', marginBottom: '30px' }}>
                <div>
                    <h2 style={{ margin: 0, color: '#1b4fd8' }}>Exazon Research</h2>
                    <div style={{ fontSize: '12px', color: '#64748b' }}>info@exazonresearch.com</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                    <h3 style={{ margin: 0 }}>INVOICE</h3>
                    <div style={{ fontSize: '12px', color: '#64748b' }}>{invoiceNo}</div>
                    <div style={{ fontSize: '12px', color: '#64748b' }}>{invoiceDate}</div>
                </div>
            </div>

            <div style={{ marginBottom: '30px' }}>
                <div style={{ fontSize: '11px', color: '#94a3b8', textTransform: 'uppercase', fontWeight: 600 }}>Bill To</div>
                <div style={{ fontSize: '16px', fontWeight: 600 }}>{client}</div>
            </div>

            <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '30px' }}>
                <thead>
                    <tr style={{ borderBottom: '2px solid #e2e8f0', textAlign: 'left' }}>
                        <th style={{ padding: '10px 8px', fontSize: '12px' }}>Project</th>
                        <th style={{ padding: '10px 8px', fontSize: '12px', textAlign: 'right' }}>Completes</th>
                        <th style={{ padding: '10px 8px', fontSize: '12px', textAlign: 'right' }}>CPI</th>
                        <th style={{ padding: '10px 8px', fontSize: '12px', textAlign: 'right' }}>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    {items.length === 0 ? (
                        <tr><td colSpan="4" style={{ padding: '16px', textAlign: 'center', color: '#94a3b8' }}>No items selected.</td></tr>
                    ) : items.map((it, i) => (
                        <tr key={i} style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '10px 8px', fontSize: '13px' }}>{it.desc}</td>
                            <td style={{ padding: '10px 8px', fontSize: '13px', textAlign: 'right' }}>{it.qty}</td>
                            <td style={{ padding: '10px 8px', fontSize: '13px', textAlign: 'right' }}>{it.currency || currency} {Number(it.rate).toFixed(2)}</td>
                            <td style={{ padding: '10px 8px', fontSize: '13px', textAlign: 'right', fontWeight: 600 }}>{it.currency || currency} {(it.qty * it.rate).toFixed(2)}</td>
                        </tr>
                    ))}
                </tbody>
            </table>

            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <div style={{ width: '250px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderTop: '2px solid #1e293b', fontSize: '16px', fontWeight: 700 }}>
                        <span>Total Due</span>
                        <span>{currency} {total.toFixed(2)}</span>
                    </div>
                </div>
            </div>

            <div style={{ marginTop: '50px', fontSize: '11px', color: '#94a3b8', textAlign: 'center' }}>
                Thank you for your business. Please contact info@exazonresearch.com with any billing questions.
            </div>
        </div>
    );
}

export default function InvoicePreviewPage() {
    return (
        <Suspense fallback={<div>Loading...</div>}>
            <InvoicePreviewInner />
        </Suspense>
    );
}
