// ============================================================
// Status Synonym Resolution — ported from ExaVerify's
// exz_resolve_status_synonym() (inc_exz.php).
//
// Checks the project-specific list first, then falls back to the
// global defaults (project_id IS NULL) — a per-project entry always
// wins if the same word is mapped differently in both places.
// ============================================================

/**
 * Resolves an incoming raw status word (from a client's redirect,
 * anything not literally 'complete'/'terminate'/'quota-full'/
 * 'quality-check') to one of the 4 canonical status-path-segments, or
 * null if genuinely unrecognized even after synonym lookup.
 */
async function resolveStatusSynonym(supabaseAdmin, rawStatus, projectId) {
    const raw = (rawStatus || '').toLowerCase().trim();
    if (!raw) return null;

    try {
        let query = supabaseAdmin
            .from('status_synonyms')
            .select('maps_to, project_id')
            .eq('synonym', raw);

        if (projectId) {
            query = query.or(`project_id.eq.${projectId},project_id.is.null`);
        } else {
            query = query.is('project_id', null);
        }

        const { data } = await query;
        if (!data || data.length === 0) return null;

        // Per-project entry wins over a global (project_id IS NULL) one
        const projectSpecific = data.find(r => r.project_id === projectId);
        return (projectSpecific || data[0]).maps_to || null;
    } catch (e) {
        return null;
    }
}

export { resolveStatusSynonym };
