-- ============================================================
-- Ghost-Entry Detection (no_entry_record)
-- Ported from ExaVerify's exz_ensure_no_entry_column /
-- pages/track.php's Ghost-Entry Check.
--
-- Flags a tracking_logs row where the completion arrived with NO
-- matching prior entry-click (respondent never genuinely went through
-- /r/[unique_code] first — a copied/replayed completion-URL, manual
-- test, etc). The row is still saved (fully auditable, nothing
-- silently lost), but this flag lets it be excluded from stats,
-- quota-counts, and supplier postback/S2S everywhere else in the app,
-- exactly like a genuine record with no_entry_record=0 is not.
-- ============================================================

ALTER TABLE public.tracking_logs ADD COLUMN IF NOT EXISTS no_entry_record BOOLEAN DEFAULT FALSE;

CREATE INDEX IF NOT EXISTS idx_tracking_logs_no_entry_record ON public.tracking_logs(no_entry_record);
