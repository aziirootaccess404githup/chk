-- ============================================================
-- Status Synonym Mapping
-- Ported from ExaVerify's exz_status_synonyms table /
-- exz_resolve_status_synonym().
--
-- Different client platforms send different words for the same
-- outcome (e.g. "success" instead of "complete"). Rather than these
-- silently becoming "Unmatched", a synonym can be mapped to one of the
-- 4 canonical statuses — either globally (project_id IS NULL, applies
-- to every project) or per-project (overrides/adds to the global list
-- for that one project specifically).
-- ============================================================

CREATE TABLE IF NOT EXISTS public.status_synonyms (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID REFERENCES public.projects(id) ON DELETE CASCADE DEFAULT NULL,
    synonym TEXT NOT NULL,
    maps_to TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE (project_id, synonym)
);

CREATE INDEX IF NOT EXISTS idx_status_synonyms_synonym ON public.status_synonyms(synonym);

-- Seed sensible, research-backed defaults (industry-common alternate
-- words seen across Qualtrics/SightX/SnapSurveys/Dynata-style panel
-- integrations) — safe to re-run, ON CONFLICT DO NOTHING skips any
-- that already exist.
INSERT INTO public.status_synonyms (project_id, synonym, maps_to) VALUES
    (NULL, 'success', 'complete'), (NULL, 'ok', 'complete'), (NULL, 'done', 'complete'),
    (NULL, 'finish', 'complete'), (NULL, 'finished', 'complete'), (NULL, 'completed', 'complete'),
    (NULL, 'screenout', 'terminate'), (NULL, 'screen-out', 'terminate'), (NULL, 'screen_out', 'terminate'),
    (NULL, 'disqualified', 'terminate'), (NULL, 'disqualify', 'terminate'), (NULL, 'ineligible', 'terminate'),
    (NULL, 'reject', 'terminate'), (NULL, 'rejected', 'terminate'), (NULL, 'fail', 'terminate'), (NULL, 'failed', 'terminate'),
    (NULL, 'overquota', 'quota-full'), (NULL, 'over-quota', 'quota-full'), (NULL, 'over_quota', 'quota-full'), (NULL, 'full', 'quota-full'),
    (NULL, 'flagged', 'quality-check'), (NULL, 'qc', 'quality-check'), (NULL, 'quality_fail', 'quality-check')
ON CONFLICT (project_id, synonym) DO NOTHING;
