<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

if (!empty($_SESSION['admin_id'])) redirect('dashboard.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($pass, $user['password'])) {
        $_SESSION['admin_id']   = $user['id'];
        $_SESSION['admin_name'] = $user['name'];
        $_SESSION['admin_role'] = $user['role'];
        redirect('dashboard.php');
    } else {
        $error = 'Invalid email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login - <?= e(BRAND_NAME) ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
  body{ background:linear-gradient(135deg,<?= BRAND_PRIMARY_COLOR ?>,#1f2440); min-height:100vh; display:flex; align-items:center; justify-content:center; font-family:'Segoe UI',Arial,sans-serif;}
  .login-card{ background:#fff; border-radius:14px; padding:36px; width:100%; max-width:380px; box-shadow:0 10px 40px rgba(0,0,0,.25);}
</style>
</head>
<body>
  <div class="login-card">
    <h4 class="text-center mb-1 fw-bold"><?= e(BRAND_NAME) ?></h4>
    <p class="text-center text-muted small mb-4">Admin Panel Login</p>
    <?php if ($error): ?><div class="alert alert-danger py-2"><?= e($error) ?></div><?php endif; ?>
    <form method="post">
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" required autofocus placeholder="admin@exazonresearch.com">
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" required placeholder="••••••••">
      </div>
      <button class="btn btn-primary w-100" style="background:<?= BRAND_PRIMARY_COLOR ?>;border:none;">Login</button>
    </form>
    <p class="text-center text-muted small mt-3 mb-0">Default: admin@yourcompany.com / Admin@123</p>
  </div>
</body>
</html>
