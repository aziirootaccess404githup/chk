<?php
require_once __DIR__ . '/../includes/auth.php';

if (isset($_GET['delete'])) {
    $del_id = (int)$_GET['delete'];
    // ── PARENT-CHILD delete-blocking ────────────────────────────
    // Never delete a Parent project while children are still
    // attached — deleting it would orphan those children (their
    // parent_pid would point to a project that no longer exists).
    ensure_extra_columns($pdo);
    $del_row = $pdo->prepare("SELECT pid, is_parent FROM projects WHERE id=?");
    $del_row->execute([$del_id]);
    $del_row = $del_row->fetch();
    if ($del_row && !empty($del_row['is_parent'])) {
        $child_count = $pdo->prepare("SELECT COUNT(*) FROM projects WHERE parent_pid=?");
        $child_count->execute([$del_row['pid']]);
        if ($child_count->fetchColumn() > 0) {
            flash_set('This is a Parent project with children still attached. Reassign or delete the children first.');
            redirect('projects.php');
        }
    }
    $stmt = $pdo->prepare("DELETE FROM projects WHERE id = ?");
    $stmt->execute([$del_id]);
    flash_set('Project deleted.');
    redirect('projects.php');
}

ensure_extra_columns($pdo);

$projects_raw = $pdo->query("
  SELECT p.*, c.name AS client_name,
    (SELECT COUNT(*) FROM leads WHERE project_id=p.id AND status='Complete') AS completes,
    (SELECT COUNT(*) FROM leads WHERE project_id=p.id AND status='Terminates') AS terminates
  FROM projects p LEFT JOIN clients c ON c.id = p.client_id
  ORDER BY p.id DESC
")->fetchAll();

// ── PARENT-CHILD HIERARCHICAL RE-SORT ───────────────────────────
// Groups each Parent project immediately followed by its own children
// (indented + collapsible in the UI below), instead of the flat
// id-order the query above returns. A Parent's own completes/
// terminates row also gets a "+children" rollup total added on, so
// the Parent row genuinely shows the WHOLE study's numbers at a
// glance, not just its own (a Parent project itself has no
// respondent-tracking traffic — its own completes/terminates are
// normally 0, the real numbers live on its children).
$by_parent_pid = [];
foreach ($projects_raw as $pr) {
    if (!empty($pr['parent_pid'])) { $by_parent_pid[$pr['parent_pid']][] = $pr; }
}
$projects = [];
foreach ($projects_raw as $pr) {
    if (!empty($pr['parent_pid'])) continue; // inserted right after its parent below
    if (!empty($pr['is_parent']) && isset($by_parent_pid[$pr['pid']])) {
        $children = $by_parent_pid[$pr['pid']];
        $pr['rollup_completes'] = $pr['completes'] + array_sum(array_column($children, 'completes'));
        $pr['rollup_terminates'] = $pr['terminates'] + array_sum(array_column($children, 'terminates'));
        $pr['child_count'] = count($children);
    }
    $projects[] = $pr;
    if (!empty($pr['is_parent']) && isset($by_parent_pid[$pr['pid']])) {
        foreach ($by_parent_pid[$pr['pid']] as $child) {
            $child['_is_child_row'] = true;
            $child['_parent_row_id'] = $pr['id'];
            $projects[] = $child;
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card-panel mt-4">
  <div class="panel-header">
    Projects List
    <a href="project/addedit.php" class="btn btn-light btn-sm"><i class="bi bi-plus-lg"></i> ADD</a>
  </div>
  <div class="panel-body">
    <input type="text" id="projectSearchBox" class="form-control mb-3" placeholder="🔍 Search by project name, client, or PID..." onkeyup="filterProjectsTable(this.value)" style="max-width:400px">
    <div class="table-responsive">
    <table class="table table-hover align-middle" id="projectsTable">
      <thead><tr>
        <th>Sl No.</th><th>Project Name</th><th>Client</th><th>PID</th><th>Status</th>
        <th>CPI</th><th>IR</th><th>LOI</th><th>Completes</th><th>Terminates</th><th>Action</th>
      </tr></thead>
      <tbody>
      <?php foreach ($projects as $i => $p): ?>
        <?php if (!empty($p['_is_child_row'])): ?>
        <tr class="child-row" data-parent-of="<?= $p['_parent_row_id'] ?>" style="display:none">
          <td><?= $i+1 ?></td>
          <td style="padding-left:32px">↳ <?= e($p['project_name']) ?></td>
        <?php else: ?>
        <tr <?= !empty($p['is_parent']) ? 'class="parent-row" data-parent-id="'.$p['id'].'"' : '' ?>>
          <td><?= $i+1 ?></td>
          <td>
            <?php if (!empty($p['is_parent']) && !empty($p['child_count'])): ?>
            <a href="javascript:void(0)" onclick="toggleChildren(<?= $p['id'] ?>, this)" style="text-decoration:none;color:inherit"><i class="bi bi-chevron-right toggle-icon" style="display:inline-block;transition:transform 0.2s"></i></a>
            <?php endif; ?>
            <?= !empty($p['is_parent']) ? '<strong>👑 ' : '' ?><?= e($p['project_name']) ?><?= !empty($p['is_parent']) ? '</strong>' : '' ?>
            <?php if (!empty($p['is_parent']) && !empty($p['child_count'])): ?>
            <span class="badge bg-secondary"><?= $p['child_count'] ?> countries</span>
            <?php endif; ?>
          </td>
        <?php endif; ?>
          <td><?= e($p['client_name']) ?></td>
          <td><?= e($p['pid']) ?></td>
          <td><?= status_badge($p['status']) ?></td>
          <td><?= number_format($p['cpi'],2) ?></td>
          <td><?= number_format($p['ir'],2) ?></td>
          <td><?= (int)$p['loi'] ?></td>
          <td><?= !empty($p['is_parent']) && isset($p['rollup_completes']) ? (int)$p['rollup_completes'].' <span class="text-muted small">(total)</span>' : (int)$p['completes'] ?></td>
          <td><?= !empty($p['is_parent']) && isset($p['rollup_terminates']) ? (int)$p['rollup_terminates'].' <span class="text-muted small">(total)</span>' : (int)$p['terminates'] ?></td>
          <td>
            <a href="project/addedit.php?id=<?= $p['id'] ?>" class="btn btn-primary btn-sm"><i class="bi bi-pencil"></i></a>
            <a href="project/view.php?id=<?= $p['id'] ?>" class="btn btn-info btn-sm text-white"><i class="bi bi-eye"></i></a>
            <a href="projects.php?delete=<?= $p['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this project?')"><i class="bi bi-x-lg"></i></a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  </div>
</div>

<script>
// ── Parent-Child collapse/expand ──────────────────────────────
function toggleChildren(parentId, iconLink) {
  var icon = iconLink.querySelector('.toggle-icon');
  var rows = document.querySelectorAll('tr[data-parent-of="' + parentId + '"]');
  var isOpen = rows.length && rows[0].style.display !== 'none';
  rows.forEach(function(r) { r.style.display = isOpen ? 'none' : ''; });
  if (icon) icon.style.transform = isOpen ? 'rotate(0deg)' : 'rotate(90deg)';
}

// ── Lightweight search (genuinely respects the parent-child grouping
// — if a Parent's OWN text matches, its children stay visible too via
// the normal collapse-toggle, not force-expanded by search) ────────
function filterProjectsTable(query) {
  var q = query.toLowerCase().trim();
  var rows = document.querySelectorAll('#projectsTable tbody tr');
  rows.forEach(function(row) {
    if (q === '') { row.style.removeProperty('display'); return; }
    var text = row.textContent.toLowerCase();
    var isChildRow = row.classList.contains('child-row');
    var matches = text.includes(q);
    if (isChildRow) {
      // A child-row's own visibility is genuinely controlled by its
      // parent's collapse-toggle state during search too — only show
      // it if it matches AND leave the collapse-icon's own state alone.
      row.style.display = matches ? '' : 'none';
    } else {
      row.style.display = matches ? '' : 'none';
    }
  });
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

