<?php
require_once __DIR__ . '/../../includes/auth.php';
ensure_extra_columns($pdo);

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$p = [
  'client_id'=>'', 'project_name'=>'', 'cpi'=>'', 'max_completes'=>'', 'loi'=>'', 'ir'=>'',
  'live_url'=>'', 'status'=>'Pause', 'description'=>'', 'encrypt_uid'=>0, 'target_countries'=>'',
  'is_parent'=>0, 'parent_pid'=>''
];
if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id=?");
    $stmt->execute([$id]);
    $p = $stmt->fetch() ?: $p;
}

$clients = $pdo->query("SELECT id, name FROM clients WHERE status=1 ORDER BY name")->fetchAll();

// Genuinely, only ACTIVE Parent projects can be picked as a Child's
// parent — and a project currently being edited can never be its own
// parent (excluded below to avoid a genuinely broken self-reference).
$parent_options = $pdo->prepare("SELECT id, pid, project_name FROM projects WHERE is_parent=1 AND id != ? ORDER BY project_name");
$parent_options->execute([$id]);
$parent_options = $parent_options->fetchAll();

$pidError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ── PARENT-CHILD STRUCTURE ──────────────────────────────────
    // 'standalone' (default), 'parent' (rolls up its children's
    // numbers), or 'child' (belongs under a parent_pid — its own
    // numbers count toward that parent's rollup). Only 2 levels deep
    // — a child project can never itself be a parent.
    $structure = $_POST['structure'] ?? 'standalone';
    $is_parent_val = ($structure === 'parent') ? 1 : 0;
    $parent_pid_val = null;
    if ($structure === 'child') {
        $wanted_parent_id = (int)($_POST['parent_id'] ?? 0);
        if ($wanted_parent_id) {
            $pchk = $pdo->prepare("SELECT pid FROM projects WHERE id=? AND is_parent=1");
            $pchk->execute([$wanted_parent_id]);
            $parent_pid_val = $pchk->fetchColumn() ?: null;
        }
    }

    $data = [
        'client_id' => (int)$_POST['client_id'],
        'project_name' => trim($_POST['project_name']),
        'cpi' => (float)$_POST['cpi'],
        'max_completes' => (int)$_POST['max_completes'],
        'loi' => (int)$_POST['loi'],
        'ir' => (float)$_POST['ir'],
        'live_url' => trim($_POST['live_url']),
        'status' => $_POST['status'],
        'description' => $_POST['description'],
        'encrypt_uid' => isset($_POST['encrypt_uid']) ? 1 : 0,
        'target_countries' => trim($_POST['target_countries'] ?? ''),
        'is_parent' => $is_parent_val,
        'parent_pid' => $parent_pid_val,
    ];

    if ($id) {
        $sql = "UPDATE projects SET client_id=:client_id, project_name=:project_name, cpi=:cpi, max_completes=:max_completes,
                loi=:loi, ir=:ir, live_url=:live_url, status=:status, description=:description,
                encrypt_uid=:encrypt_uid, target_countries=:target_countries,
                is_parent=:is_parent, parent_pid=:parent_pid WHERE id=:id";
        $data['id'] = $id;
        $pdo->prepare($sql)->execute($data);
        flash_set('Project updated.');
        redirect('../projects.php');
    } else {
        // Custom PID if the admin typed one, else auto-generate. Uniqueness enforced
        // by the DB itself (pid column is UNIQUE) - handled gracefully below.
        $customPid = trim($_POST['pid'] ?? '');
        $data['pid'] = $customPid !== '' ? $customPid : generate_pid();

        try {
            $sql = "INSERT INTO projects (pid, client_id, project_name, cpi, max_completes, loi, ir, live_url, status, description, encrypt_uid, target_countries, is_parent, parent_pid)
                    VALUES (:pid, :client_id, :project_name, :cpi, :max_completes, :loi, :ir, :live_url, :status, :description, :encrypt_uid, :target_countries, :is_parent, :parent_pid)";
            $pdo->prepare($sql)->execute($data);
            flash_set('Project created.');
            redirect('../projects.php');
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) { // duplicate key
                $pidError = "Project ID \"{$data['pid']}\" already in use - pick a different one.";
                $p = $data; // repopulate form with what was typed
            } else {
                throw $e;
            }
        }
    }
}

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="card-panel mt-4">
  <div class="panel-header">
    Project
    <a href="../projects.php" class="btn btn-light btn-sm"><i class="bi bi-list"></i> LIST</a>
  </div>
  <div class="panel-body">
    <?php if ($pidError): ?><div class="alert alert-danger py-2"><?= e($pidError) ?></div><?php endif; ?>
    <form method="post">
      <div class="row g-3">
        <?php if ($id): ?>
        <div class="col-md-6">
          <label class="form-label">Project ID</label>
          <input type="text" class="form-control" value="<?= e($p['pid']) ?>" disabled>
          <div class="form-text">Locked after creation - existing Entry Links depend on this.</div>
        </div>
        <?php else: ?>
        <div class="col-md-6">
          <label class="form-label">Project ID <span class="text-muted small">(optional - leave blank to auto-generate)</span></label>
          <input type="text" name="pid" class="form-control" value="<?= e($p['pid'] ?? '') ?>" placeholder="e.g. match another system's own project ID">
        </div>
        <?php endif; ?>
        <div class="col-md-6">
          <label class="form-label">Client</label>
          <select name="client_id" class="form-select select2" required>
            <option value="">Select</option>
            <?php foreach ($clients as $c): ?>
              <option value="<?= $c['id'] ?>" <?= $p['client_id']==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-6">
          <label class="form-label">Project Name</label>
          <input type="text" name="project_name" class="form-control" required value="<?= e($p['project_name']) ?>" placeholder="Enter Project Name">
        </div>

        <div class="col-md-6">
          <label class="form-label">Structure <span class="text-muted small">(for multi-country studies)</span></label>
          <select name="structure" id="structureSelect" class="form-select" onchange="toggleParentField()">
            <option value="standalone" <?= (empty($p['is_parent']) && empty($p['parent_pid'])) ? 'selected' : '' ?>>Standalone</option>
            <option value="parent" <?= !empty($p['is_parent']) ? 'selected' : '' ?>>Parent (rolls up children)</option>
            <option value="child" <?= !empty($p['parent_pid']) ? 'selected' : '' ?>>Child (belongs under a Parent)</option>
          </select>
        </div>
        <div class="col-md-6" id="parentProjectField" style="<?= empty($p['parent_pid']) ? 'display:none' : '' ?>">
          <label class="form-label">Parent Project</label>
          <select name="parent_id" class="form-select">
            <option value="">Select Parent</option>
            <?php foreach ($parent_options as $po): ?>
              <option value="<?= $po['id'] ?>" <?= (!empty($p['parent_pid']) && $p['parent_pid']===$po['pid']) ? 'selected' : '' ?>><?= e($po['project_name']) ?> (<?= e($po['pid']) ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-6">
          <label class="form-label">Cost Per Completes (CPI)</label>
          <input type="number" step="0.01" name="cpi" class="form-control" value="<?= e($p['cpi']) ?>" placeholder="Enter CPI">
        </div>
        <div class="col-md-6">
          <label class="form-label">Maximum Completes (Limit)</label>
          <input type="number" name="max_completes" class="form-control" value="<?= e($p['max_completes']) ?>" placeholder="Enter Max Limit">
        </div>

        <div class="col-md-6">
          <label class="form-label">LOI (In minutes)</label>
          <input type="number" name="loi" class="form-control" value="<?= e($p['loi']) ?>" placeholder="Enter Length of interview">
        </div>
        <div class="col-md-6">
          <label class="form-label">IR</label>
          <input type="number" step="0.01" name="ir" class="form-control" value="<?= e($p['ir']) ?>" placeholder="Enter IR">
        </div>

        <div class="col-md-9">
          <label class="form-label">Live URL <span class="text-muted small">(optional: uid/pid/sid/loi/ip/date/timestamp tokens auto-replaced, any bracket style)</span></label>
          <input type="text" name="live_url" class="form-control" value="<?= e($p['live_url']) ?>" placeholder="https://survey.example.com/start?uid={{uid}}">
        </div>
        <div class="col-md-3">
          <label class="form-label">Status</label>
          <select name="status" class="form-select">
            <?php foreach (['Live','Pause','Closed'] as $s): ?>
              <option value="<?= $s ?>" <?= $p['status']==$s?'selected':'' ?>><?= $s ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-6">
          <label class="form-label">Target Countries <span class="text-muted small">(comma-separated, e.g. India, USA, UK)</span></label>
          <input type="text" name="target_countries" class="form-control" value="<?= e($p['target_countries'] ?? '') ?>" placeholder="e.g. India, United States, United Kingdom">
        </div>
        <div class="col-md-6 d-flex align-items-end">
          <div class="form-check">
            <input type="checkbox" name="encrypt_uid" id="encryptUidCheck" class="form-check-input" <?= !empty($p['encrypt_uid']) ? 'checked' : '' ?>>
            <label class="form-check-label" for="encryptUidCheck">Encrypt respondent UID for this project</label>
          </div>
        </div>

        <div class="col-12">
          <label class="form-label">Description</label>
          <textarea name="description" id="editor" class="form-control" rows="8"><?= $p['description'] ?></textarea>
        </div>
      </div>
      <button class="btn btn-primary mt-4" style="background:<?= BRAND_PRIMARY_COLOR ?>;border:none;"><?= $id ? 'Update' : 'Save' ?></button>
    </form>
  </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css">
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).ready(function(){ $('.select2').select2({ placeholder: 'Select or search client', width: '100%' }); });
function toggleParentField(){
  var struct = document.getElementById('structureSelect').value;
  document.getElementById('parentProjectField').style.display = (struct === 'child') ? 'block' : 'none';
}
</script>

<script src="https://cdn.jsdelivr.net/npm/ckeditor5@41.4.2/dist/ckeditor5.umd.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/ckeditor5@41.4.2/dist/ckeditor5.css">
<script>
CKEDITOR5.ClassicEditor.create(document.querySelector('#editor'), { licenseKey: 'GPL' })
  .catch(err => console.error(err));
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
