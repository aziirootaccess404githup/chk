<?php
$host = "localhost";
$db_name = "u994909610_Exazonresearch";
$username = "u994909610_Exazon";
$password = "Insights@818181"; // <--- Yahan apna sahi password bina kisi bracket ke likhein

try {
    $conn = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Database Connection failed: " . $e->getMessage();
}
?>