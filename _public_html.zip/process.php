<?php
// ============================================================
// EXAZON RESEARCH — TP End Redirect Handler
// File: public_html/process.php
// ============================================================

date_default_timezone_set('Asia/Kolkata');
include 'db_config.php';
include 'uid_encrypt.php';

$status        = isset($_GET['status']) ? $_GET['status'] : 'unknown';
$sid           = isset($_GET['sid'])    ? $_GET['sid']    : 'ThirdParty_Project';
$encrypted_uid = isset($_GET['uid'])    ? $_GET['uid']    : 'ThirdParty_User';
$ip            = $_SERVER['REMOTE_ADDR'];

// ── REVERSE LOOKUP ────────────────────────────────────────────
$uid = exazon_decrypt($conn, $encrypted_uid, $sid);

// Geo
$details = json_decode(@file_get_contents("http://ip-api.com/json/{$ip}?fields=country,city"));
$city    = $details->city    ?? 'N/A';
$country = $details->country ?? 'N/A';

// LOI
$loi_seconds = null;
try {
    $loi_stmt = $conn->prepare("SELECT start_time FROM survey_starts WHERE uid=? AND sid=? ORDER BY id DESC LIMIT 1");
    $loi_stmt->execute([$uid, $sid]);
    $loi_row = $loi_stmt->fetch(PDO::FETCH_ASSOC);
    if ($loi_row && $loi_row['start_time']) {
        $loi_seconds = max(0, time() - strtotime($loi_row['start_time']));
    }
} catch (Exception $e) {}

// Save to DB
try {
    $conn->prepare("INSERT INTO survey_responses
        (survey_id, respondent, status, ip, country, city, loi_seconds, source, created_at)
        VALUES (?,?,?,?,?,?,?,'thirdparty',NOW())")
    ->execute([$sid, $uid, $status, $ip, $country, $city, $loi_seconds]);
} catch(PDOException $e) {
    error_log("process.php DB Error: " . $e->getMessage());
}

// Google Sheet sync
$google_script_url = "https://script.google.com/macros/s/AKfycbzQKYLZcRBnQsgjpCYrOJ9opryxIK5TpV0gARHAq9JMy9cCtPkpV2wQq1TfmLcv7urC/exec";
$sheet_data = [
    "timestamp"      => date("Y-m-d H:i:s"),
    "project_id"     => $sid,
    "respondent_id"  => $uid,
    "encrypted_uid"  => $encrypted_uid,
    "status"         => $status,
    "ip_address"     => $ip,
    "city"           => $city,
    "country"        => $country,
    "loi_seconds"    => $loi_seconds,
];

$ch = curl_init($google_script_url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode($sheet_data),
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    CURLOPT_TIMEOUT        => 8,
]);
curl_exec($ch);
curl_close($ch);

// End redirect
$page_map = [
    'complete'  => 'complete',
    'terminate' => 'terminate',
    'quotafull' => 'quota-full',
    'qc'        => 'quality-fail',
    'quality'   => 'quality-fail',
];
$page = $page_map[$status] ?? 'terminate';
header("Location: pages/{$page}.html?status=$status&sid=$sid&uid=$uid");
exit;
