<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET');
header('Access-Control-Allow-Headers: Content-Type');

include 'db_config.php';

// Test insert directly
try {
    $panelist_id = 'EXZ-' . date('Y') . '-' . strtoupper(substr(uniqid(), -6));
    
    $stmt = $conn->prepare("INSERT INTO exazon_panelists
        (panelist_id, first_name, last_name, email, phone, dob, gender, country, state, city,
         employment, income, education, industry, interests, source, ip_address, registered_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())");

    $stmt->execute([
        $panelist_id, 'Test', 'User', 'test@test.com', '1234567890',
        '1990-01-01', 'Male', 'India', 'UP', 'Lucknow',
        'Employed Full-Time', '$60,000', "Master's Degree", 'Technology', 'Tech, Finance', 'Google Search', '127.0.0.1'
    ]);

    echo json_encode([
        'success' => true,
        'panelist_id' => $panelist_id,
        'message' => 'Test insert successful!'
    ]);

} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'code' => $e->getCode()
    ]);
}
?>
