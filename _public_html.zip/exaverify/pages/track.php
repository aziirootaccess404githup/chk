<?php
// ============================================================
// Exazon Research — pages/track.php
// Final status handler: complete / terminate / quotafull / qc
// Rebuilt on the proven PanelEngine architecture:
//   - SID-authority resolution (URL sid is only a hint)
//   - Status-lock (first-write-wins)
//   - Vendor postback (show_page / redirect modes)
//   - Configurable settings-driven alerts
// ============================================================
require_once __DIR__ . '/../inc_exz.php';

$db = exz_db();

// ── PARAMETERS ──────────────────────────────────────────────
$status  = trim($_GET['status'] ?? 'unknown');
$url_sid = trim($_GET['sid']    ?? 'Unknown_Project');
// Flexible param-name fallback — some client platforms send the identifier
// back under a different name.
$uid = trim($_GET['uid'] ?? $_GET['rid'] ?? $_GET['toid'] ?? $_GET['identifier'] ?? $_GET['tid'] ?? $_GET['pid'] ?? 'Unknown_User');
$sig = trim($_GET['sig'] ?? '');
$src_param = trim($_GET['src'] ?? '');
$ip  = exz_get_ip();

// ── UNMATCHED-STATUS SAFETY NET ──────────────────────────────
// If the client's status param is missing entirely, or doesn't match one
// of our 5 known statuses, we do NOT want it silently ending up looking
// like — or worse, being COUNTED as — a genuine complete. That's exactly
// the kind of mismatch that causes a payment dispute later (respondent/
// vendor sees a "Complete" page, but internal reports never counted it
// because the real status column held some raw, unrecognized value).
// Recognized statuses are locked in explicitly; anything else becomes a
// distinct 'unmatched' status — NOT status-locked, so a correct status
// arriving later for the same respondent can still update it — shown a
// neutral "Under Review" page, and no vendor postback fires for it.
$known_statuses = ['complete', 'terminate', 'qc', 'quality', 'quotafull'];
if (!in_array($status, $known_statuses)) {
    // Not an exact match — before giving up and calling it unmatched, check
    // the Status Synonym Mapping (global defaults + this project's own
    // overrides) for a word this client's platform commonly sends instead
    // (e.g. "success" for complete, "disqualified" for terminate).
    exz_ensure_status_synonyms_table($db);
    exz_seed_default_status_synonyms($db);
    $resolved = exz_resolve_status_synonym($db, $status, $url_sid);
    if ($resolved !== null) $status = $resolved;
}
$is_unmatched = !in_array($status, $known_statuses);
if ($is_unmatched) {
    $status = 'unmatched';
}

$sid = $url_sid; // may be corrected below once we find the real lead

// ── SID-AUTHORITY RESOLUTION + STATUS-LOCK ───────────────────
// Multi-tier lookup: the URL's sid is only a hint. Our own stored
// record (from vendor.php/entry.php) is always authoritative.
$existing = null;
try {
    $lc = $db->prepare("SELECT * FROM survey_responses WHERE respondent=? AND survey_id=? ORDER BY id DESC LIMIT 1");
    $lc->execute([$uid, $sid]);
    $existing = $lc->fetch();

    if (!$existing) {
        // Fallback 1: same UID, ANY project in survey_responses — covers a
        // REPEAT hit where the client sends a wrong/mismatched sid.
        $lc2 = $db->prepare("SELECT * FROM survey_responses WHERE respondent=? ORDER BY id DESC LIMIT 1");
        $lc2->execute([$uid]);
        $existing = $lc2->fetch();
        if ($existing) $sid = $existing['survey_id']; // our stored sid wins
    }

    if (!$existing) {
        // Fallback 2: this may be the respondent's FIRST completion ever,
        // meaning survey_responses has no record yet at all — but
        // survey_starts (written by vendor.php at entry time) already has
        // the correct sid on file. This is the common case a client sending
        // a wrong/placeholder sid on their very first completion hits.
        $ss = $db->prepare("SELECT sid FROM survey_starts WHERE uid=? ORDER BY id DESC LIMIT 1");
        $ss->execute([$uid]);
        $realSid = $ss->fetchColumn();
        if ($realSid) $sid = $realSid; // our stored sid wins here too
    }
} catch (Exception $e) { error_log("track.php lookup error: ".$e->getMessage()); }

$is_repeat_locked = false;
if ($existing && !empty($existing['status_locked'])) {
    // Status already locked — ignore whatever the URL says, show the
    // respondent their original, real result.
    $status = $existing['status'];
    $is_repeat_locked = true;
}

// ── DUPLICATE DETECTION ON ALREADY-LOCKED LEADS ──────────────────
// A repeat hit here is genuinely useful fraud signal (a vendor/bot
// resubmitting, or a respondent trying again) — it must NOT be silently
// invisible to Fraud Detection just because the lead is locked and no
// further write happens to it. Flag is_duplicate=1 on the existing row
// and fire the Telegram alert, but only the FIRST time a repeat is seen
// for this lead (checked via is_duplicate already being 0) — otherwise a
// client/vendor repeatedly hitting the same completion URL would spam
// one alert per hit instead of once per lead.
if ($is_repeat_locked && $existing && empty($existing['is_duplicate'])) {
    try {
        $db->prepare("UPDATE survey_responses SET is_duplicate=1 WHERE id=?")->execute([$existing['id']]);
        exz_send_telegram($db, "⚠️ Duplicate UID! (repeat hit on an already-locked lead)\nProject: $sid\nUID: $uid\nStatus: $status | IP: $ip\nThe same respondent attempted again after their result was already locked in!");
    } catch (Exception $e) {}
}

// ── SHA-256 SIGNATURE (informational — logs mismatches, doesn't block) ──
if ($sig !== '') {
    define('EXAZON_SECRET', 'Exazon@Secret2026');
    $expected = hash_hmac('sha256', $status.'|'.$sid.'|'.$uid, EXAZON_SECRET);
    if (!hash_equals($expected, $sig)) {
        error_log("track.php: SHA-256 signature mismatch — sid=$sid uid=$uid ip=$ip");
    }
}

// ── GHOST-ENTRY CHECK: did this UID ever actually enter via our own
// entry link (vendor.php)? If survey_starts has NO record for this UID
// at all, this completion arrived out of nowhere — someone hit track.php
// directly (or guessed/replayed a URL) without ever clicking a real entry
// link. We still SAVE it (so nothing is silently lost and it stays fully
// auditable — IP, device, timestamp all recorded), but we flag it so it
// does NOT get silently counted as a normal, trustworthy complete.
$no_entry_record = 0;
try {
    $anyStart = $db->prepare("SELECT COUNT(*) FROM survey_starts WHERE uid=?");
    $anyStart->execute([$uid]);
    if ($anyStart->fetchColumn() == 0) $no_entry_record = 1;
} catch (Exception $e) { error_log("track.php ghost-entry check error: ".$e->getMessage()); }

// ── PROJECT + CLIENT (DB-driven, not hardcoded) ──────────────
$proj = null;
$client_name = 'Unknown Client';
try {
    $pp = $db->prepare("SELECT ps.*, c.client_name AS cname FROM project_settings ps
        LEFT JOIN exz_clients c ON c.id = ps.client_id WHERE ps.survey_id=? LIMIT 1");
    $pp->execute([$sid]);
    $proj = $pp->fetch();
    if ($proj && !empty($proj['cname'])) $client_name = $proj['cname'];
    elseif ($proj && !empty($proj['project_name'])) $client_name = $proj['project_name'];
} catch (Exception $e) {}

// ── GEO / DEVICE / BROWSER ──────────────────────────────────────
exz_ensure_browser_column($db);
exz_ensure_no_entry_column($db);
$geo     = exz_geo($ip);
$device  = exz_device();
$browser = exz_browser();

// ── LOI CALCULATION (self-measured — priority 1; client &loi= — fallback) ──
// NOTE: computed via SQL TIMESTAMPDIFF (not PHP DateTime math) deliberately —
// survey_starts.start_time is written by MySQL's own CURRENT_TIMESTAMP, which
// is in the DB server's timezone (UTC here), while this app's PHP timezone is
// set to Asia/Kolkata (see inc_exz.php). Diffing via `new DateTime($dbString)`
// would silently misinterpret that UTC string as IST, adding a ~5.5-hour
// offset to every LOI. TIMESTAMPDIFF keeps both sides of the diff on the
// DB's own clock, sidestepping the PHP/MySQL timezone mismatch entirely.
$loi_seconds = null;
$vendor_id   = null;
try {
    $st = $db->prepare("SELECT TIMESTAMPDIFF(SECOND, start_time, NOW()) AS loi_calc, vendor_id FROM survey_starts WHERE uid=? AND sid=? ORDER BY id DESC LIMIT 1");
    $st->execute([$uid, $sid]);
    $srow = $st->fetch();
    if ($srow) {
        if ($srow['loi_calc'] !== null) {
            $loi_seconds = max(0, (int)$srow['loi_calc']);
        }
        $vendor_id = $srow['vendor_id'] ?: null;
    }
} catch (Exception $e) { error_log("track.php LOI calc error: ".$e->getMessage()); }
if ($loi_seconds === null && isset($_GET['loi']) && is_numeric($_GET['loi'])) {
    $loi_seconds = max(0, (int)$_GET['loi']);
}
// If this is a repeat hit on an already-locked lead, prefer its saved vendor_id/loi
if ($is_repeat_locked && $existing) {
    $vendor_id   = $existing['vendor_id'] ?: $vendor_id;
    $loi_seconds = $existing['loi_seconds'] ?? $loi_seconds;
}

// ── DUPLICATE CHECK ────────────────────────────────────────────
$is_duplicate = 0;
if (!$is_repeat_locked) {
    try {
        $dup = $db->prepare("SELECT COUNT(*) FROM survey_responses WHERE respondent=? AND survey_id=?");
        $dup->execute([$uid, $sid]);
        if ($dup->fetchColumn() > 0) $is_duplicate = 1;
    } catch (Exception $e) {}
}

// ── SOURCE ─────────────────────────────────────────────────────
$source = $src_param ?: 'direct';
if (!$src_param) {
    try {
        $ss = $db->prepare("SELECT source FROM survey_starts WHERE uid=? AND sid=? ORDER BY id DESC LIMIT 1");
        $ss->execute([$uid, $sid]);
        $srow2 = $ss->fetchColumn();
        if ($srow2) $source = $srow2;
    } catch (Exception $e) {}
}

// ── SAVE / UPDATE (status-lock: only write if not already locked) ────────
$lock_value = $is_unmatched ? 0 : 1; // unmatched stays UNLOCKED, so a real status arriving later can still overwrite it
if (!$is_repeat_locked) {
    try {
        if ($existing) {
            $db->prepare("UPDATE survey_responses SET status=?,ip=?,country=?,city=?,device=?,browser=?,source=?,client_name=?,loi_seconds=?,is_duplicate=?,vendor_id=?,status_locked=?,no_entry_record=? WHERE id=?")
               ->execute([$status,$ip,$geo['country'],$geo['city'],$device,$browser,$source,$client_name,$loi_seconds,$is_duplicate,$vendor_id,$lock_value,$no_entry_record,$existing['id']]);
        } else {
            $db->prepare("INSERT INTO survey_responses
                (survey_id,respondent,status,ip,country,city,device,browser,source,client_name,loi_seconds,is_duplicate,vendor_id,status_locked,no_entry_record,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())")
               ->execute([$sid,$uid,$status,$ip,$geo['country'],$geo['city'],$device,$browser,$source,$client_name,$loi_seconds,$is_duplicate,$vendor_id,$lock_value,$no_entry_record]);
        }
        if ($status === 'complete' && !$no_entry_record) exz_check_quota($db, $sid);
        // --- ExaConnect panelist reward hook -------------------------------
// If this completed entry's UID is a panelist_id from ExaConnect (they
// all start with "EXZ-"), notify ExaConnect so it can credit points.
// This does not affect normal third-party/vendor tracking in any way —
// it only fires for panelist traffic, and failures here are silent so
// they never block or break the existing completion flow.
//
// IMPORTANT: !$no_entry_record is required here. Without it, someone
// who simply knows their OWN panelist_id (which is shown to them
// directly after registering — it's not a secret) could repeatedly
// hit ExaVerify's completion URL directly, with no genuine survey
// ever taken, and farm free points every time. no_entry_record is
// exactly the flag ExaVerify already sets for this scenario — a
// completion with no matching entry-click on record — so requiring
// it to be false here closes this off using logic that already exists.
if ($status === 'complete' && !$no_entry_record && strpos($uid, 'EXZ-') === 0) {
    $ch = curl_init('https://exaconnect.exazonresearch.com/webhook_credit_points.php');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 5, // don't let a slow webhook delay the respondent's redirect
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode([
            'key' => '417a0c2b8de3c1542885f19302942582565c3d8b66ac3ca2',
            'panelist_id' => $uid,
            'project_ref' => $sid, // ExaConnect looks up this project's own points_value instead of trusting a hardcoded number
            'reason' => "Survey complete: {$sid}",
        ]),
    ]);
    $webhook_result = curl_exec($ch);
    $webhook_http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    // Genuinely logged (not silent) — a failed reward-credit is real money
    // a panelist didn't receive, and should be visible somewhere rather
    // than vanishing with no trace. Doesn't block or alter the respondent's
    // own redirect either way.
    if ($webhook_http_code !== 200) {
        error_log("ExaConnect reward-hook failed: HTTP $webhook_http_code, panelist=$uid, project=$sid, response=" . substr((string)$webhook_result, 0, 300));
    }
}
// ---------------------------------------------------------------------
           } catch (Exception $e) { error_log("track.php save error: ".$e->getMessage()); }
}

// ── DUPLICATE ALERT (fresh writes only) ───────────────────────
if (!$is_repeat_locked && $is_duplicate === 1) {
    exz_send_telegram($db, "⚠️ Duplicate UID!\nProject: $sid\nUID: $uid\nStatus: $status | IP: $ip\nThe same respondent attempted again!");
}

// ── GHOST-ENTRY ALERT (fresh writes only) ───────────────────────
if (!$is_repeat_locked && $no_entry_record === 1) {
    exz_send_telegram($db, "🚨 GHOST ENTRY DETECTED!\nProject: $sid\nUID: $uid\nStatus: $status | IP: $ip\nThis UID never entered via the real entry link — check who hit this URL directly.");
}

// ── VENDOR REDIRECT-MODE CHECK ─────────────────────────────────
// Skipped entirely for unmatched AND for ghost entries (no real entry-link
// record) — we never want to send a vendor a postback, in any mode, for a
// completion that didn't actually originate from their own entry link.
$vendor_redirect = ($is_unmatched || $no_entry_record) ? null : exz_build_vendor_redirect($db, $vendor_id, $status, $uid, $sid, $loi_seconds);
if ($vendor_redirect) {
    header("Location: $vendor_redirect");
    exit();
}

// ── REDIRECT TO OUR OWN STATUS PAGE (send this first) ─────────
$pages = ['complete'=>'complete','terminate'=>'terminate','qc'=>'quality-fail','quality'=>'quality-fail','quotafull'=>'quota-full','unmatched'=>'unmatched'];
$page = $pages[$status] ?? 'unmatched';
// The status page's JS looks for a &disp= param to show the respondent's
// own ORIGINAL UID (not our internal encrypted token) — without this
// lookup it silently fell back to showing the encrypted uid instead, which
// isn't an ID the respondent (or the vendor checking their own records)
// would ever recognize as theirs.
$disp_uid = $uid;
try {
    $um = $db->prepare("SELECT original_uid FROM exz_uid_mapping WHERE encrypted_uid=? AND survey_id=? LIMIT 1");
    $um->execute([$uid, $sid]);
    $orig = $um->fetchColumn();
    if ($orig) $disp_uid = $orig;
} catch (Exception $e) {}
header("Location: /pages/{$page}.html?status=$status&sid=$sid&uid=$uid&disp=".urlencode($disp_uid));

// ── DEFERRED: vendor postback + speeder alert (after response sent) ──
if (!$is_repeat_locked) {
    // Unmatched, or a ghost entry (no real entry-link record), never fires
    // a vendor postback — pass vendor_id=null so exz_flush_and_defer's
    // postback branch is skipped, but the response is still correctly
    // flushed/finished either way.
    exz_flush_and_defer($db, ($is_unmatched || $no_entry_record) ? null : $vendor_id, $status, $uid, $sid, $proj, $loi_seconds);

    // Google Sheet sync (best-effort, runs after respondent's redirect)
    try {
        $ch = curl_init("https://script.google.com/macros/s/AKfycby93oXzhv0dB0evWH3Ni_KYUgqDXmlCDLyTUFSvTn8zpwe3eWiHth8aLaYJtxuX6s2-/exec");
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode([
                "timestamp"=>date("d/m/Y H:i:s"),"project_id"=>$sid,"respondent_id"=>$uid,"status"=>$status,
                "ip_address"=>$ip,"city"=>$geo['city'],"country"=>$geo['country'],"device"=>$device,
                "source"=>$source,"client"=>$client_name,
                "loi"=>$loi_seconds!==null?gmdate("i:s",$loi_seconds):'N/A',"is_duplicate"=>$is_duplicate?"YES":"NO",
            ]),
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'], CURLOPT_TIMEOUT => 8,
        ]);
        curl_exec($ch); curl_close($ch);
    } catch (Exception $e) {}
}
exit();
