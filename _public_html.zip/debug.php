<?php
header('Content-Type: application/json');
include 'db_config.php';

// Check if tables exist and show data
try {
    $tables = $conn->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $panelists = [];
    $clients = [];
    
    if (in_array('exazon_panelists', $tables)) {
        $panelists = $conn->query("SELECT panelist_id, first_name, email, status, registered_at FROM exazon_panelists ORDER BY id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
    }
    if (in_array('exazon_clients', $tables)) {
        $clients = $conn->query("SELECT ref_id, first_name, email, status, submitted_at FROM exazon_clients ORDER BY id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
    }
    
    echo json_encode([
        'tables' => $tables,
        'panelists' => $panelists,
        'clients' => $clients,
        'php_version' => PHP_VERSION
    ], JSON_PRETTY_PRINT);
} catch(Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
