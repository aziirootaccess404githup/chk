<?php
// ============================================================
// EXAZON RESEARCH — Respondent Portal Login API
// File: public_html/portal_login.php
// ============================================================
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

include 'db_config.php';

$action = $_GET['action'] ?? 'lookup';

if ($action === 'lookup') {
    $pid   = trim($_GET['id'] ?? '');
    $email = trim($_GET['email'] ?? '');

    if (!$pid || !$email) {
        echo json_encode(['success' => false, 'error' => 'Panelist ID and email are required']);
        exit;
    }

    try {
        $stmt = $conn->prepare("SELECT * FROM exazon_panelists WHERE panelist_id = ? AND email = ? LIMIT 1");
        $stmt->execute([$pid, $email]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            echo json_encode([
                'success'     => true,
                'panelist_id' => $row['panelist_id'],
                'name'        => $row['first_name'] . ' ' . $row['last_name'],
                'first_name'  => $row['first_name'],
                'email'       => $row['email'],
                'country'     => $row['country'],
                'city'        => $row['city'],
                'employment'  => $row['employment'],
                'industry'    => $row['industry'],
                'interests'   => $row['interests'],
                'status'      => $row['status'],
                'registered'  => $row['registered_at']
            ]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Invalid Panelist ID or email. Please check and try again.']);
        }
    } catch (PDOException $e) {
        error_log("portal_login.php: " . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Database error. Please try again.']);
    }
}
?>
