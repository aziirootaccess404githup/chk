<?php
// ============================================================
// EXAZON RESEARCH — Panel Registration Handler
// File: public_html/panel_submit.php
// ============================================================
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

include 'db_config.php';

// Get POST data
$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!$data) $data = $_POST;

// Debug log
error_log("panel_submit.php called. Method: " . $_SERVER['REQUEST_METHOD'] . " Raw: " . $raw);

// Validate required fields
if (empty($data['first_name']) || empty($data['email']) || empty($data['phone'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Required fields missing',
        'received' => $data
    ]);
    exit;
}

// Generate Panelist ID
$panelist_id = 'EXZ-' . date('Y') . '-' . strtoupper(substr(uniqid(), -6));

// Sanitize helper
function clean($v) { return htmlspecialchars(strip_tags(trim($v ?? ''))); }

$first_name  = clean($data['first_name']);
$last_name   = clean($data['last_name']);
$email       = filter_var(trim($data['email'] ?? ''), FILTER_SANITIZE_EMAIL);
$phone       = clean($data['phone']);
$dob         = !empty($data['dob']) ? $data['dob'] : null;
$gender      = clean($data['gender']);
$country     = clean($data['country']);
$state       = clean($data['state']);
$city        = clean($data['city']);
$employment  = clean($data['employment']);
$income      = clean($data['income']);
$education   = clean($data['education']);
$industry    = clean($data['industry']);
$interests   = clean($data['interests']);
$source      = clean($data['source']);
$ip          = $_SERVER['REMOTE_ADDR'];

try {
    // Check duplicate email
    $chk = $conn->prepare("SELECT id FROM exazon_panelists WHERE email = ? LIMIT 1");
    $chk->execute([$email]);
    if ($chk->fetch()) {
        echo json_encode(['success' => false, 'message' => 'This email is already registered. Please use a different email.']);
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO exazon_panelists
        (panelist_id, first_name, last_name, email, phone, dob, gender, country, state, city,
         employment, income, education, industry, interests, source, ip_address, registered_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())");

    $stmt->execute([
        $panelist_id, $first_name, $last_name, $email, $phone,
        $dob, $gender, $country, $state, $city,
        $employment, $income, $education, $industry, $interests, $source, $ip
    ]);

    echo json_encode([
        'success'     => true,
        'panelist_id' => $panelist_id,
        'message'     => 'Registration successful'
    ]);

} catch(PDOException $e) {
    error_log("panel_submit.php DB Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>