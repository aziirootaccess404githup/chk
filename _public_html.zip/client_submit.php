<?php
// ============================================================
// EXAZON RESEARCH — Client Enquiry Handler
// File: public_html/client_submit.php
// ============================================================
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

include 'db_config.php';

$data = json_decode(file_get_contents('php://input'), true);
if (!$data) $data = $_POST;

$ref_id = 'EXZ-REQ-' . strtoupper(substr(uniqid(), -6));

function clean($v) { return htmlspecialchars(strip_tags(trim($v ?? ''))); }

$first_name      = clean($data['first_name']);
$last_name       = clean($data['last_name']);
$email           = filter_var($data['email'] ?? '', FILTER_SANITIZE_EMAIL);
$phone           = clean($data['phone']);
$company         = clean($data['company']);
$designation     = clean($data['designation']);
$website         = clean($data['website']);
$country         = clean($data['country']);
$project_title   = clean($data['project_title']);
$objective       = clean($data['objective']);
$geography       = clean($data['geography']);
$target_audience = clean($data['target_audience']);
$sample_size     = clean($data['sample_size']);
$industry        = clean($data['industry']);
$methods         = clean($data['methods']);
$audience_types  = clean($data['audience_types']);
$deliverable     = clean($data['deliverable']);
$language        = clean($data['language']);
$special_req     = clean($data['special_req']);
$budget          = intval($data['budget'] ?? 0);
$timeline        = clean($data['timeline']);
$start_date      = $data['start_date'] ?? null;
$source          = clean($data['source']);
$notes           = clean($data['notes']);
$project_brief   = clean($data['project_brief']);
$ip              = $_SERVER['REMOTE_ADDR'];

if (!$first_name || !$last_name || !$email || !$company) {
    echo json_encode(['success' => false, 'message' => 'Required fields missing']);
    exit;
}

try {
    $stmt = $conn->prepare("INSERT INTO exazon_clients
        (ref_id, first_name, last_name, email, phone, company, designation, website, country,
         project_title, objective, geography, target_audience, sample_size, industry,
         methods, audience_types, deliverable, language, special_req, budget, timeline,
         start_date, source, notes, project_brief, ip_address, submitted_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())");

    $stmt->execute([
        $ref_id, $first_name, $last_name, $email, $phone, $company, $designation, $website, $country,
        $project_title, $objective, $geography, $target_audience, $sample_size, $industry,
        $methods, $audience_types, $deliverable, $language, $special_req, $budget, $timeline,
        $start_date ?: null, $source, $notes, $project_brief, $ip
    ]);

    echo json_encode([
        'success' => true,
        'ref_id'  => $ref_id,
        'message' => 'Enquiry submitted successfully'
    ]);

} catch (PDOException $e) {
    error_log("client_submit.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error. Please try again.']);
}
?>
