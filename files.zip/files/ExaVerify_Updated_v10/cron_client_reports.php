<?php
// ============================================================
// Exazon Research — cron_client_reports.php
// Run this on a schedule (e.g. daily via Hostinger cron) — it
// checks every project with auto_report_enabled=1, sends a
// progress-report email to the client if it's due (per that
// project's Daily/Weekly frequency), and updates last_sent so
// it never double-sends. Toggle any project's schedule off
// anytime from Project View — this script simply respects that
// flag on every run, no separate "stop" step needed.
// ============================================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'u994909610_Exaverify');
define('DB_USER', 'u994909610_Exaverify');
define('DB_PASS', 'Exaverify@8181');

// Only run via CLI (cron) or with a secret key in the URL — prevents
// randoms on the internet from triggering this by just visiting the file.
define('CRON_SECRET', 'exz_cron_9f1c7a3e'); // change this if you like
$is_cli = (php_sapi_name() === 'cli');
if (!$is_cli && ($_GET['key'] ?? '') !== CRON_SECRET) {
    http_response_code(403);
    die('Forbidden.');
}

try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (Exception $e) {
    die('DB connection failed: ' . $e->getMessage());
}

function exz_get_setting(PDO $pdo, string $key, string $default = ''): string {
    try {
        $s = $pdo->prepare("SELECT setting_value FROM exz_settings WHERE setting_key=?");
        $s->execute([$key]);
        $v = $s->fetchColumn();
        return $v !== false && $v !== '' ? $v : $default;
    } catch (Exception $e) { return $default; }
}

$host = 'exaverify.exazonresearch.com'; // used to build the report link in the email

$projects = $pdo->query("SELECT ps.*, c.client_name AS cname FROM project_settings ps
    LEFT JOIN exz_clients c ON c.id = ps.client_id
    WHERE ps.auto_report_enabled = 1")->fetchAll();

$sent_count = 0;
$skipped_count = 0;

foreach ($projects as $proj) {
    $sid = $proj['survey_id'];
    $freq = $proj['auto_report_freq'] ?: 'weekly';
    $email = trim($proj['auto_report_email'] ?? '');
    $last_sent = $proj['auto_report_last_sent'];

    if (!$email) { $skipped_count++; continue; } // nothing to send to

    $due = false;
    if (!$last_sent) {
        $due = true; // never sent before
    } elseif ($freq === 'daily') {
        $due = (date('Y-m-d', strtotime($last_sent . ' UTC')) !== date('Y-m-d'));
    } else { // weekly
        $due = (strtotime($last_sent . ' UTC') <= strtotime('-7 days'));
    }

    if (!$due) { $skipped_count++; continue; }

    // Completes count
    $cq = $pdo->prepare("SELECT COUNT(*) FROM survey_responses WHERE survey_id=? AND status='complete'");
    $cq->execute([$sid]);
    $completes = (int)$cq->fetchColumn();
    $target = (int)($proj['target'] ?? 0);

    // Existing (non-revoked) share link, if any
    $sl = $pdo->prepare("SELECT token FROM exz_share_links WHERE survey_id=? AND is_revoked=0 ORDER BY created_at DESC LIMIT 1");
    $sl->execute([$sid]);
    $token = $sl->fetchColumn();
    $report_url = $token ? "https://$host/report.php?token=$token" : '';

    $client_name = $proj['cname'] ?: 'there';
    $project_name = $proj['project_name'] ?: $sid;
    $pct = $target > 0 ? round($completes / $target * 100) : null;
    $progress_line = $target > 0
        ? "Progress: $completes / $target completes ($pct%)"
        : "Completes so far: $completes";

    $subject = "Project Update — $project_name (" . ucfirst($freq) . " report)";
    $body = "Hi $client_name,\n\n"
          . "Here's your $freq automated update on $project_name.\n\n"
          . "$progress_line\n\n"
          . ($report_url ? "View live progress anytime here (no login required):\n$report_url\n\n" : "")
          . "Please let us know if you have any questions.\n\n"
          . "Best regards,\nExazon Research";

    $alert_email = exz_get_setting($pdo, 'alert_email', 'info@exazonresearch.com');
    $sent = @mail(
        $email,
        $subject,
        $body,
        "From: Exazon Research <$alert_email>\r\nContent-Type: text/plain; charset=UTF-8"
    );

    if ($sent) {
        $pdo->prepare("UPDATE project_settings SET auto_report_last_sent=NOW() WHERE survey_id=?")->execute([$sid]);
        try {
            $pdo->prepare("INSERT INTO exz_audit_log (action,detail) VALUES ('auto_report_sent',?)")
                ->execute(["SID: $sid -> $email ($freq)"]);
        } catch (Exception $e) {}
        $sent_count++;
        echo "[SENT] $sid -> $email\n";
    } else {
        echo "[FAILED] $sid -> $email (mail() returned false)\n";
    }
}

echo "\nDone. Sent: $sent_count, Skipped (not due / no email): $skipped_count\n";
