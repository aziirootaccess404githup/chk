<?php
/* Common helper functions */

function e($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect($path) {
    header("Location: $path");
    exit;
}

function generate_uid($prefix = '') {
    return $prefix . strtoupper(bin2hex(random_bytes(8)));
}

function generate_pid($countryCode = 'IN') {
    // e.g. PHUB026172026  -> PHUB + random 6 digits + year
    return 'PHUB' . rand(100000, 999999);
}

function flash_set($msg, $type = 'success') {
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

function flash_get() {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

function status_badge($status) {
    $map = [
        'Live'       => 'success',
        'Pause'      => 'warning',
        'Closed'     => 'secondary',
        'Pending'    => 'warning',
        'Complete'   => 'success',
        'Terminates' => 'danger',
        'Screenout'  => 'dark',
        'Quota Full' => 'secondary',
    ];
    $cls = $map[$status] ?? 'secondary';
    return "<span class=\"badge bg-$cls\">" . e($status) . "</span>";
}

/**
 * Replace placeholder tokens inside ANY redirect URL - vendor's or client's,
 * doesn't matter, both use this same function so behavior is always identical.
 *
 * Supports every bracket style seen across the industry (case-insensitive,
 * whitespace-tolerant inside the brackets):
 *   {{token}}     double-curly     - e.g. the original VMH-style panel
 *   [TOKEN]       square-bracket   - e.g. Azilytics' track.php links
 *   [#token#]     hash-in-bracket  - e.g. OpinionSpark-style
 *   {token}       single-curly     - some older/legacy panel systems
 *   %TOKEN%       percent-wrapped  - some legacy/Windows-influenced systems
 *   <token>       angle-bracket    - rare, some XML-influenced systems
 *   $token$       dollar-wrapped   - rare, seen on a handful of custom platforms
 *
 * Anything not matching a known token (like a fixed "sid=YOUR_SID" the admin
 * typed in literally) is left completely untouched - this function never
 * guesses or invents a value for a token it wasn't given.
 *
 * $tokens is an associative array, e.g. build_token_set($uid, $pid, ['loi'=>12])
 */
function build_vendor_url($template, $tokens) {
    if (!$template) return null;
    $url = $template;

    // Order matters: double-curly MUST be processed before single-curly,
    // otherwise the single-curly pattern would wrongly eat the inner half
    // of an unprocessed "{{token}}" (e.g. matching just "{token}" inside it).
    $wrappers = [
        ['/\{\{\s*%s\s*\}\}/i', null],   // {{token}}
        ['/\[\s*%s\s*\]/i',     null],   // [TOKEN]
        ['/\[#\s*%s\s*#\]/i',   null],   // [#token#]  (e.g. OpinionSpark-style)
        ['/\{\s*%s\s*\}/i',     null],   // {token}
        ['/%%\s*%s\s*%%/i',     null],   // %TOKEN%
        ['/<\s*%s\s*>/i',       null],   // <token>
        ['/\$\s*%s\s*\$/i',     null],   // $token$
    ];

    foreach ($tokens as $key => $value) {
        if ($value === null) continue;
        $quotedKey = preg_quote($key, '/');
        foreach ($wrappers as [$patternTemplate, ]) {
            $pattern = sprintf($patternTemplate, $quotedKey);
            $url = preg_replace($pattern, $value, $url);
        }
    }
    return $url;
}

/**
 * Builds the standard set of tokens available to substitute into any
 * vendor or client redirect URL. Covers every field this project actually
 * tracks - fields it does NOT track (demographics, quota cell, termination
 * reason codes, etc.) are intentionally not included here, since injecting
 * a blank/fake value would be worse than leaving the placeholder untouched
 * for the admin to notice and investigate.
 *
 * IMPORTANT: 'pid' means Panelist ID (the RESPONDENT) here - confirmed
 * industry-standard meaning per Medallia/SoSciSurvey/Qualtrics panel-
 * integration documentation. This is NOT the project id (this project's
 * own internal PID column, e.g. PHUB026172026, is passed in separately as
 * $project_ref below and maps to sid/studyid/projectid instead).
 *
 * $extra lets a call site add/override situational tokens like loi or status.
 */
function build_token_set($uid, $project_ref, $extra = []) {
    $base = [
        'uid' => $uid, 'rid' => $uid, 'toid' => $uid, 'identifier' => $uid, 'tid' => $uid, 'pid' => $uid,
        'userid' => $uid, 'user_id' => $uid, 'respid' => $uid, 'resp_id' => $uid,
        'respondentid' => $uid, 'respondent_id' => $uid, 'panelistid' => $uid, 'panelist_id' => $uid,
        'participantid' => $uid, 'participant_id' => $uid, 'memberid' => $uid, 'member_id' => $uid,
        'entryid' => $uid, 'entry_id' => $uid, 'clickid' => $uid, 'subid' => $uid,
        'transactionid' => $uid, 'transaction_id' => $uid, 'qparm' => $uid, 'subject_id' => $uid,
        'ext_ref' => $uid, 'external_id' => $uid, 'id' => $uid, 'ticket' => $uid,
        'sid' => $project_ref, 'studyid' => $project_ref, 'surveyid' => $project_ref,
        'survey_id' => $project_ref, 'projectid' => $project_ref, 'project_id' => $project_ref, 'gid' => $project_ref,
        'ip'   => get_client_ip(),
        'date' => date('Y-m-d'),
        'timestamp' => time(),
    ];
    return array_merge($base, $extra);
}

/**
 * Country/city lookup by IP. Uses a primary provider with an automatic
 * fallback to a second provider if the first fails or is rate-limited
 * (e.g. under bursty traffic) - keeps country detection working even when
 * one provider is temporarily unavailable. Returns 'Unknown' (not a blank
 * string) if both providers fail, so a failed lookup is visually
 * distinguishable from one that was never attempted.
 */
function geo_lookup($ip) {
    $ctx = stream_context_create(['http' => ['timeout' => 4]]);
    $geo = @json_decode(@file_get_contents("http://ip-api.com/json/{$ip}", false, $ctx));
    if ($geo && $geo->status === 'success' && !empty($geo->country)) {
        return ['country' => $geo->country, 'city' => $geo->city ?? ''];
    }
    $ctx2 = stream_context_create(['http' => ['timeout' => 4]]);
    $geo2 = @json_decode(@file_get_contents("https://ipapi.co/{$ip}/json/", false, $ctx2));
    if ($geo2 && empty($geo2->error) && !empty($geo2->country_name)) {
        return ['country' => $geo2->country_name, 'city' => $geo2->city ?? ''];
    }
    return ['country' => 'Unknown', 'city' => ''];
}

/**
 * Safely adds new columns/tables if they don't exist yet - no manual SQL
 * needed for these newer features (encryption, geo-tracking, target
 * countries, vendor pause). Call at the top of any page that touches these.
 */
function ensure_extra_columns(PDO $pdo) {
    $leads_cols = [
        "encrypted_uid" => "VARCHAR(100) DEFAULT NULL",
        "country"       => "VARCHAR(100) DEFAULT NULL",
        "city"          => "VARCHAR(100) DEFAULT NULL",
    ];
    foreach ($leads_cols as $col => $def) {
        try { $pdo->exec("ALTER TABLE leads ADD COLUMN $col $def"); } catch (PDOException $e) {}
    }
    $project_cols = [
        "encrypt_uid"      => "TINYINT(1) NOT NULL DEFAULT 0",
        "target_countries" => "VARCHAR(500) DEFAULT NULL",
    ];
    foreach ($project_cols as $col => $def) {
        try { $pdo->exec("ALTER TABLE projects ADD COLUMN $col $def"); } catch (PDOException $e) {}
    }
    $vendor_cols = [
        "status" => "ENUM('Active','Inactive') NOT NULL DEFAULT 'Active'",
    ];
    foreach ($vendor_cols as $col => $def) {
        try { $pdo->exec("ALTER TABLE vendors ADD COLUMN $col $def"); } catch (PDOException $e) {}
    }
    $pdo->exec("CREATE TABLE IF NOT EXISTS uid_mapping (
        id INT AUTO_INCREMENT PRIMARY KEY,
        original_uid VARCHAR(100) NOT NULL,
        encrypted_uid VARCHAR(100) NOT NULL,
        project_id INT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_orig (original_uid, project_id),
        KEY idx_enc (encrypted_uid)
    ) ENGINE=InnoDB");
}

/**
 * Returns the encrypted (opaque) token for a respondent UID within a given
 * project - reusing the existing token if this UID was already mapped for
 * this project, otherwise generating and storing a new one. The real UID is
 * always recoverable via the uid_mapping table (this is a lookup-based
 * design, not reversible encryption - matching the same pattern already in
 * use across Azilytics/Rent Panel/ExaVerify).
 */
function encrypt_uid(PDO $pdo, $uid, $project_id) {
    $chk = $pdo->prepare("SELECT encrypted_uid FROM uid_mapping WHERE original_uid=? AND project_id=? LIMIT 1");
    $chk->execute([$uid, $project_id]);
    $existing = $chk->fetchColumn();
    if ($existing) return $existing;

    $token = bin2hex(random_bytes(5)); // 10-character hex token
    $pdo->prepare("INSERT INTO uid_mapping (original_uid, encrypted_uid, project_id) VALUES (?,?,?)")
        ->execute([$uid, $token, $project_id]);
    return $token;
}

/**
 * Minutes elapsed between when the lead was first clicked (created_at) and now.
 * This is the REAL length-of-interview for that respondent - used to fill the
 * [LOI] / {{loi}} token some vendors (e.g. Azilytics) expect on their Complete link.
 */
function minutes_since($datetime) {
    if (!$datetime) return '';
    $diff = time() - strtotime($datetime);
    return max(0, round($diff / 60));
}

function get_client_ip() {
    return $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

/**
 * Renders a full, branded "thank you" style end page for a respondent —
 * Complete / Terminate / Screenout / Quotafull — matching the same visual
 * design used across the other panel systems. Called directly (server-side,
 * data already known) rather than via a client-side AJAX fetch, since the
 * caller here (callback.php / client_redirect.php) already has everything.
 */
function render_end_page($status, $sid, $uid, $ip, $time) {
    $statusMap = [
        'Complete' => [
            'badgeText' => 'COMPLETE', 'color' => '#16a34a', 'bg' => 'rgba(22,163,74,0.1)',
            'h1' => 'Response Recorded!',
            'p'  => 'Your response has been recorded and verified. Thank you for taking the time to complete this survey — your input is valuable to our research.',
            'icon' => '<path d="M20 6L9 17l-5-5" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>',
        ],
        'Terminates' => [
            'badgeText' => 'TERMINATED', 'color' => '#d97706', 'bg' => 'rgba(217,119,6,0.1)',
            'h1' => 'Session Ended',
            'p'  => 'We were unable to continue your participation based on the screening criteria for this study. Thank you for your time — this helps us maintain the quality of our research.',
            'icon' => '<path d="M6 6l12 12M18 6L6 18" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>',
        ],
        'Quota Full' => [
            'badgeText' => 'QUOTA FULL', 'color' => '#2563eb', 'bg' => 'rgba(37,99,235,0.1)',
            'h1' => 'This Survey Is Now Full',
            'p'  => 'Thank you for your interest — this study has already reached the number of responses needed. Please check back for future opportunities to participate.',
            'icon' => '<path d="M12 8v5M12 16h.01" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="12" cy="12" r="9" stroke="white" stroke-width="2"/>',
        ],
        'Screenout' => [
            'badgeText' => 'QUALITY CHECK', 'color' => '#dc2626', 'bg' => 'rgba(220,38,38,0.1)',
            'h1' => 'Thank You For Your Time',
            'p'  => 'Unfortunately, your responses did not pass our quality validation checks for this study. Your participation is still appreciated.',
            'icon' => '<path d="M12 9v4M12 17h.01" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" stroke="white" stroke-width="2" stroke-linejoin="round"/>',
        ],
    ];
    $s = $statusMap[$status] ?? $statusMap['Complete'];
    $logo = defined('BRAND_LOGO') ? BASE_URL . '/' . BRAND_LOGO : '';
    $brand = defined('BRAND_NAME') ? BRAND_NAME : 'Survey Panel';
    $email = defined('BRAND_SUPPORT_EMAIL') ? BRAND_SUPPORT_EMAIL : '';
    $domain = defined('BASE_URL') ? preg_replace('#^https?://#', '', BASE_URL) : '';

    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Survey <?= e($s['badgeText']) ?> — <?= e($brand) ?></title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html{height:100%}
body{min-height:100vh;min-height:100dvh;width:100%;background:#f4f6fb;font-family:'Segoe UI',sans-serif;display:flex;align-items:center;justify-content:center;color:#0f172a;padding:24px}
.card{background:#ffffff;border:1px solid rgba(15,23,42,0.08);border-radius:20px;max-width:760px;width:100%;box-shadow:0 12px 40px rgba(15,23,42,0.08);margin:0 auto;overflow:hidden}
.top{display:flex;flex-direction:column;align-items:center;gap:18px;padding:36px 40px 0;text-align:center}
.logo{max-width:170px;width:100%;height:auto;display:block}
.badge{display:inline-flex;align-items:center;gap:9px;border-radius:8px;padding:11px 28px;font-size:15px;font-weight:700;letter-spacing:2px;color:<?= $s['color'] ?>;background:<?= $s['bg'] ?>}
.badge::before{content:'';width:9px;height:9px;border-radius:50%;background:<?= $s['color'] ?>}
.hero{padding:36px 40px 8px;display:flex;align-items:center;gap:28px}
.icon-wrap{flex-shrink:0;width:84px;height:84px;border-radius:50%;background:<?= $s['color'] ?>;display:flex;align-items:center;justify-content:center;box-shadow:0 8px 24px rgba(0,0,0,0.15)}
.icon-wrap svg{width:38px;height:38px}
.hero-text h1{font-size:32px;font-weight:800;color:#0f172a;margin-bottom:10px;letter-spacing:-0.5px}
.hero-text p{color:#64748b;font-size:15px;line-height:1.7}
.record{margin:28px 40px 0;border:1px solid rgba(15,23,42,0.08);border-radius:12px;overflow:hidden}
.record-table{width:100%;border-collapse:collapse}
.record-table th{background:<?= $s['color'] ?>;padding:12px 16px;font-size:10px;letter-spacing:1.5px;color:#ffffff;font-weight:700;text-align:left}
.record-table td{padding:14px 16px;font-size:13px;color:#334155;background:#f8fafc;border-top:1px solid rgba(15,23,42,0.06)}
.uid-val{font-family:'Consolas',monospace;font-size:12px}
.sid-val{font-weight:700;color:<?= $s['color'] ?>}
.status-pill{display:inline-flex;align-items:center;gap:5px;border-radius:5px;padding:3px 10px;font-size:10px;font-weight:700;color:#ffffff;background:<?= $s['color'] ?>}
.footer{margin-top:28px;padding:20px 40px 28px;border-top:1px solid rgba(15,23,42,0.08);font-size:12px;color:#94a3b8;line-height:1.9;text-align:center}
.footer a{color:#2563eb;text-decoration:none;font-weight:600}
.footer a:hover{text-decoration:underline}
@media (max-width:520px){
  .hero{flex-direction:column;text-align:center;gap:16px}
  .top{flex-direction:column;gap:14px;align-items:center;text-align:center}
}
</style>
</head>
<body>
<div class="card">
  <div class="top">
    <?php if ($logo): ?><img src="<?= e($logo) ?>" alt="<?= e($brand) ?>" class="logo"><?php else: ?><h2><?= e($brand) ?></h2><?php endif; ?>
    <div class="badge"><?= e($s['badgeText']) ?></div>
  </div>
  <div class="hero">
    <div class="icon-wrap">
      <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><?= $s['icon'] ?></svg>
    </div>
    <div class="hero-text">
      <h1><?= e($s['h1']) ?></h1>
      <p><?= e($s['p']) ?></p>
    </div>
  </div>
  <div class="record">
    <table class="record-table">
      <thead><tr><th>PROJECT ID</th><th>RESPONDENT ID</th><th>STATUS</th><th>IP ADDRESS</th><th>TIME</th></tr></thead>
      <tbody>
        <tr>
          <td class="sid-val"><?= e($sid) ?></td>
          <td class="uid-val"><?= e($uid) ?></td>
          <td><span class="status-pill"><?= e($s['badgeText']) ?></span></td>
          <td class="uid-val"><?= e($ip) ?></td>
          <td class="uid-val"><?= e($time) ?></td>
        </tr>
      </tbody>
    </table>
  </div>
  <div class="footer">
    <?php if ($email): ?>Need help? Reach us at <a href="mailto:<?= e($email) ?>"><?= e($email) ?></a><br><?php endif; ?>
    <?= e($domain) ?> &nbsp;•&nbsp; © <?= e($brand) ?>. All rights reserved.
  </div>
</div>
</body>
</html>
    <?php
    exit();
}
