<?php
/* =====================================================
   PanelHub - Central Config
   Change everything about branding from THIS block only.
   ===================================================== */

// ---------------- BRAND CONFIG ----------------
define('BRAND_NAME', 'YourCompany');
define('BRAND_TAGLINE', "YourCompany's");
define('BRAND_LOGO', 'assets/img/logo.png');   // put your logo here
define('BRAND_PRIMARY_COLOR', '#3B4CCA');
define('BRAND_SUPPORT_EMAIL', 'admin@yourcompany.com');
define('BASE_URL', 'https://panel.yourcompany.com'); // no trailing slash
// ------------------------------------------------

// ---------------- DATABASE CONFIG ----------------
define('DB_HOST', 'localhost');
define('DB_NAME', 'panelhub');
define('DB_USER', 'root');
define('DB_PASS', '');
// ---------------------------------------------------

date_default_timezone_set('Asia/Kolkata');
session_start();

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
