<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= e(BRAND_NAME) ?> Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.13.8/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="<?= BASE_URL ?>/assets/css/style.css" rel="stylesheet">
<style>:root{--brand:<?= BRAND_PRIMARY_COLOR ?>;}</style>
</head>
<body>
<div class="d-flex" id="wrapper">

  <!-- SIDEBAR -->
  <nav class="sidebar" id="sidebar">
    <div class="sidebar-brand">
      <img src="<?= BASE_URL ?>/assets/img/logo-placeholder.svg" alt="logo" onerror="this.style.display='none'">
      <span><?= e(BRAND_NAME) ?></span>
    </div>
    <div class="px-3 py-2 text-white-50 small">Hi, <?= e($_SESSION['admin_name'] ?? 'Admin') ?></div>
    <ul class="nav flex-column px-2">
      <li class="nav-item"><a class="nav-link <?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>" href="<?= BASE_URL ?>/admin/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
      <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/admin/client.php"><i class="bi bi-person-vcard"></i> Client</a></li>
      <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/admin/projects.php"><i class="bi bi-diagram-3"></i> Projects</a></li>
      <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/admin/leads.php"><i class="bi bi-bar-chart"></i> Leads</a></li>
      <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/admin/vendorlist.php"><i class="bi bi-folder2-open"></i> Vendor List</a></li>
      <li class="nav-item"><a class="nav-link <?= basename($_SERVER['PHP_SELF'])=='team.php'?'active':'' ?>" href="<?= BASE_URL ?>/admin/team.php"><i class="bi bi-people"></i> Team</a></li>
      <li class="nav-item"><a class="nav-link <?= basename($_SERVER['PHP_SELF'])=='backup.php'?'active':'' ?>" href="<?= BASE_URL ?>/admin/backup.php"><i class="bi bi-cloud-download"></i> Backup</a></li>
    </ul>
  </nav>

  <!-- CONTENT -->
  <div class="content-area flex-grow-1">
    <div class="topbar d-flex justify-content-between align-items-center px-4 py-3">
      <button class="btn btn-sm btn-outline-secondary d-lg-none" id="sidebarToggle"><i class="bi bi-list"></i></button>
      <div></div>
      <a href="<?= BASE_URL ?>/admin/logout.php" class="btn btn-sm btn-outline-danger"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>
    <div class="px-4 pb-5">
    <?php $f = flash_get(); if ($f): ?>
      <div class="alert alert-<?= e($f['type']) ?> alert-dismissible fade show" role="alert">
        <?= e($f['msg']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>
