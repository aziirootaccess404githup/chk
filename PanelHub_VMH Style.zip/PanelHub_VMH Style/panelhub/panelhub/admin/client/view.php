<?php
require_once __DIR__ . '/../../includes/auth.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM clients WHERE id = ?");
$stmt->execute([$id]);
$c = $stmt->fetch();
if (!$c) { flash_set('Client not found.', 'danger'); redirect('../client.php'); }

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="card-panel mt-4">
  <div class="panel-header">
    Client Details
    <a href="addedit.php?id=<?= $c['id'] ?>" class="btn btn-light btn-sm">Edit</a>
  </div>
  <div class="panel-body">
    <div class="card-panel mb-3 p-3">
      <p><strong>Client ID:</strong> <?= e($c['client_uid']) ?></p>
      <p><strong>Client Name:</strong> <?= e($c['name']) ?></p>
      <p><strong>Contact Person:</strong> <?= e($c['contact_person']) ?: '<span class="text-muted">Not set</span>' ?></p>
      <p><strong>Email:</strong> <?= e($c['email']) ?: '<span class="text-muted">Not set</span>' ?></p>
      <p><strong>Phone:</strong> <?= e($c['phone']) ?: '<span class="text-muted">Not set</span>' ?></p>
      <p class="mb-0"><strong>Registration Date:</strong> <?= date('d-M-Y', strtotime($c['created_at'])) ?></p>
    </div>

    <div class="card-panel mb-3 p-3">
      <h6>Description</h6>
      <?= $c['description'] ?: '<p class="text-muted mb-0">No description added.</p>' ?>
    </div>

    <div class="card-panel p-3">
      <h6>Redirects</h6>
      <p class="text-muted small">Ye 4 links system-generated hain (client ID se banते), inhe apne survey tool mein
        "on complete / on terminate / on screenout / on quotafull" destination ke roop mein daal do. <code>username=xxxx</code> ki jagah
        respondent ka asli UID survey tool khud bhar dega.</p>
      <?php
        $links = [
          'Complete URL'  => BASE_URL . "/public/client_redirect.php?client=" . urlencode($c['client_uid']) . "&type=complete&username=xxxx",
          'Terminate URL' => BASE_URL . "/public/client_redirect.php?client=" . urlencode($c['client_uid']) . "&type=terminate&username=xxxx",
          'Screenout URL' => BASE_URL . "/public/client_redirect.php?client=" . urlencode($c['client_uid']) . "&type=screenout&username=xxxx",
          'Quotafull URL' => BASE_URL . "/public/client_redirect.php?client=" . urlencode($c['client_uid']) . "&type=quotafull&username=xxxx",
        ];
        foreach ($links as $label => $url):
      ?>
      <p class="mb-2"><strong><?= $label ?>:</strong><br>
          <a href="<?= e($url) ?>" target="_blank" class="small text-break"><?= e($url) ?></a>
          <button class="btn btn-sm btn-link" onclick="copyToClipboard('<?= e($url) ?>', this)"><i class="bi bi-clipboard"></i></button>
      </p>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
