<?php
require_once __DIR__ . '/../../includes/auth.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM clients WHERE id=?");
$stmt->execute([$id]);
$client = $stmt->fetch();
if (!$client) { flash_set('Client not found.', 'danger'); redirect('../client.php'); }

$logs = $pdo->prepare("SELECT * FROM audit_log WHERE entity_type='client' AND entity_id=? ORDER BY id DESC");
$logs->execute([$id]);
$rows = $logs->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="card-panel mt-4">
  <div class="panel-header">
    Log &mdash; <?= e($client['name']) ?>
    <a href="addedit.php?id=<?= $id ?>" class="btn btn-light btn-sm">Back</a>
  </div>
  <div class="panel-body">
    <table class="table table-hover">
      <thead><tr><th>Action</th><th>Details</th><th>By</th><th>Date</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><span class="badge bg-<?= $r['action']==='created'?'success':'info' ?>"><?= e(ucfirst($r['action'])) ?></span></td>
          <td><?= e($r['details']) ?></td>
          <td><?= e($r['admin_name']) ?></td>
          <td><?= date('Y-m-d H:i:s', strtotime($r['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="4" class="text-center text-muted">No history yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
