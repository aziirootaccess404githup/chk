<?php
require_once __DIR__ . '/../../includes/auth.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$client = ['name'=>'','contact_person'=>'','email'=>'','phone'=>'','description'=>'','status'=>1];

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM clients WHERE id = ?");
    $stmt->execute([$id]);
    $client = $stmt->fetch() ?: $client;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $contact_person = trim($_POST['contact_person']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $desc = $_POST['description'];

    if ($id) {
        $stmt = $pdo->prepare("UPDATE clients SET name=?, contact_person=?, email=?, phone=?, description=? WHERE id=?");
        $stmt->execute([$name, $contact_person, $email, $phone, $desc, $id]);
        $pdo->prepare("INSERT INTO audit_log (entity_type, entity_id, action, admin_id, admin_name, details) VALUES ('client', ?, 'updated', ?, ?, ?)")
            ->execute([$id, $_SESSION['admin_id'], $_SESSION['admin_name'], "Name: $name"]);
        flash_set('Client updated.');
    } else {
        // client_uid is auto-generated here - it is what the 3 redirect URLs on the view page
        // are built from. Nothing about redirect URLs is manually typed by the admin.
        $uid = generate_uid();
        $stmt = $pdo->prepare("INSERT INTO clients (client_uid, name, contact_person, email, phone, description, status) VALUES (?,?,?,?,?,?,1)");
        $stmt->execute([$uid, $name, $contact_person, $email, $phone, $desc]);
        $id = $pdo->lastInsertId();
        $pdo->prepare("INSERT INTO audit_log (entity_type, entity_id, action, admin_id, admin_name, details) VALUES ('client', ?, 'created', ?, ?, ?)")
            ->execute([$id, $_SESSION['admin_id'], $_SESSION['admin_name'], "Name: $name"]);
        flash_set('Client created.');
    }
    redirect('../client.php');
}

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="card-panel mt-4">
  <div class="panel-header">
    Client
    <div>
      <?php if ($id): ?><a href="log.php?id=<?= $id ?>" class="btn btn-light btn-sm"><i class="bi bi-clock-history"></i> LOG</a><?php endif; ?>
      <a href="../client.php" class="btn btn-light btn-sm"><i class="bi bi-list"></i> LIST</a>
    </div>
  </div>
  <div class="panel-body">
    <form method="post">
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Client name</label>
          <input type="text" name="name" class="form-control" required value="<?= e($client['name']) ?>" placeholder="Enter Client Name">
        </div>
        <div class="col-md-6">
          <label class="form-label">Contact Person</label>
          <input type="text" name="contact_person" class="form-control" value="<?= e($client['contact_person']) ?>" placeholder="Enter Contact Person Name">
        </div>
        <div class="col-md-6">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" value="<?= e($client['email']) ?>" placeholder="Enter Email">
        </div>
        <div class="col-md-6">
          <label class="form-label">Phone</label>
          <input type="text" name="phone" class="form-control" value="<?= e($client['phone']) ?>" placeholder="Enter Phone Number">
        </div>
        <div class="col-12">
          <label class="form-label">Description</label>
          <textarea name="description" id="editor" class="form-control" rows="6"><?= $client['description'] ?></textarea>
        </div>
      </div>
      <button class="btn btn-primary mt-4" style="background:<?= BRAND_PRIMARY_COLOR ?>;border:none;"><?= $id ? 'Update' : 'Save' ?></button>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/ckeditor5@41.4.2/dist/ckeditor5.umd.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/ckeditor5@41.4.2/dist/ckeditor5.css">
<script>
CKEDITOR5.ClassicEditor.create(document.querySelector('#editor'), { licenseKey: 'GPL' })
  .catch(err => console.error(err));
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
