<?php
require_once __DIR__ . '/../includes/auth.php';

$activeVendors  = $pdo->query("SELECT COUNT(*) FROM vendors")->fetchColumn();
$pendingLeads   = $pdo->query("SELECT COUNT(*) FROM leads WHERE status='Pending'")->fetchColumn();
$totalClicks    = $pdo->query("SELECT COUNT(*) FROM leads")->fetchColumn();
$activeProjects = $pdo->query("SELECT COUNT(*) FROM projects WHERE status='Live'")->fetchColumn();

// clicks per project for the chart
$chart = $pdo->query("
  SELECT p.project_name, COUNT(l.id) AS clicks
  FROM projects p LEFT JOIN leads l ON l.project_id = p.id
  GROUP BY p.id ORDER BY p.id DESC LIMIT 40
")->fetchAll();
$labels = array_column($chart, 'project_name');
$values = array_column($chart, 'clicks');

require_once __DIR__ . '/../includes/header.php';
?>

<div class="row g-3 my-2">
  <div class="col-md-3"><div class="stat-card stat-1">
    <h6>Active Vendors</h6><h2><?= (int)$activeVendors ?></h2>
    <div class="progress"><div class="progress-bar" style="width:70%"></div></div>
  </div></div>
  <div class="col-md-3"><div class="stat-card stat-2">
    <h6>Pending Leads</h6><h2><?= (int)$pendingLeads ?></h2>
    <div class="progress"><div class="progress-bar" style="width:55%"></div></div>
  </div></div>
  <div class="col-md-3"><div class="stat-card stat-3">
    <h6>Total Clicks</h6><h2><?= (int)$totalClicks ?></h2>
    <div class="progress"><div class="progress-bar" style="width:80%"></div></div>
  </div></div>
  <div class="col-md-3"><div class="stat-card stat-4">
    <h6>Active Projects</h6><h2><?= (int)$activeProjects ?></h2>
    <div class="progress"><div class="progress-bar" style="width:60%"></div></div>
  </div></div>
</div>

<div class="mt-4">
  <canvas id="clicksChart" height="90"></canvas>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
const palette = ['#e91e8c','#7b2ff7','#12c48b','#f7971e','#2b6cb0','#e53e3e','#38b2ac','#d69e2e'];
new Chart(document.getElementById('clicksChart'), {
  type: 'bar',
  data: {
    labels: <?= json_encode($labels) ?>,
    datasets: [{
      label: 'Clicks',
      data: <?= json_encode($values) ?>,
      backgroundColor: <?= json_encode($labels) ?>.map((_, i) => palette[i % palette.length])
    }]
  },
  options: {
    plugins: { legend: { display: false } },
    scales: { x: { ticks: { autoSkip: false, maxRotation: 90, minRotation: 90, font:{size:9} } } }
  }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
