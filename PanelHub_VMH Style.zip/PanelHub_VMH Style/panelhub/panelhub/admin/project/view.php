<?php
require_once __DIR__ . '/../../includes/auth.php';
ensure_extra_columns($pdo);

$id = (int)($_GET['id'] ?? 0);

// ---- Handle vendor assignment ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_vendor_id'])) {
    $vendorId = (int)$_POST['assign_vendor_id'];
    $cpi = (float)($_POST['assign_cpi'] ?? 0);
    $limit = (int)($_POST['assign_limit'] ?? 0);
    $stmt = $pdo->prepare("INSERT IGNORE INTO project_vendors (project_id, vendor_id, cpi, daily_limit) VALUES (?,?,?,?)");
    $stmt->execute([$id, $vendorId, $cpi, $limit]);
    flash_set('Vendor assigned to project.');
    redirect("view.php?id=$id");
}
if (isset($_GET['unassign'])) {
    $pdo->prepare("DELETE FROM project_vendors WHERE id=?")->execute([(int)$_GET['unassign']]);
    flash_set('Vendor removed from project.');
    redirect("view.php?id=$id");
}

$stmt = $pdo->prepare("SELECT p.*, c.name AS client_name FROM projects p LEFT JOIN clients c ON c.id=p.client_id WHERE p.id=?");
$stmt->execute([$id]);
$p = $stmt->fetch();
if (!$p) { flash_set('Project not found.', 'danger'); redirect('../projects.php'); }

$stats = $pdo->prepare("SELECT
  SUM(status IN ('Pending')) AS pending,
  SUM(status='Complete') AS completes,
  SUM(status='Terminates') AS terminates
  FROM leads WHERE project_id=?");
$stats->execute([$id]);
$s = $stats->fetch();

$vendors = $pdo->prepare("
  SELECT pv.*, v.vid, v.name, v.email FROM project_vendors pv
  JOIN vendors v ON v.id = pv.vendor_id WHERE pv.project_id=? ORDER BY pv.id DESC
");
$vendors->execute([$id]);
$vendorRows = $vendors->fetchAll();

$allVendors = $pdo->query("SELECT id, vid, name FROM vendors ORDER BY name")->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="row g-3 mt-2">
  <div class="col-md-4"><div class="card-panel p-3 text-center"><div class="text-muted small">Pending</div><h3><?= (int)$s['pending'] ?></h3></div></div>
  <div class="col-md-4"><div class="card-panel p-3 text-center"><div class="text-muted small">Completes</div><h3><?= (int)$s['completes'] ?></h3></div></div>
  <div class="col-md-4"><div class="card-panel p-3 text-center"><div class="text-muted small">Terminates</div><h3><?= (int)$s['terminates'] ?></h3></div></div>
</div>

<div class="card-panel mt-3">
  <div class="panel-header">Project Info</div>
  <div class="panel-body">
    <div class="row">
      <div class="col-md-6">
        <p><strong>Project Name:</strong> <?= e($p['project_name']) ?></p>
        <p><strong>Client Name:</strong> <?= e($p['client_name']) ?></p>
        <p><strong>Cost Per Complete (CPI):</strong> $<?= number_format($p['cpi'],2) ?></p>
      </div>
      <div class="col-md-6">
        <p><strong>Status:</strong> <?= status_badge($p['status']) ?></p>
        <p><strong>Target Countries:</strong> <?= !empty($p['target_countries']) ? e($p['target_countries']) : '<span class="text-muted">All / not specified</span>' ?></p>
        <p><strong>UID Encryption:</strong> <?= !empty($p['encrypt_uid']) ? '<span class="badge bg-success">ON</span>' : '<span class="badge bg-secondary">OFF</span>' ?></p>
        <p><strong>Project ID:</strong> <?= e($p['pid']) ?></p>
        <p><strong>Maximum Completes (Limit):</strong> <?= (int)$p['max_completes'] ?></p>
      </div>
      <div class="col-12">
        <strong>Live URL:</strong><br>
        <?php if ($p['live_url']): ?>
          <a href="<?= e($p['live_url']) ?>" target="_blank" class="small"><?= e($p['live_url']) ?></a>
          <button class="btn btn-sm btn-link" onclick="copyToClipboard('<?= e($p['live_url']) ?>', this)"><i class="bi bi-clipboard"></i></button>
        <?php else: ?><span class="text-muted">Not set</span><?php endif; ?>
      </div>
    </div>
  </div>
</div>

<div class="card-panel mt-3">
  <div class="panel-header">Description</div>
  <div class="panel-body">
    <?php if ($p['description']): ?>
      <?= $p['description'] /* rich-text HTML, entered as-is via CKEditor - trusted admin content */ ?>
    <?php else: ?>
      <p class="text-muted mb-0">No description added.</p>
    <?php endif; ?>
  </div>
</div>

<div class="card-panel mt-3">
  <div class="panel-header">
    Vendors
    <button class="btn btn-light btn-sm" data-bs-toggle="modal" data-bs-target="#assignModal">Assign Vendors <i class="bi bi-arrow-right"></i></button>
  </div>
  <div class="panel-body">
    <button class="btn btn-primary btn-sm mb-3" onclick="exportTableToCSV('vendorTable','<?= e($p['pid']) ?>_vendors.csv')">Download Excel</button>
    <div class="table-responsive">
    <table class="table table-hover" id="vendorTable">
      <thead><tr>
        <th>VID</th><th>Name</th><th>Email</th><th>CPI</th><th>Limit</th><th>Status</th>
        <th>Clicks</th><th>Complete</th><th>Terminates</th><th>Entry Link</th><th></th>
      </tr></thead>
      <tbody>
      <?php foreach ($vendorRows as $v):
        $entryLink = BASE_URL . "/public/entry.php?pid=" . urlencode($p['pid']) . "&vid=" . urlencode($v['vid']) . "&uid=xxxx";
      ?>
        <tr>
          <td><?= e($v['vid']) ?></td>
          <td><?= e($v['name']) ?></td>
          <td><?= e($v['email']) ?></td>
          <td><?= number_format($v['cpi'],2) ?></td>
          <td><?= (int)$v['daily_limit'] ?></td>
          <td><?= status_badge($v['status']) ?></td>
          <td><?= (int)$v['clicks'] ?></td>
          <td><?= (int)$v['completes'] ?></td>
          <td><?= (int)$v['terminates'] ?></td>
          <td>
            <a href="#" class="small" onclick="showEntryLink('<?= e($v['vid']) ?>','<?= e($entryLink) ?>','<?= e($p['project_name']) ?>','<?= e($v['email']) ?>');return false;">
              <i class="bi bi-link-45deg"></i> Entry Link
            </a>
          </td>
          <td><a href="view.php?id=<?= $id ?>&unassign=<?= $v['id'] ?>" class="text-danger" onclick="return confirm('Remove vendor from project?')"><i class="bi bi-x-lg"></i></a></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$vendorRows): ?><tr><td colspan="11" class="text-center text-muted">No vendors assigned yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
    </div>
  </div>
</div>

<!-- Assign Vendor Modal -->
<div class="modal fade" id="assignModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="post">
        <div class="modal-header"><h5 class="modal-title">Assign Vendor</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Vendor</label>
            <select name="assign_vendor_id" class="form-select" required>
              <option value="">Select vendor</option>
              <?php foreach ($allVendors as $v): ?>
                <option value="<?= $v['id'] ?>"><?= e($v['name']) ?> (<?= e($v['vid']) ?>)</option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="row g-2">
            <div class="col-6"><label class="form-label">CPI</label><input type="number" step="0.01" name="assign_cpi" class="form-control" value="<?= number_format($p['cpi'],2) ?>"></div>
            <div class="col-6"><label class="form-label">Limit</label><input type="number" name="assign_limit" class="form-control" value="<?= (int)$p['max_completes'] ?>"></div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Assign</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Entry link popup -->
<div class="modal fade" id="entryModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title" id="entryModalTitle">Entry Link</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <p class="mb-2" id="entryModalSub"></p>
        <div class="input-group">
          <input type="text" id="entryLinkInput" class="form-control" readonly>
          <button class="btn btn-outline-secondary" onclick="copyEntryLink()"><i class="bi bi-clipboard"></i></button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
function showEntryLink(vid, link, projectName, email){
  document.getElementById('entryModalTitle').innerText = 'Entry Link for ' + vid;
  document.getElementById('entryModalSub').innerText = projectName + ' project for ' + email;
  document.getElementById('entryLinkInput').value = link;
  new bootstrap.Modal(document.getElementById('entryModal')).show();
}
function copyEntryLink(){
  const inp = document.getElementById('entryLinkInput');
  navigator.clipboard.writeText(inp.value);
}
function exportTableToCSV(tableId, filename){
  const table = document.getElementById(tableId);
  let csv = [];
  for (const row of table.rows){
    const cols = Array.from(row.querySelectorAll('th,td')).map(c => '"' + c.innerText.replace(/"/g,'""') + '"');
    csv.push(cols.join(','));
  }
  const blob = new Blob([csv.join('\n')], {type:'text/csv'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
}
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
