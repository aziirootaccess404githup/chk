<?php
require_once __DIR__ . '/../includes/auth.php';

if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM clients WHERE id = ?");
    $stmt->execute([(int)$_GET['delete']]);
    flash_set('Client deleted.', 'success');
    redirect('client.php');
}

if (isset($_GET['toggle'])) {
    $pdo->prepare("UPDATE clients SET status = 1 - status WHERE id = ?")->execute([(int)$_GET['toggle']]);
    redirect('client.php');
}

$clients = $pdo->query("SELECT * FROM clients ORDER BY id DESC")->fetchAll();
require_once __DIR__ . '/../includes/header.php';
?>

<div class="card-panel mt-4">
  <div class="panel-header">
    Client List
    <a href="client/addedit.php" class="btn btn-light btn-sm"><i class="bi bi-plus-lg"></i> ADD</a>
  </div>
  <div class="panel-body">
    <table class="table table-hover datatable align-middle">
      <thead><tr><th>Sl No.</th><th>Client name</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
      <?php foreach ($clients as $i => $c): ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td><?= e($c['name']) ?></td>
          <td>
            <a href="client.php?toggle=<?= $c['id'] ?>" title="Click to toggle">
              <?= $c['status'] ? '<i class="bi bi-check-circle-fill text-success fs-5"></i>' : '<i class="bi bi-x-circle-fill text-secondary fs-5"></i>' ?>
            </a>
          </td>
          <td>
            <a href="client/addedit.php?id=<?= $c['id'] ?>" class="btn btn-primary btn-sm"><i class="bi bi-pencil"></i></a>
            <a href="client/view.php?id=<?= $c['id'] ?>" class="btn btn-info btn-sm text-white"><i class="bi bi-eye"></i></a>
            <a href="client.php?delete=<?= $c['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this client?')"><i class="bi bi-x-lg"></i></a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
