<?php
require_once __DIR__ . '/../includes/auth.php';
ensure_extra_columns($pdo);

// ── CSV EXPORT (respects all filters below, including date range) ──────
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $where = '1=1'; $params = [];
    if (!empty($_GET['status']))     { $where .= " AND l.status=?"; $params[] = $_GET['status']; }
    if (!empty($_GET['pid']))        { $where .= " AND p.pid=?"; $params[] = $_GET['pid']; }
    if (!empty($_GET['search']))     { $where .= " AND (l.uid LIKE ? OR p.pid LIKE ?)"; $params[] = "%{$_GET['search']}%"; $params[] = "%{$_GET['search']}%"; }
    if (!empty($_GET['date_from']))  { $where .= " AND DATE(l.created_at) >= ?"; $params[] = $_GET['date_from']; }
    if (!empty($_GET['date_to']))    { $where .= " AND DATE(l.created_at) <= ?"; $params[] = $_GET['date_to']; }
    $stmt = $pdo->prepare("SELECT l.*, p.pid, p.project_name FROM leads l JOIN projects p ON p.id=l.project_id WHERE $where ORDER BY l.id DESC");
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="panelhub_leads_'.date('Ymd_His').'.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['ID','Project ID','Project Name','Status','UID','Encrypted ID','Country','City','LOI(sec)','IP','Date']);
    foreach ($rows as $r) {
        fputcsv($out, [$r['id'],$r['pid'],$r['project_name'],$r['status'],$r['uid'],$r['encrypted_uid'],$r['country'],$r['city'],$r['loi_seconds'],$r['ip'],$r['created_at']]);
    }
    fclose($out); exit;
}

// ── FILTERED LIST (on-screen) ───────────────────────────────────────────
$search     = trim($_GET['search'] ?? '');
$statusFilt = $_GET['status'] ?? '';
$pidFilt    = $_GET['pid'] ?? '';
$dateFrom   = $_GET['date_from'] ?? '';
$dateTo     = $_GET['date_to'] ?? '';

$where = '1=1'; $params = [];
if ($search)     { $where .= " AND (l.uid LIKE ? OR p.pid LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
if ($statusFilt) { $where .= " AND l.status=?"; $params[] = $statusFilt; }
if ($pidFilt)     { $where .= " AND p.pid=?"; $params[] = $pidFilt; }
if ($dateFrom)    { $where .= " AND DATE(l.created_at) >= ?"; $params[] = $dateFrom; }
if ($dateTo)      { $where .= " AND DATE(l.created_at) <= ?"; $params[] = $dateTo; }

$stmt = $pdo->prepare("
  SELECT l.*, p.pid, p.project_name FROM leads l
  JOIN projects p ON p.id = l.project_id
  WHERE $where
  ORDER BY l.id DESC LIMIT 500
");
$stmt->execute($params);
$leads = $stmt->fetchAll();

$allProjects = $pdo->query("SELECT pid, project_name FROM projects ORDER BY project_name")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card-panel mt-4">
  <div class="panel-header d-flex justify-content-between align-items-center">
    <span>Leads (<?= count($leads) ?> shown)</span>
    <a href="?export=csv&search=<?= urlencode($search) ?>&status=<?= urlencode($statusFilt) ?>&pid=<?= urlencode($pidFilt) ?>&date_from=<?= urlencode($dateFrom) ?>&date_to=<?= urlencode($dateTo) ?>" class="btn btn-sm btn-outline-success">⬇ Export CSV</a>
  </div>
  <div class="panel-body">
    <form method="GET" class="d-flex gap-2 flex-wrap mb-3">
      <input type="text" name="search" class="form-control form-control-sm" style="max-width:200px" placeholder="Search UID or Project ID..." value="<?= e($search) ?>">
      <select name="status" class="form-select form-select-sm" style="max-width:160px">
        <option value="">All Statuses</option>
        <?php foreach (['Pending','Complete','Terminates','Screenout','Quota Full'] as $s): ?>
        <option value="<?= $s ?>" <?= $statusFilt===$s?'selected':'' ?>><?= $s ?></option>
        <?php endforeach; ?>
      </select>
      <select name="pid" class="form-select form-select-sm" style="max-width:200px">
        <option value="">All Projects</option>
        <?php foreach ($allProjects as $p): ?>
        <option value="<?= e($p['pid']) ?>" <?= $pidFilt===$p['pid']?'selected':'' ?>><?= e($p['project_name']) ?></option>
        <?php endforeach; ?>
      </select>
      <input type="date" name="date_from" class="form-control form-control-sm" style="max-width:150px" value="<?= e($dateFrom) ?>" title="From date">
      <input type="date" name="date_to" class="form-control form-control-sm" style="max-width:150px" value="<?= e($dateTo) ?>" title="To date">
      <button type="submit" class="btn btn-sm btn-primary">Filter</button>
      <a href="leads.php" class="btn btn-sm btn-outline-secondary">Clear</a>
    </form>
    <div class="table-responsive">
    <table class="table table-hover datatable align-middle">
      <thead><tr><th>Id</th><th>Project Id</th><th>Project Name</th><th>Status</th><th>UID</th><th>Encrypted ID</th><th>Country</th><th>Date</th><th>IP</th></tr></thead>
      <tbody>
      <?php foreach ($leads as $l): ?>
        <tr>
          <td><?= $l['id'] ?></td>
          <td><?= e($l['pid']) ?></td>
          <td><?= e($l['project_name']) ?></td>
          <td><?= status_badge($l['status']) ?></td>
          <td><?= e($l['uid']) ?></td>
          <td class="text-muted small"><?= $l['encrypted_uid'] ? '🔒 '.e($l['encrypted_uid']) : '—' ?></td>
          <td><?= e($l['country'] ?: '—') ?></td>
          <td><?= date('Y-m-d H:i:s', strtotime($l['created_at'])) ?></td>
          <td><?= e($l['ip']) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
