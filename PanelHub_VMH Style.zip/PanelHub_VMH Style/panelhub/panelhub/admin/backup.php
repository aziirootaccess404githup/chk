<?php
require_once __DIR__ . '/../includes/auth.php';

// ── FULL DATABASE BACKUP (on-demand only — no automatic/scheduled deletion
// of any kind; this is purely a manual "download a copy right now" tool.
// Data is never removed from the server by this feature — it stays until
// manually deleted via SQL if/when needed.) ──────────────────────────────
if (isset($_GET['download']) && $_GET['download'] === '1') {
    $tables = ['clients', 'projects', 'vendors', 'project_vendors', 'leads', 'audit_log', 'uid_mapping'];
    header('Content-Type: application/sql');
    header('Content-Disposition: attachment; filename="panelhub_backup_'.date('Y-m-d_His').'.sql"');
    echo "-- PanelHub — Full Data Backup\n";
    echo "-- Generated: " . date('Y-m-d H:i:s') . " IST\n";
    echo "-- Tables included: " . implode(', ', $tables) . "\n\n";
    echo "SET FOREIGN_KEY_CHECKS=0;\n\n";
    foreach ($tables as $t) {
        try {
            $rows = $pdo->query("SELECT * FROM $t")->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            continue; // table doesn't exist on this install — skip silently
        }
        echo "-- --------------------------------------------------\n";
        echo "-- Table: $t (" . count($rows) . " rows)\n";
        echo "-- --------------------------------------------------\n";
        foreach ($rows as $row) {
            $cols = array_keys($row);
            $vals = array_map(function($v) use ($pdo) {
                if ($v === null) return 'NULL';
                return $pdo->quote($v);
            }, array_values($row));
            echo "INSERT INTO `$t` (`" . implode('`,`', $cols) . "`) VALUES (" . implode(',', $vals) . ");\n";
        }
        echo "\n";
    }
    echo "SET FOREIGN_KEY_CHECKS=1;\n";
    exit;
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card-panel mt-4">
  <div class="panel-header">Backup</div>
  <div class="panel-body">
    <div class="card-panel p-3" style="max-width:640px">
      <h6>Download Full Backup</h6>
      <p class="text-muted small">
        Ek click mein poori tarah clients, projects, vendors, leads aur baaki core data ka <strong>.sql</strong> file download ho jayega — aapke computer pe.
      </p>
      <p class="text-muted small">
        ⚠️ Ye sirf ek <strong>on-demand download</strong> hai — koi automatic schedule nahi hai, aur is se <strong>kabhi bhi kuch delete nahi hota</strong>. Sara data hamesha server pe hi rehta hai jab tak aap khud, manually, phpMyAdmin se delete na karo.
      </p>
      <a href="?download=1" class="btn btn-primary" style="background:<?= BRAND_PRIMARY_COLOR ?>;border:none;">⬇ Download Full Backup (.sql)</a>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
