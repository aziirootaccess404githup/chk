<?php
require_once __DIR__ . '/../includes/auth.php';

// Only Superadmin can manage team members
$myRole = $_SESSION['admin_role'] ?? 'Viewer';
if ($myRole !== 'Superadmin') {
    flash_set('Only Superadmin can manage team members.', 'danger');
    redirect('dashboard.php');
}

$edit = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT id, name, email, role FROM admin_users WHERE id=?");
    $stmt->execute([(int)$_GET['edit']]);
    $edit = $stmt->fetch();
}

if (isset($_GET['delete'])) {
    $delId = (int)$_GET['delete'];
    if ($delId === (int)$_SESSION['admin_id']) {
        flash_set("You can't delete your own account.", 'danger');
    } else {
        $pdo->prepare("DELETE FROM admin_users WHERE id=?")->execute([$delId]);
        flash_set('Team member deleted.');
    }
    redirect('team.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id       = (int)($_POST['id'] ?? 0);
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $role     = $_POST['role'] ?? 'Viewer';
    $password = $_POST['password'] ?? '';

    if ($id) {
        if ($password !== '') {
            $pdo->prepare("UPDATE admin_users SET name=?, email=?, role=?, password=? WHERE id=?")
                ->execute([$name, $email, $role, password_hash($password, PASSWORD_DEFAULT), $id]);
        } else {
            $pdo->prepare("UPDATE admin_users SET name=?, email=?, role=? WHERE id=?")
                ->execute([$name, $email, $role, $id]);
        }
        flash_set('Team member updated.');
    } else {
        if ($password === '') {
            flash_set('Password is required for a new team member.', 'danger');
            redirect('team.php');
        }
        try {
            $pdo->prepare("INSERT INTO admin_users (name, email, password, role) VALUES (?,?,?,?)")
                ->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), $role]);
            flash_set('Team member added.');
        } catch (PDOException $e) {
            flash_set('That email is already in use.', 'danger');
        }
    }
    redirect('team.php');
}

$team = $pdo->query("SELECT id, name, email, role, created_at FROM admin_users ORDER BY id")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card-panel mt-4">
  <div class="panel-header d-flex justify-content-between align-items-center">
    <span>Team Management</span>
    <button class="btn btn-light btn-sm" onclick="document.getElementById('teamModal').style.display='flex'">+ Add Team Member</button>
  </div>
  <div class="panel-body">
    <div class="table-responsive">
    <table class="table table-hover datatable align-middle">
      <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Role</th><th>Added On</th><th>Action</th></tr></thead>
      <tbody>
      <?php foreach ($team as $i => $t): ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td><?= e($t['name']) ?></td>
          <td><?= e($t['email']) ?></td>
          <td><span class="badge bg-<?= $t['role']==='Superadmin'?'danger':($t['role']==='Manager'?'primary':'secondary') ?>"><?= e($t['role']) ?></span></td>
          <td><?= date('Y-m-d', strtotime($t['created_at'])) ?></td>
          <td class="text-nowrap">
            <button class="btn btn-primary btn-sm" onclick='openTeamModal(<?= json_encode($t) ?>)'><i class="bi bi-pencil"></i></button>
            <?php if ((int)$t['id'] !== (int)$_SESSION['admin_id']): ?>
            <a href="team.php?delete=<?= $t['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this team member?')"><i class="bi bi-x-lg"></i></a>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  </div>
</div>

<!-- Add/Edit Team Member Modal -->
<div id="teamModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);align-items:center;justify-content:center;z-index:1050">
  <div style="background:#fff;border-radius:12px;padding:28px;width:100%;max-width:440px">
    <h5 class="mb-3" id="teamModalTitle">Add Team Member</h5>
    <form method="POST">
      <input type="hidden" name="id" id="team_id" value="">
      <div class="mb-2">
        <label class="form-label">Name</label>
        <input type="text" name="name" id="team_name" class="form-control" required>
      </div>
      <div class="mb-2">
        <label class="form-label">Email</label>
        <input type="email" name="email" id="team_email" class="form-control" required>
      </div>
      <div class="mb-2">
        <label class="form-label">Role</label>
        <select name="role" id="team_role" class="form-select">
          <option value="Superadmin">Superadmin</option>
          <option value="Manager">Manager</option>
          <option value="Viewer">Viewer</option>
        </select>
      </div>
      <div class="mb-3">
        <label class="form-label">Password <span class="text-muted small" id="team_pw_hint">(leave blank to keep unchanged)</span></label>
        <input type="password" name="password" id="team_password" class="form-control" placeholder="••••••••">
      </div>
      <div class="d-flex justify-content-end gap-2">
        <button type="button" class="btn btn-light" onclick="document.getElementById('teamModal').style.display='none'">Cancel</button>
        <button type="submit" class="btn btn-primary" style="background:<?= BRAND_PRIMARY_COLOR ?>;border:none">Save</button>
      </div>
    </form>
  </div>
</div>

<script>
function openTeamModal(data) {
  data = data || {};
  document.getElementById('teamModalTitle').textContent = data.id ? 'Edit Team Member' : 'Add Team Member';
  document.getElementById('team_id').value = data.id || '';
  document.getElementById('team_name').value = data.name || '';
  document.getElementById('team_email').value = data.email || '';
  document.getElementById('team_role').value = data.role || 'Viewer';
  document.getElementById('team_password').value = '';
  document.getElementById('team_pw_hint').style.display = data.id ? 'inline' : 'none';
  document.getElementById('teamModal').style.display = 'flex';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
