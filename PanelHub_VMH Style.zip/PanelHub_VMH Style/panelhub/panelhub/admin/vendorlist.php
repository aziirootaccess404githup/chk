<?php
require_once __DIR__ . '/../includes/auth.php';
ensure_extra_columns($pdo);

$edit = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM vendors WHERE id=?");
    $stmt->execute([(int)$_GET['edit']]);
    $edit = $stmt->fetch();
}
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM vendors WHERE id=?")->execute([(int)$_GET['delete']]);
    flash_set('Vendor deleted.');
    redirect('vendorlist.php');
}
// Pause / Resume vendor - blocks (or unblocks) this vendor across every project at once
if (isset($_GET['toggle_status'])) {
    $vid = (int)$_GET['toggle_status'];
    $cur = $pdo->prepare("SELECT status FROM vendors WHERE id=?");
    $cur->execute([$vid]);
    $newStatus = $cur->fetchColumn() === 'Active' ? 'Inactive' : 'Active';
    $pdo->prepare("UPDATE vendors SET status=? WHERE id=?")->execute([$newStatus, $vid]);
    flash_set('Vendor ' . ($newStatus === 'Active' ? 'resumed.' : 'paused.'));
    redirect('vendorlist.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $data = [
        'name' => trim($_POST['name']),
        'email' => trim($_POST['email']),
        'contact_person' => trim($_POST['contact_person']),
        'phone' => trim($_POST['phone']),
        'complete_url' => trim($_POST['complete_url']),
        'terminate_url' => trim($_POST['terminate_url']),
        'screenout_url' => trim($_POST['screenout_url']),
        'quotafull_url' => trim($_POST['quotafull_url']),
    ];
    if ($id) {
        $data['id'] = $id;
        $pdo->prepare("UPDATE vendors SET name=:name, email=:email, contact_person=:contact_person, phone=:phone, complete_url=:complete_url,
          terminate_url=:terminate_url, screenout_url=:screenout_url, quotafull_url=:quotafull_url WHERE id=:id")->execute($data);
        flash_set('Vendor updated.');
    } else {
        $data['vid'] = generate_uid('VI');
        $pdo->prepare("INSERT INTO vendors (vid, name, email, contact_person, phone, complete_url, terminate_url, screenout_url, quotafull_url)
          VALUES (:vid, :name, :email, :contact_person, :phone, :complete_url, :terminate_url, :screenout_url, :quotafull_url)")->execute($data);
        flash_set('Vendor created.');
    }
    redirect('vendorlist.php');
}

$vendors = $pdo->query("SELECT * FROM vendors ORDER BY id ASC")->fetchAll();
require_once __DIR__ . '/../includes/header.php';
?>

<div class="card-panel mt-4">
  <div class="panel-header">Vendor</div>
  <div class="panel-body">
    <form method="post">
      <input type="hidden" name="id" value="<?= $edit['id'] ?? '' ?>">
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Vendor name</label>
          <input type="text" name="name" class="form-control" required value="<?= e($edit['name'] ?? '') ?>" placeholder="Enter Vendor Name">
        </div>
        <div class="col-md-6">
          <label class="form-label">Vendor email</label>
          <input type="email" name="email" class="form-control" value="<?= e($edit['email'] ?? '') ?>" placeholder="Enter Vendor Email">
        </div>
        <div class="col-md-6">
          <label class="form-label">Contact Person</label>
          <input type="text" name="contact_person" class="form-control" value="<?= e($edit['contact_person'] ?? '') ?>" placeholder="Enter Contact Person Name">
        </div>
        <div class="col-md-6">
          <label class="form-label">Phone</label>
          <input type="text" name="phone" class="form-control" value="<?= e($edit['phone'] ?? '') ?>" placeholder="Enter Phone Number">
        </div>
        <div class="col-md-6">
          <label class="form-label">Complete URL <span class="text-muted small">(optional tokens auto-replaced: uid/rid/toid, pid/sid/studyid, loi, ip, date, timestamp, status — in {{ }}, [ ], { }, %% %%, &lt;&gt;, or $ $ style. Anything else is left as plain text.)</span></label>
          <input type="text" name="complete_url" class="form-control" value="<?= e($edit['complete_url'] ?? '') ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Terminate URL</label>
          <input type="text" name="terminate_url" class="form-control" value="<?= e($edit['terminate_url'] ?? '') ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Screenout URL</label>
          <input type="text" name="screenout_url" class="form-control" value="<?= e($edit['screenout_url'] ?? '') ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Quotafull URL</label>
          <input type="text" name="quotafull_url" class="form-control" value="<?= e($edit['quotafull_url'] ?? '') ?>">
        </div>
      </div>
      <button class="btn btn-primary mt-3" style="background:<?= BRAND_PRIMARY_COLOR ?>;border:none;">Save</button>
    </form>
  </div>
</div>

<div class="card-panel mt-3">
  <div class="panel-header">Vendor List</div>
  <div class="panel-body">
    <div class="table-responsive">
    <table class="table table-hover datatable align-middle">
      <thead><tr><th>SI No.</th><th>Vendor ID</th><th>Name</th><th>Email</th><th>Status</th>
        <th>Complete</th><th>Terminate</th><th>Screenout</th><th>Quotafull</th><th>Action</th></tr></thead>
      <tbody>
      <?php foreach ($vendors as $i => $v): ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td><a href="vendor/view.php?id=<?= $v['id'] ?>"><?= e($v['vid']) ?></a></td>
          <td><?= e($v['name']) ?></td>
          <td><?= e($v['email']) ?></td>
          <td><span class="badge bg-<?= ($v['status'] ?? 'Active')==='Active'?'success':'secondary' ?>"><?= e($v['status'] ?? 'Active') ?></span></td>
          <td class="small"><?= e($v['complete_url']) ?></td>
          <td class="small"><?= e($v['terminate_url']) ?></td>
          <td class="small"><?= e($v['screenout_url']) ?></td>
          <td class="small"><?= e($v['quotafull_url']) ?></td>
          <td class="text-nowrap">
            <a href="vendorlist.php?edit=<?= $v['id'] ?>" class="btn btn-primary btn-sm"><i class="bi bi-pencil"></i></a>
            <a href="vendor/view.php?id=<?= $v['id'] ?>" class="btn btn-info btn-sm text-white"><i class="bi bi-eye"></i></a>
            <a href="vendorlist.php?toggle_status=<?= $v['id'] ?>" class="btn btn-sm <?= ($v['status'] ?? 'Active')==='Active'?'btn-warning':'btn-success' ?>" onclick="return confirm('<?= ($v['status'] ?? 'Active')==='Active'?'Pause':'Resume' ?> this vendor across all projects?')"><?= ($v['status'] ?? 'Active')==='Active'?'⏸':'▶' ?></a>
            <a href="vendorlist.php?delete=<?= $v['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this vendor?')"><i class="bi bi-x-lg"></i></a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
