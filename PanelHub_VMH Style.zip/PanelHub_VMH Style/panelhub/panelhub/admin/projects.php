<?php
require_once __DIR__ . '/../includes/auth.php';

if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM projects WHERE id = ?");
    $stmt->execute([(int)$_GET['delete']]);
    flash_set('Project deleted.');
    redirect('projects.php');
}

$projects = $pdo->query("
  SELECT p.*, c.name AS client_name,
    (SELECT COUNT(*) FROM leads WHERE project_id=p.id AND status='Complete') AS completes,
    (SELECT COUNT(*) FROM leads WHERE project_id=p.id AND status='Terminates') AS terminates
  FROM projects p LEFT JOIN clients c ON c.id = p.client_id
  ORDER BY p.id DESC
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card-panel mt-4">
  <div class="panel-header">
    Projects List
    <a href="project/addedit.php" class="btn btn-light btn-sm"><i class="bi bi-plus-lg"></i> ADD</a>
  </div>
  <div class="panel-body">
    <div class="table-responsive">
    <table class="table table-hover datatable align-middle">
      <thead><tr>
        <th>Sl No.</th><th>Project Name</th><th>Client</th><th>PID</th><th>Status</th>
        <th>CPI</th><th>IR</th><th>LOI</th><th>Completes</th><th>Terminates</th><th>Action</th>
      </tr></thead>
      <tbody>
      <?php foreach ($projects as $i => $p): ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td><?= e($p['project_name']) ?></td>
          <td><?= e($p['client_name']) ?></td>
          <td><?= e($p['pid']) ?></td>
          <td><?= status_badge($p['status']) ?></td>
          <td><?= number_format($p['cpi'],2) ?></td>
          <td><?= number_format($p['ir'],2) ?></td>
          <td><?= (int)$p['loi'] ?></td>
          <td><?= (int)$p['completes'] ?></td>
          <td><?= (int)$p['terminates'] ?></td>
          <td>
            <a href="project/addedit.php?id=<?= $p['id'] ?>" class="btn btn-primary btn-sm"><i class="bi bi-pencil"></i></a>
            <a href="project/view.php?id=<?= $p['id'] ?>" class="btn btn-info btn-sm text-white"><i class="bi bi-eye"></i></a>
            <a href="projects.php?delete=<?= $p['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this project?')"><i class="bi bi-x-lg"></i></a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
