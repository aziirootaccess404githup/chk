# PanelHub — Survey Panel Admin System

Ek complete, self-hosted survey panel / fieldwork tracking system — jaisa VMH-style admin panel
tumne dikhaya tha, waisa hi (look, feel, aur functioning), sirf generic branding ke saath.

## Kya-kya hai isme (VMH wale panel se 1:1 mapping)

| VMH Panel | PanelHub |
|---|---|
| Dashboard (stat cards + click chart) | `admin/dashboard.php` |
| Client List / Add-Edit / View + redirect URLs | `admin/client.php`, `admin/client/addedit.php`, `admin/client/view.php` |
| Projects List / Add-Edit / View + Study Params + Vendor Assign | `admin/projects.php`, `admin/project/addedit.php`, `admin/project/view.php` |
| Leads (global log) | `admin/leads.php` |
| Vendor List + global redirect templates | `admin/vendorlist.php` |
| Vendor Details (stats + entry link + per-vendor leads) | `admin/vendor/view.php` |
| Entry link (respondent click tracking) | `public/entry.php` |
| Complete/Terminate/Screenout/Quotafull redirects | `public/callback.php` |

## Setup (Hostinger / cPanel / any PHP+MySQL host)

1. **Database**: phpMyAdmin mein `db.sql` import kar do. Isme demo data bhi hai (ek client,
   vendor, project) taaki turant test kar sako — chaho toh delete kar dena baad mein.

2. **Config**: `includes/config.php` khol ke top ka `BRAND CONFIG` block edit karo —
   - `BRAND_NAME`, `BRAND_TAGLINE`, `BRAND_PRIMARY_COLOR`, `BRAND_SUPPORT_EMAIL`
   - `BASE_URL` — jahan bhi deploy karo wahan ka full URL bina trailing slash ke
     (e.g. `https://panel.yourcompany.com`)
   - `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS` — apne hosting ke MySQL credentials

3. **Upload**: poora folder apne server pe daal do (public_html ya subdomain root mein).

4. **Login**: `https://yourdomain.com/admin/login.php`
   - Email: `admin@yourcompany.com`
   - Password: `Admin@123`
   - **Turant password change kar lena** — abhi koi "change password" UI nahi hai, seedha
     DB mein `admin_users` table ka `password` column update karo naye bcrypt hash se, ya
     mujhse bolo main add kar dunga.

## Placeholder syntax (important)

Vendor aur Project ke redirect/live URL fields **plain text hain** — jo bhi vendor apni link de,
wahi as-is paste kar do. Agar us URL mein `{{uid}}` ya `{{pid}}` token daaloge, system automatically
usse respondent ki asli UID / project ke PID se replace kar dega. Agar koi token nahi daala, URL bilkul
waisa hi (literal) use hoga — koi force substitution nahi hoti.

Example:
- `https://vendor.com/callback?status=complete&uid={{uid}}` → token replace hoga
- `https://vendor.com/go/success?hash=myaccount123` → as-is chala jayega, kuch replace nahi hoga

## Respondent flow (kaise kaam karta hai)

1. Project view page pe har assigned vendor ka ek **Entry Link** hota hai:
   `public/entry.php?pid=PID&vid=VID&uid=xxxx` — vendor `xxxx` ki jagah apna respondent UID daalega.
2. Click hone pe lead **Pending** status se log hota hai, aur respondent project ke **Live URL**
   pe redirect ho jaata hai (uid pass hota hai).
3. Survey khatam hone pe survey-tool `public/callback.php?pid=..&vid=..&uid=..&status=complete`
   (ya terminate/screenout/quotafull) pe hit karta hai.
4. System status **lock** kar deta hai (first-write-wins, duplicate/fraud proof) aur respondent
   ko **vendor ke apne redirect URL** pe bhej deta hai (agar vendor-level set nahi hai, toh
   client-level fallback use hota hai).

## Kya cheezein aage add karni ho sakti hain (abhi minimal/missing rakha jaanbujh ke)

- Change password / forgot password UI
- Role-based access (Manager/Viewer restrictions) — DB column already hai (`admin_users.role`)
- Bulk email, sales commission tracker, bidding tool (jaisa tumhare ExaVerify roadmap mein hai)
- Scheduled client reports

Bolo agar in mein se koi turant chahiye — add kar dunga.
