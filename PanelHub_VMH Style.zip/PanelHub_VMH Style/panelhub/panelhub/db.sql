-- =====================================================
-- PanelHub Database Schema
--
-- IMPORTANT (Hostinger / shared hosting): create the database first via
-- hPanel -> Databases -> MySQL Databases (you cannot CREATE DATABASE
-- yourself there). Then open phpMyAdmin, SELECT that database from the
-- left sidebar, and Import this file into it.
-- =====================================================

-- ---------- Admin Users ----------
CREATE TABLE `admin_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('Superadmin','Manager','Viewer') DEFAULT 'Superadmin',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Default login: admin@yourcompany.com / Admin@123
INSERT INTO `admin_users` (`name`,`email`,`password`,`role`) VALUES
('Admin User','admin@yourcompany.com','$2y$10$zCg3/w3./inXEBuCIFRXYeSTEfkXWKQ7L4LMsUX7E/aPQwckGfJlW','Superadmin');
-- NOTE: hash above is bcrypt('Admin@123') - verified working with PHP password_verify()

-- ---------- Clients ----------
CREATE TABLE `clients` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `client_uid` VARCHAR(64) NOT NULL UNIQUE,      -- public-facing id; the 3 redirect URLs are built from this
  `name` VARCHAR(150) NOT NULL,
  `contact_person` VARCHAR(150) NULL,
  `email` VARCHAR(150) NULL,
  `phone` VARCHAR(50) NULL,
  `description` TEXT NULL,
  `status` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------- Projects ----------
CREATE TABLE `projects` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `pid` VARCHAR(64) NOT NULL UNIQUE,             -- e.g. PHUB026172026
  `client_id` INT NOT NULL,
  `project_name` VARCHAR(200) NOT NULL,
  `cpi` DECIMAL(10,2) DEFAULT 0,
  `max_completes` INT DEFAULT 0,
  `loi` INT DEFAULT 0,                            -- length of interview (minutes)
  `ir` DECIMAL(5,2) DEFAULT 0,                     -- incidence rate %
  `live_url` VARCHAR(500) NULL,
  `status` ENUM('Live','Pause','Closed') DEFAULT 'Pause',
  `description` TEXT NULL,                        -- rich-text (CKEditor); admin can paste a study-parameters
                                                    -- table here manually, exactly like the original panel
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`client_id`) REFERENCES `clients`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Vendors (master list, global redirect templates) ----------
CREATE TABLE `vendors` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `vid` VARCHAR(64) NOT NULL UNIQUE,             -- e.g. VI010032026
  `name` VARCHAR(150) NOT NULL,
  `email` VARCHAR(150) NULL,
  `contact_person` VARCHAR(150) NULL,
  `phone` VARCHAR(50) NULL,
  `complete_url` VARCHAR(500) NULL,               -- may contain {{uid}} {{pid}} tokens - optional, plain literal URLs work too
  `terminate_url` VARCHAR(500) NULL,
  `screenout_url` VARCHAR(500) NULL,
  `quotafull_url` VARCHAR(500) NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------- Project <-> Vendor assignment ----------
CREATE TABLE `project_vendors` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `project_id` INT NOT NULL,
  `vendor_id` INT NOT NULL,
  `cpi` DECIMAL(10,2) DEFAULT 0,
  `daily_limit` INT DEFAULT 0,
  `status` ENUM('Live','Pause') DEFAULT 'Live',
  `clicks` INT DEFAULT 0,
  `completes` INT DEFAULT 0,
  `terminates` INT DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uniq_proj_vendor` (`project_id`,`vendor_id`),
  FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`vendor_id`) REFERENCES `vendors`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Leads (every respondent hit) ----------
CREATE TABLE `leads` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `project_id` INT NOT NULL,
  `vendor_id` INT NULL,
  `uid` VARCHAR(100) NOT NULL,                    -- respondent unique id from vendor
  `status` ENUM('Pending','Complete','Terminates','Screenout','Quota Full') DEFAULT 'Pending',
  `ip` VARCHAR(45) NULL,
  `user_agent` VARCHAR(255) NULL,
  `is_locked` TINYINT(1) DEFAULT 0,                -- first-write-wins status lock
  `loi_seconds` INT NULL,                          -- real elapsed time (seconds) from click to final status
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY (`project_id`), KEY (`vendor_id`), KEY(`uid`),
  FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`vendor_id`) REFERENCES `vendors`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------- Audit Log (for the "LOG" button on Client edit) ----------
CREATE TABLE `audit_log` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `entity_type` VARCHAR(50) NOT NULL,     -- e.g. 'client'
  `entity_id` INT NOT NULL,
  `action` VARCHAR(20) NOT NULL,          -- 'created' | 'updated'
  `admin_id` INT NULL,
  `admin_name` VARCHAR(100) NULL,
  `details` TEXT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY (`entity_type`, `entity_id`)
) ENGINE=InnoDB;

-- =====================================================
-- OPTIONAL: demo seed data so you can see it working
-- immediately. Safe to delete these 4 inserts anytime.
-- =====================================================
INSERT INTO `clients` (`client_uid`,`name`,`description`,`status`) VALUES
('CL1A2B3C4D5E6F7G','Demo Client Inc','Sample client for testing.',1);

INSERT INTO `vendors` (`vid`,`name`,`email`,`complete_url`,`terminate_url`,`screenout_url`,`quotafull_url`) VALUES
('VI0000001','Demo Vendor','vendor@example.com',
 'https://vendor-example.com/callback?status=complete&uid={{uid}}',
 'https://vendor-example.com/callback?status=terminate&uid={{uid}}',
 'https://vendor-example.com/callback?status=screenout&uid={{uid}}',
 'https://vendor-example.com/callback?status=quotafull&uid={{uid}}');

INSERT INTO `projects` (`pid`,`client_id`,`project_name`,`cpi`,`max_completes`,`loi`,`ir`,`live_url`,`status`,`description`) VALUES
('PHUB000001',1,'Demo Survey Project',1.50,200,12,45,
 'https://survey-example.com/start?uid={{uid}}','Live',
 '<table border="1" cellpadding="6"><tr><th colspan="2">STUDY PARAMETERS — PHUB000001</th></tr>
 <tr><td>Market / Country</td><td>IN</td></tr>
 <tr><td>Target Audience</td><td>General population, 18+</td></tr>
 <tr><td>Age Range</td><td>18+ Male/Female</td></tr>
 <tr><td>Sample Size (N)</td><td>200 N</td></tr>
 <tr><td>Device Compatibility</td><td>Desktop/Laptop/Mobile</td></tr></table>
 <p>Sample project created automatically for testing the panel end to end.</p>');

INSERT INTO `project_vendors` (`project_id`,`vendor_id`,`cpi`,`daily_limit`,`status`) VALUES (1,1,1.50,200,'Live');
