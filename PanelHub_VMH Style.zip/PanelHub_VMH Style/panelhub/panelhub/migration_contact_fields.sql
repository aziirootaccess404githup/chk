-- =====================================================
-- MIGRATION: adds Contact Person / Phone (Vendor + Client) and
-- Email (Client) fields to an EXISTING database.
-- Run this once in phpMyAdmin -> your database -> SQL tab.
-- Safe to run even if some columns already exist (uses IF NOT EXISTS
-- guards where MySQL version supports it; if your MySQL is older and
-- errors on a line that already applied, just skip that one line and
-- re-run the rest).
-- =====================================================

ALTER TABLE `clients` ADD COLUMN `contact_person` VARCHAR(150) NULL AFTER `name`;
ALTER TABLE `clients` ADD COLUMN `email` VARCHAR(150) NULL AFTER `contact_person`;
ALTER TABLE `clients` ADD COLUMN `phone` VARCHAR(50) NULL AFTER `email`;

ALTER TABLE `vendors` ADD COLUMN `contact_person` VARCHAR(150) NULL AFTER `email`;
ALTER TABLE `vendors` ADD COLUMN `phone` VARCHAR(50) NULL AFTER `contact_person`;
