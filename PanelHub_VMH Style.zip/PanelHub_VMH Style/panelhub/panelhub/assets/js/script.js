document.addEventListener('DOMContentLoaded', function () {
  const btn = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('sidebar');
  if (btn) {
    btn.addEventListener('click', () => sidebar.classList.toggle('show'));
  }

  // Auto-init any table with class "datatable"
  if (window.jQuery && $.fn.DataTable) {
    $('.datatable').DataTable({ pageLength: 10 });
  }
});

function copyToClipboard(text, btn) {
  navigator.clipboard.writeText(text).then(function () {
    if (btn) {
      const old = btn.innerHTML;
      btn.innerHTML = '<i class="bi bi-check2"></i>';
      setTimeout(() => btn.innerHTML = old, 1200);
    }
  });
}
