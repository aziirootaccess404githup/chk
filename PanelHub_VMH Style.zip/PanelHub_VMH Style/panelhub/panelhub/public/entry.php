<?php
/**
 * Vendor Entry Link:  entry.php?pid=PHUB026172026&vid=VI010032025&uid=RESPONDENT_UID
 * Logs the click as a Pending lead and redirects the respondent into the live survey URL.
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
ensure_extra_columns($pdo);

$pid = $_GET['pid'] ?? '';
$vid = $_GET['vid'] ?? '';
$uid = $_GET['uid'] ?? '';

if (!$pid || !$uid || $uid === 'xxxx') {
    http_response_code(400);
    die('Invalid or missing parameters.');
}

$stmt = $pdo->prepare("SELECT * FROM projects WHERE pid = ?");
$stmt->execute([$pid]);
$project = $stmt->fetch();
if (!$project) { http_response_code(404); die('Project not found.'); }

$vendor = null;
if ($vid) {
    $stmt = $pdo->prepare("SELECT * FROM vendors WHERE vid = ?");
    $stmt->execute([$vid]);
    $vendor = $stmt->fetch();

    // Global vendor pause - blocks this vendor across EVERY project at once,
    // checked before the more granular per-project-assignment pause below.
    if ($vendor && ($vendor['status'] ?? 'Active') === 'Inactive') {
        http_response_code(403);
        die('<h3>This survey link is currently paused. Please contact your panel manager.</h3>');
    }
    if ($vendor) {
        $pv = $pdo->prepare("SELECT status FROM project_vendors WHERE project_id=? AND vendor_id=? LIMIT 1");
        $pv->execute([$project['id'], $vendor['id']]);
        if ($pv->fetchColumn() === 'Pause') {
            http_response_code(403);
            die('<h3>This survey link is currently paused for this vendor. Please contact your panel manager.</h3>');
        }
    }
}

// Geo lookup - stored once per lead, on first click
$ip = get_client_ip();
$geo = geo_lookup($ip);

// Encrypt the UID if this project has encryption turned on - the RAW uid is
// never sent onward in that case, only the opaque token is (and only the
// token is what gets stored/displayed as "the" UID from here on).
$outgoing_uid = $uid;
if (!empty($project['encrypt_uid'])) {
    $outgoing_uid = encrypt_uid($pdo, $uid, $project['id']);
}

// Insert lead (Pending) if this UID hasn't already been seen for this project
$check = $pdo->prepare("SELECT id FROM leads WHERE project_id = ? AND uid = ?");
$check->execute([$project['id'], $uid]);
$existing = $check->fetch();

if (!$existing) {
    $pdo->prepare("INSERT INTO leads (project_id, vendor_id, uid, encrypted_uid, status, ip, country, city, user_agent) VALUES (?,?,?,?,?,?,?,?,?)")
        ->execute([$project['id'], $vendor['id'] ?? null, $uid, $outgoing_uid, 'Pending', $ip, $geo['country'], $geo['city'], $_SERVER['HTTP_USER_AGENT'] ?? '']);

    if ($vendor) {
        $pdo->prepare("UPDATE project_vendors SET clicks = clicks + 1 WHERE project_id=? AND vendor_id=?")
            ->execute([$project['id'], $vendor['id']]);
    }
}

// Build the callback URL that the survey tool should hit when respondent finishes
$callbackBase = BASE_URL . "/public/callback.php?pid=" . urlencode($pid) . "&vid=" . urlencode($vid) . "&uid=" . urlencode($outgoing_uid);

// Redirect respondent into the live survey, passing uid + our callback url
$liveUrl = build_vendor_url($project['live_url'], build_token_set(urlencode($outgoing_uid), $pid, [
    'country' => $geo['country'], 'city' => $geo['city'], 'vid' => $vid,
]));
if (!$liveUrl) { die('Live URL not configured for this project.'); }

$sep = (strpos($liveUrl, '?') !== false) ? '&' : '?';
redirect($liveUrl . $sep . 'callback=' . urlencode($callbackBase));
