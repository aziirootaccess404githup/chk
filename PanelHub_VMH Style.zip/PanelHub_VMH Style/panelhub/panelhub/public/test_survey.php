<?php
/**
 * ============================================================================
 * TEST SURVEY SIMULATOR — v2 (multi-engine)
 * ============================================================================
 * This is NOT part of any real product - it's a stand-in for a real survey
 * tool, so you can test the entire click -> survey -> callback -> redirect
 * loop yourself without needing an actual live survey.
 *
 * It auto-detects which system sent the respondent here and calls that
 * system back the correct way:
 *
 *   MODE 1 - PanelHub style (this repo's own public/entry.php + callback.php)
 *     Detected when a `callback` param is present.
 *     Example incoming URL:
 *       test_survey.php?uid=XXXX&callback=https://panel.yourcompany.com/public/callback.php?pid=..%26vid=..%26uid=XXXX
 *     On button click, appends &status=complete|terminate|screenout|quotafull
 *     to that callback URL and redirects there.
 *
 *   MODE 2 - Azilytics / PanelEngine style (track.php)
 *     Detected when a `sid` param is present (no `callback` param).
 *     Example incoming URL:
 *       test_survey.php?uid=XXXX&sid=YOUR_SID&track_url=https://hub.azilyticsinsights.com/track.php
 *     On button click, redirects to:
 *       {track_url}?status=complete|terminate|overquota|quality_fail&sid=..&uid=..&loi=<real_elapsed_seconds>
 *     `track_url` must be passed in explicitly (this file makes no assumption
 *     about which domain your Azilytics/PanelEngine instance lives on).
 *
 * If it can't detect either mode (missing callback AND missing sid+track_url),
 * it shows a warning screen instead of guessing.
 *
 * HOW TO USE (PanelHub):
 *   Project Live URL = https://panel.yourcompany.com/public/test_survey.php?uid={{uid}}
 *
 * HOW TO USE (Azilytics / PanelEngine):
 *   Project Live URL = https://hub.azilyticsinsights.com/.../whatever-your-prescreener-uses...
 *   -> eventually redirects into a survey whose "Live URL" is set to:
 *      https://panel.yourcompany.com/public/test_survey.php?uid=[UID]&sid=[SID]&track_url=https://hub.azilyticsinsights.com/track.php
 *
 * Real elapsed LOI is measured client-side in JS from the moment this page
 * loads until a button is clicked, in whole seconds - matching how a real
 * survey would report it.
 * ============================================================================
 *
 * ─────────────────────────────────────────────────────────────────────────
 * PLACEHOLDER / TOKEN REFERENCE (industry-wide, not just this project)
 * ─────────────────────────────────────────────────────────────────────────
 * Different survey/panel systems wrap their dynamic tokens in different
 * bracket styles. There is NO universal standard - each vendor/platform
 * picks their own. The ones actually confirmed in this project's own
 * systems are marked [CONFIRMED]; the rest are common conventions seen
 * across the market-research industry generally, listed for reference so
 * you recognize them if a new vendor sends you a link using them.
 *
 * BRACKET STYLES SEEN IN THE WILD:
 *   [TOKEN]      Square brackets   - Azilytics/PanelEngine [CONFIRMED], Dynata, Lucid, many others
 *   {{token}}    Double curly      - VMH-style panel [CONFIRMED], Handlebars-style APIs, some modern tools
 *   {token}      Single curly      - some older/legacy panel systems
 *   %TOKEN%      Percent-wrapped   - some legacy/Windows-influenced systems
 *   <token>      Angle brackets    - rare, some XML-influenced systems
 *   $token$      Dollar-wrapped    - rare, seen on a handful of custom platforms
 *
 * COMMON TOKEN NAMES (what they usually mean):
 *   UID / RID / TOID / IDENTIFIER / TID / RESPID / PANELISTID   -> respondent's unique ID [CONFIRMED: uid,rid,toid,identifier,tid in this project's track.php fallback chain]
 *   PID / SID / STUDYID / SURVEYID / PROJECTID                  -> project/study identifier [CONFIRMED: pid (PanelHub), sid (Azilytics)]
 *   STATUS / DISPOSITION / OUTCOME                               -> completion status
 *   LOI / DURATION / TIME                                        -> length of interview [CONFIRMED: loi, in SECONDS for Azilytics]
 *   IP / IPADDRESS                                                -> respondent's IP address [CONFIRMED: capture.php replaces [IP]]
 *   HASH / TOKEN / SIGNATURE / SEC                                -> security/verification hash
 *   SOURCE / VENDOR / SUPPLIER / PARTNERID / PANELID              -> which vendor/panel sent this respondent
 *   COUNTRY / LOCALE / LANG                                       -> respondent locale
 *   DEVICE / DEVICETYPE                                           -> desktop/mobile/tablet
 *   GENDER / AGE / AGEVAL / GENDERVAL / EDUCATION / INCOME / REGION -> demographics [CONFIRMED: capture.php replaces all of these]
 *   QUOTA / QUOTAID / CELL / CELLID                                -> which quota cell the respondent fell into
 *   CLICKID / GCLID                                                -> marketing-style click tracking id (rare in survey routing, common in ad platforms)
 *   REF / REFERRER                                                 -> where the click came from
 *   TXNID / TRANSACTION_ID                                         -> a one-off transaction/session id some platforms issue
 *   SESSIONID                                                      -> session identifier
 *   REASON / TERMCODE / QUALCODE / SCREENOUT_REASON                -> WHY a respondent was terminated/screened out (specific question/code)
 *   TIMESTAMP / STARTTIME / ENDTIME                                -> raw time values some platforms want instead of a computed LOI
 *
 * This project (PanelHub) currently only auto-replaces: {{uid}} {{pid}} {{loi}}
 * and [UID] [PID] [LOI] (see includes/functions.php -> build_vendor_url()).
 * Anything else in the list above, if a vendor's URL needs it, is NOT yet
 * auto-substituted - it would need to be added to that function first.
 * ─────────────────────────────────────────────────────────────────────────
 */

$uid       = $_GET['uid'] ?? '';
$callback  = $_GET['callback'] ?? '';
$sid       = $_GET['sid'] ?? '';
$track_url = $_GET['track_url'] ?? '';

// Guard: catch un-substituted placeholders landing here literally (a common
// real mistake - the calling system didn't actually replace its own token).
$looksUnsubstituted = function ($v) {
    return $v !== '' && (preg_match('/^\[.+\]$/', $v) || preg_match('/^\{\{.+\}\}$/', $v) || preg_match('/^\{.+\}$/', $v));
};

$mode = null;
if ($callback) {
    $mode = 'panelhub';
} elseif ($sid && $track_url) {
    $mode = 'azilytics';
}

$warning = '';
if ($looksUnsubstituted($uid))  $warning .= "The uid parameter still looks like a literal placeholder ($uid) - the system that sent you here didn't replace its own token.<br>";
if ($looksUnsubstituted($sid))  $warning .= "The sid parameter still looks like a literal placeholder ($sid).<br>";
if (!$uid) $warning .= "No uid parameter received at all.<br>";
if (!$mode) $warning .= "Could not detect a mode - need either &callback=... (PanelHub) or &sid=...&track_url=... (Azilytics/PanelEngine).<br>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Test Survey Simulator</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body{font-family:Arial,sans-serif;background:#f4f6fb;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:20px;}
  .box{background:#fff;padding:36px;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,.1);max-width:560px;text-align:center;}
  h2{margin-top:0;}
  .uid{background:#f0f2fb;padding:8px 12px;border-radius:6px;font-family:monospace;display:inline-block;margin:6px 0;word-break:break-all;}
  .mode{display:inline-block;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;margin-bottom:16px;}
  .mode-panelhub{background:#e0e7ff;color:#3730a3;}
  .mode-azilytics{background:#dcfce7;color:#166534;}
  .btns{display:flex;flex-direction:column;gap:10px;margin-top:20px;}
  button{padding:12px;border:none;border-radius:8px;font-size:15px;cursor:pointer;color:#fff;}
  .complete{background:#12c48b;}
  .terminate{background:#e53e3e;}
  .quotafull{background:#6b7280;}
  .screenout{background:#374151;}
  .note{font-size:12px;color:#888;margin-top:20px;text-align:left;}
  .warn{background:#fff3cd;border:1px solid #ffe69c;color:#664d03;padding:12px;border-radius:8px;text-align:left;font-size:13px;margin-bottom:16px;}
  #loiDisplay{font-family:monospace;color:#666;font-size:13px;}
</style>
</head>
<body>
  <div class="box">
    <h2>🧪 Test Survey Simulator</h2>

    <?php if ($warning): ?>
      <div class="warn"><strong>⚠️ Heads up:</strong><br><?= $warning ?></div>
    <?php endif; ?>

    <?php if ($mode): ?>
      <div class="mode mode-<?= $mode ?>"><?= $mode === 'panelhub' ? 'Detected: PanelHub mode' : 'Detected: Azilytics/PanelEngine mode' ?></div>
    <?php endif; ?>

    <p>Pretend this is the real survey. Respondent UID:</p>
    <div class="uid"><?= htmlspecialchars($uid ?: '(none received)') ?></div>
    <?php if ($sid): ?><p style="margin:4px 0;">SID: <span class="uid" style="padding:2px 8px;"><?= htmlspecialchars($sid) ?></span></p><?php endif; ?>
    <p id="loiDisplay">Elapsed time on this page: <span id="loiVal">0</span>s</p>

    <?php if ($mode): ?>
    <div class="btns">
      <button class="complete" onclick="go('complete')">✅ Simulate Complete</button>
      <button class="terminate" onclick="go('terminate')">🚫 Simulate Terminate</button>
      <button class="quotafull" onclick="go('quotafull')">📊 Simulate Overquota / Quota Full</button>
      <button class="screenout" onclick="go('screenout')">⛔ Simulate Screenout / Quality Fail</button>
    </div>
    <?php else: ?>
      <p style="color:#e53e3e;">Cannot show test buttons until the mode is fixed - see warning above.</p>
    <?php endif; ?>

    <p class="note">
      This page stands in for a real survey tool. Clicking a button does exactly what a real
      survey does at the end: report the outcome back to your tracking system with the real
      elapsed time (LOI), which locks the lead status and routes the respondent onward.
      See the top of this file's source code for a full reference list of placeholder token
      styles ({{ }}, [ ], etc.) used across different systems.
    </p>
  </div>

<script>
  const pageLoadTime = Date.now();
  setInterval(() => {
    document.getElementById('loiVal').innerText = Math.floor((Date.now() - pageLoadTime) / 1000);
  }, 1000);

  function go(status) {
    const elapsedSeconds = Math.floor((Date.now() - pageLoadTime) / 1000);
    const mode = <?= json_encode($mode) ?>;

    if (mode === 'panelhub') {
      // PanelHub's callback.php expects: complete | terminate | screenout | quotafull
      const cb = <?= json_encode($callback) ?>;
      const sep = cb.includes('?') ? '&' : '?';
      window.location.href = cb + sep + 'status=' + status;

    } else if (mode === 'azilytics') {
      // Azilytics/PanelEngine track.php expects: complete | terminate | overquota | quality_fail
      const statusMap = { complete: 'complete', terminate: 'terminate', quotafull: 'overquota', screenout: 'quality_fail' };
      const azStatus = statusMap[status] || status;
      const trackUrl = <?= json_encode($track_url) ?>;
      const sid = <?= json_encode($sid) ?>;
      const uid = <?= json_encode($uid) ?>;
      const sep = trackUrl.includes('?') ? '&' : '?';
      window.location.href = trackUrl + sep + 'status=' + azStatus
        + '&sid=' + encodeURIComponent(sid)
        + '&uid=' + encodeURIComponent(uid)
        + '&loi=' + elapsedSeconds;
    }
  }
</script>
</body>
</html>
