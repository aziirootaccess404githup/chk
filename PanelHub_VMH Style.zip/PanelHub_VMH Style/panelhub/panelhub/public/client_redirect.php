<?php
/**
 * Client-level redirect entry point.
 *
 * A client only gets 3 links (Complete/Terminate/Quotafull) shown once on their
 * "Client View" page - the SAME 3 links are reused across every project of that
 * client. Because of that, this endpoint does NOT know the project up front -
 * it resolves the actual pending lead purely from the respondent UID, searching
 * across all of that client's projects for the most recent matching lead.
 *
 * client_redirect.php?client=CLIENT_UID&type=complete|terminate|screenout|quotafull&username=UID
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
ensure_extra_columns($pdo);

$clientUid = $_GET['client'] ?? '';
$type      = strtolower($_GET['type'] ?? '');
$uid       = $_GET['username'] ?? ($_GET['uid'] ?? '');

$statusMap = [
    'complete'  => 'Complete',
    'terminate' => 'Terminates',
    'screenout' => 'Screenout',
    'quotafull' => 'Quota Full',
];

if (!$clientUid || !$uid || $uid === 'xxxx' || !isset($statusMap[$type])) {
    http_response_code(400);
    die('Invalid parameters.');
}
$newStatus = $statusMap[$type];

$stmt = $pdo->prepare("SELECT * FROM clients WHERE client_uid = ?");
$stmt->execute([$clientUid]);
$client = $stmt->fetch();
if (!$client) { http_response_code(404); die('Client not found.'); }

// Search leads belonging to any project of this client, matching either the
// raw uid OR the encrypted token (whichever this project actually sent
// onward), most recent first - since this link doesn't carry a project/pid
// hint itself.
$stmt = $pdo->prepare("
  SELECT l.*, pr.pid FROM leads l
  JOIN projects pr ON pr.id = l.project_id
  WHERE pr.client_id = ? AND (l.uid = ? OR l.encrypted_uid = ?)
  ORDER BY l.id DESC LIMIT 1
");
$stmt->execute([$client['id'], $uid, $uid]);
$lead = $stmt->fetch();

$vendor = null;
$finalStatus = $newStatus;

if ($lead) {
    if (!$lead['is_locked']) {
        $pdo->prepare("UPDATE leads SET status=?, is_locked=1, loi_seconds=TIMESTAMPDIFF(SECOND, created_at, NOW()) WHERE id=?")
            ->execute([$newStatus, $lead['id']]);
        $loiSeconds = (int)$pdo->query("SELECT loi_seconds FROM leads WHERE id=" . (int)$lead['id'])->fetchColumn();
        if ($lead['vendor_id']) {
            $col = $newStatus === 'Complete' ? 'completes' : ($newStatus === 'Terminates' ? 'terminates' : null);
            if ($col) {
                $pdo->prepare("UPDATE project_vendors SET $col = $col + 1 WHERE project_id=? AND vendor_id=?")
                    ->execute([$lead['project_id'], $lead['vendor_id']]);
            }
        }
    } else {
        // Already locked - respect the original outcome, ignore this duplicate hit
        $finalStatus = $lead['status'];
        $loiSeconds = $lead['loi_seconds'];
    }
    if ($lead['vendor_id']) {
        $vStmt = $pdo->prepare("SELECT * FROM vendors WHERE id = ?");
        $vStmt->execute([$lead['vendor_id']]);
        $vendor = $vStmt->fetch();
    }
} else {
    // No matching click record for this uid under this client - nothing to lock or route.
    http_response_code(404);
    die('No matching lead found for this UID under this client.');
}

$vendorUrlKey = [
    'Complete'   => 'complete_url',
    'Terminates' => 'terminate_url',
    'Screenout'  => 'screenout_url',
    'Quota Full' => 'quotafull_url',
][$finalStatus] ?? null;

$target = ($vendor && $vendorUrlKey && !empty($vendor[$vendorUrlKey]))
    ? build_vendor_url($vendor[$vendorUrlKey], build_token_set($uid, $lead['pid'], [
        'loi'    => $loiSeconds,
        'status' => $type,
        'country' => $lead['country'] ?? '',
        'city'    => $lead['city'] ?? '',
      ]))
    : null;

if ($target) {
    redirect($target);
} else {
    render_end_page($finalStatus, $lead['pid'] ?? '', $uid, $lead['ip'] ?? get_client_ip(), date('Y-m-d H:i:s'));
}
