<?php
/**
 * Survey callback:  callback.php?pid=..&vid=..&uid=..&status=complete|terminate|screenout|quotafull
 * First write wins - once a lead's status is locked, further hits are ignored (redirected to the
 * originally recorded outcome) to prevent duplicate/fraudulent completes.
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
ensure_extra_columns($pdo);

$pid    = $_GET['pid'] ?? '';
$vid    = $_GET['vid'] ?? '';
$uid    = $_GET['uid'] ?? ''; // this may be the raw uid OR the encrypted token, depending on whether this project has encryption on
$status = strtolower($_GET['status'] ?? '');

$statusMap = [
    'complete'  => 'Complete',
    'terminate' => 'Terminates',
    'screenout' => 'Screenout',
    'quotafull' => 'Quota Full',
];

if (!$pid || !$uid || !isset($statusMap[$status])) {
    http_response_code(400);
    die('Invalid parameters.');
}
$newStatus = $statusMap[$status];

$stmt = $pdo->prepare("SELECT * FROM projects WHERE pid = ?");
$stmt->execute([$pid]);
$project = $stmt->fetch();
if (!$project) { http_response_code(404); die('Project not found.'); }

$vendor = null;
if ($vid) {
    $stmt = $pdo->prepare("SELECT * FROM vendors WHERE vid = ?");
    $stmt->execute([$vid]);
    $vendor = $stmt->fetch();
}

// Match by either the raw uid OR the encrypted token - whichever this
// project actually sent onward is what will come back in the callback.
$leadStmt = $pdo->prepare("SELECT * FROM leads WHERE project_id = ? AND (uid = ? OR encrypted_uid = ?)");
$leadStmt->execute([$project['id'], $uid, $uid]);
$lead = $leadStmt->fetch();

if ($lead && !$lead['is_locked']) {
    // First genuine write -> lock it in, and record the REAL elapsed time
    // (seconds from first click to this callback) as the actual LOI.
    // Computed inside MySQL itself (TIMESTAMPDIFF) to avoid any PHP/MySQL timezone mismatch.
    $pdo->prepare("UPDATE leads SET status=?, is_locked=1, loi_seconds=TIMESTAMPDIFF(SECOND, created_at, NOW()) WHERE id=?")
        ->execute([$newStatus, $lead['id']]);
    $loiSeconds = (int)$pdo->query("SELECT loi_seconds FROM leads WHERE id=" . (int)$lead['id'])->fetchColumn();

    if ($vendor) {
        $col = $newStatus === 'Complete' ? 'completes' : ($newStatus === 'Terminates' ? 'terminates' : null);
        if ($col) {
            $pdo->prepare("UPDATE project_vendors SET $col = $col + 1 WHERE project_id=? AND vendor_id=?")
                ->execute([$project['id'], $vendor['id']]);
        }
    }
    $finalStatus = $newStatus;
} elseif ($lead) {
    // Already locked earlier - respect the original outcome (anti-fraud)
    $finalStatus = $lead['status'];
    $loiSeconds = $lead['loi_seconds'];
} else {
    // No prior click record found, log this callback directly (LOI unknown - no click was ever seen)
    $loiSeconds = isset($_GET['loi']) && is_numeric($_GET['loi']) ? (int)$_GET['loi'] : null;
    $cb_ip = get_client_ip();
    $cb_geo = geo_lookup($cb_ip);
    $pdo->prepare("INSERT INTO leads (project_id, vendor_id, uid, encrypted_uid, status, ip, country, city, user_agent, is_locked, loi_seconds) VALUES (?,?,?,?,?,?,?,?,?,1,?)")
        ->execute([$project['id'], $vendor['id'] ?? null, $uid, $uid, $newStatus, $cb_ip, $cb_geo['country'], $cb_geo['city'], $_SERVER['HTTP_USER_AGENT'] ?? '', $loiSeconds]);
    $finalStatus = $newStatus;
    $lead = ['country' => $cb_geo['country'], 'city' => $cb_geo['city']];
}

// Decide where to send the respondent: vendor's own redirect URL (preferred) else client's
$vendorUrlKey = [
    'Complete'   => 'complete_url',
    'Terminates' => 'terminate_url',
    'Screenout'  => 'screenout_url',
    'Quota Full' => 'quotafull_url',
][$finalStatus];

$target = null;
if ($vendor && !empty($vendor[$vendorUrlKey])) {
    $target = build_vendor_url($vendor[$vendorUrlKey], build_token_set($uid, $pid, [
        'loi'    => $loiSeconds,
        'status' => $status, // the lowercase status word as received (complete/terminate/screenout/quotafull)
        'country' => $lead['country'] ?? '',
        'city'    => $lead['city'] ?? '',
    ]));
}

if ($target) {
    redirect($target);
} else {
    render_end_page($finalStatus, $pid, $uid, $lead['ip'] ?? get_client_ip(), date('Y-m-d H:i:s'));
}
