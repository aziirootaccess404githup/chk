# PanelHub — Complete Reference Doc

> ⚠️ **Ye file sensitive credentials rakhegi jab tum blanks bhar dogi.**
> Isse kisi ke saath share mat karna, aur ideally apne password manager mein bhi save kar lena.

---

## 1. Domain & Hosting

| Item | Value |
|---|---|
| Live URL | `https://panel.exazonresearch.com` |
| Hosting | Hostinger |
| Root folder | `public_html/panel/` |
| Subdomain configured via | hPanel → Domains → Subdomains |

---

## 2. Admin Panel Login

| Item | Value |
|---|---|
| Login URL | `https://panel.exazonresearch.com/admin/login.php` |
| Email | `admin@yourcompany.com` |
| Password | `_______________` *(abhi bhi default `Admin@123` hai agar change nahi kiya — ⚠️ badal lena aur yahan likh lena)* |

---

## 3. Database Credentials

| Item | Value |
|---|---|
| Host | `localhost` |
| Database name | `_______________` *(jaisa `u994909610_panelhub`)* |
| DB Username | `_______________` |
| DB Password | `_______________` *(jo tumne reset kiya tha)* |
| phpMyAdmin access | Hostinger hPanel → Databases → phpMyAdmin |

*(Ye same values `includes/config.php` mein bhi honi chahiye — `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`)*

---

## 4. Branding Config

File: `includes/config.php`

| Setting | Current Value |
|---|---|
| Brand Name | `YourCompany` *(abhi placeholder hai, apna asli naam daal do)* |
| Support Email | `admin@yourcompany.com` |
| Base URL | `https://panel.exazonresearch.com` |

---

## 5. Core Modules (Admin Panel)

| Module | URL | Kaam |
|---|---|---|
| Dashboard | `/admin/dashboard.php` | Stat cards + clicks-by-project chart |
| Client | `/admin/client.php` | Client list/add/edit/view + activity log |
| Projects | `/admin/projects.php` | Project list/add/edit/view + vendor assignment |
| Leads | `/admin/leads.php` | Global respondent log (sab projects ka) |
| Vendor List | `/admin/vendorlist.php` | Vendor CRUD + global redirect templates |

---

## 6. Public / Tracking Endpoints (in-code, respondent-facing)

| Endpoint | Kaam |
|---|---|
| `/public/entry.php?pid=X&vid=Y&uid=Z` | Vendor Entry Link — respondent click log + survey redirect |
| `/public/callback.php?pid=X&vid=Y&uid=Z&status=complete/terminate/screenout/quotafull` | Project-specific survey callback — status lock + vendor redirect |
| `/public/client_redirect.php?client=X&type=complete/terminate/screenout/quotafull&username=Z` | Client-level generic callback (works across ALL of that client's projects) |
| `/public/test_survey.php` | Test Survey Simulator — testing ke liye, real survey nahi hai |

---

## 7. Redirect Links — Kisko Kya Dena Hai

### A) Agar tum VENDOR ki tarah kisi ko apne redirects doge
(jaise Azilytics ne tumhe apne 4 links diye the)

Ye links **Client View page** pe automatically generate hote hain (koi manual typing nahi):
```
https://panel.exazonresearch.com/public/client_redirect.php?client=CLIENT_ID&type=complete&username=xxxx
https://panel.exazonresearch.com/public/client_redirect.php?client=CLIENT_ID&type=terminate&username=xxxx
https://panel.exazonresearch.com/public/client_redirect.php?client=CLIENT_ID&type=screenout&username=xxxx
https://panel.exazonresearch.com/public/client_redirect.php?client=CLIENT_ID&type=quotafull&username=xxxx
```
Jo bhi system ye link use karega, usse `username=xxxx` ki jagah asli respondent UID daalni hogi (apne format mein — PanelHub sirf plain `username`/`uid` param padhta hai, koi bracket-substitution iski taraf se nahi hoti).

### B) Agar koi VENDOR tumhe apne redirects de (tum client ho)
Vendor List → us vendor ka Complete/Terminate/Screenout/Quotafull URL field mein **jo bhi vendor de wahi paste kar do as-is**.

**Supported placeholder bracket styles (6):**
```
{{token}}   [TOKEN]   {token}   %TOKEN%   <token>   $token$
```

**Supported tokens (auto-replace hote hain):**
| Token | Kya |
|---|---|
| `uid` / `rid` / `toid` | Respondent ID |
| `pid` / `sid` / `studyid` | Project ID |
| `loi` | Real elapsed seconds (jab respondent ne survey shuru se complete/terminate tak kitna time liya) |
| `ip` | Respondent ka IP address |
| `date` / `timestamp` | |
| `status` | complete/terminate/screenout/quotafull |

**Support NAHI karta** (jaanbujh ke, data collect nahi hota): demographics (age/gender/education/income), quota cell ID, termination reason codes, hash/security tokens. Agar ye vendor ke URL mein hain, wo literal text reh jayenge — replace nahi honge.

---

## 8. Respondent Flow (End-to-End)

1. Vendor apna **Entry Link** use karke respondent bhejta hai → `entry.php` click log karta hai (status: Pending) → respondent **Project ka Live URL** (survey) pe redirect hota hai
2. Survey khatam hone pe respondent **Project-level** (`callback.php`) ya **Client-level** (`client_redirect.php`) URL pe redirect hota hai status ke saath
3. System status **lock** kar deta hai (first-write-wins — duplicate/fraud-proof)
4. Respondent ko **vendor ke apne redirect URL** pe bhej diya jaata hai (agar set hai)

---

## 9. Real-World Integration Tested

PanelHub ko **Azilytics Insights** (`hub.azilyticsinsights.com`) ke saath real testing hui hai — dono directions:

| Direction | Status |
|---|---|
| Azilytics → PanelHub (Azilytics apna respondent PanelHub ko bhejta hai) | ✅ Verified working |
| PanelHub → Azilytics (PanelHub apna respondent Azilytics ko bhejta hai) | ✅ Verified working |

Test project SID jo use hua tha: `PANLHUBVMH`

---

## 10. Known Limitations / Not Yet Built

- Change-password UI nahi hai (abhi DB se manually karna padta hai)
- Role-based access (Manager/Viewer) column DB mein hai par enforce nahi hoti
- Demo/test data abhi bhi database mein hai (Demo Client, Demo Vendor, test leads) — clean karna baaki hai
- Bulk email, sales commission tracker, bidding tool — nahi bana

---

## 11. Quick Reference — Sabse Zaroori Files

| File | Kaam |
|---|---|
| `includes/config.php` | Sab settings (DB, branding, base URL) — ek hi jagah se sab control |
| `includes/functions.php` | Placeholder replacement engine (bracket styles + tokens) |
| `db.sql` | Database schema (dobara install karni ho toh ye chahiye) |

---

*Document generated: 19 July 2026*
