<?php
 goto rSkzl; Dz2no: define("\111\x75\x53\103\x48", "\162\x70\x5f\x61\x64\155\151\x6e\x5f\163\145\x73\163\x69\x6f\156"); goto A8t5F; IaXO4: function qIn1x(PDO $NyCxY, ?int $RWfgB): string { goto F90ga; pBkWL: try { goto Kyn2G; CB2KW: $Oxggf = $dzt12->fetchColumn(); goto jCCH8; jCCH8: return $Oxggf === "\x72\145\144\x69\x72\x65\x63\164" ? "\162\145\x64\x69\x72\145\x63\x74" : "\163\x68\x6f\x77\137\x70\x61\x67\x65"; goto W7YA_; Kyn2G: $dzt12 = $NyCxY->prepare("\x53\105\114\x45\x43\124\x20\x65\x6e\144\x5f\x62\x65\x68\x61\166\x69\157\162\x20\x46\122\117\x4d\x20\162\x70\x5f\166\145\156\144\x6f\x72\x73\x20\x57\x48\105\x52\x45\x20\151\x64\x20\75\40\77\40\x4c\x49\x4d\111\x54\40\61"); goto j5amf; j5amf: $dzt12->execute([$RWfgB]); goto CB2KW; W7YA_: } catch (PDOException $Uq4dY) { return "\x73\x68\157\x77\x5f\x70\141\x67\x65"; } goto Tblqw; F90ga: if (!empty($RWfgB)) { goto MTK4m; } goto wfNZf; wfNZf: return "\x73\x68\x6f\x77\x5f\x70\141\147\145"; goto RLDgW; RLDgW: MTK4m: goto pBkWL; Tblqw: } goto t1b2K; kaW9K: function YOWxk(): bool { return Jj8SS()["\162\x6f\x6c\x65"] === "\163\x75\160\145\162\x61\144\155\x69\x6e"; } goto WOggA; A8t5F: function B6fGB(): PDO { goto uEeak; fA5_i: return $ViXFB; goto SFIgh; jjuOa: AgYEx: goto fA5_i; uEeak: static $ViXFB = null; goto BV9OJ; HPEpr: try { $MLNEW = "\155\171\x73\161\x6c\72\x68\157\163\164\75" . yVYcq . "\x3b\160\x6f\162\164\75" . eCLBh . "\x3b\x64\142\156\141\x6d\145\75" . cLuY7 . "\73\x63\150\141\x72\x73\145\x74\x3d\165\164\x66\x38\x6d\x62\64"; $ViXFB = new PDO($MLNEW, N6AHH, EKHmm, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]); } catch (PDOException $Uq4dY) { http_response_code(500); die(json_encode(["\x65\162\162\157\x72" => "\x44\x61\164\141\x62\x61\x73\x65\40\143\x6f\x6e\156\x65\143\x74\151\x6f\156\x20\x66\141\x69\154\145\144"])); } goto jjuOa; BV9OJ: if (!($ViXFB === null)) { goto AgYEx; } goto HPEpr; SFIgh: } goto EW4KH; yYIyo: function YiHbr(): string { goto TZc_8; CuE2f: AgQ0Q: goto IMGnn; TZc_8: $V8v1N = $_SERVER["\110\124\x54\120\137\125\123\x45\122\x5f\101\107\105\x4e\x54"] ?? ''; goto FUXlE; Bp8IT: CXFld: goto jyH_m; m5FF3: return "\x6d\x6f\x62\x69\154\x65"; goto Bp8IT; iwAwf: return "\x74\x61\142\x6c\145\164"; goto CuE2f; jyH_m: return "\144\145\x73\x6b\x74\x6f\x70"; goto rN1PO; IMGnn: if (!preg_match("\57\155\157\142\151\x6c\145\x7c\x61\156\x64\x72\x6f\151\x64\x7c\x69\160\x68\157\156\145\x2f\151", $V8v1N)) { goto CXFld; } goto m5FF3; FUXlE: if (!preg_match("\57\x74\141\142\154\x65\164\x7c\151\160\141\144\57\151", $V8v1N)) { goto AgQ0Q; } goto iwAwf; rN1PO: } goto A9cNJ; WOggA: function FAgqv(): bool { return in_array(jJ8Ss()["\x72\157\x6c\145"], ["\163\165\x70\x65\162\141\144\155\x69\156", "\155\x61\x6e\141\147\x65\162"]); } goto GmufO; Bl1Ob: function vWr_7(string $k9bL2, string $x75sm = ''): ?string { try { goto pfcJk; Y93sk: $HHmBc = substr($LYPOT, 0, 16); goto F1CQA; OI6Md: I77Tq: goto Y93sk; pfcJk: $LYPOT = base64_decode(strtr($k9bL2 . str_repeat("\x3d", (4 - strlen($k9bL2) % 4) % 4), "\55\137", "\53\57")); goto EFXDT; EFXDT: if (!(strlen($LYPOT) < 16)) { goto I77Tq; } goto pEIL1; pEIL1: return null; goto OI6Md; UEjzj: $fOTTC = openssl_decrypt($WFh_6, "\101\105\123\55\62\65\66\x2d\x43\x42\103", $hOhaI, 0, $HHmBc); goto QEUyl; wUjxd: $hOhaI = hash("\x73\150\x61\x32\x35\66", SFn0_ . $x75sm, true); goto UEjzj; QEUyl: return $fOTTC === false ? null : $fOTTC; goto eJO2J; F1CQA: $WFh_6 = base64_encode(substr($LYPOT, 16)); goto wUjxd; eJO2J: } catch (Exception $Uq4dY) { return null; } } goto gnL_t; A9cNJ: function kn5vv(): string { goto jYj1e; DRpzB: return "\x43\150\162\157\155\x65"; goto ShN5Q; vEtjc: if (!str_contains($V8v1N, "\103\150\x72\157\155\145")) { goto SaEp9; } goto DRpzB; H_dWS: v73ZR: goto l5OD2; J33uT: KGSj1: goto UXSjb; l5OD2: return "\117\x74\x68\x65\162"; goto YtnDc; sw8VD: return "\x53\141\x66\141\162\151"; goto J33uT; I4ixO: if (!str_contains($V8v1N, "\123\141\146\141\x72\x69")) { goto KGSj1; } goto sw8VD; XxsEo: return "\105\144\x67\x65"; goto H_dWS; WGmWf: kxgxZ: goto I4ixO; jYj1e: $V8v1N = $_SERVER["\x48\124\x54\120\137\x55\123\x45\122\137\101\x47\x45\x4e\x54"] ?? ''; goto vEtjc; ptXUE: if (!str_contains($V8v1N, "\x46\x69\x72\x65\146\x6f\170")) { goto kxgxZ; } goto yJV4R; ShN5Q: SaEp9: goto ptXUE; yJV4R: return "\106\151\162\x65\146\x6f\x78"; goto WGmWf; UXSjb: if (!str_contains($V8v1N, "\x45\144\147\145")) { goto v73ZR; } goto XxsEo; YtnDc: } goto ar61B; T3zuw: function GbU_2(PDO $NyCxY, ?int $RWfgB, string $Ci2XM, string $x75sm, string $EecQ0, ?int $I_344 = null): void { goto SxFul; RdlwP: return; goto kJNOo; VezhY: $dzt12->execute([$RWfgB]); goto dbO1a; CS03k: $Honin = ["\x63\157\x6d\160\154\x65\x74\x65" => "\143\x6f\155\x70\154\x65\x74\x65\137\165\x72\x6c", "\164\x65\162\155\151\156\x61\164\x65" => "\164\145\162\155\x69\x6e\141\164\145\137\165\162\154", "\161\165\x61\154\151\x74\x79\137\146\x61\x69\x6c" => "\x73\143\x72\x65\x65\156\157\x75\x74\x5f\x75\x72\x6c", "\x6f\166\x65\162\x71\x75\157\x74\141" => "\x71\x75\x6f\x74\x61\x66\165\154\154\137\165\162\x6c"]; goto fQ4B2; v1qvm: return; goto XJUZO; yTj23: $dzt12 = $NyCxY->prepare("\x53\105\114\105\103\124\40{$QUmkv}\40\106\x52\117\115\x20\x72\160\x5f\166\x65\156\144\157\162\163\40\x57\x48\x45\x52\x45\40\x69\x64\x20\75\40\x3f\x20\114\x49\x4d\111\124\x20\61"); goto VezhY; dbO1a: $kse72 = $dzt12->fetchColumn(); goto weRbC; weRbC: if (!empty($kse72)) { goto VEDyi; } goto K03V1; IRpBN: if ($QUmkv) { goto MxMu_; } goto v1qvm; fQ4B2: $QUmkv = $Honin[$Ci2XM] ?? null; goto IRpBN; S1v1i: VEDyi: goto Zws8H; K03V1: return; goto S1v1i; SxFul: if (!empty($RWfgB)) { goto EA_hF; } goto RdlwP; D0F20: fO1FI($NMXYA); goto PMZ5l; kJNOo: EA_hF: goto CS03k; XJUZO: MxMu_: goto yTj23; Zws8H: $NMXYA = uRoqS($kse72, $x75sm, $EecQ0, $I_344); goto D0F20; PMZ5l: } goto IaXO4; KFWda: function uroqs(string $kse72, string $x75sm, string $EecQ0, ?int $I_344 = null): string { $NMXYA = UEOEJ($kse72, ["\x73\151\144" => $x75sm, "\x75\151\144" => $EecQ0, "\x70\151\x64" => $EecQ0, "\x69\x64\145\156\x74\x69\146\x69\x65\x72" => $EecQ0, "\154\157\x69" => (string) ($I_344 ?? '')]); return html_entity_decode($NMXYA, ENT_QUOTES, "\x55\x54\106\x2d\70"); } goto T3zuw; GmufO: function B6GqT(): string { goto xZXLI; xZXLI: foreach (["\x48\x54\124\x50\x5f\x43\106\137\103\117\116\x4e\105\103\x54\x49\x4e\x47\x5f\111\120", "\x48\124\124\x50\x5f\x58\137\x46\117\122\127\x41\x52\x44\105\104\137\x46\117\x52", "\x52\105\115\117\x54\x45\x5f\101\x44\x44\122"] as $qxtim) { goto T3v7W; rzODv: OajS5: goto k2d2K; B7vB9: RWYV3: goto rzODv; T3v7W: if (empty($_SERVER[$qxtim])) { goto RWYV3; } goto Ap9uc; Ap9uc: return explode("\54", $_SERVER[$qxtim])[0]; goto B7vB9; k2d2K: } goto U_EYy; nytiJ: return "\165\156\x6b\x6e\x6f\167\x6e"; goto sYABr; U_EYy: e_JWv: goto nytiJ; sYABr: } goto Exv2E; SPo9l: function LD0x0(): void { goto Uuxgj; Uuxgj: if (XA0kq()) { goto VzwD_; } goto SLb0c; PmODG: exit; goto Oq0w9; Oq0w9: VzwD_: goto Xq9jw; SLb0c: header("\x4c\x6f\x63\x61\164\151\x6f\156\x3a\40\154\x6f\147\x69\x6e\56\160\x68\160"); goto PmODG; Xq9jw: } goto MVfSk; Exv2E: function mlBWO(string $B7KNU): array {
    if (empty($B7KNU) || $B7KNU === 'unknown') return ['country' => '', 'city' => ''];

    // Multi-provider fallback chain. Previously this only called ip-api.com,
    // which is generous (45 req/min) at low volume but silently starts
    // failing once lead traffic grows past that — the old code just returned
    // an empty country/city with no fallback, which is why Country started
    // showing "—" more and more as volume increased. Now if the first
    // provider is rate-limited or down, we try two more independent
    // providers (different rate-limit buckets) before giving up.
    $geo = rp_geo_try_ipapi($B7KNU);
    if ($geo) return $geo;

    $geo = rp_geo_try_ipwhois($B7KNU);
    if ($geo) return $geo;

    $geo = rp_geo_try_ipinfo($B7KNU);
    if ($geo) return $geo;

    // All three providers failed — save the lead anyway, just without geo data.
    return ['country' => '', 'city' => ''];
}

// Shared HTTP GET helper — uses cURL when available (more reliable than
// file_get_contents, works even if allow_url_fopen is disabled on the
// server) and falls back to file_get_contents otherwise.
function rp_geo_http_get(string $url, int $timeout_seconds = 2): ?string {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $timeout_seconds,
            CURLOPT_CONNECTTIMEOUT => $timeout_seconds,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT      => 'PanelEngine-GeoLookup/1.0',
        ]);
        $body = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return ($body !== false && $http_code === 200) ? $body : null;
    }
    $ctx = stream_context_create(['http' => ['timeout' => $timeout_seconds]]);
    $body = @file_get_contents($url, false, $ctx);
    return $body !== false ? $body : null;
}

// Provider 1: ip-api.com — fast, HTTP only on the free tier, 45 req/min limit.
function rp_geo_try_ipapi(string $ip): ?array {
    $body = rp_geo_http_get("http://ip-api.com/json/{$ip}?fields=status,country,city");
    if (!$body) return null;
    $j = json_decode($body);
    if ($j && ($j->status ?? '') === 'success') {
        return ['country' => $j->country ?? '', 'city' => $j->city ?? ''];
    }
    return null;
}

// Provider 2: ipwho.is — separate provider/rate-limit bucket, HTTPS, no API key needed.
function rp_geo_try_ipwhois(string $ip): ?array {
    $body = rp_geo_http_get("https://ipwho.is/{$ip}");
    if (!$body) return null;
    $j = json_decode($body);
    if ($j && ($j->success ?? false) === true) {
        return ['country' => $j->country ?? '', 'city' => $j->city ?? ''];
    }
    return null;
}

// Provider 3: ipinfo.io — works without a token, third independent bucket.
// Only returns a 2-letter country code, so we map it to a full country name
// to stay consistent with what the panel already shows/filters on.
function rp_geo_try_ipinfo(string $ip): ?array {
    $body = rp_geo_http_get("https://ipinfo.io/{$ip}/json");
    if (!$body) return null;
    $j = json_decode($body);
    if ($j && !empty($j->country)) {
        $name = rp_country_code_to_name($j->country) ?: $j->country;
        return ['country' => $name, 'city' => $j->city ?? ''];
    }
    return null;
}

// ISO 3166-1 alpha-2 -> full country name, used only to normalize ipinfo.io's
// 2-letter codes to match the other two providers' full-name format.
function rp_country_code_to_name(string $code): ?string {
    static $map = [
    'AD' => 'Andorra',
        'AE' => 'United Arab Emirates',
        'AF' => 'Afghanistan',
        'AG' => 'Antigua and Barbuda',
        'AI' => 'Anguilla',
        'AL' => 'Albania',
        'AM' => 'Armenia',
        'AO' => 'Angola',
        'AQ' => 'Antarctica',
        'AR' => 'Argentina',
        'AS' => 'American Samoa',
        'AT' => 'Austria',
        'AU' => 'Australia',
        'AW' => 'Aruba',
        'AZ' => 'Azerbaijan',
        'BA' => 'Bosnia and Herzegovina',
        'BB' => 'Barbados',
        'BD' => 'Bangladesh',
        'BE' => 'Belgium',
        'BF' => 'Burkina Faso',
        'BG' => 'Bulgaria',
        'BH' => 'Bahrain',
        'BI' => 'Burundi',
        'BJ' => 'Benin',
        'BM' => 'Bermuda',
        'BN' => 'Brunei',
        'BO' => 'Bolivia',
        'BR' => 'Brazil',
        'BS' => 'Bahamas',
        'BT' => 'Bhutan',
        'BW' => 'Botswana',
        'BY' => 'Belarus',
        'BZ' => 'Belize',
        'CA' => 'Canada',
        'CD' => 'Congo (DRC)',
        'CF' => 'Central African Republic',
        'CG' => 'Congo',
        'CH' => 'Switzerland',
        'CI' => 'Ivory Coast',
        'CL' => 'Chile',
        'CM' => 'Cameroon',
        'CN' => 'China',
        'CO' => 'Colombia',
        'CR' => 'Costa Rica',
        'CU' => 'Cuba',
        'CV' => 'Cape Verde',
        'CW' => 'Curacao',
        'CY' => 'Cyprus',
        'CZ' => 'Czech Republic',
        'DE' => 'Germany',
        'DJ' => 'Djibouti',
        'DK' => 'Denmark',
        'DM' => 'Dominica',
        'DO' => 'Dominican Republic',
        'DZ' => 'Algeria',
        'EC' => 'Ecuador',
        'EE' => 'Estonia',
        'EG' => 'Egypt',
        'ER' => 'Eritrea',
        'ES' => 'Spain',
        'ET' => 'Ethiopia',
        'FI' => 'Finland',
        'FJ' => 'Fiji',
        'FM' => 'Micronesia',
        'FR' => 'France',
        'GA' => 'Gabon',
        'GB' => 'United Kingdom',
        'GD' => 'Grenada',
        'GE' => 'Georgia',
        'GF' => 'French Guiana',
        'GH' => 'Ghana',
        'GI' => 'Gibraltar',
        'GL' => 'Greenland',
        'GM' => 'Gambia',
        'GN' => 'Guinea',
        'GP' => 'Guadeloupe',
        'GQ' => 'Equatorial Guinea',
        'GR' => 'Greece',
        'GT' => 'Guatemala',
        'GU' => 'Guam',
        'GW' => 'Guinea-Bissau',
        'GY' => 'Guyana',
        'HK' => 'Hong Kong',
        'HN' => 'Honduras',
        'HR' => 'Croatia',
        'HT' => 'Haiti',
        'HU' => 'Hungary',
        'ID' => 'Indonesia',
        'IE' => 'Ireland',
        'IL' => 'Israel',
        'IM' => 'Isle of Man',
        'IN' => 'India',
        'IQ' => 'Iraq',
        'IR' => 'Iran',
        'IS' => 'Iceland',
        'IT' => 'Italy',
        'JE' => 'Jersey',
        'JM' => 'Jamaica',
        'JO' => 'Jordan',
        'JP' => 'Japan',
        'KE' => 'Kenya',
        'KG' => 'Kyrgyzstan',
        'KH' => 'Cambodia',
        'KI' => 'Kiribati',
        'KM' => 'Comoros',
        'KN' => 'Saint Kitts and Nevis',
        'KP' => 'North Korea',
        'KR' => 'South Korea',
        'KW' => 'Kuwait',
        'KY' => 'Cayman Islands',
        'KZ' => 'Kazakhstan',
        'LA' => 'Laos',
        'LB' => 'Lebanon',
        'LC' => 'Saint Lucia',
        'LI' => 'Liechtenstein',
        'LK' => 'Sri Lanka',
        'LR' => 'Liberia',
        'LS' => 'Lesotho',
        'LT' => 'Lithuania',
        'LU' => 'Luxembourg',
        'LV' => 'Latvia',
        'LY' => 'Libya',
        'MA' => 'Morocco',
        'MC' => 'Monaco',
        'MD' => 'Moldova',
        'ME' => 'Montenegro',
        'MG' => 'Madagascar',
        'MH' => 'Marshall Islands',
        'MK' => 'North Macedonia',
        'ML' => 'Mali',
        'MM' => 'Myanmar',
        'MN' => 'Mongolia',
        'MO' => 'Macau',
        'MQ' => 'Martinique',
        'MR' => 'Mauritania',
        'MS' => 'Montserrat',
        'MT' => 'Malta',
        'MU' => 'Mauritius',
        'MV' => 'Maldives',
        'MW' => 'Malawi',
        'MX' => 'Mexico',
        'MY' => 'Malaysia',
        'MZ' => 'Mozambique',
        'NA' => 'Namibia',
        'NC' => 'New Caledonia',
        'NE' => 'Niger',
        'NG' => 'Nigeria',
        'NI' => 'Nicaragua',
        'NL' => 'Netherlands',
        'NO' => 'Norway',
        'NP' => 'Nepal',
        'NR' => 'Nauru',
        'NZ' => 'New Zealand',
        'OM' => 'Oman',
        'PA' => 'Panama',
        'PE' => 'Peru',
        'PF' => 'French Polynesia',
        'PG' => 'Papua New Guinea',
        'PH' => 'Philippines',
        'PK' => 'Pakistan',
        'PL' => 'Poland',
        'PR' => 'Puerto Rico',
        'PS' => 'Palestine',
        'PT' => 'Portugal',
        'PW' => 'Palau',
        'PY' => 'Paraguay',
        'QA' => 'Qatar',
        'RE' => 'Reunion',
        'RO' => 'Romania',
        'RS' => 'Serbia',
        'RU' => 'Russia',
        'RW' => 'Rwanda',
        'SA' => 'Saudi Arabia',
        'SB' => 'Solomon Islands',
        'SC' => 'Seychelles',
        'SD' => 'Sudan',
        'SE' => 'Sweden',
        'SG' => 'Singapore',
        'SI' => 'Slovenia',
        'SK' => 'Slovakia',
        'SL' => 'Sierra Leone',
        'SM' => 'San Marino',
        'SN' => 'Senegal',
        'SO' => 'Somalia',
        'SR' => 'Suriname',
        'SS' => 'South Sudan',
        'ST' => 'Sao Tome and Principe',
        'SV' => 'El Salvador',
        'SX' => 'Sint Maarten',
        'SY' => 'Syria',
        'SZ' => 'Eswatini',
        'TC' => 'Turks and Caicos Islands',
        'TD' => 'Chad',
        'TG' => 'Togo',
        'TH' => 'Thailand',
        'TJ' => 'Tajikistan',
        'TL' => 'Timor-Leste',
        'TM' => 'Turkmenistan',
        'TN' => 'Tunisia',
        'TO' => 'Tonga',
        'TR' => 'Turkey',
        'TT' => 'Trinidad and Tobago',
        'TV' => 'Tuvalu',
        'TW' => 'Taiwan',
        'TZ' => 'Tanzania',
        'UA' => 'Ukraine',
        'UG' => 'Uganda',
        'US' => 'United States',
        'UY' => 'Uruguay',
        'UZ' => 'Uzbekistan',
        'VA' => 'Vatican City',
        'VC' => 'Saint Vincent and the Grenadines',
        'VE' => 'Venezuela',
        'VG' => 'British Virgin Islands',
        'VI' => 'U.S. Virgin Islands',
        'VN' => 'Vietnam',
        'VU' => 'Vanuatu',
        'WS' => 'Samoa',
        'YE' => 'Yemen',
        'ZA' => 'South Africa',
        'ZM' => 'Zambia',
        'ZW' => 'Zimbabwe'    ];
    return $map[strtoupper($code)] ?? null;
}
 goto yYIyo; V0ks6: function Fo1FI(string $NMXYA): void { goto Un_sN; dnKfR: $gzPju = $wBiYh["\160\157\162\x74"] ?? ($lPdZP === "\x68\x74\x74\x70\163" ? 443 : 80); goto at2Al; RYP3X: @fclose($PzZGH); goto RwKfL; jokIr: g2iyg: goto plstt; r1lTl: $lbPvI = $wBiYh["\x68\157\163\x74"]; goto iF4dt; IMzmo: P4P_h: goto mqr1I; RWUzX: if ($PzZGH) { goto g2iyg; } goto Qi8XV; PuoC4: $lPdZP = $wBiYh["\163\x63\150\x65\x6d\x65"] ?? "\150\x74\x74\x70"; goto dnKfR; Qi8XV: return; goto jokIr; v8d0I: if (!(!$wBiYh || empty($wBiYh["\x68\x6f\x73\x74"]))) { goto XPtDL; } goto oIMva; mqr1I: $wBiYh = @parse_url($NMXYA); goto v8d0I; Zqiar: @fwrite($PzZGH, $QlntJ); goto RYP3X; UwGn4: $QlntJ .= "\103\157\156\156\145\143\x74\x69\x6f\156\72\40\x43\154\x6f\163\145\xd\12\15\xa"; goto Zqiar; iF4dt: $QiTUi = $lPdZP === "\x68\x74\164\160\163" ? "\163\163\154\72\57\57" : ''; goto buODG; aYeG1: $QlntJ .= "\x48\157\x73\x74\x3a\40{$lbPvI}\15\12"; goto RxIvB; RxIvB: $QlntJ .= "\125\x73\145\162\x2d\x41\147\145\156\x74\x3a\x20\115\141\x74\162\x69\170\x57\x6f\x72\x6c\144\x52\x65\163\x65\141\x72\x63\x68\x2d\120\x6f\x73\x74\142\141\143\153\57\x31\56\60\xd\12"; goto UwGn4; SJaWi: XPtDL: goto PuoC4; buODG: $PzZGH = @fsockopen($QiTUi . $lbPvI, $gzPju, $JeMZC, $VDnNl, 2); goto RWUzX; plstt: $QlntJ = "\107\x45\x54\x20{$WI6Hu}\x20\110\124\x54\x50\57\61\56\x31\15\xa"; goto aYeG1; M4Mfd: return; goto IMzmo; Un_sN: if (!empty($NMXYA)) { goto P4P_h; } goto M4Mfd; oIMva: return; goto SJaWi; at2Al: $WI6Hu = ($wBiYh["\160\141\164\x68"] ?? "\57") . (!empty($wBiYh["\x71\x75\x65\x72\171"]) ? "\77" . $wBiYh["\161\165\x65\162\171"] : ''); goto r1lTl; RwKfL: } goto KFWda; ipRXs: define("\123\106\x6e\x30\x5f", "\115\x61\164\x72\151\x78\x57\157\162\x6c\144\x40\x53\145\143\x72\145\x74\x4b\x65\171\x32\60\x32\x36\x23\125\x6e\151\161\165\145\41\101\x42\x43\67"); goto Dz2no; rSkzl: date_default_timezone_set("\101\x73\x69\x61\x2f\113\157\x6c\153\141\164\x61"); goto BHoCX; MVfSk: function JJ8sS(): array { Fn7EY(); return ["\x69\x64" => $_SESSION["\162\x70\137\165\x73\145\x72\137\x69\x64"] ?? 0, "\x6e\x61\155\145" => $_SESSION["\162\x70\137\165\163\145\162\137\156\141\155\x65"] ?? '', "\x65\155\x61\151\154" => $_SESSION["\162\x70\137\x75\163\145\162\137\x65\x6d\141\x69\x6c"] ?? '', "\x72\x6f\x6c\x65" => $_SESSION["\162\160\137\x75\x73\145\162\x5f\162\x6f\154\145"] ?? "\x76\151\145\x77\x65\162"]; } goto kaW9K; fKxVs: define("\116\x36\x41\x48\110", "\165\x31\61\x37\x35\x36\70\64\60\x30\137\x4d\141\x74\162\151\170"); goto c9NdX; kqKsO: function xa0KQ(): bool { fN7EY(); return !empty($_SESSION["\x72\x70\137\165\x73\x65\x72\x5f\151\144"]); } goto SPo9l; ar61B: function UeoeJ(string $kse72, array $PQ2Bt): string { goto mCJLn; a4YrW: foreach ($PQ2Bt as $hOhaI => $IWwoH) { goto fs290; cgybK: goto ZAWIu; goto O8TdI; ft7mY: foreach ($W1Sux as $f8nri) { goto QhJo3; QhJo3: $Yk_CD = sprintf($f8nri, $tfdTk); goto oira8; JsI8L: Wk28Z: goto KqBsD; oira8: $NMXYA = preg_replace($Yk_CD, (string) $IWwoH, $NMXYA); goto JsI8L; KqBsD: } goto HXIQl; B5xDV: $tfdTk = preg_quote((string) $hOhaI, "\57"); goto ft7mY; HXIQl: Y0lhW: goto lfUPC; O8TdI: oCe8O: goto B5xDV; lfUPC: ZAWIu: goto TV08A; fs290: if (!($IWwoH === null)) { goto oCe8O; } goto cgybK; TV08A: } goto nTHmY; zycDV: return $NMXYA; goto WkKuU; mCJLn: $NMXYA = $kse72; goto GzP2m; GzP2m: $W1Sux = ["\57\x5c\x7b\134\x7b\134\163\x2a\45\x73\134\163\x2a\134\x7d\134\x7d\x2f\151", "\57\x5c\133\134\163\52\45\x73\x5c\x73\x2a\x5c\x5d\57\x69", "\57\134\173\134\163\x2a\45\x73\x5c\x73\52\x5c\175\x2f\x69", "\x2f\45\x25\134\163\52\45\163\x5c\x73\x2a\x25\x25\57\x69", "\57\74\134\x73\x2a\45\163\134\163\x2a\76\57\x69", "\x2f\134\x24\x5c\x73\x2a\x25\x73\134\163\52\134\x24\x2f\151"]; goto a4YrW; nTHmY: aWbPc: goto zycDV; WkKuU: } goto V0ks6; gnL_t: function fN7Ey(): void { goto uGNXI; DJBAC: session_name(IuSCH); goto lbxX1; lbxX1: session_start(); goto RYsPa; uGNXI: if (!(session_status() === PHP_SESSION_NONE)) { goto vQcRp; } goto DJBAC; RYsPa: vQcRp: goto x91e7; x91e7: } goto kqKsO; BHoCX: define("\171\x56\131\143\161", "\61\x32\x37\56\60\x2e\x30\x2e\61"); goto z70cJ; c9NdX: define("\105\113\x48\x6d\155", "\113\x72\x69\x73\x68\156\141\100\115\127\122\x30\x35\x32\62"); goto yul1i; yul1i: define("\145\x43\114\102\x68", "\63\x33\60\66"); goto ipRXs; z70cJ: define("\x63\x4c\x75\x59\x37", "\165\x31\x31\67\65\x36\x38\64\60\60\x5f\115\141\164\x72\151\x78"); goto fKxVs; EW4KH: function Pvvhs(string $djL_E, string $x75sm = ''): string { return bin2hex(random_bytes(5)); } goto Bl1Ob; t1b2K: function lRgoC(PDO $NyCxY, ?int $RWfgB, string $Ci2XM, string $x75sm, string $EecQ0, ?int $I_344 = null): ?string { goto ezQyF; Tw5Oa: return null; goto fElgR; Sxjix: if ($QUmkv) { goto Q9jYN; } goto sd5xF; G6Zo1: if (!empty($kse72)) { goto L0ifN; } goto Tw5Oa; kAqqz: YciPY: goto JjuXf; fElgR: L0ifN: goto LbWI0; ezQyF: if (!empty($RWfgB)) { goto JNkAo; } goto tMR63; JjuXf: $Honin = ["\x63\x6f\x6d\x70\154\x65\x74\145" => "\143\157\155\x70\x6c\145\164\145\x5f\x75\x72\x6c", "\x74\x65\x72\155\151\x6e\141\x74\145" => "\164\145\162\155\151\x6e\x61\x74\x65\137\165\x72\x6c", "\161\165\141\154\x69\x74\171\x5f\x66\x61\x69\154" => "\163\143\162\145\x65\156\x6f\x75\x74\x5f\165\162\154", "\x6f\x76\x65\162\x71\x75\x6f\164\141" => "\x71\165\157\164\141\x66\x75\154\x6c\x5f\x75\162\x6c"]; goto vy3nL; vy3nL: $QUmkv = $Honin[$Ci2XM] ?? null; goto Sxjix; kuS4t: return null; goto kAqqz; bjYPj: $kse72 = $dzt12->fetchColumn(); goto G6Zo1; BxLKn: $dzt12 = $NyCxY->prepare("\x53\105\114\105\x43\x54\40{$QUmkv}\40\106\x52\x4f\x4d\40\x72\160\x5f\166\x65\x6e\144\157\x72\163\x20\127\110\x45\x52\105\40\151\x64\40\x3d\40\x3f\x20\x4c\x49\x4d\111\x54\x20\61"); goto JQY8I; CtB_B: JNkAo: goto iIXcK; iIXcK: if (!(QIN1x($NyCxY, $RWfgB) !== "\162\x65\x64\x69\162\x65\143\164")) { goto YciPY; } goto kuS4t; JQY8I: $dzt12->execute([$RWfgB]); goto bjYPj; tMR63: return null; goto CtB_B; O_6J3: Q9jYN: goto BxLKn; sd5xF: return null; goto O_6J3; LbWI0: return uROqS($kse72, $x75sm, $EecQ0, $I_344); goto lZFok; lZFok: }

function rp_require_login(): void { LD0x0(); }
function rp_db(): PDO { return B6fGB(); }
function rp_current_user(): array { return JJ8sS(); }
function rp_is_manager(): bool { return FAgqv(); }
function rp_is_superadmin(): bool { return YOWxk(); }
function rp_session_start(): void { fN7Ey(); }
