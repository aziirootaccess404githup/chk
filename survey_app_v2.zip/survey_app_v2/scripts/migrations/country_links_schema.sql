-- ============================================================
-- Multi-Country Link — per-project, per-country override survey
-- URLs. Direct port of ExaVerify's exz_project_country_links table.
-- Activated when a project's link_type = 'Country' (that field
-- already exists — this reuses it rather than adding a new toggle).
-- ============================================================
CREATE TABLE IF NOT EXISTS public.project_country_links (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    project_id UUID REFERENCES public.projects(id) ON DELETE CASCADE,
    country TEXT NOT NULL,
    live_url TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE (project_id, country)
);
ALTER TABLE public.project_country_links ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow authenticated full access" ON public.project_country_links;
CREATE POLICY "Allow authenticated full access" ON public.project_country_links FOR ALL USING (auth.role() = 'authenticated');
DROP POLICY IF EXISTS "Allow service role full access" ON public.project_country_links;
CREATE POLICY "Allow service role full access" ON public.project_country_links FOR ALL USING (true);
