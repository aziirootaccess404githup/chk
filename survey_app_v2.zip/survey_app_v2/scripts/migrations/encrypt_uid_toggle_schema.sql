-- ============================================================
-- Per-Project UID Encryption Toggle
-- Ported from ExaVerify's project_settings.encrypt_uid — lets a
-- project owner choose whether the respondent UID sent to the
-- client's survey is encrypted (default, safer — hides the raw
-- panelist ID) or passed through raw (some client survey platforms
-- require the exact original ID for their own matching).
-- ============================================================
ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS encrypt_uid BOOLEAN DEFAULT true;
