-- ============================================================
-- Dashboard Notes — simple personal sticky-notes widget.
-- ============================================================
CREATE TABLE IF NOT EXISTS public.dashboard_notes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    admin_email TEXT,
    note TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);
ALTER TABLE public.dashboard_notes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow authenticated full access" ON public.dashboard_notes;
CREATE POLICY "Allow authenticated full access" ON public.dashboard_notes FOR ALL USING (auth.role() = 'authenticated');
