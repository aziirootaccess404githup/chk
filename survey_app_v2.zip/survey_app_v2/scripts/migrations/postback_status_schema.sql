-- ============================================================
-- Postback-Status Tracking + "Show Page" Vendor Behavior
-- Ported from ExaVerify's exz_fire_vendor_postback / end_behavior system.
--
-- Two vendor behaviors:
--   'redirect'  (default, existing behavior) — browser is redirected
--               straight to the vendor's URL.
--   'show_page' — respondent sees a status page on OUR tool; the vendor
--               is notified via a background server-to-server GET
--               request instead (more reliable — doesn't depend on the
--               respondent's browser completing the redirect).
-- ============================================================

ALTER TABLE public.suppliers ADD COLUMN IF NOT EXISTS end_behavior TEXT DEFAULT 'redirect';

ALTER TABLE public.tracking_logs ADD COLUMN IF NOT EXISTS postback_status TEXT DEFAULT 'pending';
ALTER TABLE public.tracking_logs ADD COLUMN IF NOT EXISTS postback_at TIMESTAMP WITH TIME ZONE;
