-- Please run this script in your Supabase SQL Editor

ALTER TABLE projects ADD COLUMN IF NOT EXISTS project_manager TEXT;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS country TEXT;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS language TEXT;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS category TEXT;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS loi INTEGER;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS ir INTEGER;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS sample_size INTEGER;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS currency TEXT;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS supplier_cpi NUMERIC;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS start_date DATE;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS end_date DATE;

-- Verify it worked
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'projects';
