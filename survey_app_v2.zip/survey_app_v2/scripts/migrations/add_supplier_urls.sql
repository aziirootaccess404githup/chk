-- Please run this script in your Supabase SQL Editor

ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS complete_url TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS terminate_url TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS quotafull_url TEXT;

-- Verify it worked
SELECT column_name 
FROM information_schema.columns 
WHERE table_name = 'suppliers';
