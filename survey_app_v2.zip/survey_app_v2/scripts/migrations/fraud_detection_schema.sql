-- ============================================================
-- Fraud-Detection + Status-Lock schema
-- Ported from ExaVerify's proven pages/track.php + inc_exz.php logic,
-- adapted to MWR's tracking_logs / projects Supabase schema.
-- ============================================================

-- ── tracking_logs: fraud-detection fields ──────────────────────
ALTER TABLE tracking_logs ADD COLUMN IF NOT EXISTS loi_seconds INTEGER;
ALTER TABLE tracking_logs ADD COLUMN IF NOT EXISTS is_duplicate BOOLEAN DEFAULT FALSE;
ALTER TABLE tracking_logs ADD COLUMN IF NOT EXISTS is_speeder BOOLEAN DEFAULT FALSE;
ALTER TABLE tracking_logs ADD COLUMN IF NOT EXISTS same_ip_flag BOOLEAN DEFAULT FALSE;
ALTER TABLE tracking_logs ADD COLUMN IF NOT EXISTS quality_score INTEGER DEFAULT 100;
ALTER TABLE tracking_logs ADD COLUMN IF NOT EXISTS score_reasons TEXT;

-- ── tracking_logs: status-lock (first-write-wins, same as ExaVerify) ──
-- Once a genuine terminal status (Complete/Terminate/OverQuota/SecurityFail)
-- has been written once, status_locked=true freezes it — a respondent or
-- vendor hitting the return-link again can NEVER silently overwrite a real
-- result, and never gets double-scored/double-counted.
ALTER TABLE tracking_logs ADD COLUMN IF NOT EXISTS status_locked BOOLEAN DEFAULT FALSE;

-- ── projects: configurable speeder threshold (per-project, like ExaVerify's SPD_LIMIT) ──
ALTER TABLE projects ADD COLUMN IF NOT EXISTS speeder_threshold_seconds INTEGER DEFAULT 180;

-- Helpful index for the same-IP / duplicate lookups (project + ip, project + uid)
CREATE INDEX IF NOT EXISTS idx_tracking_logs_project_ip ON tracking_logs(project_id, ip_address);
CREATE INDEX IF NOT EXISTS idx_tracking_logs_project_uid ON tracking_logs(project_id, respondent_uid);
