-- Add Client Redirect URLs to projects table
ALTER TABLE projects ADD COLUMN IF NOT EXISTS client_complete_url TEXT;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS client_terminate_url TEXT;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS client_quota_url TEXT;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS client_quality_url TEXT;

-- Add Supplier Type and Quality URL to suppliers table
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS supplier_type TEXT DEFAULT 'Static';
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS quality_url TEXT;

-- Create Project Supplier Mappings table to generate Unique Survey Links
CREATE TABLE IF NOT EXISTS public.project_supplier_mappings (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    project_id UUID REFERENCES public.projects(id) ON DELETE CASCADE,
    supplier_id UUID REFERENCES public.suppliers(id) ON DELETE CASCADE,
    unique_code TEXT UNIQUE NOT NULL,
    cpi NUMERIC(10, 2),
    allocation INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Ensure RLS is enabled for the new table
ALTER TABLE public.project_supplier_mappings ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users full access
CREATE POLICY "Allow authenticated full access" ON public.project_supplier_mappings FOR ALL USING (auth.role() = 'authenticated');
