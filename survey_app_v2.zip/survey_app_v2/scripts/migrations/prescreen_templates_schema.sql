-- ============================================================
-- Prescreen Templates — reusable named sets of questions, built
-- from the Question Library. Stores question IDs as a JSONB array
-- (same pattern as question_library.options) rather than a separate
-- junction table, since a template's question list is always read/
-- written as a whole unit.
-- ============================================================
CREATE TABLE IF NOT EXISTS public.prescreen_templates (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    question_ids JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);
ALTER TABLE public.prescreen_templates ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow authenticated full access" ON public.prescreen_templates;
CREATE POLICY "Allow authenticated full access" ON public.prescreen_templates FOR ALL USING (auth.role() = 'authenticated');
