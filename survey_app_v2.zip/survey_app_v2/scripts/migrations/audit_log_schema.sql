-- ============================================================
-- Audit Log — automatic system-wide admin-action logging.
-- Ported from ExaVerify's exz_audit_log table.
-- ============================================================
CREATE TABLE IF NOT EXISTS public.audit_log (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    admin_email TEXT,
    action TEXT NOT NULL,
    details TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow authenticated full access" ON public.audit_log;
CREATE POLICY "Allow authenticated full access" ON public.audit_log FOR ALL USING (auth.role() = 'authenticated');
DROP POLICY IF EXISTS "Allow service role full access" ON public.audit_log;
CREATE POLICY "Allow service role full access" ON public.audit_log FOR ALL USING (true);

CREATE INDEX IF NOT EXISTS idx_audit_log_created ON audit_log(created_at DESC);
