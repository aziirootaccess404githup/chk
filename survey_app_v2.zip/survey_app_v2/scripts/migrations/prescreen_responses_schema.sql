-- ============================================================
-- Prescreen Responses — the respondent-facing prescreener page
-- was collecting answers in the browser but NEVER saving them
-- anywhere (discarded on submit). This table + the wiring in
-- app/actions/prescreen.js and the prescreener page actually
-- persists them, matching ExaVerify's capture_screener.php.
-- ============================================================
CREATE TABLE IF NOT EXISTS public.prescreen_responses (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    project_id UUID REFERENCES public.projects(id) ON DELETE CASCADE,
    respondent_uid TEXT NOT NULL,
    question_id UUID REFERENCES public.prescreen_questions(id) ON DELETE SET NULL,
    question_text TEXT,
    answer TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);
ALTER TABLE public.prescreen_responses ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow authenticated full access" ON public.prescreen_responses;
CREATE POLICY "Allow authenticated full access" ON public.prescreen_responses FOR ALL USING (auth.role() = 'authenticated');
DROP POLICY IF EXISTS "Allow service role full access" ON public.prescreen_responses;
CREATE POLICY "Allow service role full access" ON public.prescreen_responses FOR ALL USING (true);

CREATE INDEX IF NOT EXISTS idx_prescreen_responses_project_uid ON prescreen_responses(project_id, respondent_uid);
