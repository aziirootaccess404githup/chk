-- ============================================================
-- Question Library — a reusable bank of demographic/screening
-- questions (separate from prescreen_questions, which are per-project).
-- ============================================================
CREATE TABLE IF NOT EXISTS public.question_library (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    country TEXT,
    language TEXT,
    control_type TEXT,          -- Text / Radio / Dropdown / Checkbox
    title TEXT NOT NULL,
    question_text TEXT NOT NULL,
    category TEXT,
    min_length INTEGER,
    max_length INTEGER,
    text_type TEXT,             -- Email / ContactNo / ZipCode / Custom (only relevant for control_type=Text)
    options JSONB,              -- array of option strings, for Radio/Dropdown/Checkbox
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);
ALTER TABLE public.question_library ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow authenticated full access" ON public.question_library;
CREATE POLICY "Allow authenticated full access" ON public.question_library FOR ALL USING (auth.role() = 'authenticated');
