-- ============================================================
-- Billing-Dispute Reconciliation — direct port of ExaVerify's
-- reconcile_records table. Tracks "we sent X, client only
-- accepted Y" disputes per project/period, with auto-calculated
-- difference and dispute amount.
-- ============================================================
CREATE TABLE IF NOT EXISTS public.reconcile_records (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    project_id UUID REFERENCES public.projects(id) ON DELETE SET NULL,
    client_name TEXT,
    period TEXT,
    we_sent INTEGER DEFAULT 0,
    client_accepted INTEGER DEFAULT 0,
    client_rejected INTEGER DEFAULT 0,
    reject_reason TEXT,
    our_completes INTEGER DEFAULT 0,
    difference INTEGER DEFAULT 0,
    cpi NUMERIC(10,2) DEFAULT 0.00,
    currency TEXT DEFAULT 'USD',
    dispute_amount NUMERIC(12,2) DEFAULT 0.00,
    status TEXT DEFAULT 'open',
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);
ALTER TABLE public.reconcile_records ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow authenticated full access" ON public.reconcile_records;
CREATE POLICY "Allow authenticated full access" ON public.reconcile_records FOR ALL USING (auth.role() = 'authenticated');
