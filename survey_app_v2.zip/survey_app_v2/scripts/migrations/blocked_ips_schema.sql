-- ============================================================
-- Blocked IPs table — powers the IP Tracker "Block" button and
-- Blocked IP List page with REAL enforcement (checked at survey entry).
-- ============================================================
CREATE TABLE IF NOT EXISTS public.blocked_ips (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    ip_address TEXT UNIQUE NOT NULL,
    comment TEXT,
    blocked_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);
ALTER TABLE public.blocked_ips ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow authenticated full access" ON public.blocked_ips;
CREATE POLICY "Allow authenticated full access" ON public.blocked_ips FOR ALL USING (auth.role() = 'authenticated');
DROP POLICY IF EXISTS "Allow service role full access" ON public.blocked_ips;
CREATE POLICY "Allow service role full access" ON public.blocked_ips FOR ALL USING (true);

CREATE INDEX IF NOT EXISTS idx_blocked_ips_ip ON blocked_ips(ip_address);
