-- ============================================================
-- Client-Level Redirect — a stable, permanent code per client so
-- vendors/clients get ONE redirect URL that never needs to change
-- even as new projects get added for that client. Ported from
-- ExaVerify's client_redirect.php concept.
-- ============================================================
ALTER TABLE public.clients ADD COLUMN IF NOT EXISTS client_code TEXT UNIQUE;
