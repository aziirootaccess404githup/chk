-- ============================================================
-- Billing / Invoice-Status — ported from ExaVerify's exz_invoice_status
-- table + the Billing tab's Revenue/Cost/Margin calculation
-- (Revenue = completes × cpi, Cost = completes × supplier_cpi).
-- Added directly to projects (simpler than a separate join table,
-- since it's a 1:1 relationship).
-- ============================================================
ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS invoice_status TEXT DEFAULT 'unpaid';
ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS invoice_no TEXT;
ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS invoice_notes TEXT;
