-- ============================================================
-- 3-Tier Role System — upgrades admin/employee to ExaVerify's
-- superadmin/manager/viewer structure.
--   superadmin — full control, including Team management (was 'admin')
--   manager    — normal day-to-day access (was 'employee')
--   viewer     — read-only (new tier, not previously available)
-- Existing accounts are migrated automatically, no manual step needed.
-- ============================================================
UPDATE public.profiles SET role = 'superadmin' WHERE role = 'admin';
UPDATE public.profiles SET role = 'manager' WHERE role = 'employee' OR role IS NULL;

ALTER TABLE public.profiles ALTER COLUMN role SET DEFAULT 'manager';
