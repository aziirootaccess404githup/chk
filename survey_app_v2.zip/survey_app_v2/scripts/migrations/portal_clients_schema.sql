-- ============================================================
-- Client Portal Accounts — real per-client login (username +
-- salted-hashed password using Node's built-in crypto.scrypt,
-- no external password-hashing library needed). Separate from
-- the admin Supabase Auth system entirely.
-- ============================================================
CREATE TABLE IF NOT EXISTS public.portal_clients (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    client_id UUID REFERENCES public.clients(id) ON DELETE CASCADE,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    password_salt TEXT NOT NULL,
    extra_project_ids JSONB DEFAULT '[]'::jsonb,
    status TEXT DEFAULT 'active',
    last_login TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);
ALTER TABLE public.portal_clients ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow authenticated full access" ON public.portal_clients;
CREATE POLICY "Allow authenticated full access" ON public.portal_clients FOR ALL USING (auth.role() = 'authenticated');
DROP POLICY IF EXISTS "Allow service role full access" ON public.portal_clients;
CREATE POLICY "Allow service role full access" ON public.portal_clients FOR ALL USING (true);
