-- ============================================================
-- Geo / Device / Browser tracking — ported from ExaVerify's
-- exz_geo() (ip-api.com + ipapi.co fallback) and exz_device()/
-- exz_browser() (User-Agent parsing). Real, free, no API key needed.
-- ============================================================
ALTER TABLE public.tracking_logs ADD COLUMN IF NOT EXISTS country TEXT;
ALTER TABLE public.tracking_logs ADD COLUMN IF NOT EXISTS city TEXT;
ALTER TABLE public.tracking_logs ADD COLUMN IF NOT EXISTS device TEXT;
ALTER TABLE public.tracking_logs ADD COLUMN IF NOT EXISTS browser TEXT;
