export default function RightSidebar() {
    return (
        
  <>
    <div className="sidebar sidebar-right sidebar-animate">
                <div className="panel panel-primary card mb-0 box-shadow">
                    <div className="tab-menu-heading border-0 p-3">
                        <div className="card-title mb-0">Notifications</div>
                        <div className="card-options ml-auto">
                            <a href="#" className="sidebar-remove"><i className="fe fe-x"></i></a>
                        </div>
                    </div>
                    <div className="panel-body tabs-menu-body latest-tasks p-0 border-0">
                        <div className="tabs-menu ">
                            
                            <ul className="nav panel-tabs">
                                <li className=""><a href="#side1" className="active" data-toggle="tab"><i className="ion ion-md-chatboxes tx-18 mr-2"></i> Chat</a></li>
                                <li><a href="#side2" data-toggle="tab"><i className="ion ion-md-notifications tx-18  mr-2"></i> Notifications</a></li>
                                <li><a href="#side3" data-toggle="tab"><i className="ion ion-md-contacts tx-18 mr-2"></i> Friends</a></li>
                            </ul>
                        </div>
                        <div className="tab-content">
                            <div className="tab-pane active " id="side1">
                                <div className="list d-flex align-items-center border-bottom p-3">
                                    <div className="">
                                        <span className="avatar bg-primary brround avatar-md">CH</span>
                                    </div>
                                    <a className="wrapper w-100 ml-3" href="#">
                                        <p className="mb-0 d-flex ">
                                            <b>New Websites is Created</b>
                                        </p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="d-flex align-items-center">
                                                <i className="mdi mdi-clock text-muted mr-1"></i>
                                                <small className="text-muted ml-auto">30 mins ago</small>
                                                <p className="mb-0"></p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div className="list d-flex align-items-center border-bottom p-3">
                                    <div className="">
                                        <span className="avatar bg-danger brround avatar-md">N</span>
                                    </div>
                                    <a className="wrapper w-100 ml-3" href="#">
                                        <p className="mb-0 d-flex ">
                                            <b>Prepare For the Next Project</b>
                                        </p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="d-flex align-items-center">
                                                <i className="mdi mdi-clock text-muted mr-1"></i>
                                                <small className="text-muted ml-auto">2 hours ago</small>
                                                <p className="mb-0"></p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div className="list d-flex align-items-center border-bottom p-3">
                                    <div className="">
                                        <span className="avatar bg-info brround avatar-md">S</span>
                                    </div>
                                    <a className="wrapper w-100 ml-3" href="#">
                                        <p className="mb-0 d-flex ">
                                            <b>Decide the live Discussion</b>
                                        </p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="d-flex align-items-center">
                                                <i className="mdi mdi-clock text-muted mr-1"></i>
                                                <small className="text-muted ml-auto">3 hours ago</small>
                                                <p className="mb-0"></p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div className="list d-flex align-items-center border-bottom p-3">
                                    <div className="">
                                        <span className="avatar bg-warning brround avatar-md">K</span>
                                    </div>
                                    <a className="wrapper w-100 ml-3" href="#">
                                        <p className="mb-0 d-flex ">
                                            <b>Meeting at 3:00 pm</b>
                                        </p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="d-flex align-items-center">
                                                <i className="mdi mdi-clock text-muted mr-1"></i>
                                                <small className="text-muted ml-auto">4 hours ago</small>
                                                <p className="mb-0"></p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div className="list d-flex align-items-center border-bottom p-3">
                                    <div className="">
                                        <span className="avatar bg-success brround avatar-md">R</span>
                                    </div>
                                    <a className="wrapper w-100 ml-3" href="#">
                                        <p className="mb-0 d-flex ">
                                            <b>Prepare for Presentation</b>
                                        </p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="d-flex align-items-center">
                                                <i className="mdi mdi-clock text-muted mr-1"></i>
                                                <small className="text-muted ml-auto">1 days ago</small>
                                                <p className="mb-0"></p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div className="list d-flex align-items-center border-bottom p-3">
                                    <div className="">
                                        <span className="avatar bg-pink brround avatar-md">MS</span>
                                    </div>
                                    <a className="wrapper w-100 ml-3" href="#">
                                        <p className="mb-0 d-flex ">
                                            <b>Prepare for Presentation</b>
                                        </p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="d-flex align-items-center">
                                                <i className="mdi mdi-clock text-muted mr-1"></i>
                                                <small className="text-muted ml-auto">1 days ago</small>
                                                <p className="mb-0"></p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div className="list d-flex align-items-center border-bottom p-3">
                                    <div className="">
                                        <span className="avatar bg-purple brround avatar-md">L</span>
                                    </div>
                                    <a className="wrapper w-100 ml-3" href="#">
                                        <p className="mb-0 d-flex ">
                                            <b>Prepare for Presentation</b>
                                        </p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="d-flex align-items-center">
                                                <i className="mdi mdi-clock text-muted mr-1"></i>
                                                <small className="text-muted ml-auto">45 mintues ago</small>
                                                <p className="mb-0"></p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div className="list d-flex align-items-center p-3">
                                    <div className="">
                                        <span className="avatar bg-blue brround avatar-md">U</span>
                                    </div>
                                    <a className="wrapper w-100 ml-3" href="#">
                                        <p className="mb-0 d-flex ">
                                            <b>Prepare for Presentation</b>
                                        </p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="d-flex align-items-center">
                                                <i className="mdi mdi-clock text-muted mr-1"></i>
                                                <small className="text-muted ml-auto">2 days ago</small>
                                                <p className="mb-0"></p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div className="tab-pane  " id="side2">
                                <div className="list-group list-group-flush ">
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-3">
                                            <span className="avatar avatar-lg brround cover-image" data-image-src="~/assets/img/faces/12.jpg"><span className="avatar-status bg-success"></span></span>
                                        </div>
                                        <div>
                                            <strong>Madeleine</strong> Hey! there I' am available....
                                            <div className="small text-muted">
                                                3 hours ago
                                            </div>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-3">
                                            <span className="avatar avatar-lg brround cover-image" data-image-src="~/assets/img/faces/1.jpg"></span>
                                        </div>
                                        <div>
                                            <strong>Anthony</strong> New product Launching...
                                            <div className="small text-muted">
                                                5 hour ago
                                            </div>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-3">
                                            <span className="avatar avatar-lg brround cover-image" data-image-src="~/assets/img/faces/2.jpg"><span className="avatar-status bg-success"></span></span>
                                        </div>
                                        <div>
                                            <strong>Olivia</strong> New Schedule Realease......
                                            <div className="small text-muted">
                                                45 mintues ago
                                            </div>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-3">
                                            <span className="avatar avatar-lg brround cover-image" data-image-src="~/assets/img/faces/8.jpg"><span className="avatar-status bg-success"></span></span>
                                        </div>
                                        <div>
                                            <strong>Madeleine</strong> Hey! there I' am available....
                                            <div className="small text-muted">
                                                3 hours ago
                                            </div>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-3">
                                            <span className="avatar avatar-lg brround cover-image" data-image-src="~/assets/img/faces/11.jpg"></span>
                                        </div>
                                        <div>
                                            <strong>Anthony</strong> New product Launching...
                                            <div className="small text-muted">
                                                5 hour ago
                                            </div>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-3">
                                            <span className="avatar avatar-lg brround cover-image" data-image-src="~/assets/img/faces/6.jpg"><span className="avatar-status bg-success"></span></span>
                                        </div>
                                        <div>
                                            <strong>Olivia</strong> New Schedule Realease......
                                            <div className="small text-muted">
                                                45 mintues ago
                                            </div>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-3">
                                            <span className="avatar avatar-lg brround cover-image" data-image-src="~/assets/img/faces/9.jpg"><span className="avatar-status bg-success"></span></span>
                                        </div>
                                        <div>
                                            <strong>Olivia</strong> Hey! there I' am available....
                                            <div className="small text-muted">
                                                12 mintues ago
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="tab-pane  " id="side3">
                                <div className="list-group list-group-flush ">
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-2">
                                            <span className="avatar avatar-md brround cover-image" data-image-src="~/assets/img/faces/9.jpg"><span className="avatar-status bg-success"></span></span>
                                        </div>
                                        <div className="">
                                            <div className="font-weight-semibold" data-toggle="modal" data-target="#chatmodel">Mozelle Belt</div>
                                        </div>
                                        <div className="ml-auto">
                                            <a href="#" className="btn btn-sm btn-light" data-toggle="modal" data-target="#chatmodel"><i className="fab fa-facebook-messenger"></i></a>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-2">
                                            <span className="avatar avatar-md brround cover-image" data-image-src="~/assets/img/faces/11.jpg"></span>
                                        </div>
                                        <div className="">
                                            <div className="font-weight-semibold" data-toggle="modal" data-target="#chatmodel">Florinda Carasco</div>
                                        </div>
                                        <div className="ml-auto">
                                            <a href="#" className="btn btn-sm btn-light" data-toggle="modal" data-target="#chatmodel"><i className="fab fa-facebook-messenger"></i></a>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-2">
                                            <span className="avatar avatar-md brround cover-image" data-image-src="~/assets/img/faces/10.jpg"><span className="avatar-status bg-success"></span></span>
                                        </div>
                                        <div className="">
                                            <div className="font-weight-semibold" data-toggle="modal" data-target="#chatmodel">Alina Bernier</div>
                                        </div>
                                        <div className="ml-auto">
                                            <a href="#" className="btn btn-sm btn-light" data-toggle="modal" data-target="#chatmodel"><i className="fab fa-facebook-messenger"></i></a>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-2">
                                            <span className="avatar avatar-md brround cover-image" data-image-src="~/assets/img/faces/2.jpg"><span className="avatar-status bg-success"></span></span>
                                        </div>
                                        <div className="">
                                            <div className="font-weight-semibold" data-toggle="modal" data-target="#chatmodel">Zula Mclaughin</div>
                                        </div>
                                        <div className="ml-auto">
                                            <a href="#" className="btn btn-sm btn-light" data-toggle="modal" data-target="#chatmodel"><i className="fab fa-facebook-messenger"></i></a>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-2">
                                            <span className="avatar avatar-md brround cover-image" data-image-src="~/assets/img/faces/13.jpg"></span>
                                        </div>
                                        <div className="">
                                            <div className="font-weight-semibold" data-toggle="modal" data-target="#chatmodel">Isidro Heide</div>
                                        </div>
                                        <div className="ml-auto">
                                            <a href="#" className="btn btn-sm btn-light" data-toggle="modal" data-target="#chatmodel"><i className="fab fa-facebook-messenger"></i></a>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-2">
                                            <span className="avatar avatar-md brround cover-image" data-image-src="~/assets/img/faces/12.jpg"><span className="avatar-status bg-success"></span></span>
                                        </div>
                                        <div className="">
                                            <div className="font-weight-semibold" data-toggle="modal" data-target="#chatmodel">Mozelle Belt</div>
                                        </div>
                                        <div className="ml-auto">
                                            <a href="#" className="btn btn-sm btn-light"><i className="fab fa-facebook-messenger"></i></a>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-2">
                                            <span className="avatar avatar-md brround cover-image" data-image-src="~/assets/img/faces/4.jpg"></span>
                                        </div>
                                        <div className="">
                                            <div className="font-weight-semibold" data-toggle="modal" data-target="#chatmodel">Florinda Carasco</div>
                                        </div>
                                        <div className="ml-auto">
                                            <a href="#" className="btn btn-sm btn-light" data-toggle="modal" data-target="#chatmodel"><i className="fab fa-facebook-messenger"></i></a>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-2">
                                            <span className="avatar avatar-md brround cover-image" data-image-src="~/assets/img/faces/7.jpg"></span>
                                        </div>
                                        <div className="">
                                            <div className="font-weight-semibold" data-toggle="modal" data-target="#chatmodel">Alina Bernier</div>
                                        </div>
                                        <div className="ml-auto">
                                            <a href="#" className="btn btn-sm btn-light"><i className="fab fa-facebook-messenger"></i></a>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-2">
                                            <span className="avatar avatar-md brround cover-image" data-image-src="~/assets/img/faces/2.jpg"></span>
                                        </div>
                                        <div className="">
                                            <div className="font-weight-semibold" data-toggle="modal" data-target="#chatmodel">Zula Mclaughin</div>
                                        </div>
                                        <div className="ml-auto">
                                            <a href="#" className="btn btn-sm btn-light" data-toggle="modal" data-target="#chatmodel"><i className="fab fa-facebook-messenger"></i></a>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-2">
                                            <span className="avatar avatar-md brround cover-image" data-image-src="~/assets/img/faces/14.jpg"><span className="avatar-status bg-success"></span></span>
                                        </div>
                                        <div className="">
                                            <div className="font-weight-semibold" data-toggle="modal" data-target="#chatmodel">Isidro Heide</div>
                                        </div>
                                        <div className="ml-auto">
                                            <a href="#" className="btn btn-sm btn-light"><i className="fab fa-facebook-messenger"></i></a>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-2">
                                            <span className="avatar avatar-md brround cover-image" data-image-src="~/assets/img/faces/11.jpg"></span>
                                        </div>
                                        <div className="">
                                            <div className="font-weight-semibold" data-toggle="modal" data-target="#chatmodel">Florinda Carasco</div>
                                        </div>
                                        <div className="ml-auto">
                                            <a href="#" className="btn btn-sm btn-light" data-toggle="modal" data-target="#chatmodel"><i className="fab fa-facebook-messenger"></i></a>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-2">
                                            <span className="avatar avatar-md brround cover-image" data-image-src="~/assets/img/faces/9.jpg"></span>
                                        </div>
                                        <div className="">
                                            <div className="font-weight-semibold" data-toggle="modal" data-target="#chatmodel">Alina Bernier</div>
                                        </div>
                                        <div className="ml-auto">
                                            <a href="#" className="btn btn-sm btn-light" data-toggle="modal" data-target="#chatmodel"><i className="fab fa-facebook-messenger"></i></a>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-2">
                                            <span className="avatar avatar-md brround cover-image" data-image-src="~/assets/img/faces/15.jpg"><span className="avatar-status bg-success"></span></span>
                                        </div>
                                        <div className="">
                                            <div className="font-weight-semibold" data-toggle="modal" data-target="#chatmodel">Zula Mclaughin</div>
                                        </div>
                                        <div className="ml-auto">
                                            <a href="#" className="btn btn-sm btn-light" data-toggle="modal" data-target="#chatmodel"><i className="fab fa-facebook-messenger"></i></a>
                                        </div>
                                    </div>
                                    <div className="list-group-item d-flex  align-items-center">
                                        <div className="mr-2">
                                            <span className="avatar avatar-md brround cover-image" data-image-src="~/assets/img/faces/4.jpg"></span>
                                        </div>
                                        <div className="">
                                            <div className="font-weight-semibold" data-toggle="modal" data-target="#chatmodel">Isidro Heide</div>
                                        </div>
                                        <div className="ml-auto">
                                            <a href="#" className="btn btn-sm btn-light" data-toggle="modal" data-target="#chatmodel"><i className="fab fa-facebook-messenger"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    <div className="modal fade" id="chatmodel" tabIndex="-1" role="dialog" aria-hidden="true">
                <div className="modal-dialog modal-dialog-right chatbox" role="document">
                    <div className="modal-content chat border-0">
                        <div className="card overflow-hidden mb-0 border-0">
                            
                            <div className="action-header clearfix">
                                <div className="float-left hidden-xs d-flex ml-2">
                                    <div className="img_cont mr-3">
                                        <img src="../../assets/img/faces/6.jpg" className="rounded-circle user_img" alt="img" />
                                    </div>
                                    <div className="align-items-center mt-2">
                                        <h4 className="text-white mb-0 font-weight-semibold">Daneil Scott</h4>
                                        <span className="dot-label bg-success"></span><span className="mr-3 text-white">online</span>
                                    </div>
                                </div>
                                <ul className="ah-actions actions align-items-center">
                                    <li className="call-icon">
                                        <a href="" className="d-done d-md-block phone-button" data-toggle="modal" data-target="#audiomodal">
                                            <i className="si si-phone"></i>
                                        </a>
                                    </li>
                                    <li className="video-icon">
                                        <a href="" className="d-done d-md-block phone-button" data-toggle="modal" data-target="#videomodal">
                                            <i className="si si-camrecorder"></i>
                                        </a>
                                    </li>
                                    <li className="dropdown">
                                        <a href="" data-toggle="dropdown" aria-expanded="true">
                                            <i className="si si-options-vertical"></i>
                                        </a>
                                        <ul className="dropdown-menu dropdown-menu-right">
                                            <li><i className="fas fa-user-circle"></i> View profile</li>
                                            <li><i className="fas fa-users"></i>Add friends</li>
                                            <li><i className="fas fa-plus"></i> Add to group</li>
                                            <li><i className="fas fa-ban"></i> Block</li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="" className="" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true"><i className="si si-close text-white"></i></span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            
                            
                            <div className="card-body msg_card_body">
                                <div className="chat-box-single-line">
                                    <abbr className="timestamp">February 1st, 2019</abbr>
                                </div>
                                <div className="d-flex justify-content-start">
                                    <div className="img_cont_msg">
                                        <img src="../../assets/img/faces/6.jpg" className="rounded-circle user_img_msg" alt="img" />
                                    </div>
                                    <div className="msg_cotainer">
                                        Hi, how are you Jenna Side?
                                        <span className="msg_time">8:40 AM, Today</span>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-end ">
                                    <div className="msg_cotainer_send">
                                        Hi Connor Paige i am good tnx how about you?
                                        <span className="msg_time_send">8:55 AM, Today</span>
                                    </div>
                                    <div className="img_cont_msg">
                                        <img src="../../assets/img/faces/9.jpg" className="rounded-circle user_img_msg" alt="img" />
                                    </div>
                                </div>
                                <div className="d-flex justify-content-start ">
                                    <div className="img_cont_msg">
                                        <img src="../../assets/img/faces/6.jpg" className="rounded-circle user_img_msg" alt="img" />
                                    </div>
                                    <div className="msg_cotainer">
                                        I am good too, thank you for your chat template
                                        <span className="msg_time">9:00 AM, Today</span>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-end ">
                                    <div className="msg_cotainer_send">
                                        You welcome Connor Paige
                                        <span className="msg_time_send">9:05 AM, Today</span>
                                    </div>
                                    <div className="img_cont_msg">
                                        <img src="../../assets/img/faces/9.jpg" className="rounded-circle user_img_msg" alt="img" />
                                    </div>
                                </div>
                                <div className="d-flex justify-content-start ">
                                    <div className="img_cont_msg">
                                        <img src="../../assets/img/faces/6.jpg" className="rounded-circle user_img_msg" alt="img" />
                                    </div>
                                    <div className="msg_cotainer">
                                        Yo, Can you update Views?
                                        <span className="msg_time">9:07 AM, Today</span>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-end mb-4">
                                    <div className="msg_cotainer_send">
                                        But I must explain to you how all this mistaken  born and I will give
                                        <span className="msg_time_send">9:10 AM, Today</span>
                                    </div>
                                    <div className="img_cont_msg">
                                        <img src="../../assets/img/faces/9.jpg" className="rounded-circle user_img_msg" alt="img" />
                                    </div>
                                </div>
                                <div className="d-flex justify-content-start ">
                                    <div className="img_cont_msg">
                                        <img src="../../assets/img/faces/6.jpg" className="rounded-circle user_img_msg" alt="img" />
                                    </div>
                                    <div className="msg_cotainer">
                                        Yo, Can you update Views?
                                        <span className="msg_time">9:07 AM, Today</span>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-end mb-4">
                                    <div className="msg_cotainer_send">
                                        But I must explain to you how all this mistaken  born and I will give
                                        <span className="msg_time_send">9:10 AM, Today</span>
                                    </div>
                                    <div className="img_cont_msg">
                                        <img src="../../assets/img/faces/9.jpg" className="rounded-circle user_img_msg" alt="img" />
                                    </div>
                                </div>
                                <div className="d-flex justify-content-start ">
                                    <div className="img_cont_msg">
                                        <img src="../../assets/img/faces/6.jpg" className="rounded-circle user_img_msg" alt="img" />
                                    </div>
                                    <div className="msg_cotainer">
                                        Yo, Can you update Views?
                                        <span className="msg_time">9:07 AM, Today</span>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-end mb-4">
                                    <div className="msg_cotainer_send">
                                        But I must explain to you how all this mistaken  born and I will give
                                        <span className="msg_time_send">9:10 AM, Today</span>
                                    </div>
                                    <div className="img_cont_msg">
                                        <img src="../../assets/img/faces/9.jpg" className="rounded-circle user_img_msg" alt="img" />
                                    </div>
                                </div>
                                <div className="d-flex justify-content-start">
                                    <div className="img_cont_msg">
                                        <img src="../../assets/img/faces/6.jpg" className="rounded-circle user_img_msg" alt="img" />
                                    </div>
                                    <div className="msg_cotainer">
                                        Okay Bye, text you later..
                                        <span className="msg_time">9:12 AM, Today</span>
                                    </div>
                                </div>
                            </div>
                            
                            
                            <div className="card-footer">
                                <div className="msb-reply d-flex">
                                    <div className="input-group">
                                        <input type="text" className="form-control " placeholder="Typing...." />
                                        <div className="input-group-append ">
                                            <button type="button" className="btn btn-primary ">
                                                <i className="far fa-paper-plane" aria-hidden="true"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    <div id="videomodal" className="modal fade">
                <div className="modal-dialog" role="document">
                    <div className="modal-content bg-dark border-0 text-white">
                        <div className="modal-body mx-auto text-center p-7">
                            <h5>Valex Video call</h5>
                            <img src="../../assets/img/faces/6.jpg" className="rounded-circle user-img-circle h-8 w-8 mt-4 mb-3" alt="img" />
                            <h4 className="mb-1 font-weight-semibold">Daneil Scott</h4>
                            <h6>Calling...</h6>
                            <div className="mt-5">
                                <div className="row">
                                    <div className="col-4">
                                        <a className="icon icon-shape rounded-circle mb-0 mr-3" href="#">
                                            <i className="fas fa-video-slash"></i>
                                        </a>
                                    </div>
                                    <div className="col-4">
                                        <a className="icon icon-shape rounded-circle text-white mb-0 mr-3" href="#" data-dismiss="modal" aria-label="Close">
                                            <i className="fas fa-phone bg-danger text-white"></i>
                                        </a>
                                    </div>
                                    <div className="col-4">
                                        <a className="icon icon-shape rounded-circle mb-0 mr-3" href="#">
                                            <i className="fas fa-microphone-slash"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    <div id="audiomodal" className="modal fade">
                <div className="modal-dialog" role="document">
                    <div className="modal-content border-0">
                        <div className="modal-body mx-auto text-center p-7">
                            <h5>Valex Voice call</h5>
                            <img src="../../assets/img/faces/6.jpg" className="rounded-circle user-img-circle h-8 w-8 mt-4 mb-3" alt="img" />
                            <h4 className="mb-1  font-weight-semibold">Daneil Scott</h4>
                            <h6>Calling...</h6>
                            <div className="mt-5">
                                <div className="row">
                                    <div className="col-4">
                                        <a className="icon icon-shape rounded-circle mb-0 mr-3" href="#">
                                            <i className="fas fa-volume-up bg-light"></i>
                                        </a>
                                    </div>
                                    <div className="col-4">
                                        <a className="icon icon-shape rounded-circle text-white mb-0 mr-3" href="#" data-dismiss="modal" aria-label="Close">
                                            <i className="fas fa-phone text-white bg-success"></i>
                                        </a>
                                    </div>
                                    <div className="col-4">
                                        <a className="icon icon-shape  rounded-circle mb-0 mr-3" href="#">
                                            <i className="fas fa-microphone-slash bg-light"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
  </>

    );
}