"use client";
import React, { useState, useEffect } from 'react';
import { createClient } from '@/utils/supabase/client';
import { logout } from '@/app/login/actions';

export default function Header({ initialProfile = { full_name: 'User', role: 'manager' } }) {
    const [profile, setProfile] = useState(initialProfile);

    return (
        <div className="main-header sticky side-header nav nav-item">
                <div className="container-fluid">
                    <div className="main-header-left ">
                        <div className="responsive-logo">
                            <a href="#"><img src="/images/logo.png" className="logoMN" alt="logo" style={{ height: '75px', maxHeight: 'none', width: 'auto' }} /></a>
                        </div>
                        <div className="app-sidebar__toggle" onClick={(e) => { e.preventDefault(); document.body.classList.toggle('sidenav-toggled'); }}>
                            <a className="open-toggle" href="#"><i className="header-icon fe fe-align-left"></i></a>
                            <a className="close-toggle" href="#"><i className="header-icons fe fe-x"></i></a>
                        </div>
                    </div>
                    <div className="main-header-right">
                        <div className="nav nav-item  navbar-nav-right ml-auto">
                            <div className="nav-link" id="bs-example-navbar-collapse-1">
                                <form className="navbar-form" role="search">
                                    <div className="input-group">
                                        <input type="text" className="form-control" placeholder="Search" />
                                        <span className="input-group-btn">
                                            <button type="reset" className="btn btn-default">
                                                <i className="fas fa-times"></i>
                                            </button>
                                            <button type="submit" className="btn btn-default nav-link resp-btn">
                                                <svg xmlns="http://www.w3.org/2000/svg" className="header-icon-svgs" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                                            </button>
                                        </span>
                                    </div>
                                </form>
                            </div>
                            <div className="nav-item full-screen fullscreen-button">
                                <a className="new nav-link full-screen-link" href="#"><svg xmlns="http://www.w3.org/2000/svg" className="header-icon-svgs" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path></svg></a>
                            </div>
                            <div className="dropdown main-profile-menu nav nav-item nav-link">
                                <a className="profile-user d-flex" href="" style={{}} >
                                    <span className="userNameTop" title={profile.full_name}> {profile.full_name} </span>
                                    <i className="far fa-user"></i>
                                </a>
                                <div className="dropdown-menu">
                                    <div className="main-header-profile bg-primary p-3">
                                        <div className="d-flex wd-100p">
                                            <div className="main-img-user">
                                                <img alt="" src="../../images/user-avtar.png" />
                                            </div>
                                            <div className="ml-3 my-auto">
                                                <h6>{profile.full_name}</h6><span>{profile.role === 'superadmin' ? 'Superadmin' : profile.role === 'viewer' ? 'Viewer' : 'Manager'}</span>
                                            </div>
                                        </div>
                                    </div>
                                        <a className="dropdown-item" href="#"><i className="bx bx-user-circle"></i>Profile</a>
                                    <a className="dropdown-item" href="#" onClick={(e) => { e.preventDefault(); logout(); }}><i className="bx bx-log-out"></i>Sign Out</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    );
}