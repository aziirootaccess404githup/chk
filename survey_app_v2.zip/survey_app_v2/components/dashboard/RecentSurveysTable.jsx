import React from 'react';

export default function RecentSurveysTable({ surveys }) {
    return (
        <div className="card topPrSrvy">
            <div className="grpTxt grpBG">
                <p className="grpTxt grpBH mb-0 pl-2 mb-2"> Recent Active Surveys  </p>
            </div>
            <div className="table-responsive topPrSrvyGrid">
                <table className="table table-sm align-items-center mb-0">
                    <thead>
                        <tr>
                            <th scope="col"> ProjectCode </th>
                            <th scope="col"> Name </th>
                            <th scope="col"> Count </th>
                        </tr>
                    </thead>
                    <tbody>
                        {surveys && surveys.length > 0 ? (
                            surveys.map((item, index) => (
                                <tr key={index}>
                                    <td> <a href="#" target="_blank"> {item.projectCode} </a> </td>
                                    <td> <h6 className="mb-0 text-sm leftHD textEll"> {item.projectName} </h6> </td>
                                    <td> <strong> {item.completeCount} </strong> </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan="3">No Record Found !</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
