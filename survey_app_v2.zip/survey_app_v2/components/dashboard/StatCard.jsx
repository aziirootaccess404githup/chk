import React from 'react';

export default function StatCard({ title, count, iconPath, boxClass }) {
    return (
        <div className="col-md-4 col-xm-12">
            <div className={`card valBox ${boxClass} overflow-hidden`}>
                <div className="">
                    <div className="crLeft">
                        <div className="crImg"> 
                            <img src={iconPath} alt={title} /> 
                        </div>
                    </div>
                    <div className="crRgt">
                        <p className="crTxt mb-0"> {title} </p>
                        <div className="">
                            <p className="numTxt mb-0">{count}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
