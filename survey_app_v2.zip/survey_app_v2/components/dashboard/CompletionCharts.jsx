"use client";
import React, { useEffect } from 'react';

export default function CompletionCharts({ charts }) {
    useEffect(() => {
        const initCharts = () => {
            if (typeof window === 'undefined' || !window.Highcharts) {
                setTimeout(initCharts, 500);
                return;
            }

            const Highcharts = window.Highcharts;

            // Fallback empty data if server didn't provide any
            const data = charts || {
                monthlyCompletes: new Array(12).fill(0),
                dailyCompletes: new Array(7).fill(0),
                tsignDaily: new Array(7).fill(0),
                tsignMonthly: new Array(12).fill(0),
                last7DaysLabels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7']
            };

            // 1. Monthly Completes
            if (document.getElementById('containerMonthly')) {
                Highcharts.chart('containerMonthly', {
                    chart: { type: 'column' },
                    title: { text: null },
                    xAxis: { categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'] },
                    yAxis: { title: { text: 'Completes' } },
                    series: [{ name: 'Completes', data: data.monthlyCompletes }],
                    credits: { enabled: false }
                });
            }

            // 2. Daily Completes
            if (document.getElementById('containerDaily')) {
                Highcharts.chart('containerDaily', {
                    chart: { type: 'line' },
                    title: { text: null },
                    xAxis: { categories: data.last7DaysLabels },
                    yAxis: { title: { text: 'Completes' } },
                    series: [{ name: 'Completes', data: data.dailyCompletes, color: '#348cd4' }],
                    credits: { enabled: false }
                });
            }

            // 3. Tsign Daily Trend
            if (document.getElementById('tsignchartDaily')) {
                Highcharts.chart('tsignchartDaily', {
                    chart: { type: 'area' },
                    title: { text: null },
                    xAxis: { categories: data.last7DaysLabels },
                    yAxis: { title: { text: 'Trend' } },
                    series: [{ name: 'Tsign Trend', data: data.tsignDaily, color: '#f7531f', fillOpacity: 0.3 }],
                    credits: { enabled: false }
                });
            }

            // 4. Tsign Monthly Trend
            if (document.getElementById('tsignMonthly')) {
                Highcharts.chart('tsignMonthly', {
                    chart: { type: 'column' },
                    title: { text: null },
                    xAxis: { categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'] },
                    yAxis: { title: { text: 'Trend' } },
                    series: [{ name: 'Tsign Trend', data: data.tsignMonthly, color: '#ff9800' }],
                    credits: { enabled: false }
                });
            }
        };

        initCharts();
    }, []);

    return (
        <>
            <div className="row">
                <div className="col-md-6 col-12">
                    <div className="statsCardBox">
                        <div className="card">
                            <div className="grpTxt grpBG">
                                <p className="grpTxt grpBH mb-0 pl-2 mb-2"> Monthly Completes </p>
                            </div>
                            <figure className="highcharts-figure">
                                <div id="containerMonthly" className="srvDBGraph" style={{height: '300px'}}></div>
                            </figure>
                        </div>
                    </div>
                </div>
                <div className="col-md-6 col-12">
                    <div className="statsCardBox">
                        <div className="card">
                            <div className="grpTxt grpBG">
                                <p className="grpTxt grpBH mb-0 pl-2 mb-2"> Daily Completes </p>
                            </div>
                            <figure className="highcharts-figure">
                                <div id="containerDaily" className="srvDBGraph" style={{height: '300px'}}></div>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
            
            <div className="row">
                <div className="col-md-6 col-12">
                    <div className="statsCardBox">
                        <div className="card">
                            <div className="grpTxt grpBG">
                                <p className="grpTxt grpBH mb-0 pl-2 mb-2"> Tsign Daily Trend </p>
                            </div>
                            <div id="tsignchartDaily" style={{height: '300px'}}></div>
                        </div>
                    </div>
                </div>
                <div className="col-md-6 col-12">
                    <div className="statsCardBox">
                        <div className="card">
                            <div className="grpTxt grpBG">
                                <p className="grpTxt grpBH mb-0 pl-2 mb-2"> Tsign Monthly Trend </p>
                            </div>
                            <figure className="highcharts-figure">
                                <div id="tsignMonthly" className="RdMonthly" style={{height: '300px'}}></div>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
