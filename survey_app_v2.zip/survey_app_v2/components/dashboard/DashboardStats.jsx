import React from 'react';
import StatCard from './StatCard';

export default function DashboardStats({ stats }) {
    return (
        <div className="row row-sm statsCardBox">
            {stats.map((stat, index) => (
                <StatCard 
                    key={index}
                    title={stat.title}
                    count={stat.count}
                    iconPath={stat.iconPath}
                    boxClass={stat.boxClass}
                />
            ))}
        </div>
    );
}
