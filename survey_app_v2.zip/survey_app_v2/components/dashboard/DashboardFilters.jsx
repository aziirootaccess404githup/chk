"use client";
import React, { useState } from 'react';

export default function DashboardFilters() {
    const [client, setClient] = useState('');
    const [manager, setManager] = useState('');
    const [projectCode, setProjectCode] = useState('');
    const [searchProject, setSearchProject] = useState('');

    const clients = [
        "Talkto-Panel Researc", "Research 8020", "Dreamlock MR", "MindsForest", 
        "Keto ", "Insights Probe", "The Field Data "
    ];

    const managers = [
        "akanksha", "aaa", "aastha", "abhishek", "aditya", "animesh", "dipesh"
    ];

    const handleSearch = () => {
        console.log("Searching with:", { client, manager, projectCode, searchProject });
    };

    const handleReset = () => {
        setClient('');
        setManager('');
        setProjectCode('');
        setSearchProject('');
    };

    return (
        <>
            <div className="row1" id="advanceSearch" style={{display: "none"}}>
                <div className="filterSearchDB form-inline justify-content-end">
                    <div className="numTabSMSearch numMT select2UI">
                        <select 
                            className="form-control select2 dropdownsel" 
                            name="ClientSearch" 
                            id="SearchClientText" 
                            title="Press Enter to Search"
                            value={client}
                            onChange={(e) => setClient(e.target.value)}
                        >
                            <option value="">Client</option>
                            {clients.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                    </div>
                    <div className="numTabSMSearch numMT select2UI">
                        <select 
                            className="form-control select2 dropdownsel" 
                            name="ProjectManager" 
                            id="SearchPMText" 
                            title="Press Enter to Search"
                            value={manager}
                            onChange={(e) => setManager(e.target.value)}
                        >
                            <option value="">  Manager  </option>
                            {managers.map(m => <option key={m} value={m}>{m}</option>)}
                        </select>
                    </div>
                    <div className=" justify-content-end numTabSMSearch numMT">
                        <div className="app-search">
                            <div className="app-search-box">
                                <div className="input-group">
                                    <input 
                                        type="text" 
                                        className="form-control" 
                                        id="SearchProjectIdText" 
                                        placeholder="ProjectCode" 
                                        title="Press Enter to Search" 
                                        value={projectCode}
                                        onChange={(e) => setProjectCode(e.target.value)}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="justify-content-end numMT">
                        <div className="">
                            <div className="text-right">
                                <button className="readonly btn btn-bg-color mr-1" title="Search" type="button" id="submit" onClick={handleSearch}> 
                                    <i className="fa fa-search"></i> 
                                </button>
                                <button className="readonly btn btn-bg-color mr-1" title="Reset" type="button" id="reset" onClick={handleReset}> 
                                    <i className="fa fa-undo"></i> 
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="row mb-1 mt-3" id="searchbox">
                <div className="col-lg-7 col-12">
                    <div className="page-title-box">
                        <div className="page-title-right">
                            <ol className="breadcrumb m-0">
                                <li className="breadcrumb-item"><a href="#">Home</a></li>
                                <li className="breadcrumb-item active">Projects</li>
                            </ol>
                        </div>
                    </div>
                </div>
                <div className="col-lg-5 col-12">
                    <div className="searchBoxR">
                        <div className="search-container mb-2">
                            <input 
                                type="text" 
                                id="searchProject" 
                                className="search-input" 
                                placeholder="Search" 
                                value={searchProject}
                                onChange={(e) => setSearchProject(e.target.value)}
                            />
                            <a className="clearCrossIcon" onClick={() => setSearchProject('')}>
                                <i className="fa fa-times-circle"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
