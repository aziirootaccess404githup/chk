import React from 'react';

export default function ConversionsChart({ todayComplete, totalClick }) {
    return (
        <div className="statsCardBox">
            <div className="card">
                <div className="grpTxt crlTest">
                    <p className="grpTxt mb-0 pl-2 mb-2"> Conversions Today </p>
                </div>

                <div className="">
                    <div id="surveyConvert"></div>
                </div>
                <div className="row">
                    <div className="col-md-6 col-12">
                        <div className="col-12 chartWrapTxt">
                            <a data-toggle="modal" data-target="#TableViewModal" data-backdrop="static" data-keyboard="false">
                                <p className="chartTxtNo"> {todayComplete} </p>
                                <p className="chartTxtLine"> Today Complete </p>
                            </a>
                        </div>
                    </div>
                    <div className="col-md-6 col-12">
                        <div className="col-12 chartWrapTxt">
                            <p className="chartTxtNo"> {totalClick} </p>
                            <p className="chartTxtLine"> Total Click </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
