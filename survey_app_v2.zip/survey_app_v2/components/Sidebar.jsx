import Link from 'next/link';

export default function Sidebar() {
    return (
        <aside className="app-sidebar sidebar-scroll">
            

            <div className="main-sidemenu">

                <ul className="side-menu">
                                <li className="slide">
                                    <Link className="side-menu__item" href="/" >
                                        <img src="../../images/dashboardicon/dashboard.svg" className="dbicon" alt="icon" />
                                        <span className="side-menu__label">Dashboard</span>
                                    </Link>
                                </li>
                                <li className="slide">
                                    <a className="side-menu__item" data-toggle="slide" href="#">
                                        <img src="../../images/dashboardicon/project.svg" className="dbicon" alt="icon" />
                                        <span className="side-menu__label">Project</span>
                                        <i className="angle fe fe-chevron-down"></i>
                                    </a>
                                    <ul className="slide-menu">
                                            <li className="">
                                                <Link className="slide-item" href="/projects" >
                                                    <span>ProjectList</span>
                                                </Link>
                                            </li>
                                            <li className="slide">
                                                <a className="slide-item" data-toggle="slide" href="#">
                                                <span className="">Create Project</span>
                                                </a>
                                                <ul className="slide-menu" style={{display: "none"}}>
                                                    <li id="nes_5">
                                                    <Link className="slide-item" href="/projects/create/single" >
                                                    <span>Single</span>
                                                    </Link>
                                                    </li>
                                                    <li id="nes_6">
                                                    <Link className="slide-item" href="/projects/create/group" >
                                                    <span>Group</span>
                                                    </Link>
                                                    </li>
                                                    <li id="nes_7">
                                                    <Link className="slide-item" href="/projects/create/recontact" >
                                                    <span>ReContact</span>
                                                    </Link>
                                                    </li>
                                                    <li id="nes_70">
                                                    <Link className="slide-item" href="/projects/create/api-survey" >
                                                    <span>API Survey</span>
                                                    </Link>
                                                    </li>
                                                </ul>
                                            </li>
                                    </ul>
                                </li>
                                <li className="slide">
                                    <a className="side-menu__item" data-toggle="slide" href="#">
                                        <img src="../../images/dashboardicon/client.svg" className="dbicon" alt="icon" />
                                        <span className="side-menu__label">Client</span>
                                        <i className="angle fe fe-chevron-down"></i>
                                    </a>
                                    <ul className="slide-menu">
                                            <li className="">
                                                <Link className="slide-item" href="/clients" >
                                                    <span>Client</span>
                                                </Link>
                                            </li>
                                            <li className="">
                                                <Link className="slide-item" href="/clients/add" >
                                                    <span>Add Client</span>
                                                </Link>
                                            </li>

                                    </ul>
                                </li>
                                <li className="slide">
                                    <a className="side-menu__item" data-toggle="slide" href="#">
                                        <img src="../../images/dashboardicon/supplier.svg" className="dbicon" alt="icon" />
                                        <span className="side-menu__label">Supplier</span>
                                        <i className="angle fe fe-chevron-down"></i>
                                    </a>
                                    <ul className="slide-menu">
                                            <li className="">
                                                <Link className="slide-item" href="/suppliers" >
                                                    <span>Supplier</span>
                                                </Link>
                                            </li>
                                            <li className="">
                                                <Link className="slide-item" href="/suppliers/add" >
                                                    <span>Add Supplier</span>
                                                </Link>
                                            </li>
                                    </ul>
                                </li>
                                <li className="slide">
                                    <a className="side-menu__item" data-toggle="slide" href="#">
                                        <img src="../../images/dashboardicon/library.svg" className="dbicon" alt="icon" />
                                        <span className="side-menu__label">Library</span>
                                        <i className="angle fe fe-chevron-down"></i>
                                    </a>
                                    <ul className="slide-menu">
                                            <li className="">
                                                <Link className="slide-item" href="/library/questions" >
                                                    <span>Question</span>
                                                </Link>
                                            </li>
                                            <li className="">
                                                <Link className="slide-item" href="/library/prescreen-templates" >
                                                    <span>Prescreen Template</span>
                                                </Link>
                                            </li>
                                    </ul>
                                </li>
                                <li className="slide">
                                    <a className="side-menu__item" data-toggle="slide" href="#">
                                        <img src="../../images/dashboardicon/report.svg" className="dbicon" alt="icon" />
                                        <span className="side-menu__label">Report</span>
                                        <i className="angle fe fe-chevron-down"></i>
                                    </a>
                                    <ul className="slide-menu">
                                            <li className="">
                                                <Link className="slide-item" href="/reports/client" >
                                                    <span>Client Report</span>
                                                </Link>
                                            </li>
                                            <li className="">
                                                <Link className="slide-item" href="/reports/supplier" >
                                                    <span>Supplier Report</span>
                                                </Link>
                                            </li>
                                            <li className="">
                                                <Link className="slide-item" href="/reports/group" >
                                                    <span>Group Report</span>
                                                </Link>
                                            </li>
                                            <li className="">
                                                <Link className="slide-item" href="/reports/tsign" >
                                                    <span>TSign Report</span>
                                                </Link>
                                            </li>
                                            <li className="">
                                                <Link className="slide-item" href="/reports/pm-activity" >
                                                    <span>PM Activity Report</span>
                                                </Link>
                                            </li>
                                    </ul>
                                </li>
                                <li className="slide">
                                    <Link className="side-menu__item" href="/billing" >
                                        <img src="../../images/dashboardicon/report.svg" className="dbicon" alt="icon" />
                                        <span className="side-menu__label">Billing</span>
                                    </Link>
                                </li>
                                <li className="slide">
                                    <Link className="side-menu__item" href="/analytics" >
                                        <img src="../../images/dashboardicon/report.svg" className="dbicon" alt="icon" />
                                        <span className="side-menu__label">Analytics</span>
                                    </Link>
                                </li>
                                <li className="slide">
                                    <Link className="side-menu__item" href="/reconciliation-billing" >
                                        <img src="../../images/dashboardicon/report.svg" className="dbicon" alt="icon" />
                                        <span className="side-menu__label">Billing Reconciliation</span>
                                    </Link>
                                </li>
                                <li className="slide">
                                    <Link className="side-menu__item" href="/client-accounts" >
                                        <img src="../../images/dashboardicon/client.svg" className="dbicon" alt="icon" />
                                        <span className="side-menu__label">Client Accounts</span>
                                    </Link>
                                </li>
                                <li className="slide">
                                    <Link className="side-menu__item" href="/audit-log" >
                                        <img src="../../images/dashboardicon/report.svg" className="dbicon" alt="icon" />
                                        <span className="side-menu__label">Audit Log</span>
                                    </Link>
                                </li>
                                <li className="slide">
                                    <Link className="side-menu__item" href="/notes" >
                                        <img src="../../images/dashboardicon/report.svg" className="dbicon" alt="icon" />
                                        <span className="side-menu__label">Notes</span>
                                    </Link>
                                </li>
                                <li className="slide">
                                    <Link className="side-menu__item" href="/feasibility" >
                                        <img src="../../images/dashboardicon/report.svg" className="dbicon" alt="icon" />
                                        <span className="side-menu__label">Feasibility Calculator</span>
                                    </Link>
                                </li>
                                <li className="slide">
                                    <Link className="side-menu__item" href="/change-password" >
                                        <img src="../../images/dashboardicon/report.svg" className="dbicon" alt="icon" />
                                        <span className="side-menu__label">Change Password</span>
                                    </Link>
                                </li>
                                <li className="slide">
                                    <a className="side-menu__item" data-toggle="slide" href="#">
                                        <img src="../../images/dashboardicon/support.svg" className="dbicon" alt="icon" />
                                        <span className="side-menu__label">Support</span>
                                        <i className="angle fe fe-chevron-down"></i>
                                    </a>
                                    <ul className="slide-menu">
                                            <li className="">
                                                <Link className="slide-item" href="/support/ip-tracker" >
                                                    <span>IP Tracker</span>
                                                </Link>
                                            </li>
                                            <li className="">
                                                <Link className="slide-item" href="/support/reconciliation" >
                                                    <span>Reconciliation</span>
                                                </Link>
                                            </li>
                                            <li className="">
                                                <Link className="slide-item" href="/support/blocked-ips" >
                                                    <span>Blocked IPs</span>
                                                </Link>
                                            </li>
                                            <li className="">
                                                <Link className="slide-item" href="/support/redirect-status" >
                                                    <span>Redirect Status</span>
                                                </Link>
                                            </li>
                                            <li className="">
                                                <Link className="slide-item" href="/support/encryption-lookup" >
                                                    <span>Encryption Tool</span>
                                                </Link>
                                            </li>
                                    </ul>
                                </li>
                    
                </ul>
            </div>


        </aside>
    );
}