import { supabaseAdmin } from "@/utils/supabase";
import { createClient } from "@/utils/supabase/server";

// Logs an admin action to the audit_log table. Never throws — a
// logging failure must never break the actual action it's logging.
export async function logAudit(action, details) {
    try {
        const supabase = await createClient();
        const { data: { user } } = await supabase.auth.getUser();

        await supabaseAdmin.from('audit_log').insert([{
            admin_email: user?.email || 'unknown',
            action,
            details: details || null,
        }]);
    } catch (error) {
        console.error('Audit log failed (non-blocking):', error);
    }
}
