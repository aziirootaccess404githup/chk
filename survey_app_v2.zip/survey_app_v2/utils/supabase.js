import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

// Client for the frontend (subject to RLS policies)
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Client for Server Actions (bypasses RLS - use carefully)
export const supabaseAdmin = createClient(supabaseUrl, supabaseServiceRoleKey);
