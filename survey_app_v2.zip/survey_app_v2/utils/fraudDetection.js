// ============================================================
// Fraud-Detection utility — ported from ExaVerify's
// pages/track.php + inc_exz.php (calcScore / is_duplicate / speeder).
//
// Same scoring philosophy as ExaVerify:
//   Speeder   → -40 pts  (LOI under the project's threshold)
//   Duplicate → -30 pts  (same respondent already has a real result
//                          on this project)
//   Same-IP   → -20 pts  (this IP has already produced a DIFFERENT
//                          respondent UID on this project — shared
//                          device / multi-account signal)
//
// This module never blocks anything by itself — same as ExaVerify,
// detection is informational (flags + score), the panel owner decides
// what to do with a flagged lead. Only the STATUS-LOCK (in the route
// files, not here) actually prevents a value from changing twice.
// ============================================================

const DEFAULT_SPEEDER_THRESHOLD_SECONDS = 180; // 3 minutes, same default as ExaVerify's SPD_LIMIT

// Statuses that count as a "real", final, already-recorded result.
// (Started/dropout doesn't count as a completed lead for dup/same-ip purposes.)
const TERMINAL_STATUSES = ['Complete', 'Terminate', 'OverQuota', 'SecurityFail'];

/**
 * Compute LOI (Length of Interview) in seconds from the tracking log's
 * started_at timestamp to now.
 */
function computeLOI(startedAt) {
    if (!startedAt) return null;
    const started = new Date(startedAt).getTime();
    if (Number.isNaN(started)) return null;
    return Math.max(0, Math.round((Date.now() - started) / 1000));
}

/**
 * Duplicate check — has this respondent (uid) already produced a
 * terminal result on this project before (excluding the current log row)?
 */
async function checkDuplicate(supabaseAdmin, { projectId, uid, excludeLogId }) {
    if (!projectId || !uid) return false;
    try {
        let query = supabaseAdmin
            .from('tracking_logs')
            .select('id', { count: 'exact', head: true })
            .eq('project_id', projectId)
            .eq('respondent_uid', uid)
            .in('status', TERMINAL_STATUSES);

        if (excludeLogId) query = query.neq('id', excludeLogId);

        const { count, error } = await query;
        if (error) throw error;
        return (count || 0) > 0;
    } catch (error) {
        console.error('checkDuplicate error:', error);
        return false; // fail-safe: never block/flag on an error
    }
}

/**
 * Same-IP check — has this IP already produced a DIFFERENT respondent
 * UID with a terminal result on this project? (shared-device / multi-
 * account signal — same detection ExaVerify calls "Same IP — Multiple UIDs").
 */
async function checkSameIP(supabaseAdmin, { projectId, ip, uid }) {
    if (!projectId || !ip || ip === '0.0.0.0' || ip === 'Unknown IP') return false;
    try {
        const { data, error } = await supabaseAdmin
            .from('tracking_logs')
            .select('respondent_uid')
            .eq('project_id', projectId)
            .eq('ip_address', ip)
            .in('status', TERMINAL_STATUSES)
            .neq('respondent_uid', uid)
            .limit(1);

        if (error) throw error;
        return (data && data.length > 0);
    } catch (error) {
        console.error('checkSameIP error:', error);
        return false;
    }
}

/**
 * Speeder check — LOI under the project's configured threshold.
 */
function checkSpeeder(loiSeconds, thresholdSeconds = DEFAULT_SPEEDER_THRESHOLD_SECONDS) {
    if (loiSeconds === null || loiSeconds === undefined) return false;
    return loiSeconds > 0 && loiSeconds < thresholdSeconds;
}

/**
 * Compute the full quality score + reasons, same formula as ExaVerify's calcScore().
 * Starts at 100, deducts points per flag.
 */
function computeQualityScore({ isSpeeder, isDuplicate, sameIpFlag }) {
    let score = 100;
    const reasons = [];

    if (isSpeeder) { score -= 40; reasons.push('Speeder (LOI under threshold)'); }
    if (isDuplicate) { score -= 30; reasons.push('Duplicate UID — same respondent already has a result'); }
    if (sameIpFlag) { score -= 20; reasons.push('Same IP — multiple UIDs from this address'); }

    return { score: Math.max(0, score), reasons };
}

/**
 * Orchestrator — runs all checks for a terminal-status write and returns
 * a ready-to-merge object for the tracking_logs update/insert payload.
 *
 * @param {object} supabaseAdmin - Supabase admin client
 * @param {object} params
 * @param {string} params.projectId
 * @param {string} params.uid - respondent_uid
 * @param {string} params.ip
 * @param {string} params.startedAt - ISO timestamp the log was first created
 * @param {number} [params.speederThresholdSeconds]
 * @param {string|number} [params.excludeLogId] - current log's own id, so
 *        duplicate-check doesn't match against itself
 */
async function runFraudChecks(supabaseAdmin, {
    projectId,
    uid,
    ip,
    startedAt,
    speederThresholdSeconds = DEFAULT_SPEEDER_THRESHOLD_SECONDS,
    excludeLogId,
}) {
    const loiSeconds = computeLOI(startedAt);

    const [isDuplicate, sameIpFlag] = await Promise.all([
        checkDuplicate(supabaseAdmin, { projectId, uid, excludeLogId }),
        checkSameIP(supabaseAdmin, { projectId, ip, uid }),
    ]);

    const isSpeeder = checkSpeeder(loiSeconds, speederThresholdSeconds);
    const { score, reasons } = computeQualityScore({ isSpeeder, isDuplicate, sameIpFlag });

    return {
        loi_seconds: loiSeconds,
        is_duplicate: isDuplicate,
        is_speeder: isSpeeder,
        same_ip_flag: sameIpFlag,
        quality_score: score,
        score_reasons: reasons.join('; ') || null,
    };
}

export {
    DEFAULT_SPEEDER_THRESHOLD_SECONDS,
    TERMINAL_STATUSES,
    computeLOI,
    checkDuplicate,
    checkSameIP,
    checkSpeeder,
    computeQualityScore,
    runFraudChecks,
};
