// ============================================================
// Universal Token + Bracket-Style URL builder
// Direct port of ExaVerify's inc_exz.php exz_build_url() /
// exz_build_token_set() — same token list, same 7 bracket styles,
// same case-insensitive/whitespace-tolerant matching.
//
// Works both directions: filling a client's survey Live-URL on entry,
// or filling a vendor's postback/redirect URL on completion — same
// engine either way, same as ExaVerify.
// ============================================================

// 7 bracket styles, in this exact order (double-curly MUST come before
// single-curly, otherwise the single-curly pattern would wrongly match
// the inner half of an unprocessed "{{token}}").
const WRAPPER_PATTERNS = [
    (key) => new RegExp(`\\{\\{\\s*${key}\\s*\\}\\}`, 'gi'),   // {{token}}
    (key) => new RegExp(`\\[\\s*${key}\\s*\\]`, 'gi'),         // [TOKEN]
    (key) => new RegExp(`\\[#\\s*${key}\\s*#\\]`, 'gi'),       // [#token#]
    (key) => new RegExp(`\\{\\s*${key}\\s*\\}`, 'gi'),         // {token}
    (key) => new RegExp(`%\\s*${key}\\s*%`, 'gi'),             // %TOKEN%
    (key) => new RegExp(`<\\s*${key}\\s*>`, 'gi'),             // <token>
    (key) => new RegExp(`\\$\\s*${key}\\s*\\$`, 'gi'),         // $token$
];

function escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Replace every recognized token (in any of the 7 bracket styles) inside
 * a URL template. Anything not matching a known token is left untouched —
 * this never guesses/invents a value for a token it wasn't given.
 *
 * @param {string} template - the URL template containing placeholders
 * @param {Record<string, string|number|null|undefined>} tokens - key/value pairs
 */
function buildUrl(template, tokens) {
    let url = template;
    for (const [key, value] of Object.entries(tokens)) {
        if (value === null || value === undefined) continue;
        const quotedKey = escapeRegex(String(key));
        for (const patternFn of WRAPPER_PATTERNS) {
            url = url.replace(patternFn(quotedKey), encodeURIComponent(String(value)));
        }
    }
    return url;
}

/**
 * Standard token set — same 41-key map as ExaVerify's exz_build_token_set().
 * `uid` maps every respondent-identifier alias vendors use; `sid` maps
 * every project/study/survey-id alias. `extra` lets a call site add or
 * override situational tokens (loi, status, etc).
 */
function buildTokenSet(uid, sid, extra = {}) {
    const base = {
        // 'pid' = Panelist ID (the respondent) — confirmed industry-standard
        // meaning per Medallia/SoSciSurvey/Qualtrics panel-integration docs.
        // NOT the project/survey ID (that's sid/studyid/surveyid below).
        uid, rid: uid, toid: uid, identifier: uid, tid: uid, pid: uid,
        userid: uid, user_id: uid, respid: uid, resp_id: uid,
        respondentid: uid, respondent_id: uid, panelistid: uid, panelist_id: uid,
        participantid: uid, participant_id: uid, memberid: uid, member_id: uid,
        entryid: uid, entry_id: uid, clickid: uid, subid: uid,
        transactionid: uid, transaction_id: uid, qparm: uid, subject_id: uid,
        ext_ref: uid, external_id: uid, id: uid, ticket: uid,
        sid, studyid: sid, surveyid: sid,
        survey_id: sid, projectid: sid, project_id: sid, gid: sid,
        project_code: sid, projectcode: sid,
        date: new Date().toISOString().slice(0, 10),
        timestamp: String(Math.floor(Date.now() / 1000)),
    };
    return { ...base, ...extra };
}

export { buildUrl, buildTokenSet };
