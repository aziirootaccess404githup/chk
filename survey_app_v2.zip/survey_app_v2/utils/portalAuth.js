import { randomBytes, scryptSync, timingSafeEqual } from 'crypto';

// Node's built-in scrypt — no external package (bcrypt/bcryptjs) needed.
// Same security properties: salted, computationally-expensive hash.

export function hashPassword(password) {
    const salt = randomBytes(16).toString('hex');
    const hash = scryptSync(password, salt, 64).toString('hex');
    return { hash, salt };
}

export function verifyPassword(password, hash, salt) {
    try {
        const attemptHash = scryptSync(password, salt, 64);
        const storedHash = Buffer.from(hash, 'hex');
        if (attemptHash.length !== storedHash.length) return false;
        return timingSafeEqual(attemptHash, storedHash);
    } catch (e) {
        return false;
    }
}
