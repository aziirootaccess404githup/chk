// ============================================================
// Telegram Alerts — direct port of ExaVerify's exz_send_telegram().
// Uses TELEGRAM_BOT_TOKEN + TELEGRAM_CHAT_ID from environment
// variables (set in .env.local). If either is missing, this is a
// silent no-op — never blocks or errors the calling code.
// ============================================================

async function sendTelegramAlert(message) {
    const token = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_CHAT_ID;
    if (!token || !chatId) return; // not configured — silently skip

    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 4000);
        await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ chat_id: chatId, text: message }),
            signal: controller.signal,
        });
        clearTimeout(timeout);
    } catch (error) {
        console.error('Telegram alert failed:', error);
        // Never throw — an alert failing must never affect the respondent's flow.
    }
}

export { sendTelegramAlert };
