import React from 'react'
import { createAdminClient } from '@/utils/supabase/admin'
import { createClient } from '@/utils/supabase/server'
import { redirect } from 'next/navigation'
import AdminClientUI from './AdminClientUI'

export const metadata = {
  title: 'Admin Management - Exazon',
}

export default async function AdminPage() {
  const supabase = await createClient()
  
  // 1. Verify Authorization
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) {
    redirect('/admin-login')
  }

  // 2. Fetch Users
  const supabaseAdmin = createAdminClient()

  const { data: profile } = await supabaseAdmin
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single()

  if (profile?.role !== 'superadmin') {
    // If not superadmin, send them back to the main dashboard
    redirect('/')
  }
  
  // Fetch auth users
  const { data: authData, error: authError } = await supabaseAdmin.auth.admin.listUsers()
  
  // Fetch profiles for roles and names
  const { data: profiles, error: profilesError } = await supabaseAdmin
    .from('profiles')
    .select('*')

  if (authError || profilesError) {
    return <div className="p-4 text-danger">Error loading users.</div>
  }

  // Merge auth user data with profile data
  const users = authData.users.map(authUser => {
    const userProfile = profiles?.find(p => p.id === authUser.id) || {}
    // Extract raw username if we saved it in metadata, or derive from email
    const rawUsername = authUser.user_metadata?.username || authUser.email.replace('@exazonresearch.com', '')
    
    return {
      id: authUser.id,
      email: authUser.email,
      username: rawUsername,
      full_name: userProfile.full_name || authUser.user_metadata?.full_name || '',
      role: userProfile.role || 'manager',
      created_at: authUser.created_at
    }
  })

  // Sort by role tier (superadmin > manager > viewer), then by date
  const roleRank = { superadmin: 0, manager: 1, viewer: 2 }
  users.sort((a, b) => {
    const rankDiff = (roleRank[a.role] ?? 1) - (roleRank[b.role] ?? 1)
    if (rankDiff !== 0) return rankDiff
    return new Date(b.created_at) - new Date(a.created_at)
  })

  // 3. Render Client UI
  return (
    <div className="main-content app-content">
      <div className="container-fluid">
        <div className="breadcrumb-header justify-content-between">
          <div className="my-auto">
            <div className="d-flex">
              <h4 className="content-title mb-0 my-auto">Settings</h4>
              <span className="text-muted mt-1 tx-13 ms-2 mb-0">/ Admin Management</span>
            </div>
          </div>
        </div>

        <AdminClientUI initialUsers={users} />
      </div>
    </div>
  )
}
