'use client'

import React, { useState } from 'react'
import { createUser, deleteUser, updateUserPassword, updateUserRole } from './actions'

export default function AdminClientUI({ initialUsers }) {
  const [users, setUsers] = useState(initialUsers)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  
  // Form states
  const [showAddForm, setShowAddForm] = useState(false)
  const [newUsername, setNewUsername] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [newFullName, setNewFullName] = useState('')
  const [newRole, setNewRole] = useState('manager')

  // Password Update States
  const [editingPasswordId, setEditingPasswordId] = useState(null)
  const [editPasswordValue, setEditPasswordValue] = useState('')

  const handleCreateUser = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setSuccess(null)

    const formData = new FormData()
    formData.append('username', newUsername)
    formData.append('password', newPassword)
    formData.append('full_name', newFullName)
    formData.append('role', newRole)

    const res = await createUser(formData)
    
    if (res.error) {
      setError(res.error)
    } else {
      setSuccess('User created successfully. Please refresh to see the new user.')
      setShowAddForm(false)
      setNewUsername('')
      setNewPassword('')
      setNewFullName('')
      setNewRole('manager')
    }
    setLoading(false)
  }

  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to permanently delete this user?")) return
    
    setLoading(true)
    const res = await deleteUser(id)
    if (res.error) {
      setError(res.error)
    } else {
      setSuccess('User deleted successfully.')
      setUsers(users.filter(u => u.id !== id))
    }
    setLoading(false)
  }

  const handleRoleChange = async (id, role) => {
    setLoading(true)
    const res = await updateUserRole(id, role)
    if (res.error) {
      setError(res.error)
    } else {
      setSuccess('User role updated.')
      setUsers(users.map(u => u.id === id ? { ...u, role } : u))
    }
    setLoading(false)
  }

  const handlePasswordUpdate = async (id) => {
    if (!editPasswordValue || editPasswordValue.length < 6) {
      setError("Password must be at least 6 characters.")
      return
    }

    setLoading(true)
    const res = await updateUserPassword(id, editPasswordValue)
    if (res.error) {
      setError(res.error)
    } else {
      setSuccess('Password updated successfully.')
      setEditingPasswordId(null)
      setEditPasswordValue('')
    }
    setLoading(false)
  }

  return (
    <div className="row">
      <div className="col-lg-12">
        {error && <div className="alert alert-danger">{error}</div>}
        {success && <div className="alert alert-success">{success}</div>}

        <div className="card custom-card">
          <div className="card-header d-flex justify-content-between align-items-center">
            <div>
              <h6 className="card-title mb-1">User Management</h6>
              <p className="text-muted card-sub-title">Manage access and roles for the dashboard.</p>
            </div>
            <button 
              className="btn btn-primary" 
              onClick={() => setShowAddForm(!showAddForm)}
            >
              {showAddForm ? 'Cancel' : 'Add New User'}
            </button>
          </div>

          {showAddForm && (
            <div className="card-body bg-light">
              <form onSubmit={handleCreateUser}>
                <div className="row">
                  <div className="col-md-3 form-group">
                    <label>Full Name</label>
                    <input type="text" className="form-control" value={newFullName} onChange={e => setNewFullName(e.target.value)} required />
                  </div>
                  <div className="col-md-3 form-group">
                    <label>Username</label>
                    <input type="text" className="form-control" placeholder="e.g. johndoe" value={newUsername} onChange={e => setNewUsername(e.target.value)} required />
                  </div>
                  <div className="col-md-3 form-group">
                    <label>Password</label>
                    <input type="password" className="form-control" value={newPassword} onChange={e => setNewPassword(e.target.value)} required minLength={6} />
                  </div>
                  <div className="col-md-2 form-group">
                    <label>Role</label>
                    <select className="form-control" value={newRole} onChange={e => setNewRole(e.target.value)}>
                      <option value="viewer">Viewer</option>
                      <option value="manager">Manager</option>
                      <option value="superadmin">Superadmin</option>
                    </select>
                  </div>
                  <div className="col-md-1 form-group d-flex align-items-end">
                    <button type="submit" className="btn btn-success w-100" disabled={loading}>
                      Save
                    </button>
                  </div>
                </div>
              </form>
            </div>
          )}

          <div className="card-body">
            <div className="table-responsive">
              <table className="table text-md-nowrap table-striped">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Created</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map(user => (
                    <tr key={user.id}>
                      <td className="align-middle">{user.full_name}</td>
                      <td className="align-middle fw-bold">{user.username}</td>
                      <td className="align-middle">
                        <select 
                          className="form-control form-control-sm"
                          value={user.role}
                          onChange={(e) => handleRoleChange(user.id, e.target.value)}
                          disabled={loading}
                          style={{ width: 'auto' }}
                        >
                          <option value="viewer">Viewer</option>
                          <option value="manager">Manager</option>
                          <option value="superadmin">Superadmin</option>
                        </select>
                      </td>
                      <td className="align-middle">
                        {new Date(user.created_at).toLocaleDateString()}
                      </td>
                      <td className="align-middle">
                        {editingPasswordId === user.id ? (
                          <div className="d-flex gap-2">
                            <input 
                              type="password" 
                              className="form-control form-control-sm" 
                              placeholder="New password"
                              value={editPasswordValue}
                              onChange={e => setEditPasswordValue(e.target.value)}
                            />
                            <button className="btn btn-sm btn-success" onClick={() => handlePasswordUpdate(user.id)} disabled={loading}>Save</button>
                            <button className="btn btn-sm btn-secondary" onClick={() => setEditingPasswordId(null)}>Cancel</button>
                          </div>
                        ) : (
                          <div className="btn-group">
                            <button 
                              className="btn btn-sm btn-outline-primary"
                              onClick={() => { setEditingPasswordId(user.id); setEditPasswordValue(''); }}
                              disabled={loading}
                            >
                              Reset Password
                            </button>
                            <button 
                              className="btn btn-sm btn-outline-danger ms-2"
                              onClick={() => handleDelete(user.id)}
                              disabled={loading}
                            >
                              Delete
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                  {users.length === 0 && (
                    <tr>
                      <td colSpan="5" className="text-center py-4">No users found.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
