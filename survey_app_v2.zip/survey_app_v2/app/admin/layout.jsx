import Link from 'next/link';
import { logout } from '@/app/login/actions';

export default function AdminLayout({ children }) {
  return (
    <div style={{ backgroundColor: '#f5f6f8', minHeight: '100vh' }}>
      <nav className="navbar navbar-expand-lg navbar-light bg-white" style={{ boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
        <div className="container-fluid px-4">
          <Link href="/admin" className="navbar-brand d-flex align-items-center">
            <img src="/images/logo.png" alt="Exazon Research" style={{ height: '40px', marginRight: '15px' }} />
            <span style={{ fontWeight: 'bold', fontSize: '1.2rem', color: '#2c3e50' }}>Admin Panel</span>
          </Link>
          
          <div className="d-flex ms-auto">
            <Link href="/" className="btn btn-outline-secondary me-3">
              Go to Dashboard
            </Link>
            <form action={logout}>
              <button type="submit" className="btn btn-danger">Logout</button>
            </form>
          </div>
        </div>
      </nav>

      <div className="container mt-4">
        {children}
      </div>
    </div>
  );
}
