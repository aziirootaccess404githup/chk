'use server'

import { createAdminClient } from '@/utils/supabase/admin'
import { revalidatePath } from 'next/cache'
import { createClient } from '@/utils/supabase/server'

async function checkAdminRole() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) throw new Error("Unauthorized")
  
  const supabaseAdmin = createAdminClient()
  const { data: profile } = await supabaseAdmin
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single()
    
  if (profile?.role !== 'superadmin') {
    throw new Error("Forbidden: Superadmin access required")
  }
}

// Viewer role = read-only. Any action that writes data should call this
// first (in addition to, or instead of, checkAdminRole where appropriate).
export async function checkWriteAccess() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) throw new Error("Unauthorized")

  const supabaseAdmin = createAdminClient()
  const { data: profile } = await supabaseAdmin
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single()

  if (profile?.role === 'viewer') {
    throw new Error("Forbidden: Viewer accounts are read-only")
  }
}

export async function createUser(formData) {
  try {
    await checkAdminRole()
    const supabaseAdmin = createAdminClient()

    let email = formData.get('username')
    const originalUsername = email
    if (!email.includes('@')) {
      email = `${email}@exazonresearch.com`
    }

    const password = formData.get('password')
    const full_name = formData.get('full_name')
    const role = formData.get('role') || 'manager'

    // Create user in Auth
    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email: email,
      password: password,
      email_confirm: true,
      user_metadata: { full_name, username: originalUsername }
    })

    if (authError) throw new Error(authError.message)

    // Wait for the trigger to create the profile, or upsert it manually
    // Many Supabase setups auto-create profiles. We will do an upsert to be safe.
    const { error: profileError } = await supabaseAdmin
      .from('profiles')
      .upsert({
        id: authData.user.id,
        full_name: full_name,
        role: role
      }, { onConflict: 'id' })

    if (profileError) {
      // If profile fails, rollback auth user creation
      await supabaseAdmin.auth.admin.deleteUser(authData.user.id)
      throw new Error(profileError.message)
    }

    revalidatePath('/admin')
    return { success: true }
  } catch (error) {
    return { error: error.message }
  }
}

export async function deleteUser(userId) {
  try {
    await checkAdminRole()
    const supabaseAdmin = createAdminClient()

    const { error } = await supabaseAdmin.auth.admin.deleteUser(userId)
    if (error) throw new Error(error.message)

    revalidatePath('/admin')
    return { success: true }
  } catch (error) {
    return { error: error.message }
  }
}

export async function updateUserPassword(userId, newPassword) {
  try {
    await checkAdminRole()
    const supabaseAdmin = createAdminClient()

    const { error } = await supabaseAdmin.auth.admin.updateUserById(userId, {
      password: newPassword
    })
    if (error) throw new Error(error.message)

    return { success: true }
  } catch (error) {
    return { error: error.message }
  }
}

export async function updateUserRole(userId, newRole) {
  try {
    await checkAdminRole()
    const supabaseAdmin = createAdminClient()

    const { error } = await supabaseAdmin
      .from('profiles')
      .update({ role: newRole })
      .eq('id', userId)

    if (error) throw new Error(error.message)

    revalidatePath('/admin')
    return { success: true }
  } catch (error) {
    return { error: error.message }
  }
}
