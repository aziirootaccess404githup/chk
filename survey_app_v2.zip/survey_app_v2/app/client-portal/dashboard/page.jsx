"use client";
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { getPortalSession, getPortalClientProjects, portalClientLogout } from '@/app/actions/portalClients';

export default function ClientPortalDashboard() {
    const router = useRouter();
    const [session, setSession] = useState(null);
    const [projects, setProjects] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function load() {
            const sessionResult = await getPortalSession();
            if (!sessionResult.success) {
                router.push('/client-portal/login');
                return;
            }
            setSession(sessionResult.data);

            const projResult = await getPortalClientProjects();
            if (projResult.success) setProjects(projResult.data);
            setLoading(false);
        }
        load();
    }, [router]);

    const handleLogout = async () => {
        await portalClientLogout();
        router.push('/client-portal/login');
    };

    const handleDownloadCsv = () => {
        const headers = ["Project", "Status", "Country", "Completed", "Target", "Start Date", "End Date"];
        const rows = projects.map(p => [p.name, p.status, p.country, p.completed, p.target, p.startDate || '', p.endDate || '']);
        const csvContent = [headers, ...rows]
            .map(row => row.map(cell => `"${String(cell ?? '').replace(/"/g, '""')}"`).join(","))
            .join("\n");
        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `my-projects-${Date.now()}.csv`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    if (loading) {
        return <div style={{ padding: '40px', textAlign: 'center' }}>Loading...</div>;
    }

    return (
        <div style={{ minHeight: '100vh', background: '#f4f6fb', fontFamily: "'DM Sans', sans-serif" }}>
            <div style={{
                background: '#0a1628',
                padding: '16px 28px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
            }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <img src="/images/exazon-logo.jpg" alt="Exazon Research" style={{ height: '32px', borderRadius: '4px' }} />
                    <div>
                        <div style={{ color: '#fff', fontWeight: 700, fontSize: '16px' }}>
                            {session?.clients?.name || 'Client Portal'}
                        </div>
                        <div style={{ color: '#94a3b8', fontSize: '11px' }}>Logged in as {session?.username}</div>
                    </div>
                </div>
                <button
                    onClick={handleLogout}
                    style={{ background: 'rgba(255,255,255,0.1)', color: '#fff', border: 'none', borderRadius: '6px', padding: '8px 16px', cursor: 'pointer', fontSize: '13px' }}
                >
                    Logout
                </button>
            </div>

            <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '24px 20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                    <h4 style={{ margin: 0 }}>Your Projects</h4>
                    <button
                        onClick={handleDownloadCsv}
                        disabled={projects.length === 0}
                        style={{ background: '#3b82f6', color: '#fff', border: 'none', borderRadius: '6px', padding: '8px 16px', cursor: 'pointer', fontSize: '13px' }}
                    >
                        Download CSV
                    </button>
                </div>

                <div style={{ background: '#fff', borderRadius: '12px', border: '1px solid #e5e9f2', overflow: 'hidden' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                        <thead>
                            <tr style={{ background: '#f8faff' }}>
                                {['Project', 'Status', 'Country', 'Completed', 'Target', 'Progress'].map(h => (
                                    <th key={h} style={{ padding: '10px 14px', textAlign: 'left', fontSize: '11px', textTransform: 'uppercase', color: '#94a3b8' }}>{h}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {projects.length > 0 ? (
                                projects.map(p => {
                                    const pct = p.target > 0 ? Math.min(100, Math.round((p.completed / p.target) * 100)) : 0;
                                    return (
                                        <tr key={p.id} style={{ borderTop: '1px solid #f1f3f9' }}>
                                            <td style={{ padding: '12px 14px', fontWeight: 600 }}>{p.name}</td>
                                            <td style={{ padding: '12px 14px' }}>
                                                <span style={{
                                                    padding: '3px 10px', borderRadius: '20px', fontSize: '11px', fontWeight: 700,
                                                    background: p.status === 'Live' ? 'rgba(34,197,94,.12)' : 'rgba(148,163,184,.15)',
                                                    color: p.status === 'Live' ? '#15803d' : '#64748b',
                                                }}>{p.status}</span>
                                            </td>
                                            <td style={{ padding: '12px 14px' }}>{p.country}</td>
                                            <td style={{ padding: '12px 14px' }}>{p.completed}</td>
                                            <td style={{ padding: '12px 14px' }}>{p.target}</td>
                                            <td style={{ padding: '12px 14px', minWidth: '120px' }}>
                                                <div style={{ background: '#eee', borderRadius: '4px', height: '8px', overflow: 'hidden' }}>
                                                    <div style={{ width: `${pct}%`, background: '#28a745', height: '100%' }}></div>
                                                </div>
                                                <div style={{ fontSize: '10px', color: '#94a3b8', marginTop: '2px' }}>{pct}%</div>
                                            </td>
                                        </tr>
                                    );
                                })
                            ) : (
                                <tr><td colSpan="6" style={{ padding: '24px', textAlign: 'center', color: '#94a3b8' }}>No projects found.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
