"use client";
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { portalClientLogin } from '@/app/actions/portalClients';

export default function ClientPortalLogin() {
    const router = useRouter();
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);
        const result = await portalClientLogin(username, password);
        setLoading(false);
        if (result.success) {
            router.push('/client-portal/dashboard');
        } else {
            setError(result.error || 'Login failed.');
        }
    };

    return (
        <div style={{
            minHeight: '100vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: '#f4f6fb',
            fontFamily: "'DM Sans', sans-serif",
        }}>
            <div style={{
                background: '#fff',
                borderRadius: '12px',
                padding: '40px',
                width: '100%',
                maxWidth: '380px',
                boxShadow: '0 4px 24px rgba(0,0,0,0.08)',
            }}>
                <div style={{ textAlign: 'center', marginBottom: '16px' }}>
                    <img src="/images/exazon-logo.jpg" alt="Exazon Research" style={{ height: '48px', borderRadius: '6px' }} />
                </div>
                <h3 style={{ textAlign: 'center', marginBottom: '8px' }}>Client Portal</h3>
                <p style={{ textAlign: 'center', color: '#94a3b8', fontSize: '13px', marginBottom: '24px' }}>
                    View your project progress and results
                </p>

                <form onSubmit={handleSubmit}>
                    <div style={{ marginBottom: '16px' }}>
                        <label style={{ fontSize: '12px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>Username</label>
                        <input
                            type="text"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            required
                            style={{ width: '100%', padding: '10px 12px', border: '1px solid #e2e8f0', borderRadius: '8px', fontSize: '14px' }}
                        />
                    </div>
                    <div style={{ marginBottom: '20px' }}>
                        <label style={{ fontSize: '12px', fontWeight: 600, color: '#374151', display: 'block', marginBottom: '4px' }}>Password</label>
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                            style={{ width: '100%', padding: '10px 12px', border: '1px solid #e2e8f0', borderRadius: '8px', fontSize: '14px' }}
                        />
                    </div>

                    {error && (
                        <div style={{ background: '#fef2f2', color: '#b91c1c', padding: '10px 12px', borderRadius: '8px', fontSize: '13px', marginBottom: '16px' }}>
                            {error}
                        </div>
                    )}

                    <button
                        type="submit"
                        disabled={loading}
                        style={{
                            width: '100%',
                            background: 'linear-gradient(135deg, #1b4fd8, #3b82f6)',
                            color: '#fff',
                            border: 'none',
                            borderRadius: '8px',
                            padding: '12px',
                            fontSize: '14px',
                            fontWeight: 600,
                            cursor: 'pointer',
                        }}
                    >
                        {loading ? 'Signing in...' : 'Sign In'}
                    </button>
                </form>
            </div>
        </div>
    );
}
