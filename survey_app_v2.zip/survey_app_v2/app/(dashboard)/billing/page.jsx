"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { getBillingData, updateInvoiceStatus } from '@/app/actions/billing';

export default function BillingDashboard() {
    const [billingData, setBillingData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState("");
    const [editingId, setEditingId] = useState(null);
    const [editStatus, setEditStatus] = useState('unpaid');
    const [editInvoiceNo, setEditInvoiceNo] = useState('');
    const [editNotes, setEditNotes] = useState('');
    const [saving, setSaving] = useState(false);

    async function fetchData() {
        setLoading(true);
        const result = await getBillingData();
        if (result.success) setBillingData(result.data);
        setLoading(false);
    }

    useEffect(() => {
        fetchData();
    }, []);

    const filtered = billingData.filter(b =>
        !searchTerm ||
        b.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        b.clientName.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const totals = filtered.reduce((acc, b) => ({
        revenue: acc.revenue + b.revenue,
        cost: acc.cost + b.cost,
        margin: acc.margin + b.margin,
    }), { revenue: 0, cost: 0, margin: 0 });

    const handleEditClick = (b) => {
        setEditingId(b.id);
        setEditStatus(b.invoiceStatus);
        setEditInvoiceNo(b.invoiceNo);
        setEditNotes(b.invoiceNotes);
    };

    const handleSave = async (id) => {
        setSaving(true);
        const result = await updateInvoiceStatus(id, editStatus, editInvoiceNo, editNotes);
        setSaving(false);
        if (result.success) {
            setEditingId(null);
            fetchData();
        } else {
            alert("Error: " + result.error);
        }
    };

    const fmt = (n, currency) => `${currency} ${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item active">Billing</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Billing Dashboard <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal'}}>(v2 — live data)</span></h4>
                </div>
            </div>

            {/* Summary cards */}
            <div className="col-md-4 mb-3">
                <div className="card">
                    <div className="card-body">
                        <div className="text-muted" style={{fontSize: '12px'}}>Total Revenue (Client billing)</div>
                        <h3 className="mb-0" style={{color: '#28a745'}}>${totals.revenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</h3>
                    </div>
                </div>
            </div>
            <div className="col-md-4 mb-3">
                <div className="card">
                    <div className="card-body">
                        <div className="text-muted" style={{fontSize: '12px'}}>Total Cost (Supplier payouts)</div>
                        <h3 className="mb-0" style={{color: '#dc3545'}}>${totals.cost.toLocaleString(undefined, {minimumFractionDigits: 2})}</h3>
                    </div>
                </div>
            </div>
            <div className="col-md-4 mb-3">
                <div className="card">
                    <div className="card-body">
                        <div className="text-muted" style={{fontSize: '12px'}}>Total Margin (Profit)</div>
                        <h3 className="mb-0" style={{color: totals.margin >= 0 ? '#28a745' : '#dc3545'}}>${totals.margin.toLocaleString(undefined, {minimumFractionDigits: 2})}</h3>
                    </div>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <div className="row mb-3 justify-content-end">
                            <div className="col-md-4 col-sm-12">
                                <div className="app-search-box">
                                    <div className="input-group">
                                        <input
                                            type="text"
                                            className="form-control"
                                            placeholder="Search project or client..."
                                            value={searchTerm}
                                            onChange={(e) => setSearchTerm(e.target.value)}
                                        />
                                        {searchTerm && (
                                            <a className="clearCrossIcon" onClick={() => setSearchTerm("")} style={{cursor: 'pointer'}}>
                                                <i className="fa fa-times-circle" aria-hidden="true"></i>
                                            </a>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="table-responsive">
                            <table className="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Project</th>
                                        <th>Client</th>
                                        <th>Completes</th>
                                        <th>CPI</th>
                                        <th>Supplier CPI</th>
                                        <th>Revenue</th>
                                        <th>Cost</th>
                                        <th>Margin</th>
                                        <th>Invoice Status</th>
                                        <th>Invoice #</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {loading ? (
                                        <tr><td colSpan="11" className="text-center">Loading...</td></tr>
                                    ) : filtered.length > 0 ? (
                                        filtered.map(b => (
                                            <tr key={b.id}>
                                                <td><strong>{b.name}</strong></td>
                                                <td>{b.clientName}</td>
                                                <td>{b.completes}</td>
                                                <td>{b.cpi}</td>
                                                <td>{b.supplierCpi}</td>
                                                <td style={{color: '#28a745'}}>{fmt(b.revenue, b.currency)}</td>
                                                <td style={{color: '#dc3545'}}>{fmt(b.cost, b.currency)}</td>
                                                <td style={{color: b.margin >= 0 ? '#28a745' : '#dc3545', fontWeight: 'bold'}}>{fmt(b.margin, b.currency)}</td>
                                                <td>
                                                    {editingId === b.id ? (
                                                        <select className="form-control form-control-sm" value={editStatus} onChange={(e) => setEditStatus(e.target.value)}>
                                                            <option value="unpaid">Unpaid</option>
                                                            <option value="paid">Paid</option>
                                                        </select>
                                                    ) : (
                                                        <span className={`badge ${b.invoiceStatus === 'paid' ? 'badge-success' : 'badge-warning'}`}>
                                                            {b.invoiceStatus === 'paid' ? 'Paid' : 'Unpaid'}
                                                        </span>
                                                    )}
                                                </td>
                                                <td>
                                                    {editingId === b.id ? (
                                                        <input className="form-control form-control-sm" value={editInvoiceNo} onChange={(e) => setEditInvoiceNo(e.target.value)} placeholder="Invoice #" />
                                                    ) : (
                                                        b.invoiceNo || '-'
                                                    )}
                                                </td>
                                                <td>
                                                    {editingId === b.id ? (
                                                        <div className="d-flex gap-1" style={{gap: '5px'}}>
                                                            <button className="btn btn-sm btn-success" onClick={() => handleSave(b.id)} disabled={saving}>Save</button>
                                                            <button className="btn btn-sm btn-secondary" onClick={() => setEditingId(null)}>Cancel</button>
                                                        </div>
                                                    ) : (
                                                        <button className="btn btn-sm btn-outline-primary" onClick={() => handleEditClick(b)}>Edit</button>
                                                    )}
                                                </td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr><td colSpan="11" className="text-center">No Record Found !</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
