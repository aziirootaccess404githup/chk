"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { getAnalyticsData } from '@/app/actions/analytics';

// Lightweight SVG line-chart — no external chart library needed.
function TrendChart({ trend }) {
    if (!trend || trend.length === 0) return <p className="text-muted">No data for this range.</p>;

    const width = 900, height = 260, padding = 40;
    const maxVal = Math.max(1, ...trend.map(d => Math.max(d.complete, d.terminate, d.overQuota)));
    const xStep = trend.length > 1 ? (width - padding * 2) / (trend.length - 1) : 0;

    const buildPoints = (key) => trend.map((d, i) => {
        const x = padding + i * xStep;
        const y = height - padding - (d[key] / maxVal) * (height - padding * 2);
        return `${x},${y}`;
    }).join(' ');

    const series = [
        { key: 'complete', color: '#28a745', label: 'Complete' },
        { key: 'terminate', color: '#dc3545', label: 'Terminate' },
        { key: 'overQuota', color: '#ffc107', label: 'OverQuota' },
    ];

    return (
        <div style={{overflowX: 'auto'}}>
            <svg width={width} height={height + 40} style={{minWidth: '600px'}}>
                {/* Y-axis gridlines */}
                {[0, 0.25, 0.5, 0.75, 1].map((f, i) => (
                    <line key={i} x1={padding} y1={height - padding - f * (height - padding * 2)}
                          x2={width - padding} y2={height - padding - f * (height - padding * 2)}
                          stroke="#eee" strokeWidth="1" />
                ))}
                {/* Lines */}
                {series.map(s => (
                    <polyline key={s.key} points={buildPoints(s.key)} fill="none" stroke={s.color} strokeWidth="2" />
                ))}
                {/* Points */}
                {series.map(s => trend.map((d, i) => {
                    const x = padding + i * xStep;
                    const y = height - padding - (d[s.key] / maxVal) * (height - padding * 2);
                    return <circle key={`${s.key}-${i}`} cx={x} cy={y} r="3" fill={s.color} />;
                }))}
                {/* X-axis labels (show every nth to avoid crowding) */}
                {trend.map((d, i) => {
                    if (trend.length > 10 && i % Math.ceil(trend.length / 10) !== 0) return null;
                    const x = padding + i * xStep;
                    return (
                        <text key={i} x={x} y={height - padding + 18} fontSize="10" textAnchor="middle" fill="#888">
                            {d.date.substring(5)}
                        </text>
                    );
                })}
            </svg>
            <div className="d-flex justify-content-center" style={{gap: '20px', marginTop: '8px'}}>
                {series.map(s => (
                    <div key={s.key} style={{display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px'}}>
                        <span style={{width: '12px', height: '12px', background: s.color, display: 'inline-block', borderRadius: '2px'}}></span>
                        {s.label}
                    </div>
                ))}
            </div>
        </div>
    );
}

// Lightweight horizontal bar-list — used for Status/Device/Country breakdowns.
function BarList({ items, labelKey, colors }) {
    if (!items || items.length === 0) return <p className="text-muted">No data.</p>;
    const max = Math.max(1, ...items.map(i => i.count));
    return (
        <div>
            {items.map((item, idx) => (
                <div key={idx} className="mb-2">
                    <div className="d-flex justify-content-between" style={{fontSize: '12px'}}>
                        <span>{item[labelKey]}</span>
                        <strong>{item.count}</strong>
                    </div>
                    <div style={{background: '#eee', borderRadius: '4px', height: '10px', overflow: 'hidden'}}>
                        <div style={{
                            width: `${(item.count / max) * 100}%`,
                            background: colors ? colors[idx % colors.length] : '#3b82f6',
                            height: '100%',
                        }}></div>
                    </div>
                </div>
            ))}
        </div>
    );
}

export default function AnalyticsDashboard() {
    const [fromDate, setFromDate] = useState('');
    const [toDate, setToDate] = useState('');
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);

    async function fetchData() {
        setLoading(true);
        const result = await getAnalyticsData(fromDate, toDate);
        if (result.success) setData(result.data);
        setLoading(false);
    }

    useEffect(() => {
        fetchData();
    }, []);

    const handleFilter = (e) => {
        e.preventDefault();
        fetchData();
    };

    const statusColors = { Complete: '#28a745', Terminate: '#dc3545', OverQuota: '#ffc107', SecurityFail: '#6f42c1', Started: '#17a2b8' };

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item active">Analytics</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Analytics <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal'}}>(v2 — live data)</span></h4>
                </div>
            </div>

            <div className="col-sm-12 mb-3">
                <div className="card">
                    <div className="card-body">
                        <form onSubmit={handleFilter} className="row align-items-end">
                            <div className="col-sm-4 form-group mb-0">
                                <label>From <span style={{fontWeight: 'normal', fontSize: '11px'}}>(optional)</span></label>
                                <input type="date" className="form-control" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
                            </div>
                            <div className="col-sm-4 form-group mb-0">
                                <label>To <span style={{fontWeight: 'normal', fontSize: '11px'}}>(optional)</span></label>
                                <input type="date" className="form-control" value={toDate} onChange={(e) => setToDate(e.target.value)} />
                            </div>
                            <div className="col-sm-4 form-group mb-0">
                                <button type="submit" className="btn btn-primary">Apply Filter</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            {loading ? (
                <div className="col-12"><p>Loading analytics...</p></div>
            ) : (
                <>
                    <div className="col-12 mb-3">
                        <div className="card">
                            <div className="card-body">
                                <h5 className="mb-3">Daily Trend</h5>
                                <TrendChart trend={data?.trend} />
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 mb-3">
                        <div className="card" style={{height: '100%'}}>
                            <div className="card-body">
                                <h5 className="mb-3">Status Breakdown</h5>
                                <BarList
                                    items={data?.statusBreakdown?.map(s => ({ ...s, label: s.status })) || []}
                                    labelKey="status"
                                    colors={data?.statusBreakdown?.map(s => statusColors[s.status] || '#6c757d')}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 mb-3">
                        <div className="card" style={{height: '100%'}}>
                            <div className="card-body">
                                <h5 className="mb-3">Device Breakdown</h5>
                                <BarList items={data?.deviceBreakdown || []} labelKey="device" />
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 mb-3">
                        <div className="card" style={{height: '100%'}}>
                            <div className="card-body">
                                <h5 className="mb-3">Top Countries</h5>
                                <BarList items={data?.countryBreakdown || []} labelKey="country" />
                            </div>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
}
