"use client";
import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/app/actions/clients';
import { countries } from '@/utils/countries';

export default function AddClient() {
    const [isAPI, setIsAPI] = useState(false);
    const [loading, setLoading] = useState(false);
    const router = useRouter();

    async function handleSubmit(e) {
        e.preventDefault();
        setLoading(true);
        const formData = new FormData(e.target);
        
        // Map the inputs to what the Server Action expects
        const actionData = new FormData();
        actionData.append('name', formData.get('ClientName'));
        actionData.append('company', formData.get('ContactPerson'));
        actionData.append('email', formData.get('ClientEmail'));
        actionData.append('phone', formData.get('ClientPhone'));
        actionData.append('address', formData.get('ClientAddress'));
        actionData.append('website', formData.get('ClientWebsite'));
        actionData.append('status', formData.get('ClientStatus'));
        actionData.append('country', formData.get('CountryId'));
        actionData.append('link_type', formData.get('link_type'));
        actionData.append('complete_url', formData.get('complete_url'));
        actionData.append('terminate_url', formData.get('terminate_url'));
        actionData.append('quotafull_url', formData.get('quotafull_url'));
        actionData.append('quality_url', formData.get('quality_url'));

        const result = await createClient(actionData);
        if (result.success) {
            alert('Client added successfully!');
            router.push('/clients');
        } else {
            alert('Error: ' + result.error);
        }
        setLoading(false);
    }

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item"><Link href="/clients">Client</Link></li>
                            <li className="breadcrumb-item active">Add Client</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Add Client</h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <form className="form-horizontal" onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-md-12 text-right checkBoxLab">
                                    <div className="checkboxTheme">
                                        <input 
                                            id="IsAPI" 
                                            type="checkbox" 
                                            checked={isAPI}
                                            onChange={(e) => setIsAPI(e.target.checked)}
                                        />
                                        <label htmlFor="IsAPI" className="control-label">API</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="row">
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="ClientName">Client Name<span className="text-danger">*</span></label>
                                    <input className="form-control" name="ClientName" id="ClientName" minLength="3" type="text" required />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="ContactPerson">Contact Person<span className="text-danger">*</span></label>
                                    <input className="form-control" name="ContactPerson" id="ContactPerson" minLength="2" required type="text" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="ClientEmail">Email</label>
                                    <input className="form-control" name="ClientEmail" id="ClientEmail" type="email" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="ClientPhone">Phone</label>
                                    <input className="form-control" name="ClientPhone" id="ClientPhone" type="text" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="ClientWebsite">Website</label>
                                    <input className="form-control" name="ClientWebsite" id="ClientWebsite" type="url" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="CountryId">Country<span className="text-danger">*</span></label>
                                    <select className="form-control" name="CountryId" id="CountryId" required>
                                        <option value="">-- Select Country --</option>
                                        {countries.map(c => (
                                            <option key={c.code} value={c.code}>{c.name}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="ClientStatus">Status<span className="text-danger">*</span></label>
                                    <select className="form-control" name="ClientStatus" id="ClientStatus" required>
                                        <option value="Active">Active</option>
                                        <option value="Inactive">Inactive</option>
                                    </select>
                                </div>
                                <div className="col-sm-12 form-group">
                                    <label className="control-label" htmlFor="ClientAddress">Address</label>
                                    <textarea className="form-control" name="ClientAddress" id="ClientAddress" rows="2"></textarea>
                                </div>
                            </div>
                            
                            <h4 className="header-title mt-2 mb-3">Default Redirect URLs</h4>
                            <div className="row">
                                <div className="col-sm-12 form-group">
                                    <label className="control-label">Link Type<span className="text-danger">*</span></label>
                                    <div className="d-flex" style={{gap: '15px'}}>
                                        <div className="custom-control custom-radio">
                                            <input type="radio" id="linkStatic" name="link_type" value="Static" className="custom-control-input" defaultChecked />
                                            <label className="custom-control-label" htmlFor="linkStatic" style={{cursor: 'pointer'}}>Static</label>
                                        </div>
                                        <div className="custom-control custom-radio">
                                            <input type="radio" id="linkDynamic" name="link_type" value="Dynamic" className="custom-control-input" />
                                            <label className="custom-control-label" htmlFor="linkDynamic" style={{cursor: 'pointer'}}>Dynamic</label>
                                        </div>
                                    </div>
                                    <small className="form-text text-muted">Select Dynamic if URLs require tracking parameters.</small>
                                </div>
                                <div className="col-sm-6 form-group">
                                    <label className="control-label">Complete URL</label>
                                    <input className="form-control" name="complete_url" type="url" placeholder="https://..." />
                                </div>
                                <div className="col-sm-6 form-group">
                                    <label className="control-label">Terminate URL</label>
                                    <input className="form-control" name="terminate_url" type="url" placeholder="https://..." />
                                </div>
                                <div className="col-sm-6 form-group">
                                    <label className="control-label">Quota Full URL</label>
                                    <input className="form-control" name="quotafull_url" type="url" placeholder="https://..." />
                                </div>
                                <div className="col-sm-6 form-group">
                                    <label className="control-label">Quality Check URL</label>
                                    <input className="form-control" name="quality_url" type="url" placeholder="https://..." />
                                </div>
                            </div>

                            <hr />
                            <div className="row mt-4">
                                <div className="col-12 text-right">
                                    <button type="submit" className="btn btn-primary mr-2" disabled={loading}>
                                        {loading ? "Submitting..." : "Submit"}
                                    </button>
                                    <Link href="/clients" className="btn btn-secondary">Cancel</Link>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}
