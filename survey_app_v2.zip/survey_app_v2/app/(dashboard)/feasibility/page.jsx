"use client";
import React, { useState, useMemo } from 'react';
import Link from 'next/link';

const DIFFICULTY_TAGS = [
    { label: 'Low IR (<10%)', add: 0.30 },
    { label: 'Medical/HCP', add: 0.40 },
    { label: 'B2B', add: 0.25 },
    { label: 'Long LOI (>25 min)', add: 0.20 },
    { label: 'Short LOI (<5 min)', add: 0.10 },
    { label: 'Urgent Timeline', add: 0.30 },
    { label: 'Webcam Interview', add: 0.35 },
    { label: 'Multi-country', add: 0.25 },
    { label: 'Rural', add: 0.15 },
    { label: 'Sensitive Topic', add: 0.20 },
];

export default function FeasibilityCalculator() {
    const [sample, setSample] = useState(200);
    const [ir, setIr] = useState(40);
    const [loi, setLoi] = useState(15);
    const [timeline, setTimeline] = useState(7);
    const [cpiClient, setCpiClient] = useState(350);
    const [cpiCost, setCpiCost] = useState(150);
    const [qcRate, setQcRate] = useState(5);
    const [overhead, setOverhead] = useState(5000);
    const [quotas, setQuotas] = useState(0);
    const [activeTags, setActiveTags] = useState([]);

    const toggleTag = (label) => {
        setActiveTags(prev => prev.includes(label) ? prev.filter(t => t !== label) : [...prev, label]);
    };

    const results = useMemo(() => {
        const irFrac = ir / 100;
        const qcFrac = qcRate / 100;

        // Effective IR adjusted for quotas (same formula as Exazon calculator)
        const quotaAdj = quotas > 0 ? Math.max(0.5, 1 - (quotas - 1) * 0.08) : 1;
        const effIR = irFrac * quotaAdj;

        // Niche/difficulty multiplier
        let nicheM = 1;
        DIFFICULTY_TAGS.forEach(t => { if (activeTags.includes(t.label)) nicheM += t.add; });

        const sugCpi = Math.round(cpiClient * nicheM);
        const compNeeded = Math.ceil(sample / (1 - qcFrac));
        const attempts = effIR > 0 ? Math.ceil(compNeeded / effIR) : 0;
        const dailyTarget = timeline > 0 ? Math.ceil(compNeeded / timeline) : 0;

        const revenue = sugCpi * sample;
        const fieldCost = cpiCost * compNeeded;
        const qcCost = cpiCost * Math.ceil(sample * qcFrac);
        const totalCost = fieldCost + qcCost + overhead;
        const profit = revenue - totalCost;
        const margin = revenue > 0 ? (profit / revenue) * 100 : 0;

        const risk = timeline < 5 && sample > 150 ? 'High — very tight' : timeline < 7 ? 'Moderate' : 'Low';

        return {
            effIR: Math.round(effIR * 100),
            nichePct: Math.round((nicheM - 1) * 100),
            sugCpi, compNeeded, attempts, dailyTarget,
            revenue, totalCost, profit, margin, risk,
        };
    }, [sample, ir, loi, timeline, cpiClient, cpiCost, qcRate, overhead, quotas, activeTags]);

    const marginColor = results.margin > 30 ? '#28a745' : results.margin > 15 ? '#ffc107' : results.margin > 5 ? '#fd7e14' : '#dc3545';
    const marginLabel = results.margin > 30 ? 'Strong' : results.margin > 15 ? 'Acceptable' : results.margin > 5 ? 'Tight' : 'Walk away';

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item active">Feasibility Calculator</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Feasibility Calculator</h4>
                </div>
            </div>

            <div className="col-md-6 mb-3">
                <div className="card">
                    <div className="card-body">
                        <h5 className="mb-3">Project Inputs</h5>
                        <div className="row">
                            <div className="col-sm-6 form-group">
                                <label>Sample Size (completes)</label>
                                <input type="number" className="form-control" value={sample} min="1" onChange={(e) => setSample(+e.target.value)} />
                            </div>
                            <div className="col-sm-6 form-group">
                                <label>Incidence Rate (IR %)</label>
                                <input type="number" className="form-control" value={ir} min="1" max="100" onChange={(e) => setIr(+e.target.value)} />
                            </div>
                            <div className="col-sm-6 form-group">
                                <label>LOI (minutes)</label>
                                <input type="number" className="form-control" value={loi} min="1" onChange={(e) => setLoi(+e.target.value)} />
                            </div>
                            <div className="col-sm-6 form-group">
                                <label>Timeline (days)</label>
                                <input type="number" className="form-control" value={timeline} min="1" onChange={(e) => setTimeline(+e.target.value)} />
                            </div>
                            <div className="col-sm-6 form-group">
                                <label>Your CPI to Client</label>
                                <input type="number" className="form-control" value={cpiClient} min="0" onChange={(e) => setCpiClient(+e.target.value)} />
                            </div>
                            <div className="col-sm-6 form-group">
                                <label>Vendor CPI (your cost)</label>
                                <input type="number" className="form-control" value={cpiCost} min="0" onChange={(e) => setCpiCost(+e.target.value)} />
                            </div>
                            <div className="col-sm-4 form-group">
                                <label>QC Reject Rate (%)</label>
                                <input type="number" className="form-control" value={qcRate} min="0" max="100" onChange={(e) => setQcRate(+e.target.value)} />
                            </div>
                            <div className="col-sm-4 form-group">
                                <label>Overhead (flat)</label>
                                <input type="number" className="form-control" value={overhead} min="0" onChange={(e) => setOverhead(+e.target.value)} />
                            </div>
                            <div className="col-sm-4 form-group">
                                <label>Number of Quotas</label>
                                <input type="number" className="form-control" value={quotas} min="0" onChange={(e) => setQuotas(+e.target.value)} />
                            </div>
                        </div>

                        <label className="mt-2">Difficulty Factors</label>
                        <div className="d-flex flex-wrap" style={{gap: '6px'}}>
                            {DIFFICULTY_TAGS.map(tag => (
                                <span
                                    key={tag.label}
                                    onClick={() => toggleTag(tag.label)}
                                    className={`badge ${activeTags.includes(tag.label) ? 'badge-primary' : 'badge-light'}`}
                                    style={{ cursor: 'pointer', padding: '6px 10px', border: '1px solid #ddd' }}
                                >
                                    {activeTags.includes(tag.label) ? '✓ ' : ''}{tag.label}
                                </span>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            <div className="col-md-6 mb-3">
                <div className="card">
                    <div className="card-body">
                        <h5 className="mb-3">Estimate</h5>

                        <div className="row mb-3">
                            <div className="col-6">
                                <div className="text-muted" style={{fontSize: '11px'}}>Recommended CPI</div>
                                <h4>{results.sugCpi} <small className="text-muted">({results.nichePct > 0 ? '+' : ''}{results.nichePct}% premium)</small></h4>
                            </div>
                            <div className="col-6">
                                <div className="text-muted" style={{fontSize: '11px'}}>Effective IR (with quotas)</div>
                                <h4>{results.effIR}%</h4>
                            </div>
                        </div>

                        <table className="table table-sm">
                            <tbody>
                                <tr><td>Completes Needed (incl. QC buffer)</td><td className="text-right"><strong>{results.compNeeded}</strong></td></tr>
                                <tr><td>Estimated Attempts / Clicks Needed</td><td className="text-right"><strong>{results.attempts}</strong></td></tr>
                                <tr><td>Daily Target</td><td className="text-right"><strong>{results.dailyTarget}/day</strong></td></tr>
                                <tr><td>Timeline Risk</td><td className="text-right"><strong>{results.risk}</strong></td></tr>
                            </tbody>
                        </table>

                        <hr />

                        <table className="table table-sm">
                            <tbody>
                                <tr><td>Revenue (CPI × sample)</td><td className="text-right" style={{color: '#28a745'}}>{results.revenue.toLocaleString()}</td></tr>
                                <tr><td>Total Field Cost</td><td className="text-right" style={{color: '#dc3545'}}>{Math.round(results.totalCost).toLocaleString()}</td></tr>
                                <tr>
                                    <td><strong>Profit</strong></td>
                                    <td className="text-right"><strong style={{color: results.profit >= 0 ? '#28a745' : '#dc3545'}}>{Math.round(results.profit).toLocaleString()}</strong></td>
                                </tr>
                            </tbody>
                        </table>

                        <div className="alert" style={{ background: `${marginColor}22`, color: marginColor, border: `1px solid ${marginColor}` }}>
                            Margin: <strong>{results.margin.toFixed(1)}%</strong> — {marginLabel}
                        </div>
                        <p className="text-muted" style={{fontSize: '11px'}}>
                            💡 Margin &gt;30% = strong. 15–30% = acceptable. &lt;15% = tight — negotiate CPI or cut cost. &lt;5% = walk away.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
}
