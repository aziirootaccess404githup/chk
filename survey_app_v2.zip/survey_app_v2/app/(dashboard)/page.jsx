import React from 'react';
export const dynamic = 'force-dynamic';
import DashboardFilters from '@/components/dashboard/DashboardFilters';
import DashboardStats from '@/components/dashboard/DashboardStats';
import ConversionsChart from '@/components/dashboard/ConversionsChart';
import RecentSurveysTable from '@/components/dashboard/RecentSurveysTable';
import CompletionCharts from '@/components/dashboard/CompletionCharts';

import { getDashboardStats } from '@/app/actions/dashboard';

export default async function Dashboard() {
    const statsResult = await getDashboardStats();
    
    // Default Fallbacks
    let counts = { active: 0, inactive: 0, closed: 0, invoiced: 0, archive: 0 };
    let recentSurveys = [];
    let conversions = { totalClicks: 0, todayCompletes: 0 };

    if (statsResult.success) {
        counts = statsResult.data.counts;
        recentSurveys = statsResult.data.recentSurveys;
        conversions = statsResult.data.conversions;
    }

    const statsData = [
        { title: "Active", count: counts.active, iconPath: "/images/activeproject.svg", boxClass: "srvBox" },
        { title: "InActive", count: counts.inactive, iconPath: "/images/inactiveproject.svg", boxClass: "ideaBox" },
        { title: "Closed", count: counts.closed, iconPath: "/images/closedprojects.svg", boxClass: "memberBox" },
        { title: "Invoiced", count: counts.invoiced, iconPath: "/images/invoicedprojects.svg", boxClass: "pollBox" },
        { title: "Archive", count: counts.archive, iconPath: "/images/totalproject.svg", boxClass: "memberBox" },
    ];

    return (
        <div className="container-fluid">
            <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
            
            <div id="dashboardId">
                <DashboardFilters />
                
                <div className="row">
                    <div className="col-md-7 col-12">
                        <DashboardStats stats={statsData} />
                    </div>
                    <div className="col-md-5 col-12">
                        <ConversionsChart todayComplete={conversions.todayCompletes} totalClick={conversions.totalClicks} />
                    </div>
                </div>

                <div className="row">
                    <div className="col-md-12 col-12">
                        <RecentSurveysTable surveys={recentSurveys} />
                    </div>
                </div>

                <CompletionCharts charts={statsResult.success ? statsResult.data.charts : null} />
                
                {/* Modal for Today Complete */}
                <div className="modal fade bs-example-modal-lg" id="TableViewModal" tabIndex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div className="modal-dialog modal-md modal-dialog-centered1" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h3 className="modal-title mt-0">Today Complete</h3>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div className="modal-body" id="groupBody">
                                <div className="card-body1">
                                    <div className="table-responsive rdrctStTbl tableBDD">
                                        <table className="table table-striped11">
                                            <thead>
                                                <tr>
                                                    <th> S.No. </th>
                                                    <th> key </th>
                                                </tr>
                                            </thead>
                                            <tbody className="SupplierTbody1">
                                                {/* Map modal data here when available */}
                                                <tr>
                                                    <td colSpan="3">No Record Found !</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
}