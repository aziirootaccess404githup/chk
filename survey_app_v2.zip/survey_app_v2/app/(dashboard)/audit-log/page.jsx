"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { getAuditLog } from '@/app/actions/auditLogActions';

export default function AuditLog() {
    const [logs, setLogs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState("");

    async function fetchLogs(term) {
        setLoading(true);
        const result = await getAuditLog(term || "");
        if (result.success) setLogs(result.data);
        setLoading(false);
    }

    useEffect(() => {
        fetchLogs("");
    }, []);

    useEffect(() => {
        const timer = setTimeout(() => fetchLogs(searchTerm), 300);
        return () => clearTimeout(timer);
    }, [searchTerm]);

    const actionColors = {
        block_ip: 'badge-danger',
        unblock_ip: 'badge-success',
        delete_client: 'badge-danger',
        delete_supplier: 'badge-danger',
        delete_project: 'badge-danger',
    };

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item active">Audit Log</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Audit Log <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal'}}>(v2 — live data)</span></h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card">
                    <div className="card-body">
                        <p className="text-muted" style={{fontSize: '12px'}}>
                            Currently logs: IP block/unblock, client/supplier/project deletion. More sensitive actions can be added over time.
                        </p>
                        <div className="row mb-3 justify-content-end">
                            <div className="col-md-4 col-sm-12">
                                <div className="app-search-box">
                                    <div className="input-group">
                                        <input
                                            type="text"
                                            className="form-control"
                                            placeholder="Search action, details, or admin..."
                                            value={searchTerm}
                                            onChange={(e) => setSearchTerm(e.target.value)}
                                        />
                                        {searchTerm && (
                                            <a className="clearCrossIcon" onClick={() => setSearchTerm("")} style={{cursor: 'pointer'}}>
                                                <i className="fa fa-times-circle" aria-hidden="true"></i>
                                            </a>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="table-responsive">
                            <table className="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Timestamp</th>
                                        <th>Admin</th>
                                        <th>Action</th>
                                        <th>Details</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {loading ? (
                                        <tr><td colSpan="4" className="text-center">Loading...</td></tr>
                                    ) : logs.length > 0 ? (
                                        logs.map(l => (
                                            <tr key={l.id}>
                                                <td>{new Date(l.created_at).toLocaleString()}</td>
                                                <td>{l.admin_email}</td>
                                                <td>
                                                    <span className={`badge ${actionColors[l.action] || 'badge-info'}`}>{l.action}</span>
                                                </td>
                                                <td>{l.details || '-'}</td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr><td colSpan="4" className="text-center">No Record Found !</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
