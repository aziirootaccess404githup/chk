"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { getNotes, addNote, deleteNote } from '@/app/actions/notes';

export default function NotesPage() {
    const [notes, setNotes] = useState([]);
    const [newNote, setNewNote] = useState('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    async function fetchNotes() {
        setLoading(true);
        const result = await getNotes();
        if (result.success) setNotes(result.data);
        setLoading(false);
    }

    useEffect(() => { fetchNotes(); }, []);

    const handleAdd = async (e) => {
        e.preventDefault();
        if (!newNote.trim()) return;
        setSaving(true);
        const result = await addNote(newNote);
        setSaving(false);
        if (result.success) {
            setNewNote('');
            fetchNotes();
        } else {
            alert("Error: " + result.error);
        }
    };

    const handleDelete = async (id) => {
        const result = await deleteNote(id);
        if (result.success) fetchNotes();
    };

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item active">Notes</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Notes <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal'}}>(v2 — live data)</span></h4>
                </div>
            </div>

            <div className="col-sm-12 mb-3">
                <div className="card">
                    <div className="card-body">
                        <form onSubmit={handleAdd} className="d-flex" style={{gap: '10px'}}>
                            <input
                                type="text"
                                className="form-control"
                                placeholder="Write a quick note..."
                                value={newNote}
                                onChange={(e) => setNewNote(e.target.value)}
                            />
                            <button type="submit" className="btn btn-primary" disabled={saving}>
                                {saving ? '...' : 'Add'}
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <div className="col-12">
                <div className="row">
                    {loading ? (
                        <div className="col-12"><p>Loading...</p></div>
                    ) : notes.length > 0 ? (
                        notes.map(n => (
                            <div key={n.id} className="col-md-3 col-sm-6 mb-3">
                                <div className="card" style={{ background: '#fffbea', border: '1px solid #f0e5b8' }}>
                                    <div className="card-body">
                                        <p style={{ fontSize: '13px', marginBottom: '10px' }}>{n.note}</p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <small className="text-muted" style={{ fontSize: '10px' }}>
                                                {new Date(n.created_at).toLocaleDateString()}
                                            </small>
                                            <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(n.id)}>
                                                <i className="fa fa-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="col-12"><p className="text-muted">No notes yet.</p></div>
                    )}
                </div>
            </div>
        </div>
    );
}
