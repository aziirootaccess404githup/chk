"use client";
import React, { useState } from 'react';
import Link from 'next/link';
import { updatePassword } from '@/app/login/actions';

export default function ChangePassword() {
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [saving, setSaving] = useState(false);
    const [message, setMessage] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage(null);

        if (newPassword.length < 6) {
            setMessage({ type: 'danger', text: 'Password must be at least 6 characters.' });
            return;
        }
        if (newPassword !== confirmPassword) {
            setMessage({ type: 'danger', text: 'Passwords do not match.' });
            return;
        }

        setSaving(true);
        const result = await updatePassword(newPassword);
        setSaving(false);

        if (result.error) {
            setMessage({ type: 'danger', text: result.error });
        } else {
            setMessage({ type: 'success', text: 'Password updated successfully!' });
            setNewPassword('');
            setConfirmPassword('');
        }
    };

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item active">Change Password</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Change Password <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal'}}>(v2 — live)</span></h4>
                </div>
            </div>

            <div className="col-sm-12 col-md-6">
                <div className="card">
                    <div className="card-body">
                        <form onSubmit={handleSubmit}>
                            <div className="form-group">
                                <label>New Password</label>
                                <input
                                    type="password"
                                    className="form-control"
                                    value={newPassword}
                                    onChange={(e) => setNewPassword(e.target.value)}
                                    required
                                    minLength={6}
                                />
                            </div>
                            <div className="form-group">
                                <label>Confirm New Password</label>
                                <input
                                    type="password"
                                    className="form-control"
                                    value={confirmPassword}
                                    onChange={(e) => setConfirmPassword(e.target.value)}
                                    required
                                    minLength={6}
                                />
                            </div>

                            {message && (
                                <div className={`alert alert-${message.type}`}>{message.text}</div>
                            )}

                            <button type="submit" className="btn btn-primary" disabled={saving}>
                                {saving ? 'Updating...' : 'Update Password'}
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}
