"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { getSuppliers, updateSupplier, deleteSupplier } from '@/app/actions/suppliers';
import { countries } from '@/utils/countries';

export default function SupplierList() {
    const [searchTerm, setSearchTerm] = useState("");
    const [filterStatus, setFilterStatus] = useState("Total");
    const [suppliers, setSuppliers] = useState([]);
    const [loading, setLoading] = useState(true);

    const [editModalSupplier, setEditModalSupplier] = useState(null);
    const [editSaving, setEditSaving] = useState(false);

    function getCountryName(code) {
        const c = countries.find(x => x.code === code);
        return c ? c.name : (code || 'N/A');
    }

    async function fetchSuppliers() {
        setLoading(true);
        const result = await getSuppliers();
        if (result.success) {
            setSuppliers(result.data);
        }
        setLoading(false);
    }

    useEffect(() => {
        fetchSuppliers();
    }, []);

    const activeCount = suppliers.filter(s => s.status === 'Active').length;
    const inactiveCount = suppliers.filter(s => s.status === 'Inactive').length;
    const totalCount = suppliers.length;

    const filteredSuppliers = suppliers.filter(s => {
        const matchesSearch = s.name.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus = filterStatus === "Total" || s.status === filterStatus;
        return matchesSearch && matchesStatus;
    });

    return (
        <div className="tabPanelWraps">
            <div className="row">
                <div className="col-12">
                    <div className="page-title-box">
                        <div className="page-title-right">
                            <ol className="breadcrumb m-0">
                                <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                                <li className="breadcrumb-item active">Supplier</li>
                            </ol>
                        </div>
                        <h4 className="page-title">Supplier</h4>
                    </div>
                </div>
            </div>

            <div className="row">
                <div className="col-md-9 col-sm-12 col-12">
                    <ul className="numTabSM">
                        <li className={`totalNM ${filterStatus === 'Total' ? 'active' : ''}`} onClick={() => setFilterStatus('Total')} style={{cursor: 'pointer'}}>
                            <p className="m-0"> Total-<span>{totalCount}</span> </p>
                        </li>
                        <li className={`bgA ${filterStatus === 'Active' ? 'active' : ''}`} onClick={() => setFilterStatus('Active')} style={{cursor: 'pointer'}}>
                            <p className="m-0"> <i className="fa fa-square active" aria-hidden="true"></i> Active-<span>{activeCount}</span> </p>
                        </li>
                        <li className={`bgA ${filterStatus === 'Inactive' ? 'active' : ''}`} onClick={() => setFilterStatus('Inactive')} style={{cursor: 'pointer'}}>
                            <p className="m-0"> <i className="fa fa-square inActive" aria-hidden="true"></i> InActive-<span>{inactiveCount}</span> </p>
                        </li>
                    </ul>
                </div>
                <div className="col-md-3 col-sm-12 col-12">
                    <div className="row justify-content-end numTabSMSearch">
                        <form className="col-12 app-search" onSubmit={(e) => e.preventDefault()}>
                            <div className="app-search-box">
                                <div className="input-group">
                                    <input 
                                        type="text" 
                                        className="form-control" 
                                        placeholder="Search..." 
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                    />
                                    {searchTerm && (
                                        <a className="clearCrossIcon" onClick={() => setSearchTerm("")} style={{cursor: 'pointer'}}>
                                            <i className="fa fa-times-circle" aria-hidden="true"></i>
                                        </a>
                                    )}
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div className="row">
                <div className="col-12">
                    <div className="card tblecard">
                        <div className="card-body">
                            <div className="responsive-table-plugin">
                                <div className="table-rep-plugin">
                                    <div className="table-responsive">
                                        <table className="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>S.No.</th>
                                                    <th>Action</th>
                                                    <th style={{minWidth: "100px", maxWidth: "120px", textAlign: "center"}}>SupplierCode</th>
                                                    <th style={{minWidth: "150px", maxWidth: "250px", textAlign: "left"}}>SupplierName</th>
                                                    <th>Country</th>
                                                    <th>TotalProject</th>
                                                    <th>ActiveProject</th>
                                                    <th>InvoicedProject</th>
                                                    <th>ArchivedProject</th>
                                                    <th>ClosedProject</th>
                                                    <th>TotalTraffic</th>
                                                    <th>Complete</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {loading ? (
                                                    <tr><td colSpan="12" className="text-center">Loading suppliers...</td></tr>
                                                ) : filteredSuppliers.length === 0 ? (
                                                    <tr><td colSpan="12" className="text-center">No suppliers found.</td></tr>
                                                ) : filteredSuppliers.map((supplier, index) => (
                                                    <tr key={supplier.id}>
                                                        <td>{index + 1}</td>
                                                        <td>
                                                            <div className="btn-group btn-group-sm" style={{gap: '5px'}}>
                                                                <Link
                                                                    href={`/suppliers/${supplier.id}`}
                                                                    className="btn btn-sm btn-info tooltipBTNA"
                                                                    title="View Details"
                                                                >
                                                                    <i className="fa fa-eye"></i>
                                                                </Link>
                                                                <button 
                                                                    className="btn btn-sm btn-primary tooltipBTNA" 
                                                                    title="Edit"
                                                                    onClick={() => setEditModalSupplier(supplier)}
                                                                >
                                                                    <i className="fa fa-edit"></i>
                                                                </button>
                                                                <button 
                                                                    className="btn btn-sm btn-danger tooltipBTNA" 
                                                                    title="Delete"
                                                                    onClick={async () => {
                                                                        if (confirm(`Are you sure you want to delete ${supplier.name}?`)) {
                                                                            const res = await deleteSupplier(supplier.id);
                                                                            if (res.success) {
                                                                                fetchSuppliers();
                                                                            } else {
                                                                                alert("Error: " + res.error);
                                                                            }
                                                                        }
                                                                    }}
                                                                >
                                                                    <i className="fas fa-trash"></i>
                                                                </button>
                                                            </div>
                                                        </td>
                                                        <td style={{textAlign: "center"}}>{"S" + supplier.id.substring(0,4)}</td>
                                                        <td style={{textAlign: "left"}}>{supplier.name}</td>
                                                        <td>{getCountryName(supplier.country)}</td>
                                                        <td>0</td>
                                                        <td>0</td>
                                                        <td>0</td>
                                                        <td>0</td>
                                                        <td>0</td>
                                                        <td>0</td>
                                                        <td>0</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Edit Modal */}
            {editModalSupplier && (
                <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog modal-lg">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">Edit Supplier: {editModalSupplier.name}</h5>
                                <button type="button" className="close" onClick={() => setEditModalSupplier(null)}>
                                    <span>&times;</span>
                                </button>
                            </div>
                            <form onSubmit={async (e) => {
                                e.preventDefault();
                                setEditSaving(true);
                                const formData = new FormData(e.target);
                                const payload = {
                                    name: formData.get('name'),
                                    contact_person: formData.get('contact_person'),
                                    contact_email: formData.get('contact_email'),
                                    phone: formData.get('phone'),
                                    website: formData.get('website'),
                                    status: formData.get('status'),
                                    country: formData.get('country'),
                                    address: formData.get('address'),
                                    supplier_type: formData.get('supplier_type'),
                                    end_behavior: formData.get('end_behavior'),
                                    complete_url: formData.get('complete_url'),
                                    terminate_url: formData.get('terminate_url'),
                                    quotafull_url: formData.get('quotafull_url'),
                                    quality_url: formData.get('quality_url'),
                                    panel_size: formData.get('panel_size') ? parseInt(formData.get('panel_size'), 10) : null,
                                    survey_close: formData.get('survey_close') || null,
                                    postback_url: formData.get('postback_url') || null
                                };
                                const result = await updateSupplier(editModalSupplier.id, payload);
                                if (result.success) {
                                    alert('Supplier updated successfully');
                                    setEditModalSupplier(null);
                                    fetchSuppliers();
                                } else {
                                    alert('Error: ' + result.error);
                                }
                                setEditSaving(false);
                            }}>
                                <div className="modal-body" style={{ maxHeight: '70vh', overflowY: 'auto' }}>
                                    <div className="row">
                                        <div className="col-sm-6 form-group">
                                            <label>Supplier Name</label>
                                            <input type="text" className="form-control" name="name" defaultValue={editModalSupplier.name} required />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Contact Person</label>
                                            <input type="text" className="form-control" name="contact_person" defaultValue={editModalSupplier.contact_person || ''} required />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Email</label>
                                            <input type="email" className="form-control" name="contact_email" defaultValue={editModalSupplier.contact_email || ''} />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Phone</label>
                                            <input type="text" className="form-control" name="phone" defaultValue={editModalSupplier.phone || ''} />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Website</label>
                                            <input type="url" className="form-control" name="website" defaultValue={editModalSupplier.website || ''} />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Status</label>
                                            <select className="form-control" name="status" defaultValue={editModalSupplier.status || 'Active'}>
                                                <option value="Active">Active</option>
                                                <option value="Inactive">Inactive</option>
                                            </select>
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Country</label>
                                            <select className="form-control" name="country" defaultValue={editModalSupplier.country || ''}>
                                                <option value="">-- Select Country --</option>
                                                {countries.map(c => (
                                                    <option key={c.code} value={c.code}>{c.name}</option>
                                                ))}
                                            </select>
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Supplier Type</label>
                                            <select className="form-control" name="supplier_type" defaultValue={editModalSupplier.supplier_type || 'Static'}>
                                                <option value="Static">Static</option>
                                                <option value="Dynamic">Dynamic</option>
                                            </select>
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>End Behavior <span style={{fontWeight: 'normal', fontSize: '11px'}}>(on complete/terminate)</span></label>
                                            <select className="form-control" name="end_behavior" defaultValue={editModalSupplier.end_behavior || 'redirect'}>
                                                <option value="redirect">Redirect (send respondent to vendor's URL)</option>
                                                <option value="show_page">Show Page (notify vendor via background postback)</option>
                                            </select>
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Panel Size</label>
                                            <input type="number" className="form-control" name="panel_size" min="0" defaultValue={editModalSupplier.panel_size || ''} placeholder="e.g. 50000" />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Survey Close</label>
                                            <select className="form-control" name="survey_close" defaultValue={editModalSupplier.survey_close || ''}>
                                                <option value="">-- Select --</option>
                                                <option value="Open">Open</option>
                                                <option value="Closed">Closed</option>
                                            </select>
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Postback URL</label>
                                            <input type="url" className="form-control" name="postback_url" defaultValue={editModalSupplier.postback_url || ''} placeholder="https://supplier.com/postback" />
                                        </div>
                                        <div className="col-sm-12 form-group">
                                            <label>Address</label>
                                            <textarea className="form-control" name="address" defaultValue={editModalSupplier.address || ''} rows="2"></textarea>
                                        </div>
                                    </div>
                                    <h5 className="mb-2 mt-3">Supplier Return URLs (Optional)</h5>
                                    <div className="row">
                                        <div className="col-sm-6 form-group">
                                            <label>Complete URL</label>
                                            <input type="url" className="form-control" name="complete_url" defaultValue={editModalSupplier.complete_url || ''} />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Terminate URL</label>
                                            <input type="url" className="form-control" name="terminate_url" defaultValue={editModalSupplier.terminate_url || ''} />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Quota Full URL</label>
                                            <input type="url" className="form-control" name="quotafull_url" defaultValue={editModalSupplier.quotafull_url || ''} />
                                        </div>
                                        <div className="col-sm-6 form-group">
                                            <label>Quality Check URL</label>
                                            <input type="url" className="form-control" name="quality_url" defaultValue={editModalSupplier.quality_url || ''} />
                                        </div>
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" onClick={() => setEditModalSupplier(null)}>Close</button>
                                    <button type="submit" className="btn btn-primary" disabled={editSaving}>
                                        {editSaving ? "Saving..." : "Save changes"}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
