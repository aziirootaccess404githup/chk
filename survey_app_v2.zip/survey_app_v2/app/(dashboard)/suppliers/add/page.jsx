"use client";
import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createSupplier } from '@/app/actions/suppliers';
import { countries } from '@/utils/countries';

export default function AddSupplier() {
    const [isAPI, setIsAPI] = useState(false);
    const [loading, setLoading] = useState(false);
    const router = useRouter();

    async function handleSubmit(e) {
        e.preventDefault();
        setLoading(true);
        const formData = new FormData(e.target);
        
        const actionData = new FormData();
        actionData.append('name', formData.get('SupplierName'));
        actionData.append('contact_email', formData.get('SupplierEmail'));
        actionData.append('cpi_rate', null);
        actionData.append('contact_person', formData.get('ContactPerson'));
        actionData.append('phone', formData.get('SupplierPhone'));
        actionData.append('website', formData.get('SupplierWebsite'));
        actionData.append('status', formData.get('SupplierStatus'));
        actionData.append('country', formData.get('CountryId'));
        actionData.append('address', formData.get('SupplierAddress'));
        actionData.append('supplier_type', formData.get('SupplierType'));
        actionData.append('end_behavior', formData.get('EndBehavior'));
        actionData.append('complete_url', formData.get('complete_url'));
        actionData.append('terminate_url', formData.get('terminate_url'));
        actionData.append('quotafull_url', formData.get('quotafull_url'));
        actionData.append('quality_url', formData.get('quality_url'));
        actionData.append('panel_size', formData.get('PanelSize'));
        actionData.append('survey_close', formData.get('SurveyClose'));
        actionData.append('postback_url', formData.get('PostbackUrl'));

        const result = await createSupplier(actionData);
        if (result.success) {
            alert('Supplier added successfully!');
            router.push('/suppliers');
        } else {
            alert('Error: ' + result.error);
        }
        setLoading(false);
    }

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item"><Link href="/suppliers">Supplier</Link></li>
                            <li className="breadcrumb-item active">Add Supplier</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Add Supplier</h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <form className="form-horizontal" onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-md-12 text-right checkBoxLab">
                                    <div className="checkboxTheme">
                                        <input 
                                            id="IsAPI" 
                                            type="checkbox" 
                                            checked={isAPI}
                                            onChange={(e) => setIsAPI(e.target.checked)}
                                        />
                                        <label htmlFor="IsAPI" className="control-label">API</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="row">
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="SupplierName">Supplier Name<span className="text-danger">*</span></label>
                                    <input className="form-control" name="SupplierName" id="SupplierName" minLength="2" type="text" required />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="ContactPerson">Contact Person<span className="text-danger">*</span></label>
                                    <input className="form-control" name="ContactPerson" id="ContactPerson" type="text" required />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="SupplierEmail">Email</label>
                                    <input className="form-control" name="SupplierEmail" id="SupplierEmail" type="email" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="SupplierPhone">Phone</label>
                                    <input className="form-control" name="SupplierPhone" id="SupplierPhone" type="text" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="SupplierWebsite">Website</label>
                                    <input className="form-control" name="SupplierWebsite" id="SupplierWebsite" type="url" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="CountryId">Country<span className="text-danger">*</span></label>
                                    <select className="form-control" name="CountryId" id="CountryId" required>
                                        <option value="">-- Select Country --</option>
                                        {countries.map(c => (
                                            <option key={c.code} value={c.code}>{c.name}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="SupplierStatus">Status<span className="text-danger">*</span></label>
                                    <select className="form-control" name="SupplierStatus" id="SupplierStatus" required>
                                        <option value="Active">Active</option>
                                        <option value="Inactive">Inactive</option>
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="SupplierType">Supplier Type<span className="text-danger">*</span></label>
                                    <select className="form-control" name="SupplierType" id="SupplierType" required>
                                        <option value="Static">Static</option>
                                        <option value="Dynamic">Dynamic</option>
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="EndBehavior">End Behavior <span style={{fontWeight: 'normal', fontSize: '11px'}}>(on complete/terminate)</span></label>
                                    <select className="form-control" name="EndBehavior" id="EndBehavior">
                                        <option value="redirect">Redirect (send respondent to vendor's URL)</option>
                                        <option value="show_page">Show Page (notify vendor via background postback)</option>
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="PanelSize">Panel Size</label>
                                    <input className="form-control" name="PanelSize" id="PanelSize" type="number" min="0" placeholder="e.g. 50000" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="SurveyClose">Survey Close</label>
                                    <select className="form-control" name="SurveyClose" id="SurveyClose">
                                        <option value="">-- Select --</option>
                                        <option value="Open">Open</option>
                                        <option value="Closed">Closed</option>
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="PostbackUrl">Postback URL</label>
                                    <input className="form-control" name="PostbackUrl" id="PostbackUrl" type="url" placeholder="https://supplier.com/postback" />
                                </div>
                                <div className="col-sm-12 form-group">
                                    <label className="control-label" htmlFor="SupplierAddress">Address</label>
                                    <textarea className="form-control" name="SupplierAddress" id="SupplierAddress" rows="2"></textarea>
                                </div>
                            </div>

                            <hr />
                            <h5 className="mb-3">Supplier Return URLs (Optional)</h5>
                            <div className="row">
                                <div className="col-12 form-group">
                                    <label className="control-label" htmlFor="complete_url">Complete URL</label>
                                    <input className="form-control" name="complete_url" id="complete_url" type="url" placeholder="https://supplier.com/complete?pid=[PID]" />
                                    <small className="text-muted">Use <code>[PID]</code> where the panelist ID should be injected.</small>
                                </div>
                                <div className="col-12 form-group">
                                    <label className="control-label" htmlFor="terminate_url">Terminate URL</label>
                                    <input className="form-control" name="terminate_url" id="terminate_url" type="url" placeholder="https://supplier.com/terminate?pid=[PID]" />
                                </div>
                                <div className="col-12 form-group">
                                    <label className="control-label" htmlFor="quotafull_url">Quota Full URL</label>
                                    <input className="form-control" name="quotafull_url" id="quotafull_url" type="url" placeholder="https://supplier.com/quotafull?pid=[PID]" />
                                </div>
                                <div className="col-12 form-group">
                                    <label className="control-label" htmlFor="quality_url">Quality Check URL</label>
                                    <input className="form-control" name="quality_url" id="quality_url" type="url" placeholder="https://supplier.com/quality?pid=[PID]" />
                                </div>
                            </div>

                            <hr />
                            <div className="row mt-4">
                                <div className="col-12 text-right">
                                    <button type="submit" className="btn btn-primary mr-2">Submit</button>
                                    <Link href="/suppliers" className="btn btn-secondary">Cancel</Link>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}
