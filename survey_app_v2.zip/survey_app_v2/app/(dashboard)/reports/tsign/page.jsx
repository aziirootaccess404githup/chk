"use client";
import React, { useState } from 'react';
import Link from 'next/link';
import { getTSignReport } from '@/app/actions/reports';

export default function TSignReport() {
    const [projectSearch, setProjectSearch] = useState("");
    const [fromDate, setFromDate] = useState("");
    const [toDate, setToDate] = useState("");
    const [showReport, setShowReport] = useState(false);
    const [reportData, setReportData] = useState([]);
    const [loading, setLoading] = useState(false);

    const handleViewReport = async (e) => {
        e.preventDefault();
        if (!fromDate || !toDate) {
            alert("Please select both From and To dates.");
            return;
        }
        setLoading(true);
        const result = await getTSignReport(fromDate, toDate, projectSearch);
        setLoading(false);
        if (result.success) {
            setReportData(result.data);
            setShowReport(true);
        } else {
            alert("Error loading report: " + result.error);
        }
    };

    const handleReset = () => {
        setProjectSearch("");
        setFromDate("");
        setToDate("");
        setShowReport(false);
        setReportData([]);
    };

    const handleDownload = () => {
        if (reportData.length === 0) return;
        const headers = ["Date", "Total Leads", "Completes", "Speeder %", "Duplicate %", "Avg Quality Score", "Signal"];
        const rows = reportData.map(d => [d.date, d.total, d.completes, d.speederRate, d.duplicateRate, d.avgScore ?? '-', d.isSignal ? 'YES' : '']);
        const csvContent = [headers, ...rows]
            .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(","))
            .join("\n");
        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `tsign-trend-report-${Date.now()}.csv`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item">Report</li>
                            <li className="breadcrumb-item active">TSign Report</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">
                        TSign Report <span style={{fontSize: '13px', color: '#6c757d', fontWeight: 'normal'}}>(Trend & Signal — daily fraud-signal breakdown)</span>
                        <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal', marginLeft: '8px'}}>(v2 — live data)</span>
                    </h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <form onSubmit={handleViewReport}>
                            <div className="row align-items-end mb-4">
                                <div className="col-sm-12 col-md-4 form-group mb-0">
                                    <label className="control-label">Project <span style={{fontWeight:'normal', fontSize:'11px'}}>(optional — leave blank for all)</span></label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Search Project..."
                                        value={projectSearch}
                                        onChange={(e) => setProjectSearch(e.target.value)}
                                    />
                                </div>
                                <div className="col-sm-12 col-md-8">
                                    <div className="row align-items-end">
                                        <div className="col-sm-6 col-md-4 form-group mb-0">
                                            <label className="control-label">From<span className="text-danger">*</span></label>
                                            <input type="date" className="form-control" value={fromDate} onChange={(e) => setFromDate(e.target.value)} required />
                                        </div>
                                        <div className="col-sm-6 col-md-4 form-group mb-0">
                                            <label className="control-label">To<span className="text-danger">*</span></label>
                                            <input type="date" className="form-control" value={toDate} onChange={(e) => setToDate(e.target.value)} required />
                                        </div>
                                        <div className="col-sm-12 col-md-4 form-group mb-0">
                                            <div className="d-flex gap-2" style={{gap: '10px'}}>
                                                <button className="btn btn-primary m-0" type="submit">View</button>
                                                <button className="btn btn-info m-0" type="button" disabled={!showReport} onClick={handleDownload}>Download</button>
                                                <button className="btn btn-secondary m-0" type="button" onClick={handleReset}>Reset</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                        {loading && <p>Loading report...</p>}

                        {showReport && !loading && (
                            <div className="row mt-4">
                                <div className="col-md-12 col-lg-12">
                                    {reportData.some(d => d.isSignal) && (
                                        <div className="alert alert-warning" role="alert">
                                            ⚠ One or more days show an anomalous fraud-signal (speeder/duplicate rate above 30%, or average quality score below 60). Flagged rows are highlighted below.
                                        </div>
                                    )}
                                    <div className="table-responsive tableScrollFix reportGrid">
                                        <table className="table table-striped fixTable">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th style={{minWidth: "100px"}}>Total Leads</th>
                                                    <th style={{minWidth: "100px"}}>Completes</th>
                                                    <th style={{minWidth: "100px"}}>Speeder %</th>
                                                    <th style={{minWidth: "110px"}}>Duplicate %</th>
                                                    <th style={{minWidth: "130px"}}>Avg Quality Score</th>
                                                    <th style={{minWidth: "100px"}}>Signal</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {reportData.length > 0 ? (
                                                    reportData.map((d) => (
                                                        <tr key={d.date} style={d.isSignal ? {background: '#fff3cd'} : {}}>
                                                            <td>{d.date}</td>
                                                            <td>{d.total}</td>
                                                            <td>{d.completes}</td>
                                                            <td>{d.speederRate}%</td>
                                                            <td>{d.duplicateRate}%</td>
                                                            <td>{d.avgScore ?? '-'}</td>
                                                            <td>
                                                                {d.isSignal
                                                                    ? <span className="badge badge-warning">⚠ Signal</span>
                                                                    : <span className="badge badge-success">Normal</span>}
                                                            </td>
                                                        </tr>
                                                    ))
                                                ) : (
                                                    <tr>
                                                        <td colSpan="7" className="text-center">No Record Found !</td>
                                                    </tr>
                                                )}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
