"use client";
import React, { useState } from 'react';
import Link from 'next/link';
import { getPMActivityReport } from '@/app/actions/reports';

export default function PMActivityReport() {
    const [projectSearch, setProjectSearch] = useState("");
    const [pmFilter, setPmFilter] = useState("");
    const [fromDate, setFromDate] = useState("");
    const [toDate, setToDate] = useState("");
    const [showReport, setShowReport] = useState(false);
    const [reportData, setReportData] = useState([]);
    const [loading, setLoading] = useState(false);

    const handleViewReport = async (e) => {
        e.preventDefault();
        if (!projectSearch) {
            alert("Please enter a project to search first.");
            return;
        }
        setLoading(true);
        const result = await getPMActivityReport(projectSearch, fromDate, toDate);
        setLoading(false);
        if (result.success) {
            const filtered = pmFilter
                ? result.data.filter(r => r.projectManager.toLowerCase().includes(pmFilter.toLowerCase()))
                : result.data;
            setReportData(filtered);
            setShowReport(true);
        } else {
            alert("Error loading report: " + result.error);
        }
    };

    const handleReset = () => {
        setProjectSearch("");
        setPmFilter("");
        setFromDate("");
        setToDate("");
        setShowReport(false);
        setReportData([]);
    };

    const handleDownload = () => {
        if (reportData.length === 0) return;
        const headers = ["S.No.", "Project Manager", "Activity", "Sub-Activity", "Date", "Duration"];
        const rows = reportData.map((p, i) => [i + 1, p.projectManager, p.activity, p.subActivity, p.date, p.duration]);
        const csvContent = [headers, ...rows]
            .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(","))
            .join("\n");
        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `pm-activity-report-${projectSearch}-${Date.now()}.csv`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item">Report</li>
                            <li className="breadcrumb-item active">PM Activity Report</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">PM Activity Report <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal'}}>(v2 — live data)</span></h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <form onSubmit={handleViewReport}>
                            <div className="row align-items-end mb-4">
                                <div className="col-sm-12 col-md-3 form-group mb-0">
                                    <label className="control-label">Project<span className="text-danger">*</span></label>
                                    <div className="position-relative">
                                        <input
                                            type="text"
                                            className="form-control"
                                            placeholder="Search Project..."
                                            value={projectSearch}
                                            onChange={(e) => setProjectSearch(e.target.value)}
                                            required
                                        />
                                        {projectSearch && (
                                            <a
                                                className="clearCrossIcon"
                                                title="Clear"
                                                onClick={() => setProjectSearch("")}
                                                style={{position: 'absolute', right: '10px', top: '10px', cursor: 'pointer', zIndex: 10}}
                                            >
                                                <i className="fa fa-times-circle" aria-hidden="true"></i>
                                            </a>
                                        )}
                                    </div>
                                </div>
                                <div className="col-sm-4 col-md-3 form-group mb-0">
                                    <label className="control-label">Project Manager <span style={{fontWeight: 'normal', fontSize: '11px'}}>(optional filter)</span></label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Filter by PM name..."
                                        value={pmFilter}
                                        onChange={(e) => setPmFilter(e.target.value)}
                                    />
                                </div>
                                <div className="col-sm-12 col-md-6">
                                    <div className="row align-items-end">
                                        <div className="col-sm-6 col-md-4 form-group mb-0">
                                            <label className="control-label">From</label>
                                            <input
                                                type="date"
                                                className="form-control"
                                                value={fromDate}
                                                onChange={(e) => setFromDate(e.target.value)}
                                            />
                                        </div>
                                        <div className="col-sm-6 col-md-4 form-group mb-0">
                                            <label className="control-label">To</label>
                                            <input
                                                type="date"
                                                className="form-control"
                                                value={toDate}
                                                onChange={(e) => setToDate(e.target.value)}
                                            />
                                        </div>
                                        <div className="col-sm-12 col-md-4 form-group mb-0">
                                            <div className="d-flex gap-2" style={{gap: '10px'}}>
                                                <button className="btn btn-primary m-0" type="submit">View</button>
                                                <button className="btn btn-info m-0" type="button" disabled={!showReport} onClick={handleDownload}>Download</button>
                                                <button className="btn btn-secondary m-0" type="button" onClick={handleReset}>Reset</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                        {loading && <p>Loading report...</p>}

                        {showReport && !loading && (
                            <div className="row mt-4">
                                <div className="col-md-12 col-lg-12">
                                    <div className="table-responsive tableScrollFix urActivityReport">
                                        <table className="table table-striped fixTable">
                                            <thead>
                                                <tr>
                                                    <th>S.No.</th>
                                                    <th style={{minWidth: "150px"}}>Project Manager</th>
                                                    <th style={{minWidth: "200px"}}>Activity</th>
                                                    <th style={{minWidth: "150px"}}>Sub-Activity</th>
                                                    <th style={{minWidth: "120px"}}>Date</th>
                                                    <th style={{minWidth: "120px"}}>Duration</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {reportData.length > 0 ? (
                                                    reportData.map((p, index) => (
                                                        <tr key={p.id}>
                                                            <td>{index + 1}</td>
                                                            <td><strong>{p.projectManager}</strong></td>
                                                            <td>{p.activity}</td>
                                                            <td>{p.subActivity}</td>
                                                            <td>{p.date}</td>
                                                            <td>{p.duration}</td>
                                                        </tr>
                                                    ))
                                                ) : (
                                                    <tr>
                                                        <td colSpan="6" className="text-center"><strong>No Record Found !</strong></td>
                                                    </tr>
                                                )}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
