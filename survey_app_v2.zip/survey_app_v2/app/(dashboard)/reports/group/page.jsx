"use client";
import React, { useState } from 'react';
import Link from 'next/link';
import { getGroupReport, exportProjectLogs } from '@/app/actions/reports';

export default function GroupReport() {
    const [groupBy, setGroupBy] = useState("client");
    const [groupValue, setGroupValue] = useState("");
    const [fromDate, setFromDate] = useState("");
    const [toDate, setToDate] = useState("");
    const [showReport, setShowReport] = useState(false);
    const [reportData, setReportData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [selectAll, setSelectAll] = useState(false);
    const [selectedItems, setSelectedItems] = useState({});
    const [rowDownloading, setRowDownloading] = useState(null);

    const handleViewReport = async (e) => {
        e.preventDefault();
        if (!groupValue) {
            alert("Please enter a value to group by first.");
            return;
        }
        setLoading(true);
        const result = await getGroupReport(groupBy, groupValue, fromDate, toDate);
        setLoading(false);
        if (result.success) {
            setReportData(result.data);
            setShowReport(true);
            setSelectedItems({});
            setSelectAll(false);
        } else {
            alert("Error loading report: " + result.error);
        }
    };

    const handleSelectAll = () => {
        const newSelectAll = !selectAll;
        setSelectAll(newSelectAll);
        const newSelectedItems = {};
        reportData.forEach(item => { newSelectedItems[item.id] = newSelectAll; });
        setSelectedItems(newSelectedItems);
    };

    const handleSelectItem = (id) => {
        setSelectedItems({ ...selectedItems, [id]: !selectedItems[id] });
    };

    const totals = reportData.reduce((acc, p) => ({
        completed: acc.completed + p.completed,
        target: acc.target + p.target,
    }), { completed: 0, target: 0 });

    const handleRowDownload = async (projectId, projectName) => {
        setRowDownloading(projectId);
        const result = await exportProjectLogs(projectId);
        setRowDownloading(null);
        if (!result.success) { alert("Error: " + result.error); return; }
        if (!result.data || result.data.length === 0) { alert("No tracking logs found for this project yet."); return; }
        const headers = ["Respondent UID", "Supplier", "Status", "Started At", "Completed At", "LOI (sec)", "Quality Score"];
        const rows = result.data.map(l => [l.respondent_uid, l.suppliers?.name || 'N/A', l.status, l.started_at, l.completed_at, l.loi_seconds, l.quality_score]);
        downloadCsv(headers, rows, `${projectName.replace(/[^a-z0-9]/gi, '_')}-logs`);
    };

    const handleDownloadSelected = () => {
        const selected = reportData.filter(p => selectedItems[p.id]);
        if (selected.length === 0) { alert("Select at least one project first."); return; }
        const headers = ["ProjectCode", "ProjectName", "Country", "Completed", "Target"];
        const rows = selected.map(p => [p.code, p.name, p.country, p.completed, p.target]);
        downloadCsv(headers, rows, `group-report-${groupBy}-${groupValue}`);
    };

    const downloadCsv = (headers, rows, filenamePrefix) => {
        const csvContent = [headers, ...rows]
            .map(row => row.map(cell => `"${String(cell ?? '').replace(/"/g, '""')}"`).join(","))
            .join("\n");
        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `${filenamePrefix}-${Date.now()}.csv`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    const groupByLabel = { client: 'Client Name', country: 'Country', category: 'Category (B2B/B2C)' };

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item">Report</li>
                            <li className="breadcrumb-item active">Group Project Report</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Group Project Report <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal'}}>(v2 — live data)</span></h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body prReportbox">
                        <form onSubmit={handleViewReport}>
                            <div className="row align-items-end mb-4">
                                <div className="col-sm-12 col-md-3 form-group mb-0">
                                    <label className="control-label">Group By</label>
                                    <select className="form-control" value={groupBy} onChange={(e) => { setGroupBy(e.target.value); setGroupValue(""); }}>
                                        <option value="client">Client</option>
                                        <option value="country">Country</option>
                                        <option value="category">Category</option>
                                    </select>
                                </div>
                                <div className="col-sm-12 col-md-5 form-group mb-0">
                                    <label className="control-label">{groupByLabel[groupBy]}<span className="text-danger">*</span></label>
                                    {groupBy === 'category' ? (
                                        <select className="form-control" value={groupValue} onChange={(e) => setGroupValue(e.target.value)} required>
                                            <option value="">-- Select Category --</option>
                                            <option value="B2C">B2C</option>
                                            <option value="B2B">B2B</option>
                                        </select>
                                    ) : (
                                        <div className="position-relative">
                                            <input
                                                type="text"
                                                className="form-control"
                                                placeholder={`Search ${groupByLabel[groupBy]}...`}
                                                value={groupValue}
                                                onChange={(e) => setGroupValue(e.target.value)}
                                                required
                                            />
                                            {groupValue && (
                                                <a className="clearCrossIcon" onClick={() => setGroupValue("")} style={{position: 'absolute', right: '10px', top: '10px', cursor: 'pointer', zIndex: 10}}>
                                                    <i className="fa fa-times-circle" aria-hidden="true"></i>
                                                </a>
                                            )}
                                        </div>
                                    )}
                                </div>
                                <div className="col-sm-12 col-md-4 form-group mb-0">
                                    <div className="d-flex gap-2" style={{gap: '10px'}}>
                                        <button className="btn btn-primary m-0" type="submit">View</button>
                                        <button className="btn btn-info m-0" type="button" disabled={!showReport} onClick={handleDownloadSelected}>Download Selected</button>
                                    </div>
                                </div>
                            </div>
                            <div className="row align-items-end mb-2">
                                <div className="col-sm-6 col-md-3 form-group mb-0">
                                    <label className="control-label">From <span style={{fontWeight:'normal', fontSize:'11px'}}>(optional)</span></label>
                                    <input type="date" className="form-control" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-3 form-group mb-0">
                                    <label className="control-label">To <span style={{fontWeight:'normal', fontSize:'11px'}}>(optional)</span></label>
                                    <input type="date" className="form-control" value={toDate} onChange={(e) => setToDate(e.target.value)} />
                                </div>
                            </div>
                        </form>

                        {loading && <p>Loading report...</p>}

                        {showReport && !loading && (
                            <div className="row mt-4">
                                <div className="col-md-12 col-lg-12">
                                    <div className="table-responsive tableScrollFix reportGrid">
                                        <table className="table table-striped fixTable">
                                            <thead>
                                                <tr>
                                                    <th style={{minWidth: "60px"}}>S.No.</th>
                                                    <th><input type="checkbox" checked={selectAll} onChange={handleSelectAll} /></th>
                                                    <th style={{minWidth: "100px"}}>ProjectCode</th>
                                                    <th style={{minWidth: "150px"}}>ProjectName</th>
                                                    <th style={{minWidth: "100px"}}>Country</th>
                                                    <th style={{minWidth: "100px"}}>Completed</th>
                                                    <th style={{minWidth: "100px"}}>Target</th>
                                                    <th style={{minWidth: "100px"}}>Download</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {reportData.length > 0 ? (
                                                    reportData.map((p, index) => (
                                                        <tr key={p.id}>
                                                            <td>{index + 1}</td>
                                                            <td>
                                                                <input type="checkbox" checked={!!selectedItems[p.id]} onChange={() => handleSelectItem(p.id)} />
                                                            </td>
                                                            <td>{p.code}</td>
                                                            <td><strong>{p.name}</strong></td>
                                                            <td>{p.country}</td>
                                                            <td>{p.completed}</td>
                                                            <td>{p.target}</td>
                                                            <td>
                                                                <button
                                                                    className="btn btn-sm btn-outline-primary"
                                                                    title="Download Project Report"
                                                                    onClick={() => handleRowDownload(p.id, p.name)}
                                                                    disabled={rowDownloading === p.id}
                                                                >
                                                                    {rowDownloading === p.id
                                                                        ? <i className="fa fa-spinner fa-spin" aria-hidden="true"></i>
                                                                        : <i className="fa fa-download" aria-hidden="true"></i>}
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    ))
                                                ) : (
                                                    <tr>
                                                        <td colSpan="8" className="text-center">No Record Found !</td>
                                                    </tr>
                                                )}
                                            </tbody>
                                            {reportData.length > 0 && (
                                                <tfoot>
                                                    <tr style={{fontWeight: 'bold', background: '#f8f9fa'}}>
                                                        <td colSpan="5" className="text-right">Group Total ({reportData.length} projects):</td>
                                                        <td>{totals.completed}</td>
                                                        <td>{totals.target}</td>
                                                        <td></td>
                                                    </tr>
                                                </tfoot>
                                            )}
                                        </table>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
