"use client";
import React, { useState } from 'react';
import Link from 'next/link';
import { getClientReport, exportProjectLogs } from '@/app/actions/reports';

export default function ClientReport() {
    const [clientSearch, setClientSearch] = useState("");
    const [fromDate, setFromDate] = useState("");
    const [toDate, setToDate] = useState("");
    const [showReport, setShowReport] = useState(false);
    const [reportData, setReportData] = useState([]);
    const [loading, setLoading] = useState(false);

    const handleViewReport = async (e) => {
        e.preventDefault();
        if (!clientSearch) {
            alert("Please select a client first.");
            return;
        }
        setLoading(true);
        const result = await getClientReport(clientSearch, fromDate, toDate);
        setLoading(false);
        if (result.success) {
            setReportData(result.data);
            setShowReport(true);
        } else {
            alert("Error loading report: " + result.error);
        }
    };

    const handleReset = () => {
        setClientSearch("");
        setFromDate("");
        setToDate("");
        setShowReport(false);
        setReportData([]);
    };

    const handleDownload = () => {
        if (reportData.length === 0) return;
        const headers = ["S.No.", "ProjectCode", "ProjectName", "Country", "Completed", "Target"];
        const rows = reportData.map((p, i) => [i + 1, p.code, p.name, p.country, p.completed, p.target]);
        const csvContent = [headers, ...rows]
            .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(","))
            .join("\n");
        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `client-report-${clientSearch}-${Date.now()}.csv`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    const [rowDownloading, setRowDownloading] = useState(null);

    const handleRowDownload = async (projectId, projectName) => {
        setRowDownloading(projectId);
        const result = await exportProjectLogs(projectId);
        setRowDownloading(null);
        if (!result.success) {
            alert("Error downloading project logs: " + result.error);
            return;
        }
        if (!result.data || result.data.length === 0) {
            alert("No tracking logs found for this project yet.");
            return;
        }
        const headers = ["Respondent UID", "Supplier", "Status", "Started At", "Completed At", "LOI (sec)", "Quality Score", "Is Duplicate", "Is Speeder", "IP Address"];
        const rows = result.data.map(l => [
            l.respondent_uid, l.suppliers?.name || 'N/A', l.status, l.started_at, l.completed_at,
            l.loi_seconds, l.quality_score, l.is_duplicate, l.is_speeder, l.ip_address
        ]);
        const csvContent = [headers, ...rows]
            .map(row => row.map(cell => `"${String(cell ?? '').replace(/"/g, '""')}"`).join(","))
            .join("\n");
        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `${projectName.replace(/[^a-z0-9]/gi, '_')}-logs-${Date.now()}.csv`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item">Report</li>
                            <li className="breadcrumb-item active">Client Report</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Client Report <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal'}}>(v2 — live data)</span></h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body prReportbox">
                        <form onSubmit={handleViewReport}>
                            <div className="row align-items-end mb-4">
                                <div className="col-sm-12 col-md-4 form-group mb-0">
                                    <label className="control-label">Client<span className="text-danger">*</span></label>
                                    <div className="position-relative">
                                        <input 
                                            type="text" 
                                            className="form-control" 
                                            placeholder="Search Client..." 
                                            value={clientSearch}
                                            onChange={(e) => setClientSearch(e.target.value)}
                                            required
                                        />
                                        {clientSearch && (
                                            <a 
                                                className="clearCrossIcon" 
                                                title="Clear" 
                                                onClick={() => setClientSearch("")}
                                                style={{position: 'absolute', right: '10px', top: '10px', cursor: 'pointer', zIndex: 10}}
                                            >
                                                <i className="fa fa-times-circle" aria-hidden="true"></i>
                                            </a>
                                        )}
                                    </div>
                                </div>
                                <div className="col-sm-12 col-md-8">
                                    <div className="row align-items-end">
                                        <div className="col-sm-6 col-md-3 form-group mb-0">
                                            <label className="control-label">From<span className="text-danger">*</span></label>
                                            <input 
                                                type="date" 
                                                className="form-control" 
                                                value={fromDate}
                                                onChange={(e) => setFromDate(e.target.value)}
                                                required 
                                            />
                                        </div>
                                        <div className="col-sm-6 col-md-3 form-group mb-0">
                                            <label className="control-label">To<span className="text-danger">*</span></label>
                                            <input 
                                                type="date" 
                                                className="form-control" 
                                                value={toDate}
                                                onChange={(e) => setToDate(e.target.value)}
                                                required 
                                            />
                                        </div>
                                        <div className="col-sm-12 col-md-6 form-group mb-0">
                                            <div className="d-flex gap-2" style={{gap: '10px'}}>
                                                <button className="btn btn-primary m-0" type="submit">View</button>
                                                <button className="btn btn-info m-0" type="button" disabled={!showReport} onClick={handleDownload}>Download</button>
                                                <button className="btn btn-secondary m-0" type="button" onClick={handleReset}>Reset</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                        {loading && <p>Loading report...</p>}

                        {showReport && !loading && (
                            <div className="row mt-4">
                                <div className="col-md-12 col-lg-12">
                                    <div className="table-responsive tableScrollFix reportGrid">
                                        <table className="table table-striped fixTable">
                                            <thead>
                                                <tr>
                                                    <th>S.No.</th>
                                                    <th style={{minWidth: "130px"}}>ProjectCode</th>
                                                    <th style={{minWidth: "130px"}}>ProjectName</th>
                                                    <th style={{minWidth: "130px"}}>Country</th>
                                                    <th style={{minWidth: "130px"}}>Completed</th>
                                                    <th style={{minWidth: "130px"}}>Target</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {reportData.length > 0 ? (
                                                    reportData.map((p, index) => (
                                                        <tr key={p.id}>
                                                            <td>{index + 1}</td>
                                                            <td>{p.code}</td>
                                                            <td><strong>{p.name}</strong></td>
                                                            <td>{p.country}</td>
                                                            <td>{p.completed}</td>
                                                            <td>{p.target}</td>
                                                            <td>
                                                                <button
                                                                    className="btn btn-sm btn-outline-primary"
                                                                    title="Download Project Report"
                                                                    onClick={() => handleRowDownload(p.id, p.name)}
                                                                    disabled={rowDownloading === p.id}
                                                                >
                                                                    {rowDownloading === p.id
                                                                        ? <i className="fa fa-spinner fa-spin" aria-hidden="true"></i>
                                                                        : <i className="fa fa-download" aria-hidden="true"></i>}
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    ))
                                                ) : (
                                                    <tr>
                                                        <td colSpan="7" className="text-center">No Record Found !</td>
                                                    </tr>
                                                )}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
