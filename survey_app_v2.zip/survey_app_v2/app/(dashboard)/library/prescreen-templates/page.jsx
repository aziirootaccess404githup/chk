"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { getTemplates, createTemplate, updateTemplateQuestions, deleteTemplate, getTemplateQuestionDetails } from '@/app/actions/prescreenTemplates';
import { getQuestions } from '@/app/actions/questionLibrary';

export default function PreScreenTemplateLibrary() {
    const [searchTerm, setSearchTerm] = useState("");
    const [newTemplate, setNewTemplate] = useState("");
    const [templates, setTemplates] = useState([]);
    const [allQuestions, setAllQuestions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedQuestionIds, setSelectedQuestionIds] = useState([]);
    const [editingTemplate, setEditingTemplate] = useState(null); // template being edited, or null
    const [viewingTemplate, setViewingTemplate] = useState(null); // { name, questions: [...] }

    async function fetchTemplates(term) {
        setLoading(true);
        const result = await getTemplates(term || "");
        if (result.success) setTemplates(result.data);
        setLoading(false);
    }

    useEffect(() => {
        fetchTemplates("");
        getQuestions("").then(res => { if (res.success) setAllQuestions(res.data); });
    }, []);

    useEffect(() => {
        const timer = setTimeout(() => fetchTemplates(searchTerm), 300);
        return () => clearTimeout(timer);
    }, [searchTerm]);

    const toggleQuestionSelect = (id) => {
        setSelectedQuestionIds(prev => prev.includes(id) ? prev.filter(q => q !== id) : [...prev, id]);
    };

    const handleAddTemplate = async () => {
        if (!newTemplate.trim()) return;
        if (editingTemplate) {
            const result = await updateTemplateQuestions(editingTemplate.id, selectedQuestionIds);
            if (result.success) {
                alert("Template updated!");
                setEditingTemplate(null);
                setNewTemplate("");
                setSelectedQuestionIds([]);
                fetchTemplates(searchTerm);
            } else {
                alert("Error: " + result.error);
            }
        } else {
            const result = await createTemplate(newTemplate.trim(), selectedQuestionIds);
            if (result.success) {
                setNewTemplate("");
                setSelectedQuestionIds([]);
                fetchTemplates(searchTerm);
            } else {
                alert("Error: " + result.error);
            }
        }
    };

    const handleEditClick = (template) => {
        setEditingTemplate(template);
        setNewTemplate(template.name);
        setSelectedQuestionIds(template.question_ids || []);
    };

    const handleCancelEdit = () => {
        setEditingTemplate(null);
        setNewTemplate("");
        setSelectedQuestionIds([]);
    };

    const handleView = async (template) => {
        const result = await getTemplateQuestionDetails(template.question_ids || []);
        if (result.success) {
            setViewingTemplate({ name: template.name, questions: result.data });
        }
    };

    const handleDelete = async (id, name) => {
        if (!confirm(`Delete template "${name}"?`)) return;
        const result = await deleteTemplate(id);
        if (result.success) {
            fetchTemplates(searchTerm);
        } else {
            alert("Error: " + result.error);
        }
    };

    return (
        <div className="tabPanelWraps mt-211">
            <div className="row">
                <div className="col-12">
                    <div className="page-title-box">
                        <div className="page-title-right">
                            <ol className="breadcrumb m-0">
                                <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                                <li className="breadcrumb-item">Library</li>
                                <li className="breadcrumb-item active">PreScreenTemplate</li>
                            </ol>
                        </div>
                        <h4 className="page-title tb-ttl">PreScreen Template List <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal'}}>(v2 — live data)</span></h4>
                    </div>
                </div>
            </div>

            <div className="row mt-4">
                <div className="col-sm-12">
                    <div className="card">
                        <div className="card-body">
                            <div className="row mb-3 align-items-end">
                                <div className="col-sm-6 col-md-6 col-lg-4">
                                    <label className="mb-0 mr-2">{editingTemplate ? `Editing: ${editingTemplate.name}` : 'PreScreen Template Name:'}</label>
                                    <div className="d-flex">
                                        <input
                                            type="text"
                                            className="form-control mr-2"
                                            value={newTemplate}
                                            onChange={(e) => setNewTemplate(e.target.value)}
                                            style={{minHeight: "36px"}}
                                            disabled={!!editingTemplate}
                                        />
                                        <button className="btn btn-primary" onClick={handleAddTemplate} style={{minWidth: "65px"}}>
                                            {editingTemplate ? 'Update' : 'Add'}
                                        </button>
                                        {editingTemplate && (
                                            <button className="btn btn-outline-secondary ml-2" onClick={handleCancelEdit}>Cancel</button>
                                        )}
                                    </div>
                                </div>
                                <div className="col-sm-6 col-md-6 col-lg-8">
                                    <label className="mb-0">Select Questions for this template:</label>
                                    <div style={{maxHeight: '150px', overflowY: 'auto', border: '1px solid #ced4da', borderRadius: '4px', padding: '8px'}}>
                                        {allQuestions.length === 0 ? (
                                            <small className="text-muted">No questions in the Question Library yet — add some first.</small>
                                        ) : (
                                            allQuestions.map(q => (
                                                <div key={q.id} className="form-check">
                                                    <input
                                                        type="checkbox"
                                                        className="form-check-input"
                                                        checked={selectedQuestionIds.includes(q.id)}
                                                        onChange={() => toggleQuestionSelect(q.id)}
                                                    />
                                                    <label className="form-check-label">{q.title} — {q.question_text}</label>
                                                </div>
                                            ))
                                        )}
                                    </div>
                                </div>
                            </div>

                            <div className="row mb-4 align-items-center">
                                <div className="col-sm-6 col-md-6 col-lg-3">
                                    <div className="pagesize">
                                        <label className="mr-2">Page Size:</label>
                                        <select className="form-control d-inline-block w-auto">
                                            <option value="10">10</option>
                                            <option value="30">30</option>
                                            <option value="50">50</option>
                                            <option value="100">100</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="col-sm-12 col-md-12 col-lg-9">
                                    <div className="app-search-box" style={{maxWidth: '300px', marginLeft: 'auto'}}>
                                        <div className="input-group">
                                            <input
                                                type="text"
                                                className="form-control"
                                                placeholder="Search Templates..."
                                                value={searchTerm}
                                                onChange={(e) => setSearchTerm(e.target.value)}
                                            />
                                            {searchTerm && (
                                                <a className="clearCrossIcon" onClick={() => setSearchTerm("")} style={{cursor: 'pointer'}}>
                                                    <i className="fa fa-times-circle" aria-hidden="true"></i>
                                                </a>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {viewingTemplate && (
                                <div className="alert alert-info">
                                    <strong>{viewingTemplate.name}</strong> — {viewingTemplate.questions.length} question(s):
                                    <ul className="mb-0 mt-2">
                                        {viewingTemplate.questions.map(q => <li key={q.id}>{q.title}: {q.question_text}</li>)}
                                        {viewingTemplate.questions.length === 0 && <li>No questions assigned yet.</li>}
                                    </ul>
                                    <button className="btn btn-sm btn-outline-secondary mt-2" onClick={() => setViewingTemplate(null)}>Close</button>
                                </div>
                            )}

                            <div className="responsive-table-plugin">
                                <div className="table-responsive table-scroll-fixed">
                                    <table className="table table-striped">
                                        <thead>
                                            <tr>
                                                <th style={{minWidth: "50px", maxWidth: "100px"}}>S.No</th>
                                                <th style={{minWidth: "200px", maxWidth: "250px", textAlign: "left"}}>TemplateName</th>
                                                <th style={{minWidth: "150px", maxWidth: "200px"}}>No.of Questions</th>
                                                <th style={{minWidth: "150px", maxWidth: "200px"}}>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {loading ? (
                                                <tr><td colSpan="4" className="text-center">Loading...</td></tr>
                                            ) : templates.length > 0 ? (
                                                templates.map((template, index) => (
                                                    <tr key={template.id}>
                                                        <td>{index + 1}</td>
                                                        <td style={{textAlign: "left", paddingLeft: "10px"}}><strong>{template.name}</strong></td>
                                                        <td><span className="badge badge-secondary">{(template.question_ids || []).length}</span></td>
                                                        <td>
                                                            <button className="btn btn-sm btn-info mr-1" title="View" onClick={() => handleView(template)}><i className="fas fa-eye"></i></button>
                                                            <button className="btn btn-sm btn-primary mr-1" title="Edit" onClick={() => handleEditClick(template)}><i className="fas fa-edit"></i></button>
                                                            <button className="btn btn-sm btn-danger" title="Delete" onClick={() => handleDelete(template.id, template.name)}><i className="fas fa-trash"></i></button>
                                                        </td>
                                                    </tr>
                                                ))
                                            ) : (
                                                <tr><td colSpan="4" className="text-center">No Record Found !</td></tr>
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
