"use client";
import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { getQuestions, addQuestion, updateQuestion, deleteQuestion } from '@/app/actions/questionLibrary';

export default function QuestionLibrary() {
    const [searchTerm, setSearchTerm] = useState("");
    const [options, setOptions] = useState([]);
    const [newOption, setNewOption] = useState("");
    const [questions, setQuestions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [editingQuestion, setEditingQuestion] = useState(null); // null = Add mode, else Edit mode
    const formRef = useRef(null);
    const formCardRef = useRef(null);

    async function fetchQuestions(term) {
        setLoading(true);
        const result = await getQuestions(term || "");
        if (result.success) setQuestions(result.data);
        setLoading(false);
    }

    useEffect(() => {
        fetchQuestions("");
    }, []);

    useEffect(() => {
        const timer = setTimeout(() => fetchQuestions(searchTerm), 300);
        return () => clearTimeout(timer);
    }, [searchTerm]);

    const handleAddOption = () => {
        if (newOption.trim()) {
            setOptions([...options, newOption.trim()]);
            setNewOption("");
        }
    };

    const handleRemoveOption = (indexToRemove) => {
        setOptions(options.filter((_, index) => index !== indexToRemove));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSaving(true);
        const formData = new FormData(e.target);
        formData.set('options', JSON.stringify(options));

        const result = editingQuestion
            ? await updateQuestion(editingQuestion.id, formData)
            : await addQuestion(formData);

        setSaving(false);
        if (result.success) {
            alert(editingQuestion ? "Question updated!" : "Question saved!");
            e.target.reset();
            setOptions([]);
            setEditingQuestion(null);
            fetchQuestions(searchTerm);
        } else {
            alert("Error saving question: " + result.error);
        }
    };

    const handleEditClick = (q) => {
        setEditingQuestion(q);
        setOptions(Array.isArray(q.options) ? q.options : []);
        // Pre-fill the form fields on next render
        setTimeout(() => {
            if (formRef.current) {
                formRef.current.country.value = q.country || "";
                formRef.current.language.value = q.language || "";
                formRef.current.control_type.value = q.control_type || "";
                formRef.current.title.value = q.title || "";
                formRef.current.category.value = q.category || "";
                formRef.current.question_text.value = q.question_text || "";
                formRef.current.min_length.value = q.min_length ?? "";
                formRef.current.max_length.value = q.max_length ?? "";
                formRef.current.text_type.value = q.text_type || "";
            }
            formCardRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 0);
    };

    const handleCancelEdit = () => {
        setEditingQuestion(null);
        setOptions([]);
        formRef.current?.reset();
    };

    const handleDelete = async (id, title) => {
        if (!confirm(`Delete question "${title}"?`)) return;
        const result = await deleteQuestion(id);
        if (result.success) {
            if (editingQuestion?.id === id) handleCancelEdit();
            fetchQuestions(searchTerm);
        } else {
            alert("Error deleting: " + result.error);
        }
    };

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item">Library</li>
                            <li className="breadcrumb-item active">Question</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Question Library <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal'}}>(v2 — live data)</span></h4>
                </div>
            </div>

            <div className="col-sm-12 mb-4" ref={formCardRef}>
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <div className="d-flex justify-content-between align-items-center mb-3">
                            <h5 className="mb-0">{editingQuestion ? `Editing: ${editingQuestion.title}` : 'Add New Question'}</h5>
                            {editingQuestion && (
                                <button type="button" className="btn btn-sm btn-outline-secondary" onClick={handleCancelEdit}>
                                    Cancel Edit
                                </button>
                            )}
                        </div>
                        <form className="form-horizontal" onSubmit={handleSubmit} ref={formRef}>
                            <div className="row">
                                <div className="col-sm-4 col-md-4 col-12 form-group">
                                    <label className="control-label">Country<span className="text-danger">*</span></label>
                                    <select name="country" className="form-control" required>
                                        <option value="">-- Select Country --</option>
                                        <option value="US">United States</option>
                                        <option value="UK">United Kingdom</option>
                                        <option value="IN">India</option>
                                    </select>
                                </div>
                                <div className="col-sm-4 col-md-4 col-12 form-group">
                                    <label className="control-label">Language<span className="text-danger">*</span></label>
                                    <select name="language" className="form-control" required>
                                        <option value="">-- Select Language --</option>
                                        <option value="en">English</option>
                                        <option value="es">Spanish</option>
                                        <option value="fr">French</option>
                                    </select>
                                </div>
                                <div className="col-sm-4 col-md-4 col-12 form-group">
                                    <label className="control-label">Control Type <span className="text-danger">*</span></label>
                                    <select name="control_type" className="form-control" required>
                                        <option value="">-- Select Control --</option>
                                        <option value="Text">Text</option>
                                        <option value="Radio">Radio</option>
                                        <option value="Dropdown">Dropdown</option>
                                        <option value="Checkbox">Checkbox</option>
                                    </select>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-sm-4 col-md-4 col-12 form-group">
                                    <label className="control-label">Title<span className="text-danger">*</span></label>
                                    <input name="title" type="text" className="form-control" required />
                                </div>
                                <div className="col-sm-4 col-md-4 col-12 form-group">
                                    <label className="control-label">Category</label>
                                    <input name="category" type="text" className="form-control" placeholder="e.g. Demographics" />
                                </div>
                                <div className="col-sm-4 col-md-4 col-12 form-group">
                                    <label className="control-label">Question<span className="text-danger">*</span></label>
                                    <input name="question_text" type="text" className="form-control" required />
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-sm-4 col-md-4 col-12 form-group">
                                    <label className="control-label">Min-Length</label>
                                    <input name="min_length" type="number" className="form-control" min="0" />
                                </div>
                                <div className="col-sm-4 col-md-4 col-12 form-group">
                                    <label className="control-label">Max-Length</label>
                                    <input name="max_length" type="number" className="form-control" min="0" />
                                </div>
                                <div className="col-sm-4 col-md-4 col-12 form-group">
                                    <label className="control-label">Text Type</label>
                                    <select name="text_type" className="form-control">
                                        <option value="">-- Select Type --</option>
                                        <option value="Email">Email</option>
                                        <option value="ContactNo">ContactNo</option>
                                        <option value="ZipCode">ZipCode</option>
                                        <option value="Custom">Custom</option>
                                    </select>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-sm-6 col-md-6 form-group">
                                    <label className="control-label">Add Option</label>
                                    <textarea
                                        rows="4"
                                        className="form-control"
                                        value={newOption}
                                        onChange={(e) => setNewOption(e.target.value)}
                                        placeholder="Type an option here..."
                                    ></textarea>
                                    <div className="text-right mt-2">
                                        <button type="button" className="btn btn-secondary" onClick={handleAddOption}>Add to List</button>
                                    </div>
                                </div>
                                <div className="col-sm-6 col-md-6 form-group">
                                    <label className="control-label">Mapped Options</label>
                                    <select className="form-control" multiple style={{height: "115px"}}>
                                        {options.map((opt, idx) => (
                                            <option key={idx} onDoubleClick={() => handleRemoveOption(idx)}>{opt}</option>
                                        ))}
                                    </select>
                                    <small className="text-muted">Double click any option to remove it</small>
                                </div>
                            </div>

                            <div className="row mt-3">
                                <div className="col-sm-12 text-right">
                                    <button type="submit" className="btn btn-primary mr-2" disabled={saving}>
                                        {saving ? 'Saving...' : (editingQuestion ? 'Update Question' : 'Save Question')}
                                    </button>
                                    <button type="button" className="btn btn-outline-secondary" onClick={handleCancelEdit}>
                                        {editingQuestion ? 'Cancel' : 'Clear'}
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card">
                    <div className="card-body">
                        <div className="row mb-3 justify-content-end">
                            <div className="col-md-4 col-sm-12">
                                <div className="app-search-box">
                                    <div className="input-group">
                                        <input
                                            type="text"
                                            className="form-control"
                                            placeholder="Search Questions..."
                                            value={searchTerm}
                                            onChange={(e) => setSearchTerm(e.target.value)}
                                        />
                                        {searchTerm && (
                                            <a className="clearCrossIcon" onClick={() => setSearchTerm("")} style={{cursor: 'pointer'}}>
                                                <i className="fa fa-times-circle" aria-hidden="true"></i>
                                            </a>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="responsive-table-plugin">
                            <div className="table-responsive">
                                <table className="table table-striped">
                                    <thead>
                                        <tr>
                                            <th style={{minWidth: "40px", maxWidth: "40px"}}>S.No.</th>
                                            <th>Question Title</th>
                                            <th>Question Description</th>
                                            <th>Category</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {loading ? (
                                            <tr><td colSpan="5" className="text-center">Loading...</td></tr>
                                        ) : questions.length > 0 ? (
                                            questions.map((q, index) => (
                                                <tr key={q.id} style={editingQuestion?.id === q.id ? {background: '#fff8e1'} : {}}>
                                                    <td>{index + 1}</td>
                                                    <td><strong>{q.title}</strong></td>
                                                    <td>{q.question_text}</td>
                                                    <td>{q.category ? <span className="badge badge-info">{q.category}</span> : '-'}</td>
                                                    <td>
                                                        <button className="btn btn-sm btn-primary mr-1" onClick={() => handleEditClick(q)}>
                                                            <i className="fa fa-edit"></i> Edit
                                                        </button>
                                                        <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(q.id, q.title)}>
                                                            <i className="fa fa-trash"></i> Delete
                                                        </button>
                                                    </td>
                                                </tr>
                                            ))
                                        ) : (
                                            <tr><td colSpan="5" className="text-center">No Record Found !</td></tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
