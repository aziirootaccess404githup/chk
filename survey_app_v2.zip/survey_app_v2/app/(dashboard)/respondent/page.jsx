"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { getRespondentDetail } from '@/app/actions/respondentDetail';

function calcQualityBreakdown(lead) {
    let score = 100;
    const reasons = [];
    const loi = lead.loi_seconds;

    if (loi !== null && loi !== undefined && loi > 0 && loi < 180) {
        score -= 40;
        reasons.push(`⚡ Speeder (LOI: ${Math.floor(loi / 60)}m ${loi % 60}s)`);
    } else if (loi === null || loi === undefined) {
        score -= 10;
        reasons.push('⏱ LOI not recorded');
    }
    if (lead.is_duplicate) { score -= 30; reasons.push('⚠️ Duplicate UID'); }
    if (lead.same_ip_flag) { score -= 20; reasons.push('🌐 Same IP as another respondent'); }
    if (!lead.device || lead.device === 'Unknown') { score -= 5; reasons.push('📱 Device unknown'); }
    if (!lead.country || lead.country === 'Unknown') { score -= 5; reasons.push('🌍 Country unknown'); }

    return { score: Math.max(0, Math.min(100, score)), reasons };
}

export default function RespondentDetailPage() {
    const searchParams = useSearchParams();
    const uid = searchParams.get('uid');
    const pid = searchParams.get('pid');
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function load() {
            setLoading(true);
            const result = await getRespondentDetail(uid, pid);
            if (result.success) setData(result.data);
            setLoading(false);
        }
        if (uid) load();
    }, [uid, pid]);

    if (!uid) return <div className="row"><div className="col-12"><p>No UID specified.</p></div></div>;
    if (loading) return <div className="row"><div className="col-12"><p>Loading...</p></div></div>;
    if (!data?.lead) return <div className="row"><div className="col-12"><p>No session record found for UID: {uid}</p></div></div>;

    const { lead, answers } = data;
    const { score, reasons } = calcQualityBreakdown(lead);
    const scoreColor = score >= 80 ? '#28a745' : score >= 60 ? '#f59e0b' : '#ef4444';

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item active">Respondent Details</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Respondent — {uid}</h4>
                </div>
            </div>

            <div className="col-sm-12 mb-3">
                <div className="card">
                    <div className="card-body">
                        <h5 className="mb-3">Session Details</h5>
                        <div className="row">
                            <div className="col-md-3 mb-2"><div className="text-muted" style={{fontSize: '11px'}}>Project</div><div>{lead.projects?.title || '-'}</div></div>
                            <div className="col-md-3 mb-2"><div className="text-muted" style={{fontSize: '11px'}}>Supplier</div><div>{lead.suppliers?.name || '-'}</div></div>
                            <div className="col-md-3 mb-2"><div className="text-muted" style={{fontSize: '11px'}}>Status</div>
                                <span className={`badge ${lead.status === 'Complete' ? 'badge-success' : 'badge-secondary'}`}>{lead.status}</span>
                            </div>
                            <div className="col-md-3 mb-2"><div className="text-muted" style={{fontSize: '11px'}}>LOI</div><div>{lead.loi_seconds ? `${Math.floor(lead.loi_seconds/60)}m ${lead.loi_seconds%60}s` : '-'}</div></div>
                            <div className="col-md-3 mb-2"><div className="text-muted" style={{fontSize: '11px'}}>Country</div><div>{lead.country || '-'}</div></div>
                            <div className="col-md-3 mb-2"><div className="text-muted" style={{fontSize: '11px'}}>City</div><div>{lead.city || '-'}</div></div>
                            <div className="col-md-3 mb-2"><div className="text-muted" style={{fontSize: '11px'}}>Device</div><div>{lead.device || '-'}</div></div>
                            <div className="col-md-3 mb-2"><div className="text-muted" style={{fontSize: '11px'}}>Browser</div><div>{lead.browser || '-'}</div></div>
                            <div className="col-md-3 mb-2"><div className="text-muted" style={{fontSize: '11px'}}>IP Address</div><div>{lead.ip_address || '-'}</div></div>
                            <div className="col-md-3 mb-2"><div className="text-muted" style={{fontSize: '11px'}}>Duplicate?</div><div>{lead.is_duplicate ? '⚠️ Yes' : '✓ No'}</div></div>
                            <div className="col-md-3 mb-2"><div className="text-muted" style={{fontSize: '11px'}}>Started</div><div>{lead.started_at ? new Date(lead.started_at).toLocaleString() : '-'}</div></div>
                            <div className="col-md-3 mb-2"><div className="text-muted" style={{fontSize: '11px'}}>Completed</div><div>{lead.completed_at ? new Date(lead.completed_at).toLocaleString() : '-'}</div></div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="col-sm-12 mb-3">
                <div className="card">
                    <div className="card-body">
                        <h5 className="mb-3">Quality Score Breakdown</h5>
                        <h2 style={{color: scoreColor}}>{score}<small className="text-muted" style={{fontSize: '16px'}}>/100</small></h2>
                        <div style={{background: '#eee', borderRadius: '8px', height: '12px', overflow: 'hidden', marginBottom: '10px'}}>
                            <div style={{width: `${score}%`, background: scoreColor, height: '100%'}}></div>
                        </div>
                        {reasons.length === 0 ? (
                            <div style={{color: '#15803d'}}>✅ No quality issues detected.</div>
                        ) : (
                            reasons.map((r, i) => (
                                <span key={i} className="badge badge-light mr-2" style={{border: '1px solid #ddd', padding: '6px 10px', marginRight: '6px'}}>{r}</span>
                            ))
                        )}
                    </div>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card">
                    <div className="card-body">
                        <h5 className="mb-3">Pre-Survey (Screener) Answers</h5>
                        <div className="table-responsive">
                            <table className="table table-sm table-striped">
                                <thead><tr><th>Question</th><th>Answer</th><th>Captured At</th></tr></thead>
                                <tbody>
                                    {answers.length > 0 ? answers.map((a, i) => (
                                        <tr key={i}>
                                            <td>{a.question_text}</td>
                                            <td><strong>{a.answer}</strong></td>
                                            <td className="text-muted">{new Date(a.created_at).toLocaleString()}</td>
                                        </tr>
                                    )) : (
                                        <tr><td colSpan="3" className="text-center text-muted">No pre-survey answers captured for this respondent.</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
