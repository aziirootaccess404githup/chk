"use client";
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { createProject, getProjects } from '@/app/actions/projects';
import { getClients } from '@/app/actions/clients';
import { countries } from '@/utils/countries';

export default function ReContactProject() {
    const router = useRouter();
    const [clients, setClients] = useState([]);
    const [projects, setProjects] = useState([]);
    const [clientId, setClientId] = useState('');
    const [parentProjectId, setParentProjectId] = useState('');
    const [title, setTitle] = useState('');
    const [projectManager, setProjectManager] = useState('');
    const [country, setCountry] = useState('');
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        async function fetchData() {
            const [clientRes, projRes] = await Promise.all([getClients(), getProjects()]);
            if (clientRes.success) setClients(clientRes.data);
            if (projRes.success) setProjects(projRes.data);
        }
        fetchData();
    }, []);

    async function handleSubmit(e) {
        e.preventDefault();
        if (!clientId || !parentProjectId || !title || !projectManager || !country) {
            alert("Please fill in all required fields.");
            return;
        }
        setSaving(true);
        const formData = new FormData();
        formData.append('title', title);
        formData.append('client_id', clientId);
        formData.append('project_manager', projectManager);
        formData.append('country', country);
        formData.append('parent_id', parentProjectId);
        formData.append('status', 'Draft');

        const result = await createProject(formData);
        setSaving(false);
        if (result.success) {
            alert('ReContact project created successfully!');
            router.push(`/projects/${result.data.id}`);
        } else {
            alert('Error: ' + result.error);
        }
    }

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><a href="/">Home</a></li>
                            <li className="breadcrumb-item">Projects</li>
                            <li className="breadcrumb-item active">ReContact Project</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">ReContact Project <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal'}}>(v2 — live data)</span></h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <p className="text-muted">Creates a new project linked to a parent project (for following up with the same respondent base).</p>
                        <form onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Client<span className="text-danger">*</span></label>
                                    <select className="form-control" value={clientId} onChange={(e) => setClientId(e.target.value)} required>
                                        <option value="">-- Select Client --</option>
                                        {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Parent Project<span className="text-danger">*</span></label>
                                    <select className="form-control" value={parentProjectId} onChange={(e) => setParentProjectId(e.target.value)} required>
                                        <option value="">-- Select Parent Project --</option>
                                        {projects.map(p => <option key={p.id} value={p.id}>{p.title}</option>)}
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">ReContact Project Name<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="text" value={title} onChange={(e) => setTitle(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Project Manager<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="text" value={projectManager} onChange={(e) => setProjectManager(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Project Country<span className="text-danger">*</span></label>
                                    <select className="form-control" value={country} onChange={(e) => setCountry(e.target.value)} required>
                                        <option value="">-- Select Country --</option>
                                        {countries.map(c => <option key={c.code} value={c.code}>{c.name}</option>)}
                                    </select>
                                </div>
                            </div>

                            <hr />
                            <div className="row mt-4">
                                <div className="col-12 text-right">
                                    <button type="submit" className="btn btn-primary mr-2" disabled={saving}>
                                        {saving ? 'Creating...' : 'Create ReContact Project'}
                                    </button>
                                    <button type="button" className="btn btn-secondary" onClick={() => router.back()}>Cancel</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}
