"use client";
import React, { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { createProject, getProjectById } from '@/app/actions/projects';
import { getClients } from '@/app/actions/clients';
import { countries } from '@/utils/countries';

function ChildProjectContent() {
    const [clients, setClients] = useState([]);
    const [loading, setLoading] = useState(false);
    const [parentProject, setParentProject] = useState(null);
    
    // Form fields
    const [title, setTitle] = useState('');
    const [clientId, setClientId] = useState('');
    const [projectManager, setProjectManager] = useState('');
    const [countryId, setCountryId] = useState('');
    const [languageId, setLanguageId] = useState('');
    const [categoryId, setCategoryId] = useState('');
    const [description, setDescription] = useState('');
    const [loi, setLoi] = useState('');
    const [ir, setIr] = useState('');
    const [sampleSize, setSampleSize] = useState(0);
    const [clickQuota, setClickQuota] = useState(0);
    const [currency, setCurrency] = useState('USD');
    const [projectCpi, setProjectCpi] = useState('');
    const [supplierCpi, setSupplierCpi] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [status, setStatus] = useState('Draft');
    const [clientLink, setClientLink] = useState('');

    const [completeUrl, setCompleteUrl] = useState('');
    const [terminateUrl, setTerminateUrl] = useState('');
    const [quotaUrl, setQuotaUrl] = useState('');
    const [qualityUrl, setQualityUrl] = useState('');

    const router = useRouter();
    const searchParams = useSearchParams();
    const parent_id = searchParams.get('parent_id');

    useEffect(() => {
        async function fetchData() {
            const clientRes = await getClients();
            if (clientRes.success) setClients(clientRes.data);

            if (parent_id) {
                const projRes = await getProjectById(parent_id);
                if (projRes.success && projRes.data) {
                    const p = projRes.data;
                    setParentProject(p);
                    setClientId(p.client_id || '');
                    setProjectManager(p.project_manager || '');
                    setCountryId(p.country || '');
                    setLanguageId(p.language || '');
                    setCategoryId(p.category || '');
                    setDescription(p.description || '');
                    setLoi(p.loi || '');
                    setIr(p.ir || '');
                    setSampleSize(p.sample_size || 0);
                    setClickQuota(p.quota || 0);
                    setCurrency(p.currency || 'USD');
                    setProjectCpi(p.cpi || '');
                    setSupplierCpi(p.supplier_cpi || '');
                    if (p.start_date) setStartDate(p.start_date.substring(0, 10));
                    if (p.end_date) setEndDate(p.end_date.substring(0, 10));
                    setStatus(p.status || 'Draft');
                    setClientLink(p.client_link || '');
                    setCompleteUrl(p.client_complete_url || '');
                    setTerminateUrl(p.client_terminate_url || '');
                    setQuotaUrl(p.client_quota_url || '');
                    setQualityUrl(p.client_quality_url || '');
                }
            }
        }
        fetchData();
    }, [parent_id]);

    async function handleSubmit(e) {
        e.preventDefault();
        setLoading(true);
        const formData = new FormData(e.target);
        
        const actionData = new FormData();
        actionData.append('title', formData.get('ProjectName'));
        actionData.append('client_id', formData.get('ClientId'));
        actionData.append('status', formData.get('Status'));
        actionData.append('client_link', formData.get('ClientLink'));
        actionData.append('project_manager', formData.get('ProjectManager'));
        actionData.append('country', formData.get('CountryId'));
        actionData.append('language', formData.get('LanguageId'));
        actionData.append('category', formData.get('CategoryId'));
        actionData.append('description', formData.get('ProjectDescription'));
        actionData.append('loi', formData.get('LOI'));
        actionData.append('ir', formData.get('IR'));
        actionData.append('sample_size', formData.get('SampleSize'));
        actionData.append('quota', formData.get('ClickQuota'));
        actionData.append('currency', formData.get('Currency'));
        actionData.append('cpi', formData.get('ProjectCPI'));
        actionData.append('supplier_cpi', formData.get('SupplierCPI'));
        actionData.append('start_date', formData.get('StartDate'));
        actionData.append('end_date', formData.get('EndDate'));
        actionData.append('client_complete_url', formData.get('ClientCompleteUrl'));
        actionData.append('client_terminate_url', formData.get('ClientTerminateUrl'));
        actionData.append('client_quota_url', formData.get('ClientQuotaUrl'));
        actionData.append('client_quality_url', formData.get('ClientQualityUrl'));
        
        if (parent_id) {
            actionData.append('parent_id', parent_id);
        }

        const result = await createProject(actionData);
        if (result.success) {
            alert('Child Project created successfully!');
            router.push('/projects');
        } else {
            alert('Error: ' + result.error);
        }
        setLoading(false);
    }
    
    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><a href="/">Home</a></li>
                            <li className="breadcrumb-item">Projects</li>
                            <li className="breadcrumb-item active">Add Child Project</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Add Child Project</h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <form id="add_client_form_ChildProject" name="ChildProjectForm" onSubmit={handleSubmit}>
                            <div className="row">
                                {parentProject && (
                                    <div className="col-sm-12 col-md-12 form-group">
                                        <label className="control-label">Group Project</label>
                                        <input className="form-control" type="text" readOnly value={`PRJ-${parentProject.id.substring(0,4)} | ${parentProject.title}`} />
                                    </div>
                                )}
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="ClientId">Client Name<span className="text-danger">*</span></label>
                                    <select 
                                        className="form-control" 
                                        name="ClientId" 
                                        id="ClientId" 
                                        required
                                        value={clientId}
                                        onChange={(e) => {
                                            setClientId(e.target.value);
                                            const selectedClient = clients.find(c => String(c.id) === String(e.target.value));
                                            if (selectedClient) {
                                                setCompleteUrl(selectedClient.complete_url || '');
                                                setTerminateUrl(selectedClient.terminate_url || '');
                                                setQuotaUrl(selectedClient.quotafull_url || '');
                                                setQualityUrl(selectedClient.quality_url || '');
                                            }
                                        }}
                                    >
                                        <option value="">-- Select Client Name --</option>
                                        {clients.map(client => (
                                            <option key={client.id} value={client.id}>{client.name}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="ProjectName">Project Name<span className="text-danger">*</span></label>
                                    <input className="form-control" name="ProjectName" id="ProjectName" required type="text" value={title} onChange={e => setTitle(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="ProjectManager">Project Manager<span className="text-danger">*</span></label>
                                    <input className="form-control" name="ProjectManager" id="ProjectManager" required type="text" value={projectManager} onChange={e => setProjectManager(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="CountryId">Project Country<span className="text-danger">*</span></label>
                                    <select className="form-control" name="CountryId" id="CountryId" required value={countryId} onChange={e => setCountryId(e.target.value)}>
                                        <option value="">-- Select Country --</option>
                                        {countries.map(c => (
                                            <option key={c.code} value={c.code}>{c.name}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="LanguageId">Project Language<span className="text-danger">*</span></label>
                                    <select className="form-control" name="LanguageId" id="LanguageId" required value={languageId} onChange={e => setLanguageId(e.target.value)}>
                                        <option value="">-- Select Language --</option>
                                        <option value="EN">English</option>
                                        <option value="ES">Spanish</option>
                                        <option value="FR">French</option>
                                        <option value="DE">German</option>
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="CategoryId">Project Category<span className="text-danger">*</span></label>
                                    <select className="form-control" name="CategoryId" id="CategoryId" required value={categoryId} onChange={e => setCategoryId(e.target.value)}>
                                        <option value="">-- Select Category --</option>
                                        <option value="B2B">B2B</option>
                                        <option value="B2C">B2C</option>
                                        <option value="Healthcare">Healthcare</option>
                                    </select>
                                </div>
                                
                                <div className="col-sm-12 form-group">
                                    <label className="control-label" htmlFor="ProjectDescription">Project Description</label>
                                    <textarea className="form-control" name="ProjectDescription" id="ProjectDescription" rows="3" value={description} onChange={e => setDescription(e.target.value)}></textarea>
                                </div>
                                
                                <div className="col-sm-6 col-md-3 form-group">
                                    <label className="control-label" htmlFor="LOI">LOI (Minute)<span className="text-danger">*</span></label>
                                    <input className="form-control" name="LOI" id="LOI" required type="number" min="1" value={loi} onChange={e => setLoi(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-3 form-group">
                                    <label className="control-label" htmlFor="IR">IR (%)<span className="text-danger">*</span></label>
                                    <input className="form-control" name="IR" id="IR" required type="number" min="1" max="100" value={ir} onChange={e => setIr(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-3 form-group">
                                    <label className="control-label" htmlFor="SampleSize">Sample Size<span className="text-danger">*</span></label>
                                    <input className="form-control" name="SampleSize" id="SampleSize" required type="number" min="1" value={sampleSize} onChange={e => setSampleSize(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-3 form-group">
                                    <label className="control-label" htmlFor="ClickQuota">Respondent Click Quota<span className="text-danger">*</span></label>
                                    <input className="form-control" name="ClickQuota" id="ClickQuota" required type="number" min="1" value={clickQuota} onChange={e => setClickQuota(e.target.value)} />
                                </div>
                                
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="Currency">Currency<span className="text-danger">*</span></label>
                                    <select className="form-control" name="Currency" id="Currency" required value={currency} onChange={e => setCurrency(e.target.value)}>
                                        <option value="USD">USD</option>
                                        <option value="EUR">EUR</option>
                                        <option value="GBP">GBP</option>
                                        <option value="INR">INR</option>
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="ProjectCPI">Project CPI<span className="text-danger">*</span></label>
                                    <input className="form-control" name="ProjectCPI" id="ProjectCPI" required type="number" step="0.01" value={projectCpi} onChange={e => setProjectCpi(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="SupplierCPI">Supplier CPI<span className="text-danger">*</span></label>
                                    <input className="form-control" name="SupplierCPI" id="SupplierCPI" required type="number" step="0.01" value={supplierCpi} onChange={e => setSupplierCpi(e.target.value)} />
                                </div>
                                
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="StartDate">Start Date<span className="text-danger">*</span></label>
                                    <input className="form-control" name="StartDate" id="StartDate" required type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="EndDate">End Date<span className="text-danger">*</span></label>
                                    <input className="form-control" name="EndDate" id="EndDate" required type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
                                </div>
                                
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label" htmlFor="Status">Project Status<span className="text-danger">*</span></label>
                                    <select className="form-control" name="Status" id="Status" required value={status} onChange={e => setStatus(e.target.value)}>
                                        <option value="Draft">Draft</option>
                                        <option value="Live">Live</option>
                                        <option value="Paused">Paused</option>
                                        <option value="Closed">Closed</option>
                                    </select>
                                </div>
                                <div className="col-sm-12 form-group">
                                    <label className="control-label" htmlFor="ClientLink">Client Survey Link (Destination)<span className="text-danger">*</span></label>
                                    <input className="form-control" name="ClientLink" id="ClientLink" required type="url" placeholder="https://..." value={clientLink} onChange={e => setClientLink(e.target.value)} />
                                </div>
                            </div>
                            
                            <h4 className="header-title mt-2 mb-3">Client Redirect URLs</h4>
                            <div className="row">
                                <div className="col-sm-6 form-group">
                                    <label className="control-label">Complete URL</label>
                                    <input className="form-control" name="ClientCompleteUrl" type="url" placeholder="https://..." value={completeUrl} onChange={e => setCompleteUrl(e.target.value)} />
                                </div>
                                <div className="col-sm-6 form-group">
                                    <label className="control-label">Terminate URL</label>
                                    <input className="form-control" name="ClientTerminateUrl" type="url" placeholder="https://..." value={terminateUrl} onChange={e => setTerminateUrl(e.target.value)} />
                                </div>
                                <div className="col-sm-6 form-group">
                                    <label className="control-label">Quota Full URL</label>
                                    <input className="form-control" name="ClientQuotaUrl" type="url" placeholder="https://..." value={quotaUrl} onChange={e => setQuotaUrl(e.target.value)} />
                                </div>
                                <div className="col-sm-6 form-group">
                                    <label className="control-label">Quality Check URL</label>
                                    <input className="form-control" name="ClientQualityUrl" type="url" placeholder="https://..." value={qualityUrl} onChange={e => setQualityUrl(e.target.value)} />
                                </div>
                            </div>
                            
                            <hr />
                            <div className="row mt-4">
                                <div className="col-12 text-right">
                                    <button type="submit" className="btn btn-primary mr-2" disabled={loading}>
                                        {loading ? "Creating..." : "Submit"}
                                    </button>
                                    <button type="button" className="btn btn-secondary" onClick={() => router.push('/projects')}>Cancel</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default function ChildProject() {
    return (
        <Suspense fallback={<div>Loading...</div>}>
            <ChildProjectContent />
        </Suspense>
    );
}
