"use client";
import React from 'react';

export default function APISurvey() {
    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><a href="/">Home</a></li>
                            <li className="breadcrumb-item">Projects</li>
                            <li className="breadcrumb-item active">API Survey</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">API Survey Integration</h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <form onSubmit={(e) => e.preventDefault()}>
                            <div className="row">
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Supplier API Source<span className="text-danger">*</span></label>
                                    <select className="form-control" required>
                                        <option value="">-- Select API --</option>
                                        <option value="lucid">Lucid API</option>
                                        <option value="cint">Cint API</option>
                                        <option value="dynata">Dynata API</option>
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">API Project Name<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="text" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Project Manager<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="text" />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Survey Link / Webhook URL<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="url" />
                                </div>
                            </div>
                            
                            <hr />
                            <div className="row mt-4">
                                <div className="col-12 text-right">
                                    <button type="submit" className="btn btn-primary mr-2">Connect API Survey</button>
                                    <button type="button" className="btn btn-secondary">Cancel</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}
