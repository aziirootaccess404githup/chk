"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { getProjectById, getProjectAndChildLinks } from '@/app/actions/projects';
import { getMappingsByProject, addMapping, removeMapping, updateMapping } from '@/app/actions/mappings';
import { getSuppliers } from '@/app/actions/suppliers';
import { countries } from '@/utils/countries';

// Import new tab components
import SurveyLinkTab from './components/SurveyLinkTab';
import PreScreenTab from './components/PreScreenTab';
import ProjectReportTab from './components/ProjectReportTab';
import ActivityTab from './components/ActivityTab';

export default function ProjectDetails({ params }) {
    const { id } = React.use(params);
    const searchParams = useSearchParams();
    const tabParam = searchParams.get('tab');
    const [project, setProject] = useState(null);
    const [mappings, setMappings] = useState([]);
    const [allSuppliers, setAllSuppliers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState(tabParam === 'mapping' ? 'mapping' : 'details');
    
    // Modal states
    const [showMappingModal, setShowMappingModal] = useState(false);
    const [mappingSaving, setMappingSaving] = useState(false);

    useEffect(() => {
        async function fetchData() {
            setLoading(true);
            const [projRes, mapRes, supRes] = await Promise.all([
                getProjectById(id),
                getMappingsByProject(id),
                getSuppliers()
            ]);
            
            if (projRes.success) setProject(projRes.data);
            if (mapRes.success) setMappings(mapRes.data);
            if (supRes.success) setAllSuppliers(supRes.data);
            
            setLoading(false);
        }
        fetchData();
    }, [id]);

    async function handleAddMapping(e) {
        e.preventDefault();
        setMappingSaving(true);
        const formData = new FormData(e.target);
        formData.append('project_id', id);
        
        const result = await addMapping(formData);
        if (result.success) {
            alert('Supplier mapped successfully!');
            setShowMappingModal(false);
            // Refresh mappings
            const mapRes = await getMappingsByProject(id);
            if (mapRes.success) setMappings(mapRes.data);
        } else {
            alert('Error: ' + result.error);
        }
        setMappingSaving(false);
    }

    async function handleDeleteMapping(mappingId) {
        if (!confirm('Are you sure you want to remove this supplier mapping?')) return;
        const result = await removeMapping(mappingId, id);
        if (result.success) {
            // Refresh mappings
            const mapRes = await getMappingsByProject(id);
            if (mapRes.success) setMappings(mapRes.data);
        } else {
            alert('Error: ' + result.error);
        }
    }

    async function handleToggleTraffic(mappingId, currentStatus) {
        const result = await updateMapping(mappingId, id, { allow_traffic: !currentStatus });
        if (result.success) {
            // Refresh mappings locally
            setMappings(mappings.map(m => m.id === mappingId ? { ...m, allow_traffic: !currentStatus } : m));
        } else {
            alert('Error updating traffic status: ' + result.error);
        }
    }

    async function handleTogglePrescreener(mappingId, currentStatus) {
        const result = await updateMapping(mappingId, id, { show_prescreener: !currentStatus });
        if (result.success) {
            setMappings(mappings.map(m => m.id === mappingId ? { ...m, show_prescreener: !currentStatus } : m));
        } else {
            alert('Error updating prescreener status: ' + result.error);
        }
    }

    function getCountryName(code) {
        const c = countries.find(x => x.code === code);
        return c ? c.name : (code || 'N/A');
    }

    async function handleDownloadLinks() {
        const result = await getProjectAndChildLinks(id);
        if (result.success && result.data.length > 0) {
            let csvContent = "data:text/csv;charset=utf-8,";
            csvContent += "Country,Project Name,Supplier Name,Link\n";
            result.data.forEach(row => {
                const countryName = getCountryName(row.country);
                const uniqueLink = `${window.location.origin}/r/${row.unique_code}?uid=[xxxxxx]`;
                csvContent += `"${countryName}","${row.projectName}","${row.supplierName}","${uniqueLink}"\n`;
            });
            const encodedUri = encodeURI(csvContent);
            const link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", `Project_Links_${id}.csv`);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } else {
            alert('No links found to download.');
        }
    }

    if (loading) {
        return <div className="text-center mt-5">Loading project details...</div>;
    }

    if (!project) {
        return <div className="text-center mt-5">Project not found.</div>;
    }

    return (
        <div className="tabPanelWraps">
            <div className="row">
                <div className="col-12">
                    <div className="page-title-box d-flex align-items-center justify-content-between">
                        <div>
                            <ol className="breadcrumb m-0">
                                <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                                <li className="breadcrumb-item"><Link href="/projects">Projects</Link></li>
                                <li className="breadcrumb-item active">Project Details</li>
                            </ol>
                            <h4 className="page-title mb-0 mt-2">
                                {project.title} <span className="badge badge-info ml-2">PRJ-{project.id.substring(0,4)}</span>
                            </h4>
                        </div>
                        <div>
                            <Link href={`/projects/${id}/edit`} className="btn btn-warning">
                                <i className="fas fa-edit mr-1"></i> Edit Project
                            </Link>
                        </div>
                    </div>
                </div>
            </div>

            <div className="row mb-3">
                <div className="col-12">
                    <ul className="nav nav-pills" style={{backgroundColor: '#fff', padding: '10px', borderRadius: '5px'}}>
                        <li className="nav-item">
                            <a 
                                className={`nav-link ${activeTab === 'details' ? 'active' : ''}`} 
                                href="#" 
                                onClick={(e) => { e.preventDefault(); setActiveTab('details'); }}
                                style={{cursor: 'pointer'}}
                            >
                                Project Detail
                            </a>
                        </li>
                        <li className="nav-item">
                            <a 
                                className={`nav-link ${activeTab === 'surveylink' ? 'active' : ''}`} 
                                href="#" 
                                onClick={(e) => { e.preventDefault(); setActiveTab('surveylink'); }}
                                style={{cursor: 'pointer'}}
                            >
                                Survey Link
                            </a>
                        </li>
                        <li className="nav-item">
                            <a 
                                className={`nav-link ${activeTab === 'prescreen' ? 'active' : ''}`} 
                                href="#" 
                                onClick={(e) => { e.preventDefault(); setActiveTab('prescreen'); }}
                                style={{cursor: 'pointer'}}
                            >
                                PreScreen
                            </a>
                        </li>
                        <li className="nav-item">
                            <a 
                                className={`nav-link ${activeTab === 'mapping' ? 'active' : ''}`} 
                                href="#" 
                                onClick={(e) => { e.preventDefault(); setActiveTab('mapping'); }}
                                style={{cursor: 'pointer'}}
                            >
                                Supplier Mapping
                            </a>
                        </li>
                        <li className="nav-item">
                            <a 
                                className={`nav-link ${activeTab === 'report' ? 'active' : ''}`} 
                                href="#" 
                                onClick={(e) => { e.preventDefault(); setActiveTab('report'); }}
                                style={{cursor: 'pointer'}}
                            >
                                Project Report
                            </a>
                        </li>
                        <li className="nav-item">
                            <a 
                                className={`nav-link ${activeTab === 'activity' ? 'active' : ''}`} 
                                href="#" 
                                onClick={(e) => { e.preventDefault(); setActiveTab('activity'); }}
                                style={{cursor: 'pointer'}}
                            >
                                Activity
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            {activeTab === 'details' && (
                <div className="row">
                    <div className="col-sm-12">
                        <div className="card">
                            <div className="card-body">
                                <h4 className="header-title mb-4">Project Information</h4>
                                <div className="row">
                                    <div className="col-md-6">
                                        <table className="table table-bordered table-sm">
                                            <tbody>
                                                <tr><th style={{width: '40%'}}>Project Code</th><td>PRJ-{project.id.substring(0,4)}</td></tr>
                                                <tr><th>Project Name</th><td>{project.title}</td></tr>
                                                <tr><th>Client</th><td>{project.clients?.name || 'N/A'}</td></tr>
                                                <tr><th>Project Manager</th><td>{project.project_manager || 'N/A'}</td></tr>
                                                <tr><th>Category</th><td>{project.category || 'N/A'}</td></tr>
                                                <tr><th>Status</th><td><span className="badge badge-success">{project.status}</span></td></tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div className="col-md-6">
                                        <table className="table table-bordered table-sm">
                                            <tbody>
                                                <tr><th style={{width: '40%'}}>Country</th><td>{getCountryName(project.country)}</td></tr>
                                                <tr><th>Language</th><td>{project.language || 'N/A'}</td></tr>
                                                <tr><th>LOI (Minutes)</th><td>{project.loi || 'N/A'}</td></tr>
                                                <tr><th>IR (%)</th><td>{project.ir || 'N/A'}</td></tr>
                                                <tr><th>Sample Size</th><td>{project.sample_size || 'N/A'}</td></tr>
                                                <tr><th>Respondent Quota</th><td>{project.quota || '0'}</td></tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                
                                <h4 className="header-title mb-4 mt-4">Pricing & Dates</h4>
                                <div className="row">
                                    <div className="col-md-6">
                                        <table className="table table-bordered table-sm">
                                            <tbody>
                                                <tr><th style={{width: '40%'}}>Currency</th><td>{project.currency || 'USD'}</td></tr>
                                                <tr><th>Project CPI</th><td>${project.cpi || '0.00'}</td></tr>
                                                <tr><th>Supplier CPI</th><td>${project.supplier_cpi || '0.00'}</td></tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div className="col-md-6">
                                        <table className="table table-bordered table-sm">
                                            <tbody>
                                                <tr><th style={{width: '40%'}}>Start Date</th><td>{project.start_date || 'N/A'}</td></tr>
                                                <tr><th>End Date</th><td>{project.end_date || 'N/A'}</td></tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div className="row mt-4">
                                    <div className="col-12">
                                        <h4 className="header-title mb-3">Client URLs</h4>
                                        <table className="table table-bordered table-sm" style={{wordBreak: 'break-all'}}>
                                            <tbody>
                                                <tr><th style={{width: '20%'}}>Destination Link</th><td><a href={project.client_link} target="_blank" rel="noreferrer">{project.client_link}</a></td></tr>
                                                <tr><th>Complete URL</th><td>{project.client_complete_url || 'Not set'}</td></tr>
                                                <tr><th>Terminate URL</th><td>{project.client_terminate_url || 'Not set'}</td></tr>
                                                <tr><th>Quota Full URL</th><td>{project.client_quota_url || 'Not set'}</td></tr>
                                                <tr><th>Quality Check URL</th><td>{project.client_quality_url || 'Not set'}</td></tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div className="row mt-4">
                                    <div className="col-12">
                                        <h4 className="header-title mb-3">Client Redirect Links (Give to Client)</h4>
                                        <p className="text-muted mb-2">These are the links your client should redirect respondents to after survey completion.</p>
                                        
                                        <h6 className="mt-3"><strong>Static Links</strong></h6>
                                        <table className="table table-bordered table-sm" style={{wordBreak: 'break-all'}}>
                                            <tbody>
                                                <tr><th style={{width: '15%'}}>Complete</th><td><code>{`${typeof window !== 'undefined' ? window.location.origin : ''}/panel/redirect/complete?uid=XXXX`}</code></td></tr>
                                                <tr><th>Terminate</th><td><code>{`${typeof window !== 'undefined' ? window.location.origin : ''}/panel/redirect/terminate?uid=XXXX`}</code></td></tr>
                                                <tr><th>Quota Full</th><td><code>{`${typeof window !== 'undefined' ? window.location.origin : ''}/panel/redirect/quota-full?uid=XXXX`}</code></td></tr>
                                                <tr><th>Quality Check</th><td><code>{`${typeof window !== 'undefined' ? window.location.origin : ''}/panel/redirect/quality-check?uid=XXXX`}</code></td></tr>
                                            </tbody>
                                        </table>

                                        <h6 className="mt-3"><strong>Dynamic Links</strong> <span className="badge badge-info">With PID & SID</span></h6>
                                        <table className="table table-bordered table-sm" style={{wordBreak: 'break-all'}}>
                                            <tbody>
                                                <tr><th style={{width: '15%'}}>Complete</th><td><code>{`${typeof window !== 'undefined' ? window.location.origin : ''}/panel/redirect/complete?pid=XXXX&sid=XXXX&uid=XXXX`}</code></td></tr>
                                                <tr><th>Terminate</th><td><code>{`${typeof window !== 'undefined' ? window.location.origin : ''}/panel/redirect/terminate?pid=XXXX&sid=XXXX&uid=XXXX`}</code></td></tr>
                                                <tr><th>Quota Full</th><td><code>{`${typeof window !== 'undefined' ? window.location.origin : ''}/panel/redirect/quota-full?pid=XXXX&sid=XXXX&uid=XXXX`}</code></td></tr>
                                                <tr><th>Quality Check</th><td><code>{`${typeof window !== 'undefined' ? window.location.origin : ''}/panel/redirect/quality-check?pid=XXXX&sid=XXXX&uid=XXXX`}</code></td></tr>
                                            </tbody>
                                        </table>

                                    </div>
                                </div>

                                <div className="row mt-3">
                                    <div className="col-12">
                                        <table className="table table-bordered table-sm mt-3">
                                            <tbody>
                                                <tr><th style={{width: '20%'}}>Description</th><td>{project.description || 'No description provided.'}</td></tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div className="row mt-4">
                                    <div className="col-12">
                                        <h4 className="header-title mb-3">Group Supplier Mapped</h4>
                                        <div className="table-responsive">
                                            <table className="table table-bordered table-sm text-center">
                                                <thead className="thead-light">
                                                    <tr>
                                                        <th>S.No</th>
                                                        <th>SupplierCode</th>
                                                        <th>SupplierName</th>
                                                        <th>Total</th>
                                                        <th>Complete</th>
                                                        <th>Terminate</th>
                                                        <th>OverQuota</th>
                                                        <th>DropOut</th>
                                                        <th>QualityTerm</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {mappings.length === 0 ? (
                                                        <tr><td colSpan="9">No suppliers mapped</td></tr>
                                                    ) : mappings.map((map, i) => (
                                                        <tr key={map.id}>
                                                            <td>{i + 1}</td>
                                                            <td>{map.unique_code || map.supplier_id.substring(0,4)}</td>
                                                            <td>{map.suppliers?.name}</td>
                                                            <td>{map.stats?.clicks || 0}</td>
                                                            <td>{map.stats?.completes || 0}</td>
                                                            <td>{map.stats?.terminates || 0}</td>
                                                            <td>{map.stats?.overQuota || 0}</td>
                                                            <td>{map.stats?.dropouts || 0}</td>
                                                            <td>{map.stats?.securityFails || 0}</td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                                {mappings.length > 0 && (
                                                    <tfoot className="font-weight-bold bg-light">
                                                        <tr>
                                                            <td colSpan="3" className="text-right">Total</td>
                                                            <td>{mappings.reduce((sum, m) => sum + (m.stats?.clicks || 0), 0)}</td>
                                                            <td>{mappings.reduce((sum, m) => sum + (m.stats?.completes || 0), 0)}</td>
                                                            <td>{mappings.reduce((sum, m) => sum + (m.stats?.terminates || 0), 0)}</td>
                                                            <td>{mappings.reduce((sum, m) => sum + (m.stats?.overQuota || 0), 0)}</td>
                                                            <td>{mappings.reduce((sum, m) => sum + (m.stats?.dropouts || 0), 0)}</td>
                                                            <td>{mappings.reduce((sum, m) => sum + (m.stats?.securityFails || 0), 0)}</td>
                                                        </tr>
                                                    </tfoot>
                                                )}
                                            </table>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'mapping' && (
                <div className="row">
                    <div className="col-sm-12">
                        <div className="card">
                            <div className="card-body">
                                <h4 className="header-title mb-4">Supplier Mapping</h4>
                                <p className="text-muted">Allocate sample sizes and configure specific CPIs for suppliers on this project.</p>
                                
                                <div className="table-responsive">
                                    <table className="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Supplier Name</th>
                                                <th>Type</th>
                                                <th>Unique Link</th>
                                                <th>Allocated Quota</th>
                                                <th>ClickQuota</th>
                                                <th>CPI</th>
                                                <th>Prescreener</th>
                                                <th>Traffic</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {mappings.length === 0 ? (
                                                <tr>
                                                    <td colSpan="6" className="text-center text-muted">
                                                        No suppliers mapped yet. Click "Add Supplier" to map a supplier to this project.
                                                    </td>
                                                </tr>
                                            ) : (
                                                mappings.map(map => {
                                                    const uniqueLink = `${window.location.origin}/r/${map.unique_code}?pid=[PID]`;
                                                    return (
                                                        <tr key={map.id}>
                                                            <td>{map.suppliers?.name}</td>
                                                            <td><span className="badge badge-secondary">{map.suppliers?.supplier_type}</span></td>
                                                            <td>
                                                                <div className="input-group input-group-sm">
                                                                    <input type="text" className="form-control" value={uniqueLink} readOnly />
                                                                    <div className="input-group-append">
                                                                        <button className="btn btn-outline-secondary" type="button" onClick={() => navigator.clipboard.writeText(uniqueLink)}>Copy</button>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td>{map.allocation}</td>
                                                            <td>{map.click_quota || 0}</td>
                                                            <td>${map.cpi || '0.00'}</td>
                                                            <td>
                                                                <div className="custom-control custom-switch">
                                                                    <input type="checkbox" className="custom-control-input" id={`prescreenerSwitch${map.id}`} checked={map.show_prescreener === true} onChange={() => handleTogglePrescreener(map.id, map.show_prescreener === true)} />
                                                                    <label className="custom-control-label" htmlFor={`prescreenerSwitch${map.id}`}></label>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div className="custom-control custom-switch">
                                                                    <input type="checkbox" className="custom-control-input" id={`customSwitch${map.id}`} checked={map.allow_traffic !== false} onChange={() => handleToggleTraffic(map.id, map.allow_traffic !== false)} />
                                                                    <label className="custom-control-label" htmlFor={`customSwitch${map.id}`}></label>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <button className="btn btn-danger btn-sm" onClick={() => handleDeleteMapping(map.id)}><i className="fas fa-trash"></i></button>
                                                            </td>
                                                        </tr>
                                                    );
                                                })
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                                <div className="mt-3">
                                    <button className="btn btn-primary mr-2" onClick={() => setShowMappingModal(true)}><i className="fas fa-plus mr-1"></i> Add Supplier</button>
                                    <button className="btn btn-success" onClick={handleDownloadLinks}><i className="fas fa-download mr-1"></i> Download Links (Includes Children)</button>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'surveylink' && (
                <SurveyLinkTab project={project} />
            )}

            {activeTab === 'prescreen' && (
                <PreScreenTab projectId={id} />
            )}

            {activeTab === 'report' && (
                <ProjectReportTab projectId={id} />
            )}

            {activeTab === 'activity' && (
                <ActivityTab projectId={id} />
            )}


            {showMappingModal && (
                <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">Map Supplier to Project</h5>
                                <button type="button" className="close" onClick={() => setShowMappingModal(false)}>
                                    <span>&times;</span>
                                </button>
                            </div>
                            <form onSubmit={handleAddMapping}>
                                <div className="modal-body">
                                    <div className="form-group">
                                        <label>Supplier<span className="text-danger">*</span></label>
                                        <select className="form-control" name="supplier_id" multiple required style={{ height: '200px' }}>
                                            <option value="ALL" className="font-weight-bold text-primary">-- Select All Suppliers --</option>
                                            {allSuppliers.map(sup => (
                                                <option key={sup.id} value={sup.id}>{sup.name} ({sup.supplier_type})</option>
                                            ))}
                                        </select>
                                        <small className="text-muted mt-1 d-block">Hold Ctrl/Cmd to select multiple, or just click "Select All Suppliers" to map all at once.</small>
                                    </div>
                                    <div className="form-group">
                                        <label>Allocated Quota</label>
                                        <input type="number" className="form-control" name="allocation" defaultValue="0" min="0" />
                                    </div>
                                    <div className="form-group">
                                        <label>Click Quota</label>
                                        <input type="number" className="form-control" name="click_quota" defaultValue="0" min="0" />
                                    </div>
                                    <div className="form-group">
                                        <label>Agreed CPI</label>
                                        <input type="number" step="0.01" className="form-control" name="cpi" defaultValue={project.supplier_cpi || "0.00"} />
                                    </div>
                                    <div className="form-group">
                                        <div className="custom-control custom-switch">
                                            <input type="checkbox" className="custom-control-input" id="allowTrafficSwitch" name="allow_traffic" defaultChecked />
                                            <label className="custom-control-label" htmlFor="allowTrafficSwitch">Allow Traffic (Open)</label>
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <div className="custom-control custom-checkbox">
                                            <input type="checkbox" className="custom-control-input" id="showPrescreenerCheck" name="show_prescreener" value="true" />
                                            <label className="custom-control-label" htmlFor="showPrescreenerCheck">Show Prescreener</label>
                                        </div>
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" onClick={() => setShowMappingModal(false)}>Close</button>
                                    <button type="submit" className="btn btn-primary" disabled={mappingSaving}>
                                        {mappingSaving ? "Mapping..." : "Map Supplier"}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
