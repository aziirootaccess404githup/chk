"use client";
import React, { useState, useEffect } from 'react';
import { getPreScreenQuestions, addPreScreenQuestion, deletePreScreenQuestion } from '@/app/actions/prescreen';

export default function PreScreenTab({ projectId }) {
    const [questions, setQuestions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showModal, setShowModal] = useState(false);
    const [saving, setSaving] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');

    useEffect(() => {
        fetchQuestions();
    }, [projectId]);

    async function fetchQuestions() {
        setLoading(true);
        const res = await getPreScreenQuestions(projectId);
        if (res.success) {
            setQuestions(res.data);
        }
        setLoading(false);
    }

    async function handleAddQuestion(e) {
        e.preventDefault();
        setSaving(true);
        const formData = new FormData(e.target);
        formData.append('project_id', projectId);
        
        const res = await addPreScreenQuestion(formData);
        if (res.success) {
            setShowModal(false);
            fetchQuestions();
        } else {
            alert('Failed to add question: ' + res.error);
        }
        setSaving(false);
    }

    async function handleDelete(id) {
        if (!confirm('Are you sure you want to delete this question?')) return;
        const res = await deletePreScreenQuestion(id, projectId);
        if (res.success) {
            fetchQuestions();
        } else {
            alert('Failed to delete question: ' + res.error);
        }
    }

    const filteredQuestions = questions.filter(q => 
        q.question_text.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div className="row">
            <div className="col-sm-12">
                <div className="card">
                    <div className="card-body">
                        <h4 className="header-title mb-4">PreScreen</h4>
                        
                        <div className="row mb-4">
                            <div className="col-sm-3">
                                <select className="form-control">
                                    <option>Select Language</option>
                                    <option>EN</option>
                                </select>
                            </div>
                            <div className="col-sm-3">
                                <select className="form-control">
                                    <option>Choose Template</option>
                                    <option>B2B Standard</option>
                                    <option>Healthcare</option>
                                    <option>Consumer Demo</option>
                                </select>
                            </div>
                            <div className="col-sm-6 text-right" style={{ textAlign: 'right' }}>
                                <button className="btn btn-primary btn-sm mr-2" style={{ marginRight: '8px' }} onClick={() => setShowModal(true)}>Add Temp Question</button>
                                <button className="btn btn-secondary btn-sm mr-2" style={{ marginRight: '8px' }}>View Temp Question</button>
                                <button className="btn btn-info btn-sm">PreScreen Message</button>
                            </div>
                        </div>

                        <div className="row mb-3">
                            <div className="col-sm-4">
                                <input type="text" className="form-control" placeholder="Search Question..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
                            </div>
                        </div>

                        <div className="table-responsive mt-3">
                            <table className="table table-bordered table-striped text-center">
                                <thead className="thead-light">
                                    <tr>
                                        <th style={{width: '10%'}}>S.No</th>
                                        <th style={{width: '50%', textAlign: 'left'}}>Question</th>
                                        <th style={{width: '20%'}}>Type</th>
                                        <th style={{width: '20%'}}>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {loading ? (
                                        <tr><td colSpan="4" className="text-muted py-3">Loading questions...</td></tr>
                                    ) : filteredQuestions.length === 0 ? (
                                        <tr><td colSpan="4" className="text-muted py-3">No prescreen questions found.</td></tr>
                                    ) : (
                                        filteredQuestions.map((q, index) => (
                                            <tr key={q.id}>
                                                <td>{index + 1}</td>
                                                <td style={{ textAlign: 'left' }}>{q.question_text}</td>
                                                <td><span className="badge badge-secondary">{q.question_type}</span></td>
                                                <td>
                                                    <button className="btn btn-sm btn-danger" onClick={() => handleDelete(q.id)}>Delete</button>
                                                </td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            {/* Add Question Modal */}
            {showModal && (
                <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">Add Prescreen Question</h5>
                                <button type="button" className="close" onClick={() => setShowModal(false)}>
                                    <span>&times;</span>
                                </button>
                            </div>
                            <form onSubmit={handleAddQuestion}>
                                <div className="modal-body">
                                    <div className="form-group mb-3">
                                        <label>Language</label>
                                        <select className="form-control" name="language">
                                            <option value="EN">English</option>
                                        </select>
                                    </div>
                                    <div className="form-group mb-3">
                                        <label>Question Type <span className="text-danger">*</span></label>
                                        <select className="form-control" name="question_type" required>
                                            <option value="">-- Select Type --</option>
                                            <option value="Single Choice">Single Choice (Radio)</option>
                                            <option value="Multiple Choice">Multiple Choice (Checkbox)</option>
                                            <option value="Open Ended">Open Ended (Text)</option>
                                        </select>
                                    </div>
                                    <div className="form-group mb-3">
                                        <label>Question Text <span className="text-danger">*</span></label>
                                        <textarea className="form-control" name="question_text" rows="3" required placeholder="Enter the question text..."></textarea>
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                                    <button type="submit" className="btn btn-primary" disabled={saving}>
                                        {saving ? 'Saving...' : 'Save Question'}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
