"use client";
import React, { useState, useEffect } from 'react';
import { getProjectStats, exportProjectLogs } from '@/app/actions/reports';

export default function ProjectReportTab({ projectId }) {
    const [reportType, setReportType] = useState('Project');
    const [stats, setStats] = useState({ completes: 0, terminates: 0, overQuota: 0, securityFails: 0, dropouts: 0, total: 0 });
    const [loading, setLoading] = useState(true);
    const [downloading, setDownloading] = useState(false);

    useEffect(() => {
        if (reportType === 'Project') {
            fetchStats();
        }
    }, [projectId, reportType]);

    async function fetchStats() {
        setLoading(true);
        const res = await getProjectStats(projectId);
        if (res.success) {
            setStats(res.data);
        }
        setLoading(false);
    }

    async function handleDownload() {
        setDownloading(true);
        const res = await exportProjectLogs(projectId);
        if (res.success && res.data) {
            // Convert to CSV
            const headers = ['ID', 'Supplier', 'Respondent UID', 'Status', 'IP Address', 'Started At', 'Completed At'];
            const rows = res.data.map(log => [
                log.id,
                log.suppliers?.name || 'Unknown',
                log.respondent_uid,
                log.status,
                log.ip_address || '',
                log.started_at,
                log.completed_at || ''
            ]);
            
            const csvContent = [
                headers.join(','),
                ...rows.map(r => r.map(cell => `"${cell}"`).join(','))
            ].join('\n');

            // Download trigger
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.setAttribute("href", url);
            link.setAttribute("download", `Project_Report_${projectId.substring(0,8)}.csv`);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } else {
            alert("Failed to export report.");
        }
        setDownloading(false);
    }

    return (
        <div className="row">
            <div className="col-sm-12">
                <div className="card">
                    <div className="card-body">
                        <h4 className="header-title mb-4">Project Report</h4>
                        
                        <div className="row mb-4">
                            <div className="col-sm-6">
                                <div className="custom-control custom-radio custom-control-inline" style={{ display: 'inline-block', marginRight: '15px' }}>
                                    <input type="radio" id="reportProject" name="reportType" className="custom-control-input" 
                                        checked={reportType === 'Project'} onChange={() => setReportType('Project')} />
                                    <label className="custom-control-label ml-1" htmlFor="reportProject">Project Report</label>
                                </div>
                                <div className="custom-control custom-radio custom-control-inline" style={{ display: 'inline-block' }}>
                                    <input type="radio" id="reportPreScreen" name="reportType" className="custom-control-input" 
                                        checked={reportType === 'PreScreen'} onChange={() => setReportType('PreScreen')} />
                                    <label className="custom-control-label ml-1" htmlFor="reportPreScreen">PreScreen Report</label>
                                </div>
                            </div>
                            <div className="col-sm-6 text-right" style={{ textAlign: 'right' }}>
                                <button className="btn btn-primary btn-sm" onClick={handleDownload} disabled={downloading}>
                                    {downloading ? 'Downloading...' : 'Download CSV'}
                                </button>
                            </div>
                        </div>

                        {reportType === 'Project' ? (
                            <div className="row mt-4">
                                <div className="col-sm-6">
                                    <table className="table table-bordered table-striped text-center">
                                        <thead className="thead-light">
                                            <tr>
                                                <th>Status</th>
                                                <th>Count</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {loading ? (
                                                <tr><td colSpan="2" className="text-muted">Loading stats...</td></tr>
                                            ) : (
                                                <>
                                                    <tr><td className="font-weight-bold text-success">Complete</td><td>{stats.completes}</td></tr>
                                                    <tr><td className="font-weight-bold text-danger">Terminate</td><td>{stats.terminates}</td></tr>
                                                    <tr><td className="font-weight-bold text-warning">Over Quota</td><td>{stats.overQuota}</td></tr>
                                                    <tr><td className="font-weight-bold text-secondary">Security Fail</td><td>{stats.securityFails}</td></tr>
                                                    <tr><td className="font-weight-bold text-info">Started / Dropout</td><td>{stats.dropouts}</td></tr>
                                                    <tr className="bg-light"><td className="font-weight-bold">Total Clicks</td><td className="font-weight-bold">{stats.total}</td></tr>
                                                </>
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                                <div className="col-sm-6">
                                    <div style={{ height: '270px', background: '#f8f9fa', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px dashed #ccc', flexDirection: 'column' }}>
                                        <span className="text-muted">Chart Integration Ready</span>
                                        <small className="text-muted mt-2">Connect your preferred chart library (e.g., ApexCharts) here.</small>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <div className="row mt-4">
                                <div className="col-12 text-center text-muted py-5 border">
                                    PreScreen reports will appear here once the survey engine collects prescreening data.
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
