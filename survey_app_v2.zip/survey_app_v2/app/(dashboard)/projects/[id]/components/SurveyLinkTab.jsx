"use client";
import React, { useState, useEffect } from 'react';
import { updateProject } from '@/app/actions/projects';
import { getCountryLinks, addCountryLink, deleteCountryLink } from '@/app/actions/countryLinks';
import { countries } from '@/utils/countries';

export default function SurveyLinkTab({ project }) {
    const [isEditing, setIsEditing] = useState(false);
    const [saving, setSaving] = useState(false);
    
    // Form state
    const [linkType, setLinkType] = useState(project?.link_type || 'Single');
    const [clientLink, setClientLink] = useState(project?.client_link || '');
    const [testLink, setTestLink] = useState(project?.test_link || '');

    // Multi-Country Link state
    const [countryLinks, setCountryLinks] = useState([]);
    const [newCountry, setNewCountry] = useState('');
    const [newCountryUrl, setNewCountryUrl] = useState('');
    const [addingCountryLink, setAddingCountryLink] = useState(false);

    async function fetchCountryLinks() {
        const result = await getCountryLinks(project.id);
        if (result.success) setCountryLinks(result.data);
    }

    useEffect(() => {
        if (linkType === 'Country') fetchCountryLinks();
    }, [linkType]);

    async function handleAddCountryLink() {
        if (!newCountry || !newCountryUrl) {
            alert("Select a country and enter a URL.");
            return;
        }
        setAddingCountryLink(true);
        const result = await addCountryLink(project.id, newCountry, newCountryUrl);
        setAddingCountryLink(false);
        if (result.success) {
            setNewCountry('');
            setNewCountryUrl('');
            fetchCountryLinks();
        } else {
            alert("Error: " + result.error);
        }
    }

    async function handleDeleteCountryLink(id) {
        if (!confirm("Remove this country's override URL?")) return;
        const result = await deleteCountryLink(id, project.id);
        if (result.success) fetchCountryLinks();
    }

    async function handleSave() {
        setSaving(true);
        const result = await updateProject(project.id, {
            link_type: linkType,
            client_link: clientLink,
            test_link: testLink
        });
        
        setSaving(false);
        if (result.success) {
            setIsEditing(false);
        } else {
            alert('Failed to save URLs: ' + result.error);
        }
    }

    function handleTestSurvey() {
        const urlToTest = testLink || clientLink;
        if (!urlToTest) {
            alert('No URL configured to test.');
            return;
        }
        window.open(urlToTest, '_blank');
    }

    return (
        <div className="row">
            <div className="col-sm-12">
                <div className="card">
                    <div className="card-body">
                        <div className="row">
                            <div className="col-sm-6">
                                <h4 className="header-title mb-4">Survey Link</h4>
                            </div>
                            <div className="col-sm-6 text-right" style={{ textAlign: 'right' }}>
                                <button className="btn btn-primary btn-sm mr-2" style={{ marginRight: '8px' }} onClick={handleTestSurvey}>Test Survey</button>
                                {isEditing ? (
                                    <>
                                        <button className="btn btn-success btn-sm mr-2" style={{ marginRight: '8px' }} onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : 'Save'}</button>
                                        <button className="btn btn-secondary btn-sm" onClick={() => setIsEditing(false)}>Cancel</button>
                                    </>
                                ) : (
                                    <>
                                        <button className="btn btn-warning btn-sm mr-2" style={{ marginRight: '8px' }} onClick={() => setIsEditing(true)}>Edit</button>
                                        <button className="btn btn-secondary btn-sm">Refresh</button>
                                    </>
                                )}
                            </div>
                        </div>

                        <div className="row mb-3">
                            <div className="col-12">
                                <div className="custom-control custom-radio custom-control-inline" style={{ display: 'inline-block', marginRight: '15px' }}>
                                    <input type="radio" id="singleLink" name="linkType" className="custom-control-input" 
                                        checked={linkType === 'Single'} onChange={() => isEditing && setLinkType('Single')} disabled={!isEditing} />
                                    <label className="custom-control-label ml-1" htmlFor="singleLink">Single Link</label>
                                </div>
                                <div className="custom-control custom-radio custom-control-inline" style={{ display: 'inline-block', marginRight: '15px' }}>
                                    <input type="radio" id="multiLink" name="linkType" className="custom-control-input" 
                                        checked={linkType === 'Multi'} onChange={() => isEditing && setLinkType('Multi')} disabled={!isEditing} />
                                    <label className="custom-control-label ml-1" htmlFor="multiLink">Multi Link</label>
                                </div>
                                <div className="custom-control custom-radio custom-control-inline" style={{ display: 'inline-block' }}>
                                    <input type="radio" id="countryLink" name="linkType" className="custom-control-input" 
                                        checked={linkType === 'Country'} onChange={() => isEditing && setLinkType('Country')} disabled={!isEditing} />
                                    <label className="custom-control-label ml-1" htmlFor="countryLink">Country Link</label>
                                </div>
                            </div>
                        </div>

                        <div className="form-group row mt-3">
                            <label className="col-sm-2 col-form-label">Live URL</label>
                            <div className="col-sm-10">
                                <input type="text" className="form-control" value={clientLink} onChange={e => setClientLink(e.target.value)} readOnly={!isEditing} />
                            </div>
                        </div>

                        <div className="form-group row mt-2">
                            <label className="col-sm-2 col-form-label">Test URL</label>
                            <div className="col-sm-10">
                                <input type="text" className="form-control" value={testLink} onChange={e => setTestLink(e.target.value)} readOnly={!isEditing} />
                            </div>
                        </div>

                        {linkType === 'Country' && (
                            <div className="mt-4 pt-3" style={{ borderTop: '1px solid #eee' }}>
                                <h5 className="mb-2">Per-Country Override URLs</h5>
                                <p className="text-muted" style={{ fontSize: '12px' }}>
                                    Respondents from a listed country get sent here instead of the default Live URL above (detected automatically from their IP). Any country not listed falls back to the default.
                                </p>

                                <div className="row align-items-end mb-3">
                                    <div className="col-sm-4 form-group mb-0">
                                        <select className="form-control" value={newCountry} onChange={(e) => setNewCountry(e.target.value)}>
                                            <option value="">-- Select Country --</option>
                                            {countries.map(c => <option key={c.code} value={c.name}>{c.name}</option>)}
                                        </select>
                                    </div>
                                    <div className="col-sm-6 form-group mb-0">
                                        <input type="text" className="form-control" placeholder="https://..." value={newCountryUrl} onChange={(e) => setNewCountryUrl(e.target.value)} />
                                    </div>
                                    <div className="col-sm-2 form-group mb-0">
                                        <button className="btn btn-primary w-100" onClick={handleAddCountryLink} disabled={addingCountryLink}>
                                            {addingCountryLink ? '...' : 'Add'}
                                        </button>
                                    </div>
                                </div>

                                <table className="table table-sm table-striped">
                                    <thead>
                                        <tr><th>Country</th><th>Override URL</th><th>Action</th></tr>
                                    </thead>
                                    <tbody>
                                        {countryLinks.length > 0 ? countryLinks.map(cl => (
                                            <tr key={cl.id}>
                                                <td>{cl.country}</td>
                                                <td style={{ wordBreak: 'break-all' }}>{cl.live_url}</td>
                                                <td>
                                                    <button className="btn btn-sm btn-outline-danger" onClick={() => handleDeleteCountryLink(cl.id)}>Remove</button>
                                                </td>
                                            </tr>
                                        )) : (
                                            <tr><td colSpan="3" className="text-center text-muted">No country-specific URLs added yet.</td></tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
