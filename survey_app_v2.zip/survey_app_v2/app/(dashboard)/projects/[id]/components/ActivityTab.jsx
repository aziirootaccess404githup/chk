"use client";
import React, { useState, useEffect } from 'react';
import { getActivities, addActivity } from '@/app/actions/activities';

export default function ActivityTab({ projectId }) {
    const [activities, setActivities] = useState([]);
    const [loading, setLoading] = useState(true);
    const [adding, setAdding] = useState(false);

    useEffect(() => {
        fetchActivities();
    }, [projectId]);

    async function fetchActivities() {
        setLoading(true);
        const res = await getActivities(projectId);
        if (res.success) {
            setActivities(res.data);
        }
        setLoading(false);
    }

    async function handleAddActivity(e) {
        e.preventDefault();
        setAdding(true);
        const formData = new FormData(e.target);
        formData.append('project_id', projectId);
        
        const res = await addActivity(formData);
        if (res.success) {
            e.target.reset(); // clear form
            fetchActivities(); // reload
        } else {
            alert('Failed to add activity: ' + res.error);
        }
        setAdding(false);
    }

    return (
        <div className="row">
            <div className="col-sm-12">
                <div className="card">
                    <div className="card-body">
                        <h4 className="header-title mb-4">Activity (PM Logs)</h4>
                        
                        <form onSubmit={handleAddActivity} className="row mb-3">
                            <div className="col-sm-2">
                                <label>Date</label>
                                <input type="date" name="date" className="form-control" required defaultValue={new Date().toISOString().split('T')[0]} />
                            </div>
                            <div className="col-sm-3">
                                <label>Activity</label>
                                <select name="activity" className="form-control" required>
                                    <option value="">Select Activity</option>
                                    <option value="Bidding">Bidding</option>
                                    <option value="Setup">Setup</option>
                                    <option value="Fieldwork">Fieldwork</option>
                                    <option value="Data Delivery">Data Delivery</option>
                                </select>
                            </div>
                            <div className="col-sm-3">
                                <label>Sub Activity</label>
                                <select name="sub_activity" className="form-control">
                                    <option value="">Select Sub Activity</option>
                                    <option value="Review Specs">Review Specs</option>
                                    <option value="Program Survey">Program Survey</option>
                                    <option value="Test Link">Test Link</option>
                                    <option value="Launch">Launch</option>
                                    <option value="Monitor Quotas">Monitor Quotas</option>
                                    <option value="Close Project">Close Project</option>
                                </select>
                            </div>
                            <div className="col-sm-2">
                                <label>Duration</label>
                                <select name="duration" className="form-control" required>
                                    <option value="">Select</option>
                                    <option value="5 min">5 min</option>
                                    <option value="10 min">10 min</option>
                                    <option value="15 min">15 min</option>
                                    <option value="30 min">30 min</option>
                                    <option value="60 min">60 min</option>
                                    <option value="120 min">120 min</option>
                                </select>
                            </div>
                            <div className="col-sm-2">
                                <label>&nbsp;</label>
                                <div>
                                    <button type="submit" className="btn btn-primary btn-block" disabled={adding}>
                                        {adding ? '...' : 'Add'}
                                    </button>
                                </div>
                            </div>
                        </form>

                        <div className="table-responsive mt-4">
                            <table className="table table-bordered table-striped text-center">
                                <thead className="thead-light">
                                    <tr>
                                        <th>S.No</th>
                                        <th>Date</th>
                                        <th>Activity</th>
                                        <th>SubActivity</th>
                                        <th>Duration</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {loading ? (
                                        <tr><td colSpan="5" className="text-muted py-3">Loading...</td></tr>
                                    ) : activities.length === 0 ? (
                                        <tr><td colSpan="5" className="text-muted py-3">No activity logged yet.</td></tr>
                                    ) : (
                                        activities.map((act, index) => (
                                            <tr key={act.id}>
                                                <td>{index + 1}</td>
                                                <td>{act.date}</td>
                                                <td>{act.activity}</td>
                                                <td>{act.sub_activity || '-'}</td>
                                                <td>{act.duration}</td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
