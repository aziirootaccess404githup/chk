"use client";
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { getProjectById, updateProject } from '@/app/actions/projects';
import { getClients } from '@/app/actions/clients';
import { countries } from '@/utils/countries';

export default function EditProject({ params }) {
    const { id } = React.use(params);
    const router = useRouter();
    
    const [clients, setClients] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isUpdating, setIsUpdating] = useState(false);
    
    // Form fields (same as previous modal)
    const [editStatus, setEditStatus] = useState("Draft");
    const [editClientLink, setEditClientLink] = useState("");
    const [editDynamicThanks, setEditDynamicThanks] = useState(false);
    const [editEncryptUid, setEditEncryptUid] = useState(true);
    const [editClientId, setEditClientId] = useState("");
    const [editTitle, setEditTitle] = useState("");
    const [editCountry, setEditCountry] = useState("");
    const [editDescription, setEditDescription] = useState("");
    const [editNotes, setEditNotes] = useState("");
    const [editLoi, setEditLoi] = useState("");
    const [editIr, setEditIr] = useState("");
    const [editSampleSize, setEditSampleSize] = useState("");
    const [editQuota, setEditQuota] = useState("");
    const [editCurrency, setEditCurrency] = useState("USD");
    const [editCpi, setEditCpi] = useState("");
    const [editSupplierCpi, setEditSupplierCpi] = useState("");
    const [editStartDate, setEditStartDate] = useState("");
    const [editEndDate, setEditEndDate] = useState("");

    useEffect(() => {
        async function fetchData() {
            const clientRes = await getClients();
            if (clientRes.success) setClients(clientRes.data);

            const projRes = await getProjectById(id);
            if (projRes.success && projRes.data) {
                const item = projRes.data;
                setEditStatus(item.status || 'Draft');
                setEditClientLink(item.client_link || '');
                setEditDynamicThanks(item.dynamic_thanks || false);
                setEditEncryptUid(item.encrypt_uid !== false);
                setEditClientId(item.client_id || '');
                setEditTitle(item.title || '');
                setEditCountry(item.country || '');
                setEditDescription(item.description || '');
                setEditNotes(item.notes || '');
                setEditLoi(item.loi || '');
                setEditIr(item.ir || '');
                setEditSampleSize(item.sample_size || '');
                setEditQuota(item.quota || '');
                setEditCurrency(item.currency || 'USD');
                setEditCpi(item.cpi || '');
                setEditSupplierCpi(item.supplier_cpi || '');
                setEditStartDate(item.start_date || '');
                setEditEndDate(item.end_date || '');
            }
            setLoading(false);
        }
        fetchData();
    }, [id]);

    async function handleUpdateProject(e) {
        e.preventDefault();
        setIsUpdating(true);
        const result = await updateProject(id, {
            status: editStatus,
            client_link: editClientLink,
            dynamic_thanks: editDynamicThanks,
            encrypt_uid: editEncryptUid,
            client_id: editClientId || null,
            title: editTitle,
            country: editCountry || null,
            description: editDescription,
            notes: editNotes,
            loi: editLoi ? parseInt(editLoi, 10) : null,
            ir: editIr ? parseInt(editIr, 10) : null,
            sample_size: editSampleSize ? parseInt(editSampleSize, 10) : null,
            quota: editQuota ? parseInt(editQuota, 10) : 0,
            currency: editCurrency,
            cpi: editCpi ? parseFloat(editCpi) : null,
            supplier_cpi: editSupplierCpi ? parseFloat(editSupplierCpi) : null,
            start_date: editStartDate || null,
            end_date: editEndDate || null
        });

        if (result.success) {
            alert("Project updated successfully!");
            router.push('/projects');
        } else {
            alert("Error updating project: " + result.error);
            setIsUpdating(false);
        }
    }

    if (loading) return <div className="p-4 text-center">Loading project...</div>;

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><a href="/">Home</a></li>
                            <li className="breadcrumb-item"><a href="/projects">Projects</a></li>
                            <li className="breadcrumb-item active">Edit Project</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Edit Project</h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <form onSubmit={handleUpdateProject}>

                            <div className="row">
                                <div className="col-md-6 form-group">
                                    <label>Client <span className="text-danger">*</span></label>
                                    <select 
                                        className="form-control"
                                        value={editClientId}
                                        onChange={(e) => setEditClientId(e.target.value)}
                                        required
                                    >
                                        <option value="">-- Select Client --</option>
                                        {clients.map(c => (
                                            <option key={c.id} value={c.id}>{c.name}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-md-6 form-group">
                                    <label>Project Name <span className="text-danger">*</span></label>
                                    <input 
                                        type="text" 
                                        className="form-control" 
                                        value={editTitle}
                                        onChange={(e) => setEditTitle(e.target.value)}
                                        required
                                    />
                                </div>
                            </div>
                            <div className="row mt-3">
                                <div className="col-md-6 form-group">
                                    <label>Project Country <span className="text-danger">*</span></label>
                                    <select 
                                        className="form-control"
                                        value={editCountry}
                                        onChange={(e) => setEditCountry(e.target.value)}
                                        required
                                    >
                                        <option value="">-- Select Country --</option>
                                        {countries.map(c => (
                                            <option key={c.code} value={c.code}>{c.name}</option>
                                        ))}
                                    </select>
                                </div>
                            </div>
                            <div className="form-group mt-3">
                                <label>Project Description</label>
                                <input 
                                    type="text" 
                                    className="form-control" 
                                    value={editDescription}
                                    onChange={(e) => setEditDescription(e.target.value)}
                                />
                            </div>
                            <div className="form-group mt-3">
                                <label>Notes</label>
                                <textarea 
                                    className="form-control" 
                                    rows="3"
                                    value={editNotes}
                                    onChange={(e) => setEditNotes(e.target.value)}
                                    placeholder="Maximum limit of characters 2000"
                                    maxLength={2000}
                                ></textarea>
                            </div>
                            <div className="form-group mt-3 mb-3">
                                <div className="custom-control custom-checkbox">
                                    <input 
                                        type="checkbox" 
                                        className="custom-control-input" 
                                        id="dynamicThanksCheck" 
                                        checked={editDynamicThanks}
                                        onChange={(e) => setEditDynamicThanks(e.target.checked)}
                                    />
                                    <label className="custom-control-label" htmlFor="dynamicThanksCheck">Dynamic Thanks</label>
                                </div>
                            </div>
                            <div className="form-group mt-3 mb-3">
                                <div className="custom-control custom-checkbox">
                                    <input
                                        type="checkbox"
                                        className="custom-control-input"
                                        id="encryptUidCheck"
                                        checked={editEncryptUid}
                                        onChange={(e) => setEditEncryptUid(e.target.checked)}
                                    />
                                    <label className="custom-control-label" htmlFor="encryptUidCheck">
                                        Encrypt respondent UID sent to client survey <span style={{fontWeight: 'normal', fontSize: '11px'}}>(recommended — uncheck only if the client's survey platform requires the exact original ID)</span>
                                    </label>
                                </div>
                            </div>
                            
                            <div className="row mt-3">
                                <div className="col-md-3 form-group">
                                    <label>LOI (Minute)<span className="text-danger">*</span></label>
                                    <input type="number" className="form-control" value={editLoi} onChange={(e) => setEditLoi(e.target.value)} required />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>IR (%)<span className="text-danger">*</span></label>
                                    <input type="number" className="form-control" value={editIr} onChange={(e) => setEditIr(e.target.value)} required />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Sample Size<span className="text-danger">*</span></label>
                                    <input type="number" className="form-control" value={editSampleSize} onChange={(e) => setEditSampleSize(e.target.value)} required />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label>Respondent Click Quota<span className="text-danger">*</span></label>
                                    <input type="number" className="form-control" value={editQuota} onChange={(e) => setEditQuota(e.target.value)} required />
                                </div>
                            </div>

                            <div className="row mt-3">
                                <div className="col-md-4 form-group">
                                    <label>Currency<span className="text-danger">*</span></label>
                                    <select className="form-control" value={editCurrency} onChange={(e) => setEditCurrency(e.target.value)} required>
                                        <option value="USD">USD</option>
                                        <option value="EUR">EUR</option>
                                        <option value="GBP">GBP</option>
                                        <option value="INR">INR</option>
                                    </select>
                                </div>
                                <div className="col-md-4 form-group">
                                    <label>Project CPI<span className="text-danger">*</span></label>
                                    <input type="number" step="0.01" className="form-control" value={editCpi} onChange={(e) => setEditCpi(e.target.value)} required />
                                </div>
                                <div className="col-md-4 form-group">
                                    <label>Supplier CPI<span className="text-danger">*</span></label>
                                    <input type="number" step="0.01" className="form-control" value={editSupplierCpi} onChange={(e) => setEditSupplierCpi(e.target.value)} required />
                                </div>
                            </div>
                            <div className="row mt-3">
                                <div className="col-md-4 form-group">
                                    <label>Start Date<span className="text-danger">*</span></label>
                                    <input type="date" className="form-control" value={editStartDate} onChange={(e) => setEditStartDate(e.target.value)} required />
                                </div>
                                <div className="col-md-4 form-group">
                                    <label>End Date<span className="text-danger">*</span></label>
                                    <input type="date" className="form-control" value={editEndDate} onChange={(e) => setEditEndDate(e.target.value)} required />
                                </div>
                                <div className="col-md-4 form-group">
                                    <label>Project Status<span className="text-danger">*</span></label>
                                    <select 
                                        className="form-control"
                                        value={editStatus}
                                        onChange={(e) => setEditStatus(e.target.value)}
                                        required
                                    >
                                        <option value="Draft">Draft</option>
                                        <option value="Live">Live</option>
                                        <option value="Paused">Paused</option>
                                        <option value="Closed">Closed</option>
                                        <option value="Invoiced">Invoiced</option>
                                        <option value="Archive">Archive</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div className="form-group mt-3">
                                <label>Client Survey Link (Destination)<span className="text-danger">*</span></label>
                                <input 
                                    type="url" 
                                    className="form-control" 
                                    value={editClientLink}
                                    onChange={(e) => setEditClientLink(e.target.value)}
                                    required
                                    placeholder="https://..."
                                />
                            </div>

                            <div className="mt-4">
                                <h6>Client Redirect URLs</h6>
                                <div className="row mt-2">
                                    <div className="col-md-6 form-group">
                                        <label>Complete URL</label>
                                        <input type="text" className="form-control" readOnly value={`https://your-domain.com/panel/redirect/complete?uid=XXXX`} />
                                    </div>
                                    <div className="col-md-6 form-group">
                                        <label>Terminate URL</label>
                                        <input type="text" className="form-control" readOnly value={`https://your-domain.com/panel/redirect/terminate?uid=XXXX`} />
                                    </div>
                                </div>
                                <div className="row mt-2">
                                    <div className="col-md-6 form-group">
                                        <label>Quota Full URL</label>
                                        <input type="text" className="form-control" readOnly value={`https://your-domain.com/panel/redirect/quota-full?uid=XXXX`} />
                                    </div>
                                    <div className="col-md-6 form-group">
                                        <label>Quality Check URL</label>
                                        <input type="text" className="form-control" readOnly value={`https://your-domain.com/panel/redirect/quality-check?uid=XXXX`} />
                                    </div>
                                </div>
                            </div>
                            <hr />
                            <div className="row mt-4">
                                <div className="col-12 text-right">
                                    <button type="submit" className="btn btn-primary mr-2" disabled={isUpdating}>
                                        {isUpdating ? "Saving..." : "Save Changes"}
                                    </button>
                                    <button type="button" className="btn btn-secondary" onClick={() => router.push('/projects')}>Cancel</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}
