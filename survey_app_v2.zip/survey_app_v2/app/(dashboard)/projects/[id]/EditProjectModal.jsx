import React, { useState, useEffect } from 'react';
import { updateProject } from '@/app/actions/projects';
import { getClients } from '@/app/actions/clients';
import { countries } from '@/utils/countries';

export default function EditProjectModal({ project, onClose, onSaved }) {
    const [clients, setClients] = useState([]);
    const [loading, setLoading] = useState(false);
    
    // Form fields initialized with project data
    const [title, setTitle] = useState(project.title || '');
    const [clientId, setClientId] = useState(project.client_id || '');
    const [projectManager, setProjectManager] = useState(project.project_manager || '');
    const [countryId, setCountryId] = useState(project.country || '');
    const [languageId, setLanguageId] = useState(project.language || '');
    const [categoryId, setCategoryId] = useState(project.category || '');
    const [description, setDescription] = useState(project.description || '');
    const [notes, setNotes] = useState(project.notes || '');
    const [dynamicThanks, setDynamicThanks] = useState(project.dynamic_thanks || false);
    const [loi, setLoi] = useState(project.loi || '');
    const [ir, setIr] = useState(project.ir || '');
    const [sampleSize, setSampleSize] = useState(project.sample_size || 0);
    const [clickQuota, setClickQuota] = useState(project.quota || 0);
    const [currency, setCurrency] = useState(project.currency || 'USD');
    const [projectCpi, setProjectCpi] = useState(project.cpi || '');
    const [supplierCpi, setSupplierCpi] = useState(project.supplier_cpi || '');
    const [startDate, setStartDate] = useState(project.start_date ? project.start_date.substring(0, 10) : '');
    const [endDate, setEndDate] = useState(project.end_date ? project.end_date.substring(0, 10) : '');
    const [status, setStatus] = useState(project.status || 'Draft');
    const [clientLink, setClientLink] = useState(project.client_link || '');

    const [completeUrl, setCompleteUrl] = useState(project.client_complete_url || '');
    const [terminateUrl, setTerminateUrl] = useState(project.client_terminate_url || '');
    const [quotaUrl, setQuotaUrl] = useState(project.client_quota_url || '');
    const [qualityUrl, setQualityUrl] = useState(project.client_quality_url || '');

    useEffect(() => {
        async function fetchClients() {
            const res = await getClients();
            if (res.success) setClients(res.data);
        }
        fetchClients();
    }, []);

    async function handleSubmit(e) {
        e.preventDefault();
        setLoading(true);
        
        const updateData = {
            title,
            client_id: clientId || null,
            project_manager: projectManager,
            country: countryId,
            language: languageId,
            category: categoryId,
            description,
            loi: loi ? parseInt(loi, 10) : null,
            ir: ir ? parseInt(ir, 10) : null,
            sample_size: sampleSize ? parseInt(sampleSize, 10) : null,
            quota: clickQuota ? parseInt(clickQuota, 10) : 0,
            currency,
            cpi: projectCpi ? parseFloat(projectCpi) : null,
            supplier_cpi: supplierCpi ? parseFloat(supplierCpi) : null,
            start_date: startDate || null,
            end_date: endDate || null,
            status,
            client_link: clientLink,
            client_complete_url: completeUrl,
            client_terminate_url: terminateUrl,
            client_quota_url: quotaUrl,
            notes,
            dynamic_thanks: dynamicThanks
        };

        const result = await updateProject(project.id, updateData);
        setLoading(false);
        if (result.success) {
            onSaved(result.data);
        } else {
            alert('Error: ' + result.error);
        }
    }

    return (
        <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)', overflowY: 'auto' }}>
            <div className="modal-dialog modal-xl">
                <div className="modal-content">
                    <div className="modal-header">
                        <h5 className="modal-title">Edit Project</h5>
                        <button type="button" className="close" onClick={onClose}>
                            <span>&times;</span>
                        </button>
                    </div>
                    <form onSubmit={handleSubmit}>
                        <div className="modal-body">
                            <div className="row">
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Client Name<span className="text-danger">*</span></label>
                                    <select className="form-control" required value={clientId} onChange={(e) => setClientId(e.target.value)}>
                                        <option value="">-- Select Client Name --</option>
                                        {clients.map(client => (
                                            <option key={client.id} value={client.id}>{client.name}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Project Name<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="text" value={title} onChange={e => setTitle(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Project Manager<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="text" value={projectManager} onChange={e => setProjectManager(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Project Country<span className="text-danger">*</span></label>
                                    <select className="form-control" required value={countryId} onChange={e => setCountryId(e.target.value)}>
                                        <option value="">-- Select Country --</option>
                                        {countries.map(c => (
                                            <option key={c.code} value={c.code}>{c.name}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Project Language<span className="text-danger">*</span></label>
                                    <select className="form-control" required value={languageId} onChange={e => setLanguageId(e.target.value)}>
                                        <option value="">-- Select Language --</option>
                                        <option value="EN">English</option>
                                        <option value="ES">Spanish</option>
                                        <option value="FR">French</option>
                                        <option value="DE">German</option>
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Project Category<span className="text-danger">*</span></label>
                                    <select className="form-control" required value={categoryId} onChange={e => setCategoryId(e.target.value)}>
                                        <option value="">-- Select Category --</option>
                                        <option value="B2B">B2B</option>
                                        <option value="B2C">B2C</option>
                                        <option value="Healthcare">Healthcare</option>
                                    </select>
                                </div>
                                
                                <div className="col-sm-12 form-group">
                                    <label className="control-label">Project Description</label>
                                    <textarea className="form-control" rows="3" value={description} onChange={e => setDescription(e.target.value)}></textarea>
                                </div>
                                <div className="col-sm-12 form-group">
                                    <label className="control-label">Notes</label>
                                    <textarea className="form-control" rows="3" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Maximum limit of characters 2000" maxLength={2000}></textarea>
                                </div>
                                
                                <div className="col-sm-12 form-group">
                                    <div className="custom-control custom-checkbox">
                                        <input type="checkbox" className="custom-control-input" id="dynamicThanksCheckModal" checked={dynamicThanks} onChange={e => setDynamicThanks(e.target.checked)} />
                                        <label className="custom-control-label" htmlFor="dynamicThanksCheckModal">Dynamic Thanks</label>
                                    </div>
                                </div>
                                
                                <div className="col-sm-6 col-md-3 form-group">
                                    <label className="control-label">LOI (Minute)<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="number" min="1" value={loi} onChange={e => setLoi(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-3 form-group">
                                    <label className="control-label">IR (%)<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="number" min="1" max="100" value={ir} onChange={e => setIr(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-3 form-group">
                                    <label className="control-label">Sample Size<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="number" min="1" value={sampleSize} onChange={e => setSampleSize(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-3 form-group">
                                    <label className="control-label">Respondent Click Quota<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="number" min="1" value={clickQuota} onChange={e => setClickQuota(e.target.value)} />
                                </div>
                                
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Currency<span className="text-danger">*</span></label>
                                    <select className="form-control" required value={currency} onChange={e => setCurrency(e.target.value)}>
                                        <option value="USD">USD</option>
                                        <option value="EUR">EUR</option>
                                        <option value="GBP">GBP</option>
                                        <option value="INR">INR</option>
                                    </select>
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Project CPI<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="number" step="0.01" value={projectCpi} onChange={e => setProjectCpi(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Supplier CPI<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="number" step="0.01" value={supplierCpi} onChange={e => setSupplierCpi(e.target.value)} />
                                </div>
                                
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Start Date<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
                                </div>
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">End Date<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
                                </div>
                                
                                <div className="col-sm-6 col-md-4 form-group">
                                    <label className="control-label">Project Status<span className="text-danger">*</span></label>
                                    <select className="form-control" required value={status} onChange={e => setStatus(e.target.value)}>
                                        <option value="Draft">Draft</option>
                                        <option value="Live">Live</option>
                                        <option value="Paused">Paused</option>
                                        <option value="Closed">Closed</option>
                                    </select>
                                </div>
                                <div className="col-sm-12 form-group">
                                    <label className="control-label">Client Survey Link (Destination)<span className="text-danger">*</span></label>
                                    <input className="form-control" required type="url" placeholder="https://..." value={clientLink} onChange={e => setClientLink(e.target.value)} />
                                </div>
                            </div>
                            
                            <h4 className="header-title mt-2 mb-3">Client Redirect URLs</h4>
                            <div className="row">
                                <div className="col-sm-6 form-group">
                                    <label className="control-label">Complete URL</label>
                                    <input className="form-control" type="url" placeholder="https://..." value={completeUrl} onChange={e => setCompleteUrl(e.target.value)} />
                                </div>
                                <div className="col-sm-6 form-group">
                                    <label className="control-label">Terminate URL</label>
                                    <input className="form-control" type="url" placeholder="https://..." value={terminateUrl} onChange={e => setTerminateUrl(e.target.value)} />
                                </div>
                                <div className="col-sm-6 form-group">
                                    <label className="control-label">Quota Full URL</label>
                                    <input className="form-control" type="url" placeholder="https://..." value={quotaUrl} onChange={e => setQuotaUrl(e.target.value)} />
                                </div>
                                <div className="col-sm-6 form-group">
                                    <label className="control-label">Quality Check URL</label>
                                    <input className="form-control" type="url" placeholder="https://..." value={qualityUrl} onChange={e => setQualityUrl(e.target.value)} />
                                </div>
                            </div>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
                            <button type="submit" className="btn btn-primary" disabled={loading}>
                                {loading ? "Saving..." : "Save Changes"}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}
