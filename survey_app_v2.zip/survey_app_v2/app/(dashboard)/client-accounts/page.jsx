"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { getPortalClients, createPortalClient, togglePortalClientStatus, deletePortalClient } from '@/app/actions/portalClients';
import { getClients } from '@/app/actions/clients';

export default function ClientAccounts() {
    const [accounts, setAccounts] = useState([]);
    const [clients, setClients] = useState([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    async function fetchAll() {
        setLoading(true);
        const [accRes, clientRes] = await Promise.all([getPortalClients(), getClients()]);
        if (accRes.success) setAccounts(accRes.data);
        if (clientRes.success) setClients(clientRes.data);
        setLoading(false);
    }

    useEffect(() => { fetchAll(); }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSaving(true);
        const formData = new FormData(e.target);
        const result = await createPortalClient(formData);
        setSaving(false);
        if (result.success) {
            alert("Client account saved!");
            e.target.reset();
            fetchAll();
        } else {
            alert("Error: " + result.error);
        }
    };

    const handleToggle = async (id, status) => {
        const result = await togglePortalClientStatus(id, status);
        if (result.success) fetchAll();
    };

    const handleDelete = async (id) => {
        if (!confirm("Delete this client account? They will no longer be able to log in.")) return;
        const result = await deletePortalClient(id);
        if (result.success) fetchAll();
    };

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item active">Client Accounts</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">
                        Client Portal Accounts <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal'}}>(v2 — live data)</span>
                        &nbsp;<a href="/client-portal/login" target="_blank" style={{fontSize: '12px'}}>🔗 Open Client Portal Login</a>
                    </h4>
                </div>
            </div>

            <div className="col-sm-12 mb-4">
                <div className="card">
                    <div className="card-body">
                        <h5 className="mb-3">Add / Update Client Account</h5>
                        <form onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-sm-3 form-group">
                                    <label>Client<span className="text-danger">*</span></label>
                                    <select name="client_id" className="form-control" required>
                                        <option value="">-- Select client --</option>
                                        {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                    </select>
                                </div>
                                <div className="col-sm-3 form-group">
                                    <label>Username<span className="text-danger">*</span></label>
                                    <input name="username" className="form-control" type="text" required placeholder="e.g. globalopine" />
                                </div>
                                <div className="col-sm-3 form-group">
                                    <label>Password<span className="text-danger">*</span></label>
                                    <input name="password" className="form-control" type="text" required placeholder="Set password" />
                                </div>
                                <div className="col-sm-3 form-group">
                                    <label>Extra Projects <span style={{fontWeight: 'normal', fontSize: '11px'}}>(optional, comma-separated project IDs)</span></label>
                                    <input name="extra_project_ids" className="form-control" type="text" placeholder="Only if extra project access needed" />
                                </div>
                            </div>
                            <p className="text-muted" style={{fontSize: '12px'}}>
                                Client select karte hi, us client ke saare projects (jo Projects tab mein is client se link hain) automatically portal mein dikh jaayenge.
                                "Extra Projects" sirf tab bharo jab koi project kisi doosre client se linked ho phir bhi is client ko dikhana ho.
                            </p>
                            <button type="submit" className="btn btn-primary" disabled={saving}>
                                {saving ? 'Saving...' : 'Save Client Account'}
                            </button>
                            <span className="text-muted ml-2" style={{fontSize: '12px'}}>⚠ Same username = password & projects will be updated</span>
                        </form>
                    </div>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card">
                    <div className="card-body">
                        <h5 className="mb-3">All Client Accounts</h5>
                        <div className="table-responsive">
                            <table className="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Client</th><th>Username</th><th>Status</th>
                                        <th>Last Login</th><th>Created</th><th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {loading ? (
                                        <tr><td colSpan="6" className="text-center">Loading...</td></tr>
                                    ) : accounts.length > 0 ? (
                                        accounts.map(a => (
                                            <tr key={a.id}>
                                                <td>{a.clients?.name || '-'}</td>
                                                <td>{a.username}</td>
                                                <td>
                                                    <span className={`badge ${a.status === 'active' ? 'badge-success' : 'badge-secondary'}`}>{a.status}</span>
                                                </td>
                                                <td>{a.last_login ? new Date(a.last_login).toLocaleString() : 'Never'}</td>
                                                <td>{new Date(a.created_at).toLocaleDateString()}</td>
                                                <td>
                                                    <button className="btn btn-sm btn-outline-secondary mr-1" onClick={() => handleToggle(a.id, a.status)}>
                                                        {a.status === 'active' ? 'Deactivate' : 'Activate'}
                                                    </button>
                                                    <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(a.id)}>Delete</button>
                                                </td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr><td colSpan="6" className="text-center">No Record Found !</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
