"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { getReconcileRecords, createReconcileRecord, updateReconcileStatus, deleteReconcileRecord, compareReconcileCsv } from '@/app/actions/reconcileBilling';
import { getProjects } from '@/app/actions/projects';

export default function BillingReconciliation() {
    const [records, setRecords] = useState([]);
    const [projects, setProjects] = useState([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    // Manual entry form state (for live diff/dispute preview)
    const [ourCompletes, setOurCompletes] = useState(0);
    const [clientAccepted, setClientAccepted] = useState(0);
    const [cpi, setCpi] = useState(0);

    // CSV comparison state
    const [csvProjectId, setCsvProjectId] = useState('');
    const [csvFile, setCsvFile] = useState(null);
    const [csvResult, setCsvResult] = useState(null);
    const [comparing, setComparing] = useState(false);

    async function fetchAll() {
        setLoading(true);
        const [recRes, projRes] = await Promise.all([getReconcileRecords(), getProjects()]);
        if (recRes.success) setRecords(recRes.data);
        if (projRes.success) setProjects(projRes.data);
        setLoading(false);
    }

    useEffect(() => { fetchAll(); }, []);

    const difference = ourCompletes - clientAccepted;
    const disputeAmount = difference * cpi;

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSaving(true);
        const formData = new FormData(e.target);
        const result = await createReconcileRecord(formData);
        setSaving(false);
        if (result.success) {
            alert("Reconcile record saved!");
            e.target.reset();
            setOurCompletes(0);
            setClientAccepted(0);
            setCpi(0);
            fetchAll();
        } else {
            alert("Error: " + result.error);
        }
    };

    const handleDelete = async (id) => {
        if (!confirm("Delete this reconcile record?")) return;
        const result = await deleteReconcileRecord(id);
        if (result.success) fetchAll();
    };

    const handleCloseDispute = async (id) => {
        const result = await updateReconcileStatus(id, 'closed', '');
        if (result.success) fetchAll();
    };

    // Simple CSV parser (no external library) — expects columns: uid,status
    const parseCsv = (text) => {
        const lines = text.trim().split('\n').filter(Boolean);
        const rows = [];
        for (let i = 0; i < lines.length; i++) {
            const parts = lines[i].split(',').map(p => p.trim().replace(/^"|"$/g, ''));
            if (i === 0 && parts[0].toLowerCase().includes('uid')) continue; // skip header row
            if (parts[0]) rows.push({ uid: parts[0], status: parts[1] || '' });
        }
        return rows;
    };

    const handleCompareCsv = async () => {
        if (!csvProjectId || !csvFile) {
            alert("Select a project and choose a CSV file first.");
            return;
        }
        setComparing(true);
        const text = await csvFile.text();
        const rows = parseCsv(text);
        const result = await compareReconcileCsv(csvProjectId, rows);
        setComparing(false);
        if (result.success) {
            setCsvResult(result.data);
        } else {
            alert("Error: " + result.error);
        }
    };

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item active">Billing Reconciliation</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Billing Reconciliation <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal'}}>(v2 — live data)</span></h4>
                </div>
            </div>

            {/* Manual Entry Form */}
            <div className="col-sm-12 mb-4">
                <div className="card">
                    <div className="card-body">
                        <h5 className="mb-3">New Dispute Record (Manual Entry)</h5>
                        <form onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-sm-4 form-group">
                                    <label>Project</label>
                                    <select name="project_id" className="form-control">
                                        <option value="">-- Select Project (optional) --</option>
                                        {projects.map(p => <option key={p.id} value={p.id}>{p.title}</option>)}
                                    </select>
                                </div>
                                <div className="col-sm-4 form-group">
                                    <label>Client Name</label>
                                    <input name="client_name" className="form-control" type="text" />
                                </div>
                                <div className="col-sm-4 form-group">
                                    <label>Period</label>
                                    <input name="period" className="form-control" type="text" placeholder="e.g. Aug 2026" />
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-sm-3 form-group">
                                    <label>We Sent</label>
                                    <input name="we_sent" className="form-control" type="number" min="0" defaultValue="0" />
                                </div>
                                <div className="col-sm-3 form-group">
                                    <label>Our Completes</label>
                                    <input name="our_completes" className="form-control" type="number" min="0" defaultValue="0"
                                        onChange={(e) => setOurCompletes(parseInt(e.target.value) || 0)} />
                                </div>
                                <div className="col-sm-3 form-group">
                                    <label>Client Accepted</label>
                                    <input name="client_accepted" className="form-control" type="number" min="0" defaultValue="0"
                                        onChange={(e) => setClientAccepted(parseInt(e.target.value) || 0)} />
                                </div>
                                <div className="col-sm-3 form-group">
                                    <label>Client Rejected</label>
                                    <input name="client_rejected" className="form-control" type="number" min="0" defaultValue="0" />
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-sm-6 form-group">
                                    <label>Reject Reason</label>
                                    <textarea name="reject_reason" className="form-control" rows="2" placeholder="e.g. Bad quality, duplicate IPs, low LOI..."></textarea>
                                </div>
                                <div className="col-sm-3 form-group">
                                    <label>CPI</label>
                                    <input name="cpi" className="form-control" type="number" step="0.01" min="0" defaultValue="0"
                                        onChange={(e) => setCpi(parseFloat(e.target.value) || 0)} />
                                </div>
                                <div className="col-sm-3 form-group">
                                    <label>Currency</label>
                                    <select name="currency" className="form-control" defaultValue="USD">
                                        <option value="USD">USD</option>
                                        <option value="INR">INR</option>
                                        <option value="EUR">EUR</option>
                                        <option value="GBP">GBP</option>
                                    </select>
                                </div>
                            </div>

                            {(ourCompletes > 0 || clientAccepted > 0) && (
                                <div className={`alert ${difference > 0 ? 'alert-danger' : 'alert-success'}`}>
                                    Difference: <strong>{difference > 0 ? '+' : ''}{difference}</strong> &nbsp;|&nbsp;
                                    Dispute Amount: <strong>{disputeAmount.toFixed(2)}</strong>
                                    {difference > 0 && <span> — Hamara data zyada hai, proof attach karo dispute ke liye</span>}
                                </div>
                            )}

                            <div className="row">
                                <div className="col-sm-6 form-group">
                                    <label>Status</label>
                                    <select name="status" className="form-control" defaultValue="open">
                                        <option value="open">Open</option>
                                        <option value="closed">Closed</option>
                                    </select>
                                </div>
                                <div className="col-sm-6 form-group">
                                    <label>Notes</label>
                                    <input name="notes" className="form-control" type="text" placeholder="Additional context..." />
                                </div>
                            </div>

                            <button type="submit" className="btn btn-primary" disabled={saving}>
                                {saving ? 'Saving...' : 'Save Record'}
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            {/* CSV Comparison */}
            <div className="col-sm-12 mb-4">
                <div className="card">
                    <div className="card-body">
                        <h5 className="mb-3">Compare Client's CSV Against Our Data</h5>
                        <p className="text-muted" style={{fontSize: '12px'}}>CSV format: first column = respondent UID, second column = status (header row optional).</p>
                        <div className="row align-items-end mb-3">
                            <div className="col-sm-4 form-group mb-0">
                                <label>Project</label>
                                <select className="form-control" value={csvProjectId} onChange={(e) => setCsvProjectId(e.target.value)}>
                                    <option value="">-- Select Project --</option>
                                    {projects.map(p => <option key={p.id} value={p.id}>{p.title}</option>)}
                                </select>
                            </div>
                            <div className="col-sm-4 form-group mb-0">
                                <label>Client's CSV File</label>
                                <input type="file" accept=".csv" className="form-control" onChange={(e) => setCsvFile(e.target.files[0])} />
                            </div>
                            <div className="col-sm-4 form-group mb-0">
                                <button className="btn btn-info" onClick={handleCompareCsv} disabled={comparing}>
                                    {comparing ? 'Comparing...' : 'Compare'}
                                </button>
                            </div>
                        </div>

                        {csvResult && (
                            <>
                                <div className="row mb-3">
                                    <div className="col-sm-4"><span className="badge badge-success">Matched: {csvResult.summary.matched}</span></div>
                                    <div className="col-sm-4"><span className="badge badge-warning">Mismatched: {csvResult.summary.mismatched}</span></div>
                                    <div className="col-sm-4"><span className="badge badge-danger">Missing (not in our data): {csvResult.summary.missing}</span></div>
                                </div>
                                <div className="table-responsive" style={{maxHeight: '300px', overflowY: 'auto'}}>
                                    <table className="table table-sm table-striped">
                                        <thead>
                                            <tr><th>UID</th><th>Client Status</th><th>Our Status</th><th>Result</th></tr>
                                        </thead>
                                        <tbody>
                                            {csvResult.rows.map((r, i) => (
                                                <tr key={i}>
                                                    <td>{r.uid}</td>
                                                    <td>{r.clientStatus}</td>
                                                    <td>{r.ourStatus}</td>
                                                    <td>
                                                        <span className={`badge ${r.result === 'Matched' ? 'badge-success' : r.result === 'Mismatched' ? 'badge-warning' : 'badge-danger'}`}>
                                                            {r.result}
                                                        </span>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </>
                        )}
                    </div>
                </div>
            </div>

            {/* Existing Records List */}
            <div className="col-sm-12">
                <div className="card">
                    <div className="card-body">
                        <h5 className="mb-3">All Dispute Records</h5>
                        <div className="table-responsive">
                            <table className="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Project</th><th>Client</th><th>Period</th><th>We Sent</th>
                                        <th>Client Accepted</th><th>Difference</th><th>Dispute Amount</th>
                                        <th>Status</th><th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {loading ? (
                                        <tr><td colSpan="9" className="text-center">Loading...</td></tr>
                                    ) : records.length > 0 ? (
                                        records.map(r => (
                                            <tr key={r.id}>
                                                <td>{r.projects?.title || '-'}</td>
                                                <td>{r.client_name || '-'}</td>
                                                <td>{r.period || '-'}</td>
                                                <td>{r.we_sent}</td>
                                                <td>{r.client_accepted}</td>
                                                <td style={{color: r.difference > 0 ? '#dc3545' : '#28a745'}}>{r.difference > 0 ? '+' : ''}{r.difference}</td>
                                                <td>{r.currency} {Number(r.dispute_amount).toFixed(2)}</td>
                                                <td>
                                                    <span className={`badge ${r.status === 'closed' ? 'badge-secondary' : 'badge-warning'}`}>{r.status}</span>
                                                </td>
                                                <td>
                                                    {r.status !== 'closed' && (
                                                        <button className="btn btn-sm btn-outline-success mr-1" onClick={() => handleCloseDispute(r.id)}>Close</button>
                                                    )}
                                                    <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(r.id)}>Delete</button>
                                                </td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr><td colSpan="9" className="text-center">No Record Found !</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
