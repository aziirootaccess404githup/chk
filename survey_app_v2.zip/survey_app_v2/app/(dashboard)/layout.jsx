import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';
import RightSidebar from '@/components/RightSidebar';
import { createClient } from '@/utils/supabase/server';
import { createAdminClient } from '@/utils/supabase/admin';

export default async function DashboardLayout({ children }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  
  let initialProfile = { full_name: 'Unknown User', role: 'manager' };
  
  if (user) {
    const supabaseAdmin = createAdminClient();
    const { data } = await supabaseAdmin
      .from('profiles')
      .select('full_name, role')
      .eq('id', user.id)
      .single();
      
    if (data) {
      initialProfile = data;
    } else {
      const rawUsername = user.user_metadata?.username || user.email?.replace('@exazonresearch.com', '') || 'User';
      initialProfile = { full_name: rawUsername, role: 'manager' };
    }
  }

  return (
    <div className="page">
        <Sidebar />
        <div className="main-content app-content">
        <Header initialProfile={initialProfile} />
        {children}
        </div>
        <RightSidebar />
    </div>
  );
}
