"use client";
import React, { useState } from 'react';
import Link from 'next/link';
import { processUID } from '@/app/actions/crypto';

export default function EncryptionLookup() {
    const [inputValue, setInputValue] = useState("");
    const [original, setOriginal] = useState("");
    const [encrypted, setEncrypted] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    async function handleSubmit(e) {
        e.preventDefault();
        setLoading(true);
        setError("");
        setOriginal("");
        setEncrypted("");

        const result = await processUID(inputValue);
        if (result.success) {
            setOriginal(result.original);
            setEncrypted(result.encrypted);
        } else {
            setError(result.error || "An error occurred during processing.");
        }
        setLoading(false);
    }

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item">Support</li>
                            <li className="breadcrumb-item active">Encryption Lookup</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Encryption Lookup Tool</h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <p className="text-muted">Enter a raw UID or an encrypted UID string. The tool will automatically detect and convert it.</p>
                        
                        <form onSubmit={handleSubmit} className="mb-4">
                            <div className="row align-items-end">
                                <div className="col-md-8 form-group mb-0">
                                    <label className="control-label">UID or Encrypted String</label>
                                    <input 
                                        type="text" 
                                        className="form-control" 
                                        placeholder="Enter UID (e.g. USER-123) or Encrypted string..."
                                        value={inputValue}
                                        onChange={e => setInputValue(e.target.value)}
                                        required 
                                    />
                                </div>
                                <div className="col-md-4">
                                    <button type="submit" className="btn btn-primary btn-block" disabled={loading}>
                                        {loading ? "Processing..." : "Lookup / Convert"}
                                    </button>
                                </div>
                            </div>
                            {error && <div className="alert alert-danger mt-3">{error}</div>}
                        </form>

                        <hr />

                        <div className="row mt-4">
                            <div className="col-md-6 form-group">
                                <label className="control-label">Original UID (Raw)</label>
                                <div className="input-group">
                                    <input 
                                        type="text" 
                                        className="form-control" 
                                        readOnly 
                                        value={original}
                                        style={{ backgroundColor: '#f8f9fa', fontFamily: 'monospace' }} 
                                    />
                                    <div className="input-group-append">
                                        <button className="btn btn-outline-secondary" type="button" onClick={() => navigator.clipboard.writeText(original)} disabled={!original}>
                                            <i className="fas fa-copy"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-6 form-group">
                                <label className="control-label">Encrypted UID (Safe)</label>
                                <div className="input-group">
                                    <input 
                                        type="text" 
                                        className="form-control" 
                                        readOnly 
                                        value={encrypted}
                                        style={{ backgroundColor: '#f8f9fa', fontFamily: 'monospace' }} 
                                    />
                                    <div className="input-group-append">
                                        <button className="btn btn-outline-secondary" type="button" onClick={() => navigator.clipboard.writeText(encrypted)} disabled={!encrypted}>
                                            <i className="fas fa-copy"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    );
}
