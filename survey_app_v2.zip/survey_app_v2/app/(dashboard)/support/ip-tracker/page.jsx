"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { searchIpActivity, blockIP } from '@/app/actions/ipTracker';

export default function IPTracker() {
    const [ipSearch, setIpSearch] = useState("");
    const [comment, setComment] = useState("");
    const [searchTerm, setSearchTerm] = useState("");
    const [ipData, setIpData] = useState([]);
    const [loading, setLoading] = useState(true);

    async function fetchData(ip) {
        setLoading(true);
        const result = await searchIpActivity(ip || null);
        if (result.success) setIpData(result.data);
        setLoading(false);
    }

    useEffect(() => {
        fetchData(null);
    }, []);

    const handleSearchIP = () => {
        fetchData(ipSearch);
    };

    const handleBlockIP = async () => {
        if (!ipSearch || !comment) {
            alert("Please provide both IP Address and Comment to block.");
            return;
        }
        const result = await blockIP(ipSearch, comment);
        if (result.success) {
            alert(`IP ${ipSearch} has been blocked.`);
            setComment("");
            fetchData(ipSearch);
        } else {
            alert("Error blocking IP: " + result.error);
        }
    };

    const filteredData = ipData.filter(item =>
        !searchTerm ||
        item.ip.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.pName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.sName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.identifier.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="row mt-3">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item">Support</li>
                            <li className="breadcrumb-item active">IP Tracker</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">IP Tracker <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal'}}>(v2 — live data)</span></h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <div className="row mb-3">
                            <div className="col-sm-12">
                                <ul className="linksTo d-flex justify-content-end">
                                    <li>
                                        <button className="btn btn-primary" title="Refresh" onClick={() => fetchData(ipSearch)}>
                                            <i className="fa fa-refresh" aria-hidden="true"></i>
                                        </button>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div className="row mb-4">
                            <div className="col-md-4 col-sm-12 mb-3 mb-md-0">
                                <div className="row align-items-end">
                                    <div className="col-md-9 form-group mb-0">
                                        <label className="control-label font-weight-bold">Search IP</label>
                                        <div className="position-relative">
                                            <input
                                                type="text"
                                                className="form-control"
                                                placeholder="xxx.xxx.xxx.xxx"
                                                style={{fontSize: "18px"}}
                                                value={ipSearch}
                                                onChange={(e) => setIpSearch(e.target.value)}
                                            />
                                            {ipSearch && (
                                                <a
                                                    className="clearCrossIcon"
                                                    onClick={() => { setIpSearch(""); fetchData(null); }}
                                                    style={{position: 'absolute', right: '10px', top: '10px', cursor: 'pointer', zIndex: 10}}
                                                >
                                                    <i className="fa fa-times-circle" aria-hidden="true"></i>
                                                </a>
                                            )}
                                        </div>
                                    </div>
                                    <div className="col-md-3 form-group mb-0">
                                        <button className="btn btn-primary w-100" onClick={handleSearchIP}>Search</button>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-8 col-sm-12">
                                <div className="row align-items-end justify-content-md-end">
                                    <div className="col-md-6 form-group mb-0">
                                        <label className="control-label font-weight-bold">Comment</label>
                                        <input
                                            type="text"
                                            className="form-control"
                                            placeholder="Reason for block"
                                            value={comment}
                                            onChange={(e) => setComment(e.target.value)}
                                        />
                                    </div>
                                    <div className="col-md-2 form-group mb-0">
                                        <button className="btn btn-danger w-100" onClick={handleBlockIP}>Block</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="row mb-3 align-items-center">
                            <div className="col-sm-6 col-md-6 col-lg-6">
                                <div className="pagesize d-flex align-items-center">
                                    <label className="mb-0 mr-2">Page Size:</label>
                                    <select className="form-control w-auto d-inline-block">
                                        <option value="10">10</option>
                                        <option value="30">30</option>
                                        <option value="50">50</option>
                                        <option value="100">100</option>
                                    </select>
                                </div>
                            </div>
                            <div className="col-sm-6 col-md-6 col-lg-6">
                                <div className="row justify-content-end">
                                    <div className="col-sm-12 col-md-6 col-lg-6">
                                        <div className="app-search-box">
                                            <div className="input-group">
                                                <input
                                                    type="text"
                                                    className="form-control"
                                                    placeholder="Search..."
                                                    value={searchTerm}
                                                    onChange={(e) => setSearchTerm(e.target.value)}
                                                />
                                                {searchTerm && (
                                                    <a className="clearCrossIcon" onClick={() => setSearchTerm("")} style={{cursor: 'pointer'}}>
                                                        <i className="fa fa-times-circle" aria-hidden="true"></i>
                                                    </a>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="responsive-table-plugin">
                            <div className="table-responsive">
                                <table className="table table-striped table-bordered">
                                    <thead className="thead-light">
                                        <tr>
                                            <th>S.No.</th>
                                            <th>IP Address</th>
                                            <th>Project</th>
                                            <th>Supplier</th>
                                            <th>Identifier</th>
                                            <th>Status</th>
                                            <th>Quality Score</th>
                                            <th>LOI (sec)</th>
                                            <th>Geo Location</th>
                                            <th>Device</th>
                                            <th>Browser</th>
                                            <th>Date</th>
                                            <th>Block Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {loading ? (
                                            <tr><td colSpan="12" className="text-center">Loading...</td></tr>
                                        ) : filteredData.length > 0 ? (
                                            filteredData.map((item, index) => (
                                                <tr key={item.id}>
                                                    <td>{index + 1}</td>
                                                    <td>{item.ip}</td>
                                                    <td>{item.pName}</td>
                                                    <td>{item.sName}</td>
                                                    <td>{item.identifier}</td>
                                                    <td>
                                                        <span className={`badge ${item.status === 'Complete' ? 'badge-success' : item.status === 'Started' ? 'badge-info' : 'badge-warning'}`}>
                                                            {item.status}
                                                        </span>
                                                    </td>
                                                    <td>{item.qualityScore ?? '-'}</td>
                                                    <td>{item.loiSeconds ?? '-'}</td>
                                                    <td>{item.city ? `${item.city}, ${item.country}` : item.country}</td>
                                                    <td>{item.device}</td>
                                                    <td>{item.browser}</td>
                                                    <td>{item.date}</td>
                                                    <td>
                                                        {item.isBlocked ? (
                                                            <span className="badge badge-danger">Blocked</span>
                                                        ) : (
                                                            <span className="badge badge-success">Not Blocked</span>
                                                        )}
                                                    </td>
                                                </tr>
                                            ))
                                        ) : (
                                            <tr><td colSpan="12" className="text-center">No Record Found !</td></tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
