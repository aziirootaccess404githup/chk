"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { getBlockedIps, unblockIP } from '@/app/actions/ipTracker';

export default function BlockedIPs() {
    const [searchTerm, setSearchTerm] = useState("");
    const [blockedData, setBlockedData] = useState([]);
    const [loading, setLoading] = useState(true);

    async function fetchData() {
        setLoading(true);
        const result = await getBlockedIps();
        if (result.success) setBlockedData(result.data);
        setLoading(false);
    }

    useEffect(() => {
        fetchData();
    }, []);

    const handleUnblock = async (ip) => {
        const result = await unblockIP(ip);
        if (result.success) {
            fetchData();
        } else {
            alert("Error unblocking IP: " + result.error);
        }
    };

    const filteredData = blockedData.filter(item =>
        !searchTerm ||
        item.ip_address.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (item.comment || '').toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="row mt-3">
            <div className="col-12">
                <div className="page-title-box mt-3">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item">Support</li>
                            <li className="breadcrumb-item active">Blocked IPs</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Blocked IP List <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal'}}>(v2 — live data)</span></h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <div className="row mb-4">
                            <div className="col-sm-12">
                                <ul className="linksTo d-flex justify-content-end mb-0">
                                    <li>
                                        <button className="btn btn-primary" title="Refresh" onClick={fetchData}>
                                            <i className="fa fa-refresh" aria-hidden="true"></i> Refresh
                                        </button>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div className="row mb-3 align-items-center">
                            <div className="col-sm-6 col-md-6 col-lg-6">
                                <div className="pagesize d-flex align-items-center">
                                    <label className="mb-0 mr-2">Page Size:</label>
                                    <select className="form-control w-auto d-inline-block">
                                        <option value="10">10</option>
                                        <option value="30">30</option>
                                        <option value="50">50</option>
                                        <option value="100">100</option>
                                    </select>
                                </div>
                            </div>
                            <div className="col-sm-6 col-md-6 col-lg-6">
                                <div className="row justify-content-end">
                                    <div className="col-sm-12 col-md-8 col-lg-6">
                                        <div className="app-search-box">
                                            <div className="input-group">
                                                <input
                                                    type="text"
                                                    className="form-control"
                                                    placeholder="Search..."
                                                    value={searchTerm}
                                                    onChange={(e) => setSearchTerm(e.target.value)}
                                                />
                                                {searchTerm && (
                                                    <a className="clearCrossIcon" onClick={() => setSearchTerm("")} style={{cursor: 'pointer'}}>
                                                        <i className="fa fa-times-circle" aria-hidden="true"></i>
                                                    </a>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="responsive-table-plugin">
                            <div className="table-responsive">
                                <table className="table table-striped table-bordered">
                                    <thead className="thead-light">
                                        <tr>
                                            <th>S.No.</th>
                                            <th>IP</th>
                                            <th>Block Date</th>
                                            <th>Comments</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {loading ? (
                                            <tr><td colSpan="5" className="text-center">Loading...</td></tr>
                                        ) : filteredData.length > 0 ? (
                                            filteredData.map((item, index) => (
                                                <tr key={item.id}>
                                                    <td>{index + 1}</td>
                                                    <td><strong>{item.ip_address}</strong></td>
                                                    <td>{new Date(item.blocked_at).toLocaleString()}</td>
                                                    <td>{item.comment || '-'}</td>
                                                    <td>
                                                        <button
                                                            className="btn btn-sm btn-outline-danger"
                                                            onClick={() => handleUnblock(item.ip_address)}
                                                            title="UnBlock"
                                                        >
                                                            UnBlock
                                                        </button>
                                                    </td>
                                                </tr>
                                            ))
                                        ) : (
                                            <tr>
                                                <td colSpan="5" className="text-center">No Records Found</td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
