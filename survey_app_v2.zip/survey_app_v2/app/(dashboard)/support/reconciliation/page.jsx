"use client";
import React, { useState } from 'react';
import Link from 'next/link';
import { searchReconciliation, reconcileLogs } from '@/app/actions/reconciliation';

export default function Reconciliation() {
    const [identifiers, setIdentifiers] = useState("");
    const [searchTerm, setSearchTerm] = useState("");
    const [results, setResults] = useState([]);
    const [selected, setSelected] = useState({});
    const [loading, setLoading] = useState(false);
    const [reconciling, setReconciling] = useState(false);

    const handleSearch = async () => {
        if (!identifiers.trim()) {
            alert("Please enter identifiers to search.");
            return;
        }
        setLoading(true);
        const result = await searchReconciliation(identifiers);
        setLoading(false);
        if (result.success) {
            setResults(result.data);
            setSelected({});
        } else {
            alert("Error: " + result.error);
        }
    };

    const handleClear = () => {
        setIdentifiers("");
        setResults([]);
        setSelected({});
    };

    const handleSelect = (id) => {
        setSelected({ ...selected, [id]: !selected[id] });
    };

    const handleReconcile = async () => {
        const logIds = Object.keys(selected).filter(id => selected[id]);
        if (logIds.length === 0) {
            alert("Select at least one record first.");
            return;
        }
        const newStatus = prompt("Set status to (Complete / Terminate / OverQuota / SecurityFail):", "Complete");
        if (!newStatus) return;
        setReconciling(true);
        const result = await reconcileLogs(logIds, newStatus.trim());
        setReconciling(false);
        if (result.success) {
            alert("Reconciled successfully.");
            handleSearch();
        } else {
            alert("Error: " + result.error);
        }
    };

    const filteredResults = results.filter(item =>
        !searchTerm ||
        item.pName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.sName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.uid.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="row">
            <div className="col-12">
                <div className="page-title-box">
                    <div className="page-title-right">
                        <ol className="breadcrumb m-0">
                            <li className="breadcrumb-item"><Link href="/">Home</Link></li>
                            <li className="breadcrumb-item">Support</li>
                            <li className="breadcrumb-item active">Reconciliation</li>
                        </ol>
                    </div>
                    <h4 className="page-title tb-ttl">Reconciliation <span style={{fontSize: '11px', color: '#28a745', fontWeight: 'normal'}}>(v2 — live data)</span></h4>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card border-top-left-radius">
                    <div className="card-body">
                        <div className="row mb-4">
                            <div className="col-md-6 form-group">
                                <label className="control-label font-weight-bold">Search Identifiers</label>
                                <textarea
                                    className="form-control"
                                    rows="4"
                                    value={identifiers}
                                    onChange={(e) => setIdentifiers(e.target.value)}
                                    placeholder="Enter respondent identifiers separated by comma or new line"
                                ></textarea>
                            </div>
                            <div className="col-md-6 form-group d-flex align-items-end">
                                <div className="d-flex gap-2" style={{gap: '10px'}}>
                                    <button className="btn btn-primary" onClick={handleSearch} disabled={loading}>
                                        {loading ? 'Searching...' : 'Search'}
                                    </button>
                                    <button className="btn btn-secondary" onClick={handleClear}>Clear</button>
                                    <button className="btn btn-success" onClick={handleReconcile} disabled={reconciling}>
                                        {reconciling ? 'Reconciling...' : 'Reconcile'}
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div className="row mb-3 align-items-center">
                            <div className="col-sm-6 col-md-6 col-lg-6">
                                <div className="pagesize d-flex align-items-center">
                                    <label className="mb-0 mr-2">Page Size:</label>
                                    <select className="form-control w-auto d-inline-block">
                                        <option value="10">10</option>
                                        <option value="30">30</option>
                                        <option value="50">50</option>
                                        <option value="100">100</option>
                                    </select>
                                </div>
                            </div>
                            <div className="col-sm-6 col-md-6 col-lg-6">
                                <div className="row justify-content-end">
                                    <div className="col-sm-12 col-md-6 col-lg-6">
                                        <div className="app-search-box">
                                            <div className="input-group">
                                                <input
                                                    type="text"
                                                    className="form-control"
                                                    placeholder="Search..."
                                                    value={searchTerm}
                                                    onChange={(e) => setSearchTerm(e.target.value)}
                                                />
                                                {searchTerm && (
                                                    <a className="clearCrossIcon" onClick={() => setSearchTerm("")} style={{cursor: 'pointer'}}>
                                                        <i className="fa fa-times-circle" aria-hidden="true"></i>
                                                    </a>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="responsive-table-plugin">
                            <div className="table-responsive">
                                <table className="table table-striped table-bordered">
                                    <thead className="thead-light">
                                        <tr>
                                            <th>S.No.</th>
                                            <th>Select</th>
                                            <th>Project</th>
                                            <th>Supplier</th>
                                            <th>Identifier</th>
                                            <th>Status</th>
                                            <th>Locked</th>
                                            <th>Date</th>
                                            <th>IP</th>
                                            <th>Quality Score</th>
                                            <th>Flags</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {filteredResults.length > 0 ? (
                                            filteredResults.map((item, index) => (
                                                <tr key={item.id}>
                                                    <td>{index + 1}</td>
                                                    <td><input type="checkbox" checked={!!selected[item.id]} onChange={() => handleSelect(item.id)} /></td>
                                                    <td>{item.pName}</td>
                                                    <td>{item.sName}</td>
                                                    <td>{item.uid}</td>
                                                    <td>
                                                        <span className={`badge ${item.status === 'Complete' ? 'badge-success' : 'badge-secondary'}`}>
                                                            {item.status}
                                                        </span>
                                                    </td>
                                                    <td>{item.statusLocked ? '🔒' : '—'}</td>
                                                    <td>{item.date}</td>
                                                    <td>{item.ip}</td>
                                                    <td>{item.qualityScore ?? '-'}</td>
                                                    <td>
                                                        {item.isDuplicate && <span className="badge badge-warning mr-1">Dup</span>}
                                                        {item.isSpeeder && <span className="badge badge-warning">Speeder</span>}
                                                    </td>
                                                </tr>
                                            ))
                                        ) : (
                                            <tr>
                                                <td colSpan="11" className="text-center">
                                                    {loading ? 'Searching...' : 'No records — search identifiers above'}
                                                </td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
