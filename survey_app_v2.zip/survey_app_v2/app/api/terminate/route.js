import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/utils/supabase';

export async function GET(request) {
    const { searchParams } = new URL(request.url);
    const pid = searchParams.get('pid') || searchParams.get('uid');

    if (!pid) {
        return new NextResponse("Missing tracking ID.", { status: 400 });
    }

    try {
        // 1. Find the tracking log
        const { data: logs, error: logError } = await supabaseAdmin
            .from('tracking_logs')
            .select('id, supplier_id')
            .eq('respondent_uid', pid)
            .order('started_at', { ascending: false })
            .limit(1);

        if (logError || !logs || logs.length === 0) {
            return new NextResponse("Invalid tracking ID.", { status: 404 });
        }

        const log = logs[0];

        // 2. Update the tracking log
        await supabaseAdmin
            .from('tracking_logs')
            .update({
                status: 'Terminated',
                completed_at: new Date().toISOString()
            })
            .eq('id', log.id);

        // 3. Find supplier return URL if applicable
        if (log.supplier_id) {
            const { data: supplier } = await supabaseAdmin
                .from('suppliers')
                .select('terminate_url')
                .eq('id', log.supplier_id)
                .single();

            if (supplier && supplier.terminate_url) {
                const returnUrl = supplier.terminate_url.replace(/\[PID\]/g, pid);
                return NextResponse.redirect(returnUrl, 302);
            }
        }

        // 4. Fallback default success
        return new NextResponse("Unfortunately, you did not qualify for this survey.", { status: 200 });

    } catch (error) {
        console.error("Terminate Route Error:", error);
        return new NextResponse("An error occurred processing the termination.", { status: 500 });
    }
}
