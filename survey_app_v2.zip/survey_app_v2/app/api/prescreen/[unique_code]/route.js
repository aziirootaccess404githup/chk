import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/utils/supabase';

export async function GET(request, { params }) {
    const { unique_code } = await params;

    try {
        // Look up mapping to get project_id
        const { data: mapping, error: mappingError } = await supabaseAdmin
            .from('project_supplier_mappings')
            .select('project_id, projects ( title, status )')
            .eq('unique_code', unique_code)
            .single();

        if (mappingError || !mapping) {
            return NextResponse.json({ success: false, error: 'Invalid survey link.' }, { status: 404 });
        }

        // Fetch prescreen questions for this project
        const { data: questions, error: questionsError } = await supabaseAdmin
            .from('prescreen_questions')
            .select('*')
            .eq('project_id', mapping.project_id)
            .order('created_at', { ascending: true });

        if (questionsError) throw questionsError;

        return NextResponse.json({
            success: true,
            questions: questions || [],
            projectTitle: mapping.projects?.title || 'Survey',
            projectId: mapping.project_id,
        });

    } catch (error) {
        console.error('Prescreen API error:', error);
        return NextResponse.json({ success: false, error: 'Internal Server Error' }, { status: 500 });
    }
}
