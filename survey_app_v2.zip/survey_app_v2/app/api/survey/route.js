import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/utils/supabase';
import { encryptUID } from '@/utils/encryption';
import { getGeo, getDevice, getBrowser } from '@/utils/geoDevice';
import { sendTelegramAlert } from '@/utils/telegramAlert';

// Helper: build the correct public base URL using Nginx-forwarded headers
function getBaseUrl(request) {
    const host = request.headers.get('host') || 'your-domain.com';
    const proto = request.headers.get('x-forwarded-proto') || 'https';
    return `${proto}://${host}`;
}

export async function GET(request) {
    const { searchParams } = new URL(request.url);
    
    // Example URL: /api/survey?project_id=uuid&supplier_id=uuid&pid=12345
    const projectId = searchParams.get('project_id');
    const supplierId = searchParams.get('supplier_id');
    const pid = searchParams.get('pid') || searchParams.get('uid'); // Fallback to uid just in case

    // Basic validation
    if (!projectId || !pid) {
        return NextResponse.json({ error: "Missing required tracking parameters: project_id or pid." }, { status: 400 });
    }

    try {
        // 1. Fetch the project to get the actual client survey link
        const { data: project, error: projectError } = await supabaseAdmin
            .from('projects')
            .select('client_link, status, encrypt_uid')
            .eq('id', projectId)
            .single();

        if (projectError || !project) {
            return NextResponse.json({ error: "Project not found." }, { status: 404 });
        }

        // 2. Check if project is Live
        if (project.status !== 'Live') {
            return NextResponse.redirect(`${getBaseUrl(request)}/survey-paused`);
        }

        if (!project.client_link) {
            return NextResponse.json({ error: "Survey link is not configured." }, { status: 500 });
        }

        // Capture IP early for the block-list check.
        const ip = request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'Unknown IP';

        // Blocked-IP check (IP Tracker's "Block" button)
        if (ip && ip !== 'Unknown IP') {
            const { data: blockedEntry } = await supabaseAdmin
                .from('blocked_ips')
                .select('ip_address')
                .eq('ip_address', ip.split(',')[0].trim())
                .maybeSingle();
            if (blockedEntry) {
                return NextResponse.json({ error: "Access denied." }, { status: 403 });
            }
        }

        // 2.5 Check Supplier Traffic Controls (if supplierId is provided)
        if (supplierId) {
            const { data: mapping, error: mappingError } = await supabaseAdmin
                .from('project_supplier_mappings')
                .select('allow_traffic, click_quota, suppliers ( status )')
                .eq('project_id', projectId)
                .eq('supplier_id', supplierId)
                .single();

            if (mapping) {
                // Global vendor-pause: supplier.status blocks ALL projects for
                // that supplier at once, checked before the per-project flag.
                const supplierStatus = mapping.suppliers?.status;
                if (supplierStatus && supplierStatus !== 'Active') {
                    return NextResponse.json({ error: "This supplier is currently paused." }, { status: 403 });
                }

                if (mapping.allow_traffic === false) {
                    return NextResponse.json({ error: "Survey is currently closed for this supplier." }, { status: 403 });
                }

                if (mapping.click_quota > 0) {
                    const { count, error: countError } = await supabaseAdmin
                        .from('tracking_logs')
                        .select('*', { count: 'exact', head: true })
                        .eq('project_id', projectId)
                        .eq('supplier_id', supplierId);
                        
                    if (count >= mapping.click_quota) {
                        sendTelegramAlert(`🚨 Quota Reached\nProject: ${projectId}\nSupplier: ${supplierId}\nClick quota (${mapping.click_quota}) reached — traffic now blocked for this supplier.`);
                        return NextResponse.json({ error: "Supplier quota reached." }, { status: 403 });
                    }
                }
            }
        }

        // 3. Encrypt the UID — unless this project has encryption toggled off
        const shouldEncrypt = project.encrypt_uid !== false;
        const encrypted = shouldEncrypt ? encryptUID(pid) : pid;

        // Geo + Device + Browser detection
        const userAgent = request.headers.get('user-agent') || '';
        const device = getDevice(userAgent);
        const browser = getBrowser(userAgent);
        const geo = await getGeo(ip);

        // 4. Log the click in tracking_logs
        const { error: logError } = await supabaseAdmin
            .from('tracking_logs')
            .insert([{
                project_id: projectId,
                supplier_id: supplierId || null,
                respondent_uid: pid,
                encrypted_uid: encrypted,
                ip_address: ip,
                status: 'Started',
                country: geo.country,
                city: geo.city,
                device,
                browser
            }]);

        if (logError) {
            console.error("Failed to log tracking data:", logError);
        }

        // 5. Construct the redirect URL
        // We pass: the encrypted UID to the client survey, AND embed pid/sid in the URL
        // so our redirect endpoint can always recover the tracking log when the client
        // sends the respondent back.
        let redirectUrl = project.client_link;
        if (redirectUrl) {
            if (redirectUrl.includes('[UID]')) {
                redirectUrl = redirectUrl.replace('[UID]', encodeURIComponent(encrypted));
            } else if (redirectUrl.includes('{uid}')) {
                redirectUrl = redirectUrl.replace('{uid}', encodeURIComponent(encrypted));
            } else if (redirectUrl.endsWith('=')) {
                // If the link ends with an empty parameter like &pid= or &uid=
                redirectUrl += encodeURIComponent(encrypted);
            } else {
                // Fallback: append &pid= (legacy behavior)
                const separator = redirectUrl.includes('?') ? '&' : '?';
                redirectUrl += `${separator}pid=${encodeURIComponent(encrypted)}`;
            }
        }

        // 6. Redirect the user to the client's survey!
        return NextResponse.redirect(redirectUrl);

    } catch (error) {
        console.error("Survey Routing Error:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}
