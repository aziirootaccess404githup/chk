import ScriptLoader from '@/components/ScriptLoader';
// import './globals.css'; // Removed default tailwind globals. We use scraped CSS.

export const metadata = {
  title: 'Exazon Research - Panel Dashboard',
  description: 'Exazon Research Operations Dashboard',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" dir="ltr" suppressHydrationWarning>
      <head>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0" />
        {/* App css */}
        <link href="/css/bootstrap.min.css" rel="stylesheet" />
        <link href="/css/icons.min.css" rel="stylesheet" />
        <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
        <link href="/css/app.min.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" />

        {/* JS Libraries */}
        {/* New CSS Layout */}
        <link rel="icon" href="/assets/img/brand/favicon.png" type="image/x-icon" />
        <link href="/assets/css/icons.css" rel="stylesheet" />
        <link href="/assets/plugins/sidebar/sidebar.css" rel="stylesheet" />
        <link href="/assets/plugins/perfect-scrollbar/p-scrollbar.css" rel="stylesheet" />
        <link rel="stylesheet" href="/assets/css/sidemenu.css" />
        <link href="/assets/css/style.css" rel="stylesheet" />
        <link href="/assets/css/style-dark.css" rel="stylesheet" />
        <link href="/assets/css/skin-modes.css" rel="stylesheet" />
        <link href="/assets/css/animate.css" rel="stylesheet" />
        <link href="/css/color.css" rel="stylesheet" />
        <link href="/css/custom.css" rel="stylesheet" />
        
        <style dangerouslySetInnerHTML={{ __html: `
            .readonly { cursor: pointer; pointer-events: initial; color: white; background-color: #CE2F5F; opacity: 1 }
            .readonlyTI { cursor: pointer; pointer-events: initial; color: #000 !important; opacity: 1 }
            [ng-if] ~ [ng-if], [ng-show] ~ [ng-show], [ng-hide] ~ [ng-hide] { display: none !important; }
        `}} />
      </head>
      <body className="main-body app sidebar-mini " suppressHydrationWarning>
        {children}
        
        {/* JS Layout Scripts */}
                
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        <ScriptLoader />
      </body>
    </html>
  );
}
