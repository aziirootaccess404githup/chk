'use server'

import { revalidatePath } from 'next/cache'
import { createClient } from '@/utils/supabase/server'
import { createAdminClient } from '@/utils/supabase/admin'

export async function adminLogin(formData) {
  const supabase = await createClient()
  const supabaseAdmin = createAdminClient()

  let email = formData.get('username')
  if (!email.includes('@')) {
    email = `${email}@exazonresearch.com`
  }

  const data = {
    email: email,
    password: formData.get('password'),
  }

  const { error, data: authData } = await supabase.auth.signInWithPassword(data)

  if (error) {
    return { error: error.message }
  }

  // Check if they are an admin using the service role to bypass RLS
  const { data: profile } = await supabaseAdmin
    .from('profiles')
    .select('role')
    .eq('id', authData.user.id)
    .single()

  if (profile?.role !== 'superadmin') {
    // If not superadmin, sign them out immediately and return error
    await supabase.auth.signOut()
    return { error: "Access Denied: You do not have superadmin privileges." }
  }

  revalidatePath('/admin', 'layout')
  return { success: true }
}
