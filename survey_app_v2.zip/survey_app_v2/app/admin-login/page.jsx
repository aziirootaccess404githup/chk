"use client";

import React, { useState } from 'react';
import { adminLogin } from './actions';

export const dynamic = 'force-dynamic';

export default function AdminLoginPage() {
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(false);

    async function handleSubmit(e) {
        e.preventDefault();
        setLoading(true);
        setError(null);
        
        try {
            const formData = new FormData(e.target);
            const result = await adminLogin(formData);
            
            if (result && result.error) {
                setError(result.error);
                setLoading(false);
            } else if (result && result.success) {
                window.location.href = '/admin';
            }
        } catch (err) {
            setError("An unexpected server error occurred. Please try again.");
            setLoading(false);
        }
    }

    return (
        <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#f5f6f8' }}>
            <div className="card" style={{ width: '100%', maxWidth: '400px', padding: '20px', borderRadius: '10px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}>
                <div className="text-center mb-4">
                    <img src="/images/logo.png" alt="Exazon" style={{ height: '60px' }} />
                </div>
                
                <h4 className="text-center mb-4">Admin Panel Login</h4>
                
                {error && (
                    <div className="alert alert-danger" role="alert">
                        {error}
                    </div>
                )}

                <form onSubmit={handleSubmit}>
                    <div className="form-group mb-3">
                        <label htmlFor="username">Username</label>
                        <input 
                            type="text" 
                            className="form-control" 
                            id="username" 
                            name="username" 
                            required 
                            placeholder="Enter your username" 
                        />
                    </div>
                    
                    <div className="form-group mb-4">
                        <label htmlFor="password">Password</label>
                        <input 
                            type="password" 
                            className="form-control" 
                            id="password" 
                            name="password" 
                            required 
                            placeholder="Enter your password" 
                        />
                    </div>
                    
                    <button 
                        type="submit" 
                        className="btn btn-dark btn-block" 
                        style={{ width: '100%', backgroundColor: '#2c3e50', borderColor: '#2c3e50' }}
                        disabled={loading}
                    >
                        {loading ? 'Verifying...' : 'Secure Admin Login'}
                    </button>
                </form>
            </div>
        </div>
    );
}
