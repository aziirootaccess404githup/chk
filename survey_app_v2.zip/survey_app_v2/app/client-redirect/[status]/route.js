import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/utils/supabase';

// ============================================================
// Client-Level Redirect — ported from ExaVerify's client_redirect.php.
// Gives a client ONE permanent URL (?client=CLT.....&uid=...) that
// works across ALL of their projects, so it never needs to be
// regenerated when a new project is added.
//
// This route only RESOLVES which project/supplier a lead belongs to —
// it then hands off to the already-tested /panel/redirect/[status]
// route for the actual status-lock + fraud-detection + postback logic,
// so that logic lives in exactly one place.
// ============================================================
export async function GET(request, { params }) {
    const { status } = await params;
    const url = new URL(request.url);
    const clientCode = url.searchParams.get('client');
    const uid = url.searchParams.get('uid');

    if (!clientCode || !uid) {
        return NextResponse.json({ error: "Missing client code or uid." }, { status: 400 });
    }

    try {
        const { data: client } = await supabaseAdmin
            .from('clients')
            .select('id')
            .eq('client_code', clientCode)
            .maybeSingle();

        if (!client) {
            return NextResponse.json({ error: "Invalid client code." }, { status: 404 });
        }

        const { data: clientProjects } = await supabaseAdmin
            .from('projects')
            .select('id')
            .eq('client_id', client.id);

        const projectIds = (clientProjects || []).map(p => p.id);
        if (projectIds.length === 0) {
            return NextResponse.json({ error: "No projects found for this client." }, { status: 404 });
        }

        // Find this respondent's most recent lead across ANY of this
        // client's projects.
        const { data: lead } = await supabaseAdmin
            .from('tracking_logs')
            .select('project_id, supplier_id')
            .in('project_id', projectIds)
            .eq('respondent_uid', uid)
            .order('started_at', { ascending: false })
            .limit(1)
            .maybeSingle();

        if (!lead) {
            return NextResponse.json({ error: "No matching lead found for this respondent." }, { status: 404 });
        }

        // Hand off to the existing, already-tested panel/redirect logic —
        // preserve any extra query params (e.g. loi) the caller sent.
        const forwardUrl = new URL(`/panel/redirect/${status}`, request.url);
        forwardUrl.searchParams.set('pid', lead.project_id);
        if (lead.supplier_id) forwardUrl.searchParams.set('sid', lead.supplier_id);
        forwardUrl.searchParams.set('uid', uid);
        // Copy through any other params the caller included (e.g. loi)
        for (const [key, value] of url.searchParams.entries()) {
            if (!['client', 'uid'].includes(key)) forwardUrl.searchParams.set(key, value);
        }

        return NextResponse.redirect(forwardUrl);
    } catch (error) {
        console.error('Client-redirect error:', error);
        return NextResponse.json({ error: "Something went wrong." }, { status: 500 });
    }
}
