"use server";

import { supabaseAdmin } from "@/utils/supabase";

export async function getAuditLog(searchTerm) {
    try {
        let query = supabaseAdmin
            .from('audit_log')
            .select('*')
            .order('created_at', { ascending: false })
            .limit(500);

        if (searchTerm) {
            query = query.or(`action.ilike.%${searchTerm}%,details.ilike.%${searchTerm}%,admin_email.ilike.%${searchTerm}%`);
        }

        const { data, error } = await query;
        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error("Error fetching audit log:", error);
        return { success: false, error: error.message };
    }
}
