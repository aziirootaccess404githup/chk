"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { revalidatePath } from "next/cache";
import { logAudit } from "@/utils/auditLog";

// ── SEARCH IP ACTIVITY ───────────────────────────────────────
// Real search across tracking_logs by IP (or leave blank to show recent
// activity), joined with project/supplier names. No fake geo/device/
// browser data — that isn't captured anywhere in the real schema, so
// this only shows fields that genuinely exist: status, quality score,
// LOI, and whether the IP is currently on the block list.
export async function searchIpActivity(ip) {
    try {
        let query = supabaseAdmin
            .from('tracking_logs')
            .select(`
                id,
                ip_address,
                respondent_uid,
                status,
                quality_score,
                loi_seconds,
                started_at,
                country,
                city,
                device,
                browser,
                projects ( title ),
                suppliers ( name )
            `)
            .order('started_at', { ascending: false })
            .limit(200);

        if (ip) query = query.ilike('ip_address', `%${ip}%`);

        const { data: logs, error } = await query;
        if (error) throw error;

        const { data: blocked } = await supabaseAdmin.from('blocked_ips').select('ip_address');
        const blockedSet = new Set((blocked || []).map(b => b.ip_address));

        const result = (logs || []).map(l => ({
            id: l.id,
            ip: l.ip_address,
            pName: l.projects?.title || 'N/A',
            sName: l.suppliers?.name || 'N/A',
            identifier: l.respondent_uid || 'N/A',
            status: l.status,
            date: l.started_at ? new Date(l.started_at).toLocaleString() : 'N/A',
            qualityScore: l.quality_score,
            loiSeconds: l.loi_seconds,
            country: l.country || 'Unknown',
            city: l.city || '',
            device: l.device || 'Unknown',
            browser: l.browser || 'Unknown',
            isBlocked: blockedSet.has(l.ip_address),
        }));

        return { success: true, data: result };
    } catch (error) {
        console.error("Error searching IP activity:", error);
        return { success: false, error: error.message };
    }
}

// ── BLOCK / UNBLOCK ───────────────────────────────────────────
// Real block: this IP is checked and rejected at the survey entry-points
// (app/r/[unique_code]/route.js and app/api/survey/route.js) the same
// way the Global Vendor-Pause blocks a supplier.
export async function blockIP(ip, comment) {
    try {
        if (!ip) return { success: false, error: "IP address is required." };

        const { error } = await supabaseAdmin
            .from('blocked_ips')
            .upsert([{ ip_address: ip, comment: comment || null }], { onConflict: 'ip_address' });

        if (error) throw error;

        await logAudit('block_ip', `IP: ${ip}${comment ? ` — ${comment}` : ''}`);

        revalidatePath('/support/ip-tracker');
        revalidatePath('/support/blocked-ips');
        return { success: true };
    } catch (error) {
        console.error("Error blocking IP:", error);
        return { success: false, error: error.message };
    }
}

export async function unblockIP(ip) {
    try {
        const { error } = await supabaseAdmin
            .from('blocked_ips')
            .delete()
            .eq('ip_address', ip);

        if (error) throw error;

        await logAudit('unblock_ip', `IP: ${ip}`);

        revalidatePath('/support/ip-tracker');
        revalidatePath('/support/blocked-ips');
        return { success: true };
    } catch (error) {
        console.error("Error unblocking IP:", error);
        return { success: false, error: error.message };
    }
}

export async function getBlockedIps() {
    try {
        const { data, error } = await supabaseAdmin
            .from('blocked_ips')
            .select('*')
            .order('blocked_at', { ascending: false });

        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error("Error fetching blocked IPs:", error);
        return { success: false, error: error.message };
    }
}
