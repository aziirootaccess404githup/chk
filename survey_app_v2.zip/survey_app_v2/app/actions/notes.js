"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { createClient } from "@/utils/supabase/server";
import { revalidatePath } from "next/cache";

export async function getNotes() {
    try {
        const { data, error } = await supabaseAdmin
            .from('dashboard_notes')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error("Error fetching notes:", error);
        return { success: false, error: error.message };
    }
}

export async function addNote(note) {
    try {
        if (!note || !note.trim()) return { success: false, error: "Note cannot be empty." };

        const supabase = await createClient();
        const { data: { user } } = await supabase.auth.getUser();

        const { data, error } = await supabaseAdmin
            .from('dashboard_notes')
            .insert([{ note: note.trim(), admin_email: user?.email || 'unknown' }])
            .select()
            .single();

        if (error) throw error;

        revalidatePath('/');
        return { success: true, data };
    } catch (error) {
        console.error("Error adding note:", error);
        return { success: false, error: error.message };
    }
}

export async function deleteNote(id) {
    try {
        const { error } = await supabaseAdmin
            .from('dashboard_notes')
            .delete()
            .eq('id', id);

        if (error) throw error;

        revalidatePath('/');
        return { success: true };
    } catch (error) {
        console.error("Error deleting note:", error);
        return { success: false, error: error.message };
    }
}
