"use server";

import { supabaseAdmin } from "@/utils/supabase";

export async function getRespondentDetail(uid, projectId) {
    try {
        if (!uid) return { success: false, error: "UID is required." };

        let query = supabaseAdmin
            .from('tracking_logs')
            .select('*, projects ( title ), suppliers ( name )')
            .eq('respondent_uid', uid)
            .order('started_at', { ascending: false })
            .limit(1);

        if (projectId) query = query.eq('project_id', projectId);

        const { data: lead, error: leadErr } = await query.maybeSingle();
        if (leadErr) throw leadErr;

        if (!lead) {
            return { success: true, data: { lead: null, answers: [] } };
        }

        const { data: answers, error: ansErr } = await supabaseAdmin
            .from('prescreen_responses')
            .select('question_text, answer, created_at')
            .eq('respondent_uid', uid)
            .eq('project_id', lead.project_id)
            .order('created_at', { ascending: true });
        if (ansErr) throw ansErr;

        return { success: true, data: { lead, answers: answers || [] } };
    } catch (error) {
        console.error("Error fetching respondent detail:", error);
        return { success: false, error: error.message };
    }
}
