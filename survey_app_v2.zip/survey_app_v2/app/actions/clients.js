"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { revalidatePath } from "next/cache";
import { logAudit } from "@/utils/auditLog";

/**
 * Fetch all clients from the database
 */
// Generates (or returns existing) a stable, permanent code for a
// client, used by the Client-Level Redirect route so vendors get one
// URL that never needs to change as new projects are added.
export async function generateClientCode(clientId) {
    try {
        const { data: existing } = await supabaseAdmin
            .from('clients')
            .select('client_code')
            .eq('id', clientId)
            .single();

        if (existing?.client_code) return { success: true, data: existing.client_code };

        // Simple random code: CLT + 8 hex chars
        const code = 'CLT' + Math.random().toString(16).slice(2, 10);

        const { error } = await supabaseAdmin
            .from('clients')
            .update({ client_code: code })
            .eq('id', clientId);

        if (error) throw error;

        revalidatePath('/clients');
        return { success: true, data: code };
    } catch (error) {
        console.error("Error generating client code:", error);
        return { success: false, error: error.message };
    }
}

export async function getClients() {
    try {
        const { data, error } = await supabaseAdmin
            .from('clients')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error("Error fetching clients:", error);
        return { success: false, error: error.message };
    }
}

/**
 * Create a new client
 */
export async function createClient(formData) {
    try {
        const name = formData.get('name');
        const email = formData.get('email');
        const company = formData.get('company');
        const phone = formData.get('phone');
        const address = formData.get('address');
        const website = formData.get('website');
        const status = formData.get('status');
        const country = formData.get('country');
        const link_type = formData.get('link_type') || 'Dynamic';
        const complete_url = formData.get('complete_url');
        const terminate_url = formData.get('terminate_url');
        const quotafull_url = formData.get('quotafull_url');
        const quality_url = formData.get('quality_url');

        if (!name) {
            return { success: false, error: "Name is required" };
        }

        const { data, error } = await supabaseAdmin
            .from('clients')
            .insert([{ 
                name, email, company, phone, address, website, status, country,
                link_type, complete_url, terminate_url, quotafull_url, quality_url
            }])
            .select()
            .single();

        if (error) throw error;

        // Revalidate the clients list page so it shows the new data
        revalidatePath('/clients/data');
        
        return { success: true, data };
    } catch (error) {
        console.error("Error creating client:", error);
        return { success: false, error: error.message };
    }
}

/**
 * Delete a client
 */
export async function deleteClient(id) {
    try {
        const { error } = await supabaseAdmin
            .from('clients')
            .delete()
            .eq('id', id);

        if (error) throw error;

        await logAudit('delete_client', `Client ID: ${id}`);

        revalidatePath('/clients/data');
        return { success: true };
    } catch (error) {
        console.error("Error deleting client:", error);
        return { success: false, error: error.message };
    }
}

export async function updateClient(id, updateData) {
    try {
        const { data, error } = await supabaseAdmin
            .from('clients')
            .update(updateData)
            .eq('id', id)
            .select()
            .single();

        if (error) throw error;

        revalidatePath('/clients/data');
        return { success: true, data };
    } catch (error) {
        console.error("Error updating client:", error);
        return { success: false, error: error.message };
    }
}
