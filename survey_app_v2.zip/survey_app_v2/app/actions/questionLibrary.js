"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { revalidatePath } from "next/cache";

export async function getQuestions(searchTerm) {
    try {
        let query = supabaseAdmin
            .from('question_library')
            .select('*')
            .order('created_at', { ascending: false });

        if (searchTerm) {
            query = query.or(`title.ilike.%${searchTerm}%,question_text.ilike.%${searchTerm}%,category.ilike.%${searchTerm}%`);
        }

        const { data, error } = await query;
        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error("Error fetching questions:", error);
        return { success: false, error: error.message };
    }
}

export async function addQuestion(formData) {
    try {
        const country = formData.get('country');
        const language = formData.get('language');
        const control_type = formData.get('control_type');
        const title = formData.get('title');
        const question_text = formData.get('question_text');
        const category = formData.get('category');
        const min_length = formData.get('min_length') || null;
        const max_length = formData.get('max_length') || null;
        const text_type = formData.get('text_type') || null;
        const optionsRaw = formData.get('options');
        const options = optionsRaw ? JSON.parse(optionsRaw) : [];

        if (!title || !question_text || !control_type) {
            return { success: false, error: "Title, Question, and Control Type are required." };
        }

        const { data, error } = await supabaseAdmin
            .from('question_library')
            .insert([{
                country, language, control_type, title, question_text, category,
                min_length: min_length ? parseInt(min_length) : null,
                max_length: max_length ? parseInt(max_length) : null,
                text_type, options,
            }])
            .select()
            .single();

        if (error) throw error;

        revalidatePath('/library/questions');
        return { success: true, data };
    } catch (error) {
        console.error("Error adding question:", error);
        return { success: false, error: error.message };
    }
}

export async function updateQuestion(id, formData) {
    try {
        const country = formData.get('country');
        const language = formData.get('language');
        const control_type = formData.get('control_type');
        const title = formData.get('title');
        const question_text = formData.get('question_text');
        const category = formData.get('category');
        const min_length = formData.get('min_length') || null;
        const max_length = formData.get('max_length') || null;
        const text_type = formData.get('text_type') || null;
        const optionsRaw = formData.get('options');
        const options = optionsRaw ? JSON.parse(optionsRaw) : [];

        if (!title || !question_text || !control_type) {
            return { success: false, error: "Title, Question, and Control Type are required." };
        }

        const { data, error } = await supabaseAdmin
            .from('question_library')
            .update({
                country, language, control_type, title, question_text, category,
                min_length: min_length ? parseInt(min_length) : null,
                max_length: max_length ? parseInt(max_length) : null,
                text_type, options,
            })
            .eq('id', id)
            .select()
            .single();

        if (error) throw error;

        revalidatePath('/library/questions');
        return { success: true, data };
    } catch (error) {
        console.error("Error updating question:", error);
        return { success: false, error: error.message };
    }
}

export async function deleteQuestion(id) {
    try {
        const { error } = await supabaseAdmin
            .from('question_library')
            .delete()
            .eq('id', id);

        if (error) throw error;

        revalidatePath('/library/questions');
        return { success: true };
    } catch (error) {
        console.error("Error deleting question:", error);
        return { success: false, error: error.message };
    }
}
