"use server";

import { encryptUID, decryptUID } from "@/utils/encryption";

export async function processUID(uidOrEncrypted) {
    if (!uidOrEncrypted) {
        return { success: false, error: "Please provide a UID." };
    }

    try {
        const input = String(uidOrEncrypted).trim();
        
        // Attempt to decrypt it
        const decrypted = decryptUID(input);
        
        // If decryption returns the exact same string, it means the input was likely raw/original (or failed to decrypt)
        // If it's different, it successfully decrypted.
        if (decrypted !== input) {
            // The input was an encrypted string
            return {
                success: true,
                original: decrypted,
                encrypted: input
            };
        } else {
            // The input was likely an original UID. Let's encrypt it.
            const encrypted = encryptUID(input);
            return {
                success: true,
                original: input,
                encrypted: encrypted
            };
        }
    } catch (err) {
        return { success: false, error: err.message };
    }
}
