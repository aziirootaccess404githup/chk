"use server";

import { supabaseAdmin } from "@/utils/supabase";

export async function getVendorDetail(supplierId) {
    try {
        const { data: supplier, error: supErr } = await supabaseAdmin
            .from('suppliers')
            .select('*')
            .eq('id', supplierId)
            .single();
        if (supErr) throw supErr;

        // Aggregate stats across ALL projects this vendor is on
        const { data: allLogs, error: logsErr } = await supabaseAdmin
            .from('tracking_logs')
            .select('status')
            .eq('supplier_id', supplierId);
        if (logsErr) throw logsErr;

        const total = (allLogs || []).length;
        const completes = (allLogs || []).filter(l => l.status === 'Complete').length;
        const terminates = (allLogs || []).filter(l => l.status === 'Terminate').length;
        const conversion = total > 0 ? Math.round((completes / total) * 1000) / 10 : 0;

        // Assigned projects
        const { data: mappings, error: mapErr } = await supabaseAdmin
            .from('project_supplier_mappings')
            .select('project_id, cpi, allocation, click_quota, allow_traffic, created_at, projects ( title, status, country )')
            .eq('supplier_id', supplierId)
            .order('created_at', { ascending: false });
        if (mapErr) throw mapErr;

        // Recent leads (last 100, across all projects)
        const { data: recentLeads, error: leadsErr } = await supabaseAdmin
            .from('tracking_logs')
            .select('respondent_uid, status, country, device, loi_seconds, ip_address, started_at, project_id, projects ( title )')
            .eq('supplier_id', supplierId)
            .order('started_at', { ascending: false })
            .limit(100);
        if (leadsErr) throw leadsErr;

        return {
            success: true,
            data: {
                supplier,
                stats: { total, completes, terminates, conversion },
                assignedProjects: mappings || [],
                recentLeads: recentLeads || [],
            },
        };
    } catch (error) {
        console.error("Error fetching vendor detail:", error);
        return { success: false, error: error.message };
    }
}
