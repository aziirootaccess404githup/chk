"use server";

import { supabaseAdmin } from "@/utils/supabase";

// ── ANALYTICS DATA ────────────────────────────────────────────
// Aggregates real tracking_logs into the shapes ExaVerify's
// Analytics tab charts (daily trend, status breakdown, device
// breakdown, country breakdown) — no fake numbers, all computed
// from actual rows.
export async function getAnalyticsData(fromDate, toDate) {
    try {
        let query = supabaseAdmin
            .from('tracking_logs')
            .select('status, started_at, device, country, quality_score');

        if (fromDate) query = query.gte('started_at', fromDate);
        if (toDate) query = query.lte('started_at', `${toDate}T23:59:59`);

        const { data: logs, error } = await query;
        if (error) throw error;

        // ── Daily Trend (Complete / Terminate / OverQuota / avg Quality) ──
        const byDate = {};
        (logs || []).forEach(l => {
            const date = l.started_at ? l.started_at.substring(0, 10) : 'Unknown';
            if (!byDate[date]) byDate[date] = { date, complete: 0, terminate: 0, overQuota: 0, scoreSum: 0, scoreCount: 0 };
            if (l.status === 'Complete') byDate[date].complete++;
            else if (l.status === 'Terminate') byDate[date].terminate++;
            else if (l.status === 'OverQuota') byDate[date].overQuota++;
            if (l.quality_score !== null && l.quality_score !== undefined) {
                byDate[date].scoreSum += l.quality_score;
                byDate[date].scoreCount++;
            }
        });
        const trend = Object.values(byDate)
            .filter(d => d.date !== 'Unknown')
            .sort((a, b) => a.date.localeCompare(b.date))
            .map(d => ({
                date: d.date,
                complete: d.complete,
                terminate: d.terminate,
                overQuota: d.overQuota,
                avgQuality: d.scoreCount > 0 ? Math.round(d.scoreSum / d.scoreCount) : null,
            }));

        // ── Status Breakdown ──
        const statusCounts = {};
        (logs || []).forEach(l => {
            statusCounts[l.status] = (statusCounts[l.status] || 0) + 1;
        });
        const statusBreakdown = Object.entries(statusCounts).map(([status, count]) => ({ status, count }));

        // ── Device Breakdown ──
        const deviceCounts = {};
        (logs || []).forEach(l => {
            const d = l.device || 'Unknown';
            deviceCounts[d] = (deviceCounts[d] || 0) + 1;
        });
        const deviceBreakdown = Object.entries(deviceCounts)
            .sort((a, b) => b[1] - a[1])
            .map(([device, count]) => ({ device, count }));

        // ── Country Breakdown (top 10) ──
        const countryCounts = {};
        (logs || []).forEach(l => {
            const c = l.country || 'Unknown';
            countryCounts[c] = (countryCounts[c] || 0) + 1;
        });
        const countryBreakdown = Object.entries(countryCounts)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 10)
            .map(([country, count]) => ({ country, count }));

        return {
            success: true,
            data: { trend, statusBreakdown, deviceBreakdown, countryBreakdown, total: (logs || []).length },
        };
    } catch (error) {
        console.error("Error fetching analytics data:", error);
        return { success: false, error: error.message };
    }
}
