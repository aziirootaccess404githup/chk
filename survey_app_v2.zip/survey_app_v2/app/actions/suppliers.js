"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { revalidatePath } from "next/cache";
import { logAudit } from "@/utils/auditLog";

export async function getSuppliers() {
    try {
        const { data, error } = await supabaseAdmin
            .from('suppliers')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error("Error fetching suppliers:", error);
        return { success: false, error: error.message };
    }
}

export async function createSupplier(formData) {
    try {
        const name = formData.get('name');
        const contact_email = formData.get('contact_email');
        const cpi_rate = formData.get('cpi_rate');
        const contact_person = formData.get('contact_person');
        const phone = formData.get('phone');
        const website = formData.get('website');
        const status = formData.get('status');
        const country = formData.get('country');
        const address = formData.get('address');
        const complete_url = formData.get('complete_url');
        const terminate_url = formData.get('terminate_url');
        const quotafull_url = formData.get('quotafull_url');
        const quality_url = formData.get('quality_url');
        const supplier_type = formData.get('supplier_type');
        const end_behavior = formData.get('end_behavior');
        const panel_size = formData.get('panel_size');
        const survey_close = formData.get('survey_close');
        const postback_url = formData.get('postback_url');

        if (!name) {
            return { success: false, error: "Name is required" };
        }

        const { data, error } = await supabaseAdmin
            .from('suppliers')
            .insert([{ 
                name, 
                contact_email: contact_email || null, 
                cpi_rate: cpi_rate ? parseFloat(cpi_rate) : null,
                contact_person: contact_person || null,
                phone: phone || null,
                website: website || null,
                status: status || 'Active',
                country: country || null,
                address: address || null,
                supplier_type: supplier_type || 'Static',
                end_behavior: end_behavior || 'redirect',
                complete_url: complete_url || null,
                terminate_url: terminate_url || null,
                quotafull_url: quotafull_url || null,
                quality_url: quality_url || null,
                panel_size: panel_size ? parseInt(panel_size, 10) : null,
                survey_close: survey_close || null,
                postback_url: postback_url || null
            }])
            .select()
            .single();

        if (error) throw error;

        revalidatePath('/suppliers');
        return { success: true, data };
    } catch (error) {
        console.error("Error creating supplier:", error);
        return { success: false, error: error.message };
    }
}

export async function deleteSupplier(id) {
    try {
        const { error } = await supabaseAdmin
            .from('suppliers')
            .delete()
            .eq('id', id);

        if (error) throw error;

        await logAudit('delete_supplier', `Supplier ID: ${id}`);

        revalidatePath('/suppliers');
        return { success: true };
    } catch (error) {
        console.error("Error deleting supplier:", error);
        return { success: false, error: error.message };
    }
}

export async function updateSupplier(id, updateData) {
    try {
        const { data, error } = await supabaseAdmin
            .from('suppliers')
            .update(updateData)
            .eq('id', id)
            .select()
            .single();

        if (error) throw error;

        revalidatePath('/suppliers');
        return { success: true, data };
    } catch (error) {
        console.error("Error updating supplier:", error);
        return { success: false, error: error.message };
    }
}
