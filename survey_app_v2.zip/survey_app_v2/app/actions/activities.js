"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { revalidatePath } from "next/cache";

export async function getActivities(projectId) {
    try {
        const { data, error } = await supabaseAdmin
            .from('project_activities')
            .select('*')
            .eq('project_id', projectId)
            .order('date', { ascending: false })
            .order('created_at', { ascending: false });

        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error("Error fetching activities:", error);
        return { success: false, error: error.message };
    }
}

export async function addActivity(formData) {
    try {
        const project_id = formData.get('project_id');
        const date = formData.get('date');
        const activity = formData.get('activity');
        const sub_activity = formData.get('sub_activity');
        const duration = formData.get('duration');

        if (!project_id || !date || !activity || !duration) {
            return { success: false, error: "Missing required fields" };
        }

        const { data, error } = await supabaseAdmin
            .from('project_activities')
            .insert([{ project_id, date, activity, sub_activity, duration }])
            .select()
            .single();

        if (error) throw error;

        revalidatePath(`/projects/${project_id}`);
        return { success: true, data };
    } catch (error) {
        console.error("Error adding activity:", error);
        return { success: false, error: error.message };
    }
}
