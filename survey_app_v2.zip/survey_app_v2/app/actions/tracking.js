"use server";

import { supabaseAdmin } from "@/utils/supabase";

export async function getTrackingLogs() {
    try {
        const { data, error } = await supabaseAdmin
            .from('tracking_logs')
            .select(`
                *,
                projects ( title, cpi, clients ( name ) ),
                suppliers ( name )
            `)
            .order('started_at', { ascending: false })
            .limit(5000);

        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error('Error fetching tracking logs:', error);
        return { success: false, error: error.message };
    }
}
