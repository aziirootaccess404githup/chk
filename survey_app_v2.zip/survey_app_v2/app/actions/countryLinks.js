"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { revalidatePath } from "next/cache";

export async function getCountryLinks(projectId) {
    try {
        const { data, error } = await supabaseAdmin
            .from('project_country_links')
            .select('*')
            .eq('project_id', projectId)
            .order('country', { ascending: true });

        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error("Error fetching country links:", error);
        return { success: false, error: error.message };
    }
}

export async function addCountryLink(projectId, country, liveUrl) {
    try {
        if (!projectId || !country || !liveUrl) {
            return { success: false, error: "Project, country, and URL are all required." };
        }

        const { data, error } = await supabaseAdmin
            .from('project_country_links')
            // one URL per country per project — re-adding the same country updates it
            .upsert([{ project_id: projectId, country, live_url: liveUrl }], { onConflict: 'project_id,country' })
            .select()
            .single();

        if (error) throw error;

        revalidatePath(`/projects/${projectId}`);
        return { success: true, data };
    } catch (error) {
        console.error("Error adding country link:", error);
        return { success: false, error: error.message };
    }
}

export async function deleteCountryLink(id, projectId) {
    try {
        const { error } = await supabaseAdmin
            .from('project_country_links')
            .delete()
            .eq('id', id);

        if (error) throw error;

        revalidatePath(`/projects/${projectId}`);
        return { success: true };
    } catch (error) {
        console.error("Error deleting country link:", error);
        return { success: false, error: error.message };
    }
}
