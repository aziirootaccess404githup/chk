"use server";

import { supabaseAdmin } from "@/utils/supabase";

export async function getDashboardStats() {
    try {
        // 1. Get Project Counts by Status
        // For efficiency, we can fetch all statuses and count them in memory
        const { data: projects, error: projectsError } = await supabaseAdmin
            .from('projects')
            .select('status, title, id, quota, parent_id')
            .order('created_at', { ascending: false });

        if (projectsError) throw projectsError;

        let active = 0, inactive = 0, closed = 0, invoiced = 0, archive = 0;
        let recentSurveys = [];

        projects.forEach(p => {
            const status = (p.status || '').toLowerCase();
            
            if (!p.parent_id) {
                if (status === 'active' || status === 'live') active++;
                else if (status === 'inactive' || status === 'paused' || status === 'draft') inactive++;
                else if (status === 'closed') closed++;
                else if (status === 'invoiced') invoiced++;
                else if (status === 'archive') archive++;

                // Grab top 3 active/live main projects for Recent Surveys
                if ((status === 'active' || status === 'live') && recentSurveys.length < 3) {
                    recentSurveys.push({
                        projectCode: "PRJ-" + p.id.substring(0, 4), 
                        projectName: p.title,
                        completeCount: 0 // We'll populate this below
                    });
                }
            }
        });

        // 2. Get Tracking Logs Data
        // Use UTC midnight for accurate timezone-safe "today" comparison
        const nowUtc = new Date();
        const todayUtcMidnight = new Date(Date.UTC(nowUtc.getUTCFullYear(), nowUtc.getUTCMonth(), nowUtc.getUTCDate()));

        let logs = [];
        let from = 0;
        const pageSize = 1000;
        while (true) {
            const { data: chunk, error: logsError } = await supabaseAdmin
                .from('tracking_logs')
                .select('status, started_at, completed_at, project_id')
                .range(from, from + pageSize - 1);
            if (logsError) throw logsError;
            if (!chunk || chunk.length === 0) break;
            logs = logs.concat(chunk);
            if (chunk.length < pageSize) break;
            from += pageSize;
        }

        let totalClicks = 0;
        let todayCompletes = 0;

        // Chart Data Arrays
        const currentYear = nowUtc.getUTCFullYear();
        
        // Months: Jan-Dec
        const monthlyCompletes = new Array(12).fill(0);
        const tsignMonthly = new Array(12).fill(0);

        // Days: Last 7 days (including today)
        const dailyCompletes = new Array(7).fill(0);
        const tsignDaily = new Array(7).fill(0);
        
        // Helper to get labels for last 7 days
        const last7DaysLabels = [];
        for (let i = 6; i >= 0; i--) {
            const d = new Date(todayUtcMidnight);
            d.setUTCDate(d.getUTCDate() - i);
            last7DaysLabels.push(d.toLocaleDateString('en-US', { weekday: 'short' }));
        }

        logs.forEach(log => {
            const isComplete = log.status === 'Complete';
            const isStarted = log.status === 'Started';
            const logStartDate = new Date(log.started_at);
            const logCompleteDate = log.completed_at ? new Date(log.completed_at) : null;

            // totalClicks = respondents who clicked/started the survey
            if (isStarted || isComplete || log.status === 'Terminate' || log.status === 'OverQuota' || log.status === 'SecurityFail') {
                totalClicks++;
            }

            // Today completes — check completed_at date, not started_at
            if (isComplete && logCompleteDate && logCompleteDate >= todayUtcMidnight) {
                todayCompletes++;
            }

            // Monthly Aggregation (Current Year Only) — based on started_at
            if (logStartDate.getUTCFullYear() === currentYear) {
                const monthIndex = logStartDate.getUTCMonth(); // 0-11
                tsignMonthly[monthIndex]++;
                if (isComplete) {
                    monthlyCompletes[monthIndex]++;
                }
            }

            // Daily Aggregation (Last 7 Days) — based on started_at
            const logDayUtc = new Date(Date.UTC(logStartDate.getUTCFullYear(), logStartDate.getUTCMonth(), logStartDate.getUTCDate()));
            const diffTime = todayUtcMidnight.getTime() - logDayUtc.getTime();
            const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
            
            if (diffDays >= 0 && diffDays < 7) {
                const dayIndex = 6 - diffDays; // 6 is today, 0 is 6 days ago
                tsignDaily[dayIndex]++;
                if (isComplete) {
                    dailyCompletes[dayIndex]++;
                }
            }

            // Update recentSurveys complete counts
            const logProject = projects.find(pr => pr.id === log.project_id);
            const mainProjectId = logProject?.parent_id || logProject?.id;
            const mainProject = projects.find(pr => pr.id === mainProjectId);
            
            const rsIndex = recentSurveys.findIndex(rs => rs.projectName === mainProject?.title);
            if (rsIndex > -1 && isComplete) {
                recentSurveys[rsIndex].completeCount++;
            }
        });

        return {
            success: true,
            data: {
                counts: {
                    active, inactive, closed, invoiced, archive
                },
                recentSurveys,
                conversions: {
                    totalClicks,
                    todayCompletes
                },
                charts: {
                    monthlyCompletes,
                    tsignMonthly,
                    dailyCompletes,
                    tsignDaily,
                    last7DaysLabels
                }
            }
        };

    } catch (error) {
        console.error("Dashboard Stats Error:", error);
        return { success: false, error: error.message };
    }
}
