"use server";

import { supabaseAdmin } from "@/utils/supabase";
import { revalidatePath } from "next/cache";

export async function getMappingsByProject(projectId) {
    try {
        const { data, error } = await supabaseAdmin
            .from('project_supplier_mappings')
            .select(`
                *,
                suppliers ( name, cpi_rate, supplier_type )
            `)
            .eq('project_id', projectId)
            .order('created_at', { ascending: false });

        if (error) throw error;

        // Fetch logs for this project to calculate stats for each mapping
        let logsData = [];
        const { data: logs } = await supabaseAdmin
            .from('tracking_logs')
            .select('supplier_id, status')
            .eq('project_id', projectId);
        if (logs) logsData = logs;

        const mappingsWithStats = data.map(map => {
            const supplierLogs = logsData.filter(log => log.supplier_id === map.supplier_id);
            const stats = {
                clicks: supplierLogs.length,
                completes: supplierLogs.filter(l => l.status === 'Complete').length,
                terminates: supplierLogs.filter(l => l.status === 'Terminate').length,
                overQuota: supplierLogs.filter(l => l.status === 'OverQuota').length,
                securityFails: supplierLogs.filter(l => l.status === 'SecurityFail').length,
                dropouts: supplierLogs.filter(l => l.status === 'Started').length
            };
            return { ...map, stats };
        });

        return { success: true, data: mappingsWithStats };
    } catch (error) {
        console.error("Error fetching mappings:", error);
        return { success: false, error: error.message };
    }
}

export async function addMapping(formData) {
    try {
        const project_id = formData.get('project_id');
        let supplier_ids = formData.getAll('supplier_id');
        const cpi = formData.get('cpi');
        const allocation = formData.get('allocation');
        const click_quota = formData.get('click_quota');
        const allow_traffic = formData.get('allow_traffic') === 'true' || formData.get('allow_traffic') === 'on';
        const show_prescreener = formData.get('show_prescreener') === 'true' || formData.get('show_prescreener') === 'on';

        if (!project_id || !supplier_ids || supplier_ids.length === 0) {
            return { success: false, error: "Project and Supplier are required." };
        }

        // If 'ALL' is selected, fetch all supplier IDs
        if (supplier_ids.includes('ALL')) {
            const { data: allSups } = await supabaseAdmin.from('suppliers').select('id');
            if (allSups) {
                supplier_ids = allSups.map(s => s.id);
            }
        }

        const mappingsToInsert = supplier_ids.filter(id => id && id !== 'ALL').map(supplier_id => {
            return {
                project_id,
                supplier_id,
                unique_code: Math.random().toString(36).substring(2, 7).toUpperCase(),
                cpi: cpi ? parseFloat(cpi) : null,
                allocation: allocation ? parseInt(allocation, 10) : 0,
                click_quota: click_quota ? parseInt(click_quota, 10) : 0,
                allow_traffic,
                show_prescreener
            };
        });

        if (mappingsToInsert.length === 0) {
            return { success: false, error: "No valid suppliers selected." };
        }

        const { data, error } = await supabaseAdmin
            .from('project_supplier_mappings')
            .insert(mappingsToInsert)
            .select();

        if (error) {
            throw error;
        }

        revalidatePath(`/projects/${project_id}`);
        return { success: true, data };
    } catch (error) {
        console.error("Error adding mapping:", error);
        return { success: false, error: error.message };
    }
}

export async function removeMapping(id, projectId) {
    try {
        const { error } = await supabaseAdmin
            .from('project_supplier_mappings')
            .delete()
            .eq('id', id);

        if (error) throw error;

        revalidatePath(`/projects/${projectId}`);
        return { success: true };
    } catch (error) {
        console.error("Error removing mapping:", error);
        return { success: false, error: error.message };
    }
}

export async function updateMapping(id, projectId, updates) {
    try {
        const { data, error } = await supabaseAdmin
            .from('project_supplier_mappings')
            .update(updates)
            .eq('id', id)
            .select()
            .single();

        if (error) throw error;

        revalidatePath(`/projects/${projectId}`);
        return { success: true, data };
    } catch (error) {
        console.error("Error updating mapping:", error);
        return { success: false, error: error.message };
    }
}
