import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/utils/supabase';
import { encryptUID } from '@/utils/encryption';
import { getGeo, getDevice, getBrowser } from '@/utils/geoDevice';
import { sendTelegramAlert } from '@/utils/telegramAlert';

// Helper: build the correct public base URL using Nginx-forwarded headers
function getBaseUrl(request) {
    const host = request.headers.get('host') || 'your-domain.com';
    const proto = request.headers.get('x-forwarded-proto') || 'https';
    return `${proto}://${host}`;
}

export async function GET(request, { params }) {
    const { unique_code } = await params;
    
    // Get URL search parameters (like ?uid=12345 or ?pid=12345)
    const url = new URL(request.url);
    const uid = url.searchParams.get('uid') || url.searchParams.get('id') || url.searchParams.get('rid') || url.searchParams.get('pid');

    if (!uid) {
        return NextResponse.json({ error: "Missing respondent identifier (uid)." }, { status: 400 });
    }

    try {
        // 1. Look up the mapping
        const { data: mapping, error: mappingError } = await supabaseAdmin
            .from('project_supplier_mappings')
            .select(`
                project_id,
                supplier_id,
                allow_traffic,
                click_quota,
                projects ( client_link, status, encrypt_uid, link_type ),
                suppliers ( status )
            `)
            .eq('unique_code', unique_code)
            .single();

        if (mappingError || !mapping) {
            return NextResponse.json({ error: "Invalid survey link." }, { status: 404 });
        }

        const project = mapping.projects;
        if (!project) {
            return NextResponse.json({ error: "Project not found." }, { status: 404 });
        }

        if (project.status !== 'Live') {
            return NextResponse.redirect(`${getBaseUrl(request)}/survey-paused`);
        }

        // Check if project has prescreen questions AND respondent hasn't been prescreened
        // Wrap safely — prescreen failure must NEVER block a live survey redirect
        const prescreened = url.searchParams.get('prescreened');
        if (!prescreened) {
            try {
                const { count: questionCount } = await supabaseAdmin
                    .from('prescreen_questions')
                    .select('*', { count: 'exact', head: true })
                    .eq('project_id', mapping.project_id);

                if (questionCount && questionCount > 0) {
                    const base = getBaseUrl(request);
                    const prescreenUrl = new URL(`/prescreen/${unique_code}`, base);
                    if (uid) prescreenUrl.searchParams.set('uid', uid);
                    return NextResponse.redirect(prescreenUrl);
                }
            } catch (prescreenErr) {
                // Log but don't block — continue to survey
                console.error('Prescreen check failed, continuing to survey:', prescreenErr);
            }
        }

        // 2. Enforce Traffic Controls
        // Capture IP early so it can be checked against the block-list.
        const forwarded = request.headers.get('x-forwarded-for');
        const ip = forwarded ? forwarded.split(',')[0].trim() : (request.headers.get('x-real-ip') || '0.0.0.0');

        // Blocked-IP check (IP Tracker's "Block" button): a blocked IP is
        // rejected immediately, before any project/vendor checks.
        if (ip && ip !== '0.0.0.0') {
            const { data: blockedEntry } = await supabaseAdmin
                .from('blocked_ips')
                .select('ip_address')
                .eq('ip_address', ip)
                .maybeSingle();
            if (blockedEntry) {
                return NextResponse.json({ error: "Access denied." }, { status: 403 });
            }
        }

        // Global vendor-pause (ported from ExaVerify): supplier.status governs
        // ALL projects for that supplier at once — checked BEFORE the
        // per-project allow_traffic flag, so pausing a vendor once blocks
        // every one of their links immediately, without editing each mapping.
        const supplierStatus = mapping.suppliers?.status;
        if (supplierStatus && supplierStatus !== 'Active') {
            return NextResponse.json({ error: "This supplier is currently paused." }, { status: 403 });
        }

        if (mapping.allow_traffic === false) {
            return NextResponse.json({ error: "Survey is currently closed for this supplier." }, { status: 403 });
        }

        if (mapping.click_quota > 0) {
            const { count, error: countError } = await supabaseAdmin
                .from('tracking_logs')
                .select('*', { count: 'exact', head: true })
                .eq('project_id', mapping.project_id)
                .eq('supplier_id', mapping.supplier_id);
                
            if (count >= mapping.click_quota) {
                sendTelegramAlert(`🚨 Quota Reached\nProject: ${project.client_link ? mapping.project_id : mapping.project_id}\nSupplier: ${mapping.supplier_id}\nClick quota (${mapping.click_quota}) reached — traffic now blocked for this supplier.`);
                return NextResponse.json({ error: "Supplier quota reached." }, { status: 403 });
            }
        }

        // 3. Encrypt the UID — unless this project has encryption toggled off
        // (some client survey platforms need the exact original ID for
        // their own matching). Default is ON, same as ExaVerify.
        const shouldEncrypt = project.encrypt_uid !== false;
        const encrypted = shouldEncrypt ? encryptUID(uid) : uid;

        // Geo + Device + Browser detection (ported from ExaVerify's
        // exz_geo/exz_device/exz_browser) — real data, no fake fields.
        const userAgent = request.headers.get('user-agent') || '';
        const device = getDevice(userAgent);
        const browser = getBrowser(userAgent);
        const geo = await getGeo(ip);

        // 5. Log the click (Started)
        const { error: logError } = await supabaseAdmin
            .from('tracking_logs')
            .insert([{
                project_id: mapping.project_id,
                supplier_id: mapping.supplier_id,
                respondent_uid: uid,
                encrypted_uid: encrypted,
                ip_address: ip,
                status: 'Started',
                country: geo.country,
                city: geo.city,
                device,
                browser
            }]);

        if (logError) {
            console.error("Error logging start:", logError);
            // Continue anyway so respondent isn't blocked
        }

        // 4. Construct the client survey URL
        let finalUrl = project.client_link;

        // Multi-Country Link (ported from ExaVerify): if this project is
        // set to "Country" link-type, try to find a per-country override
        // URL matching the respondent's detected country (from geo lookup
        // above) — falls back to the default client_link if no match.
        if (project.link_type === 'Country' && geo.country && geo.country !== 'Unknown') {
            const { data: countryLink } = await supabaseAdmin
                .from('project_country_links')
                .select('live_url')
                .eq('project_id', mapping.project_id)
                .ilike('country', geo.country)
                .maybeSingle();
            if (countryLink?.live_url) {
                finalUrl = countryLink.live_url;
            }
        }

        // ── Universal Placeholder Replacement ──────────────────────────────────
        // We support ALL common placeholder formats used by different survey platforms.
        // Priority order:
        //   1. [anything]  → e.g. [qparm], [UID], [PID], [identifier]
        //   2. {anything}  → e.g. {uid}, {respondent_id}
        //   3. XXXX / XXXXXX (4+ X's) → Universal convention: put XXXXXX where UID should go
        //   4. URL ends with = → e.g. &qparm=  (value left empty)
        //   5. No placeholder → append &uid=... at the end
        // ───────────────────────────────────────────────────────────────────────
        if (/\[[^\]]+\]/.test(finalUrl)) {
            // e.g. [qparm], [UID], [PID], [identifier] — replace first match
            finalUrl = finalUrl.replace(/\[[^\]]+\]/, encodeURIComponent(encrypted));

        } else if (/\{[^}]+\}/.test(finalUrl)) {
            // e.g. {uid}, {respondent_id} — replace first match
            finalUrl = finalUrl.replace(/\{[^}]+\}/, encodeURIComponent(encrypted));

        } else if (/X{4,}/i.test(finalUrl)) {
            // XXXXXX convention: 4 or more X's (uppercase OR lowercase) used as UID placeholder
            // Works even when UID is in the MIDDLE of the URL
            // e.g. https://somesurvey.com/start?uid=XXXXXX or ?uid=xxxxxx
            finalUrl = finalUrl.replace(/X{4,}/i, encodeURIComponent(encrypted));

        } else if (finalUrl.endsWith('=')) {
            // URL ends with = (value left empty), just append the encrypted UID
            // e.g. https://survey.com/start?qparm=
            finalUrl += encodeURIComponent(encrypted);

        } else {
            // No placeholder found — safely append uid as a new query parameter
            const separator = finalUrl.includes('?') ? '&' : '?';
            finalUrl += `${separator}uid=${encodeURIComponent(encrypted)}`;
        }

        // 5. Redirect respondent to the client survey
        return NextResponse.redirect(finalUrl);

    } catch (error) {
        console.error("Routing error:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}
