import React from 'react';
import Link from 'next/link';

export const metadata = {
    title: 'Survey Temporarily Paused | Exazon Research',
    description: 'This survey has been temporarily paused by the research team.',
};

export default function SurveyPausedPage() {
    return (
        <>
            <style>{`
                @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');
                
                * { margin: 0; padding: 0; box-sizing: border-box; }

                .paused-body {
                    font-family: 'Poppins', sans-serif;
                    background: linear-gradient(135deg, #0f172a, #1e3a8a, #2563eb);
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    min-height: 100vh;
                    padding: 20px;
                }

                .paused-card {
                    max-width: 700px;
                    width: 100%;
                    background: #fff;
                    border-radius: 20px;
                    padding: 45px;
                    text-align: center;
                    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.25);
                    animation: fadeInUp 0.5s ease;
                }

                @keyframes fadeInUp {
                    from { opacity: 0; transform: translateY(30px); }
                    to   { opacity: 1; transform: translateY(0); }
                }

                .paused-icon {
                    font-size: 72px;
                    line-height: 1;
                    margin-bottom: 10px;
                    display: block;
                }

                .paused-card h1 {
                    font-size: 36px;
                    color: #1f2937;
                    margin: 15px 0;
                    font-weight: 700;
                }

                .paused-card p {
                    font-size: 16px;
                    color: #6b7280;
                    line-height: 1.75;
                    margin: 12px 0;
                }

                .paused-notice {
                    margin: 25px 0;
                    padding: 18px 20px;
                    background: #fef3c7;
                    border-left: 5px solid #f59e0b;
                    border-radius: 10px;
                    color: #92400e;
                    text-align: left;
                    font-size: 15px;
                    line-height: 1.6;
                }

                .paused-notice strong {
                    display: block;
                    margin-bottom: 4px;
                    font-size: 16px;
                }

                .paused-btn {
                    display: inline-block;
                    margin-top: 18px;
                    background: #2563eb;
                    color: #fff;
                    padding: 14px 32px;
                    text-decoration: none;
                    border-radius: 10px;
                    font-weight: 600;
                    font-size: 15px;
                    transition: background 0.2s;
                }

                .paused-btn:hover {
                    background: #1d4ed8;
                    color: #fff;
                    text-decoration: none;
                }

                .paused-footer {
                    margin-top: 28px;
                    font-size: 13px;
                    color: #9ca3af;
                }
            `}</style>

            <div className="paused-body">
                <div className="paused-card">
                    <span className="paused-icon">⏸️</span>
                    <h1>Survey Temporarily Paused</h1>
                    <p>
                        Thank you for your interest. This survey has been temporarily paused
                        by the research team and is not accepting new responses at the moment.
                    </p>

                    <div className="paused-notice">
                        <strong>What does this mean?</strong>
                        The project may resume later, reach its response quota, or be under review.
                        Please check back later or contact the survey provider if you believe you
                        reached this page in error.
                    </div>

                    <p>We appreciate your patience and understanding.</p>

                    <a href="/" className="paused-btn">Return to Home</a>

                    <div className="paused-footer">© 2026 Exazon Research. Thank you for your time.</div>
                </div>
            </div>
        </>
    );
}
