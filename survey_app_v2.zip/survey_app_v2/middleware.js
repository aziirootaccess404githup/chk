import { createServerClient } from '@supabase/ssr';
import { NextResponse } from 'next/server';

export async function middleware(request) {
    // ===== MAINTENANCE MODE =====
    const MAINTENANCE_MODE = false;
    const pathname = request.nextUrl.pathname;
    const isMaintenanceExempt =
        pathname.startsWith('/_next') ||
        pathname.startsWith('/images') ||
        pathname === '/favicon.ico' ||
        pathname === '/survey-paused' ||
        pathname.startsWith('/r/') ||         // keep live survey links working
        pathname.startsWith('/api/') ||        // keep API routes working
        pathname.startsWith('/panel/redirect/');
    
    if (MAINTENANCE_MODE && !isMaintenanceExempt) {
        const url = request.nextUrl.clone();
        url.pathname = '/survey-paused';
        return NextResponse.redirect(url);
    }
    // ===========================

    let supabaseResponse = NextResponse.next({ request });

    const supabase = createServerClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
        {
            cookies: {
                getAll() {
                    return request.cookies.getAll();
                },
                setAll(cookiesToSet) {
                    cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
                    supabaseResponse = NextResponse.next({ request });
                    cookiesToSet.forEach(({ name, value, options }) =>
                        supabaseResponse.cookies.set(name, value, options)
                    );
                },
            },
        }
    );

    // Refresh session if expired
    const { data: { user } } = await supabase.auth.getUser();

    const isAuthRoute = pathname.startsWith('/login') || pathname.startsWith('/admin-login');
    const isAdminRoute = pathname.startsWith('/admin') && !pathname.startsWith('/admin-login');
    
    // Define routes that do NOT require authentication
    const isPublicRoute =
        pathname.startsWith('/panel/redirect/') ||   // Client-facing redirect confirmation pages
        pathname.startsWith('/r/') ||                // Respondent survey entry links
        pathname.startsWith('/client-redirect/') ||  // Client-Level Redirect (permanent per-client URL)
        pathname.startsWith('/api/') ||              // All API routes
        pathname.startsWith('/client-portal/') ||    // Client Portal — its own separate cookie-auth, not Supabase Auth
        pathname.startsWith('/_next') ||
        pathname.startsWith('/images') ||
        pathname.startsWith('/css') ||
        pathname.startsWith('/js') ||
        pathname.startsWith('/assets') ||
        pathname === '/favicon.ico';

    // Redirect unauthenticated users
    if (!user && !isAuthRoute && !isPublicRoute) {
        const url = request.nextUrl.clone();
        if (isAdminRoute) {
            url.pathname = '/admin-login';
        } else {
            url.pathname = '/login';
        }
        return NextResponse.redirect(url);
    }

    // Redirect authenticated users away from login pages
    if (user && isAuthRoute) {
        const url = request.nextUrl.clone();
        url.pathname = '/';
        return NextResponse.redirect(url);
    }

    return supabaseResponse;
}

export const config = {
    matcher: [
        '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
    ],
};
