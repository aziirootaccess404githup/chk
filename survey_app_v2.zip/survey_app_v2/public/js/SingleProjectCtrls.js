$(document).ready(function () {
    //$("#ProjectManager").autocomplete({
    //    source: function (request, response) {
    //        
    //        var projectManager = document.getElementById('ProjectManager').value;
    //        $.ajax({
    //            url: '/Admin/User/ProjectManagerdetails?ProjectManager=' + projectManager,
    //            dataType: "json",
    //            type: "GET",
    //            contentType: "application/json; charset=utf-8",
    //            success: function (data) {

    //                response($.map(data.userlist, function (item) {
    //                    //return item;
    //                    return { label: item.userName, value: item.userId };
    //                }))
    //            },
    //            error: function (response) {
    //            //    alert(response.responseText);
    //            },
    //            failure: function (response) {
    //           //     alert(response.responseText);
    //            },
    //        });
    //    },
    //    appendTo: "#manager",
    //    select: function (event, ui) {
    //        // alert(ui.item.value);
    //        $("#ManagerId").val(ui.item.value);
    //        ui.item.value = ui.item.label;
    //        $("#ProjectManager").html(ui.item.label);


    //    },
    //    minLength: 1

    //});

   

});
$('#ddllink').show();
$('#SingleLink').click(function () {
    $('#ddllink').show();
    $('#linkerror').hide();
});
$('#MultiLink').click(function () {
    $('#ddllink').hide();
    $('#linkerror').hide();
});
$('#Speeder').click(function () {
    if ($("#Speeder").is(":checked")) {
        $('#ddlSpeeder').show();
    }
    else {
        $('#ddlSpeeder').hide();

    }

});
$('#UniqueIP').click(function () {
    if ($("#UniqueIP").is(":checked")) {
        $('#ddlUniqueIP').show();
       //$('#UniqueIPTxt').val(1);

    }
    else {
        //$("#UniqueIPTxt").val(0);
        $('#ddlUniqueIP').hide();
    }

});

$('#IsChecksum').click(function () {

    if ($("#IsChecksum").is(":checked")) {
        $('#ddlIsChecksum').show();
    }
    else {
        SecretKey = $("#txtchecksum").val(0);
        $('#ddlIsChecksum').hide();

    }
});
//$('#PreScreens').click(function () {

//    if ($("#PreScreens").is(":checked")) {
//        $('#ddlLanguageId').show();
//    }
//    else {
//        $("#LanguageId").val(null);
//        $('#ddlLanguageId').hide();
//    }
//});
//$('#LanguageId').on('change', function () {
//    if ($('#LanguageId').val() != "") {
//        $('#LanguageIderror').hide();
//    }
//    else {
//        $('#LanguageIderror').show();
//    }
//});
$('#CurrencyCode').on('change', function () {
    if ($('#CurrencyCode').val() != "") {
        $('#Currenceerror').hide();
    }
    else {
        $('#Currenceerror').show();
    }
});



