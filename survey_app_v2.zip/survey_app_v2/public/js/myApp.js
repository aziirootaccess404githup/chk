/// <reference path="angular.js" />
 
(function () {
    var App = angular.module('ConnectApp', []);
    
})();   