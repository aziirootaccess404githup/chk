$(function () {
    $('.navigation-menu > li > a').each(function () {
        if ($(this).prop('href') === window.location.href) {
            $(this).parent().addClass('active');
        }
    });
    $('.navigation-menu > li > ul > li > a').each(function () {
        if ($(this).prop('href') === window.location.href) {
            $(this).parent().parent().parent().addClass('active');
             $(this).parent().addClass('active');
            return false;
        }
    });
    $('.navigation-menu > li > ul > li > ul > li a').each(function () {
        if ($(this).prop('href') === window.location.href) {
            $(this).parent().parent().parent().parent().parent().addClass('active');
            $(this).parent().parent().parent().addClass('active');
            $(this).parent().parent().child('a').addClass('active');
            $(this).parent().addClass('active');
            return false;
        }
    });

});

$(document).ready(function () {
    $("body").tooltip({ show: { effect: "blind", duration: 100 } });
    $("body .qsGrid").tooltip({ hide: { effect: "bounce", delay: 10, duration: 0 } });
    
    //Project details accordion
    //$(".accordionProjectsWraps .card-header button").click(function () {
    //    $(this).find(".accordIcon i").toggleClass('fa-chevron-up fa-chevron-down');
    //    $(".accordionProjectsWraps .card-header button i").removeClass("fa-chevron-up").addClass("fa-chevron-down"); 
    //});

 
    //accordion default open one
    //$('[data-toggle="collapse"]').on('click', function (e) {
    //    if ($(this).parents('.accordion.accordionProjectsWraps').find('.collapse.show')) {
    //        var idx = $(this).index('[data-toggle="collapse"]');
    //        if (idx == $('.collapse.show').index('.collapse')) {
    //            // prevent collapse
    //            e.stopPropagation();
    //        }
    //    }
    //});
    //Project Single
    $(".toggleMoreBtn a").click(function () {
        $(".toggleMoreBtn a i").toggleClass('fa-plus fa-minus');
    });
    //Project Index
    $('#Projectslist .tile_count .card-body').click(function () {
        if (!$(this).hasClass('active')) {
            $("#Projectslist .tile_count .card-body.active").removeClass("active");
            $(this).addClass("active");
        }
    });
    //common tabs
    $('.tabPanelWraps .tile_count .card-body').click(function () {
        if (!$(this).hasClass('active')) {
            $(".tabPanelWraps .tile_count .card-body.active").removeClass("active");
            $(this).addClass("active");
        }
    });
    $(function () {
        $('.tabPanelWraps .numTabSM .bgA ').click(function () {
            $('.tabPanelWraps .numTabSM .bgA.active').removeClass('active');
            $(this).addClass('active');
        });
    });
    //Project mapping edit btn click
    $(document).on('click', '.editsupplier', function (event) {
        event.preventDefault();
        $(".toggleMoreBtn .suppliertab i").removeClass("fa-plus").addClass("fa-minus");
        $("#addsupplierq").addClass("show");
    });
});






