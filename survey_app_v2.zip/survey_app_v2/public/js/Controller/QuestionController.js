var App = angular.module('ConnectApp');
App.controller('ListCntrl', function ($scope, $filter, ListCntrlOp, paginationService, PrescreenProjectService, $location, $timeout) {//
    $('#update').hide();
    $scope.QuestionList = [];
    $scope.LanguageList = [];
    $scope.norocords = false;
    $scope.AddQuestion = [];
    $scope.Subcategory = [];
    $scope.Subcategorylist = [];
    $scope.AddQuestion.questionOption = [];
    $scope.pageSize = '10';
    $scope.currentPage = 1;
    $scope.questionId = "";
    $scope.questionDesc = "";
    $scope.questionTitle = "";
    $scope.isvalidquestionTitle = true;
    $scope.minVal = 1;
    $scope.maxVal = 5;
    $scope.totalPages = 0;
    $scope.LanguageCode = "";
    $scope.CntrlTypeId = "";
    $('.clearCrossIcon').hide();
    $('#txtlength').hide();
    $('#minlength').val(0);
    $('#maxlength').val(0);

    function GetList(languageCode, countryCode) {
        $('#Languagevalidation').html('');
        $('#Countryvalidation').html('');
        //$('#Controltypevalidation').html('');
        var requestResponse = ListCntrlOp.GetLists(languageCode, countryCode);
        requestResponse.then(function (response1) {

            $scope.QuestionList = response1.data.questionList
            if ($scope.QuestionList.length > 0) {
                $scope.norocords = true;
            } else {
                $scope.norocords = false;
            }
            $scope.totalPages = Math.round(($scope.QuestionList.length) / ($scope.pageSize));
        }, function () {

        });
    };

    $("#ddlControlTypeId").on('change', function () {
        $scope.CntrlTypeId = $('#ddlControlTypeId').val();
        $('#optiondiv').show();
        $('#txtlength').hide();
        if ($scope.CntrlTypeId === "") {
            $('#Controltypevalidation').html('Please select Control Type');
        }
        else {
            if ($scope.CntrlTypeId == "1") {
                $('#btnoptions').prop("disabled", true);
                $('#optiondiv').hide();
                $('#txtlength').show();
            }
            else {
                $('#btnoptions').prop("disabled", false);
                $('#maxlengtherror').html('');
                $('#minlengtherror').html('');
                $('#texttypevalidation').html('');
            }
            $('#Controltypevalidation').html('');
        }
    });

    $scope.GetLanguageList = function () {
        $('#Countryvalidation').html('');
        var countryCode = document.getElementById('CountryCode').value;
        if (countryCode !== "") {
            var requestResponse = ListCntrlOp.GetLanguageByCountryCode(countryCode);
            requestResponse.then(function successCallback(response) {
                $scope.LanguageList = response.data.languagelist;
            });          
            var languageCode = document.getElementById('LanguageCode').value;
            if (languageCode !== "" && countryCode !== "") {
                GetList(languageCode, countryCode);
            }
            else {
                $scope.QuestionList = [];
            }
        } else {
            $scope.LanguageList = [];
            $scope.QuestionList = [];
        }
    };

    $scope.GetQuestionList = function () {
        $('#Languagevalidation').html('');
        $("#questionTitle").val('');
        var languageCode = document.getElementById('LanguageCode').value;
        var countryCode = document.getElementById('CountryCode').value;
        if (languageCode !== "" && countryCode !== "") {
            GetList(languageCode, countryCode);
        }
        else {
            $scope.QuestionList = [];
        }
    };

    $scope.submit = async function () {
        $('.loader').show();
        var UserCtrlForm = window.$("#add_client_form");
        var isUserCtrlForm = UserCtrlForm.valid();

        if ($('#LanguageCode').val() === "" && $('#CountryCode').val() === "" && $('#ddlControlTypeId').val() === "") {
            $('#Languagevalidation').html('Please select language');
            $('#Countryvalidation').html('Please select Country');
            $('#Controltypevalidation').html('Please select Control Type');
            $('#questionTitleerror').html('This field is required');
            $('#questionerror').html('This field is required');
            isUserCtrlForm = false;
            $('.loader').hide();
        }

        if (($('#ddlControlTypeId option:selected').text().trim().toLowerCase() == "radio" || $('#ddlControlTypeId option:selected').text().trim().toLowerCase() == "checkbox") && $scope.AddQuestion.questionOption.length < 2) {
            // $('#optionlisterror').html("Please add more than one option");
            swal({ title: "", text: "Please add more than one mapped option", closeOnClickOutside: false });
            $('#Optionlisterror').show();
            isUserCtrlForm = false;
            $('.loader').hide();
            return false;
        }
        if ($('#LanguageCode').val() === "") {
            $('#Languagevalidation').html('Please select language');
            $('.loader').hide();
            isUserCtrlForm = false;
            $('.loader').hide();
        }
        if ($('#CountryCode').val() === "") {
            $('#Countryvalidation').html('Please select Country');
            $('.loader').hide();
            isUserCtrlForm = false;
            $('.loader').hide();
        }
        if ($('#ddlControlTypeId').val() === "") {
            $('#Controltypevalidation').html('Please select Control Type');
            $('.loader').hide();
            isUserCtrlForm = false;
        }

        if ($scope.isvalidquestionTitle == false) {
            $('.loader').hide();
            $('#questionTitleerror').html('This Question Title is already available');
            isUserCtrlForm = false;
            return false;
        }


        if ($scope.CntrlTypeId == '1') {
            if ($('#minlength').val() == '' || $('#minlength').val() == 0) {
                ($('#minlength').val() != '') ? $('#minlengtherror').html('Value should be greater than 0') : $('#minlengtherror').html('This field is required');
                isUserCtrlForm = false;
            }
            if ($('#maxlength').val() == '' || $('#maxlength').val() == 0) {
                ($('#maxlength').val() != '') ? $('#maxlengtherror').html('Value should be greater than 0') : $('#maxlengtherror').html('This field is required');               
                isUserCtrlForm = false;
            }
            if (parseInt($('#minlength').val()) > parseInt($('#maxlength').val())) {
                $('#maxlengtherror').html('Max Length should be greater from Min Length');
                isUserCtrlForm = false;
            }
            if ($('#textTypeId').val() === "") {
                $('#texttypevalidation').html('Please select Text Type');
                isUserCtrlForm = false;
            }
        }
        if (isUserCtrlForm) {
            $scope.AddQuestion.questionTitle = $scope.questionTitle;
            $scope.AddQuestion.questionDesc = $scope.questionDesc;
            //$scope.AddQuestion.CategoryId = parseInt(document.getElementById('CategoryId').value);
            $scope.AddQuestion.LanguageCode = document.getElementById('LanguageCode').value;
            $scope.AddQuestion.CountryCode = document.getElementById('CountryCode').value;
            $scope.AddQuestion.ControlTypeId = parseInt(document.getElementById('ddlControlTypeId').value);
            $scope.AddQuestion.questionOption = $scope.AddQuestion.questionOption;
            $scope.AddQuestion.mapping = $scope.AddQuestion.questionOption;
            $scope.AddQuestion.MinLength = document.getElementById('minlength').value;
            $scope.AddQuestion.MaxLength = document.getElementById('maxlength').value;
            $scope.AddQuestion.TextTypeId = document.getElementById('textTypeId').value;
            var requestResponse = ListCntrlOp.AddQuestion($scope.AddQuestion);
            requestResponse.then(function (response) {
                $('.loader').hide();

                if (response.data.message === "SuccessFully Saved.") {
                    swal({ title: "", text: "Question added successfully!", type: "success", closeOnClickOutside: false }).then((type) => {
                        GetList(document.getElementById('LanguageCode').value, document.getElementById('CountryCode').value);
                        window.location.href = '/Admin/Question';
                    });
                }
                else {
                    $('.loader').hide();
                    //swal({ title: "", text: response.data.message, type: "error", closeOnClickOutside: false });
                }
            }, function () {

            });
        }
        else {
            $('.loader').hide();
            return false;
        }
    };

    $scope.TempAddQuestion = [];
    $scope.Edit = function (id) {
        $scope.reset();
        $('.loader').show();
        $('#update').show();
        $('#submit').hide();
        $('#btnoptions').prop("disabled", false);
        $('#Optionlist').prop("disabled", false);
        $('#ddlControlTypeId').prop("disabled", false);
        $('#QuestionDesc-error').html('');
        $('#questionTitle-error').html('');
        $('#minlength').val(0);
        $('#maxlength').val(0);
        $('#minlengtherror').html('');  
        $('#maxlengtherror').html('');  
        $('#textTypeId').val('');
        $('#textTypeId').trigger('change');
        $('#texttypevalidation').html('');
        var QuestionMappingResponse = PrescreenProjectService.GetQuestionMappingResponse(id);
        QuestionMappingResponse.then(function (result) {
            if (result.data.message !== "") {
                $('#Optionlist').prop("disabled", true);
                $('#ddlControlTypeId').prop("disabled", true);
            }
        });

        $scope.editData = $filter('filter')($scope.QuestionList, { 'questionId': id })[0];
        $scope.questionDesc = $scope.editData.questionDesc;
        $('#QuestionDesc').val($scope.questionDesc);
        $scope.questionId = $scope.editData.questionId;
        $scope.questionTitle = $scope.editData.questionTitle;
        $('#questionTitle').val($scope.questionTitle);
        var QuestionOptionResponse = PrescreenProjectService.EditGetQuestionOptionbyQuestionId(id);
        QuestionOptionResponse.then(function (response) {
            $('.loader').hide();
            $.each(response.data.questionOptionlist, function (i, data) {
                $('#Optionlist').append('<option value=' + data.optionId + '>' + data.questionOptionDesc + '</option>');

            });
            angular.forEach(response.data.questionOptionlist, function (item) {
                $scope.TempAddQuestion.push(item.questionOptionDesc);
            });
            if ($scope.TempAddQuestion != null) {
                angular.forEach($scope.TempAddQuestion, function (item) {
                    $scope.AddQuestion.questionOption.push(item);
                });
            }
        });
        //document.getElementById('CategoryId').value = $scope.editData.categoryId;
        document.getElementById('CountryCode').value = $scope.editData.countryCode;
        document.getElementById('LanguageCode').value = $scope.editData.languageCode;
        document.getElementById('ddlControlTypeId').value = $scope.editData.controlTypeId;
        $('#LanguageCode').trigger('change');
        $('#ddlControlTypeId').trigger('change');
        if ($scope.editData.controlTypeId == 1) {
            document.getElementById('minlength').value = $scope.editData.minLength;
            document.getElementById('maxlength').value = $scope.editData.maxLength;
            document.getElementById('textTypeId').value = $scope.editData.textTypeId;
            $('#textTypeId').trigger('change');
        }
    };
    $(function () {

        $('#btnoptions').click(function (e) {


            var name = $("#txtoptions").val().split('\n');
            $.each(name, function (i, value) {
                if (value.trim() !== '') {
                    $('#Optionlist').
                        append($("<option></option>").
                            attr("value", value).
                            text(value));
                    $scope.AddQuestion.questionOption.push(value);

                }
            });
            $("#txtoptions").val('');
            // $('#Optionlisterror').hide();
        });
    });


    $scope.update = function () {
        $('.loader').show();
        var UserCtrlForm = window.$("#add_client_form");
        var isUserCtrlForm = UserCtrlForm.valid();
        if ($('#LanguageCode').val() === "") {
            $('#Languagevalidation').html('Please select language');
            $('.loader').hide();
            isUserCtrlForm = false;
            return false;
        }
        if ($('#CountryCode').val() === "") {
            $('#Countryvalidation').html('Please select Country');
            $('.loader').hide();
            isUserCtrlForm = false;
            return false;
        }
        if ($('#ddlControlTypeId').val() === "") {
            $('#Controltypevalidation').html('Please select Control Type');
            $('.loader').hide();
            isUserCtrlForm = false;
            return false;
        }
        if ($scope.isvalidquestionTitle == false) {
            $('.loader').hide();
            $('#questionTitleerror').html('This Question Title is already available');
            isUserCtrlForm = false;
            return false;
        }
        if (($('#ddlControlTypeId option:selected').text().trim().toLowerCase() == "radio" || $('#ddlControlTypeId option:selected').text().trim().toLowerCase() == "checkbox") && $scope.AddQuestion.questionOption.length < 2) {
            // $('#optionlisterror').html("Please add more than one option");
            swal({ title: "", text: "Please add more than one option", closeOnClickOutside: false });
            $('#Optionlisterror').show();
            isUserCtrlForm = false;
            $('.loader').hide();
            return false;
        }

        if ($scope.CntrlTypeId == '1') {
            if ($('#minlength').val() == '' || $('#minlength').val() == 0) {
                ($('#minlength').val() != '') ? $('#minlengtherror').html('Value should be greater than 0') : $('#minlengtherror').html('This field is required');
                isUserCtrlForm = false;
            }
            if ($('#maxlength').val() == '' || $('#maxlength').val() == 0) {
                ($('#maxlength').val() != '') ? $('#maxlengtherror').html('Value should be greater than 0') : $('#maxlengtherror').html('This field is required');
                isUserCtrlForm = false;
            }
            if (parseInt($('#minlength').val()) > parseInt($('#maxlength').val())) {
                $('#maxlengtherror').html('Max Length should be greater from Min Length');
                isUserCtrlForm = false;
            }
            if ($('#textTypeId').val() === "" || $('#textTypeId').val() == null) {
                $('#texttypevalidation').html('Please select Text Type');
                isUserCtrlForm = false;
            }
        }

        if (isUserCtrlForm) {
            $scope.AddQuestion.questionId = $scope.questionId;
            $scope.AddQuestion.questionTitle = $scope.questionTitle;
            $scope.AddQuestion.questionDesc = $scope.questionDesc;
            $scope.questionId = $scope.editData.questionId;
            //$scope.AddQuestion.CategoryId = parseInt(document.getElementById('CategoryId').value);
            $scope.AddQuestion.CountryCode = document.getElementById('CountryCode').value;
            $scope.AddQuestion.LanguageCode = document.getElementById('LanguageCode').value;
            $scope.AddQuestion.ControlTypeId = parseInt(document.getElementById('ddlControlTypeId').value);
            //$scope.AddQuestion.SubCategoryId = document.getElementById('SubCategoryId').value;
            $scope.AddQuestion.mapping = $scope.AddQuestion.questionOption;
            $scope.AddQuestion.MinLength = document.getElementById('minlength').value;
            $scope.AddQuestion.MaxLength = document.getElementById('maxlength').value;
            $scope.AddQuestion.TextTypeId = document.getElementById('textTypeId').value;
            var requestResponse = ListCntrlOp.UpdateQuestion($scope.AddQuestion);
            requestResponse.then(function (response) {
                $('.loader').hide();


                if (response.data.message === "SuccessFully Saved.") {
                    swal({ title: "", text: "Question updated successfully!", type: "success", closeOnClickOutside: false }).then((type) => {
                        GetList(document.getElementById('LanguageCode').value, document.getElementById('CountryCode').value);
                        window.location.href = '/Admin/Question';
                    });
                }
                else {
                    $('.loader').hide();
                    //swal({ title: "", text: response.data.message, type: "error", closeOnClickOutside: false });
                }
            }, function () {

            });
        }
        else {
            $('.loader').hide();
            return false;
        }
    };

    $scope.reset = function (id) {
        $('#update').hide();
        $('#submit').show();
        document.getElementById("Optionlist").options.length = 0;
        $scope.questionTitle = "";
        $scope.questionDesc = "";
        document.getElementById('ddlControlTypeId').value = "";
        $scope.CtrlTypeId = document.getElementById('ddlControlTypeId').value;
        $('#ddlControlTypeId').trigger('change');
        $('#Controltypevalidation').html('');
        $('#ddlControlTypeId').prop("disabled", false);
        $('#Optionlist').prop('disabled', false);
        $('#btnoptions').prop("disabled", false);
        $('#minlength').val(0);
        $('#maxlength').val(0);
        $('#minlengtherror').html('');
        $('#maxlengtherror').html('');
        document.getElementById('textTypeId').value = "";
        $('#textTypeId').trigger('change');
        $('#texttypevalidation').html('');
        $scope.AddQuestion.questionOption = [];
        $('#Languagevalidation').html('');
        $('#questionTitle-error').html('');
        $('#QuestionDesc-error').html('');

    };

    $("#CountryCode").on('change', function () {
        $scope.totalPages = 0
        document.getElementById('LanguageCode').value = "";
        document.getElementById('txtoptions').value = "";
        $scope.LanguageCode = "";
        $scope.LanguageList = [];
        $scope.GetLanguageList();
        $('#Languagevalidation').show();
        $scope.QuestionList = [];
        $scope.clearText();
        $scope.reset();
    });

    $scope.cancel = function () {
        if ($scope.SearchQuestionId > 0) {
            $('.loader').show();
            window.location.href = '/Admin/Question/Index';
        }
        else{
            document.getElementById('CountryCode').value = "";
            $('#Languagevalidation').html("");
            $('#questionTitleerror').html("");
            $('#questionerror').html("");
            $('#CountryCode').trigger('change');
            $('#questionTitleerror').html('');
            $scope.clearText();
            $scope.reset();
        }
        
    }
    $scope.RemoveElement = function ($event) {

        var element = angular.element($event.target);
        $("#Optionlist option[value='" + element[0].value + "']").remove();
        if ($scope.AddQuestion.questionOption[0] != null) {
            $scope.AddQuestion.questionOption.splice(element[0].index, 1);
        }
    }

    $scope.CheckQuestionTitle = function () {

        var questionTitle = $("#questionTitle").val();
        var LanguageCode = $("#LanguageCode").val();
        var CountryCode = $("#CountryCode").val();
        if (LanguageCode == null || LanguageCode == "") {
            //alert("Please select Language");
            $('#Languagevalidation').html('Please select language');
            $("#questionTitle").val('');
            return false;
        }
        if (CountryCode == null || CountryCode == "") {
            //alert("Please select Language");
            $('#Countryvalidation').html('Please select Country');
            $("#questionTitle").val('');
            return false;
        }
        var requestResponse = ListCntrlOp.CheckQuestionTitle(questionTitle, LanguageCode, CountryCode);
        requestResponse.then(function (response) {

            if (response.data === "Active") {
                swal({title: "", text: 'This Question Title is already available', closeOnClickOutside: false });
                $('#questionTitleerror').html('This Question Title is already available');
                //$("#questionTitle").val('');
                $scope.isvalidquestionTitle = false;
                return false;
            }
            else {
                $('#questionTitleerror').html('');
                $scope.isvalidquestionTitle = true;
            }

        }, function () {
        });
    };

  



    $scope.selectPage = function (num) {
        $scope.num = num;
        if ($scope.totalPages > 5) {
            if (num > 3) {
                if ((num + 2) > $scope.totalPages) { $scope.maxVal = $scope.totalPages; } else { $scope.maxVal = num + 2; }
                $scope.minVal = $scope.maxVal - 4;
            } else {
                $scope.minVal = 1;
                $scope.maxVal = 5;
            }
        }
        $scope.currentPage = num;
        $scope.GetQuestionList();
    };

    $scope.setIndex = function (type, val) {
        if (angular.lowercase(type) == 'min') {
            if (val < 1) {
                $scope.minVal = 1;
                $scope.maxVal = 5;
            }
            else {
                $scope.minVal = val;
                $scope.maxVal = $scope.minVal + 4;
            }
        }
        if (angular.lowercase(type) == 'max') {
            if (val > $scope.totalPages) {
                $scope.maxVal = $scope.totalPages;
                $scope.minVal = $scope.maxVal - 4;

            }
            else {
                $scope.maxVal = val;
                $scope.minVal = $scope.maxVal - 4;
            }
        }
    };

    $scope.rangeCreator = function (minVal, maxVal) {
        if (maxVal > $scope.totalPages) {
            maxVal = $scope.totalPages;
        }
        var arr = [];
        for (var i = minVal; i <= maxVal; i++) {
            arr.push(i);
        }
        return arr;
    };
    $('#textTypeId').on('change', function () {
        ($('#textTypeId').val() === "") ? $('#texttypevalidation').html('Please select Text Type') : $('#texttypevalidation').html('');
    });

    $('#minlength').on('keyup', function () {
        var minLength = $('#minlength').val();
        var maxLength = $('#maxlength').val();

        if (minLength == '0')
            $('#minlengtherror').html('Value should be greater than 0');

        else if (minLength == '')
            $('#minlengtherror').html('This field is required');

        else if (parseInt(minLength) > parseInt(maxLength))
            $('#minlengtherror').html('Max Length should be greater from Min Length');

        else if (parseInt(minLength) < parseInt(maxLength) && minLength != '0') {
            $('#minlengtherror').html('');
            $('#maxlengtherror').html('');
        }
        else
            $('#minlengtherror').html('');
    });

    $('#maxlength').on('keyup', function () {
        var minLength = $('#minlength').val();
        var maxLength = $('#maxlength').val();

        if (maxLength == '0')
            $('#maxlengtherror').html('Value should be greater than 0');

        else if (maxLength == '')
            $('#maxlengtherror').html('This field is required');

        else if (parseInt(minLength) > parseInt(maxLength))
            $('#maxlengtherror').html('Max Length should be greater from Min Length');

        else if (parseInt(minLength) < parseInt(maxLength) && minLength != '0') {
            $('#minlengtherror').html('');
            $('#maxlengtherror').html('');
        }
        else
            $('#maxlengtherror').html('');

    });

    $('#LanguageCode').on('change', function () {
        if ($scope.SearchQuestionId == 0) {
            $scope.GetQuestionList();
        }
        if ($('#LanguageCode').val() != "") {
            $('#Languagevalidation').hide();
        }
        else {
            $('#Languagevalidation').show();
        }
    });

    $scope.clearText = function () {
        $('#SearchText').val("");
        $scope.query = '';
        $('.clearCrossIcon').hide();
        $scope.currentPage = ($scope.num != null) ? $scope.num: 1;
    }
    $('#SearchText').on("input", function () {
        (this.value !== '') ? $('.clearCrossIcon').show() : $('.clearCrossIcon').hide();
        $scope.currentPage = 1;
    });

    $scope.SearchQuestionId = (($location.absUrl().split('=')[1]) != null) ? $location.absUrl().split('=')[1].split('&')[0] : 0;

    if ($scope.SearchQuestionId > 0) {
        $('#questionGrid').hide();
        $('.loader').show();
        var languageCode = $location.absUrl().split('LanguageCode=')[1].split('&')[0];
        var countryCode = $location.absUrl().split('CountryCode=')[1].split('&')[0];
        $('#CountryCode').val(countryCode).trigger('change');
        $('#LanguageCode').val(languageCode);
        GetList(languageCode, countryCode);
        $timeout(function () {
            if ($scope.SearchQuestionId > 0) {
                $scope.Edit($scope.SearchQuestionId);
            }
        }, 2000);
    }

});

