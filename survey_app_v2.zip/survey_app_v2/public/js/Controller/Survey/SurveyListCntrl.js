/// <reference path="../../angular.js" />

var App = angular.module('ConnectApp');

App.factory('storageService', [function () {

    return {
        get: function (key) {
            return sessionStorage.getItem(key);
        },
        save: function (key, data) {
            sessionStorage.setItem(key, data);
        }
    };
}]);

App.controller('SurveyListCtrl', function (storageService, $scope, SurveyListServices) {

    $scope.pageSize = '10';
    $scope.currentPage = 1;
    $scope.SurveyList = [];
    $scope.CountryList = [];
    $('.clearCrossIcon ').hide();
    $scope.isBackFromProject = '';
    $scope.clientId = '';
    $scope.CountryId = '';

    $scope.GetSurveyList = function () {
        var ClientId = ''; var CountryId = ''; var FromLoi = '';
        var ToLoi = ''; var FromCPI = ''; var ToCPI = '';
        var FromIR = ''; var ToIR = ''; var Fromdate = '';
        var ToDate = ''; var isvalid = true;

        if ($scope.isBackFromProject == "true" && $scope.clientId != "" && $scope.CountryId != "") {
            ClientId = $scope.clientId;
            CountryId = $scope.CountryId;
            storageService.save('clientId', ""); storageService.save('countryId', "");
            storageService.save('FromCpi', ""); storageService.save('ToCPI', "");
            storageService.save('Fromloi', ""); storageService.save('Toloi', "");
            storageService.save('FromIR', ""); storageService.save('ToIR', "");
            storageService.save('FromDate', ""); storageService.save('ToDate', "");
            storageService.save('Search', ""); $scope.isBackFromProject = '';
        }
        else {
            ClientId = $('#ClientId').val();
            CountryId = $('#CountryId').val();
            ($('#SearchText').val() !== '') ? $('.clearCrossIcon ').show() : $('.clearCrossIcon ').hide();
        }

        FromCPI = ($('#FromCPI').val() == "") ? null : parseFloat($('#FromCPI').val(), 2);
        ToCPI = ($('#ToCPI').val() == "") ? null : parseFloat($('#ToCPI').val(), 2);

        FromLoi = ($('#Fromloi').val() == "") ? null : parseInt($('#Fromloi').val());
        ToLoi = ($('#Toloi').val() == "") ? null : parseInt($('#Toloi').val());

        FromIR = ($('#FromIR').val() == "") ? null : parseFloat($('#FromIR').val(), 2);
        ToIR = ($('#ToIR').val() == "") ? null : parseFloat($('#ToIR').val(), 2);

        Fromdate = ($('#FromDate').val() == "") ? null : new Date($('#FromDate').val())//.trim().split("/").reverse().join("-");
        ToDate = ($('#ToDate').val() == "") ? null : new Date($('#ToDate').val())

        if (ClientId == '' && CountryId == '') {
            $('#clientidValidation').html('This field is required');
            $('#clientCountryValidation').html('This field is required');
            isvalid = false;
        }
        if (ClientId == '') {
            $('#clientidValidation').html('This field is required');
            isvalid = false;
        }
        if (CountryId == '') {
            $('#clientCountryValidation').html('This field is required');
            isvalid = false;
        }
        else if (isvalid){

            var data = {
                ClientId: ClientId,
                CountryId: CountryId,
                FromLoi: FromLoi,
                ToLoi: ToLoi,
                FromCPI: FromCPI,
                ToCPI: ToCPI,
                FromLoi: FromLoi,
                ToLoi: ToLoi,
                FromIR: FromIR,
                ToIR: ToIR,
                Fromdate: Fromdate,
                ToDate: ToDate,
            }
            $('.loader').show();
            var requestResponse = SurveyListServices.GetSurveyList(data);
            requestResponse.then(function (response) {
                $('.loader').hide();
                $scope.SurveyList = response.data.survyeList;
            }, function () {

            });
        }             
    }

    $('#ClientId').on('change', function () {
        GetClientCountryList();
        ($('#ClientId').val() !== '') ? $('#clientidValidation').html('') : $('#clientidValidation').html('This field is required');
        $scope.query = '';
        $scope.SurveyList = [];
        $scope.clearText();
    });

    $('#CountryId').on('change', function () {
        ($('#CountryId').val() !== '') ? $('#clientCountryValidation').html('') : $('#clientCountryValidation').html('This field is required');  
    });

    function GetClientCountryList() {
        $('.loader').show();
        $scope.CountryList = [];
        var client = $('#ClientId option:selected').text();
        var requestResponse = SurveyListServices.GetClientCountryList(client);
        requestResponse.then(function (response) {
            $('.loader').hide();
            $scope.CountryList = response.data;
        }, function () {
            $('.loader').hide();
        });
        $('#clientCountryValidation').html('');
    }
    $scope.reloadRoute = function () {
        $('.loader').show();
        $scope.SurveyList = [];
        $scope.CountryList = [];
        $('#ClientId').val('');
        $('#FromCPI').val('');
        $('#ToCPI').val('');
        $('#Fromloi').val('');
        $('#Toloi').val('');
        $('#FromIR').val('');
        $('#ToIR').val('');
        $('#FromDate').val('');
        $('#ToDate').val('');
        $('.toggleMoreBtn i').addClass('fa-plus').removeClass('fa-minus');
        $('#advancesearch').removeClass('show');
        $('#ClientId').trigger('change');
        $('#clientidValidation').html('');
        $('#clientCountryValidation').html(''); 
        $('.loader').delay(2000).hide(200);        
    }
    $scope.clearText = function () {
        $('#SearchText').val("");
        $scope.query = '';        
        $('.clearCrossIcon ').hide();
    }
    $('#SearchText').on("input", function () {
        (this.value !== '') ? $('.clearCrossIcon ').show() : $('.clearCrossIcon ').hide();
        $scope.query = $('#SearchText').val();        
    });

    $scope.PersistData = function () {        
        $scope.isBackFromProject = window.location.href.split('=')[1];

        if ($scope.isBackFromProject == "true") {

            $scope.clientId = storageService.get('clientId');
            $scope.CountryId = storageService.get('countryId');

            $scope.FromCPI = storageService.get('FromCpi');
            $scope.ToCPI = storageService.get('ToCPI');
            $scope.Fromloi = storageService.get('Fromloi');
            $scope.Toloi = storageService.get('Toloi');
            $scope.FromIR = storageService.get('FromIR');
            $scope.ToIR = storageService.get('ToIR');
            $scope.FromDate = storageService.get('FromDate');
            $scope.ToDate = storageService.get('ToDate');

            if ($scope.clientId != "" && $scope.CountryId != "") {               
                window.$('#ClientId').val($scope.clientId).trigger('change');
                window.$('#CountryId').val($scope.CountryId).trigger('change');

                if ($scope.FromCpi != "")
                    window.$('#FromCPI').val($scope.FromCPI);
                if ($scope.ToCPI != "")
                    window.$('#ToCPI').val($scope.ToCPI);
                if ($scope.Fromloi != "")
                    window.$('#Fromloi').val($scope.Fromloi);
                if ($scope.Toloi != "")
                    window.$('#Toloi').val($scope.Toloi);
                if ($scope.FromIR != "")
                    window.$('#FromIR').val($scope.FromIR);
                if ($scope.ToIR != "")
                    window.$('#ToIR').val($scope.ToIR);
                if ($scope.FromDate != "")
                    window.$('#FromDate').val($scope.FromDate);
                if ($scope.ToDate != "")
                    window.$('#ToDate').val($scope.ToDate);

                $scope.query = storageService.get('Search');
                ($scope.query !== '') ? $('.clearCrossIcon ').show() : $('.clearCrossIcon ').hide();
                $scope.GetSurveyList();                
            }
        }
    }
    $scope.PersistData();

    $scope.SaveData = function () {
        storageService.save('clientId', $('#ClientId').val());
        storageService.save('countryId', $('#CountryId').val());
        storageService.save('Search', $scope.query);

        if ($('#FromCPI').val() != "")
            storageService.save('FromCpi', $('#FromCPI').val());
        if ($('#ToCPI').val() != "")
            storageService.save('ToCPI', $('#ToCPI').val());
        if ($('#Fromloi').val() != "")
            storageService.save('Fromloi', $('#Fromloi').val());
        if ($('#Toloi').val() != "")
            storageService.save('Toloi', $('#Toloi').val());
        if ($('#FromIR').val() != "")
            storageService.save('FromIR', $('#FromIR').val());
        if ($('#ToIR').val() != "")
            storageService.save('ToIR', $('#ToIR').val());
        if ($('#FromDate').val() != "")
            storageService.save('FromDate', $('#FromDate').val());
        if ($('#ToDate').val() != "")
            storageService.save('ToDate', $('#ToDate').val());
    }
});