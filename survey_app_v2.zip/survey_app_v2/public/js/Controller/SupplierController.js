/// <reference path="../angular.js" />

var App = angular.module('ConnectApp');
App.controller('SupplierCtrlcontroller', function ($scope, SupplierService) {
    $scope.SupplierPanelBody = [];
    $scope.IsAPIlink = false;
    MultiselectDropdown();
    $scope.AllowedCountries = [];
    $scope.AllowedCountriesList = [];
    $scope.IsRouter = false;

    $scope.btnSupplierForm = function (command) {
        $('.loader').show();
        var supplierCtrlForm = window.$("#SupplierCtrlForm");
        var isSupplierFormValid = supplierCtrlForm.valid();
        if ($('#SupplierContactNo').val() == "0000000000") {
            swal({ title: "", text: "Invalid Contact Number", closeOnClickOutside: false });
            $('.loader').hide();
            isSupplierFormValid = false;
            return false;
        }
        var hashchecked = false;
        if ($("#hashURL").is(":checked")) {
            hashchecked = true;
        }
        var IsAPI = false;
        if ($("#IsAPI").is(":checked")) {
            IsAPI = true;
        }
        if ($('#AllowedCountryCode').val().length == 0) {
            swal({ title: "", text: "Please Select Allowed Project Country", type: "warning", closeOnClickOutside: false });
            $('.loader').hide();
            return false;
        }
        var IsMaskEntry = false;
        if ($("#IsMaskEntry").is(":checked")) {
            IsMaskEntry = true;
        }

        if ($scope.IsRouter == true) {
            if ($('#RedirectPostBackUrl').val() == "") {
                swal({ title: "", text: "Please Enter PostBack URL", type: "warning", closeOnClickOutside: false });
                $('.loader').hide();
                return false;
            }
        }

        var IsAffiliate = false;
        if ($("#IsAffiliate").is(":checked")) {
            IsAffiliate = true;
        }
        var IsAutoMap = false;
        if ($("#AutoMap").is(":checked")) {
            IsAutoMap = true;
        }
        if (isSupplierFormValid !== false) {
            if (command === "Save") {
                var data = {
                    SupplierId: 0,
                    SupplierCode: null,
                    IsRemoved: false,
                    SupplierName: $('#SupplierName').val(),
                    SupplierWebsite: $('#SupplierWebsite').val(),
                    SupplierContactNo: $('#SupplierContactNo').val(),
                    SupplierEmail: $('#SupplierEmail').val(),
                    SupplierPanelSize: $('#SupplierPanelSize').val(),
                    SupplierDescription: $('#SupplierDescription').val(),
                    CountryId: $("#CountryId").val(),
                    CountryName: $("#CountryId").find("option:selected").text().trim(),
                    CountryCode: null,
                    RedirectQualityTerm: $('#RedirectQualityTermj').val(),
                    ReDirectComplete: $('#ReDirectComplete').val(),
                    ReDirectTerminate: $('#ReDirectTerminate').val(),
                    ReDirectQuotaFull: $('#ReDirectQuotaFull').val(),
                    RedirectSurveyClose: $('#RedirectSurveyClose').val(),
                    RedirectPostBackUrl: $('#RedirectPostBackUrl').val(),
                    IsAPI: IsAPI,
                    APIKey: $('#APIKey').val(),
                    APISecretKey: $('#APISecretKey').val(),
                    APIUrl: $('#APIUrl').val(),
                    APIBody: $('#APIBody').val(),
                    IsHashing: hashchecked,
                    AllowedCountryCode: $('#AllowedCountryCode').val(),                    
                    IsMaskEntry: IsMaskEntry,
                    IsAffiliate: IsAffiliate,
                    IsRouter: $scope.IsRouter,
                    AutoMap: IsAutoMap
                };
                
                window.$("#btnSave").attr("disabled", "disabled");
                var UserService = SupplierService.AddandEditServices(data);
                
                UserService.then(function successCallback(response) {
                    $('.loader').hide();
                    if (response.data.message === "SuccessFully Saved.") {
                        swal({ title: "", text: "Supplier added successfully!", type: "success", closeOnClickOutside: false }).then((type) => {
                     //   swal("", "Supplier Added Successfully!", "success").then((type) => {
                            if (type) {
                                window.location.href = '/Admin/Supplier/Index';
                            }
                        });
                    }
                    else if (response.data.message === "Duplicate") {
                        swal({ title: "", text: "Supplier Name Already Exists", type: "error", closeOnClickOutside: false });
                        $('#btnSave').attr('disabled', false);
                    }
                    else {
                        $('.loader').hide();
                        swal({ title: "Error!", text: response.data.message == "" ? "Something went wrong.Please try again!" : response.data.message, type: "error", closeOnClickOutside: false });
                      //  swal("Error..!", response.data.message, "error");

                        $('#btnSave').attr('disabled', false);
                         
                    }
                }, function errorCallback(response) {
                        $('.loader').hide();
                        swal({ title: "Error!", text: response.data.message == "" ? "Something went wrong.Please try again!" : response.data.message, type: "error", closeOnClickOutside: false });
                       // alert(response.data.message);
                        window.Location.href = '/Admin/Supplier/AddSupplier';
                    // called asynchronously if an error occurs  
                    // or server returns response with an error status.  
                });
            }
        }
        else {
            $('.loader').hide();
        }
    };
    $scope.Add = function () {

        //Check validation of order item
        if ($("#CountryId2").find("option:selected").text().trim() === '' || $("#CountryId2").find("option:selected").text().trim() === '-- Select Country --') {
            $('#CountryId2').siblings('span.error').css('visibility', 'visible');
            return;
        }
        else {
            $('#CountryId2').siblings('span.error').css('visibility', 'hidden');
        }
         
        //Add item to list if valid
        var CountryId = $('#CountryId2').val();
        var CountryName = $("#CountryId2").find("option:selected").text().trim();
        var SupplierPanelSize = $('#SupplierPanelSize2').val();

        if ((CountryId !== undefined && CountryName !== undefined && SupplierPanelSize !== undefined) || (CountryId !== "" && CountryName !== "" && SupplierPanelSize !== "")) {
            var SupplierPanel = [];
            SupplierPanel.CountryId = CountryId;
            SupplierPanel.CountryName = CountryName;
            SupplierPanel.SupplierPanelSize = SupplierPanelSize;
            $scope.SupplierPanelBody.push(SupplierPanel);
            //Clear fields
            $('#CountryId2').prop('selectedIndex', '-- Select Country --');
            $('#SupplierPanelSize2').val('');
            $('#CountryId2').focus();
            
        } 

    };
    // REMOVE SELECTED ROW(s) FROM TABLE.
    $scope.removeRow = function (index) {
        var CountryId = $scope.SupplierPanelBody[index].CountryId;
        swal("Do you want to delete: " + CountryId, {
            buttons: {

                catch: {
                    text: "Yes",
                    value: "catch",
                },
                cancelButtonText: "No"
            },
            closeOnClickOutside: false
        }).then((value) => {
            if (value == "catch") {
                //Remove the item from Array using Index.
                $scope.SupplierPanelBody.splice(index, 1);
            }
        });
    };

    $scope.apilinkfun = function () {
        
        
        if ($("#IsAPI").is(":checked")) {
            $scope.IsAPIlink = true;
        }
        else {
            $scope.IsAPIlink = false;
        }
    };

    $scope.AddCountry = function () {
        $scope.AllowedCountries = [];
        $scope.AllowedCountriesList = [];
        $("#AllowedCountryCode option:selected").each(function () {
            var $this = $(this);
            if ($this.length) {
                var val = $this.val();
                var text = $this.text();
                $scope.AllowedCountries.push(val);
                $scope.AllowedCountriesList.push({ CountryCode: val, CountryName: text });
            }
        });
    };

    $scope.RemoveCountry = function (countryCode) {
        $scope.AllowedCountries.splice($scope.AllowedCountries.indexOf(countryCode), 1);
        $scope.AllowedCountriesList.splice($scope.AllowedCountriesList.findIndex(x => x.CountryCode === countryCode), 1);
        window.$('#AllowedCountryCode').val($scope.AllowedCountries);
        MultiselectDropdown();
    };

    $('#AllowedCountryCode').on('change', function () {
        $scope.AddCountry();
        $scope.$apply();
    });

    $scope.copyToClipboard = function (elementId) {
        var TestLink = elementId;
        var textArea = document.createElement("textarea");
        textArea.value = document.getElementById(TestLink).innerText.trim();        
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand("copy");
        textArea.remove();

        if (document.selection) { // IE
            var range = document.body.createTextRange();
            range.moveToElementText(document.getElementById(TestLink));
            range.select();
        } else if (window.getSelection) {
            var range = document.createRange();
            range.selectNode(document.getElementById(TestLink));
            window.getSelection().removeAllRanges();
            window.getSelection().addRange(range);
        }
    }

    $scope.routerlinkfun = function () {
        if ($("#IsRouter").is(":checked")) {
            $scope.IsRouter = true;
        }
        else {
            $scope.IsRouter = false;
        }
    };
    $scope.Affiliate = function () {
        swal("Affiliate Partner can't be changed after submission.", {
            buttons: {

                catch: {
                    text: "Yes",
                    value: "catch",
                },
                cancelButtonText: "No"
            },
            closeOnClickOutside: false
        }).then((value) => {
            if (value == "catch") {
                if ($('#IsAffiliate').is(':checked')) {
                    $('#IsAffiliate').prop('checked', true);
                }
                else {
                    $('#IsAffiliate').prop('checked', false);
                }
            }
            else {
                if ($('#IsAffiliate').is(':checked')) {
                    $('#IsAffiliate').prop('checked', false);
                }
                else {
                    $('#IsAffiliate').prop('checked', 'checked');
                }

            }
        })
    }
  
});

