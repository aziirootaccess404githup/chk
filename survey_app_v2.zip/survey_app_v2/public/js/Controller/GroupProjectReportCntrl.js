/// <reference path="../angular.js" />

var App = angular.module('ConnectApp');
App.controller('GroupProjectListCtrlController', function ($scope, $filter, paginationService, GroupProjectService) {
    $scope.isSelected = false;
    $scope.ListofGroupProjects = "";
    $scope.searchprojectId = "";
    $scope.ListofChildProjects = [];
    $scope.searchProjectCode = '';
    $scope.SelectValue = '';
    $scope.chk = false;
    $scope.Clearbtn = false;
    $scope.IsTracker = false;

    $scope.SearchGroupProject = function (searchProjectCode) {
        $('#lstserch').show();
        $scope.isSelected = false;
        $scope.searchprojectId = 0;
        var requestResponse = GroupProjectService.GetGroupProjectList(searchProjectCode);
        requestResponse.then(function successCallback(response) {
            $scope.ListofGroupProjects = response.data;
            $scope.ListofChildProjects = [];
        });
    }

    $scope.SelectValue = function (searchProjectCode) {
        $scope.searchProjectCode = searchProjectCode.projectName;
        $scope.searchprojectId = searchProjectCode.projectId;
        $scope.IsTracker = searchProjectCode.isTracker;
        $scope.isSelected = true;
        $('#lstserch').hide();
    }
    $scope.ViewReport = function () {
        if ($('#textsearchText').val().length == 0) {
            swal({ title: "", text: "Please select the Project", type: "warning", closeOnClickOutside: false });
            $scope.showReport = false;
            return false;
        }
        else if ($scope.searchprojectId === 0) {
            swal({ title: "", text: "Please enter a valid project", type: "warning", closeOnClickOutside: false });
            $scope.showReport = false;
            return false;
        }
        else {
            $('.loader').show();
            var psm = GroupProjectService.GetGroupProjectListReport($scope.searchprojectId);
            psm.then(function (response) {
                $('.loader').hide();
                $scope.ListofChildProjects = response.data.Report.GroupChild;
            });
            $scope.showReport = true;
        }
    }


    $scope.DownloadGroupProjectReport = function (Id) {
        $('.loader').show();
        var selectedProjects = $('input[type=checkbox][class=chkEnable]:checked').map(function () {
            return $(this).attr("data-identifier");
        }).get();
        $('.loader').hide();
        var ChildProjectIds = selectedProjects.toString();
        if (selectedProjects.length >= 1) {
            if ($scope.IsTracker) {
                window.location.href = '/Admin/Project/GetSelectedChildProjectReport?ProjectId=' + ChildProjectIds + '&ParentProjectId=' + Id + '&ReportType=TrackerGroup';
            } else {
                window.location.href = '/Admin/Project/GetSelectedChildProjectReport?ProjectId=' + ChildProjectIds + '&ParentProjectId=' + Id + '&ReportType=Group';
            }
        }
        else {
            swal({ title: "", text: "Please select at least 1 project", closeOnClickOutside: false });
            return false;
        }
    }

    $scope.DownloadChildProjectReport = function (Id) {
        if ($scope.IsTracker) {
            var projectId = Id.split("-")[0];
            var cycleId = parseInt(Id.split("-")[1]);
            if (cycleId > 0) {
                var cycleObj = $scope.ListofChildProjects.filter(x => x.CycleId == cycleId);
                var cycleName = cycleObj[0].ProjectName.split(' - ')[1];
                window.location.href = '/Admin/Project/GetProjectReport?ProjectId=' + projectId + "&ReportType=TrackerChild" + "&CycleId=" + cycleId + "&CycleName=" + cycleName;
            } else {
                window.location.href = '/Admin/Project/GetProjectReport?ProjectId=' + projectId + "&ReportType=Project";
            }
        } else {
            window.location.href = '/Admin/Project/GetProjectReport?ProjectId=' + Id + "&ReportType=Project";
        }
    }

    $scope.SelectedCountries = function (ProjectId) {
        $scope.CountryList = [];
        $('.loader').show();
        requestResponse = GroupProjectService.SelectedCountries(ProjectId);
        requestResponse.then(function successCallback(response) {
            $('.loader').hide();
            $scope.CountryList = response.data.countries;
        });
    }

    $scope.SelectAll = function () {
        $('#selectAll').is(":checked") ? $scope.chk = true : $scope.chk = false;
    }

    $('#textsearchText').on('keyup', function () {
        if ($('#textsearchText').val() != '') {
            $scope.Clearbtn = true;
        }
        else {
            $scope.Clearbtn = false;
        }
    })

    $scope.clearText = function () {

        $('#textsearchText').val('');
        $('#lstserch').hide();
        $scope.ListofChildProjects = [];
        $scope.showReport = false;
        $('#selectAll').prop("checked", false);
        $scope.SelectAll();
        $scope.Clearbtn = false;
    }

});