var App = angular.module('ConnectApp');
App.controller('DashboardController', function ($scope, SingleProjectService, $window) {
    $('.clearCrossIcon').hide();
    $scope.toggleSwitch = false;
    $scope.Criteria = '';
    $scope.ProjectCode = '';
    $scope.ClientSearch = '';
    $scope.ProjectManager = '';
    $scope.SearchValue = '';
    $scope.FlagCount = [];
    $scope.MonthlyComplete = [];
    $scope.Conversion = [];
    $scope.TsignDailyTrend = [];
    $scope.Projects = [];
    $scope.GetDashboardData = function () {
        $('.loader').show();
        var TotalForDashboard = SingleProjectService.GetDashboardData();
        TotalForDashboard.then(function (response) {
            $('.loader').hide();
            if (response.data != null) {
                $scope.FlagCount = response.data.flagCount;
                $scope.DailyComplete = response.data.dashboardDailyStat;
                $scope.MonthlyComplete = response.data.dashboardMonthlyStat;
                $scope.Conversion = response.data.dashboardConversion;
                $scope.TsignDailyTrend = response.data.dashboardTsignStat;
                $scope.Projects = response.data.projects;
            }
            LoadGraph();
            CompleteDetails();
        });
    }
    $scope.GetDashboardData();
    function CompleteDetails() {
        $('.loader').show();
        var requestresponse = SingleProjectService.GetTodayCompleteCount();
        requestresponse.then(function successCallback(response) {
            $('.loader').hide();
            $scope.ListofComplete = response.data.TodayCompleteCount.Complete;
        }, function () {
        });
    }

    $scope.SearchProjectList = function () {
        if (($scope.SearchValue != null && $scope.SearchValue != '')) {
            sessionStorage.setItem('Searched', '');
            var url = '/Admin/Project/ProjectList?Searchvalue=' + $scope.SearchValue;
            $window.open(url, '_blank');
        }
        else if ($scope.ClientSearch != '' || $scope.ProjectManager != '' || $scope.ProjectCode != '') {
            var url = '/Admin/Project/ProjectList?ClientSearch=' + $scope.ClientSearch + "&ProjectManager=" + $scope.ProjectManager + "&ProjectCode=" + $scope.ProjectCode;
            $window.open(url, '_blank');
        }
    }
    $scope.ResetSearch = function () {
        $scope.Criteria = '';
        $scope.ClientSearch = '';
        $scope.ProjectManager = '';
        $('#SearchClientText').val('').trigger('change.select2');
        $('#SearchPMText').val('').trigger('change.select2');
        $scope.ProjectCode = '';
        $('#advanceSearch').slideToggle();
        $('#searchbox').show();
    };

    $scope.clearText = function () {
        $scope.SearchValue = "";
        $('#searchProject').val('');
        $('.clearCrossIcon').hide();
    }

    $('#searchProject').on("input", function () {
        ($('#searchProject').val() != '') ? $('.clearCrossIcon').show() : $('.clearCrossIcon').hide();
    });

    $scope.GetProjectList = function (flagId) {
        var url = '/Admin/Project/ProjectList?FlagId=' + flagId
        $window.open(url, '_blank');
        //window.location.href = url;
    }

    $scope.toggleSearchBox = function () {
        $('#searchProject').val('')
        $scope.SearchValue = '';
        $scope.ClientSearch = '';
        $scope.ProjectManager = '';
        $('#SearchClientText').val('').trigger('change.select2');
        $('#SearchPMText').val('').trigger('change.select2');
        $scope.ProjectCode = '';
        $('.clearCrossIcon ').hide();
        $('#advanceSearch').slideToggle();
        $('#searchbox').hide();
        //$scope.toggleSwitch
    };

    function LoadGraph() {
        // Monthly Complete
        Highcharts.chart('containerMonthly', {
            chart: {
                type: 'column',
                offsetY: -100,
            },
            title: {
                text: null
            },
            subtitle: {
                text: null
            },
            xAxis: {
                categories: $scope.MonthlyComplete.monthlyCategory,
                crosshair: true,
                accessibility: {
                    description: 'Countries'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: null
                }
            },
            tooltip: {
                valueSuffix: 'Survey'
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true,
                        inside: true,
                        verticalAlign: 'bottom',
                        useHTML: true,
                    }
                }
            },
            series: [
                {
                    name: 'Click',
                    data: $scope.MonthlyComplete.monthlyClick,
                    dataLabels: {
                        formatter: function () {
                            return '<span style="color:' + this.color + ';opacity: 0;  position: relative; top:20px;">.</span>';
                        }
                    }
                },
                {
                    name: 'Complete',
                    data: $scope.MonthlyComplete.monthlyComplete,
                    dataLabels: {
                        formatter: function () {
                            return '<span style="color:' + this.color + ';opacity: 0;  position: relative; top:20px;">.</span>';
                        }
                    }
                }
            ]
        });

        // Monthly Complete
        Highcharts.chart('tsignMonthly', {
            chart: {
                type: 'column',
                offsetY: -100,
            },
            title: {
                text: null
            },
            subtitle: {
                text: null
            },
            xAxis: {
                categories: $scope.TsignDailyTrend.tsignMonthlyCategory,
                crosshair: true,
                accessibility: {
                    description: 'Countries'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '(Counts)'
                }
            },
            tooltip: {
                valueSuffix: 'Survey'
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true,
                        inside: true,
                        verticalAlign: 'bottom',
                        useHTML: true,
                    }
                }
            },
            series: [
                {
                    color: '#005dea',
                    name: 'Click',
                    data: $scope.TsignDailyTrend.tsignMonthlyClick,
                    dataLabels: {
                        formatter: function () {
                            return '<span style="color:' + this.color + ';opacity: 0;  position: relative; top:20px;">.</span>';
                        }
                    }
                },
                {
                    color: '#f65741',
                    name: 'Failure',
                    data: $scope.TsignDailyTrend.tsignMonthlyFail,
                    dataLabels: {
                        formatter: function () {
                            return '<span style="color:' + this.color + ';opacity: 0;  position: relative; top:20px;">.</span>';
                        }
                    }
                }
            ]
        });


        // Daily Complete
        $scope.DailyCompletechart = Highcharts.chart('containerDaily', {
            chart: {
                type: 'column',
                offsetY: -100,
            },
            title: {
                text: null
            },
            subtitle: {
                text: null
            },
            xAxis: {
                categories: $scope.DailyComplete.date,
                crosshair: true,
                accessibility: {
                    description: 'Countries'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: null
                }
            },
            tooltip: {

            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
            series: [
                {
                    name: 'Click',
                    data: $scope.DailyComplete.dailyClicks
                },
                {
                    name: 'Complete',
                    data: $scope.DailyComplete.dailyCompletes
                }
            ]
        });



        //Tsign Daily Trend
        var options = {
            series: [
                {
                    name: "Click",
                    data: $scope.TsignDailyTrend.tsignDailyClick,
                    color: '#005dea'
                },
                {
                    name: 'Failure',
                    data: $scope.TsignDailyTrend.tsignDailyFail,
                    color: '#f65741'
                }
            ],
            chart: {
                height: 230,
                type: 'line',
                zoom: {
                    enabled: false
                },
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                width: [3, 3],
                curve: 'straight',
                dashArray: [0, 0]
            },
            //title: {
            //    text: 'Counts',
            //    align: 'left'
            //},
            legend: {
                tooltipHoverFormatter: function (val, opts) {
                    return val + ' - ' + opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex] + ''
                }
            },
            markers: {
                size: 0,
                hover: {
                    sizeOffset: 6
                }
            },
            xaxis: {
                categories: $scope.TsignDailyTrend.dailyCategory,
            },
            yaxis: {
                title: {
                    text: '(Counts)'
                }
            },
            tooltip: {
                y: [
                    {
                        title: {
                            formatter: function (val) {
                                return val
                            }
                        }
                    },
                    {
                        title: {
                            formatter: function (val) {
                                return val
                            }
                        }
                    },
                    {
                        title: {
                            formatter: function (val) {
                                return val;
                            }
                        }
                    }
                ]
            },
            grid: {
                borderColor: '#f1f1f1',
            }
        };

        var chart = new ApexCharts(document.querySelector("#tsignchartDaily"), options);
        chart.render();


        // Map Charts
        (async () => {

            const topology = await fetch(
                'https://code.highcharts.com/mapdata/custom/world.topo.json'
            ).then(response => response.json());

        })();

        // Conversions Today
        var options = {
            series: [$scope.Conversion.conversionRatio],
            chart: {
                height: 170,
                type: 'radialBar',
                offsetY: -10,
            },
            plotOptions: {
                radialBar: {
                    startAngle: -135,
                    endAngle: 135,
                    dataLabels: {
                        name: {
                            fontSize: '12px',
                            color: ["#344054"],
                            fontWight: '200',
                            offsetY: 60
                        },
                        value: {
                            offsetY: -10,
                            fontSize: '22px',
                            color: ["#333"],
                            formatter: function (val) {
                                return val + "%";
                            }
                        }
                    }
                }
            },
            fill: {
                type: 'gradient',
                gradient: {
                    shade: 'dark',
                    shadeIntensity: 0.15,
                    inverseColors: false,
                    opacityFrom: 1,
                    opacityTo: 1,
                    stops: [0, 50, 65, 91]
                },
            },
            stroke: {
                dashArray: 4
            },
            colors: ["#ca8758"],
            labels: ['Conversion Ratio'],
            // labels: ['Ratio of complete by total click'], 
        };

        var chart = new ApexCharts(document.querySelector("#surveyConvert"), options);
        chart.render();
    }


});