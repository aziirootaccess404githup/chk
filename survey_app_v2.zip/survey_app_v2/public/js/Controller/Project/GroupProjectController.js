/// <reference path="../../angular.min.js" />
var App = angular.module('ConnectApp');

App.controller('GroupProjectController', function ($scope, $location, $filter, GroupProjectService) {

    //$scope.IsVisible = true;
    $scope.CheckUniqueIP = true;
    $scope.CheckSpeeder = true;
    $scope.CheckGeoLocation = true;
    $scope.Captcha = false;
    $scope.PreScreen = false;
    $scope.IsTS = false;
    $scope.SampleSize = 0;
    $scope.RespondentClickQuota = 0;
    document.getElementById('CurrencyCode').value = 1;$('#CurrencyCode').trigger('change');
    MultiselectDropdown();
    document.getElementById('StartDate').value = moment().format('DD-MMM-YYYY');
    var endDate = moment(document.getElementById('StartDate').value, "DD-MMM-YYYY").add(1, 'M').endOf("month")
    document.getElementById('EndDate').value = endDate.format('DD-MMM-YYYY');


    //$scope.ShowSinglelink = function (value) {
    //    //If DIV is visible it will be hidden and vice versa.  
    //    $scope.IsVisible = value === "Y";
    //};

    //$scope.btnGroupProjectForm = function (command) {

    //    $('.loader').show();
    //    var groupProjectCtrlForm = window.$("#add_client_form_Group");
    //    var isValid = groupProjectCtrlForm.valid();
    //    if (isValid) {

    //        if (command === "Save") {

    //            var data = {
    //                ProjectId: 0,
    //                ProjectCode: null,
    //                ClientId: $('#ClientId').val(),
    //                ProjectName: $('#ProjectName').val(),
    //                ProjectDescription: $('#ProjectDescription').val(),
    //                IsDynamicThanks: $("#IsDynamicThanks").is(":checked"),
    //                FlagId: 1,
    //                Notes: $('#Notes').val(),
    //                SID: null
    //            }

    //            window.$("#btnSave").attr("disabled", "disabled");
    //            var UserService = GroupProjectService.AddGroupProject(data);

    //            UserService.then(function successCallback(response) {
    //                $('.loader').hide();
    //                if (response.data.message === "SuccessFully Saved.") {
    //                    swal({ title: "", text: "Project added successfully!", type: "success", closeOnClickOutside: false }).then((type) => {
    //                        // swal("", "Project Added Successfully!", "success").then((type) => {
    //                        if (type) {
    //                            //window.Location.href = '/Admin/Project/SingleProject';
    //                            //window.location.href = '/Admin/Project/index';
    //                            window.location.href = '/Admin/Project/ChildProject?ProjectId=' + response.data.projIds;
    //                        }
    //                    });
    //                }
    //                else {
    //                    $('.loader').hide();
    //                    swal({ title: "Error!", text: response.data.message == "" ? "Something went wrong.Please try again!" : response.data.message, type: "error", closeOnClickOutside: false });
    //                    // swal("Error..!", response.data.message, "error");
    //                    $('#btnSave').attr('disabled', false);
    //                }
    //            }, function errorCallback(response) {
    //                $('.loader').hide();
    //                alert(response.data.message);
    //                $('#btnSave').attr('disabled', false);
    //                window.Location.href = '/Admin/Project/GroupProject';
    //                // called asynchronously if an error occurs  
    //                // or server returns response with an error status.  
    //            });


    //        }
    //    } else {
    //        $('.loader').hide();
    //    }
    //}

    $scope.Cancel = function () {
        location.href = "/Admin/Project/Dashboard";
    }

    $scope.btnGroupProjectForm = function (command) {
        
        $('.loader').show();
        var groupProjectCtrlForm = window.$("#add_client_form_Group");
        var isValid = groupProjectCtrlForm.valid();
        if (parseInt($('#AverageLoi').val()) > 120 || parseInt($('#AverageLoi').val()) < 1) {
            swal({ title: "", text: "LOI should not be greater than 120 ", closeOnClickOutside: false });
            $('.loader').hide();
            isValid = false;
            return false;
        }
        if (($("#UniqueIP").is(":checked") == true) && ($("#UniqueIPTxt").val() == "")) {
            $('.loader').hide();
            swal({ title: "", text: "Unique value is blank!", closeOnClickOutside: false });
            isValid = false;
            return false;
        }
        if (($("#Speeder").is(":checked") == true) && ($("#SpeederValue").val() == "")) {
            $('.loader').hide();
            swal({ title: "", text: "Speeder value is blank!", closeOnClickOutside: false });
            isValid = false;
            return false;
        }
        if ($('#CountryId').val() == "") {
            $('.loader').hide();
            $('#multiCountry').html("This field is required");
            isValid = false;
            return false;
        }
        if (isValid) {
            var varStartDate = $('#StartDate').val().trim().split("/").reverse().join("-");
            var varEndDate = $('#EndDate').val().trim().split("/").reverse().join("-");

            //var isMultilink = false;
            //var isTestLink = false;
            var isPreScreen = false; var IsGeoLocation = false; var MaxIPCount = 0; var IsUrlPortection = false; var IsCheckSum = false; var SecretKey = '';

            //if ($("#MultiLink").is(":checked"))
            //    isMultilink = true;
            //if ($("#SingleLink").is(":checked"))
            //    isTestLink = true;
            if ($("#PreScreen").is(":checked"))
                isPreScreen = true;
            if ($("#IsGeoLocation").is(":checked"))
                IsGeoLocation = true;
            if ($("#MaxIpcount").is(":checked"))
                MaxIPCount = $("#UniqueIPTxt").val();
            if ($("#IsUrlProtection").is(":checked"))
                IsUrlPortection = true;
            if ($("#IsChecksum").is(":checked")) {
                IsCheckSum = true;
                SecretKey = $("#txtchecksum").val();
            }
            var IsDynamicThanks = false;
            if ($("#IsDynamicThanksUrl").is(":checked")) {
                IsDynamicThanks = true;
            }
            var IsExclude = false;
            if ($("#IsExclude").is(":checked")) {
                IsExclude = true;
            }
            var IsMobile = false;
            if ($("#IsMobile").is(":checked")) {
                IsMobile = true;
            }
            var Istablet = false;
            if ($("#IsTablet").is(":checked")) {
                Istablet = true;
            }
            var IsDesktop = false;
            if ($("#IsDesktop").is(":checked")) {
                IsDesktop = true;
            }
            var Speeder = false;
            if ($("#Speeder").is(":checked")) {
                Speeder = true;
            }
            var IsCollectPii = false;
            if ($("#IsCollectPii").is(":checked")) {
                IsCollectPii = true;
            }
            var checkbox7 = false;
            if ($("#MaxIpcount").is(":checked")) {
                checkbox7 = true;
            }
            //if (isTestLink == true) {
            //    var SingleLinkUrl = $('#SingleLinkUrl').val();
            //    if (SingleLinkUrl == "" || SingleLinkUrl == null) {
            //        $('#ddlSingleLinkUrl').text("This field is required");
            //        $('.loader').hide();
            //        return false;
            //    }
            //}
            var IsVPN = false;
            if ($("#IsVPN").is(":checked")) {
                IsVPN = true;
            }
            var IsCaptcha = false;
            if ($("#IsCaptcha").is(":checked")) {
                IsCaptcha = true;
            }
            if ($("#IsTS").is(":checked")) {
                $scope.IsTS = true;
            }  
            var IsReInvite = false;
            if ($("#IsReInvite").is(":checked")) {
                IsReInvite = true;
            }
            var IsIpExclusion = false;
            if ($("#IsIpExclusion").is(":checked")) {
                IsIpExclusion = true;
            }
            if (command === "Save") {
                
                $('.loader').show();

                var data = {
                    ProjectId: 0,
                    ProjectCode: null,
                    ClientId: $('#ClientId').val(),
                    ClientCode: "C" + $('#ClientId').val(),
                    GroupProjectName: $('#GroupProjectName').val(),
                    GroupProjectDescription: $('#GroupProjectDescription').val(),
                    IsDynamicThanks: $("#IsDynamicThanks").is(":checked"),
                    FlagId: 1,
                    Notes: $('#Notes').val(),
                    SID: null,
                    ProjectId: 0,
                    ParentProjectId: $('#ParentProjectId').val(),
                    ProjectCategoryId: $('#ProjectCategoryId').val(),
                    ProjectCode: null,
                    ClientId: $('#ClientId').val(),
                    ClientName: $("#ClientId").find("option:selected").text().trim(),
                    ProjectName: $('#ProjectName').val(),
                    CountryId: 0,
                    CountryCodeList: $("#CountryId").val(),
                    ProjectDescription: $('#ProjectDescription').val(),
                    AverageLoi: $('#AverageLoi').val(),
                    Ir: parseFloat($('#Ir').val()).toFixed(2),
                    ProjectCpi: parseFloat($('#Cpi').val()).toFixed(2),
                    SupplierCpi: parseFloat($('#SupplierCpi').val()).toFixed(2),
                    SampleSize: $('#SampleSize').val(),
                    RespondentClickQuota: $('#RespondentClickQuota').val(),
                    CurrencyCode: $('#CurrencyCode').val(),
                    StartDate: varStartDate,
                    EndDate: varEndDate,
                    //IsMultiLinkUrl: isMultilink,
                    //IsTestLink: isTestLink,
                    IsPreScreen: isPreScreen,
                    IsReContact: false,
                    IsMultipleVariable: false,
                    IsDeDuplication: false,
                    ProjectManager: $('#ProjectManager').val().trim(),
                    //ManagerId: $('#ManagerId').val().trim(),
                    IsActive: false,
                    IsArchive: false,
                    //SingleLinkUrl: $('#SingleLinkUrl').val(),
                    //SingleLinkUrlTest: $('#SingleLinkUrlTest').val(),
                    LanguageId: $('#LanguageId').val(),
                    LanguageCode: null,
                    LanguageName: $("#LanguageId").find("option:selected").text().trim(),
                    IsGeoLocation: IsGeoLocation,
                    MaxIPCount: MaxIPCount,
                    IsChecksum: IsCheckSum,
                    IsUrlProtection: IsUrlPortection,
                    IsDynamicThanksUrl: IsDynamicThanks,
                    Note: $('#Note').val(),
                    IsOneQuestionPerPage: false,
                    Cpi1: 0,
                    Cpi2: 0,
                    RevisedProjectCpi: $('#Cpi').val(),
                    IsExclude: IsExclude,
                    IsMobile: IsMobile,
                    IsTablet: Istablet,
                    IsDesktop: IsDesktop,
                    IsSpeeder: Speeder,
                    IsMacAddress: checkbox7,
                    IsCollectPii: IsCollectPii,
                    IsVPN: IsVPN,
                    IsCaptcha: IsCaptcha,
                    SpeederValue: $('#SpeederValue').val(),
                    FlagId: 1,
                    PreScreenMessage: null,
                    PreScreenLanguageCode: $('#LanguageId').val(),
                    ProjectStatus: null,
                    ProjectType: 'C',
                    SecretKey: SecretKey,
                    IsTS: $scope.IsTS,
                    IsReInvite: IsReInvite,
                    IsIpExclusion: IsIpExclusion
                };
                
                window.$("#btnSave").attr("disabled", "disabled");
                var UserService = GroupProjectService.AddGroupProject(data);
                try {

                    UserService.then(function successCallback(response) {
                        
                        $('.loader').hide();

                        if (response.data.message === "SuccessFully Saved.") {

                            swal({ title: "", text: "Project added successfully!", type: "success", closeonclickoutside: false }).then((type) => {
                                if (type) {
                                      //window.location.href = '/admin/project/index';
                                    window.location.href = '/Admin/Project/MultiTabbedDetail?ProjectId=' + response.data.projIds;
                                }
                            });
                        }
                        else {

                            $('.loader').hide();
                            swal({ title: "Error!", text: response.data.message == "" ? "Something went wrong.Please try again!" : response.data.message, type: "error", closeonclickoutside: false });
                            $('#btnsave').attr('disabled', false);
                        }



                    }).catch(function (response, status) {

                        $('.loader').hide();
                        console.error('response error', response);
                    }).finally(function () {
                    });
                }
                catch (e) {
                    throw e;
                };

            }


        }
        else {
            $('.loader').hide();
        }


    };

    $('#CountryId').on('change', function () {
        var countryCode = $('#CountryId').val();
        $('#multiCountry').html("");
        $scope.AddCountry();
        $scope.$apply();
        $scope.GetCloneCountryLanguage();
    });
    $scope.GetCloneCountryLanguage = function () {
        var countryCode ="";
        if ($scope.SelectedCountries.length > 1) {
            countryCode = "MLC";
        }
        else {
             countryCode = $scope.SelectedCountries[0];
        }
        var UserService = GroupProjectService.GetCloneCountryLanguage(countryCode);
        UserService.then(function successCallback(response) {
            window.$('#LanguageId').html(""); //clear the dropdownlist
            //add the first select option
            window.$('#LanguageId').append($('<option></option>').val("").html("-- Select Language --"));
            //loop through the return data and check the value
            for (var i = 0; i < response.data.length; i++) {
                window.$('#LanguageId').append($('<option></option>').val(response.data[i].languageId).html(response.data[i].languageName));
            }
        });
    };
    $scope.AddCountry = function () {
        $scope.SelectedCountries = [];
        $scope.SelectedCountriesList = [];
        $("#CountryId option:selected").each(function () {
            var $this = $(this);
            if ($this.length) {
                var countryode = $this.val();
                var countryname = $this.text();
                $scope.SelectedCountries.push(countryode);
                $scope.SelectedCountriesList.push({ CountryCode: countryode, CountryName: countryname });
            }
        });
    };

    $scope.RemoveCountry = function (CountryCode) {
        $scope.SelectedCountries.splice($scope.SelectedCountries.indexOf(CountryCode), 1);
        $scope.SelectedCountriesList.splice($scope.SelectedCountriesList.findIndex(x => x.CountryCode === CountryCode), 1);
        window.$('#CountryId').val($scope.SelectedCountries);
        $scope.GetCloneCountryLanguage();
        MultiselectDropdown();
    };


});


