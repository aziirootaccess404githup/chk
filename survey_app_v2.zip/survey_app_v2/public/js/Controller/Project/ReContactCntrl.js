/// <reference path="../../angular.js" />


var App = angular.module('ConnectApp');
App.controller('ReContactCntrl', function ($scope, $location, RecontactProjectService) {
    $scope.SelectedProject = null;
    $scope.ListofProjects = "";
    $scope.ListofChildProjects = [];
    $scope.isChild = false;
    $scope.isShown = false;
    $scope.ReContact = false;
    $scope.isSupplier = false;
    $scope.CheckUniqueIP = true;
    $scope.CheckSpeeder = true;
    $scope.Captcha = false;
    $scope.PreScreen = false;
    $scope.IsTS = false;
    $('#searchcleartext ').hide();
    $scope.SelectedCountries = [];
    $scope.SelectedCountriesList = [];
    MultiselectDropdown();
    var ProjectId = $location.absUrl().split('=')[1];
    $scope.GetProjectDetail = function () {
        if (parseInt(ProjectId) != 0 && ProjectId != undefined) {
            $('.loader').show();
            var project = RecontactProjectService.GetRecontactGroup(ProjectId);
            project.then(function successCallback(response) {
                $scope.projectName = response.data.projectName;
                $scope.RecontactProjectId = response.data.projectId;
                $('#searchcleartext ').show();
                $scope.GetGroupProjectListReport();
                $('#lstserch').hide();
                $("#ClientId").prop("disabled", true);
                $("#CountryId").prop("disabled", true);
                $("#ClientId").val(response.data.clientId);
                $("#CountryId").val(response.data.countryCodeList);
                MultiselectDropdown();
                $scope.AddCountry();
                $scope.GetCloneCountryLanguage();
                $scope.ListofChildProjects = [];
                var psm = RecontactProjectService.GetChildProjectList($scope.RecontactProjectId);
                psm.then(function (response1) {
                    $('.loader').hide();
                    $scope.ListofChildProjects = response1.data.getlist;
                    $('#btnAdd').show();
                    if ($scope.ListofChildProjects.length > 0) {
                        $scope.isChild = true;

                    } else {
                        $scope.ReContact = true;
                        $scope.isSupplier = true;
                    }
                    $scope.isShown = true;
                });
            });
        }
    };

    $scope.GetProjectDetail();
    $scope.SearchProject = function (value) {
        $scope.ReContact = false;
        $scope.isChild = false;
        $scope.isShown = false;
        $scope.isSupplier = false;
        $('#lstserch').show();
        $('#btnAdd').hide();
        var projects = RecontactProjectService.GetRecontactProjectList(value);
        projects.then(function successCallback(response) {
            $scope.ListofProjects = response.data;
        });

    };

    $scope.showReContact = function () {
        $scope.ReContact = true;
    };

    $scope.SelectValue = function (projectName) {

        $scope.projectName = projectName.projectName;
        $scope.RecontactProjectId = projectName.projectId;
        $scope.ProjectType = projectName.projectType;
        $scope.GetGroupProjectListReport();
        $('#lstserch').hide();
    };





    $scope.GetGroupProjectListReport = function () {

        $scope.ListofChildProjects = [];
        var psm = RecontactProjectService.GetChildProjectList($scope.RecontactProjectId);
        psm.then(function (response) {
            $scope.ListofChildProjects = response.data.getlist;
            $('#btnAdd').show();
            if ($scope.ProjectType == 'G') {
                if ($scope.ListofChildProjects.length > 0) {
                    $scope.isChild = true;
                }
                else {
                    swal({ title: "", text: "Onhold project can't be added", closeOnClickOutside: false });
                }
            }
            else {
                $scope.ReContact = true;
                $scope.isSupplier = true;
            }
        });

    };

    $scope.supplierView = function () {

        var psm = RecontactProjectService.GetSuppliersStat($scope.RecontactProjectId);

        psm.then(function successCallback(response) {
            $scope.ListSupplierMappings = response.data;
        });

    };


    $scope.showForm = function () {

        $scope.isShown = true;

        var projectClient = RecontactProjectService.GetProjectClientCountry($scope.RecontactProjectId);
        projectClient.then(function successCallback(response) {

            $("#ClientId").prop("disabled", true);
            $("#ClientId").val(response.data.clientId);
            $("#CountryId").val(response.data.countryCodeList);
            MultiselectDropdown();
            $scope.AddCountry();
            $scope.GetCloneCountryLanguage();
            $scope.CheckGeoLocation = true;
            $scope.SampleSize = 0;
            $scope.RespondentClickQuota = 0;
            document.getElementById('CurrencyCode').value = 1; $('#CurrencyCode').trigger('change');
            document.getElementById('StartDate').value = moment().format('DD-MMM-YYYY');
            var endDate = moment(document.getElementById('StartDate').value, "DD-MMM-YYYY").add(1, 'M').endOf("month")
            document.getElementById('EndDate').value = endDate.format('DD-MMM-YYYY');

        });
    };


    $scope.SaveRecontact = function (e, command) {
        e.preventDefault();
        var reContactForm = window.$("#add_form_RecontactProject");
        var isValid = reContactForm.valid();
        if (parseInt($('#AverageLoi').val()) > 120 || parseInt($('#AverageLoi').val()) < 1) {
            swal({ title: "", text: "LOI should not be greater than 120 ", closeOnClickOutside: false });
            $('.loader').hide();
            isValid = false;
            return false;
        }
        if (($("#UniqueIP").is(":checked") == true) && ($("#UniqueIPTxt").val() == "")) {
            $('.loader').hide();
            swal({ title: "", text: "Unique value is blank!", closeOnClickOutside: false });
            isValid = false;
            return false;
        }
        if (($("#Speeder").is(":checked") == true) && ($("#SpeederValue").val() == "")) {
            $('.loader').hide();
            swal({ title: "", text: "Speeder value is blank!", closeOnClickOutside: false });
            isValid = false;
            return false;
        }
        if (isValid) {

            var varStartDate = $('#StartDate').val().trim().split("/").reverse().join("-");
            var varEndDate = $('#EndDate').val().trim().split("/").reverse().join("-");

            var isPreScreen = false; var IsGeoLocation = false; var MaxIPCount = 0; var speederValue = 0; var IsUrlPortection = false; var IsCheckSum = false; var SecretKey = '';


            if ($("#IsPreScreen").is(":checked"))
                isPreScreen = true;
            if ($("#IsGeoLocation").is(":checked"))
                IsGeoLocation = true;
            var checkbox7 = false;
            if ($("#UniqueIP").is(":checked")) {
                MaxIPCount = $("#UniqueIPTxt").val();
                checkbox7 = true;
            }
            if ($("#IsUrlProtection").is(":checked"))
                IsUrlPortection = true;
            if ($("#IsChecksum").is(":checked")) {
                IsCheckSum = true;
                SecretKey = $("#txtchecksum").val();
            }
            var IsDynamicThanks = false;
            if ($("#IsDynamicThanksUrl").is(":checked")) {
                IsDynamicThanks = true;
            }
            var IsExclude = false;
            if ($("#IsExclude").is(":checked")) {
                IsExclude = true;
            }
            var IsMobile = false;
            if ($("#IsMobile").is(":checked")) {
                IsMobile = true;
            }
            var Istablet = false;
            if ($("#IsTablet").is(":checked")) {
                Istablet = true;
            }
            var IsDesktop = false;
            if ($("#IsDesktop").is(":checked")) {
                IsDesktop = true;
            }
            var Speeder = false;
            if ($("#Speeder").is(":checked")) {
                Speeder = true;
                speederValue = $("#SpeederValue").val();
            }
            var IsCollectPii = false;
            if ($("#IsCollectPii").is(":checked")) {
                IsCollectPii = true;
            }
            var IsVPN = false;
            if ($("#IsVPN").is(":checked")) {
                IsVPN = true;
            }
            var IsCaptcha = false;
            if ($("#IsCaptcha").is(":checked")) {
                IsCaptcha = true;
            }
            if ($("#IsTS").is(":checked")) {
                $scope.IsTS = true;
            }
            var ChildProjectList = [];
            if ($scope.isChild == true) {
                $.each($('input[type=checkbox][name=recontact]:checked'), function () {
                    ChildProjectList.push($(this).val());
                });
            } else {
                ChildProjectList.push($scope.RecontactProjectId);
            }
            if (command === "Save") {
                $('.loader').show();
                var data = {
                    ProjectId: 0,
                    ParentProjectId: 0,
                    RecontactProjectId: $scope.RecontactProjectId,
                    ProjectCategoryId: $('#ProjectCategoryId').val(),
                    ProjectCode: null,
                    ClientId: $('#ClientId').val(),
                    ClientName: $("#ClientId").find("option:selected").text().trim(),
                    ProjectName: $('#ProjectName').val(),
                    CountryId: 0,
                    ProjectDescription: $('#ProjectDescription').val(),
                    AverageLoi: $('#AverageLoi').val(),
                    Ir: parseFloat($('#Ir').val()).toFixed(2),
                    ProjectCpi: parseFloat($('#Cpi').val()).toFixed(2),
                    SupplierCpi: parseFloat($('#SupplierCpi').val()).toFixed(2),
                    SampleSize: $('#SampleSize').val(),
                    RespondentClickQuota: $('#RespondentClickQuota').val(),
                    CurrencyCode: $('#CurrencyCode').val(),
                    StartDate: varStartDate,
                    EndDate: varEndDate,
                    IsMultiLinkUrl: true,
                    IsPreScreen: isPreScreen,
                    IsReContact: true,
                    IsMultipleVariable: false,
                    IsDeDuplication: false,
                    ProjectManager: $('#ProjectManager').val().trim(),
                    IsActive: false,
                    IsArchive: false,
                    LanguageId: $('#LanguageId').val(),
                    LanguageCode: null,
                    LanguageName: $("#LanguageId").find("option:selected").text().trim(),
                    IsGeoLocation: IsGeoLocation,
                    IsMacAddress: checkbox7,
                    MaxIPCount: MaxIPCount,
                    IsChecksum: IsCheckSum,
                    IsUrlProtection: IsUrlPortection,
                    IsDynamicThanksUrl: IsDynamicThanks,
                    Note: $('#Note').val(),
                    IsOneQuestionPerPage: false,
                    Cpi1: 0,
                    Cpi2: 0,
                    RevisedProjectCpi: $('#Cpi').val(),
                    IsExclude: IsExclude,
                    IsMobile: IsMobile,
                    IsTablet: Istablet,
                    IsDesktop: IsDesktop,
                    IsSpeeder: Speeder,
                    IsCollectPii: IsCollectPii,
                    IsVPN: IsVPN,
                    IsCaptcha: IsCaptcha,
                    SpeederValue: speederValue,
                    FlagId: 1,
                    PreScreenMessage: null,
                    PreScreenLanguageCode: $('#LanguageId').val(),
                    ProjectStatus: null,
                    ProjectType: 'S',
                    SecretKey: SecretKey,
                    IsTS: $scope.IsTS,
                    ChildProjectList: ChildProjectList,
                    CountryCodeList: $('#CountryId').val()
                };

                window.$("#btnSave").attr("disabled", "disabled");
                var addresponse = RecontactProjectService.AddRecontactProject(data);
                try {

                    addresponse.then(function successCallback(response) {
                        $('.loader').hide();

                        if (response.data.message === "SuccessFully Saved.") {

                            swal({ title: "", text: "Project added successfully!", type: "success", closeonclickoutside: false }).then((type) => {
                                if (type) {
                                    window.location.href = '/Admin/Project/MultiTabbedDetail?ProjectId=' + response.data.projIds;
                                }
                            });
                        }
                        else {

                            $('.loader').hide();
                            swal({ title: "Error!", text: response.data.message == "" ? "Something went wrong.Please try again!" : response.data.message, type: "error", closeonclickoutside: false });
                            $('#btnsave').attr('disabled', false);
                        }



                    }).catch(function (response, status) {

                        $('.loader').hide();
                        console.error('response error', response);
                    }).finally(function () {
                        $scope.isShown = false;
                    });
                }
                catch (e) {
                    throw e;
                };


            }


        }
    };

    $scope.CheckRecontact = function (val, id, clientId) {
        if ($('input[type=checkbox][name=recontact]:checked').length > 0) {
            $scope.ReContact = true;
            var result = angular.equals($scope.SelectedCountries.sort(), val.sort());
            if ($scope.SelectedCountries.length > 0 && !result) {
                swal({ title: "", text: "Please select the project with same country name!", closeOnClickOutside: false });
                $('#' + id).prop('checked', false);
            } else {
                $("#ClientId").val(clientId);
                $('#CountryId').val(val);
                MultiselectDropdown();
                $scope.AddCountry();
                $scope.GetCloneCountryLanguage();
                /*Default Settings */
                $scope.CheckGeoLocation = true;
                $scope.SampleSize = 0;
                $scope.RespondentClickQuota = 0;
                document.getElementById('CurrencyCode').value = 1; $('#CurrencyCode').trigger('change');
                document.getElementById('StartDate').value = moment().format('DD-MMM-YYYY');
                var endDate = moment(document.getElementById('StartDate').value, "DD-MMM-YYYY").add(1, 'M').endOf("month")
                document.getElementById('EndDate').value = endDate.format('DD-MMM-YYYY');
            }
        } else {
            $scope.ReContact = false;
            $('#CountryId').val('');
            MultiselectDropdown();
            $scope.AddCountry();
            $scope.GetCloneCountryLanguage();
        }
    };



    $('#CountryId').on('change', function () {
        $('#Countryerror').html('');
        $scope.AddCountry();
        $scope.GetCloneCountryLanguage();
    });

    $scope.GetCloneCountryLanguage = function () {
        // Select the country code
        var CountryCode = "";
        if ($scope.SelectedCountries.length > 1) {
            CountryCode = "MLC"
        }
        else {
            CountryCode = $scope.SelectedCountries[0];
        }
        var UserService = RecontactProjectService.GetCloneCountryLanguage(CountryCode);
        UserService.then(function successCallback(response) {
            window.$('#LanguageId').html(""); //clear the dropdownlist
            //add the first select option
            window.$('#LanguageId').append($('<option></option>').val("").html("-- Select Language --"));
            //loop through the return data and check the value
            for (var i = 0; i < response.data.length; i++) {
                window.$('#LanguageId').append($('<option></option>').val(response.data[i].languageId).html(response.data[i].languageName));
            }
        });
    };

    $scope.AddCountry = function () {
        $scope.SelectedCountries = [];
        $scope.SelectedCountriesList = [];
        $("#CountryId option:selected").each(function () {
            var $this = $(this);
            if ($this.length) {
                var countryode = $this.val();
                var countryname = $this.text();
                $scope.SelectedCountries.push(countryode);
                $scope.SelectedCountriesList.push({ CountryCode: countryode, CountryName: countryname });
            }
        });
    };

    $scope.Cancel = function () {
        if (parseInt(ProjectId) != 0 && ProjectId != undefined) {
            location.href = '/Admin/Project/ProjectList?Criteria=true';
        }
        else {
            location.href = '/Admin/Project/Dashboard';
        }
    };
    $scope.searchcleartext = function () {
        $('#textsearchText').val('');
        $('#lstserch').hide();
        $scope.ListofChildProjects = [];
        $scope.isShown = false;
        $('input[type=checkbox][name=recontact]').prop("checked", false);
        $('#searchcleartext ').hide();
        $('#btnAdd').hide();
        $scope.isSupplier = false;
    }
    $('#textsearchText').on("input", function () {
        (this.value !== '') ? $('#searchcleartext ').show() : $('#searchcleartext ').hide();
    });
});