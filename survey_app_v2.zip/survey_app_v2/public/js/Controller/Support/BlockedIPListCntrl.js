/// <reference path="../../angular.js" />

var App = angular.module('ConnectApp');
App.controller('BlockedIPListCtrl', function ($scope, $filter, IPTrackerServices) {

    $scope.pageSize = '10';
    $scope.currentPage = 1;
    $scope.BlockedIPList = [];
    $('.clearCrossIcon ').hide();

    GetBlockedIPList();
    function GetBlockedIPList() {
        $('.loader').show();
        var requestResponse = IPTrackerServices.GetBlockedIPList();
        requestResponse.then(function (response) {
            $('.loader').hide();

            $scope.BlockedIPList = response.data.blockedIPList;

        }, function () {

        });
    }

    $scope.UnblockIp = function (Ip) {
        swal("Are you sure want to unblock this ip?", {
            buttons: {

                catch: {
                    text: "Yes",
                    value: "catch",
                },
                cancelButtonText: "No"
            },
            closeOnClickOutside: false
        }).then((value) => {
            if (value == "catch") {
            $('.loader').show();
            var requestResponse = IPTrackerServices.UnblockIp(Ip);
            requestResponse.then(function successCallback(response) {
                $('.loader').hide();
                if (response.data.message === "SuccessFully Saved.") {
                    swal({ title: "", text: "Ip unblocked successfully!", type: "success", closeOnClickOutside: false }).then((type) => {
                        GetBlockedIPList();
                    });
                }
                else {
                    $('.loader').hide();
                    swal({ title: "Error!", text: response.data.message == "" ? "Something went wrong.Please try again!" : response.data.message, type: "error", closeOnClickOutside: false });
                    //  swal("Error..!", response.data.message, "error");

                }
            }, function errorCallback(response) {
                $('.loader').hide();
                swal({ title: "", text: response.data.message, closeOnClickOutside: false });
            });
            }
        });
    }  
    $scope.reloadRoute = function () {
        location.href = "/Admin/Support/BlockedIPList";
    }

    $scope.clearText = function () {
        $('#SearchText').val("");
        $scope.query = '';
        $('.clearCrossIcon ').hide();
    }

    $('#SearchText').on("input", function () {
        (this.value !== '') ? $('.clearCrossIcon ').show() : $('.clearCrossIcon ').hide();
    });
});