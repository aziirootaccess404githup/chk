/// <reference path="../../angular.js" />

var App = angular.module('ConnectApp');
App.controller('IPTrackerCntrl', function ($scope, $filter, IPTrackerServices) {

    $scope.pageSize = '10';
    $scope.currentPage = 1;
    $scope.IPTrackerList = [];
    $('#crossicon ').hide();
    $('#crossiconip ').hide();

    $scope.GetIPTrackerList = function () {
        var ip_address = $('#ip_address').val();
        if (ip_address == "") {
            swal({ title: "", text: "Please enter ip address", closeOnClickOutside: false });
            return false;
        }
        $('.loader').show();
        var requestResponse = IPTrackerServices.GetIPTrackerList(ip_address);
        requestResponse.then(function (response) {
            $('.loader').hide();

            $scope.IPTrackerList = response.data.iPTrackerList;

        }, function () {

        });
    }

    $scope.BlockIp = function () {
        var ip_address = $('#ip_address').val();
        var Comment = $('#Comment').val();
        if (ip_address == "") {
            swal({ title: "", text: "Please enter ip address", closeOnClickOutside: false });
            return false;
        }
        if (Comment == "") {
            swal({ title: "", text: "Please enter Comment", closeOnClickOutside: false });
            return false;
        }
        $('.loader').show();
        var requestResponse = IPTrackerServices.BlockIp(ip_address, Comment);
        requestResponse.then(function successCallback(response) {
            $('.loader').hide();
            if (response.data.message === "SuccessFully Saved.") {
                swal({ title: "", text: "Ip blocked successfully!", type: "success", closeOnClickOutside: false }).then((type) => {
                    
                });
            }
            else {
                $('.loader').hide();
                swal({ title: "Error!", text: response.data.message == "" ? "Something went wrong.Please try again!" : response.data.message, type: "error", closeOnClickOutside: false });
                //  swal("Error..!", response.data.message, "error");

            }
        }, function errorCallback(response) {
            $('.loader').hide();
            alert(response.data.message);
        });
    }
    $scope.reloadRoute = function () {
        location.href = "/Admin/Support/IPTracker";
    }
    $scope.clearText = function () {
        $('#SearchText').val("");
        $scope.query = '';
        $('#crossicon ').hide();
    }

    $scope.clearTextIP = function () {
        $('#SearchText').val("");
        $('#ip_address').val("");
        $scope.query = '';
        $scope.IPTrackerList = [];
        $('.clearCrossIcon ').hide();
    }
    $('#ip_address').on("input", function () {
        (this.value !== '') ? $('#crossiconip ').show() : $('#crossiconip ').hide();
    });
    $('#SearchText').on("input", function () {
        (this.value !== '') ? $('#crossicon ').show() : $('#crossicon ').hide();
    });
});