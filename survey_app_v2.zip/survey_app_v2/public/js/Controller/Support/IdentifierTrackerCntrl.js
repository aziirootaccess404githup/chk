/// <reference path="../../angular.js" />

var App = angular.module('ConnectApp');
App.controller('IdentifierTrackerCntrl', function ($scope, $filter, IdentifierTrackerServices) {

    $scope.pageSize = '10';
    $scope.currentPage = 1;
    $scope.query = '';
    $scope.IdentifierTrackerList = [];
    $scope.IdentifierTrackerListAll = [];
    $scope.Identifiers = '';
    $scope.ReconcileDisable = true;
    $scope.message = "Please enter valid Identifier";
    $scope.DownloadDisable = true;
    $scope.CompleteDisable = true;
    $scope.ChkReconcileDisable = false;
    $scope.ChkCompleteDisable = false;
    $scope.ChkDropOutDisable = false;
    $scope.chk = false;
    $('.clearCrossIcon ').hide();
    $scope.status = '';
    $scope.SelectedIdentifiers = [];

    $scope.GetIdentifierTrackerList = function () {
        $scope.SelectedIdentifiers = [];
        var Identifiers = $('#Identifiers').val().trim();
        if (Identifiers == "") {
            swal({ title: "", text: $scope.message, type: "warning", closeOnClickOutside: false });
            return false;
        }
        $('.loader').show();
        var requestResponse = IdentifierTrackerServices.GetIdentifierTrackerList(Identifiers);
        requestResponse.then(function (response) {
            $('.loader').hide();
            $scope.IdentifierTrackerList = response.data.identifierTrackerList;
            $scope.IdentifierTrackerListAll = response.data.identifierTrackerList;
            $scope.ChkReconcileDisable = false;
            $scope.ChkCompleteDisable = false;
            $scope.ChkDropOutDisable = false;
            $scope.CompleteDisable = true;
            $scope.ReconcileDisable = true;
            $("#idC").prop('checked', false);
            $("#idSF").prop('checked', false);
            $("#idD").prop('checked', false);
            $scope.chk = false;
        }, function () {

        });
    }


    $scope.ReplaceComma = function (Identifiers) {
        $scope.Identifiers = Identifiers.replaceAll(',', '\n');
    }

    $scope.Clear = function () {
        $scope.pageSize = '10';
        $scope.currentPage = 1;
        $scope.query = '';
        $scope.IdentifierTrackerList = [];
        $scope.IdentifierTrackerListAll = [];
        $scope.Identifiers = '';
        $scope.ReconcileDisable = true;
        $scope.CompleteDisable = true;
        $scope.DownloadDisable = true;
        $("#idC").prop('checked', false);
        $("#idSF").prop('checked', false);
        $("#idD").prop('checked', false);
        $scope.SelectedIdentifiers = [];
        $scope.chk = false;
    }

    $scope.reloadRoute = function () {
        location.href = "/Admin/Support/IdentifierTracker";
    }

    $scope.DownloadReport = function (IdentifierTrackerList) {
        if ($scope.IdentifierTrackerList == 0) {
            return false;
        } else {

            var Identifiers = [];

            for (var i in $scope.IdentifierTrackerList) {
                Identifiers.push($scope.IdentifierTrackerList[i].userIdentifier);
            }
            $('.loader').show();
            var requestResponse = IdentifierTrackerServices.Download(Identifiers);
            requestResponse.then(function (response) {
                $('.loader').hide();
                window.location = '/Admin/MultiLink/DownloadLinks?filename=' + response.data.fileName;
            }, function (resposne) {
                swal({
                    title: "Error!", text: response.data.message == "" ? "Something went wrong.Please try again!"
                        : response.data.message, type: "error", closeOnClickOutside: false
                });
            });
        }
    }

    $scope.Reconcile = function (command) {

        swal("Do you want to" + " " + command + "?", {
            buttons: {
                catch: {
                    text: "Yes",
                    value: "catch",
                },
                cancelButtonText: "No"
            },
            closeOnClickOutside: false
        }).then((value) => {
            if (value == "catch") {
                var Identifiers = [];
                $('.loader').show();

                //$.each($('input[type=checkbox][class=chkEnable]:checked'), function () {
                //    Identifiers.push($(this).attr("data-identifier"));
                //});

                if ($scope.SelectedIdentifiers.length == 0) {
                    swal({ title: "", text: "Please Select Identifier", type: "warning", closeOnClickOutside: false });
                    $('.loader').hide();
                    return false;
                }
                var requestResponse = IdentifierTrackerServices.Reconcile($scope.SelectedIdentifiers, command);
                requestResponse.then(function (response) {
                    $('.loader').hide();
                    if (response.data.message == "Reconciled Successfully!!!")
                        swal({
                            title: "", text: response.data.message == "" ? command + " Successfully!!!"
                                : command + " Successfully!!!", type: "success", closeOnClickOutside: false
                        });
                    $scope.GetIdentifierTrackerList();

                }, function (resposne) {
                    swal({
                        title: "Error!", text: response.data.message == "" ? "Something went wrong.Please try again!"
                            : response.data.message, type: "error", closeOnClickOutside: false
                    });
                });
            }
        })
    }

    $scope.enable = function (useridentifier, Ischecked) {
        if (Ischecked) {
            if (!$scope.SelectedIdentifiers.includes(useridentifier)) {
                $scope.SelectedIdentifiers.push(useridentifier.trim());
            }
        }
        else {
            const index = $scope.SelectedIdentifiers.indexOf(useridentifier);
            if (index > -1) {
                $scope.SelectedIdentifiers.splice(index, 1);
            }
        }

        var Complete = $("input[type=checkbox][data-status=C]");
        var Reconcile = $("input[type=checkbox][data-status=SF]");
        var Dropout = $("input[type=checkbox][data-status=D]");
        if (Complete.filter(":checked").length > 0 || Reconcile.filter(":checked").length > 0 || Dropout.filter(":checked").length > 0) {
            if (Complete.filter(":checked").length > 0) {
                $scope.ReconcileDisable = false;
                $scope.ChkReconcileDisable = true;
                $scope.ChkDropOutDisable = true;
                ($scope.SelectedIdentifiers.length > 0 && $scope.IdentifierTrackerListAll.filter(x => x.status.trim() == 'C').length == $scope.SelectedIdentifiers.length) ? ($('#idC').prop("checked", true), $scope.chk = true) : $('#idC').prop("checked", false);
            } else {
                $scope.ChkCompleteDisable = true;
                $scope.ReconcileDisable = true;
            }
            if (Reconcile.filter(":checked").length > 0) {
                $scope.CompleteDisable = false;
                $scope.ChkCompleteDisable = true;
                $scope.ChkDropOutDisable = true;
                ($scope.SelectedIdentifiers.length > 0 && $scope.IdentifierTrackerListAll.filter(x => x.status.trim() == 'SF').length == $scope.SelectedIdentifiers.length) ? ($('#idSF').prop("checked", true), $scope.chk = true) : ($('#idSF').prop("checked", false));
            } else {
                $scope.ChkReconcileDisable = true;
                $scope.CompleteDisable = true;
            }
            if (Dropout.filter(":checked").length > 0) {
                $scope.CompleteDisable = false;
                $scope.ChkReconcileDisable = true;
                $scope.ChkCompleteDisable = true;
                ($scope.SelectedIdentifiers.length > 0 && $scope.IdentifierTrackerListAll.filter(x => x.status.trim() == 'D').length == $scope.SelectedIdentifiers.length) ? ($('#idD').prop("checked", true), $scope.chk = true) : ($('#idD').prop("checked", false));
            } else {
                $scope.ChkDropOutDisable = true;
                $scope.CompleteDisable = true;
            }
        }
        else {
            if ($scope.SelectedIdentifiers.length == 0) {
                $scope.ChkReconcileDisable = false;
                $scope.ChkCompleteDisable = false;
                $scope.ChkDropOutDisable = false;
                $scope.ReconcileDisable = true;
                $scope.CompleteDisable = true;
                $('#idC').prop("checked", false);
                $('#idSF').prop("checked", false);
                $('#idD').prop("checked", false);
                $scope.chk = false
            }
        }
    }

    $scope.IdentifierStatus = function (status) {
        $scope.SelectedIdentifiers = [];
        $scope.status = status;
        if (status == 'C ') {
            $scope.IdentifierTrackerList = $scope.IdentifierTrackerListAll.filter(x => x.status == 'C ');
            if ($scope.IdentifierTrackerList.length != 0) {
                $scope.ChkReconcileDisable = false;
                $scope.ChkCompleteDisable = false;
                $scope.ReconcileDisable = false;
                $scope.CompleteDisable = true;
                $scope.chk = true;
                $scope.IdentifierTrackerList.forEach(function (item) {
                    $scope.SelectedIdentifiers.push(item.userIdentifier);
                });
            }
        }
        else {
            if (status == 'SF') { $scope.IdentifierTrackerList = $scope.IdentifierTrackerListAll.filter(x => x.status == 'SF'); }
            else { $scope.IdentifierTrackerList = $scope.IdentifierTrackerListAll.filter(x => x.status == 'D '); }
            if ($scope.IdentifierTrackerList.length != 0) {
                $scope.ChkReconcileDisable = false;
                $scope.ChkCompleteDisable = false;
                $scope.ReconcileDisable = true;
                $scope.CompleteDisable = false;
                $scope.chk = true;
                $scope.IdentifierTrackerList.forEach(function (item) {
                    $scope.SelectedIdentifiers.push(item.userIdentifier);
                });
            }
        }
        if (!$("#idC").is(":checked") && !$("#idSF").is(":checked") && !$("#idD").is(":checked")) {
            $scope.GetIdentifierTrackerList();
            $scope.chk = false;
        }
    }
    $scope.clearText = function () {
        $('#SearchText').val("");
        $scope.query = '';
        $('.clearCrossIcon ').hide();
    }

    $('#SearchText').on("input", function () {
        (this.value !== '') ? $('.clearCrossIcon ').show() : $('.clearCrossIcon ').hide();
    });

});

