/// <reference path="../angular.js" />

var App = angular.module('ConnectApp');
App.controller('ListClientCntrl', function ($scope, $filter, $window, ClientService, paginationService) {
     
    $scope.pageSize = '10';
    $scope.currentPage = 1;
    $scope.ClientList = [];
    $scope.ClientList1 = [];
    $scope.ClientList2 = [];
    $scope.dataget = [];
    $scope.length = '';
    $scope.tlength = '';
    $scope.isEmpty = false;
    $scope.inactive = "";
    $scope.active = "";
    $('.clearCrossIcon').hide();
    
    GetUsers();
    function GetUsers() {
        $('.loader').show();
        var requestResponse = ClientService.GetAll();
        requestResponse.then(function (response) {
            $('.loader').hide();            
            $scope.ClientList = response.data.clientData;
            $scope.ClientList2 = response.data.clientData;
            var active = $filter('filter')($scope.ClientList2, { isRemoved: 'false' }).length;
            var inactive = $filter('filter')($scope.ClientList2, { isRemoved: 'true' }).length;
            $scope.length = $scope.ClientList.length;
            $scope.inactive = inactive;
            $scope.active = active;
           
            $scope.getactive();

        }, function () {

        });
    }
    $scope.getactive = function () {
        $scope.currentPage = 1;
        $scope.dataget = $scope.ClientList;
         
        $scope.ClientList1 = [];
        for (var i in $scope.ClientList) {
            if (false == $scope.ClientList[i].isRemoved) {
                $scope.ClientList1.push($scope.ClientList[i]);
            }
        }
        if ($scope.ClientList1.length == 0) {
            $scope.isEmpty = true;
        }
    }
    $scope.getinactive = function () {
        $scope.currentPage = 1;
        $scope.dataget = $scope.ClientList2;
         
        $scope.ClientList1 = [];
        for (var i in $scope.dataget) {
            if (true == $scope.dataget[i].isRemoved) {
                $scope.ClientList1.push($scope.dataget[i]);
            }
        }
        if ($scope.ClientList1.length == 0) {
            $scope.isEmpty = true;
        }
    }

    $scope.DisplayTotal = function (ClientId) {
        $window.open('/Admin/Client/TotalProjects?ClientId=' + ClientId, '_blank');
    }

    $scope.DisplayActive = function (ClientId, Flag) {
        $window.open('/Admin/Client/TotalProjects?ClientId=' + ClientId + '&Flag=' + Flag, '_blank');
    }

    $scope.clearText = function () {
        $('#SearchText').val("");
        $scope.query = '';
        $('.clearCrossIcon ').hide();
    }

    $('#SearchText').on("input", function () {
        (this.value !== '') ? $('.clearCrossIcon ').show() : $('.clearCrossIcon ').hide();
    });
    $scope.ShowClientDetail = function (ClientId) {
        $scope.ClientDetail = [];
        var requestResponse = ClientService.GetClient(ClientId);
        requestResponse.then(function (response) {
            $('.loader').hide();
            $scope.ClientDetail = response.data.listOfMatchingIncome;
            $scope.IsAPI = $scope.ClientDetail.isApi;
            var filterClientlist = $scope.ClientList1.filter(item => item.clientId == $scope.ClientDetail.clientId);
            $scope.CountryName = filterClientlist[0].countryName;
        }, function () {

        });
    }
   
});