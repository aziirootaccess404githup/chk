/// <reference path="../angular.js" />

var App = angular.module('ConnectApp');
App.controller('ListStatusCtrl', function ($scope, StatusService) {

    $scope.ListofStatusOption = [];

    GetStatus();

    function GetStatus() {
        $('.loader').show();
        var requestResponse = StatusService.GetAllStatus();
        requestResponse.then(function (response) {
            $('.loader').hide();

            $scope.ListofStatusOption = response.data.statusOptionList;;

        }, function () {

        });
    }
});