/// <reference path="../../angular.js" />

var App = angular.module('ConnectApp');
App.controller('TSignReportController', function ($scope,Report) {

    $scope.ManagerList = [];
    $scope.TSignReport = [];
    $scope.managerCode = '';
    $scope.managerId = 0;
    $scope.showReport = false;

    $scope.ViewReport = function (Id) {
        var fromDate = $('#StartDate').val();
        var toDate = $('#EndDate').val();
        if (fromDate == '' || toDate == '') {
            swal({ title: "", text: 'All fields required !', closeOnClickOutside: false });
            return false;
        } else {
            $('.loader').show();
            var requestResponse = Report.ClientSupplierReport(Id,fromDate, toDate, 'TSignTrafficReport');
            requestResponse.then(function successCallback(response) {
                $scope.TSignReport = [];
                $('.loader').hide();
                if (response.data.Report.TSign != null) {
                    $scope.TSignReport = response.data.Report.TSign;
                }
                $scope.showReport = true;
            });
        }
    }

    $scope.DownloadReport = function () {
        var fromDate = $('#StartDate').val();
        var toDate = $('#EndDate').val();
        if (fromDate == '' || toDate == '') {
            swal({ title: "", text: 'All fields required !', closeOnClickOutside: false });
            return false;
        } else {
            window.location.href = '/Admin/Report/SurveyReport?fromDate=' + fromDate + "&toDate=" + toDate + "&type=TSignTrafficReport";
        }
    }

    $scope.searchcleartext = function () {
        $('#StartDate').val('');
        $('#EndDate').val('');
        $scope.TSignReport = [];
        $scope.showReport = false;
    }

});