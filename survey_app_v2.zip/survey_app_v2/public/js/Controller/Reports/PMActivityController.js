///<reference path="../../angular.js" />

var App = angular.module('ConnectApp');
App.controller('PMActivityController', function ($scope, $filter, Report) {
    $scope.ProjectList = [];
    $scope.ProjectReport = [];

    $scope.showReport = false;
    $scope.Clearbtn = false;
    $scope.UserList = [];
    $('#lstsearch').hide();


    $scope.userList = function () {
        $scope.UserList = [];
        $('.loader').show();
        var requestResponse = Report.GetManagerList();
        requestResponse.then(function successCallback(response) {
            $('.loader').hide();
            $scope.UserList = response.data;
        });
    }
    $scope.userList();

    $scope.SelectValue = function (manager) {
        $scope.managerCode = manager.managerName;
        $scope.managerId = manager.managerId;
        $('#lstserch').hide();
    }

    $scope.ViewReport = function (ProjectCode) {
        $scope.ProjectReport = [];
        var fromDate = $('#StartDate').val();
        var toDate = $('#EndDate').val();
        var Userid = $('#userid').val();
        if (ProjectCode == 0 || fromDate == '' || toDate == '' || Userid == '' || $('#textsearchText').val().length == 0) {
            swal({ title: "", text: "All fields are required!", type: "warning", closeOnClickOutside: false });
            $scope.showReport = false;
            return false;
        } else {
            $('.loader').show();
            var requestResponse = Report.UserActivityReport(ProjectCode, fromDate, toDate, Userid);
            requestResponse.then(function successCallback(response) {
                $scope.ProjectReport = response.data.Report.UserActivity;
                $scope.showReport = true;
                $('.loader').hide();
            });
        }
    }

    $scope.DownloadReport = function (ProjectCode) {
        var fromDate = $('#StartDate').val();
        var toDate = $('#EndDate').val();
        var UserId = $('#userid').val();
        if (ProjectCode == 0 || $('#textsearchText').val().length == 0) {
            swal({ title: "", text: "Please select Project Code", type: "warning", closeOnClickOutside: false });
            return false;
        } else {
            window.location.href = '/Admin/Report/UserActivityDetailReport?ProjectCode=' + ProjectCode + "&UserId=" + UserId + "&fromDate=" + fromDate + "&toDate=" + toDate;
        }
    }

    $scope.SearchProject = function (value) {
        $('#lstsearch').show();

        var projects = Report.SearchProjectList(value);
        projects.then(function successCallback(response) {
            $scope.ListofProjects = response.data;
        });

    };
    $scope.SelectProject = function (projectName) {
        $scope.projectName = projectName.projectName;
        $scope.ProjectId = projectName.projectId;
        $scope.ProjectCode = projectName.projectCode;
        $('#lstsearch').hide();
    };

    $scope.clearText = function () {
        $('#textsearchText').val('');
        $('#lstsearch').hide();
        $scope.ProjectReport = [];
        $scope.showReport = false;
        $scope.Clearbtn = false;
    }
    $('#textsearchText').on('keyup', function () {
        if ($('#textsearchText').val() != '') {
            $scope.Clearbtn = true;
        }
        else {
            $scope.Clearbtn = false;
        }
    });

    $scope.Reset = function () {
        $('#textsearchText').val('');
        $('#lstsearch').hide();
        $scope.ListofProjects = [];
        $scope.projectName = "";
        $scope.ProjectId = "";
        $scope.ProjectCode = "";
        $scope.ProjectReport = [];
        $scope.showReport = false;
        $scope.Clearbtn = false;
        $('#userid').val('').trigger('change');
        $('#StartDate').val('');
        $('#EndDate').val('');
    }

});
