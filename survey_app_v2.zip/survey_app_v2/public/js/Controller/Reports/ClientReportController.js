/// <reference path="../../angular.js" />

var App = angular.module('ConnectApp');
App.controller('ClientReportController', function ($scope, $filter, Report) {
    $scope.ClientList = [];
    $scope.ClientReport = [];
    $scope.clientCode = '';
    $scope.clientId = 0;
    $scope.showReport = false;
    $scope.Clearbtn = false;

    $scope.SearchClient = function (clientCode) {
        if (clientCode === '') {
            $('#lstserch').hide();
            $scope.showReport = false;
        }
        else {
            $scope.showReport = false;
            $('#lstserch').show();
            var requestResponse = Report.SearchClientList(clientCode);
            requestResponse.then(function successCallback(response) {
                $scope.ClientList = [];
                $scope.ClientList = response.data;
            });
        }
    }

    $scope.SelectValue = function (client) {
        $scope.clientCode = client.clientName;
        $scope.clientId = client.clientId;
        $('#lstserch').hide();
    }

    $scope.ViewReport = function (Id) {
        var fromDate = $('#StartDate').val();
        var toDate = $('#EndDate').val();
        if (Id == 0 || fromDate == '' || toDate == '' || $('#textsearchText').val().length == 0) {
            swal({ title: "", text: 'All fields required !', closeOnClickOutside: false });
            return false;
        } else {
            $('.loader').show();
            var requestResponse = Report.ClientSupplierReport(Id, fromDate, toDate, 'Client');
            requestResponse.then(function successCallback(response) {
                $('.loader').hide();
                $scope.ClientReport = [];
                if (response.data.Report.Client != null) {
                    $scope.ClientReport = response.data.Report.Client;
                }
                $scope.showReport = true;
            });
        }
    }

    $scope.DownloadReport = function (Id) {
        var fromDate = $('#StartDate').val();
        var toDate = $('#EndDate').val();
        if (Id == 0 || fromDate == '' || toDate == '') {
            swal({ title: "", text: 'All fields required !', closeOnClickOutside: false });
            return false;
        } else {
            window.location.href = '/Admin/Report/SurveyReport?Id=' + Id + "&fromDate=" + fromDate + "&toDate=" + toDate + "&type=Client";
        }
    }

    $scope.DownloadProjectReport = function (Id, ProjectId) {
        window.location.href = '/Admin/Report/ProjectSurveyReport?Id=' + Id + "&ProjectId=" + ProjectId + "&type=Client";
    }
    $scope.SelectedCountries = function (ProjectId) {
        $scope.CountryList = [];
        $('.loader').show();
        requestResponse = Report.SelectedCountries(ProjectId);
        requestResponse.then(function successCallback(response) {
            $('.loader').hide();
            $scope.CountryList = response.data.countries;
        });
    }

    $scope.searchcleartext = function () {
        $('#textsearchText').val('');
        $('#StartDate').val('');
        $('#EndDate').val('');
        $('#lstserch').hide();
        $('.clearCrossIcon').hide();
        $scope.ClientReport = [];
        $scope.showReport = false;
    }

    $('#textsearchText').on('keyup', function () {
        if ($('#textsearchText').val() != '') {
            $scope.Clearbtn = true;
        }
        else {
            $scope.Clearbtn = false;
        }
    });

    $scope.clearText = function () {
        $('#textsearchText').val('');
        $('#lstserch').hide();
        $scope.ClientReport = [];
        $scope.showReport = false;
        $scope.Clearbtn = false;
    }


});
