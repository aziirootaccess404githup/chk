/// <reference path="../../angular.js" />

var App = angular.module('ConnectApp');
App.controller('SupplierReportController', function ($scope, $filter, Report) {
    $scope.SupplierList = [];
    $scope.SupplierReport = [];
    $scope.SupplierCode = '';
    $scope.SupplierId = 0;
    $scope.showReport = false;

    $scope.SearchSupplier = function (SupplierCode) {
        if (SupplierCode === '') {
            $('#lstserch').hide();
            $scope.showReport = false;
        }
        else {
            $scope.showReport = false;
            $('#lstserch').show();
            var requestResponse = Report.SearchSupplierList(SupplierCode);
            requestResponse.then(function successCallback(response) {
                $scope.SupplierList = [];
                $scope.SupplierList = response.data;
            });
        }
    }

    $scope.SelectValue = function (Supplier) {
        $scope.SupplierCode = Supplier.supplierName;
        $scope.SupplierId = Supplier.supplierId;
        $('#lstserch').hide();
    }

    $scope.ViewReport = function (Id) {
        var fromDate = $('#StartDate').val();
        var toDate = $('#EndDate').val();
        if (Id == 0 || fromDate == '' || toDate == '' || $('#textsearchText').val().length == 0) {
            swal({ title: "", text: 'All fields required !', closeOnClickOutside: false });
            return false;
        } else {
            $('.loader').show();
            var requestResponse = Report.ClientSupplierReport(Id, fromDate, toDate, 'Supplier');
            requestResponse.then(function successCallback(response) {
                $scope.SupplierReport = [];
                $('.loader').hide();
                if (response.data.Report.Supplier != null) {
                    $scope.SupplierReport = response.data.Report.Supplier;
                }
                $scope.showReport = true;
            });
        }
    }

    $scope.DownloadReport = function (Id) {
        var fromDate = $('#StartDate').val();
        var toDate = $('#EndDate').val();
        if (Id == 0 || fromDate == '' || toDate == '') {
            swal({ title: "", text: 'All fields required !', closeOnClickOutside: false });
            return false;
        } else {
            window.location.href = '/Admin/Report/SurveyReport?Id=' + Id + "&fromDate=" + fromDate + "&toDate=" + toDate + "&type=Supplier";
        }
    }

    $scope.DownloadProjectReport = function (Id, ProjectId) {
        window.location.href = '/Admin/Report/ProjectSurveyReport?Id=' + Id + "&ProjectId=" + ProjectId + "&type=Supplier";
    }
    $scope.SelectedCountries = function (ProjectId) {
        $scope.CountryList = [];
        $('.loader').show();
        requestResponse = Report.SelectedCountries(ProjectId);
        requestResponse.then(function successCallback(response) {
            $('.loader').hide();
            $scope.CountryList = response.data.countries;
        });
    }

    $scope.searchcleartext = function () {
        $('#textsearchText').val('');
        $('#StartDate').val('');
        $('#EndDate').val('');
        $('#lstserch').hide();
        $('.clearCrossIcon').hide();
        $scope.SupplierReport = [];
        $scope.showReport = false;
    }

    $('#textsearchText').on('keyup', function () {
        if ($('#textsearchText').val() != '') {
            $scope.Clearbtn = true;
        }
        else {
            $scope.Clearbtn = false;
        }
    });

    $scope.clearText = function () {
        $('#textsearchText').val('');
        $('#lstserch').hide();
        $scope.SupplierReport = [];
        $scope.showReport = false;
        $scope.Clearbtn = false;
    }
});
