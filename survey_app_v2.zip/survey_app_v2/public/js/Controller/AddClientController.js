/// <reference path="../angular.js" />

var App = angular.module('ConnectApp');
App.controller('ClientCtrlcontroller', function ($scope, ClientService) {
    $scope.IsAPI = false;
    $scope.btnClientForm = function (command) {
        $('.loader').show();
        var clientCtrlForm = window.$("#ClientCtrlForm");
        var isClientFormValid = clientCtrlForm.valid();
        if ($('#ClientContactNo').val() == "0000000000") {
            swal({ title: "", text: "Invalid Contact Number", closeOnClickOutside: false });
            $('.loader').hide();
            isClientFormValid = false;
            return false;
        }
        if (isClientFormValid !== false) {
            if (command === "Save") {
                var data = {
                    ClientId: 0,
                    ClientCode: null,
                    IsRemoved: false,
                    ClientName: $('#ClientName').val(),
                    ContactPerson: $('#ContactPerson').val(),
                    ClientContactNo: $('#ClientContactNo').val(),
                    ClientEmail: $('#ClientEmail').val(),
                    ClientWebsite: $('#ClientWebsite').val(),
                    CountryId: $("#CountryId").val(),
                    Apiurl: $("#Apiurl").val(),
                    Apikey: $("#Apikey").val(),
                    ApisecretKey: $("#ApisecretKey").val(),
                    IsApi: $scope.IsAPI,
                    CountryName: $("#CountryId").find("option:selected").text().trim(),
                };

                window.$("#btnSave").attr("disabled", "disabled");
                var UserService = ClientService.AddandEditServices(data);
                

                UserService.then(function successCallback(response) {
                    $('.loader').hide();
                    if (response.data.message === "SuccessFully Saved.") {
                        swal({ title: "", text: "Client added successfully!", type: "success", closeOnClickOutside: false }).then((type) => {
                      //  swal("", "Client Added Successfully!", "success").then((type) => {
                            if (type) {
                                window.location.href = '/Admin/Client/Index';
                            }
                        });
                    }
                    else if (response.data.message === "Duplicate") {
                        swal({ title: "", text: "Client Name Already Exists", type: "error", closeOnClickOutside: false });
                        $('#btnSave').attr('disabled', false);
                    }
                    else {
                        $('.loader').hide();
                        swal({ title: "Error!", text: response.data.message == "" ? "Something went wrong.Please try again!" : response.data.message, type: "error", closeOnClickOutside: false });
                     //   swal("Error..!", response.data.message, "error");
                        $('#btnSave').attr('disabled', false);
                    }
                }, function errorCallback(response) {
                    $('.loader').hide();
                    swal({ title: "", text: response.data.message, closeOnClickOutside: false });
                    window.Location.href = '/Admin/Client/AddClient';
                    // called asynchronously if an error occurs  
                    // or server returns response with an error status.  
                });
            }
        }
        else {
            $('.loader').hide();
        }

    };
     

});

