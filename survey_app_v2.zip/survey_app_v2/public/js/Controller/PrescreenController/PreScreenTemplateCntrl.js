/// <reference path="../../angular.js" />

var App = angular.module('ConnectApp');
App.controller('PreScreenTemplate', function ($scope, $filter, PrescreenProjectService, paginationService) {

    $scope.pageSize = '10';
    $scope.currentPage = 1;
    $scope.PreScreenTemplateList = [];
    $scope.TemplateQuestionList = [];
    $scope.TemplateName = '';
    $scope.length = '';
    $scope.isvalidTemplateTitle = true;
    $('.clearCrossIcon ').hide();

    GetTemplates();
    function GetTemplates() {
        $('.loader').show();
        var requestResponse = PrescreenProjectService.GetPreScreenTemplates();
        requestResponse.then(function (response) {
            $('.loader').hide();
            $scope.PreScreenTemplateList = response.data.templateList;
            $scope.length = $scope.PreScreenTemplateList.length;

        }, function () {

        });
    };

    $scope.AddPreScreenTemplate = function (command) {
        if ($('#TemplateName').val() === "") {
            $('#Templatevalidation').html('This field is required');
            return false;
        }
        if ($scope.isvalidTemplateTitle == false) {
            $('#Templatevalidation').html('Template name already in use');
            return false;
        }
        $('.loader').show();
        if (command === "Save") {
            var TemplateName = $("#TemplateName").val();

            window.$("#btnSave").attr("disabled", "disabled");
            var UserService = PrescreenProjectService.AddPreScreenTemplate(TemplateName);
            UserService.then(function successCallback(response) {
                $('.loader').hide();
                if (response.data.message === "Success") {
                    GetTemplates();
                    window.$("#btnSave").attr("disabled", false);
                }
                else if (response.data.message === "Already Available") {
                    $('.loader').hide();
                    window.$("#btnSave").attr("disabled", false);
                    $('#Templatevalidation').html('Template name already in use');
                }
                else {
                    $('.loader').hide();
                    swal({ title: "Error!", text: response.data.message == "" ? "Something went wrong.Please try again!" : response.data.message, type: "error", closeOnClickOutside: false });
                    window.$("#btnSave").attr("disabled", false);

                }
            }, function errorCallback(response) {
                $('.loader').hide();
                swal({ title: "", text: response.data.message, closeOnClickOutside: false });
                    window.Location.href = '/Admin/PreScreenTemplate';
                // called asynchronously if an error occurs  
                // or server returns response with an error status.  
            });

        }
        
    };

    $scope.DeleteTemplate = function (id) {
        swal("Are you sure want to delete?", {
            buttons: {

                catch: {
                    text: "Yes",
                    value: "catch",
                },
                cancelButtonText: "No"
            },
            closeOnClickOutside: false
        }).then((value) => {
            if (value == "catch") {
                $('.loader').show();
                var UserService = PrescreenProjectService.DeleteTemplate(id);
                UserService.then(function successCallback(response) {
                    $('.loader').hide();
                    if (response.data.message === "Success") {
                        swal({ title: "", text: "Deleted successfully!", type: "success", closeOnClickOutside: false }).then((type) => {
                            if (type) {
                                GetTemplates();
                            }
                        });
                    }
                    else {
                        $('.loader').hide();
                        swal({ title: "Error!", text: response.data.message == "" ? "Something went wrong.Please try again!" : response.data.message, type: "error", closeOnClickOutside: false });
                    }
                }, function errorCallback(response) {
                    $('.loader').hide();
                    alert(response.data.message);
                    $window.location.reload();
                });
            }
            else {
                $('.loader').hide();
            }
        });
    };

    $scope.ShowTemplateQuestions = function (id) {
        $('.loader').show();
        var requestResponse = PrescreenProjectService.GetTemplateQuestions(id);
        requestResponse.then(function (response) {
            $('.loader').hide();
            $scope.TemplateQuestionList = response.data.questionList;
            $scope.TemplateName = response.data.template.name;
        }, function () {

        });
    };
    $scope.clearText = function () {
        $('#SearchText').val("");
        $scope.query = '';
        $('.clearCrossIcon ').hide();
    }

    $('#SearchText').on("input", function () {
        (this.value !== '') ? $('.clearCrossIcon ').show() : $('.clearCrossIcon ').hide();
    });
});