var myApp = angular.module('ConnectApp');

myApp.controller('LayoutController', function ($scope, $location, LayoutService) {

    $scope.SetTheme = function (Theme) {
        var UserService = LayoutService.SetTheme(Theme);
        UserService.then(function successCallback(response) {
           
        }, function errorCallback(response) {
           
        });
    };
});