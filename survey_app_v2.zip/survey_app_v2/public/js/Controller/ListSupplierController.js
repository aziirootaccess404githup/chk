/// <reference path="../angular.js" />

var App = angular.module('ConnectApp');
App.controller('ListSupplierCtrlcontroller', ['$scope', '$filter', 'SupplierService','paginationService','$window', function ($scope, $filter, SupplierService, paginationService, $window) {
     
    $scope.pageSize = '10';
    $scope.currentPage = 1;
    $scope.supplierTableData = [];
    $scope.supplierTableData1 = [];
    $scope.supplierTableData2 = [];
    $scope.dataget = [];
    $scope.length = '';
    $scope.tlength = '';
    $scope.isEmpty = false;
    $scope.IsRouter = false;
    $('.clearCrossIcon').hide();
     
    GetUsers();


  

    function GetUsers() {
        $('.loader').show();
        var requestResponse = SupplierService.GetAll();
        requestResponse.then(function (response) {
            $('.loader').hide();
            $scope.supplierTableData = response.data.supplierData;
            $scope.getinactive();
            $scope.getactive();
            if ($scope.supplierTableData1.length == 0) {
                $scope.isEmpty = true;
            }
            $scope.supplierTableData2 = response.data.supplierData;
            $scope.length = $scope.supplierTableData.length;
            var inactive = $filter('filter')(response.data.supplierData, { isRemoved: 'true' }).length;
            var active = $filter('filter')(response.data.supplierData, { isRemoved: 'false' }).length;
            $scope.inactive = inactive;
            $scope.active = active;
        }, function () {

        });
    }
    $scope.getactive = function () {
        $scope.supplierTableData1 = []
        $scope.currentPage = 1;
        $scope.supplierTableData1 = $filter('filter')($scope.supplierTableData, { 'isRemoved': false });
        if ($scope.supplierTableData1.length == 0) {
            $scope.isEmpty = true;
        }
         
    }
    $scope.getinactive = function () {

        $scope.supplierTableData1 = []
        $scope.currentPage = 1;
        $scope.supplierTableData1 = $filter('filter')($scope.supplierTableData, { 'isRemoved': true });

        if ($scope.supplierTableData1.length == 0) {
            $scope.isEmpty = true;
        }
    }

    $scope.DisplayTotal = function (SupplierId) {
        $window.open('/Admin/Supplier/TotalProjects?SupplierId=' + SupplierId, '_blank');
    }

    $scope.DisplayActive = function (SupplierId,Flag) {
        $window.open('/Admin/Supplier/TotalProjects?SupplierId=' + SupplierId + '&Flag=' + Flag, '_blank');
    }
    $scope.clearText = function () {
        $('#SearchText').val("");
        $scope.query = '';
        $('.clearCrossIcon').hide();
    }

    $('#SearchText').on("input", function () {
        (this.value !== '') ? $('.clearCrossIcon').show() : $('.clearCrossIcon').hide();
    });

    $scope.ShowSupplierDetail = function (SupplierId) {
        $scope.SupplierDetail = [];
        var requestResponse = SupplierService.GetSupplier(SupplierId);
        requestResponse.then(function (response) {
            $('.loader').hide();
            $scope.SupplierDetail = response.data.listOfMatchingIncome;
            $scope.IsAPI = $scope.SupplierDetail.isAPI;
            $scope.IsRouter = $scope.SupplierDetail.isRouter;
            $scope.IsAffiliate = $scope.SupplierDetail.isAffiliate;
            $scope.IsMaskEntry = $scope.SupplierDetail.isMaskEntry
        }, function () {

        });
    }

    $scope.copyToClipboard = function (elementId) {
        var TestLink = elementId;
        if (document.selection) { // IE
            var range = document.body.createTextRange();
            range.moveToElementText(document.getElementById(TestLink));
            range.select();
        } else if (window.getSelection) {
            var range = document.createRange();
            range.selectNode(document.getElementById(TestLink));
            window.getSelection().removeAllRanges();
            window.getSelection().addRange(range);
        }
        var textArea = document.createElement("textarea");

        textArea.value = document.getElementById(TestLink).innerText;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand("copy");

        textArea.remove();
    }


}]);
