var App = angular.module('ConnectApp');
App.controller('ProfileController', function ($scope, ProfileService) {
    $scope.Username = '';
    $scope.Email = '';
    $scope.ContactNo = '';
    $scope.FirstName = '';
    $scope.LastName = '';
    $scope.Path = '/images/userI.png';
    $scope.AuthKey = '';


    // variable for image container
    const imgDiv = document.querySelector('#img_contain');
    // variable for img tag
    const img = document.querySelector('#image-preview');
    // variable for input tag
    const file = document.querySelector('#file-input');
    // variable for label tag


    // If User hover on profile div


    // Lets work for image showing functinality when we choose an image to upload

    file.addEventListener('change', function () {
        // this refers to file
        const choosedFile = this.files[0];

        if (choosedFile) {

            // FileReader is a predefined function of JS
            const reader = new FileReader();

            reader.addEventListener('load', function () {
                img.setAttribute('src', reader.result);
                $scope.Update();
            });

            reader.readAsDataURL(choosedFile);
        }
    });

    $scope.Update = function () {
        var fileUpload = $("#file-input").get(0);
        var files = fileUpload.files;
        const fileData = new FormData();
        for (var i = 0; i < files.length; i++) {
            fileData.append(files[i].name, files[i]);
        }

        var requestResponse = ProfileService.AddImg(fileData);
        requestResponse.then(function (response) {
            if (response.data.message === "SuccessFully Saved.") {

                swal({ title: "", text: "Profile image uploaded successfully !", type: "success", closeOnClickOutside: false }).then((type) => {
                });

            } else {
                swal({ title: "Error!", text: "Error while uploading Profile Image!", type: "error", closeOnClickOutside: false });
            }
        }, function (resposne) {
            swal({ title: "Error!", text: response.data.message == "" ? "Something went wrong.Please try again!" : response.data.message, type: "error", closeOnClickOutside: false });
        });

    };

    var profileResponse = ProfileService.GetProfileDetail();
    profileResponse.then(function (response) {
        $scope.Username = response.data.profileDetail.userName;
        $scope.Email = response.data.profileDetail.email;
        $scope.ContactNo = response.data.profileDetail.contactNo;
        $scope.FirstName = response.data.profileDetail.firstName;
        $scope.LastName = response.data.profileDetail.lastName;
        if (response.data.profileDetail.profileImage != null && response.data.profileDetail.profileImage != '') {
            $scope.Path = response.data.profileDetail.profileImage;
        }
        $scope.AuthKey = response.data.authDetail;
    }, function () {

    });

    document.getElementById("cp_btn").addEventListener("click", codeSpans);
    function codeSpans() {
        var copyText = document.getElementById("myCodeTxts");
        var textArea = document.createElement("textarea");
        textArea.value = copyText.textContent;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand("Copy");
        textArea.remove();
        swal({ title: "", text: "Activation Code is Copied : " + copyText.innerHTML, closeOnClickOutside: false });
    }


});