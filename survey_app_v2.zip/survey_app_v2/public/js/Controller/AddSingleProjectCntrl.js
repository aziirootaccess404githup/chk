/// <reference path="../angular.min.js" />

var App = angular.module('ConnectApp');
App.controller('AddSingleProjectCntrl', function ($scope, $location, $filter, SingleProjectService) {
    //This will hide the DIV by default.  
    //$scope.IsVisible = false;
    $scope.CheckUniqueIP = true;
    $scope.CheckSpeeder = true;
    $scope.CheckGeoLocation = true;
    $scope.Captcha = false;
    $scope.PreScreen = false;
    $scope.IsTS = false;
    $scope.SampleSize = 0;
    $scope.RespondentClickQuota = 0;
    $scope.SelectedCountries = [];
    $scope.SelectedCountriesList = [];
    MultiselectDropdown();
    document.getElementById('CurrencyCode').value = 1;$('#CurrencyCode').trigger('change');
    
    document.getElementById('StartDate').value = moment().format('DD-MMM-YYYY');
    var endDate = moment(document.getElementById('StartDate').value, "DD-MMM-YYYY").add(1, 'M').endOf("month")
    document.getElementById('EndDate').value = endDate.format('DD-MMM-YYYY');


    //$scope.ShowSinglelink = function (value) {
    //    //If DIV is visible it will be hidden and vice versa.  
    //    $scope.IsVisible = value === "Y";
    //};
    $scope.btnSingleProjectForm = function (command) {
        $('.loader').show();

        var singleprojectCtrlForm = window.$("#add_client_form_SingleProject");
        var issingleprojectCtrlFormValid = singleprojectCtrlForm.valid();
        var checkbox1 = false;
        var checkbox8 = false;
        var checkbox2 = false;

        if ($('#CurrencyCode').val() == "") {
            $('#Currenceerror').html('This field is required');
            $('.loader').hide();
            return false;
        }

        if ($('#CountryId').val() == "") {
            $('#Countryerror').html('This field is required');
            $('.loader').hide();
            return false;
        }


        if ($("#PreScreens").is(":checked")) {
            checkbox8 = true;
            //if ($('#LanguageId').val() == "") {
            //    $('#LanguageIderror').html('This field is required');
            //    if (checkbox1 == false && checkbox2 == false) {
            //        $('#linkerror').html('Please select any one');
            //        $('.loader').hide();
            //        return false;
            //    }
            //    $('.loader').hide();
            //    return false;
            //}
        }


        //if ($("#SingleLink").is(":checked")) {
        //    checkbox1 = true;
        //    var SingleLinkUrl = $('#SingleLinkUrl').val();
        //    var SingleLinkUrlTest = $('#SingleLinkUrlTest').val();
        //    if (SingleLinkUrl == "" || SingleLinkUrl == null) {
        //        $('#ddlSingleLinkUrl').text("This field is required");
        //        $('.loader').hide();
        //        return false;
        //    }
        //    else {
        //        $('#ddlSingleLinkUrl').hide();
        //    }


        //}
        //if ($("#MultiLink").is(":checked")) {
        //    checkbox2 = true;
        //}

        //if (checkbox1 == false && checkbox2 == false) {
        //    $('#linkerror').html('Please select any one');
        //    $('.loader').hide();
        //    return false;
        //}
        var varStartDate = $('#StartDate').val().trim().split("/").reverse().join("-");
        var varEndDate = $('#EndDate').val().trim().split("/").reverse().join("-");
        //if (parseInt($('#SampleSize').val()) > parseInt($('#RespondentClickQuota').val())) {
        //    alert("Respondent Click Quota should not be less than Sample Size!");
        //    $('.loader').hide();
        //    issingleprojectCtrlFormValid = false;
        //    return false;
        //}
        //if (parseInt($('#SupplierCpi').val()) > parseInt($('#Cpi').val())) {
        //    alert("Supplier CPI should not be greater than CPI!");
        //    $('.loader').hide();
        //    issingleprojectCtrlFormValid = false;
        //    return false;
        //}
        if (parseInt($('#AverageLoi').val()) > 120 || parseInt($('#AverageLoi').val()) < 1) {
            swal({ title: "", text: "LOI should not be greater than 120 ", closeOnClickOutside: false });
            $('.loader').hide();
            issingleprojectCtrlFormValid = false;
            return false;
        }
        if (($("#IsChecksum").is(":checked") == true) && ($("#txtchecksum").val() == "")) {
            $('.loader').hide();
            swal({ title: "", text: "Check Sum value is blank!", closeOnClickOutside: false });
            isUpdateSingleProjectFormValid = false;
            return false;
        }
        if (($("#UniqueIP").is(":checked") == true) && ($("#UniqueIPTxt").val() == "")) {
            $('.loader').hide();
            swal({ title: "", text: "Unique value is blank!", closeOnClickOutside: false });
            isUpdateSingleProjectFormValid = false;
            return false;
        }
        if (($("#Speeder").is(":checked") == true) && ($("#SpeederValue").val() == "")) {
            $('.loader').hide();
            swal({ title: "", text: "Speeder value is blank!", closeOnClickOutside: false });
            isUpdateSingleProjectFormValid = false;
            return false;
        }
        if (issingleprojectCtrlFormValid != false) {

            var checkbox3 = false;
            if ($("#chkGeoLocation").is(":checked")) {
                checkbox3 = true;
            }
            var checkbox4 = false;
            if ($("#IsUrlProtection").is(":checked")) {
                checkbox4 = true;
            }
            var checkbox5 = false;
            if ($("#IsDynamicThanksUrl").is(":checked")) {
                checkbox5 = true;
            }
            var checkbox6 = false;
            var SecretKey = '';

            if ($("#IsChecksum").is(":checked")) {
                checkbox6 = true;
                SecretKey = $("#txtchecksum").val();

            }

            var checkbox9 = false;
            if ($("#IsExclude").is(":checked")) {
                checkbox9 = true;
            }
            var checkbox10 = false;
            if ($("#IsMobile").is(":checked")) {
                checkbox10 = true;
            }
            var checkbox11 = false;
            if ($("#IsTablet").is(":checked")) {
                checkbox11 = true;
            }
            var checkbox12 = false;
            if ($("#IsDesktop").is(":checked")) {
                checkbox12 = true;
            }
            var checkbox13 = false;
            var SpeederValue = 0;
            if ($("#Speeder").is(":checked")) {
                checkbox13 = true;
                SpeederValue = parseInt($("#SpeederValue").val());
            }
            var checkbox14 = false;
            if ($("#IsCollectPii").is(":checked")) {
                checkbox14 = true;
            }
            var checkbox15 = false;
            if ($("#IsVPN").is(":checked")) {
                checkbox15 = true;
            }
            var checkbox7 = false;
            var MaxIPCount = 0;
            if ($("#UniqueIP").is(":checked")) {
                checkbox7 = true;
                MaxIPCount = parseInt($("#UniqueIPTxt").val());
            }
            var IsCaptcha = false;
            if ($("#IsCaptcha").is(":checked")) {
                IsCaptcha = true;
            }
            var chkIsTS = false;
            if ($("#IsTS").is(":checked")) {
                chkIsTS = true;
            }
            var IsReInvite = false;
            if ($("#IsReInvite").is(":checked")) {
                IsReInvite = true;
            }
            if (command === "Save") {

                var data = {
                    ProjectId: 0,
                    ProjectCode: null,
                    ProjectCategoryId: $('#ProjectCategoryId').val(),
                    ClientId: $('#ClientId').val(),
                    ClientCode: "C" + $('#ClientId').val(),
                    ClientName: $("#ClientId").find("option:selected").text().trim(),
                    ProjectName: $('#ProjectName').val(),
                    CountryId: 0,                
                    ProjectDescription: $('#ProjectDescription').val(),
                    AverageLoi: $('#AverageLoi').val(),
                    Ir: parseFloat($('#Ir').val()).toFixed(2),
                    ProjectCpi: parseFloat($('#Cpi').val()).toFixed(2),
                    SupplierCpi: parseFloat($('#SupplierCpi').val()).toFixed(2),
                    SampleSize: $('#SampleSize').val(),
                    RespondentClickQuota: $('#RespondentClickQuota').val(),
                    CurrencyCode: $('#CurrencyCode').val(),
                    StartDate: varStartDate,
                    EndDate: varEndDate,
                    //IsMultiLinkUrl: checkbox2,
                    //IsTestLink: checkbox1,
                    IsPreScreen: checkbox8,
                    IsReContact: false,
                    IsMultipleVariable: false,
                    IsDeDuplication: false,
                    ProjectManager: $('#ProjectManager').val().trim(),
                    ManagerId: $('#ManagerId').val().trim(),
                    IsActive: false,
                    IsArchive: false,
                    //SingleLinkUrl: $('#SingleLinkUrl').val(),
                    //SingleLinkUrlTest: $('#SingleLinkUrlTest').val(),
                    LanguageId: $('#LanguageId').val(),
                    LanguageCode: null,
                    LanguageName: $("#LanguageId").find("option:selected").text().trim(),

                    IsGeoLocation: checkbox3,
                    MaxIPCount: MaxIPCount,
                    IsClientUrlProtection: false,
                    IsMacAddress: checkbox7,
                    IsChecksum: checkbox6,
                    IsUrlProtection: checkbox4,
                    IsDynamicThanksUrl: checkbox5,
                    Note: $('#Note').val(),
                    IsOneQuestionPerPage: false,
                    Cpi1: 0,
                    Cpi2: 0,
                    RevisedProjectCpi: $('#Cpi').val(),
                    ParentProjectId: 0,
                    IsExclude: checkbox9,
                    IsMobile: checkbox10,
                    IsTablet: checkbox11,
                    IsDesktop: checkbox12,
                    IsSpeeder: checkbox13,
                    IsCollectPii: checkbox14,
                    IsVPN: checkbox15,
                    IsCaptcha: IsCaptcha,
                    SpeederValue: SpeederValue,
                    FlagId: 1,
                    PreScreenMessage: null,
                    PreScreenLanguageCode: $('#LanguageId').val(),
                    ProjectStatus: null,
                    ProjectType: 'S',
                    SecretKey: SecretKey,
                    IsTS: chkIsTS,
                    IsReInvite: IsReInvite,
                    CountryCodeList: $('#CountryId').val()
                };

                window.$("#btnSave").attr("disabled", "disabled");
                var UserService = SingleProjectService.AddandEditServices(data);


                UserService.then(function successCallback(response) {
                    $('.loader').hide();
                    if (response.data.message === "SuccessFully Saved.") {
                        swal({ title: "", text: "Project added successfully!", type: "success", closeOnClickOutside: false }).then((type) => {
                            // swal("", "Project Added Successfully!", "success").then((type) => {
                            if (type) {
                                //window.Location.href = '/Admin/Project/SingleProject';
                                window.location.href = '/Admin/Project/MultiTabbedDetail?ProjectId=' + response.data.projIds;
                            }
                        });
                    }
                    else {
                        $('.loader').hide();
                        swal({ title: "Error!", text: response.data.message == "" ? "Something went wrong.Please try again!" : response.data.message, type: "error", closeOnClickOutside: false });
                        // swal("Error..!", response.data.message, "error");
                        $('#btnSave').attr('disabled', false);
                    }
                }, function errorCallback(response) {
                    $('.loader').hide();
                    swal({ title: "", text: response.data.message, closeOnClickOutside: false });
                    $('#btnSave').attr('disabled', false);
                    window.Location.href = '/Admin/Project/SingleProject';
                    // called asynchronously if an error occurs  
                    // or server returns response with an error status.  
                });
            }
        }
        else {
            $('.loader').hide();
        }
    };
    $('#CountryId').on('change', function () {
        $('#Countryerror').html('');
        $scope.AddCountry();        
        $scope.GetCloneCountryLanguage();               
    });

    $scope.GetCloneCountryLanguage = function () {
        // Select the country code
        var CountryCode = "";
        if ($scope.SelectedCountries.length > 1) {
            CountryCode = "MLC"
        }
        else {
             CountryCode = $scope.SelectedCountries[0];
        }
        var UserService = SingleProjectService.GetCloneCountryLanguage(CountryCode);
        UserService.then(function successCallback(response) {
            window.$('#LanguageId').html(""); //clear the dropdownlist
            //add the first select option
            window.$('#LanguageId').append($('<option></option>').val("").html("-- Select Language --"));
            //loop through the return data and check the value
            for (var i = 0; i < response.data.length; i++) {
                window.$('#LanguageId').append($('<option></option>').val(response.data[i].languageId).html(response.data[i].languageName));
            }
        });
    };

    $scope.AddCountry = function () {
        $scope.SelectedCountries = [];
        $scope.SelectedCountriesList = [];
        $("#CountryId option:selected").each(function () {
            var $this = $(this);
            if ($this.length) {
                var countryode = $this.val();
                var countryname = $this.text();
                $scope.SelectedCountries.push(countryode);
                $scope.SelectedCountriesList.push({ CountryCode: countryode, CountryName: countryname });
            }
        });
    };

    $scope.RemoveCountry = function (CountryCode) {
        $scope.SelectedCountries.splice($scope.SelectedCountries.indexOf(CountryCode), 1);
        $scope.SelectedCountriesList.splice($scope.SelectedCountriesList.findIndex(x => x.CountryCode === CountryCode), 1);
        window.$('#CountryId').val($scope.SelectedCountries);
        MultiselectDropdown();
        $scope.GetCloneCountryLanguage();
    };
});
