var App = angular.module('ConnectApp');
App.service("PrescreenProjectService", function ($http) {
    var $this = this;
    //------------Start---------------This service used to bind Get Total Question data in gride
    $this.GetQuestionMappingListByProject = function (id) {
        var request = $http({
            method: 'GET',
            url: '/Admin/PreScreen/GetQuestionMappingListByProject?projectId=' + id,
        });
        return request;
    };
    //------------End---------------This service used to bind Get Total Question data in gride

    //------------Start---------------This service used to bind Get Show prescreen message
    $this.GetPreScreenMessage = function (projectId, languageid) {
        var request = $http({
            method: 'Get',
            url: '/Admin/PreScreen/GetPreScreenMessage',
            params: { projectId: projectId, languageid: languageid },
            contentType: "application/json;charset=utf-8"
        });
        
        return request;
    };
    //------------End---------------This service used to bind Get Show prescreen message


    $this.EditTempQuestionData = function (ProjectId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/PreScreen/GetQuestionTempData?projectId=' + ProjectId,
            dataType: "json",
        });
        return request;
    };
    $this.DeleteTableRowPreScreen = function (questionMappingId,ProjectId) {
        var request = $http({
            method: 'Post',
            url: '/Admin/PreScreen/UpdateQuestionMapping',
            params: { QuestionMappingId: questionMappingId, ProjectId: ProjectId },
            dataType: "json",
        });
        return request;
    };

    $this.GetsearchTextQuestion = function (searchQuestions, languageCode, ProjectId) {
        
        var request = $http({
            method: 'Get',
            url: '/Admin/PreScreen/GetsearchQuestions',
            params: { searchQuestions: searchQuestions, languageCode: languageCode, ProjectId: ProjectId },
            contentType: "application/json;charset=utf-8"
        });
        return request;
    };
    $this.GetquestionView = function (projectId, languageid) {

        var request = $http({
            method: 'Get',
            url: '/Admin/PreScreen/GetquestionView',
            params: { projectId: projectId, languageid: languageid },
            contentType: "application/json;charset=utf-8"
        });
        return request;
    };
    $this.GetQuestionOptionValidationMapping = function (projectId, questionId) {

        var request = $http({
            method: 'Get',
            url: '/Admin/PreScreen/GetQuestionOptionValidationMapping',
            params: { projectId: projectId, questionId: questionId },
            contentType: "application/json;charset=utf-8"
        });
        return request;
    };
    $this.GetAgeQuestionOptionValidation = function (projectId, questionId) {

        var request = $http({
            method: 'Get',
            url: '/Admin/PreScreen/GetAgeQuestionOptionValidation',
            params: { projectId: projectId, questionId: questionId },
            contentType: "application/json;charset=utf-8"
        });
        return request;
    };
    $this.EditGetQuestionOptionbyQuestionId = function (questionId) {

        var request = $http({
            method: 'Get',
            url: '/Admin/PreScreen/EditGetQuestionOptionbyQuestionId',
            params: {questionId: questionId },
            contentType: "application/json;charset=utf-8"
        });
        return request;
    };

    $this.AddQuestion = function (question) {
        var request = $http({
            url: '/Admin/PreScreen/AddQuestion',
            data: {
                QuestionId: question.questionId,
                ProjectId: question.projectId,
                QuestionDesc: question.questionDesc,
                LanguageCode: question.LanguageCode,
                ControlTypeId: question.ControlTypeId,
                QuestionTitle: question.questionTitle,
                mapping: question.mapping,
                QuestionOption: question.QuestionOption,
                MinLength: question.minLength,
                MaxLength: question.maxLength,
                TextTypeId: question.textTypeId
            },
            method: "Post"
        });
        return request;
    };
    $this.PostPreScreen = function (objQuestionMapping) {
        var request = $http({
            url: '/Admin/PreScreen/PostPreScreen',
            params: objQuestionMapping,
            method: "Post"
        });
        return request;
    };
    $this.PostPreScreenValidation = function (questionValidationList) {
        var request = $http({
            url: '/Admin/PreScreen/PostPreScreenValidation',
            data: { ProjectId: questionValidationList.ProjectId, finalArray: questionValidationList.finalArray },
            //params: questionValidationList,
            method: "Post",
            //contentType: "application/json;charset=utf-8"
        });
        return request;
    };
    $this.PostAgeValidation = function (questionValidation) {
        var request = $http({
            url: '/Admin/PreScreen/PostAgeValidation',
            params: questionValidation,
            method: "Post"
        });
        return request;
    };
    $this.AddPreScreenMessage = function (objPreScreenMessage) {
        var request = $http({
            url: '/Admin/PreScreen/AddPreScreenMessage',
            params: objPreScreenMessage,
            method: "Post"
        });
        return request;
    };
    $this.UploadFilesPrescreenZipcode = function (fileData) {
        var request = $http.post('/Admin/PreScreen/UploadFilesPrescreenZipcode', fileData, {
            withCredentials: true,
            headers: { 'Content-Type': undefined },
            transformRequest: angular.identity
        });
        return request;
    };

    $this.UpdateQuestionMappingSortedid = function (questionId, ProjectId, sortId) {
        var request = $http({
            method: 'POST',
            url: '/Admin/PreScreen/UpdateQuestionMappingSortedid',
            params: { questionId: questionId, ProjectId: ProjectId, sortId: sortId },
            contentType: "application/json;charset=utf-8"
        });

        return request;
    };

    $this.GetPreScreenTemplates = function () {
        var request = $http({
            method: 'GET',
            url: '/Admin/PreScreenTemplate/GetPreScreenTemplates',
        });
        return request;
    };

    $this.AddPreScreenTemplate = function (TemplateName) {
        var request = $http({
            method: 'POST',
            url: '/Admin/PreScreenTemplate/AddPreScreenTemplate',
            params: { TemplateName: TemplateName },
        });
        return request;
    };

    $this.GetTemplateQuestions = function (id) {
        var request = $http({
            method: 'POST',
            url: '/Admin/PreScreenTemplate/GetTemplateQuestions',
            params: { TemplateId: id },
        });
        return request;
    };

    $this.GetsearchTextQuestionForTemplate = function (searchQuestions, TemplateId, LanguageCode) {

        var request = $http({
            method: 'Get',
            url: '/Admin/PreScreenTemplate/GetsearchQuestionsForTemplate',
            params: { searchQuestions: searchQuestions, TemplateId: TemplateId, LanguageCode: LanguageCode },
            contentType: "application/json;charset=utf-8"
        });
        return request;
    };

    $this.AddQuestionForTemplate = function (TemplateId,QuestionId) {

        var request = $http({
            method: 'Post',
            url: '/Admin/PreScreenTemplate/AddQuestionForTemplate',
            params: { TemplateId: TemplateId, QuestionId: QuestionId },
            contentType: "application/json;charset=utf-8"
        });
        return request;
    };

    $this.DeleteQuestionForTemplate = function (Id) {

        var request = $http({
            method: 'Post',
            url: '/Admin/PreScreenTemplate/DeleteQuestionForTemplate',
            params: { Id: Id },
            contentType: "application/json;charset=utf-8"
        });
        return request;
    };

    $this.DeleteTemplate = function (Id) {

        var request = $http({
            method: 'Post',
            url: '/Admin/PreScreenTemplate/DeleteTemplate',
            params: { Id: Id },
            contentType: "application/json;charset=utf-8"
        });
        return request;
    };

    $this.MapTemplateQuestions = function (ProjectId,TemplateId,LanguageCode) {

        var request = $http({
            method: 'Post',
            url: '/Admin/PreScreen/MapTemplateQuestions',
            params: { ProjectId: ProjectId, TemplateId: TemplateId, LanguageCode: LanguageCode  },
            contentType: "application/json;charset=utf-8"
        });
        return request;
    };

    $this.UpdateTemplateName = function (TemplateId,TemplateName) {

        var request = $http({
            method: 'Post',
            url: '/Admin/PreScreen/UpdateTemplateName',
            params: { TemplateId: TemplateId, TemplateName: TemplateName },
            contentType: "application/json;charset=utf-8"
        });
        return request;
    };

    $this.UpdateTemplateSortId = function (TemplateDetails) {

        var request = $http({
            method: 'Post',
            url: '/Admin/PreScreenTemplate/UpdateTemplateSortId',
            params: { TemplateDetails: TemplateDetails },
            contentType: "application/json;charset=utf-8"
        });
        return request;
    };

    $this.uploadZipCode = function (fileData) {
        var request = $http.post('/Admin/PreScreen/uploadZipCode', fileData, {
            withCredentials: true,
            headers: { 'Content-Type': undefined },
            transformRequest: angular.identity
        });
        return request;
    };

    $this.UpdateIsPreScreenMessage = function (ProjectId, IsPreScreenMessage) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/UpdateIsPreScreenMessage',
            params: { ProjectId: ProjectId, IsPreScreenMessage: IsPreScreenMessage },
        });
        return request;
    };

    $this.GetPreScreenMappedVariableList = function (projectId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/Project/GetPreScreenMappedVariableList?projectId=' + projectId,
            dataType: "json",
        });
        return request;
    };

    $this.GetQuestionOptionLibrary = function (projectId) {
        var request = $http({
            method: 'Get',
            url: '/Clients/ClientProjects/GetQuestionOptionLibrary?projectId=' + projectId,
            dataType: "json",
        });
        return request;
    };

    $this.UpdateClientTargeting = function (clientTargeting, filepath, ProjectId) {
        var request = $http({
            method: 'Post',
            url: '/Clients/ClientProjects/UpdateClientTargeting',
            params: { ProjectId: ProjectId },
            data: { clientTargettingLists: clientTargeting, FilePath: filepath },
            contentType: "application/json;charset=utf-8"
        });
        return request;
    };

    $this.GetQuestionMappingResponse = function (questionId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/PreScreen/GetQuestionMappingResponse',
            params: { questionId: questionId },
            contentType: "application/json;charset=utf-8"
        });
        return request;
    };
    $this.SaveIsConditional = function (projectId, IsConditional, questionId) {
        var request = $http({
            method: 'Post',
            url: '/Admin/PreScreen/SaveIsConditional',
            params: { ProjectId : projectId, IsConditional : IsConditional, QuestionId: questionId },
            dataType: "json",
        });
        return request;
    };
    $this.GetLogicQuestionList = function (projectId, sortid, questionId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/PreScreen/GetLogicQuestionList',
            params: { ProjectId: projectId, sortid: sortid, questionId: questionId },
            dataType: "json",
        });
        return request;
    };
    $this.GetLogicOptionList = function (projectId, questionId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/PreScreen/GetLogicOptionList',
            params: { ProjectId: projectId, QuestionId: questionId },
            dataType: "json",
        });
        return request;
    };
    $this.AddLogicQuestions = function (ProjectId, DervivedQuestionId, optionId, LogicQuestionId) {
        var request = $http({
            method: 'Post',
            url: '/Admin/PreScreen/AddLogicQuestions',
            params: { ProjectId: ProjectId, DervivedQuestionId: DervivedQuestionId, optionId: optionId, LogicQuestionId: LogicQuestionId },
            dataType: "json",
        });
        return request;
    };
    $this.DeleteLogicPreScreen = function (projectId, optionId, questionId) {
        var request = $http({
            method: 'Post',
            url: '/Admin/PreScreen/DeleteLogicPreScreen',
            params: { ProjectId: projectId, QuestionId: questionId, optionId: optionId },
            dataType: "json",
        });
        return request;
    };
});