
var App = angular.module('ConnectApp');
App.service("SingleProjectService", function ($http) {
    var $this = this;

    $this.AddandEditServices = function (models) {

        var request = $http({
            url: '/Admin/Project/ManageProject',
            params: models,
            method: "POST"

        });

        return request;
    };
    $this.UpdatedsSupplierMapping = function (models) {

        var request = $http({
            url: '/Admin/Project/UpdateSupplierMapping',
            params: models,
            method: "POST"

        });

        return request;
    };

    $this.GetAll = function () {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetAllProject'
        });
        return request;
    };

    $this.GetProjectListWithProcedurePaging = function (PageNo, PageSize, Criteria, ClientSearch, ProjectManager, ProjectCode, Flag) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/GetProjectListWithProcedurePaging',
            params: { PageNo: PageNo, PageSize: PageSize, Criteria: Criteria, ClientSearch: ClientSearch, ProjectManager: ProjectManager, ProjectCode: ProjectCode, Flag: Flag },
        });
        return request;
    };


    $this.AddQuestion = function (question) {
        var request = $http({
            url: '/Admin/PreScreen/AddQuestion',
            params: question,
            method: "Post"
        });
        return request;
    };
    $this.PostPreScreen = function (objQuestionMapping) {
        var request = $http({
            url: '/Admin/PreScreen/PostPreScreen',
            params: objQuestionMapping,
            method: "Post"
        });
        return request;
    };
    $this.PostPreScreenValidation = function (questionValidationList) {
        var request = $http({
            url: '/Admin/PreScreen/PostPreScreenValidation',
            data: { ProjectId: questionValidationList.ProjectId, finalArray: questionValidationList.finalArray },
            //params: questionValidationList,
            method: "Post",
            // dataType: "json"
        });
        return request;
    };


    $this.GetProjectupdetails = function (ProjectId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetProjectdata?ProjectId=' + ProjectId,
            dataType: "json"
        });
        return request;
    };
    $this.GetProject = function (ProjectId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/ProjectViewDetails?ProjectId=' + ProjectId,
            dataType: "json"
        });
        return request;
    };
    //$this.GetProjectViewDetails = function (ProjectId) {
    //    var request = $http({
    //        method: 'GET',
    //        url: '/Admin/Project/ProjectViewDetails?ProjectId=' + ProjectId,
    //        dataType: "json"
    //    });
    //    return request;
    //};
    $this.UpdateProjectFlag = function (models) {

        var request = $http({
            url: '/Admin/Project/UpdateProjectFlag',
            params: models,
            method: "POST"

        });

        return request;
    };

    $this.SaveSupplierMapping = function (supplierMapping) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/SaveSupplierMappingData',
            params: supplierMapping,
        });
        return request;
    };

    $this.GetSupplierMappingData = function (projectId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/Project/GetSupplierMappingData?projectId=' + projectId,
            dataType: "json",
        });
        return request;
    };

    $this.EditTempQuestionData = function (ProjectId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/PreScreen/GetQuestionTempData?projectId=' + ProjectId,
            dataType: "json",
        });
        return request;
    };


    $this.UpdateSupplierMapping = function (id, IsAllowTraffic, supplier) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/UpdateAllowTraffic',
            params: { ProjectSupplierMappingId: id, IsAllowTraffic: IsAllowTraffic, supplier: supplier },
        });
        return request;
    };

    $this.UpdateIsPreScreen = function (id, IsPreScreen) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/UpdateIsPreScreen',
            params: { ProjectSupplierMappingId: id, IsPreScreen: IsPreScreen },
        });
        return request;
    };

    $this.UpdateSupplierMappingTest = function (id, IsTestLink) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/UpdateIsTestLink',
            params: { ProjectSupplierMappingId: id, IsTestLink: IsTestLink },
        });
        return request;
    };

    $this.UpdateOpenForMapping = function (id, IsOpenForMapping) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/UpdateIsOpenForMapping',
            params: { ProjectId: id, IsOpenForMapping: IsOpenForMapping },
        });
        return request;
    };

    $this.uploadMultilink = function (fileData) {
        var request = $http.post('/Admin/Multilink/uploadmultilinkFile', fileData, {
            withCredentials: true,
            headers: { 'Content-Type': undefined },
            transformRequest: angular.identity
        });
        return request;
    };
    $this.Listmultiactivity = function (ProjectId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/Multilink/GetMultipleLinkList?projectId=' + ProjectId,
        });
        return request;
    };

    $this.DownloadMultiLink = function (ProjectId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/Multilink/DownloadMultiLink?projectId=' + ProjectId,
        });
        return request;
    };

    $this.DownloadSupplierLinks = function (multiLinkActivityId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/Multilink/DownloadSupplierLinks?multiLinkActivityId=' + multiLinkActivityId,
        });
        return request;
    };

    $this.DownloadRejectedLinks = function (multiLinkActivityId) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Multilink/DownloadRejectedLinks',
            params: { multiLinkActivityId: multiLinkActivityId }
        });
        return request;
    };

    $this.DownloadLinks = function (filename) {
        var request = $http({
            method: 'Get',
            url: '/Admin/Multilink/DownloadLinks?filename=' + filename,
        });
        return request;
    };


    $this.GetProjectReport = function (projectId, type) {
        var request = $http({
            method: 'Get',
            url: '/Admin/Project/GetProjectReport',
            params: { ProjectId: projectId, Type: type },
            contentType: "application/json;charset=utf-8"
        });
        return request;
    };

    $this.GetSupplierAllList = function () {
        var request = $http({
            method: 'Get',
            url: '/Admin/Project/GetSupplierAllList',
        });
        return request;
    };
    $this.GetSupplier = function (SupplierId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Supplier/getSupplierdata?SupplierId=' + SupplierId,
            dataType: "json"
        });
        return request;
    };


    $this.CreateCloneProject = function (models) {

        var request = $http({
            url: '/Admin/Project/CreateCloneProject',
            params: models,
            method: "POST",
        });

        return request;
    };

    $this.GetCloneCountryLanguage = function (CountryCode) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetCloneCountryLanguage?CountryCode=' + CountryCode,
            dataType: "json"
        });
        return request;
    };

    $this.CheckStaticPostBackUrl = function (SupplierId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/CheckStaticPostBackUrl?SupplierId=' + SupplierId,
            dataType: "json"
        });
        return request;
    };

    $this.uploadToken = function (fileData) {
        var request = $http.post('/Admin/Report/uploadToken', fileData, {
            withCredentials: true,
            headers: { 'Content-Type': undefined },
            transformRequest: angular.identity
        });
        return request;
    };

    $this.GetSupplierQuestionLibrary = function (supplier, supplerid, ProjectId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Supplier/GetSupplierQuestionLibrary',
            params: { supplier: supplier, SupplierId: supplerid, ProjectId: ProjectId },
            dataType: "json"
        });
        return request;
    };

    $this.GetSupplierTargeting = function (supplierId, ProjectId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Supplier/GetSupplierTargeting',
            params: { SupplierId: supplierId, ProjectId: ProjectId },
            dataType: "json"
        });
        return request;
    };

    $this.UpdateSupplierTargeting = function (data) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Supplier/UpdateSupplierTargeting',
            data: data,
        });
        return request;
    };
    $this.GetSingleLink = function (ProjectId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/Multilink/GetSingleLink?projectId=' + ProjectId,
        });
        return request;
    };

    $this.UpdateSingleLink = function (models) {
        var request = $http({
            params: models,
            method: "POST",
            url: '/Admin/Multilink/UpdateSingleLink',
        });
        return request;
    };

    $this.RetrySupplierMapping = function (SupplierName, SupplierId, ProjectId) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/RetrySupplierMapping',
            params: { SupplierName: SupplierName, SupplierId: SupplierId, ProjectId: ProjectId },
        });
        return request;
    };

    $this.GetSupplierCPI = function (SupplierId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Supplier/GetSupplierCPI?SupplierId=' + SupplierId,
            dataType: "json"
        });
        return request;
    };

    $this.uploadZipCode = function (fileData) {
        var request = $http.post('/Admin/PreScreen/uploadZipCode', fileData, {
            withCredentials: true,
            headers: { 'Content-Type': undefined },
            transformRequest: angular.identity
        });
        return request;
    };

    $this.GetAllFlags = function () {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetAllProjectFlag'
        });
        return request;
    };

    $this.GetDashboardStats = function () {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetDashboardStats'
        });
        return request;
    };

    $this.SaveDynamicVariableMapping = function (variableMapping) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/SaveDynamicVariableMapping',
            params: variableMapping,
        });
        return request;
    };
    $this.GetVariableList = function (projectId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/Project/GetVariableList?projectId=' + projectId,
            dataType: "json",
        });
        return request;
    };

    $this.UpdateDynamicVariableMappingFlag = function (projectId, IsVariableMapping ) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/UpdateDynamicVariableMappingFlag',
            params: { projectId: projectId, IsVariableMapping: IsVariableMapping  },
        });
        return request;
    };
    $this.DeleteSingleMappedVariable = function (VariableId, ProjectId) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/DeleteSingleMappedVariable',
            params: { VariableId: VariableId, ProjectId: ProjectId},
        });
        return request;
    };
    $this.DeleteDynamicVariables = function (ProjectId) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/DeleteDynamicVariables',
            params: {ProjectId: ProjectId },
        });
        return request;
    };
    $this.TestSupplierMapping = function (ProjectId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Supplier/TestSupplierMapping?ProjectId=' + ProjectId,
            dataType: "json"
        });
        return request;
    };
    $this.GetSupplierURL = function (ProjectId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetSupplierURL',
            params: { ProjectId: ProjectId },
        });
        return request;
    };
    $this.GetOpenForAllFlag = function (ProjectId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetOpenForAllFlag?ProjectId=' + ProjectId,
            dataType: "json"
        });
        return request;
    };
    $this.SaveCountryLink = function (models) {
        var request = $http({
            data: models,
            method: "POST",
            url: '/Admin/Multilink/SaveCountryLink',
        });
        return request;
    };
    $this.GetTrackerProjectDetail = function (ProjectId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetTrackerProjectDetail?ProjectId=' + ProjectId,
            dataType: "json"
        });
        return request;
    };
    $this.CheckSingleModeProject = function (ProjectId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/Multilink/CheckSingleModeProject?projectId=' + ProjectId,
        });
        return request;
    };
    $this.AddSingleLinkForSingleMode = function (ProjectId, IsOverWrite) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Multilink/AddSingleLinkForSingleMode',
            params: { ProjectId: ProjectId, IsOverWrite: IsOverWrite }
        });
        return request;
    };

    $this.GetCompletedCycleForExclude = function (ProjectId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetCompletedCycleForExclude',
            params: { ProjectId: ProjectId },
            dataType: "json"
        });
        return request;
    };

    $this.UpdateCycleSelection = function (data) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/UpdateCycleSelection',
            data: data
        });

        return request;
    };

    $this.GetCycleStatistics = function (cycleId, projectId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/Project/GetCycleStatistics',
            params: { cycleId, projectId },
            dataType: "json"
        });
        return request;
    }

    $this.EditCycleDetails = function (data) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/EditCycleDetails',
            data: data
        });
        return request;
    };
    $this.GetGroupSupplierMappingData = function (projectId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/Project/GetGroupSupplierMappingData?projectId=' + projectId,
            dataType: "json",
        });
        return request;
    };

    $this.SaveGroupSupplierMapping = function (supplierMapping) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/SaveGroupSupplierMappingData',
            params: supplierMapping,
        });
        return request;
    };

    $this.UpdateGroupSupplierMapping = function (models) {

        var request = $http({
            url: '/Admin/Project/UpdateGroupSupplierMapping',
            params: models,
            method: "POST"

        });

        return request;
    };

    $this.GetClientRevenue = function (StartDate, EndDate, RevenueValue) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetClientRevenue',
            params: { StartDate: StartDate, EndDate: EndDate, RevenueValue: RevenueValue },
        });
        return request;
    };
    $this.GetTodayCompleteCount = function () {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetTodayCompleteCount',
        });
        return request;
    };

    $this.UpdateIsReattempt = function (id, IsReattempt) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/UpdateIsReattempt',
            params: { ProjectSupplierMappingId: id, IsReattempt: IsReattempt },
        });
        return request;
    };

    $this.GetRouterProjectPriority = function () {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetRouterProjectPriority'
        });
        return request;
    };

    $this.UpdateSecurity = function (id, IsAllowSecurity) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/UpdateSecurity',
            params: { ProjectSupplierMappingId: id, IsAllowSecurity: IsAllowSecurity},
        });
        return request;
    };

    $this.GetGroupQuotaDetail = function (projectId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/Project/GetGroupQuotaDetail',
            params: { projectId: projectId }
        });
        return request;
    }

    $this.SaveGroupQuota = function (ProjectId, CountryId, Quota) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/SaveGroupQuota',
            params: { ProjectId: ProjectId, CountryId: CountryId, Quota: Quota },
        });
        return request;
    };

    $this.GetProjectDetailData = function (ProjectId, command) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetProjectDetailData',
            params: { ProjectId: ProjectId, Type: command },
            dataType: "json"
        });
        return request;
    };
    $this.GetSupplierList = function (ProjectId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/SupplierViewDetails?ProjectId=' + ProjectId,
            dataType: "json"
        });
        return request;
    };
    $this.GetProjectandPrescreenStats = function (type, projectId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetProjectandPrescreenStats?type=' + type + "&projectId=" + projectId
        });
        return request;
    };

    $this.GetStaticRedirect = function (supplierId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetStaticRedirect?supplierId=' + supplierId
        });
        return request;
    };
    $this.GetNoteDetail = function (projectId) {
        var request = $http({
            method: 'Get',
            url: '/Admin/Project/GetNoteDetail',
            params: { projectId: projectId }
        });
        return request;
    }
    $this.GetActivityData = function (projectId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetActivityData?ProjectId=' + projectId
        });
        return request;
    };
    $this.GetSubActivity = function (Id) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetSubActivity?Id=' + Id
        });
        return request;
    };
    $this.AddActivity = function (models) {

        var request = $http({
            url: '/Admin/Project/AddActivity',
            params: models,
            method: "POST"

        });

        return request;
    };

    $this.GetDashboardData = function () {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetDashboardData'
        });
        return request;
    };

    $this.GetNewProjectListWithProcedurePaging = function (PageNo, PageSize, Criteria, ClientSearch, ProjectManager, ProjectCode, Flag) {
        var request = $http({
            method: 'Post',
            url: '/Admin/Project/GetNewProjectListWithProcedurePaging',
            params: { PageNo: PageNo, PageSize: PageSize, Criteria: Criteria, ClientSearch: ClientSearch, ProjectManager: ProjectManager, ProjectCode: ProjectCode, Flag: Flag },
        });
        return request;
    };

});