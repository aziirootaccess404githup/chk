var App = angular.module('ConnectApp');
App.service("ProfileService", function ($http) {
    var $this = this;
    $this.GetProfileDetail = function () {
        var request = $http({
            method: 'GET',
            url: '/Account/GetProfileDetail',
            dataType: "json"
        });
        return request;
    };

    $this.AddImg = function (fileData) {
        var request = $http.post('/Account/AddImg', fileData, {
            withCredentials: true,
            headers: { 'Content-Type': undefined },
            transformRequest: angular.identity
        });
        return request;
    };

});


