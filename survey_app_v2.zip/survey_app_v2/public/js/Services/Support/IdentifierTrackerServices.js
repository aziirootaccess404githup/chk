
var App = angular.module('ConnectApp');
App.service("IdentifierTrackerServices", function ($http) {
    var $this = this;
    $this.GetIdentifierTrackerList = function (Identifiers) {

        var request = $http({
            url: '/Admin/Support/GetIdentifierTrackerList',
            method: "POST",
            data: { Identifiers: Identifiers }

        });

        return request;
    };

    $this.Reconcile = function (Identifiers, Command) {

        var request = $http({
            url: '/Admin/Support/Reconcile',
            method: "POST",
            data: { IdentifiersList: Identifiers, Command: Command }

        });

        return request;
    };

    $this.Download = function (Identifiers) {
        var request = $http({
            method: 'POST',
            url: '/Admin/Support/Download',
            data: { IdentifiersList: Identifiers }
        });
        return request;
    };
});