
var App = angular.module('ConnectApp');
App.service("IPTrackerServices", function ($http) {
    var $this = this;
    $this.GetIPTrackerList = function (Ip) {

        var request = $http({
            url: '/Admin/Support/GetIPTrackerList?Ip=' + Ip,
            method: "GET"

        });

        return request;
    };

    $this.BlockIp = function (Ip, Comment) {

        var request = $http({
            url: '/Admin/Support/BlockIp?Ip=' + Ip + '&Comment=' + Comment,
            method: "POST"

        });

        return request;
    };

    $this.GetBlockedIPList = function () {

        var request = $http({
            url: '/Admin/Support/GetBlockedIPList',
            method: "GET"

        });

        return request;
    };

    $this.UnblockIp = function (Ip) {

        var request = $http({
            url: '/Admin/Support/UnblockIp?Ip=' + Ip,
            method: "POST"

        });

        return request;
    };

});