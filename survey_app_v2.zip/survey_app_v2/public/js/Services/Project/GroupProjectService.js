var App = angular.module('ConnectApp');
App.service("GroupProjectService", function ($http) {

    var $this = this;

    $this.AddGroupProject = function (models) {

        var request = $http({
            url: '/Admin/Project/AddGroupProject',
            params: models,
            method: "POST"

        });

        return request;
    };

    $this.UpdateGroupProject = function (models) {
        var request = $http({
            url: '/Admin/Project/UpdateGroupProject',
            params: models,
            method: "POST"

        });
        return request;
    };

    $this.GetGroupProjectDetail = function (projectId) {

        var request = $http({
            url: '/Admin/Project/GetGroupProjectDetail?projectId=' + projectId,
            method: "GET"
        });
        return request;
    };
    $this.GetCloneCountryLanguage = function (countryCode) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetCloneCountryLanguage?CountryCode=' + countryCode,
            dataType: "json"
        });
        return request;
    };

    $this.GetGroupProjectList = function (searchProjectCode) {
        var request = $http({
            url: '/Admin/Project/GetGroupProjectList?searchProjectCode=' + searchProjectCode,
            method: "GET"

        });
        return request;
    };

    $this.GetGroupProjectListReport = function (ProjectId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetGroupProjectListReport?ProjectId=' + ProjectId,
            dataType: "json"
        });
        return request;
    };
    $this.SelectedCountries = function (ProjectId) {
        var request = $http({
            url: '/Admin/Report/SelectedCountries?ProjectId=' + ProjectId,
            method: "GET"

        });
        return request;
    }
    $this.UpdateGroupProjectStatus = function (flagId, ProjectId) {
        var request = $http({
            url: '/Admin/Project/UpdateGroupProjectStatus?flagId=' + flagId + "&ProjectId=" + ProjectId,
            method: "POST"

        });
        return request;
    };

});