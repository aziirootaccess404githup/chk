var App = angular.module('ConnectApp');
App.service("RecontactProjectService", function ($http) {

    var $this = this;

    //$this.GetSingleProjectList = function (searchValue) {

    //    var request = $http({
    //        url: '/Admin/Project/GetSingleProjectList?searchValue=' + searchValue,            
    //        method: "GET"

    //    });
    //    return request;
    //}
    $this.GetRecontactProjectList = function (searchValue) {

        var request = $http({
            url: '/Admin/Project/GetRecontactProjectList?searchValue=' + searchValue,
            method: "GET"

        });
        return request;
    }




    $this.GetSuppliersStat = function (projectId) {

        var request = $http({
            url: '/Admin/Supplier/GetSuppliersStatData?ProjectId=' + projectId,            
            method: "GET"

        });

        return request;
    };

    $this.GetProjectClientCountry = function (projectId) {

        var request = $http({
            url: '/Admin/Project/GetProjectClientCountry?ProjectId=' + projectId,
            method: "GET"

        });
        return request;
    }

    $this.GetRecontactGroup = function (projectId) {

        var request = $http({
            url: '/Admin/Project/GetRecontactGroup?ProjectId=' + projectId,
            method: "GET"

        });
        return request;
    }


    $this.AddandEditProject = function (models) {

        var request = $http({
            url: '/Admin/Project/ManageProject',
            params: models,
            method: "POST"

        });

        return request;
    };

    $this.AddRecontactProject = function (models) {

        var request = $http({
            url: '/Admin/Project/AddRecontactProject',
            params: models,
            method: "POST"

        });

        return request;
    };

    $this.GetCloneCountryLanguage = function (CountryCode) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetCloneCountryLanguage?CountryCode=' + CountryCode,
            dataType: "json"
        });
        return request;
    };

    $this.GetChildProjectList = function (ProjectId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetChildProjectList?ProjectId=' + ProjectId,
            dataType: "json"
        });
        return request;
    };
});