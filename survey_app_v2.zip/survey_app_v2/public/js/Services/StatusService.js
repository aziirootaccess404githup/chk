var App = angular.module('ConnectApp');
App.service("StatusService", function ($http) {
    var $this = this;

    $this.GetAllStatus = function () {
        var request = $http({
            method: 'GET',
            url: '/Admin/Support/GetAllStatusOption'
        });
        return request;
    };

    $this.GetSupplierStats = function (tid) {
        var request = $http({
            method: 'GET',
            url: '/SupplierStats/GetSupplierStats?tid=' + tid,
            dataType: "json"
        });
        return request;
    };
    $this.GetProjectStats = function (ProjectId, IsToggle) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Support/GetProjectStats?projectId=' + ProjectId,
            params: { ProjectId: ProjectId, IsToggle: IsToggle },
            dataType: "json"
        });
        return request;
    };
    $this.GetMultiCountryNames = function (ProjectId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Support/GetMultiCountryNames?projectId=' + ProjectId,
            params: { ProjectId: ProjectId },
            dataType: "json"
        });
        return request;
    };

});