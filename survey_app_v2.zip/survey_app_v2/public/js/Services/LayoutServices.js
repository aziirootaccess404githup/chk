var App = angular.module('ConnectApp');
App.service("LayoutService", function ($http) {
    var $this = this;
    $this.SetTheme = function (Theme) {

        var request = $http({
            url: '/Account/SetTheme',
            params: { Theme: Theme },
            method: "POST"

        });
        return request;
    };
});