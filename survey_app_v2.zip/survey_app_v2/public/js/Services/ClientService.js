
var App = angular.module('ConnectApp');
App.service("ClientService", function ($http) {
    var $this = this;
    $this.AddandEditServices = function (user) {
         
        var request = $http({
            url: '/Admin/Client/AddClient',
            params: user,
            method: "POST"

        });

        return request;
    };

    $this.GetAll = function () {
        var request = $http({
            method: 'GET',
            url: '/Admin/Client/getAlldata'
        });
        return request;
    };

    $this.GetClient = function (ClientId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Client/getClientdata?ClientId=' + ClientId,
            dataType: "json"
        });
        return request;
    };

    $this.GetTotalClientProjects = function (ClientId, PageNo, PageSize, Flag) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Client/GetTotalClientProjects',
            params: { ClientId: ClientId, PageNo: PageNo, PageSize: PageSize, Flag: Flag },
        });
        return request;
    };

});