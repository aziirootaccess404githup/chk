var ListCntrl = angular.module('ConnectApp');
//ListCntrl.service('ListCntrlOp', ['$http', function ($http) {
ListCntrl.service('ListCntrlOp', function ($http) {
    var ListCntrlOp = {};
    ListCntrlOp.GetLists = function (languageCodes, countryCode) {
        var request = $http({
            url: '/Admin/Question/GetQuestionData',//?languageCode=' + languageCode + "&catagoryId" + categoryId,
            params: { languageCode: languageCodes, countryCode: countryCode },
            method: "Get"
        });
        return request;
    };

    ListCntrlOp.AddQuestion = function (question) {
        var request = $http({
            url: '/Admin/Question/AddQuestionData',//?languageCode=' + languageCode + "&catagoryId" + categoryId,
            params: question,
            method: "Post"
        });
        return request;
    };
    ListCntrlOp.UpdateQuestion = function (question) {
        var request = $http({
            url: '/Admin/Question/UpdateQuestionData',//?languageCode=' + languageCode + "&catagoryId" + categoryId,
            params: question,
            method: "Post"
        });
        return request;
    };

    ListCntrlOp.GetSubCategory = function (categoryId) {
        var request = $http({
            url: '/Admin/Question/GetSubCategory',//?languageCode=' + languageCode + "&catagoryId" + categoryId,
            params: { catagoryId: categoryId },
            method: "Get"
        });
        return request;
    };
    ListCntrlOp.CheckQuestionTitle = function (questionTitle, LanguageCode, CountryCode) {
        var request = $http({
            url: '/Admin/Question/CheckQuestionTitle',
            params: { questionTitle: questionTitle, LanguageCode: LanguageCode, CountryCode: CountryCode },
            method: "Get"
        });
        return request;
    };

    ListCntrlOp.GetLanguageByCountryCode = function (CountryCode) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Question/GetLanguageByCountryCode?CountryCode=' + CountryCode,
            dataType: "json"
        });
        return request;
    };

    ListCntrlOp.GetQuestionDetail = function (questionTitle) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Question/GetQuestionDetail?questionTitle=' + questionTitle
        });
        return request;
    };

    return ListCntrlOp;
    //}]);
});