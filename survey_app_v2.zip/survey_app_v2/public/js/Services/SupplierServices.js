
var App = angular.module('ConnectApp');
App.service("SupplierService", function ($http) {
    var $this = this;
    $this.AddandEditServices = function (user) {

        var request = $http({
            url: '/Admin/Supplier/AddSuppliers',
            params: user,
            method: "POST"

        });

        return request;
    };

    $this.GetAll = function () {
        var request = $http({
            method: 'GET',
            url: '/Admin/Supplier/getAlldata'
        });
        return request;
    };

    $this.GetSupplier = function (SupplierId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Supplier/getSupplierdata?SupplierId=' + SupplierId,
            dataType: "json"
        });
        return request;
    };
    $this.GetSupplierActiveStatusCode = function (SupplierId, status) {
        var request = $http({
            method: 'POST',
            url: '/Admin/Supplier/SupplierActiveStatusCode',
            params: { SupplierId: SupplierId, status: status },
            contentType: "application/json;charset=utf-8"
        });

        return request;
    };

    $this.GetTotalProjects = function (SupplierId, PageNo, PageSize, Flag) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Supplier/GetTotalProjects',
            params: { SupplierId: SupplierId, PageNo: PageNo, PageSize: PageSize, Flag: Flag },
        });
        return request;
    };


});