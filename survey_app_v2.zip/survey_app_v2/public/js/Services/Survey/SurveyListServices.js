
var App = angular.module('ConnectApp');
App.service("SurveyListServices", function ($http) {
    var $this = this;

    $this.GetSurveyList = function (data) {

        var request = $http({
            url: '/Admin/Client/GetSurveyList',
            data: data,
            method: "POST"

        });

        return request;
    };

    $this.GetSurveyData = function (ClientId, SurveyId) {

        var request = $http({
            url: '/Admin/Client/GetSurveyData',
            params: { ClientId: ClientId, SurveyId: SurveyId },
            method: "GET"

        });

        return request;
    };

    $this.AddandEditServices = function (models) {

        var request = $http({
            url: '/Admin/Project/ManageProject',
            params: models,
            method: "POST"

        });

        return request;
    };

    $this.GetCloneCountryLanguage = function (countryId) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Project/GetCloneCountryLanguage?CountryId=' + countryId,
            dataType: "json"
        });
        return request;
    };

    $this.GetClientCountryList = function (client) {
        var request = $http({
            method: 'GET',
            url: '/Admin/Client/GetClientCountryList',
            params: { client: client },
        });
        return request;
    };

});