var Report = angular.module('ConnectApp');
//ListCntrl.service('ListCntrlOp', ['$http', function ($http) {
Report.service('Report', function ($http) {
    var Report = {};
    
    Report.SearchClientList = function (criteria) {
        var request = $http({
            url: '/Admin/Report/SearchClientList?criteria=' + criteria,
            method: "GET"

        });
        return request;
    };

    Report.SearchSupplierList = function (criteria) {
        var request = $http({
            url: '/Admin/Report/SearchSupplierList?criteria=' + criteria,
            method: "GET"

        });
        return request;
    };
    Report.SearchManagerList = function (criteria) {
        var request = $http({
            url: '/Admin/Report/SearchManagerList?criteria=' + criteria,
            method: "GET"

        });
        return request;
    };
    Report.ClientSupplierReport = function (Id,fromDate,toDate,type) {
        var request = $http({
            url: '/Admin/Report/ClientSupplierReport',
            params: { Id: Id, fromDate: fromDate, toDate: toDate, type: type },
            method: "GET"
        });
        return request;
    };
    Report.ProjectActivityLogReport = function (ProjectCode) {
        var request = $http({
            url: '/Admin/Report/ProjectActivityLogReport',
            params: { ProjectCode: ProjectCode },
            method: "GET"
        });
        return request;
    };
    Report.SearchProjectList = function (searchValue) {
        var request = $http({
            url: '/Admin/Report/SearchProjectList?searchValue=' + searchValue,
            method: "GET"

        });
        return request;
    }
    Report.SelectedCountries = function (ProjectId) {
        var request = $http({
            url: '/Admin/Report/SelectedCountries?ProjectId=' + ProjectId,
            method: "GET"

        });
        return request;
    }
    Report.GetAllPendingReports = function () {
        var request = $http({
            url: '/Admin/Report/GetAllPendingReports',
            method: "GET"
        });
        return request;
    }
    Report.GetDailyProgressReport = function (Id, fromDate, toDate) {
        var request = $http({
            url: '/Admin/Report/GetDailyProgressReport',
            params: { Id: Id, fromDate: fromDate, toDate: toDate},
            method: "GET"
        });
        return request;
    }
    Report.GetManagerList = function () {
        var request = $http({
            url: '/Admin/Report/GetManagerList',
            method: "GET"
        });
        return request;
    }
    Report.UserActivityReport = function (ProjectCode, fromDate, toDate, Userid) {
        var request = $http({
            url: '/Admin/Report/GetUserActivityReport',
            params: { ProjectCode: ProjectCode, Userid: Userid, fromDate: fromDate, toDate: toDate },
            method: "GET"
        });
        return request;
    };
    return Report;
    //}]);
});
